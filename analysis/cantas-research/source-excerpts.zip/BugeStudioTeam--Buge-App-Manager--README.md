<p align="center">
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/refs/heads/main/images/icons/icon.png" alt="Buge App Manager Icon" width="120"/>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/refs/heads/main/images/title.svg" alt="Buge App Manager" width="520"/>
</p>


<p align="center">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Android/android2.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Kotlin/kotlin2.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/Github/github3.svg">
  <img src="https://ziadoua.github.io/m3-Markdown-Badges/badges/LicenceGPLv3/licencegplv32.svg">
</p>

**Buge App Manager** is a powerful Android utility application designed for advanced app and permission management. Built with **Material Design 3 Expressive**, it offers a modern and intuitive interface for granular control over your device.

---

## 📸 Screenshots

<div style="overflow-x: auto; white-space: nowrap; padding: 10px 0;">

<img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/main/images/Screenshot_Apps.png" width="260" style="display: inline-block; margin-right: 12px;" />
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/main/images/Screenshot_Permissions.png" width="260" style="display: inline-block; margin-right: 12px;" />
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/main/images/Screenshot_Activities.png" width="260" style="display: inline-block; margin-right: 12px;" />
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/main/images/Screenshot_Settings.png" width="260" style="display: inline-block; margin-right: 12px;" />
  <img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/main/images/Screenshot_Details.png" width="260" style="display: inline-block; margin-right: 12px;" />

</div>

## ✨ Features

### 🚀 Core Capabilities

| Feature                             | Description                                                                      |
| ----------------------------------- | -------------------------------------------------------------------------------- |
| **Shizuku Integration**             | Operates with Shizuku authorization for elevated control without requiring root  |
| **ROOT Integration**                | Operates with ROOT authorization for elevated control                            |
| **App Management**                  | Browse and manage both user-installed and system applications with ease          |
| **Material Design 3 Expressive UI** | Clean, system-themed interface that follows the latest Android design guidelines |

### 📱 Apps Manager

- Manage any apps, **including system apps**

- Allow advanced operations such as **Uninstall**, **Disable**, **Force Stop**, etc.

- Allow **restoring uninstalled system apps**

### 🔐 Permission Manager

- View and modify app permissions by **category**
- Supported categories include: Microphone, Camera, Location access, Notifications, Phone & Contacts, Storage and other
- Filter permissions by **granted** or **denied** status
- Batch permission operations for multiple apps

### 🧩 Activities Launcher

- Browse and **launch** any activity
- View unexported activities

### 🛡️ Privacy & Security

- Quickly identify which apps have access to sensitive permissions
- Optimize your device's security posture with clear permission insights

---

## 📋 Requirements

| Requirement | Minimum Version                       |
| ----------- | ------------------------------------- |
| Android OS  | 8.0 (API 26) or higher                |
| Shizuku     | Installed and authorized              |
| ROOT        | Device has been rooted and authorized |

Choose between **Shizuku** or **ROOT** authorization.

> **Note**: [Shizuku](https://shizuku.rikka.app/) is required for advanced permission management features.

---

## 🎓 Tutorial: How to Perform Batch Permission Operations for Your Apps

Follow this step-by-step guide to manage the same permission type across multiple applications simultaneously.

### 📹 Video Tutorial

<p align="center">
  <video src="https://github.com/user-attachments/assets/10c03a7b-d235-4006-9a60-7fe228d3db83" width="100%" controls>
  </video>
</p>

---

## 🌐 Supported languages

- English - en

- Français - fr

- Deutsch - de

- Русский - ru

- Português - pt

- Português (Brasil) - pt-rBR

- Español - es

- 中文 (简体) - zh

- 中文 (繁体) - zh-rTW

- العربية - ar

- 日本語 - ja

- 한국어 - ko

[If you'd like to request support for a specific language, please open an issue and let us know](https://github.com/BugeStudioTeam/Buge-App-Manager/issues)

---

## 📦 Installation

[<img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/refs/heads/main/images/README/Release/get-it-on-github.svg"
    alt="Get it on GitHub"
    height="80">](https://github.com/BugeStudioTeam/Buge-App-Manager/releases)[<img src="https://raw.githubusercontent.com/BugeStudioTeam/Buge-App-Manager/refs/heads/main/images/README/Release/get-it-on-telegram.svg"
 alt="Get it on Telegram"
 height="80">](https://t.me/bugestudio)
 
---

## ⭐ Star History

<a href="https://www.star-history.com/?repos=BugeStudioTeam%2FBuge-App-Manager&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=BugeStudioTeam/Buge-App-Manager&type=date&theme=dark&legend=top-left&sealed_token=jZTygO4Pz6rzviCijN8nJplRBnY9ehHv9qlEL3uW_EVikw63qBIraoS0O7xV3lszffGX8ONjKeKo47xT3Kv8g6xwd27TbnZVekUxbRDLPGZjUlV7vc-jPg" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=BugeStudioTeam/Buge-App-Manager&type=date&legend=top-left&sealed_token=jZTygO4Pz6rzviCijN8nJplRBnY9ehHv9qlEL3uW_EVikw63qBIraoS0O7xV3lszffGX8ONjKeKo47xT3Kv8g6xwd27TbnZVekUxbRDLPGZjUlV7vc-jPg" />
   <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=BugeStudioTeam/Buge-App-Manager&type=date&legend=top-left&sealed_token=jZTygO4Pz6rzviCijN8nJplRBnY9ehHv9qlEL3uW_EVikw63qBIraoS0O7xV3lszffGX8ONjKeKo47xT3Kv8g6xwd27TbnZVekUxbRDLPGZjUlV7vc-jPg" />
 </picture>
</a>

---

## 📄 License

This project is licensed under the **GNU General Public License v3.0**.
