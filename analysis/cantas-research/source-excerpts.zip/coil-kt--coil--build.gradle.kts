import coil3.enableComposeMetrics
import coil3.groupId
import coil3.publicModules
import coil3.versionName
import com.diffplug.gradle.spotless.SpotlessExtension
import dev.drewhamilton.poko.gradle.PokoPluginExtension
import org.jetbrains.kotlin.compose.compiler.gradle.ComposeCompilerGradlePluginExtension
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinProjectExtension
import org.jetbrains.kotlin.gradle.dsl.KotlinVersion
import org.jetbrains.kotlin.gradle.dsl.abi.BinariesSource
import org.jetbrains.kotlin.gradle.dsl.abi.ExperimentalAbiValidation
import org.jetbrains.kotlin.gradle.targets.js.testing.KotlinJsTest
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
import org.jetbrains.kotlin.gradle.tasks.KotlinJvmCompile

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath(libs.gradlePlugin.android)
        classpath(libs.gradlePlugin.atomicFu)
        classpath(libs.gradlePlugin.jetbrainsCompose)
        classpath(libs.gradlePlugin.composeCompiler)
        classpath(libs.gradlePlugin.mavenPublish)
        classpath(libs.gradlePlugin.paparazzi)
        classpath(libs.gradlePlugin.roborazzi)
    }
}

plugins {
    alias(libs.plugins.baselineProfile) apply false
    alias(libs.plugins.poko) apply false
    alias(libs.plugins.spotless)
    id("coil3.verify-skiko-versions")
    // https://github.com/gradle/gradle/issues/20084#issuecomment-1060822638
    id("org.jetbrains.dokka")
}

dokka {
    dokkaGeneratorIsolation = ClassLoaderIsolation()
    dokkaPublications.configureEach {
        outputDirectory.set(layout.projectDirectory.dir("docs/api"))
    }
}

dependencies {
    for (module in publicModules) {
        dokka(project(":$module"))
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }

    // Necessary to publish to Maven.
    group = groupId
    version = versionName

    // Target JVM 11.
    tasks.withType<JavaCompile>().configureEach {
        sourceCompatibility = JavaVersion.VERSION_11.toString()
        targetCompatibility = JavaVersion.VERSION_11.toString()
        options.compilerArgs = options.compilerArgs + "-Xlint:-options"
    }
    tasks.withType<KotlinJvmCompile>().configureEach {
        compilerOptions.jvmTarget = JvmTarget.JVM_11

        // R8 uses the module name embedded in Kotlin metadata to generate filenames.
        // AGP rejects ':' in those filenames when packaging a release build with R8.
        // https://github.com/coil-kt/coil/issues/3585
        compilerOptions.moduleName.set(compilerOptions.moduleName.get().replace(':', '_'))
    }

    // Target Kotlin 2.2.
    tasks.withType<KotlinCompile>().configureEach {
        compilerOptions.apiVersion = KotlinVersion.KOTLIN_2_2
        compilerOptions.languageVersion = KotlinVersion.KOTLIN_2_2
    }

    // https://issuetracker.google.com/issues/411739086?pli=1
    tasks.withType<AbstractTestTask>().configureEach {
        failOnNoDiscoveredTests = false
    }

    // Uninstall test APKs after running instrumentation tests.
    tasks.configureEach {
        if (name == "connectedDebugAndroidTest") {
            finalizedBy("uninstallDebugAndroidTest")
        }
    }

    pluginManager.apply("com.diffplug.spotless")

    extensions.configure<SpotlessExtension> {
        kotlin {
            target("**/*.kt", "**/*.kts")
            ktlint(libs.versions.ktlint.get()).editorConfigOverride(ktlintRules)
            endWithNewline()
            leadingTabsToSpaces()
            trimTrailingWhitespace()
        }
    }

    plugins.withId("org.jetbrains.kotlin.plugin.compose") {
        extensions.configure<ComposeCompilerGradlePluginExtension> {
            stabilityConfigurationFiles.add {
                rootDir.resolve("coil-core/compose_compiler_config.conf")
            }

            if (enableComposeMetrics && name in publicModules) {
                val outputDir = layout.buildDirectory.dir("composeMetrics").get().asFile
                metricsDestination = outputDir
                reportsDestination = outputDir
            }
        }
    }

    plugins.withId("dev.drewhamilton.poko") {
        extensions.configure<PokoPluginExtension> {
            pokoAnnotation = "coil3/annotation/Poko"
        }
    }

    // https://youtrack.jetbrains.com/issue/CMP-5831
    configurations.all {
        resolutionStrategy.eachDependency {
            if (requested.group == "org.jetbrains.kotlinx" && requested.name == "atomicfu") {
                useVersion(libs.versions.atomicfu.get())
            }
        }
    }

    if (project.name in publicModules) {
        configureAbiValidation()
        configureAndroidAbiValidation()
    }

    // Skiko's runtime files are ESM-only so preload our shim to let Node require them during tests.
    tasks.withType<KotlinJsTest>().configureEach {
        nodeJsArgs.add("--require")
        val skikoMjsWorkaround = rootProject.layout.projectDirectory
            .file("gradle/nodejs/registerSkikoMjsWorkaround.cjs")
            .asFile
        nodeJsArgs.add(skikoMjsWorkaround.absolutePath)
    }
}

@OptIn(ExperimentalAbiValidation::class)
fun Project.configureAbiValidation() {
    afterEvaluate {
        val kotlinExtension = extensions.findByType<KotlinProjectExtension>() ?: return@afterEvaluate

        kotlinExtension.abiValidation {
            referenceDumpDir.set(layout.projectDirectory.dir("api"))
            filters {
                exclude {
                    annotatedWith.add("coil3.annotation.InternalCoilApi")
                }
            }
            binariesSource.set(BinariesSource.MAIN_COMPILATION)
        }
    }
}

fun Project.configureAndroidAbiValidation() {
    plugins.withId("com.android.library") {
        afterEvaluate {
            configureAndroidAbiValidation(
                subdirectoryName = "",
                dependencyTaskNames = listOf(
                    "compileReleaseKotlin",
                    "compileReleaseJavaWithJavac",
                ),
                classfiles = files(
                    layout.buildDirectory.dir("intermediates/built_in_kotlinc/release/compileReleaseKotlin/classes"),
                    layout.buildDirectory.dir("intermediates/javac/release/compileReleaseJavaWithJavac/classes"),
                ),
            )
        }
    }

    plugins.withId("com.android.kotlin.multiplatform.library") {
        afterEvaluate {
            configureAndroidAbiValidation(
                subdirectoryName = "android",
                dependencyTaskNames = listOf(
                    "compileAndroidMain",
                    "compileAndroidMainJavaWithJavac",
                ),
                classfiles = files(
                    layout.buildDirectory.dir("classes/kotlin/android/main"),
                    layout.buildDirectory.dir("classes/java/android/main"),
                    layout.buildDirectory.dir("intermediates/javac/androidMain/classes"),
                ),
            )
        }
    }
}

private fun Project.configureAndroidAbiValidation(
    subdirectoryName: String,
    dependencyTaskNames: List<String>,
    classfiles: FileCollection,
) {
    val dependencyTasks = tasks.matching { it.name in dependencyTaskNames }
    tasks.matching { it.name == "internalDumpKotlinAbi" }.configureEach {
        dependsOn(dependencyTasks)
        configureKotlinAbiDumpInput(subdirectoryName, classfiles)
    }
}

private fun Task.configureKotlinAbiDumpInput(
    subdirectoryName: String,
    classfiles: FileCollection,
) {
    val dumpTaskClass = javaClass
    val getJvm = runCatching { dumpTaskClass.getMethod("getJvm") }.getOrNull() ?: return
    val jvmProperty = getJvm.invoke(this)

    val propertyClass = jvmProperty.javaClass
    val get = propertyClass.getMethod("get")
    val set = propertyClass.getMethod("set", Iterable::class.java)

    val existingEntries = mutableListOf<Any>()
    val currentEntries = get.invoke(jvmProperty)
    if (currentEntries is Iterable<*>) {
        currentEntries.filterNotNullTo(existingEntries)
    } else {
        return
    }

    val entryClass = existingEntries.firstOrNull()?.javaClass
        ?: runCatching {
            dumpTaskClass.classLoader.loadClass(
                $$"org.jetbrains.kotlin.gradle.tasks.abi.KotlinAbiDumpTaskImpl$JvmTargetInfo",
            )
        }.getOrNull()
        ?: return

    val getSubdirectoryName = entryClass.getMethod("getSubdirectoryName")
    if (existingEntries.any { getSubdirectoryName.invoke(it) == subdirectoryName }) return

    val constructor = entryClass.getConstructor(String::class.java, FileCollection::class.java)
    existingEntries.add(constructor.newInstance(subdirectoryName, classfiles))
    set.invoke(jvmProperty, existingEntries)
}

private val ktlintRules = buildMap {
    put("ktlint_code_style", "intellij_idea")

    put("ktlint_standard_annotation", "disabled")
    put("ktlint_standard_blank-line-before-declaration", "disabled")
    put("ktlint_standard_blank-line-between-when-conditions", "disabled")
    put("ktlint_standard_class-signature", "disabled")
    put("ktlint_standard_filename", "disabled")
    put("ktlint_standard_function-expression-body", "disabled")
    put("ktlint_standard_function-signature", "disabled")
    put("ktlint_standard_function-literal", "disabled")
    put("ktlint_standard_indent", "disabled")
    put("ktlint_standard_max-line-length", "disabled")
    put("ktlint_standard_no-blank-line-in-list", "disabled")
    put("ktlint_standard_no-empty-first-line-in-class-body", "disabled")
    put("ktlint_standard_spacing-between-declarations-with-annotations", "disabled")
    put("ktlint_standard_string-template-indent", "disabled")
    put("ktlint_standard_trailing-comma-on-call-site", "enabled")
    put("ktlint_standard_trailing-comma-on-declaration-site", "enabled")
    put("ktlint_standard_try-catch-finally-spacing", "disabled")

    put("ktlint_standard_backing-property-naming", "disabled")
    put("ktlint_standard_function-naming", "disabled")
    put("ktlint_standard_property-naming", "disabled")

    put("ktlint_standard_type-argument-comment", "disabled")
    put("ktlint_standard_type-parameter-comment", "disabled")
    put("ktlint_standard_value-argument-comment", "disabled")
    put("ktlint_standard_value-parameter-comment", "disabled")

    put("ktlint_standard_argument-list-wrapping", "disabled")
    put("ktlint_standard_binary-expression-wrapping", "disabled")
    put("ktlint_standard_condition-wrapping", "disabled")
    put("ktlint_standard_context-receiver-wrapping", "disabled")
    put("ktlint_standard_enum-wrapping", "disabled")
    put("ktlint_standard_if-else-wrapping", "disabled")
    put("ktlint_standard_multiline-expression-wrapping", "disabled")
    put("ktlint_standard_parameter-wrapping", "disabled")
    put("ktlint_standard_parameter-list-wrapping", "disabled")
    put("ktlint_standard_property-wrapping", "disabled")
    put("ktlint_standard_statement-wrapping", "disabled")
    put("ktlint_standard_wrapping", "enabled")
}
