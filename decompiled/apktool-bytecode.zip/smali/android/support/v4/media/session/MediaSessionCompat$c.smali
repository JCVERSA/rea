.class interface abstract Landroid/support/v4/media/session/MediaSessionCompat$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/media/session/MediaSessionCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "c"
.end annotation


# virtual methods
.method public abstract V()Landroid/support/v4/media/session/PlaybackStateCompat;
.end method

.method public abstract X(I)V
.end method

.method public abstract c()Landroid/support/v4/media/session/MediaSessionCompat$Token;
.end method

.method public abstract h()V
.end method

.method public abstract i()Z
.end method

.method public abstract j(I)V
.end method

.method public abstract k()Ljava/lang/String;
.end method

.method public abstract l(Landroid/support/v4/media/session/MediaSessionCompat$b;Landroid/os/Handler;)V
.end method

.method public abstract m(Lax/M0/d;)V
.end method

.method public abstract n(Ljava/lang/CharSequence;)V
.end method

.method public abstract o()Landroid/support/v4/media/session/MediaSessionCompat$b;
.end method

.method public abstract p(Landroid/support/v4/media/MediaMetadataCompat;)V
.end method

.method public abstract p0(I)V
.end method

.method public abstract q(Landroid/app/PendingIntent;)V
.end method

.method public abstract r(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/support/v4/media/session/MediaSessionCompat$QueueItem;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract s(Z)V
.end method

.method public abstract setExtras(Landroid/os/Bundle;)V
.end method

.method public abstract t(Landroid/support/v4/media/session/PlaybackStateCompat;)V
.end method

.method public abstract u()Lax/M0/d;
.end method
