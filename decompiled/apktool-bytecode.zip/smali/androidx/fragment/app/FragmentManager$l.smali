.class Landroidx/fragment/app/FragmentManager$l;
.super Ljava/lang/Object;

# interfaces
.implements Lax/A0/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/FragmentManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "l"
.end annotation


# instance fields
.field private final a:Landroidx/lifecycle/d;

.field private final b:Lax/A0/l;

.field private final c:Landroidx/lifecycle/f;


# direct methods
.method constructor <init>(Landroidx/lifecycle/d;Lax/A0/l;Landroidx/lifecycle/f;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/fragment/app/FragmentManager$l;->a:Landroidx/lifecycle/d;

    iput-object p2, p0, Landroidx/fragment/app/FragmentManager$l;->b:Lax/A0/l;

    iput-object p3, p0, Landroidx/fragment/app/FragmentManager$l;->c:Landroidx/lifecycle/f;

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/FragmentManager$l;->b:Lax/A0/l;

    invoke-interface {v0, p1, p2}, Lax/A0/l;->a(Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method

.method public b(Landroidx/lifecycle/d$b;)Z
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/FragmentManager$l;->a:Landroidx/lifecycle/d;

    invoke-virtual {v0}, Landroidx/lifecycle/d;->b()Landroidx/lifecycle/d$b;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroidx/lifecycle/d$b;->h(Landroidx/lifecycle/d$b;)Z

    move-result p1

    return p1
.end method

.method public c()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/FragmentManager$l;->a:Landroidx/lifecycle/d;

    iget-object v1, p0, Landroidx/fragment/app/FragmentManager$l;->c:Landroidx/lifecycle/f;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/d;->c(Lax/G0/g;)V

    return-void
.end method
