.class interface abstract Landroidx/fragment/app/A;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/ViewGroup;)Landroidx/fragment/app/z;
.end method
