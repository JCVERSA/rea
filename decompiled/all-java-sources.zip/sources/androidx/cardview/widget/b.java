package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
interface b {
    void b(int i, int i2, int i3, int i4);

    void c(Drawable drawable);

    boolean d();

    boolean e();

    Drawable f();

    View g();
}
