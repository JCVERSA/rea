package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/* JADX INFO: loaded from: classes.dex */
public class CardView extends FrameLayout {
    private static final int[] q0 = {R.attr.colorBackground};
    private static final c r0;
    private boolean k0;
    int l0;
    int m0;
    final Rect n0;
    final Rect o0;
    private final b p0;
    private boolean q;

    class a implements b {
        private Drawable a;

        a() {
        }

        @Override // androidx.cardview.widget.b
        public void b(int i, int i2, int i3, int i4) {
            CardView.this.o0.set(i, i2, i3, i4);
            CardView cardView = CardView.this;
            Rect rect = cardView.n0;
            CardView.super.setPadding(i + rect.left, i2 + rect.top, i3 + rect.right, i4 + rect.bottom);
        }

        @Override // androidx.cardview.widget.b
        public void c(Drawable drawable) {
            this.a = drawable;
            CardView.this.setBackgroundDrawable(drawable);
        }

        @Override // androidx.cardview.widget.b
        public boolean d() {
            return CardView.this.getPreventCornerOverlap();
        }

        @Override // androidx.cardview.widget.b
        public boolean e() {
            return CardView.this.getUseCompatPadding();
        }

        @Override // androidx.cardview.widget.b
        public Drawable f() {
            return this.a;
        }

        @Override // androidx.cardview.widget.b
        public View g() {
            return CardView.this;
        }
    }

    static {
        androidx.cardview.widget.a aVar = new androidx.cardview.widget.a();
        r0 = aVar;
        aVar.i();
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.A.a.a);
    }

    public CardView(Context context, AttributeSet attributeSet, int i) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, i);
        Rect rect = new Rect();
        this.n0 = rect;
        this.o0 = new Rect();
        a aVar = new a();
        this.p0 = aVar;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.A.d.a, i, ax.A.c.a);
        int i2 = ax.A.d.d;
        if (typedArrayObtainStyledAttributes.hasValue(i2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(i2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(q0);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(ax.A.b.b) : getResources().getColor(ax.A.b.a));
        }
        ColorStateList colorStateList = colorStateListValueOf;
        float dimension = typedArrayObtainStyledAttributes.getDimension(ax.A.d.e, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(ax.A.d.f, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(ax.A.d.g, 0.0f);
        this.q = typedArrayObtainStyledAttributes.getBoolean(ax.A.d.i, false);
        this.k0 = typedArrayObtainStyledAttributes.getBoolean(ax.A.d.h, true);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.j, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.l, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.n, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.m, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.k, dimensionPixelSize);
        float f = dimension2 > dimension3 ? dimension2 : dimension3;
        this.l0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.b, 0);
        this.m0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.A.d.c, 0);
        typedArrayObtainStyledAttributes.recycle();
        r0.a(aVar, context, colorStateList, dimension, dimension2, f);
    }

    public ColorStateList getCardBackgroundColor() {
        return r0.h(this.p0);
    }

    public float getCardElevation() {
        return r0.c(this.p0);
    }

    public int getContentPaddingBottom() {
        return this.n0.bottom;
    }

    public int getContentPaddingLeft() {
        return this.n0.left;
    }

    public int getContentPaddingRight() {
        return this.n0.right;
    }

    public int getContentPaddingTop() {
        return this.n0.top;
    }

    public float getMaxCardElevation() {
        return r0.g(this.p0);
    }

    public boolean getPreventCornerOverlap() {
        return this.k0;
    }

    public float getRadius() {
        return r0.d(this.p0);
    }

    public boolean getUseCompatPadding() {
        return this.q;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        c cVar = r0;
        if (cVar instanceof androidx.cardview.widget.a) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i);
        if (mode == Integer.MIN_VALUE || mode == 1073741824) {
            i = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(cVar.k(this.p0)), View.MeasureSpec.getSize(i)), mode);
        }
        int mode2 = View.MeasureSpec.getMode(i2);
        if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
            i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(cVar.j(this.p0)), View.MeasureSpec.getSize(i2)), mode2);
        }
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        r0.m(this.p0, ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        r0.m(this.p0, colorStateList);
    }

    public void setCardElevation(float f) {
        r0.f(this.p0, f);
    }

    public void setMaxCardElevation(float f) {
        r0.n(this.p0, f);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i) {
        this.m0 = i;
        super.setMinimumHeight(i);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i) {
        this.l0 = i;
        super.setMinimumWidth(i);
    }

    @Override // android.view.View
    public void setPadding(int i, int i2, int i3, int i4) {
    }

    @Override // android.view.View
    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.k0) {
            this.k0 = z;
            r0.l(this.p0);
        }
    }

    public void setRadius(float f) {
        r0.b(this.p0, f);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.q != z) {
            this.q = z;
            r0.e(this.p0);
        }
    }
}
