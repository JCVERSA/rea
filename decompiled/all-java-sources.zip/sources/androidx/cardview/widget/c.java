package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

/* JADX INFO: loaded from: classes.dex */
interface c {
    void a(b bVar, Context context, ColorStateList colorStateList, float f, float f2, float f3);

    void b(b bVar, float f);

    float c(b bVar);

    float d(b bVar);

    void e(b bVar);

    void f(b bVar, float f);

    float g(b bVar);

    ColorStateList h(b bVar);

    void i();

    float j(b bVar);

    float k(b bVar);

    void l(b bVar);

    void m(b bVar, ColorStateList colorStateList);

    void n(b bVar, float f);
}
