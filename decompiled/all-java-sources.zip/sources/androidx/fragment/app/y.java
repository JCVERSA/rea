package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

/* JADX INFO: loaded from: classes.dex */
final class y extends Writer {
    private StringBuilder X = new StringBuilder(128);
    private final String q;

    y(String str) {
        this.q = str;
    }

    private void a() {
        if (this.X.length() > 0) {
            Log.d(this.q, this.X.toString());
            StringBuilder sb = this.X;
            sb.delete(0, sb.length());
        }
    }

    @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        a();
    }

    @Override // java.io.Writer, java.io.Flushable
    public void flush() {
        a();
    }

    @Override // java.io.Writer
    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == '\n') {
                a();
            } else {
                this.X.append(c);
            }
        }
    }
}
