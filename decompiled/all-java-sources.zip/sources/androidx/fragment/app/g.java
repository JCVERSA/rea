package androidx.fragment.app;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import ax.p015b0.K;

/* JADX INFO: loaded from: classes.dex */
class g {
    private static int a(Fragment fragment, boolean z, boolean z2) {
        if (z2) {
            return z ? fragment.P0() : fragment.Q0();
        }
        return z ? fragment.y0() : fragment.B0();
    }

    /* JADX WARN: Code duplicated, block: B:34:0x006f A[Catch: RuntimeException -> 0x0075, TRY_LEAVE, TryCatch #0 {RuntimeException -> 0x0075, blocks: (B:32:0x0069, B:34:0x006f), top: B:45:0x0069 }] */
    static a b(Context context, Fragment fragment, boolean z, boolean z2) {
        Animator animatorLoadAnimator;
        int iL0 = fragment.L0();
        int iA = a(fragment, z, z2);
        fragment.I2(0, 0, 0, 0);
        ViewGroup viewGroup = fragment.K0;
        if (viewGroup != null) {
            int i = ax.p337y0.b.c;
            if (viewGroup.getTag(i) != null) {
                fragment.K0.setTag(i, null);
            }
        }
        ViewGroup viewGroup2 = fragment.K0;
        if (viewGroup2 != null && viewGroup2.getLayoutTransition() != null) {
            return null;
        }
        Animation animationC1 = fragment.C1(iL0, z, iA);
        if (animationC1 != null) {
            return new a(animationC1);
        }
        Animator animatorD1 = fragment.D1(iL0, z, iA);
        if (animatorD1 != null) {
            return new a(animatorD1);
        }
        if (iA == 0 && iL0 != 0) {
            iA = d(context, iL0, z);
        }
        if (iA != 0) {
            boolean zEquals = "anim".equals(context.getResources().getResourceTypeName(iA));
            if (zEquals) {
                try {
                    Animation animationLoadAnimation = AnimationUtils.loadAnimation(context, iA);
                    if (animationLoadAnimation != null) {
                        return new a(animationLoadAnimation);
                    }
                } catch (Resources.NotFoundException e) {
                    throw e;
                } catch (RuntimeException unused) {
                    try {
                        animatorLoadAnimator = AnimatorInflater.loadAnimator(context, iA);
                        if (animatorLoadAnimator != null) {
                            return new a(animatorLoadAnimator);
                        }
                    } catch (RuntimeException e2) {
                        if (zEquals) {
                            throw e2;
                        }
                        Animation animationLoadAnimation2 = AnimationUtils.loadAnimation(context, iA);
                        if (animationLoadAnimation2 != null) {
                            return new a(animationLoadAnimation2);
                        }
                    }
                }
            } else {
                animatorLoadAnimator = AnimatorInflater.loadAnimator(context, iA);
                if (animatorLoadAnimator != null) {
                    return new a(animatorLoadAnimator);
                }
            }
        }
        return null;
    }

    private static int c(Context context, int i) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(R.style.Animation.Activity, new int[]{i});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, -1);
        typedArrayObtainStyledAttributes.recycle();
        return resourceId;
    }

    private static int d(Context context, int i, boolean z) {
        if (i == 4097) {
            return z ? ax.p337y0.a.e : ax.p337y0.a.f;
        }
        if (i == 8194) {
            return z ? ax.p337y0.a.a : ax.p337y0.a.b;
        }
        if (i == 8197) {
            return z ? c(context, R.attr.activityCloseEnterAnimation) : c(context, R.attr.activityCloseExitAnimation);
        }
        if (i == 4099) {
            return z ? ax.p337y0.a.c : ax.p337y0.a.d;
        }
        if (i != 4100) {
            return -1;
        }
        return z ? c(context, R.attr.activityOpenEnterAnimation) : c(context, R.attr.activityOpenExitAnimation);
    }

    static class a {
        public final Animation a;
        public final Animator b;

        a(Animation animation) {
            this.a = animation;
            this.b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }

        a(Animator animator) {
            this.a = null;
            this.b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }
    }

    static class b extends AnimationSet implements Runnable {
        private final View X;
        private boolean Y;
        private boolean Z;
        private boolean h0;
        private final ViewGroup q;

        b(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.h0 = true;
            this.q = viewGroup;
            this.X = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j, Transformation transformation) {
            this.h0 = true;
            if (this.Y) {
                return !this.Z;
            }
            if (!super.getTransformation(j, transformation)) {
                this.Y = true;
                K.a(this.q, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.Y || !this.h0) {
                this.q.endViewTransition(this.X);
                this.Z = true;
            } else {
                this.h0 = false;
                this.q.post(this);
            }
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.h0 = true;
            if (this.Y) {
                return !this.Z;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.Y = true;
                K.a(this.q, this);
            }
            return true;
        }
    }
}
