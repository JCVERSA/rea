package androidx.fragment.app;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import ax.p035c0.L;

/* JADX INFO: loaded from: classes.dex */
class g {

    static class a {
        public final Animation a;
        public final Animator b;

        a(Animator animator) {
            this.a = null;
            this.b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        a(Animation animation) {
            this.a = animation;
            this.b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    static class b extends AnimationSet implements Runnable {
        private final View X;
        private boolean Y;
        private boolean Z;
        private boolean k0;
        private final ViewGroup q;

        b(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.k0 = true;
            this.q = viewGroup;
            this.X = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j, Transformation transformation) {
            this.k0 = true;
            if (this.Y) {
                return !this.Z;
            }
            if (!super.getTransformation(j, transformation)) {
                this.Y = true;
                L.a(this.q, this);
            }
            return true;
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.k0 = true;
            if (this.Y) {
                return !this.Z;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.Y = true;
                L.a(this.q, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.Y || !this.k0) {
                this.q.endViewTransition(this.X);
                this.Z = true;
            } else {
                this.k0 = false;
                this.q.post(this);
            }
        }
    }

    private static int a(Fragment fragment, boolean z, boolean z2) {
        if (z2) {
            return z ? fragment.L0() : fragment.M0();
        }
        return z ? fragment.u0() : fragment.x0();
    }

    /* JADX WARN: Code duplicated, block: B:34:0x006f A[Catch: RuntimeException -> 0x0075, TRY_LEAVE, TryCatch #0 {RuntimeException -> 0x0075, blocks: (B:32:0x0069, B:34:0x006f), top: B:45:0x0069 }] */
    static a b(Context context, Fragment fragment, boolean z, boolean z2) {
        Animator animatorLoadAnimator;
        int iH0 = fragment.H0();
        int iA = a(fragment, z, z2);
        fragment.E2(0, 0, 0, 0);
        ViewGroup viewGroup = fragment.N0;
        if (viewGroup != null) {
            int i = ax.p403z0.b.c;
            if (viewGroup.getTag(i) != null) {
                fragment.N0.setTag(i, null);
            }
        }
        ViewGroup viewGroup2 = fragment.N0;
        if (viewGroup2 != null && viewGroup2.getLayoutTransition() != null) {
            return null;
        }
        Animation animationY1 = fragment.y1(iH0, z, iA);
        if (animationY1 != null) {
            return new a(animationY1);
        }
        Animator animatorZ1 = fragment.z1(iH0, z, iA);
        if (animatorZ1 != null) {
            return new a(animatorZ1);
        }
        if (iA == 0 && iH0 != 0) {
            iA = d(context, iH0, z);
        }
        if (iA != 0) {
            boolean zEquals = "anim".equals(context.getResources().getResourceTypeName(iA));
            if (zEquals) {
                try {
                    Animation animationLoadAnimation = AnimationUtils.loadAnimation(context, iA);
                    if (animationLoadAnimation != null) {
                        return new a(animationLoadAnimation);
                    }
                } catch (Resources.NotFoundException e) {
                    throw e;
                } catch (RuntimeException unused) {
                    try {
                        animatorLoadAnimator = AnimatorInflater.loadAnimator(context, iA);
                        if (animatorLoadAnimator != null) {
                            return new a(animatorLoadAnimator);
                        }
                    } catch (RuntimeException e2) {
                        if (zEquals) {
                            throw e2;
                        }
                        Animation animationLoadAnimation2 = AnimationUtils.loadAnimation(context, iA);
                        if (animationLoadAnimation2 != null) {
                            return new a(animationLoadAnimation2);
                        }
                    }
                }
            } else {
                animatorLoadAnimator = AnimatorInflater.loadAnimator(context, iA);
                if (animatorLoadAnimator != null) {
                    return new a(animatorLoadAnimator);
                }
            }
        }
        return null;
    }

    private static int c(Context context, int i) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(R.style.Animation.Activity, new int[]{i});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, -1);
        typedArrayObtainStyledAttributes.recycle();
        return resourceId;
    }

    private static int d(Context context, int i, boolean z) {
        if (i == 4097) {
            return z ? ax.p403z0.a.e : ax.p403z0.a.f;
        }
        if (i == 8194) {
            return z ? ax.p403z0.a.a : ax.p403z0.a.b;
        }
        if (i == 8197) {
            return z ? c(context, R.attr.activityCloseEnterAnimation) : c(context, R.attr.activityCloseExitAnimation);
        }
        if (i == 4099) {
            return z ? ax.p403z0.a.c : ax.p403z0.a.d;
        }
        if (i != 4100) {
            return -1;
        }
        return z ? c(context, R.attr.activityOpenEnterAnimation) : c(context, R.attr.activityOpenExitAnimation);
    }
}
