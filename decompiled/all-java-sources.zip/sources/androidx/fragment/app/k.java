package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
class k implements LayoutInflater.Factory2 {
    final FragmentManager q;

    class a implements View.OnAttachStateChangeListener {
        final /* synthetic */ r q;

        a(r rVar) {
            this.q = rVar;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            Fragment fragmentK = this.q.k();
            this.q.m();
            z.n((ViewGroup) fragmentK.O0.getParent(), k.this.q).j();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    k(FragmentManager fragmentManager) {
        this.q = fragmentManager;
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        r rVarX;
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.q);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p403z0.c.a);
        if (attributeValue == null) {
            attributeValue = typedArrayObtainStyledAttributes.getString(ax.p403z0.c.b);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(ax.p403z0.c.c, -1);
        String string = typedArrayObtainStyledAttributes.getString(ax.p403z0.c.d);
        typedArrayObtainStyledAttributes.recycle();
        if (attributeValue == null || !i.b(context.getClassLoader(), attributeValue)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
        }
        Fragment fragmentJ0 = resourceId != -1 ? this.q.j0(resourceId) : null;
        if (fragmentJ0 == null && string != null) {
            fragmentJ0 = this.q.k0(string);
        }
        if (fragmentJ0 == null && id != -1) {
            fragmentJ0 = this.q.j0(id);
        }
        if (fragmentJ0 == null) {
            fragmentJ0 = this.q.u0().a(context.getClassLoader(), attributeValue);
            fragmentJ0.u0 = true;
            fragmentJ0.D0 = resourceId != 0 ? resourceId : id;
            fragmentJ0.E0 = id;
            fragmentJ0.F0 = string;
            fragmentJ0.v0 = true;
            FragmentManager fragmentManager = this.q;
            fragmentJ0.z0 = fragmentManager;
            fragmentJ0.A0 = fragmentManager.w0();
            fragmentJ0.J1(this.q.w0().f(), attributeSet, fragmentJ0.X);
            rVarX = this.q.j(fragmentJ0);
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Fragment " + fragmentJ0 + " has been inflated via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        } else {
            if (fragmentJ0.v0) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
            }
            fragmentJ0.v0 = true;
            FragmentManager fragmentManager2 = this.q;
            fragmentJ0.z0 = fragmentManager2;
            fragmentJ0.A0 = fragmentManager2.w0();
            fragmentJ0.J1(this.q.w0().f(), attributeSet, fragmentJ0.X);
            rVarX = this.q.x(fragmentJ0);
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Retained Fragment " + fragmentJ0 + " has been re-attached via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        }
        ViewGroup viewGroup = (ViewGroup) view;
        ax.B0.c.g(fragmentJ0, viewGroup);
        fragmentJ0.N0 = viewGroup;
        rVarX.m();
        rVarX.j();
        View view2 = fragmentJ0.O0;
        if (view2 == null) {
            throw new IllegalStateException("Fragment " + attributeValue + " did not create a view.");
        }
        if (resourceId != 0) {
            view2.setId(resourceId);
        }
        if (fragmentJ0.O0.getTag() == null) {
            fragmentJ0.O0.setTag(string);
        }
        fragmentJ0.O0.addOnAttachStateChangeListener(new a(rVarX));
        return fragmentJ0.O0;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
