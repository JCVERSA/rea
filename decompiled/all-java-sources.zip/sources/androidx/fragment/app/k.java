package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
class k implements LayoutInflater.Factory2 {
    final m q;

    class a implements View.OnAttachStateChangeListener {
        final /* synthetic */ r q;

        a(r rVar) {
            this.q = rVar;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            Fragment fragmentK = this.q.k();
            this.q.m();
            z.n((ViewGroup) fragmentK.L0.getParent(), k.this.q).j();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    k(m mVar) {
        this.q = mVar;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        r rVarV;
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.q);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p337y0.c.a);
        if (attributeValue == null) {
            attributeValue = typedArrayObtainStyledAttributes.getString(ax.p337y0.c.b);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(ax.p337y0.c.c, -1);
        String string = typedArrayObtainStyledAttributes.getString(ax.p337y0.c.d);
        typedArrayObtainStyledAttributes.recycle();
        if (attributeValue == null || !i.b(context.getClassLoader(), attributeValue)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
        }
        Fragment fragmentH0 = resourceId != -1 ? this.q.h0(resourceId) : null;
        if (fragmentH0 == null && string != null) {
            fragmentH0 = this.q.i0(string);
        }
        if (fragmentH0 == null && id != -1) {
            fragmentH0 = this.q.h0(id);
        }
        if (fragmentH0 == null) {
            fragmentH0 = this.q.s0().a(context.getClassLoader(), attributeValue);
            fragmentH0.r0 = true;
            fragmentH0.A0 = resourceId != 0 ? resourceId : id;
            fragmentH0.B0 = id;
            fragmentH0.C0 = string;
            fragmentH0.s0 = true;
            m mVar = this.q;
            fragmentH0.w0 = mVar;
            fragmentH0.x0 = mVar.u0();
            fragmentH0.N1(this.q.u0().g(), attributeSet, fragmentH0.X);
            rVarV = this.q.j(fragmentH0);
            if (m.H0(2)) {
                Log.v("FragmentManager", "Fragment " + fragmentH0 + " has been inflated via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        } else {
            if (fragmentH0.s0) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
            }
            fragmentH0.s0 = true;
            m mVar2 = this.q;
            fragmentH0.w0 = mVar2;
            fragmentH0.x0 = mVar2.u0();
            fragmentH0.N1(this.q.u0().g(), attributeSet, fragmentH0.X);
            rVarV = this.q.v(fragmentH0);
            if (m.H0(2)) {
                Log.v("FragmentManager", "Retained Fragment " + fragmentH0 + " has been re-attached via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        }
        ViewGroup viewGroup = (ViewGroup) view;
        ax.A0.c.g(fragmentH0, viewGroup);
        fragmentH0.K0 = viewGroup;
        rVarV.m();
        rVarV.j();
        View view2 = fragmentH0.L0;
        if (view2 == null) {
            throw new IllegalStateException("Fragment " + attributeValue + " did not create a view.");
        }
        if (resourceId != 0) {
            view2.setId(resourceId);
        }
        if (fragmentH0.L0.getTag() == null) {
            fragmentH0.L0.setTag(string);
        }
        fragmentH0.L0.addOnAttachStateChangeListener(new a(rVarV));
        return fragmentH0.L0;
    }
}
