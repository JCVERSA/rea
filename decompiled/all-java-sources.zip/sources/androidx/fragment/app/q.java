package androidx.fragment.app;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class q {
    public static void a(Object obj) {
        p pVar;
        Bundle bundle;
        if (!(obj instanceof p) || (bundle = (pVar = (p) obj).s0) == null) {
            return;
        }
        bundle.clear();
        ax.U2.d.c("FRAGMENT_TRANSACTION_TOO_LARGE", new Exception("FRAGMENT_TRANSACTION_TOO_LARGE : " + pVar.q));
    }
}
