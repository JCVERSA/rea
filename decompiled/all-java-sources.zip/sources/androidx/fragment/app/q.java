package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class q implements Parcelable {
    public static final Parcelable.Creator<q> CREATOR = new a();
    final String X;
    final boolean Y;
    final int Z;
    final int h0;
    final String i0;
    final boolean j0;
    final boolean k0;
    final boolean l0;
    final Bundle m0;
    final boolean n0;
    final int o0;
    Bundle p0;
    final String q;

    class a implements Parcelable.Creator<q> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public q createFromParcel(Parcel parcel) {
            return new q(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public q[] newArray(int i) {
            return new q[i];
        }
    }

    q(Fragment fragment) {
        this.q = fragment.getClass().getName();
        this.X = fragment.i0;
        this.Y = fragment.r0;
        this.Z = fragment.A0;
        this.h0 = fragment.B0;
        this.i0 = fragment.C0;
        this.j0 = fragment.F0;
        this.k0 = fragment.p0;
        this.l0 = fragment.E0;
        this.m0 = fragment.j0;
        this.n0 = fragment.D0;
        this.o0 = fragment.V0.ordinal();
    }

    Fragment a(i iVar, ClassLoader classLoader) {
        Fragment fragmentA = iVar.a(classLoader, this.q);
        Bundle bundle = this.m0;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        fragmentA.J2(this.m0);
        fragmentA.i0 = this.X;
        fragmentA.r0 = this.Y;
        fragmentA.t0 = true;
        fragmentA.A0 = this.Z;
        fragmentA.B0 = this.h0;
        fragmentA.C0 = this.i0;
        fragmentA.F0 = this.j0;
        fragmentA.p0 = this.k0;
        fragmentA.E0 = this.l0;
        fragmentA.D0 = this.n0;
        fragmentA.V0 = androidx.lifecycle.d.b.values()[this.o0];
        Bundle bundle2 = this.p0;
        if (bundle2 != null) {
            fragmentA.X = bundle2;
        } else {
            fragmentA.X = new Bundle();
        }
        return fragmentA;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.q);
        sb.append(" (");
        sb.append(this.X);
        sb.append(")}:");
        if (this.Y) {
            sb.append(" fromLayout");
        }
        if (this.h0 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.h0));
        }
        String str = this.i0;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.i0);
        }
        if (this.j0) {
            sb.append(" retainInstance");
        }
        if (this.k0) {
            sb.append(" removing");
        }
        if (this.l0) {
            sb.append(" detached");
        }
        if (this.n0) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.q);
        parcel.writeString(this.X);
        parcel.writeInt(this.Y ? 1 : 0);
        parcel.writeInt(this.Z);
        parcel.writeInt(this.h0);
        parcel.writeString(this.i0);
        parcel.writeInt(this.j0 ? 1 : 0);
        parcel.writeInt(this.k0 ? 1 : 0);
        parcel.writeInt(this.l0 ? 1 : 0);
        parcel.writeBundle(this.m0);
        parcel.writeInt(this.n0 ? 1 : 0);
        parcel.writeBundle(this.p0);
        parcel.writeInt(this.o0);
    }

    q(Parcel parcel) {
        this.q = parcel.readString();
        this.X = parcel.readString();
        this.Y = parcel.readInt() != 0;
        this.Z = parcel.readInt();
        this.h0 = parcel.readInt();
        this.i0 = parcel.readString();
        this.j0 = parcel.readInt() != 0;
        this.k0 = parcel.readInt() != 0;
        this.l0 = parcel.readInt() != 0;
        this.m0 = parcel.readBundle();
        this.n0 = parcel.readInt() != 0;
        this.p0 = parcel.readBundle();
        this.o0 = parcel.readInt();
    }
}
