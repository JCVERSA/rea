package androidx.fragment.app;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
class x implements androidx.lifecycle.c, ax.p016b1.d, ax.F0.t {
    private final androidx.lifecycle.q X;
    private androidx.lifecycle.g Y = null;
    private ax.p016b1.c Z = null;
    private final Fragment q;

    x(Fragment fragment, androidx.lifecycle.q qVar) {
        this.q = fragment;
        this.X = qVar;
    }

    @Override // androidx.lifecycle.c
    public ax.H0.a E() {
        Application application;
        Context applicationContext = this.q.D2().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        ax.H0.d dVar = new ax.H0.d();
        if (application != null) {
            dVar.b(androidx.lifecycle.p.a.d, application);
        }
        dVar.b(androidx.lifecycle.m.a, this.q);
        dVar.b(androidx.lifecycle.m.b, this);
        if (this.q.w0() != null) {
            dVar.b(androidx.lifecycle.m.c, this.q.w0());
        }
        return dVar;
    }

    @Override // ax.F0.t
    public androidx.lifecycle.q J() {
        b();
        return this.X;
    }

    @Override // ax.p016b1.d
    public androidx.savedstate.a R() {
        b();
        return this.Z.b();
    }

    void a(androidx.lifecycle.d.a aVar) {
        this.Y.h(aVar);
    }

    void b() {
        if (this.Y == null) {
            this.Y = new androidx.lifecycle.g(this);
            ax.p016b1.c cVarA = ax.p016b1.c.a(this);
            this.Z = cVarA;
            cVarA.c();
        }
    }

    boolean c() {
        return this.Y != null;
    }

    void d(Bundle bundle) {
        this.Z.d(bundle);
    }

    void e(Bundle bundle) {
        this.Z.e(bundle);
    }

    @Override // ax.F0.g
    public androidx.lifecycle.d f() {
        b();
        return this.Y;
    }

    void g(androidx.lifecycle.d.b bVar) {
        this.Y.m(bVar);
    }
}
