package androidx.fragment.app;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
class x implements androidx.lifecycle.c, ax.p245p2.d, ax.G0.v {
    private final androidx.lifecycle.r X;
    private androidx.lifecycle.g Y = null;
    private ax.p245p2.c Z = null;
    private final Fragment q;

    x(Fragment fragment, androidx.lifecycle.r rVar) {
        this.q = fragment;
        this.X = rVar;
    }

    void a(androidx.lifecycle.d.a aVar) {
        this.Y.h(aVar);
    }

    void b() {
        if (this.Y == null) {
            this.Y = new androidx.lifecycle.g(this);
            ax.p245p2.c cVarA = ax.p245p2.c.a(this);
            this.Z = cVarA;
            cVarA.c();
        }
    }

    boolean c() {
        return this.Y != null;
    }

    void d(Bundle bundle) {
        this.Z.d(bundle);
    }

    void e(Bundle bundle) {
        this.Z.e(bundle);
    }

    void f(androidx.lifecycle.d.b bVar) {
        this.Y.m(bVar);
    }

    @Override // androidx.lifecycle.c
    public ax.I0.a getDefaultViewModelCreationExtras() {
        Application application;
        Context applicationContext = this.q.z2().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        ax.I0.d dVar = new ax.I0.d();
        if (application != null) {
            dVar.c(androidx.lifecycle.q.a.g, application);
        }
        dVar.c(androidx.lifecycle.m.a, this.q);
        dVar.c(androidx.lifecycle.m.b, this);
        if (this.q.s0() != null) {
            dVar.c(androidx.lifecycle.m.c, this.q.s0());
        }
        return dVar;
    }

    @Override // ax.G0.h
    public androidx.lifecycle.d getLifecycle() {
        b();
        return this.Y;
    }

    @Override // ax.p245p2.d
    public androidx.savedstate.a getSavedStateRegistry() {
        b();
        return this.Z.b();
    }

    @Override // ax.G0.v
    public androidx.lifecycle.r getViewModelStore() {
        b();
        return this.X;
    }
}
