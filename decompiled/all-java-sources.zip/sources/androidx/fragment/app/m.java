package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import ax.O.i;
import ax.O.t;
import ax.p015b0.InterfaceC5252x;
import j$.util.DesugarCollections;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {
    private static boolean S = false;
    private ax.p140k.c<Intent> D;
    private ax.p140k.c<ax.p140k.e> E;
    private ax.p140k.c<String[]> F;
    private boolean H;
    private boolean I;
    private boolean J;
    private boolean K;
    private boolean L;
    private ArrayList<C0563a> M;
    private ArrayList<Boolean> N;
    private ArrayList<Fragment> O;
    private p P;
    private ax.A0.c.C0050c Q;
    private boolean b;
    ArrayList<C0563a> d;
    private ArrayList<Fragment> e;
    private OnBackPressedDispatcher g;
    private ArrayList<l> m;
    private androidx.fragment.app.j<?> v;
    private ax.p351z0.e w;
    private Fragment x;
    Fragment y;
    private final ArrayList<InterfaceC0019m> a = new ArrayList<>();
    private final s c = new s();
    private final androidx.fragment.app.k f = new androidx.fragment.app.k(this);
    private final ax.p112i.n h = new b(false);
    private final AtomicInteger i = new AtomicInteger();
    private final Map<String, androidx.fragment.app.c> j = DesugarCollections.synchronizedMap(new HashMap());
    private final Map<String, Bundle> k = DesugarCollections.synchronizedMap(new HashMap());
    private final Map<String, Object> l = DesugarCollections.synchronizedMap(new HashMap());
    private final androidx.fragment.app.l n = new androidx.fragment.app.l(this);
    private final CopyOnWriteArrayList<ax.p351z0.k> o = new CopyOnWriteArrayList<>();
    private final ax.p001a0.a<Configuration> p = new ax.p001a0.a() { // from class: ax.z0.f
        @Override // ax.p001a0.a
        public final void a(Object obj) {
            this.a.Q0((Configuration) obj);
        }
    };
    private final ax.p001a0.a<Integer> q = new ax.p001a0.a() { // from class: ax.z0.g
        @Override // ax.p001a0.a
        public final void a(Object obj) {
            this.a.R0((Integer) obj);
        }
    };
    private final ax.p001a0.a<ax.O.i> r = new ax.p001a0.a() { // from class: ax.z0.h
        @Override // ax.p001a0.a
        public final void a(Object obj) {
            this.a.S0((i) obj);
        }
    };
    private final ax.p001a0.a<ax.O.t> s = new ax.p001a0.a() { // from class: ax.z0.i
        @Override // ax.p001a0.a
        public final void a(Object obj) {
            this.a.T0((t) obj);
        }
    };
    private final ax.p015b0.A t = new c();
    int u = -1;
    private androidx.fragment.app.i z = null;
    private androidx.fragment.app.i A = new d();
    private A B = null;
    private A C = new e();
    ArrayDeque<k> G = new ArrayDeque<>();
    private Runnable R = new f();

    class a implements ax.p140k.b<Map<String, Boolean>> {
        a() {
        }

        @Override // ax.p140k.b
        @SuppressLint({"SyntheticAccessor"})
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(Map<String, Boolean> map) {
            String[] strArr = (String[]) map.keySet().toArray(new String[0]);
            ArrayList arrayList = new ArrayList(map.values());
            int[] iArr = new int[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                iArr[i] = ((Boolean) arrayList.get(i)).booleanValue() ? 0 : -1;
            }
            k kVarPollFirst = m.this.G.pollFirst();
            if (kVarPollFirst == null) {
                Log.w("FragmentManager", "No permissions were requested for " + this);
                return;
            }
            String str = kVarPollFirst.q;
            int i2 = kVarPollFirst.X;
            Fragment fragmentI = m.this.c.i(str);
            if (fragmentI != null) {
                fragmentI.onRequestPermissionsResult(i2, strArr, iArr);
                return;
            }
            Log.w("FragmentManager", "Permission request result delivered for unknown Fragment " + str);
        }
    }

    class b extends ax.p112i.n {
        b(boolean z) {
            super(z);
        }

        @Override // ax.p112i.n
        public void d() {
            m.this.D0();
        }
    }

    class c implements ax.p015b0.A {
        c() {
        }

        @Override // ax.p015b0.A
        public boolean a(MenuItem menuItem) {
            return m.this.J(menuItem);
        }

        @Override // ax.p015b0.A
        public void b(Menu menu) {
            m.this.K(menu);
        }

        @Override // ax.p015b0.A
        public void c(Menu menu, MenuInflater menuInflater) {
            m.this.C(menu, menuInflater);
        }

        @Override // ax.p015b0.A
        public void d(Menu menu) {
            m.this.O(menu);
        }
    }

    class d extends androidx.fragment.app.i {
        d() {
        }

        @Override // androidx.fragment.app.i
        public Fragment a(ClassLoader classLoader, String str) {
            return m.this.u0().b(m.this.u0().g(), str, null);
        }
    }

    class e implements A {
        e() {
        }

        @Override // androidx.fragment.app.A
        public z a(ViewGroup viewGroup) {
            return new androidx.fragment.app.d(viewGroup);
        }
    }

    class f implements Runnable {
        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            m.this.a0(true);
        }
    }

    class g implements ax.p351z0.k {
        final /* synthetic */ Fragment q;

        g(Fragment fragment) {
            this.q = fragment;
        }

        @Override // ax.p351z0.k
        public void a(m mVar, Fragment fragment) {
            this.q.z1(fragment);
        }
    }

    class h implements ax.p140k.b<ax.p140k.a> {
        h() {
        }

        @Override // ax.p140k.b
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(ax.p140k.a aVar) {
            k kVarPollFirst = m.this.G.pollFirst();
            if (kVarPollFirst == null) {
                Log.w("FragmentManager", "No Activities were started for result for " + this);
                return;
            }
            String str = kVarPollFirst.q;
            int i = kVarPollFirst.X;
            Fragment fragmentI = m.this.c.i(str);
            if (fragmentI != null) {
                fragmentI.w1(i, aVar.b(), aVar.a());
                return;
            }
            Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str);
        }
    }

    class i implements ax.p140k.b<ax.p140k.a> {
        i() {
        }

        @Override // ax.p140k.b
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(ax.p140k.a aVar) {
            k kVarPollFirst = m.this.G.pollFirst();
            if (kVarPollFirst == null) {
                Log.w("FragmentManager", "No IntentSenders were started for " + this);
                return;
            }
            String str = kVarPollFirst.q;
            int i = kVarPollFirst.X;
            Fragment fragmentI = m.this.c.i(str);
            if (fragmentI != null) {
                fragmentI.w1(i, aVar.b(), aVar.a());
                return;
            }
            Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str);
        }
    }

    static class j extends ax.p154l.a<ax.p140k.e, ax.p140k.a> {
        j() {
        }

        @Override // ax.p154l.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public Intent a(Context context, ax.p140k.e eVar) {
            Bundle bundleExtra;
            Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
            Intent intentA = eVar.a();
            if (intentA != null && (bundleExtra = intentA.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                intentA.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                if (intentA.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                    eVar = new ax.k.e.a(eVar.d()).b(null).c(eVar.c(), eVar.b()).a();
                }
            }
            intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", eVar);
            if (m.H0(2)) {
                Log.v("FragmentManager", "CreateIntent created the following intent: " + intent);
            }
            return intent;
        }

        @Override // ax.p154l.a
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public ax.p140k.a c(int i, Intent intent) {
            return new ax.p140k.a(i, intent);
        }
    }

    public interface l {
        void a();
    }

    /* JADX INFO: renamed from: androidx.fragment.app.m$m, reason: collision with other inner class name */
    interface InterfaceC0019m {
        boolean a(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2);
    }

    private class n implements InterfaceC0019m {
        final String a;
        final int b;
        final int c;

        n(String str, int i, int i2) {
            this.a = str;
            this.b = i;
            this.c = i2;
        }

        @Override // androidx.fragment.app.m.InterfaceC0019m
        public boolean a(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = m.this.y;
            if (fragment == null || this.b >= 0 || this.a != null || !fragment.x0().b1()) {
                return m.this.e1(arrayList, arrayList2, this.a, this.b, this.c);
            }
            return false;
        }
    }

    static Fragment B0(View view) {
        Object tag = view.getTag(ax.p337y0.b.a);
        if (tag instanceof Fragment) {
            return (Fragment) tag;
        }
        return null;
    }

    public static boolean H0(int i2) {
        return S || Log.isLoggable("FragmentManager", i2);
    }

    private boolean I0(Fragment fragment) {
        return (fragment.H0 && fragment.I0) || fragment.y0.p();
    }

    private boolean J0() {
        Fragment fragment = this.x;
        if (fragment == null) {
            return true;
        }
        return fragment.l1() && this.x.N0().J0();
    }

    private void L(Fragment fragment) {
        if (fragment == null || !fragment.equals(f0(fragment.i0))) {
            return;
        }
        fragment.t2();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void Q0(Configuration configuration) {
        if (J0()) {
            z(configuration, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void R0(Integer num) {
        if (J0() && num.intValue() == 80) {
            F(false);
        }
    }

    private void S(int i2) {
        try {
            this.b = true;
            this.c.d(i2);
            W0(i2, false);
            Iterator<z> it = t().iterator();
            while (it.hasNext()) {
                it.next().j();
            }
            this.b = false;
            a0(true);
        } catch (Throwable th) {
            this.b = false;
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void S0(ax.O.i iVar) {
        if (J0()) {
            G(iVar.a(), false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void T0(ax.O.t tVar) {
        if (J0()) {
            N(tVar.a(), false);
        }
    }

    private void V() {
        if (this.L) {
            this.L = false;
            r1();
        }
    }

    private void X() {
        Iterator<z> it = t().iterator();
        while (it.hasNext()) {
            it.next().j();
        }
    }

    private void Z(boolean z) {
        if (this.b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.v == null) {
            if (!this.K) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.v.h().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z) {
            q();
        }
        if (this.M == null) {
            this.M = new ArrayList<>();
            this.N = new ArrayList<>();
        }
    }

    private static void c0(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        while (i2 < i3) {
            C0563a c0563a = arrayList.get(i2);
            if (arrayList2.get(i2).booleanValue()) {
                c0563a.w(-1);
                c0563a.B();
            } else {
                c0563a.w(1);
                c0563a.A();
            }
            i2++;
        }
    }

    private void d0(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        boolean z = arrayList.get(i2).r;
        ArrayList<Fragment> arrayList3 = this.O;
        if (arrayList3 == null) {
            this.O = new ArrayList<>();
        } else {
            arrayList3.clear();
        }
        this.O.addAll(this.c.o());
        Fragment fragmentY0 = y0();
        boolean z2 = false;
        for (int i4 = i2; i4 < i3; i4++) {
            C0563a c0563a = arrayList.get(i4);
            fragmentY0 = !arrayList2.get(i4).booleanValue() ? c0563a.C(this.O, fragmentY0) : c0563a.F(this.O, fragmentY0);
            z2 = z2 || c0563a.i;
        }
        this.O.clear();
        if (!z && this.u >= 1) {
            for (int i5 = i2; i5 < i3; i5++) {
                Iterator<t.a> it = arrayList.get(i5).c.iterator();
                while (it.hasNext()) {
                    Fragment fragment = it.next().b;
                    if (fragment != null && fragment.w0 != null) {
                        this.c.r(v(fragment));
                    }
                }
            }
        }
        c0(arrayList, arrayList2, i2, i3);
        boolean zBooleanValue = arrayList2.get(i3 - 1).booleanValue();
        for (int i6 = i2; i6 < i3; i6++) {
            C0563a c0563a2 = arrayList.get(i6);
            if (zBooleanValue) {
                for (int size = c0563a2.c.size() - 1; size >= 0; size--) {
                    Fragment fragment2 = c0563a2.c.get(size).b;
                    if (fragment2 != null) {
                        v(fragment2).m();
                    }
                }
            } else {
                Iterator<t.a> it2 = c0563a2.c.iterator();
                while (it2.hasNext()) {
                    Fragment fragment3 = it2.next().b;
                    if (fragment3 != null) {
                        v(fragment3).m();
                    }
                }
            }
        }
        W0(this.u, true);
        for (z zVar : u(arrayList, i2, i3)) {
            zVar.r(zBooleanValue);
            zVar.p();
            zVar.g();
        }
        while (i2 < i3) {
            C0563a c0563a3 = arrayList.get(i2);
            if (arrayList2.get(i2).booleanValue() && c0563a3.v >= 0) {
                c0563a3.v = -1;
            }
            c0563a3.E();
            i2++;
        }
        if (z2) {
            h1();
        }
    }

    private boolean d1(String str, int i2, int i3) {
        a0(false);
        Z(true);
        Fragment fragment = this.y;
        if (fragment != null && i2 < 0 && str == null && fragment.x0().b1()) {
            return true;
        }
        boolean zE1 = e1(this.M, this.N, str, i2, i3);
        if (zE1) {
            this.b = true;
            try {
                g1(this.M, this.N);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        V();
        this.c.b();
        return zE1;
    }

    private int g0(String str, int i2, boolean z) {
        ArrayList<C0563a> arrayList = this.d;
        if (arrayList == null || arrayList.isEmpty()) {
            return -1;
        }
        if (str == null && i2 < 0) {
            if (z) {
                return 0;
            }
            return this.d.size() - 1;
        }
        int size = this.d.size() - 1;
        while (size >= 0) {
            C0563a c0563a = this.d.get(size);
            if ((str != null && str.equals(c0563a.D())) || (i2 >= 0 && i2 == c0563a.v)) {
                break;
            }
            size--;
        }
        if (size < 0) {
            return size;
        }
        if (!z) {
            if (size == this.d.size() - 1) {
                return -1;
            }
            return size + 1;
        }
        while (size > 0) {
            C0563a c0563a2 = this.d.get(size - 1);
            if ((str == null || !str.equals(c0563a2.D())) && (i2 < 0 || i2 != c0563a2.v)) {
                return size;
            }
            size--;
        }
        return size;
    }

    private void g1(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!arrayList.get(i2).r) {
                if (i3 != i2) {
                    d0(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (arrayList2.get(i2).booleanValue()) {
                    while (i3 < size && arrayList2.get(i3).booleanValue() && !arrayList.get(i3).r) {
                        i3++;
                    }
                }
                d0(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            d0(arrayList, arrayList2, i3, size);
        }
    }

    private void h1() {
        if (this.m != null) {
            for (int i2 = 0; i2 < this.m.size(); i2++) {
                this.m.get(i2).a();
            }
        }
    }

    static int j1(int i2) {
        if (i2 == 4097) {
            return 8194;
        }
        if (i2 == 8194) {
            return 4097;
        }
        if (i2 == 8197) {
            return 4100;
        }
        if (i2 != 4099) {
            return i2 != 4100 ? 0 : 8197;
        }
        return 4099;
    }

    static m k0(View view) {
        androidx.fragment.app.f fVar;
        Fragment fragmentL0 = l0(view);
        if (fragmentL0 != null) {
            if (fragmentL0.l1()) {
                return fragmentL0.x0();
            }
            throw new IllegalStateException("The Fragment " + fragmentL0 + " that owns View " + view + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
        }
        Context context = view.getContext();
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                fVar = null;
                break;
            }
            if (context instanceof androidx.fragment.app.f) {
                fVar = (androidx.fragment.app.f) context;
                break;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        if (fVar != null) {
            return fVar.w();
        }
        throw new IllegalStateException("View " + view + " is not within a subclass of FragmentActivity.");
    }

    private static Fragment l0(View view) {
        while (view != null) {
            Fragment fragmentB0 = B0(view);
            if (fragmentB0 != null) {
                return fragmentB0;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        return null;
    }

    private void m0() {
        Iterator<z> it = t().iterator();
        while (it.hasNext()) {
            it.next().k();
        }
    }

    private boolean n0(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2) {
        synchronized (this.a) {
            if (this.a.isEmpty()) {
                return false;
            }
            try {
                int size = this.a.size();
                boolean zA = false;
                for (int i2 = 0; i2 < size; i2++) {
                    zA |= this.a.get(i2).a(arrayList, arrayList2);
                }
                this.a.clear();
                this.v.h().removeCallbacks(this.R);
                return zA;
            } catch (Throwable th) {
                this.a.clear();
                this.v.h().removeCallbacks(this.R);
                throw th;
            }
        }
    }

    private p p0(Fragment fragment) {
        return this.P.j(fragment);
    }

    private void p1(Fragment fragment) {
        ViewGroup viewGroupR0 = r0(fragment);
        if (viewGroupR0 == null || fragment.y0() + fragment.B0() + fragment.P0() + fragment.Q0() <= 0) {
            return;
        }
        int i2 = ax.p337y0.b.c;
        if (viewGroupR0.getTag(i2) == null) {
            viewGroupR0.setTag(i2, fragment);
        }
        ((Fragment) viewGroupR0.getTag(i2)).O2(fragment.O0());
    }

    private void q() {
        if (O0()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    private void r() {
        this.b = false;
        this.N.clear();
        this.M.clear();
    }

    private ViewGroup r0(Fragment fragment) {
        ViewGroup viewGroup = fragment.K0;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (fragment.B0 > 0 && this.w.d()) {
            View viewC = this.w.c(fragment.B0);
            if (viewC instanceof ViewGroup) {
                return (ViewGroup) viewC;
            }
        }
        return null;
    }

    private void r1() {
        Iterator<r> it = this.c.k().iterator();
        while (it.hasNext()) {
            Z0(it.next());
        }
    }

    private void s() {
        boolean zN;
        androidx.fragment.app.j<?> jVar = this.v;
        if (jVar instanceof ax.F0.t) {
            zN = this.c.p().n();
        } else {
            zN = jVar.g() instanceof Activity ? !((Activity) this.v.g()).isChangingConfigurations() : true;
        }
        if (zN) {
            Iterator<androidx.fragment.app.c> it = this.j.values().iterator();
            while (it.hasNext()) {
                Iterator<String> it2 = it.next().q.iterator();
                while (it2.hasNext()) {
                    this.c.p().g(it2.next());
                }
            }
        }
    }

    private void s1(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new y("FragmentManager"));
        androidx.fragment.app.j<?> jVar = this.v;
        if (jVar != null) {
            try {
                jVar.i("  ", null, printWriter, new String[0]);
                throw runtimeException;
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
                throw runtimeException;
            }
        }
        try {
            W("  ", null, printWriter, new String[0]);
            throw runtimeException;
        } catch (Exception e3) {
            Log.e("FragmentManager", "Failed dumping state", e3);
            throw runtimeException;
        }
    }

    private Set<z> t() {
        HashSet hashSet = new HashSet();
        Iterator<r> it = this.c.k().iterator();
        while (it.hasNext()) {
            ViewGroup viewGroup = it.next().k().K0;
            if (viewGroup != null) {
                hashSet.add(z.o(viewGroup, z0()));
            }
        }
        return hashSet;
    }

    private void t1() {
        synchronized (this.a) {
            try {
                if (this.a.isEmpty()) {
                    this.h.j(o0() > 0 && M0(this.x));
                } else {
                    this.h.j(true);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private Set<z> u(ArrayList<C0563a> arrayList, int i2, int i3) {
        ViewGroup viewGroup;
        HashSet hashSet = new HashSet();
        while (i2 < i3) {
            Iterator<t.a> it = arrayList.get(i2).c.iterator();
            while (it.hasNext()) {
                Fragment fragment = it.next().b;
                if (fragment != null && (viewGroup = fragment.K0) != null) {
                    hashSet.add(z.n(viewGroup, this));
                }
            }
            i2++;
        }
        return hashSet;
    }

    boolean A(MenuItem menuItem) {
        if (this.u < 1) {
            return false;
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null && fragment.e2(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public ax.A0.c.C0050c A0() {
        return this.Q;
    }

    void B() {
        this.I = false;
        this.J = false;
        this.P.p(false);
        S(1);
    }

    boolean C(Menu menu, MenuInflater menuInflater) {
        if (this.u < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z = false;
        for (Fragment fragment : this.c.o()) {
            if (fragment != null && L0(fragment) && fragment.g2(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(fragment);
                z = true;
            }
        }
        if (this.e != null) {
            for (int i2 = 0; i2 < this.e.size(); i2++) {
                Fragment fragment2 = this.e.get(i2);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    fragment2.H1();
                }
            }
        }
        this.e = arrayList;
        return z;
    }

    androidx.lifecycle.q C0(Fragment fragment) {
        return this.P.m(fragment);
    }

    void D() {
        this.K = true;
        a0(true);
        X();
        s();
        S(-1);
        Object obj = this.v;
        if (obj instanceof ax.P.f) {
            ((ax.P.f) obj).X(this.q);
        }
        Object obj2 = this.v;
        if (obj2 instanceof ax.P.e) {
            ((ax.P.e) obj2).l(this.p);
        }
        Object obj3 = this.v;
        if (obj3 instanceof ax.O.q) {
            ((ax.O.q) obj3).K(this.r);
        }
        Object obj4 = this.v;
        if (obj4 instanceof ax.O.r) {
            ((ax.O.r) obj4).B(this.s);
        }
        Object obj5 = this.v;
        if ((obj5 instanceof InterfaceC5252x) && this.x == null) {
            ((InterfaceC5252x) obj5).j(this.t);
        }
        this.v = null;
        this.w = null;
        this.x = null;
        if (this.g != null) {
            this.h.h();
            this.g = null;
        }
        ax.p140k.c<Intent> cVar = this.D;
        if (cVar != null) {
            cVar.c();
            this.E.c();
            this.F.c();
        }
    }

    void D0() {
        a0(true);
        if (this.h.g()) {
            b1();
        } else {
            this.g.k();
        }
    }

    void E() {
        S(1);
    }

    void E0(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (fragment.D0) {
            return;
        }
        fragment.D0 = true;
        fragment.R0 = true ^ fragment.R0;
        p1(fragment);
    }

    void F(boolean z) {
        if (z && (this.v instanceof ax.P.f)) {
            s1(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments."));
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.m2();
                if (z) {
                    fragment.y0.F(true);
                }
            }
        }
    }

    void F0(Fragment fragment) {
        if (fragment.o0 && I0(fragment)) {
            this.H = true;
        }
    }

    void G(boolean z, boolean z2) {
        if (z2 && (this.v instanceof ax.O.q)) {
            s1(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments."));
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.n2(z);
                if (z2) {
                    fragment.y0.G(z, true);
                }
            }
        }
    }

    public boolean G0() {
        return this.K;
    }

    void H(Fragment fragment) {
        Iterator<ax.p351z0.k> it = this.o.iterator();
        while (it.hasNext()) {
            it.next().a(this, fragment);
        }
    }

    void I() {
        for (Fragment fragment : this.c.l()) {
            if (fragment != null) {
                fragment.L1(fragment.n1());
                fragment.y0.I();
            }
        }
    }

    boolean J(MenuItem menuItem) {
        if (this.u < 1) {
            return false;
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null && fragment.o2(menuItem)) {
                return true;
            }
        }
        return false;
    }

    void K(Menu menu) {
        if (this.u < 1) {
            return;
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.p2(menu);
            }
        }
    }

    boolean K0(Fragment fragment) {
        if (fragment == null) {
            return false;
        }
        return fragment.n1();
    }

    boolean L0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        return fragment.p1();
    }

    void M() {
        S(5);
    }

    boolean M0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        m mVar = fragment.w0;
        return fragment.equals(mVar.y0()) && M0(mVar.x);
    }

    void N(boolean z, boolean z2) {
        if (z2 && (this.v instanceof ax.O.r)) {
            s1(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments."));
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.r2(z);
                if (z2) {
                    fragment.y0.N(z, true);
                }
            }
        }
    }

    boolean N0(int i2) {
        return this.u >= i2;
    }

    boolean O(Menu menu) {
        boolean z = false;
        if (this.u < 1) {
            return false;
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null && L0(fragment) && fragment.s2(menu)) {
                z = true;
            }
        }
        return z;
    }

    public boolean O0() {
        return this.I || this.J;
    }

    void P() {
        t1();
        L(this.y);
    }

    void Q() {
        this.I = false;
        this.J = false;
        this.P.p(false);
        S(7);
    }

    void R() {
        this.I = false;
        this.J = false;
        this.P.p(false);
        S(5);
    }

    void T() {
        this.J = true;
        this.P.p(true);
        S(4);
    }

    void U() {
        S(2);
    }

    void U0(Fragment fragment, String[] strArr, int i2) {
        if (this.F == null) {
            this.v.n(fragment, strArr, i2);
            return;
        }
        this.G.addLast(new k(fragment.i0, i2));
        this.F.a(strArr);
    }

    void V0(Fragment fragment, @SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (this.D == null) {
            this.v.p(fragment, intent, i2, bundle);
            return;
        }
        this.G.addLast(new k(fragment.i0, i2));
        if (intent != null && bundle != null) {
            intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
        }
        this.D.a(intent);
    }

    public void W(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String str2 = str + "    ";
        this.c.e(str, fileDescriptor, printWriter, strArr);
        ArrayList<Fragment> arrayList = this.e;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i2 = 0; i2 < size2; i2++) {
                Fragment fragment = this.e.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment.toString());
            }
        }
        ArrayList<C0563a> arrayList2 = this.d;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i3 = 0; i3 < size; i3++) {
                C0563a c0563a = this.d.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(c0563a.toString());
                c0563a.y(str2, printWriter);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.i.get());
        synchronized (this.a) {
            try {
                int size3 = this.a.size();
                if (size3 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i4 = 0; i4 < size3; i4++) {
                        InterfaceC0019m interfaceC0019m = this.a.get(i4);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i4);
                        printWriter.print(": ");
                        printWriter.println(interfaceC0019m);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.v);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.w);
        if (this.x != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.x);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.u);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.I);
        printWriter.print(" mStopped=");
        printWriter.print(this.J);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.K);
        if (this.H) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.H);
        }
    }

    void W0(int i2, boolean z) {
        androidx.fragment.app.j<?> jVar;
        if (this.v == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z || i2 != this.u) {
            this.u = i2;
            this.c.t();
            r1();
            if (this.H && (jVar = this.v) != null && this.u == 7) {
                jVar.t();
                this.H = false;
            }
        }
    }

    void X0() {
        if (this.v == null) {
            return;
        }
        this.I = false;
        this.J = false;
        this.P.p(false);
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.u1();
            }
        }
    }

    void Y(InterfaceC0019m interfaceC0019m, boolean z) {
        if (!z) {
            if (this.v == null) {
                if (!this.K) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            q();
        }
        synchronized (this.a) {
            try {
                if (this.v == null) {
                    if (!z) {
                        throw new IllegalStateException("Activity has been destroyed");
                    }
                } else {
                    this.a.add(interfaceC0019m);
                    l1();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    void Y0(FragmentContainerView fragmentContainerView) {
        View view;
        for (r rVar : this.c.k()) {
            Fragment fragmentK = rVar.k();
            if (fragmentK.B0 == fragmentContainerView.getId() && (view = fragmentK.L0) != null && view.getParent() == null) {
                fragmentK.K0 = fragmentContainerView;
                rVar.b();
            }
        }
    }

    void Z0(r rVar) {
        Fragment fragmentK = rVar.k();
        if (fragmentK.M0) {
            if (this.b) {
                this.L = true;
            } else {
                fragmentK.M0 = false;
                rVar.m();
            }
        }
    }

    boolean a0(boolean z) {
        Z(z);
        boolean z2 = false;
        while (n0(this.M, this.N)) {
            z2 = true;
            this.b = true;
            try {
                g1(this.M, this.N);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        V();
        this.c.b();
        return z2;
    }

    void a1(int i2, int i3, boolean z) {
        if (i2 >= 0) {
            Y(new n(null, i2, i3), z);
            return;
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    void b0(InterfaceC0019m interfaceC0019m, boolean z) {
        if (z && (this.v == null || this.K)) {
            return;
        }
        Z(z);
        if (interfaceC0019m.a(this.M, this.N)) {
            this.b = true;
            try {
                g1(this.M, this.N);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        V();
        this.c.b();
    }

    public boolean b1() {
        return d1(null, -1, 0);
    }

    public boolean c1(int i2, int i3) {
        if (i2 >= 0) {
            return d1(null, i2, i3);
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    public boolean e0() {
        boolean zA0 = a0(true);
        m0();
        return zA0;
    }

    boolean e1(ArrayList<C0563a> arrayList, ArrayList<Boolean> arrayList2, String str, int i2, int i3) {
        int iG0 = g0(str, i2, (i3 & 1) != 0);
        if (iG0 < 0) {
            return false;
        }
        for (int size = this.d.size() - 1; size >= iG0; size--) {
            arrayList.add(this.d.remove(size));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    Fragment f0(String str) {
        return this.c.f(str);
    }

    void f1(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.v0);
        }
        boolean z = !fragment.o1();
        if (!fragment.E0 || z) {
            this.c.u(fragment);
            if (I0(fragment)) {
                this.H = true;
            }
            fragment.p0 = true;
            p1(fragment);
        }
    }

    public Fragment h0(int i2) {
        return this.c.g(i2);
    }

    void i(C0563a c0563a) {
        if (this.d == null) {
            this.d = new ArrayList<>();
        }
        this.d.add(c0563a);
    }

    public Fragment i0(String str) {
        return this.c.h(str);
    }

    void i1(Parcelable parcelable) {
        r rVar;
        Bundle bundle;
        Bundle bundle2;
        if (parcelable == null) {
            return;
        }
        Bundle bundle3 = (Bundle) parcelable;
        for (String str : bundle3.keySet()) {
            if (str.startsWith("result_") && (bundle2 = bundle3.getBundle(str)) != null) {
                bundle2.setClassLoader(this.v.g().getClassLoader());
                this.k.put(str.substring(7), bundle2);
            }
        }
        ArrayList<q> arrayList = new ArrayList<>();
        for (String str2 : bundle3.keySet()) {
            if (str2.startsWith("fragment_") && (bundle = bundle3.getBundle(str2)) != null) {
                bundle.setClassLoader(this.v.g().getClassLoader());
                arrayList.add((q) bundle.getParcelable("state"));
            }
        }
        this.c.x(arrayList);
        o oVar = (o) bundle3.getParcelable("state");
        if (oVar == null) {
            return;
        }
        this.c.v();
        Iterator<String> it = oVar.q.iterator();
        while (it.hasNext()) {
            q qVarB = this.c.B(it.next(), null);
            if (qVarB != null) {
                Fragment fragmentI = this.P.i(qVarB.X);
                if (fragmentI != null) {
                    if (H0(2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + fragmentI);
                    }
                    rVar = new r(this.n, this.c, fragmentI, qVarB);
                } else {
                    rVar = new r(this.n, this.c, this.v.g().getClassLoader(), s0(), qVarB);
                }
                Fragment fragmentK = rVar.k();
                fragmentK.w0 = this;
                if (H0(2)) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + fragmentK.i0 + "): " + fragmentK);
                }
                rVar.o(this.v.g().getClassLoader());
                this.c.r(rVar);
                rVar.t(this.u);
            }
        }
        for (Fragment fragment : this.P.l()) {
            if (!this.c.c(fragment.i0)) {
                if (H0(2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + oVar.q);
                }
                this.P.o(fragment);
                fragment.w0 = this;
                r rVar2 = new r(this.n, this.c, fragment);
                rVar2.t(1);
                rVar2.m();
                fragment.p0 = true;
                rVar2.m();
            }
        }
        this.c.w(oVar.X);
        if (oVar.Y != null) {
            this.d = new ArrayList<>(oVar.Y.length);
            int i2 = 0;
            while (true) {
                C0564b[] c0564bArr = oVar.Y;
                if (i2 >= c0564bArr.length) {
                    break;
                }
                C0563a c0563aB = c0564bArr[i2].b(this);
                if (H0(2)) {
                    Log.v("FragmentManager", "restoreAllState: back stack #" + i2 + " (index " + c0563aB.v + "): " + c0563aB);
                    PrintWriter printWriter = new PrintWriter(new y("FragmentManager"));
                    c0563aB.z("  ", printWriter, false);
                    printWriter.close();
                }
                this.d.add(c0563aB);
                i2++;
            }
        } else {
            this.d = null;
        }
        this.i.set(oVar.Z);
        String str3 = oVar.h0;
        if (str3 != null) {
            Fragment fragmentF0 = f0(str3);
            this.y = fragmentF0;
            L(fragmentF0);
        }
        ArrayList<String> arrayList2 = oVar.i0;
        if (arrayList2 != null) {
            for (int i3 = 0; i3 < arrayList2.size(); i3++) {
                this.j.put(arrayList2.get(i3), oVar.j0.get(i3));
            }
        }
        this.G = new ArrayDeque<>(oVar.k0);
    }

    r j(Fragment fragment) {
        String str = fragment.U0;
        if (str != null) {
            ax.A0.c.f(fragment, str);
        }
        if (H0(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        r rVarV = v(fragment);
        fragment.w0 = this;
        this.c.r(rVarV);
        if (!fragment.E0) {
            this.c.a(fragment);
            fragment.p0 = false;
            if (fragment.L0 == null) {
                fragment.R0 = false;
            }
            if (I0(fragment)) {
                this.H = true;
            }
        }
        return rVarV;
    }

    Fragment j0(String str) {
        return this.c.i(str);
    }

    public void k(ax.p351z0.k kVar) {
        this.o.add(kVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX INFO: renamed from: k1, reason: merged with bridge method [inline-methods] */
    public Bundle P0() {
        C0564b[] c0564bArr;
        int size;
        Bundle bundle = new Bundle();
        m0();
        X();
        a0(true);
        this.I = true;
        this.P.p(true);
        ArrayList<String> arrayListY = this.c.y();
        ArrayList<q> arrayListM = this.c.m();
        if (!arrayListM.isEmpty()) {
            ArrayList<String> arrayListZ = this.c.z();
            ArrayList<C0563a> arrayList = this.d;
            if (arrayList == null || (size = arrayList.size()) <= 0) {
                c0564bArr = null;
            } else {
                c0564bArr = new C0564b[size];
                for (int i2 = 0; i2 < size; i2++) {
                    c0564bArr[i2] = new C0564b(this.d.get(i2));
                    if (H0(2)) {
                        Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.d.get(i2));
                    }
                }
            }
            o oVar = new o();
            oVar.q = arrayListY;
            oVar.X = arrayListZ;
            oVar.Y = c0564bArr;
            oVar.Z = this.i.get();
            Fragment fragment = this.y;
            if (fragment != null) {
                oVar.h0 = fragment.i0;
            }
            oVar.i0.addAll(this.j.keySet());
            oVar.j0.addAll(this.j.values());
            oVar.k0 = new ArrayList<>(this.G);
            bundle.putParcelable("state", oVar);
            for (String str : this.k.keySet()) {
                bundle.putBundle("result_" + str, this.k.get(str));
            }
            for (q qVar : arrayListM) {
                Bundle bundle2 = new Bundle();
                bundle2.putParcelable("state", qVar);
                bundle.putBundle("fragment_" + qVar.X, bundle2);
            }
        } else if (H0(2)) {
            Log.v("FragmentManager", "saveAllState: no fragments!");
        }
        return bundle;
    }

    int l() {
        return this.i.getAndIncrement();
    }

    void l1() {
        synchronized (this.a) {
            try {
                if (this.a.size() == 1) {
                    this.v.h().removeCallbacks(this.R);
                    this.v.h().post(this.R);
                    t1();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @SuppressLint({"SyntheticAccessor"})
    void m(androidx.fragment.app.j<?> jVar, ax.p351z0.e eVar, Fragment fragment) {
        String str;
        ax.F0.g gVar;
        if (this.v != null) {
            throw new IllegalStateException("Already attached");
        }
        this.v = jVar;
        this.w = eVar;
        this.x = fragment;
        if (fragment != null) {
            k(new g(fragment));
        } else if (jVar instanceof ax.p351z0.k) {
            k((ax.p351z0.k) jVar);
        }
        if (this.x != null) {
            t1();
        }
        if (jVar instanceof ax.p112i.p) {
            ax.p112i.p pVar = (ax.p112i.p) jVar;
            OnBackPressedDispatcher onBackPressedDispatcherQ = pVar.q();
            this.g = onBackPressedDispatcherQ;
            if (fragment != null) {
                gVar = pVar;
                gVar = fragment;
            }
            gVar = pVar;
            onBackPressedDispatcherQ.h(gVar, this.h);
        }
        if (fragment != null) {
            this.P = fragment.w0.p0(fragment);
        } else if (jVar instanceof ax.F0.t) {
            this.P = p.k(((ax.F0.t) jVar).J());
        } else {
            this.P = new p(false);
        }
        this.P.p(O0());
        this.c.A(this.P);
        Object obj = this.v;
        if ((obj instanceof ax.p016b1.d) && fragment == null) {
            androidx.savedstate.a aVarR = ((ax.p016b1.d) obj).R();
            aVarR.h("android:support:fragments", new androidx.savedstate.a.c() { // from class: ax.z0.j
                @Override // androidx.savedstate.a.c
                public final Bundle a() {
                    return this.a.P0();
                }
            });
            Bundle bundleB = aVarR.b("android:support:fragments");
            if (bundleB != null) {
                i1(bundleB);
            }
        }
        Object obj2 = this.v;
        if (obj2 instanceof ax.p140k.d) {
            ActivityResultRegistry activityResultRegistryR = ((ax.p140k.d) obj2).r();
            if (fragment != null) {
                str = fragment.i0 + ":";
            } else {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String str2 = "FragmentManager:" + str;
            this.D = activityResultRegistryR.j(str2 + "StartActivityForResult", new ax.p154l.c(), new h());
            this.E = activityResultRegistryR.j(str2 + "StartIntentSenderForResult", new j(), new i());
            this.F = activityResultRegistryR.j(str2 + "RequestPermissions", new ax.p154l.b(), new a());
        }
        Object obj3 = this.v;
        if (obj3 instanceof ax.P.e) {
            ((ax.P.e) obj3).Q(this.p);
        }
        Object obj4 = this.v;
        if (obj4 instanceof ax.P.f) {
            ((ax.P.f) obj4).W(this.q);
        }
        Object obj5 = this.v;
        if (obj5 instanceof ax.O.q) {
            ((ax.O.q) obj5).N(this.r);
        }
        Object obj6 = this.v;
        if (obj6 instanceof ax.O.r) {
            ((ax.O.r) obj6).L(this.s);
        }
        Object obj7 = this.v;
        if ((obj7 instanceof InterfaceC5252x) && fragment == null) {
            ((InterfaceC5252x) obj7).s(this.t);
        }
    }

    void m1(Fragment fragment, boolean z) {
        ViewGroup viewGroupR0 = r0(fragment);
        if (viewGroupR0 == null || !(viewGroupR0 instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) viewGroupR0).setDrawDisappearingViewsLast(!z);
    }

    void n(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.E0) {
            fragment.E0 = false;
            if (fragment.o0) {
                return;
            }
            this.c.a(fragment);
            if (H0(2)) {
                Log.v("FragmentManager", "add from attach: " + fragment);
            }
            if (I0(fragment)) {
                this.H = true;
            }
        }
    }

    void n1(Fragment fragment, androidx.lifecycle.d.b bVar) {
        if (fragment.equals(f0(fragment.i0)) && (fragment.x0 == null || fragment.w0 == this)) {
            fragment.V0 = bVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public t o() {
        return new C0563a(this);
    }

    public int o0() {
        ArrayList<C0563a> arrayList = this.d;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    void o1(Fragment fragment) {
        if (fragment == null || (fragment.equals(f0(fragment.i0)) && (fragment.x0 == null || fragment.w0 == this))) {
            Fragment fragment2 = this.y;
            this.y = fragment;
            L(fragment2);
            L(this.y);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    boolean p() {
        boolean zI0 = false;
        for (Fragment fragment : this.c.l()) {
            if (fragment != null) {
                zI0 = I0(fragment);
            }
            if (zI0) {
                return true;
            }
        }
        return false;
    }

    ax.p351z0.e q0() {
        return this.w;
    }

    void q1(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.D0) {
            fragment.D0 = false;
            fragment.R0 = !fragment.R0;
        }
    }

    public androidx.fragment.app.i s0() {
        androidx.fragment.app.i iVar = this.z;
        if (iVar != null) {
            return iVar;
        }
        Fragment fragment = this.x;
        return fragment != null ? fragment.w0.s0() : this.A;
    }

    public List<Fragment> t0() {
        return this.c.o();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.x;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.x)));
            sb.append("}");
        } else {
            androidx.fragment.app.j<?> jVar = this.v;
            if (jVar != null) {
                sb.append(jVar.getClass().getSimpleName());
                sb.append("{");
                sb.append(Integer.toHexString(System.identityHashCode(this.v)));
                sb.append("}");
            } else {
                sb.append("null");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    public androidx.fragment.app.j<?> u0() {
        return this.v;
    }

    r v(Fragment fragment) {
        r rVarN = this.c.n(fragment.i0);
        if (rVarN != null) {
            return rVarN;
        }
        r rVar = new r(this.n, this.c, fragment);
        rVar.o(this.v.g().getClassLoader());
        rVar.t(this.u);
        return rVar;
    }

    LayoutInflater.Factory2 v0() {
        return this.f;
    }

    void w(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (fragment.E0) {
            return;
        }
        fragment.E0 = true;
        if (fragment.o0) {
            if (H0(2)) {
                Log.v("FragmentManager", "remove from detach: " + fragment);
            }
            this.c.u(fragment);
            if (I0(fragment)) {
                this.H = true;
            }
            p1(fragment);
        }
    }

    androidx.fragment.app.l w0() {
        return this.n;
    }

    void x() {
        this.I = false;
        this.J = false;
        this.P.p(false);
        S(4);
    }

    Fragment x0() {
        return this.x;
    }

    void y() {
        this.I = false;
        this.J = false;
        this.P.p(false);
        S(0);
    }

    public Fragment y0() {
        return this.y;
    }

    void z(Configuration configuration, boolean z) {
        if (z && (this.v instanceof ax.P.e)) {
            s1(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments."));
        }
        for (Fragment fragment : this.c.o()) {
            if (fragment != null) {
                fragment.d2(configuration);
                if (z) {
                    fragment.y0.z(configuration, true);
                }
            }
        }
    }

    A z0() {
        A a2 = this.B;
        if (a2 != null) {
            return a2;
        }
        Fragment fragment = this.x;
        return fragment != null ? fragment.w0.z0() : this.C;
    }

    @SuppressLint({"BanParcelableUsage"})
    static class k implements Parcelable {
        public static final Parcelable.Creator<k> CREATOR = new a();
        int X;
        String q;

        class a implements Parcelable.Creator<k> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public k createFromParcel(Parcel parcel) {
                return new k(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public k[] newArray(int i) {
                return new k[i];
            }
        }

        k(String str, int i) {
            this.q = str;
            this.X = i;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.q);
            parcel.writeInt(this.X);
        }

        k(Parcel parcel) {
            this.q = parcel.readString();
            this.X = parcel.readInt();
        }
    }
}
