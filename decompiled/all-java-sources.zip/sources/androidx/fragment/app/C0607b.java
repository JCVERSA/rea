package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.fragment.app.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class C0607b implements Parcelable {
    public static final Parcelable.Creator<C0607b> CREATOR = new a();
    final ArrayList<String> X;
    final int[] Y;
    final int[] Z;
    final int k0;
    final String l0;
    final int m0;
    final int n0;
    final CharSequence o0;
    final int p0;
    final int[] q;
    final CharSequence q0;
    final ArrayList<String> r0;
    final ArrayList<String> s0;
    final boolean t0;

    /* JADX INFO: renamed from: androidx.fragment.app.b$a */
    class a implements Parcelable.Creator<C0607b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public C0607b createFromParcel(Parcel parcel) {
            return new C0607b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public C0607b[] newArray(int i) {
            return new C0607b[i];
        }
    }

    C0607b(Parcel parcel) {
        this.q = parcel.createIntArray();
        this.X = parcel.createStringArrayList();
        this.Y = parcel.createIntArray();
        this.Z = parcel.createIntArray();
        this.k0 = parcel.readInt();
        this.l0 = parcel.readString();
        this.m0 = parcel.readInt();
        this.n0 = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.o0 = (CharSequence) creator.createFromParcel(parcel);
        this.p0 = parcel.readInt();
        this.q0 = (CharSequence) creator.createFromParcel(parcel);
        this.r0 = parcel.createStringArrayList();
        this.s0 = parcel.createStringArrayList();
        this.t0 = parcel.readInt() != 0;
    }

    C0607b(C0606a c0606a) {
        int size = c0606a.c.size();
        this.q = new int[size * 6];
        if (!c0606a.i) {
            throw new IllegalStateException("Not on back stack");
        }
        this.X = new ArrayList<>(size);
        this.Y = new int[size];
        this.Z = new int[size];
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            t.a aVar = c0606a.c.get(i2);
            int i3 = i + 1;
            this.q[i] = aVar.a;
            ArrayList<String> arrayList = this.X;
            Fragment fragment = aVar.b;
            arrayList.add(fragment != null ? fragment.l0 : null);
            int[] iArr = this.q;
            iArr[i3] = aVar.c ? 1 : 0;
            iArr[i + 2] = aVar.d;
            iArr[i + 3] = aVar.e;
            int i4 = i + 5;
            iArr[i + 4] = aVar.f;
            i += 6;
            iArr[i4] = aVar.g;
            this.Y[i2] = aVar.h.ordinal();
            this.Z[i2] = aVar.i.ordinal();
        }
        this.k0 = c0606a.h;
        this.l0 = c0606a.k;
        this.m0 = c0606a.v;
        this.n0 = c0606a.l;
        this.o0 = c0606a.m;
        this.p0 = c0606a.n;
        this.q0 = c0606a.o;
        this.r0 = c0606a.p;
        this.s0 = c0606a.q;
        this.t0 = c0606a.r;
    }

    private void a(C0606a c0606a) {
        int i = 0;
        int i2 = 0;
        while (true) {
            boolean z = true;
            if (i >= this.q.length) {
                c0606a.h = this.k0;
                c0606a.k = this.l0;
                c0606a.i = true;
                c0606a.l = this.n0;
                c0606a.m = this.o0;
                c0606a.n = this.p0;
                c0606a.o = this.q0;
                c0606a.p = this.r0;
                c0606a.q = this.s0;
                c0606a.r = this.t0;
                return;
            }
            t.a aVar = new t.a();
            int i3 = i + 1;
            aVar.a = this.q[i];
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Instantiate " + c0606a + " op #" + i2 + " base fragment #" + this.q[i3]);
            }
            aVar.h = androidx.lifecycle.d.b.values()[this.Y[i2]];
            aVar.i = androidx.lifecycle.d.b.values()[this.Z[i2]];
            int[] iArr = this.q;
            int i4 = i + 2;
            if (iArr[i3] == 0) {
                z = false;
            }
            aVar.c = z;
            int i5 = iArr[i4];
            aVar.d = i5;
            int i6 = iArr[i + 3];
            aVar.e = i6;
            int i7 = i + 5;
            int i8 = iArr[i + 4];
            aVar.f = i8;
            i += 6;
            int i9 = iArr[i7];
            aVar.g = i9;
            c0606a.d = i5;
            c0606a.e = i6;
            c0606a.f = i8;
            c0606a.g = i9;
            c0606a.f(aVar);
            i2++;
        }
    }

    public C0606a b(FragmentManager fragmentManager) {
        C0606a c0606a = new C0606a(fragmentManager);
        a(c0606a);
        c0606a.v = this.m0;
        for (int i = 0; i < this.X.size(); i++) {
            String str = this.X.get(i);
            if (str != null) {
                c0606a.c.get(i).b = fragmentManager.h0(str);
            }
        }
        c0606a.w(1);
        return c0606a;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.q);
        parcel.writeStringList(this.X);
        parcel.writeIntArray(this.Y);
        parcel.writeIntArray(this.Z);
        parcel.writeInt(this.k0);
        parcel.writeString(this.l0);
        parcel.writeInt(this.m0);
        parcel.writeInt(this.n0);
        TextUtils.writeToParcel(this.o0, parcel, 0);
        parcel.writeInt(this.p0);
        TextUtils.writeToParcel(this.q0, parcel, 0);
        parcel.writeStringList(this.r0);
        parcel.writeStringList(this.s0);
        parcel.writeInt(this.t0 ? 1 : 0);
    }
}
