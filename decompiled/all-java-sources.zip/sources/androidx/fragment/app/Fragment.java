package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.LiveData;
import ax.p035c0.C1873v;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, ax.G0.h, ax.G0.v, androidx.lifecycle.c, ax.p245p2.d {
    static final Object i1 = new Object();
    j<?> A0;
    Fragment C0;
    int D0;
    int E0;
    String F0;
    boolean G0;
    boolean H0;
    boolean I0;
    boolean J0;
    boolean K0;
    private boolean M0;
    ViewGroup N0;
    View O0;
    boolean P0;
    f R0;
    Handler S0;
    boolean U0;
    LayoutInflater V0;
    boolean W0;
    Bundle X;
    public String X0;
    SparseArray<Parcelable> Y;
    Bundle Z;
    androidx.lifecycle.g Z0;
    x a1;
    androidx.lifecycle.q.b c1;
    ax.p245p2.c d1;
    private int e1;
    Boolean k0;
    Bundle m0;
    Fragment n0;
    int p0;
    boolean r0;
    boolean s0;
    boolean t0;
    boolean u0;
    boolean v0;
    boolean w0;
    boolean x0;
    int y0;
    FragmentManager z0;
    int q = -1;
    String l0 = UUID.randomUUID().toString();
    String o0 = null;
    private Boolean q0 = null;
    FragmentManager B0 = new m();
    boolean L0 = true;
    boolean Q0 = true;
    Runnable T0 = new a();
    androidx.lifecycle.d.b Y0 = androidx.lifecycle.d.b.RESUMED;
    ax.G0.l<ax.G0.h> b1 = new ax.G0.l<>();
    private final AtomicInteger f1 = new AtomicInteger();
    private final ArrayList<i> g1 = new ArrayList<>();
    private final i h1 = new b();

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.T2();
        }
    }

    class b extends i {
        b() {
            super(null);
        }

        @Override // androidx.fragment.app.Fragment.i
        void a() {
            Fragment.this.d1.c();
            androidx.lifecycle.m.c(Fragment.this);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.j0(false);
        }
    }

    class d implements Runnable {
        final /* synthetic */ z q;

        d(z zVar) {
            this.q = zVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.g();
        }
    }

    class e extends ax.A0.e {
        e() {
        }

        @Override // ax.A0.e
        public View c(int i) {
            View view = Fragment.this.O0;
            if (view != null) {
                return view.findViewById(i);
            }
            throw new IllegalStateException("Fragment " + Fragment.this + " does not have a view");
        }

        @Override // ax.A0.e
        public boolean d() {
            return Fragment.this.O0 != null;
        }
    }

    static class f {
        View a;
        boolean b;
        int c;
        int d;
        int e;
        int f;
        int g;
        ArrayList<String> h;
        ArrayList<String> i;
        Object j = null;
        Object k;
        Object l;
        Object m;
        Object n;
        Object o;
        Boolean p;
        Boolean q;
        float r;
        View s;
        boolean t;

        f() {
            Object obj = Fragment.i1;
            this.k = obj;
            this.l = null;
            this.m = obj;
            this.n = null;
            this.o = obj;
            this.r = 1.0f;
            this.s = null;
        }
    }

    static class g {
        static void a(View view) {
            view.cancelPendingInputEvents();
        }
    }

    public static class h extends RuntimeException {
        public h(String str, Exception exc) {
            super(str, exc);
        }
    }

    private static abstract class i {
        private i() {
        }

        /* synthetic */ i(a aVar) {
            this();
        }

        abstract void a();
    }

    public Fragment() {
        d1();
    }

    private void C2() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this);
        }
        if (this.O0 != null) {
            D2(this.X);
        }
        this.X = null;
    }

    private int G0() {
        androidx.lifecycle.d.b bVar = this.Y0;
        return (bVar == androidx.lifecycle.d.b.INITIALIZED || this.C0 == null) ? bVar.ordinal() : Math.min(bVar.ordinal(), this.C0.G0());
    }

    private Fragment Z0(boolean z) {
        String str;
        if (z) {
            ax.B0.c.h(this);
        }
        Fragment fragment = this.n0;
        if (fragment != null) {
            return fragment;
        }
        FragmentManager fragmentManager = this.z0;
        if (fragmentManager == null || (str = this.o0) == null) {
            return null;
        }
        return fragmentManager.h0(str);
    }

    private void d1() {
        this.Z0 = new androidx.lifecycle.g(this);
        this.d1 = ax.p245p2.c.a(this);
        this.c1 = null;
        if (this.g1.contains(this.h1)) {
            return;
        }
        v2(this.h1);
    }

    @Deprecated
    public static Fragment g1(Context context, String str, Bundle bundle) {
        try {
            Fragment fragmentNewInstance = androidx.fragment.app.i.d(context.getClassLoader(), str).getConstructor(null).newInstance(null);
            if (bundle == null) {
                return fragmentNewInstance;
            }
            bundle.setClassLoader(fragmentNewInstance.getClass().getClassLoader());
            fragmentNewInstance.F2(bundle);
            return fragmentNewInstance;
        } catch (IllegalAccessException e2) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new h("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new h("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    private f m0() {
        if (this.R0 == null) {
            this.R0 = new f();
        }
        return this.R0;
    }

    private void v2(i iVar) {
        if (this.q >= 0) {
            iVar.a();
        } else {
            this.g1.add(iVar);
        }
    }

    View A0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        return fVar.s;
    }

    @Deprecated
    public void A1(Menu menu, MenuInflater menuInflater) {
    }

    public final View A2() {
        View viewA1 = a1();
        if (viewA1 != null) {
            return viewA1;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    @Deprecated
    public final FragmentManager B0() {
        return this.z0;
    }

    public View B1(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.e1;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    void B2(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.B0.g1(parcelable);
        this.B0.D();
    }

    public final Object C0() {
        j<?> jVar = this.A0;
        if (jVar == null) {
            return null;
        }
        return jVar.i();
    }

    public void C1() {
        this.M0 = true;
    }

    public final LayoutInflater D0() {
        LayoutInflater layoutInflater = this.V0;
        return layoutInflater == null ? h2(null) : layoutInflater;
    }

    @Deprecated
    public void D1() {
    }

    final void D2(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.Y;
        if (sparseArray != null) {
            this.O0.restoreHierarchyState(sparseArray);
            this.Y = null;
        }
        if (this.O0 != null) {
            this.a1.d(this.Z);
            this.Z = null;
        }
        this.M0 = false;
        W1(bundle);
        if (this.M0) {
            if (this.O0 != null) {
                this.a1.a(androidx.lifecycle.d.a.ON_CREATE);
            }
        } else {
            throw new B("Fragment " + this + " did not call through to super.onViewStateRestored()");
        }
    }

    @Deprecated
    public LayoutInflater E0(Bundle bundle) {
        j<?> jVar = this.A0;
        if (jVar == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        LayoutInflater layoutInflaterJ = jVar.j();
        C1873v.a(layoutInflaterJ, this.B0.x0());
        return layoutInflaterJ;
    }

    public void E1() {
        this.M0 = true;
    }

    void E2(int i2, int i3, int i4, int i5) {
        if (this.R0 == null && i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) {
            return;
        }
        m0().c = i2;
        m0().d = i3;
        m0().e = i4;
        m0().f = i5;
    }

    @Deprecated
    public ax.J0.a F0() {
        return ax.J0.a.c(this);
    }

    public void F1() {
        this.M0 = true;
    }

    public void F2(Bundle bundle) {
        if (this.z0 != null && p1()) {
            throw new IllegalStateException("Fragment already added and state has been saved");
        }
        this.m0 = bundle;
    }

    public LayoutInflater G1(Bundle bundle) {
        return E0(bundle);
    }

    void G2(View view) {
        m0().s = view;
    }

    int H0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 0;
        }
        return fVar.g;
    }

    public void H1(boolean z) {
    }

    @Deprecated
    public void H2(boolean z) {
        if (this.K0 != z) {
            this.K0 = z;
            if (!h1() || j1()) {
                return;
            }
            this.A0.o();
        }
    }

    public final Fragment I0() {
        return this.C0;
    }

    @Deprecated
    public void I1(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.M0 = true;
    }

    public void I2(boolean z) {
        if (this.L0 != z) {
            this.L0 = z;
            if (this.K0 && h1() && !j1()) {
                this.A0.o();
            }
        }
    }

    public final FragmentManager J0() {
        FragmentManager fragmentManager = this.z0;
        if (fragmentManager != null) {
            return fragmentManager;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public void J1(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.M0 = true;
        j<?> jVar = this.A0;
        Activity activityE = jVar == null ? null : jVar.e();
        if (activityE != null) {
            this.M0 = false;
            I1(activityE, attributeSet, bundle);
        }
    }

    void J2(int i2) {
        if (this.R0 == null && i2 == 0) {
            return;
        }
        m0();
        this.R0.g = i2;
    }

    boolean K0() {
        f fVar = this.R0;
        if (fVar == null) {
            return false;
        }
        return fVar.b;
    }

    public void K1(boolean z) {
    }

    void K2(boolean z) {
        if (this.R0 == null) {
            return;
        }
        m0().b = z;
    }

    int L0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 0;
        }
        return fVar.e;
    }

    @Deprecated
    public boolean L1(MenuItem menuItem) {
        return false;
    }

    void L2(float f2) {
        m0().r = f2;
    }

    int M0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 0;
        }
        return fVar.f;
    }

    @Deprecated
    public void M1(Menu menu) {
    }

    void M2(ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        m0();
        f fVar = this.R0;
        fVar.h = arrayList;
        fVar.i = arrayList2;
    }

    float N0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 1.0f;
        }
        return fVar.r;
    }

    public void N1() {
        this.M0 = true;
    }

    @Deprecated
    public void N2(Fragment fragment, int i2) {
        if (fragment != null) {
            ax.B0.c.i(this, fragment, i2);
        }
        FragmentManager fragmentManager = this.z0;
        FragmentManager fragmentManager2 = fragment != null ? fragment.z0 : null;
        if (fragmentManager != null && fragmentManager2 != null && fragmentManager != fragmentManager2) {
            throw new IllegalArgumentException("Fragment " + fragment + " must share the same FragmentManager to be set as a target fragment");
        }
        for (Fragment fragmentZ0 = fragment; fragmentZ0 != null; fragmentZ0 = fragmentZ0.Z0(false)) {
            if (fragmentZ0.equals(this)) {
                throw new IllegalArgumentException("Setting " + fragment + " as the target of " + this + " would create a target cycle");
            }
        }
        if (fragment == null) {
            this.o0 = null;
            this.n0 = null;
        } else if (this.z0 == null || fragment.z0 == null) {
            this.o0 = null;
            this.n0 = fragment;
        } else {
            this.o0 = fragment.l0;
            this.n0 = null;
        }
        this.p0 = i2;
    }

    public Object O0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.m;
        return obj == i1 ? y0() : obj;
    }

    public void O1(boolean z) {
    }

    public boolean O2(String str) {
        j<?> jVar = this.A0;
        if (jVar != null) {
            return jVar.l(str);
        }
        return false;
    }

    public final Resources P0() {
        return z2().getResources();
    }

    @Deprecated
    public void P1(Menu menu) {
    }

    public void P2(@SuppressLint({"UnknownNullness"}) Intent intent) {
        Q2(intent, null);
    }

    public Object Q0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.k;
        return obj == i1 ? v0() : obj;
    }

    public void Q1(boolean z) {
    }

    public void Q2(@SuppressLint({"UnknownNullness"}) Intent intent, Bundle bundle) {
        j<?> jVar = this.A0;
        if (jVar != null) {
            jVar.m(this, intent, -1, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    public Object R0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        return fVar.n;
    }

    public void R1() {
        this.M0 = true;
    }

    @Deprecated
    public void R2(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (this.A0 != null) {
            J0().S0(this, intent, i2, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    public Object S0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.o;
        return obj == i1 ? R0() : obj;
    }

    public void S1(Bundle bundle) {
    }

    @Deprecated
    public void S2(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        Bundle bundle2;
        if (this.A0 == null) {
            throw new IllegalStateException("Fragment " + this + " not attached to Activity");
        }
        if (FragmentManager.J0(2)) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(this);
            sb.append(" received the following in startIntentSenderForResult() requestCode: ");
            sb.append(i2);
            sb.append(" IntentSender: ");
            sb.append(intentSender);
            sb.append(" fillInIntent: ");
            sb.append(intent);
            sb.append(" options: ");
            bundle2 = bundle;
            sb.append(bundle2);
            Log.v("FragmentManager", sb.toString());
        } else {
            bundle2 = bundle;
        }
        J0().T0(this, intentSender, i2, intent, i3, i4, i5, bundle2);
    }

    ArrayList<String> T0() {
        ArrayList<String> arrayList;
        f fVar = this.R0;
        return (fVar == null || (arrayList = fVar.h) == null) ? new ArrayList<>() : arrayList;
    }

    public void T1() {
        this.M0 = true;
    }

    public void T2() {
        if (this.R0 == null || !m0().t) {
            return;
        }
        if (this.A0 == null) {
            m0().t = false;
        } else if (Looper.myLooper() != this.A0.g().getLooper()) {
            this.A0.g().postAtFrontOfQueue(new c());
        } else {
            j0(true);
        }
    }

    ArrayList<String> U0() {
        ArrayList<String> arrayList;
        f fVar = this.R0;
        return (fVar == null || (arrayList = fVar.i) == null) ? new ArrayList<>() : arrayList;
    }

    public void U1() {
        this.M0 = true;
    }

    public final String V0(int i2) {
        return P0().getString(i2);
    }

    public void V1(View view, Bundle bundle) {
    }

    public final String W0(int i2, Object... objArr) {
        return P0().getString(i2, objArr);
    }

    public void W1(Bundle bundle) {
        this.M0 = true;
    }

    public final String X0() {
        return this.F0;
    }

    void X1(Bundle bundle) {
        this.B0.V0();
        this.q = 3;
        this.M0 = false;
        r1(bundle);
        if (this.M0) {
            C2();
            this.B0.z();
        } else {
            throw new B("Fragment " + this + " did not call through to super.onActivityCreated()");
        }
    }

    @Deprecated
    public final Fragment Y0() {
        return Z0(true);
    }

    void Y1() {
        ArrayList<i> arrayList = this.g1;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            i iVar = arrayList.get(i2);
            i2++;
            iVar.a();
        }
        this.g1.clear();
        this.B0.m(this.A0, k0(), this);
        this.q = 0;
        this.M0 = false;
        u1(this.A0.f());
        if (this.M0) {
            this.z0.J(this);
            this.B0.A();
        } else {
            throw new B("Fragment " + this + " did not call through to super.onAttach()");
        }
    }

    void Z1(Configuration configuration) {
        onConfigurationChanged(configuration);
    }

    public View a1() {
        return this.O0;
    }

    boolean a2(MenuItem menuItem) {
        if (this.G0) {
            return false;
        }
        if (w1(menuItem)) {
            return true;
        }
        return this.B0.C(menuItem);
    }

    public ax.G0.h b1() {
        x xVar = this.a1;
        if (xVar != null) {
            return xVar;
        }
        throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
    }

    void b2(Bundle bundle) {
        this.B0.V0();
        this.q = 1;
        this.M0 = false;
        this.Z0.a(new androidx.lifecycle.f() { // from class: androidx.fragment.app.Fragment.6
            @Override // androidx.lifecycle.f
            public void b(ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
                View view;
                if (aVar != androidx.lifecycle.d.a.ON_STOP || (view = Fragment.this.O0) == null) {
                    return;
                }
                g.a(view);
            }
        });
        this.d1.d(bundle);
        x1(bundle);
        this.W0 = true;
        if (this.M0) {
            this.Z0.h(androidx.lifecycle.d.a.ON_CREATE);
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onCreate()");
    }

    public LiveData<ax.G0.h> c1() {
        return this.b1;
    }

    boolean c2(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.G0) {
            return false;
        }
        if (this.K0 && this.L0) {
            A1(menu, menuInflater);
            z = true;
        }
        return this.B0.E(menu, menuInflater) | z;
    }

    void d2(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.B0.V0();
        this.x0 = true;
        this.a1 = new x(this, getViewModelStore());
        View viewB1 = B1(layoutInflater, viewGroup, bundle);
        this.O0 = viewB1;
        if (viewB1 == null) {
            if (this.a1.c()) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.a1 = null;
        } else {
            this.a1.b();
            ax.G0.w.a(this.O0, this.a1);
            ax.G0.x.a(this.O0, this.a1);
            ax.p245p2.e.a(this.O0, this.a1);
            this.b1.n(this.a1);
        }
    }

    void e2() {
        this.B0.F();
        this.Z0.h(androidx.lifecycle.d.a.ON_DESTROY);
        this.q = 0;
        this.M0 = false;
        this.W0 = false;
        C1();
        if (this.M0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    void f1() {
        d1();
        this.X0 = this.l0;
        this.l0 = UUID.randomUUID().toString();
        this.r0 = false;
        this.s0 = false;
        this.u0 = false;
        this.v0 = false;
        this.w0 = false;
        this.y0 = 0;
        this.z0 = null;
        this.B0 = new m();
        this.A0 = null;
        this.D0 = 0;
        this.E0 = 0;
        this.F0 = null;
        this.G0 = false;
        this.H0 = false;
    }

    void f2() {
        this.B0.G();
        if (this.O0 != null && this.a1.getLifecycle().b().h(androidx.lifecycle.d.b.CREATED)) {
            this.a1.a(androidx.lifecycle.d.a.ON_DESTROY);
        }
        this.q = 1;
        this.M0 = false;
        E1();
        if (this.M0) {
            ax.J0.a.c(this).f();
            this.x0 = false;
        } else {
            throw new B("Fragment " + this + " did not call through to super.onDestroyView()");
        }
    }

    void g2() {
        this.q = -1;
        this.M0 = false;
        F1();
        this.V0 = null;
        if (this.M0) {
            if (this.B0.I0()) {
                return;
            }
            this.B0.F();
            this.B0 = new m();
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onDetach()");
    }

    public Context getContext() {
        j<?> jVar = this.A0;
        if (jVar == null) {
            return null;
        }
        return jVar.f();
    }

    @Override // androidx.lifecycle.c
    public ax.I0.a getDefaultViewModelCreationExtras() {
        Application application;
        Context applicationContext = z2().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        if (application == null && FragmentManager.J0(3)) {
            Log.d("FragmentManager", "Could not find Application instance from Context " + z2().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
        }
        ax.I0.d dVar = new ax.I0.d();
        if (application != null) {
            dVar.c(androidx.lifecycle.q.a.g, application);
        }
        dVar.c(androidx.lifecycle.m.a, this);
        dVar.c(androidx.lifecycle.m.b, this);
        if (s0() != null) {
            dVar.c(androidx.lifecycle.m.c, s0());
        }
        return dVar;
    }

    @Override // ax.G0.h
    public androidx.lifecycle.d getLifecycle() {
        return this.Z0;
    }

    @Override // ax.p245p2.d
    public final androidx.savedstate.a getSavedStateRegistry() {
        return this.d1.b();
    }

    @Override // ax.G0.v
    public androidx.lifecycle.r getViewModelStore() {
        if (this.z0 == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (G0() != androidx.lifecycle.d.b.INITIALIZED.ordinal()) {
            return this.z0.E0(this);
        }
        throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    }

    public final boolean h1() {
        return this.A0 != null && this.r0;
    }

    LayoutInflater h2(Bundle bundle) {
        LayoutInflater layoutInflaterG1 = G1(bundle);
        this.V0 = layoutInflaterG1;
        return layoutInflaterG1;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final boolean i1() {
        return this.H0;
    }

    void i2() {
        onLowMemory();
    }

    void j0(boolean z) {
        ViewGroup viewGroup;
        FragmentManager fragmentManager;
        f fVar = this.R0;
        if (fVar != null) {
            fVar.t = false;
        }
        if (this.O0 == null || (viewGroup = this.N0) == null || (fragmentManager = this.z0) == null) {
            return;
        }
        z zVarN = z.n(viewGroup, fragmentManager);
        zVarN.p();
        if (z) {
            this.A0.g().post(new d(zVarN));
        } else {
            zVarN.g();
        }
        Handler handler = this.S0;
        if (handler != null) {
            handler.removeCallbacks(this.T0);
            this.S0 = null;
        }
    }

    public final boolean j1() {
        if (this.G0) {
            return true;
        }
        FragmentManager fragmentManager = this.z0;
        return fragmentManager != null && fragmentManager.M0(this.C0);
    }

    void j2(boolean z) {
        K1(z);
    }

    ax.A0.e k0() {
        return new e();
    }

    final boolean k1() {
        return this.y0 > 0;
    }

    boolean k2(MenuItem menuItem) {
        if (this.G0) {
            return false;
        }
        if (this.K0 && this.L0 && L1(menuItem)) {
            return true;
        }
        return this.B0.L(menuItem);
    }

    public void l0(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.D0));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.E0));
        printWriter.print(" mTag=");
        printWriter.println(this.F0);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.q);
        printWriter.print(" mWho=");
        printWriter.print(this.l0);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.y0);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.r0);
        printWriter.print(" mRemoving=");
        printWriter.print(this.s0);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.u0);
        printWriter.print(" mInLayout=");
        printWriter.println(this.v0);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.G0);
        printWriter.print(" mDetached=");
        printWriter.print(this.H0);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.L0);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.K0);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.I0);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.Q0);
        if (this.z0 != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.z0);
        }
        if (this.A0 != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.A0);
        }
        if (this.C0 != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.C0);
        }
        if (this.m0 != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.m0);
        }
        if (this.X != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.X);
        }
        if (this.Y != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.Y);
        }
        if (this.Z != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.Z);
        }
        Fragment fragmentZ0 = Z0(false);
        if (fragmentZ0 != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(fragmentZ0);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.p0);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(K0());
        if (u0() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(u0());
        }
        if (x0() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(x0());
        }
        if (L0() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(L0());
        }
        if (M0() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(M0());
        }
        if (this.N0 != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.N0);
        }
        if (this.O0 != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.O0);
        }
        if (r0() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(r0());
        }
        if (getContext() != null) {
            ax.J0.a.c(this).b(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.B0 + ":");
        this.B0.Y(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public final boolean l1() {
        if (!this.L0) {
            return false;
        }
        FragmentManager fragmentManager = this.z0;
        return fragmentManager == null || fragmentManager.N0(this.C0);
    }

    void l2(Menu menu) {
        if (this.G0) {
            return;
        }
        if (this.K0 && this.L0) {
            M1(menu);
        }
        this.B0.M(menu);
    }

    boolean m1() {
        f fVar = this.R0;
        if (fVar == null) {
            return false;
        }
        return fVar.t;
    }

    void m2() {
        this.B0.O();
        if (this.O0 != null) {
            this.a1.a(androidx.lifecycle.d.a.ON_PAUSE);
        }
        this.Z0.h(androidx.lifecycle.d.a.ON_PAUSE);
        this.q = 6;
        this.M0 = false;
        N1();
        if (this.M0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onPause()");
    }

    Fragment n0(String str) {
        return str.equals(this.l0) ? this : this.B0.l0(str);
    }

    public final boolean n1() {
        return this.s0;
    }

    void n2(boolean z) {
        O1(z);
    }

    public final androidx.fragment.app.f o0() {
        j<?> jVar = this.A0;
        if (jVar == null) {
            return null;
        }
        return (androidx.fragment.app.f) jVar.e();
    }

    public final boolean o1() {
        return this.q >= 7;
    }

    boolean o2(Menu menu) {
        boolean z = false;
        if (this.G0) {
            return false;
        }
        if (this.K0 && this.L0) {
            P1(menu);
            z = true;
        }
        return this.B0.Q(menu) | z;
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.M0 = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        x2().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.M0 = true;
    }

    @Deprecated
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
    }

    public boolean p0() {
        Boolean bool;
        f fVar = this.R0;
        if (fVar == null || (bool = fVar.q) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public final boolean p1() {
        FragmentManager fragmentManager = this.z0;
        if (fragmentManager == null) {
            return false;
        }
        return fragmentManager.Q0();
    }

    void p2() {
        boolean zO0 = this.z0.O0(this);
        Boolean bool = this.q0;
        if (bool == null || bool.booleanValue() != zO0) {
            this.q0 = Boolean.valueOf(zO0);
            Q1(zO0);
            this.B0.R();
        }
    }

    public boolean q0() {
        Boolean bool;
        f fVar = this.R0;
        if (fVar == null || (bool = fVar.p) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    void q1() {
        this.B0.V0();
    }

    void q2() {
        this.B0.V0();
        this.B0.c0(true);
        this.q = 7;
        this.M0 = false;
        R1();
        if (!this.M0) {
            throw new B("Fragment " + this + " did not call through to super.onResume()");
        }
        androidx.lifecycle.g gVar = this.Z0;
        androidx.lifecycle.d.a aVar = androidx.lifecycle.d.a.ON_RESUME;
        gVar.h(aVar);
        if (this.O0 != null) {
            this.a1.a(aVar);
        }
        this.B0.S();
    }

    View r0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        return fVar.a;
    }

    @Deprecated
    public void r1(Bundle bundle) {
        this.M0 = true;
    }

    void r2(Bundle bundle) {
        S1(bundle);
        this.d1.e(bundle);
        Bundle bundleI1 = this.B0.i1();
        if (bundleI1 != null) {
            bundle.putParcelable("android:support:fragments", bundleI1);
        }
    }

    public final Bundle s0() {
        return this.m0;
    }

    @Deprecated
    public void s1(int i2, int i3, Intent intent) {
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i2 + " resultCode: " + i3 + " data: " + intent);
        }
    }

    void s2() {
        this.B0.V0();
        this.B0.c0(true);
        this.q = 5;
        this.M0 = false;
        T1();
        if (!this.M0) {
            throw new B("Fragment " + this + " did not call through to super.onStart()");
        }
        androidx.lifecycle.g gVar = this.Z0;
        androidx.lifecycle.d.a aVar = androidx.lifecycle.d.a.ON_START;
        gVar.h(aVar);
        if (this.O0 != null) {
            this.a1.a(aVar);
        }
        this.B0.T();
    }

    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        R2(intent, i2, null);
    }

    public final FragmentManager t0() {
        if (this.A0 != null) {
            return this.B0;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    @Deprecated
    public void t1(Activity activity) {
        this.M0 = true;
    }

    void t2() {
        this.B0.V();
        if (this.O0 != null) {
            this.a1.a(androidx.lifecycle.d.a.ON_STOP);
        }
        this.Z0.h(androidx.lifecycle.d.a.ON_STOP);
        this.q = 4;
        this.M0 = false;
        U1();
        if (this.M0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onStop()");
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.l0);
        if (this.D0 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.D0));
        }
        if (this.F0 != null) {
            sb.append(" tag=");
            sb.append(this.F0);
        }
        sb.append(")");
        return sb.toString();
    }

    int u0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 0;
        }
        return fVar.c;
    }

    public void u1(Context context) {
        this.M0 = true;
        j<?> jVar = this.A0;
        Activity activityE = jVar == null ? null : jVar.e();
        if (activityE != null) {
            this.M0 = false;
            t1(activityE);
        }
    }

    void u2() {
        V1(this.O0, this.X);
        this.B0.W();
    }

    public Object v0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        return fVar.j;
    }

    @Deprecated
    public void v1(Fragment fragment) {
    }

    ax.P.v w0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public boolean w1(MenuItem menuItem) {
        return false;
    }

    @Deprecated
    public final void w2(String[] strArr, int i2) {
        if (this.A0 != null) {
            J0().R0(this, strArr, i2);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    int x0() {
        f fVar = this.R0;
        if (fVar == null) {
            return 0;
        }
        return fVar.d;
    }

    public void x1(Bundle bundle) {
        this.M0 = true;
        B2(bundle);
        if (this.B0.P0(1)) {
            return;
        }
        this.B0.D();
    }

    public final androidx.fragment.app.f x2() {
        androidx.fragment.app.f fVarO0 = o0();
        if (fVarO0 != null) {
            return fVarO0;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public Object y0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        return fVar.l;
    }

    public Animation y1(int i2, boolean z, int i3) {
        return null;
    }

    public final Bundle y2() {
        Bundle bundleS0 = s0();
        if (bundleS0 != null) {
            return bundleS0;
        }
        throw new IllegalStateException("Fragment " + this + " does not have any arguments.");
    }

    ax.P.v z0() {
        f fVar = this.R0;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public Animator z1(int i2, boolean z, int i3) {
        return null;
    }

    public final Context z2() {
        Context context = getContext();
        if (context != null) {
            return context;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }
}
