package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.LiveData;
import ax.p015b0.C5248v;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, ax.F0.g, ax.F0.t, androidx.lifecycle.c, ax.p016b1.d {
    static final Object f1 = new Object();
    int A0;
    int B0;
    String C0;
    boolean D0;
    boolean E0;
    boolean F0;
    boolean G0;
    boolean H0;
    private boolean J0;
    ViewGroup K0;
    View L0;
    boolean M0;
    f O0;
    Handler P0;
    boolean R0;
    LayoutInflater S0;
    boolean T0;
    public String U0;
    androidx.lifecycle.g W0;
    Bundle X;
    x X0;
    SparseArray<Parcelable> Y;
    Bundle Z;
    androidx.lifecycle.p.b Z0;
    ax.p016b1.c a1;
    private int b1;
    Boolean h0;
    Bundle j0;
    Fragment k0;
    int m0;
    boolean o0;
    boolean p0;
    boolean q0;
    boolean r0;
    boolean s0;
    boolean t0;
    boolean u0;
    int v0;
    m w0;
    j<?> x0;
    Fragment z0;
    int q = -1;
    String i0 = UUID.randomUUID().toString();
    String l0 = null;
    private Boolean n0 = null;
    m y0 = new n();
    boolean I0 = true;
    boolean N0 = true;
    Runnable Q0 = new a();
    androidx.lifecycle.d.b V0 = androidx.lifecycle.d.b.RESUMED;
    ax.F0.k<ax.F0.g> Y0 = new ax.F0.k<>();
    private final AtomicInteger c1 = new AtomicInteger();
    private final ArrayList<i> d1 = new ArrayList<>();
    private final i e1 = new b();

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.W2();
        }
    }

    class b extends i {
        b() {
            super(null);
        }

        @Override // androidx.fragment.app.Fragment.i
        void a() {
            Fragment.this.a1.c();
            androidx.lifecycle.m.a(Fragment.this);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.n0(false);
        }
    }

    class d implements Runnable {
        final /* synthetic */ z q;

        d(z zVar) {
            this.q = zVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.g();
        }
    }

    class e extends ax.p351z0.e {
        e() {
        }

        @Override // ax.p351z0.e
        public View c(int i) {
            View view = Fragment.this.L0;
            if (view != null) {
                return view.findViewById(i);
            }
            throw new IllegalStateException("Fragment " + Fragment.this + " does not have a view");
        }

        @Override // ax.p351z0.e
        public boolean d() {
            return Fragment.this.L0 != null;
        }
    }

    static class f {
        View a;
        boolean b;
        int c;
        int d;
        int e;
        int f;
        int g;
        ArrayList<String> h;
        ArrayList<String> i;
        Object j = null;
        Object k;
        Object l;
        Object m;
        Object n;
        Object o;
        Boolean p;
        Boolean q;
        float r;
        View s;
        boolean t;

        f() {
            Object obj = Fragment.f1;
            this.k = obj;
            this.l = null;
            this.m = obj;
            this.n = null;
            this.o = obj;
            this.r = 1.0f;
            this.s = null;
        }
    }

    static class g {
        static void a(View view) {
            view.cancelPendingInputEvents();
        }
    }

    public static class h extends RuntimeException {
        public h(String str, Exception exc) {
            super(str, exc);
        }
    }

    private static abstract class i {
        private i() {
        }

        abstract void a();

        /* synthetic */ i(a aVar) {
            this();
        }
    }

    public Fragment() {
        i1();
    }

    private void G2() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this);
        }
        if (this.L0 != null) {
            H2(this.X);
        }
        this.X = null;
    }

    private int K0() {
        androidx.lifecycle.d.b bVar = this.V0;
        return (bVar == androidx.lifecycle.d.b.INITIALIZED || this.z0 == null) ? bVar.ordinal() : Math.min(bVar.ordinal(), this.z0.K0());
    }

    private Fragment e1(boolean z) {
        String str;
        if (z) {
            ax.A0.c.i(this);
        }
        Fragment fragment = this.k0;
        if (fragment != null) {
            return fragment;
        }
        m mVar = this.w0;
        if (mVar == null || (str = this.l0) == null) {
            return null;
        }
        return mVar.f0(str);
    }

    private void i1() {
        this.W0 = new androidx.lifecycle.g(this);
        this.a1 = ax.p016b1.c.a(this);
        this.Z0 = null;
        if (this.d1.contains(this.e1)) {
            return;
        }
        z2(this.e1);
    }

    @Deprecated
    public static Fragment k1(Context context, String str, Bundle bundle) {
        try {
            Fragment fragmentNewInstance = androidx.fragment.app.i.d(context.getClassLoader(), str).getConstructor(null).newInstance(null);
            if (bundle != null) {
                bundle.setClassLoader(fragmentNewInstance.getClass().getClassLoader());
                fragmentNewInstance.J2(bundle);
            }
            return fragmentNewInstance;
        } catch (IllegalAccessException e2) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new h("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new h("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    private f q0() {
        if (this.O0 == null) {
            this.O0 = new f();
        }
        return this.O0;
    }

    private void z2(i iVar) {
        if (this.q >= 0) {
            iVar.a();
        } else {
            this.d1.add(iVar);
        }
    }

    ax.O.v A0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public boolean A1(MenuItem menuItem) {
        return false;
    }

    @Deprecated
    public final void A2(String[] strArr, int i2) {
        if (this.x0 != null) {
            N0().U0(this, strArr, i2);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    int B0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 0;
        }
        return fVar.d;
    }

    public void B1(Bundle bundle) {
        this.J0 = true;
        F2(bundle);
        if (this.y0.N0(1)) {
            return;
        }
        this.y0.B();
    }

    public final androidx.fragment.app.f B2() {
        androidx.fragment.app.f fVarS0 = s0();
        if (fVarS0 != null) {
            return fVarS0;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public Object C0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        return fVar.l;
    }

    public Animation C1(int i2, boolean z, int i3) {
        return null;
    }

    public final Bundle C2() {
        Bundle bundleW0 = w0();
        if (bundleW0 != null) {
            return bundleW0;
        }
        throw new IllegalStateException("Fragment " + this + " does not have any arguments.");
    }

    ax.O.v D0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public Animator D1(int i2, boolean z, int i3) {
        return null;
    }

    public final Context D2() {
        Context context = getContext();
        if (context != null) {
            return context;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    @Override // androidx.lifecycle.c
    public ax.H0.a E() {
        Application application;
        Context applicationContext = D2().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        if (application == null && m.H0(3)) {
            Log.d("FragmentManager", "Could not find Application instance from Context " + D2().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
        }
        ax.H0.d dVar = new ax.H0.d();
        if (application != null) {
            dVar.b(androidx.lifecycle.p.a.d, application);
        }
        dVar.b(androidx.lifecycle.m.a, this);
        dVar.b(androidx.lifecycle.m.b, this);
        if (w0() != null) {
            dVar.b(androidx.lifecycle.m.c, w0());
        }
        return dVar;
    }

    View E0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        return fVar.s;
    }

    @Deprecated
    public void E1(Menu menu, MenuInflater menuInflater) {
    }

    public final View E2() {
        View viewG1 = g1();
        if (viewG1 != null) {
            return viewG1;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    @Deprecated
    public final m F0() {
        return this.w0;
    }

    public View F1(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.b1;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    void F2(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.y0.i1(parcelable);
        this.y0.B();
    }

    public final Object G0() {
        j<?> jVar = this.x0;
        if (jVar == null) {
            return null;
        }
        return jVar.k();
    }

    public void G1() {
        this.J0 = true;
    }

    public final LayoutInflater H0() {
        LayoutInflater layoutInflater = this.S0;
        return layoutInflater == null ? l2(null) : layoutInflater;
    }

    @Deprecated
    public void H1() {
    }

    final void H2(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.Y;
        if (sparseArray != null) {
            this.L0.restoreHierarchyState(sparseArray);
            this.Y = null;
        }
        if (this.L0 != null) {
            this.X0.d(this.Z);
            this.Z = null;
        }
        this.J0 = false;
        a2(bundle);
        if (this.J0) {
            if (this.L0 != null) {
                this.X0.a(androidx.lifecycle.d.a.ON_CREATE);
            }
        } else {
            throw new B("Fragment " + this + " did not call through to super.onViewStateRestored()");
        }
    }

    @Deprecated
    public LayoutInflater I0(Bundle bundle) {
        j<?> jVar = this.x0;
        if (jVar == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        LayoutInflater layoutInflaterM = jVar.m();
        C5248v.a(layoutInflaterM, this.y0.v0());
        return layoutInflaterM;
    }

    public void I1() {
        this.J0 = true;
    }

    void I2(int i2, int i3, int i4, int i5) {
        if (this.O0 == null && i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) {
            return;
        }
        q0().c = i2;
        q0().d = i3;
        q0().e = i4;
        q0().f = i5;
    }

    @Override // ax.F0.t
    public androidx.lifecycle.q J() {
        if (this.w0 == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (K0() != androidx.lifecycle.d.b.INITIALIZED.ordinal()) {
            return this.w0.C0(this);
        }
        throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    }

    @Deprecated
    public ax.I0.a J0() {
        return ax.I0.a.c(this);
    }

    public void J1() {
        this.J0 = true;
    }

    public void J2(Bundle bundle) {
        if (this.w0 != null && t1()) {
            throw new IllegalStateException("Fragment already added and state has been saved");
        }
        this.j0 = bundle;
    }

    public LayoutInflater K1(Bundle bundle) {
        return I0(bundle);
    }

    void K2(View view) {
        q0().s = view;
    }

    int L0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 0;
        }
        return fVar.g;
    }

    public void L1(boolean z) {
    }

    @Deprecated
    public void L2(boolean z) {
        if (this.H0 != z) {
            this.H0 = z;
            if (!l1() || n1()) {
                return;
            }
            this.x0.t();
        }
    }

    public final Fragment M0() {
        return this.z0;
    }

    @Deprecated
    public void M1(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.J0 = true;
    }

    public void M2(boolean z) {
        if (this.I0 != z) {
            this.I0 = z;
            if (this.H0 && l1() && !n1()) {
                this.x0.t();
            }
        }
    }

    public final m N0() {
        m mVar = this.w0;
        if (mVar != null) {
            return mVar;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public void N1(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.J0 = true;
        j<?> jVar = this.x0;
        Activity activityE = jVar == null ? null : jVar.e();
        if (activityE != null) {
            this.J0 = false;
            M1(activityE, attributeSet, bundle);
        }
    }

    void N2(int i2) {
        if (this.O0 == null && i2 == 0) {
            return;
        }
        q0();
        this.O0.g = i2;
    }

    boolean O0() {
        f fVar = this.O0;
        if (fVar == null) {
            return false;
        }
        return fVar.b;
    }

    public void O1(boolean z) {
    }

    void O2(boolean z) {
        if (this.O0 == null) {
            return;
        }
        q0().b = z;
    }

    int P0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 0;
        }
        return fVar.e;
    }

    @Deprecated
    public boolean P1(MenuItem menuItem) {
        return false;
    }

    void P2(float f2) {
        q0().r = f2;
    }

    int Q0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 0;
        }
        return fVar.f;
    }

    @Deprecated
    public void Q1(Menu menu) {
    }

    void Q2(ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        q0();
        f fVar = this.O0;
        fVar.h = arrayList;
        fVar.i = arrayList2;
    }

    @Override // ax.p016b1.d
    public final androidx.savedstate.a R() {
        return this.a1.b();
    }

    float R0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 1.0f;
        }
        return fVar.r;
    }

    public void R1() {
        this.J0 = true;
    }

    @Deprecated
    public void R2(Fragment fragment, int i2) {
        if (fragment != null) {
            ax.A0.c.j(this, fragment, i2);
        }
        m mVar = this.w0;
        m mVar2 = fragment != null ? fragment.w0 : null;
        if (mVar != null && mVar2 != null && mVar != mVar2) {
            throw new IllegalArgumentException("Fragment " + fragment + " must share the same FragmentManager to be set as a target fragment");
        }
        for (Fragment fragmentE1 = fragment; fragmentE1 != null; fragmentE1 = fragmentE1.e1(false)) {
            if (fragmentE1.equals(this)) {
                throw new IllegalArgumentException("Setting " + fragment + " as the target of " + this + " would create a target cycle");
            }
        }
        if (fragment == null) {
            this.l0 = null;
            this.k0 = null;
        } else if (this.w0 == null || fragment.w0 == null) {
            this.l0 = null;
            this.k0 = fragment;
        } else {
            this.l0 = fragment.i0;
            this.k0 = null;
        }
        this.m0 = i2;
    }

    public Object S0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.m;
        return obj == f1 ? C0() : obj;
    }

    public void S1(boolean z) {
    }

    public boolean S2(String str) {
        j<?> jVar = this.x0;
        if (jVar != null) {
            return jVar.o(str);
        }
        return false;
    }

    public final Resources T0() {
        return D2().getResources();
    }

    @Deprecated
    public void T1(Menu menu) {
    }

    public void T2(@SuppressLint({"UnknownNullness"}) Intent intent) {
        U2(intent, null);
    }

    public Object U0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.k;
        return obj == f1 ? z0() : obj;
    }

    public void U1(boolean z) {
    }

    public void U2(@SuppressLint({"UnknownNullness"}) Intent intent, Bundle bundle) {
        j<?> jVar = this.x0;
        if (jVar != null) {
            jVar.p(this, intent, -1, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    public Object V0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        return fVar.n;
    }

    public void V1() {
        this.J0 = true;
    }

    @Deprecated
    public void V2(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (this.x0 != null) {
            N0().V0(this, intent, i2, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    public Object W0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.o;
        return obj == f1 ? V0() : obj;
    }

    public void W1(Bundle bundle) {
    }

    public void W2() {
        if (this.O0 == null || !q0().t) {
            return;
        }
        if (this.x0 == null) {
            q0().t = false;
        } else if (Looper.myLooper() != this.x0.h().getLooper()) {
            this.x0.h().postAtFrontOfQueue(new c());
        } else {
            n0(true);
        }
    }

    ArrayList<String> X0() {
        ArrayList<String> arrayList;
        f fVar = this.O0;
        return (fVar == null || (arrayList = fVar.h) == null) ? new ArrayList<>() : arrayList;
    }

    public void X1() {
        this.J0 = true;
    }

    ArrayList<String> Y0() {
        ArrayList<String> arrayList;
        f fVar = this.O0;
        return (fVar == null || (arrayList = fVar.i) == null) ? new ArrayList<>() : arrayList;
    }

    public void Y1() {
        this.J0 = true;
    }

    public final String Z0(int i2) {
        return T0().getString(i2);
    }

    public void Z1(View view, Bundle bundle) {
    }

    public void a2(Bundle bundle) {
        this.J0 = true;
    }

    public final String b1(int i2, Object... objArr) {
        return T0().getString(i2, objArr);
    }

    void b2(Bundle bundle) {
        this.y0.X0();
        this.q = 3;
        this.J0 = false;
        v1(bundle);
        if (this.J0) {
            G2();
            this.y0.x();
        } else {
            throw new B("Fragment " + this + " did not call through to super.onActivityCreated()");
        }
    }

    public final String c1() {
        return this.C0;
    }

    void c2() {
        Iterator<i> it = this.d1.iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.d1.clear();
        this.y0.m(this.x0, o0(), this);
        this.q = 0;
        this.J0 = false;
        y1(this.x0.g());
        if (this.J0) {
            this.w0.H(this);
            this.y0.y();
        } else {
            throw new B("Fragment " + this + " did not call through to super.onAttach()");
        }
    }

    @Deprecated
    public final Fragment d1() {
        return e1(true);
    }

    void d2(Configuration configuration) {
        onConfigurationChanged(configuration);
    }

    boolean e2(MenuItem menuItem) {
        if (this.D0) {
            return false;
        }
        if (A1(menuItem)) {
            return true;
        }
        return this.y0.A(menuItem);
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override // ax.F0.g
    public androidx.lifecycle.d f() {
        return this.W0;
    }

    @Deprecated
    public final int f1() {
        ax.A0.c.h(this);
        return this.m0;
    }

    void f2(Bundle bundle) {
        this.y0.X0();
        this.q = 1;
        this.J0 = false;
        this.W0.a(new androidx.lifecycle.f() { // from class: androidx.fragment.app.Fragment.6
            @Override // androidx.lifecycle.f
            public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                View view;
                if (aVar != androidx.lifecycle.d.a.ON_STOP || (view = Fragment.this.L0) == null) {
                    return;
                }
                g.a(view);
            }
        });
        this.a1.d(bundle);
        B1(bundle);
        this.T0 = true;
        if (this.J0) {
            this.W0.h(androidx.lifecycle.d.a.ON_CREATE);
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onCreate()");
    }

    public View g1() {
        return this.L0;
    }

    boolean g2(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.D0) {
            return false;
        }
        if (this.H0 && this.I0) {
            E1(menu, menuInflater);
            z = true;
        }
        return z | this.y0.C(menu, menuInflater);
    }

    public Context getContext() {
        j<?> jVar = this.x0;
        if (jVar == null) {
            return null;
        }
        return jVar.g();
    }

    public LiveData<ax.F0.g> h1() {
        return this.Y0;
    }

    void h2(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.y0.X0();
        this.u0 = true;
        this.X0 = new x(this, J());
        View viewF1 = F1(layoutInflater, viewGroup, bundle);
        this.L0 = viewF1;
        if (viewF1 == null) {
            if (this.X0.c()) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.X0 = null;
        } else {
            this.X0.b();
            ax.F0.u.a(this.L0, this.X0);
            ax.F0.v.a(this.L0, this.X0);
            ax.p016b1.e.a(this.L0, this.X0);
            this.Y0.n(this.X0);
        }
    }

    public final int hashCode() {
        return super.hashCode();
    }

    void i2() {
        this.y0.D();
        this.W0.h(androidx.lifecycle.d.a.ON_DESTROY);
        this.q = 0;
        this.J0 = false;
        this.T0 = false;
        G1();
        if (this.J0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onDestroy()");
    }

    void j1() {
        i1();
        this.U0 = this.i0;
        this.i0 = UUID.randomUUID().toString();
        this.o0 = false;
        this.p0 = false;
        this.r0 = false;
        this.s0 = false;
        this.t0 = false;
        this.v0 = 0;
        this.w0 = null;
        this.y0 = new n();
        this.x0 = null;
        this.A0 = 0;
        this.B0 = 0;
        this.C0 = null;
        this.D0 = false;
        this.E0 = false;
    }

    void j2() {
        this.y0.E();
        if (this.L0 != null && this.X0.f().b().h(androidx.lifecycle.d.b.CREATED)) {
            this.X0.a(androidx.lifecycle.d.a.ON_DESTROY);
        }
        this.q = 1;
        this.J0 = false;
        I1();
        if (this.J0) {
            ax.I0.a.c(this).f();
            this.u0 = false;
        } else {
            throw new B("Fragment " + this + " did not call through to super.onDestroyView()");
        }
    }

    void k2() {
        this.q = -1;
        this.J0 = false;
        J1();
        this.S0 = null;
        if (this.J0) {
            if (this.y0.G0()) {
                return;
            }
            this.y0.D();
            this.y0 = new n();
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onDetach()");
    }

    public final boolean l1() {
        return this.x0 != null && this.o0;
    }

    LayoutInflater l2(Bundle bundle) {
        LayoutInflater layoutInflaterK1 = K1(bundle);
        this.S0 = layoutInflaterK1;
        return layoutInflaterK1;
    }

    public final boolean m1() {
        return this.E0;
    }

    void m2() {
        onLowMemory();
    }

    void n0(boolean z) {
        ViewGroup viewGroup;
        m mVar;
        f fVar = this.O0;
        if (fVar != null) {
            fVar.t = false;
        }
        if (this.L0 == null || (viewGroup = this.K0) == null || (mVar = this.w0) == null) {
            return;
        }
        z zVarN = z.n(viewGroup, mVar);
        zVarN.p();
        if (z) {
            this.x0.h().post(new d(zVarN));
        } else {
            zVarN.g();
        }
        Handler handler = this.P0;
        if (handler != null) {
            handler.removeCallbacks(this.Q0);
            this.P0 = null;
        }
    }

    public final boolean n1() {
        m mVar;
        return this.D0 || ((mVar = this.w0) != null && mVar.K0(this.z0));
    }

    void n2(boolean z) {
        O1(z);
    }

    ax.p351z0.e o0() {
        return new e();
    }

    final boolean o1() {
        return this.v0 > 0;
    }

    boolean o2(MenuItem menuItem) {
        if (this.D0) {
            return false;
        }
        if (this.H0 && this.I0 && P1(menuItem)) {
            return true;
        }
        return this.y0.J(menuItem);
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.J0 = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        B2().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.J0 = true;
    }

    @Deprecated
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
    }

    public void p0(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.A0));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.B0));
        printWriter.print(" mTag=");
        printWriter.println(this.C0);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.q);
        printWriter.print(" mWho=");
        printWriter.print(this.i0);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.v0);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.o0);
        printWriter.print(" mRemoving=");
        printWriter.print(this.p0);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.r0);
        printWriter.print(" mInLayout=");
        printWriter.println(this.s0);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.D0);
        printWriter.print(" mDetached=");
        printWriter.print(this.E0);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.I0);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.H0);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.F0);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.N0);
        if (this.w0 != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.w0);
        }
        if (this.x0 != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.x0);
        }
        if (this.z0 != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.z0);
        }
        if (this.j0 != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.j0);
        }
        if (this.X != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.X);
        }
        if (this.Y != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.Y);
        }
        if (this.Z != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.Z);
        }
        Fragment fragmentE1 = e1(false);
        if (fragmentE1 != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(fragmentE1);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.m0);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(O0());
        if (y0() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(y0());
        }
        if (B0() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(B0());
        }
        if (P0() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(P0());
        }
        if (Q0() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(Q0());
        }
        if (this.K0 != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.K0);
        }
        if (this.L0 != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.L0);
        }
        if (v0() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(v0());
        }
        if (getContext() != null) {
            ax.I0.a.c(this).b(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.y0 + ":");
        this.y0.W(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public final boolean p1() {
        m mVar;
        return this.I0 && ((mVar = this.w0) == null || mVar.L0(this.z0));
    }

    void p2(Menu menu) {
        if (this.D0) {
            return;
        }
        if (this.H0 && this.I0) {
            Q1(menu);
        }
        this.y0.K(menu);
    }

    boolean q1() {
        f fVar = this.O0;
        if (fVar == null) {
            return false;
        }
        return fVar.t;
    }

    void q2() {
        this.y0.M();
        if (this.L0 != null) {
            this.X0.a(androidx.lifecycle.d.a.ON_PAUSE);
        }
        this.W0.h(androidx.lifecycle.d.a.ON_PAUSE);
        this.q = 6;
        this.J0 = false;
        R1();
        if (this.J0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onPause()");
    }

    Fragment r0(String str) {
        return str.equals(this.i0) ? this : this.y0.j0(str);
    }

    public final boolean r1() {
        return this.p0;
    }

    void r2(boolean z) {
        S1(z);
    }

    public final androidx.fragment.app.f s0() {
        j<?> jVar = this.x0;
        if (jVar == null) {
            return null;
        }
        return (androidx.fragment.app.f) jVar.e();
    }

    public final boolean s1() {
        return this.q >= 7;
    }

    boolean s2(Menu menu) {
        boolean z = false;
        if (this.D0) {
            return false;
        }
        if (this.H0 && this.I0) {
            T1(menu);
            z = true;
        }
        return z | this.y0.O(menu);
    }

    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        V2(intent, i2, null);
    }

    public boolean t0() {
        Boolean bool;
        f fVar = this.O0;
        if (fVar == null || (bool = fVar.q) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public final boolean t1() {
        m mVar = this.w0;
        if (mVar == null) {
            return false;
        }
        return mVar.O0();
    }

    void t2() {
        boolean zM0 = this.w0.M0(this);
        Boolean bool = this.n0;
        if (bool == null || bool.booleanValue() != zM0) {
            this.n0 = Boolean.valueOf(zM0);
            U1(zM0);
            this.y0.P();
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.i0);
        if (this.A0 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.A0));
        }
        if (this.C0 != null) {
            sb.append(" tag=");
            sb.append(this.C0);
        }
        sb.append(")");
        return sb.toString();
    }

    public boolean u0() {
        Boolean bool;
        f fVar = this.O0;
        if (fVar == null || (bool = fVar.p) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    void u1() {
        this.y0.X0();
    }

    void u2() {
        this.y0.X0();
        this.y0.a0(true);
        this.q = 7;
        this.J0 = false;
        V1();
        if (!this.J0) {
            throw new B("Fragment " + this + " did not call through to super.onResume()");
        }
        androidx.lifecycle.g gVar = this.W0;
        androidx.lifecycle.d.a aVar = androidx.lifecycle.d.a.ON_RESUME;
        gVar.h(aVar);
        if (this.L0 != null) {
            this.X0.a(aVar);
        }
        this.y0.Q();
    }

    View v0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        return fVar.a;
    }

    @Deprecated
    public void v1(Bundle bundle) {
        this.J0 = true;
    }

    void v2(Bundle bundle) {
        W1(bundle);
        this.a1.e(bundle);
        Bundle bundleK1 = this.y0.P0();
        if (bundleK1 != null) {
            bundle.putParcelable("android:support:fragments", bundleK1);
        }
    }

    public final Bundle w0() {
        return this.j0;
    }

    @Deprecated
    public void w1(int i2, int i3, Intent intent) {
        if (m.H0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i2 + " resultCode: " + i3 + " data: " + intent);
        }
    }

    void w2() {
        this.y0.X0();
        this.y0.a0(true);
        this.q = 5;
        this.J0 = false;
        X1();
        if (!this.J0) {
            throw new B("Fragment " + this + " did not call through to super.onStart()");
        }
        androidx.lifecycle.g gVar = this.W0;
        androidx.lifecycle.d.a aVar = androidx.lifecycle.d.a.ON_START;
        gVar.h(aVar);
        if (this.L0 != null) {
            this.X0.a(aVar);
        }
        this.y0.R();
    }

    public final m x0() {
        if (this.x0 != null) {
            return this.y0;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    @Deprecated
    public void x1(Activity activity) {
        this.J0 = true;
    }

    void x2() {
        this.y0.T();
        if (this.L0 != null) {
            this.X0.a(androidx.lifecycle.d.a.ON_STOP);
        }
        this.W0.h(androidx.lifecycle.d.a.ON_STOP);
        this.q = 4;
        this.J0 = false;
        Y1();
        if (this.J0) {
            return;
        }
        throw new B("Fragment " + this + " did not call through to super.onStop()");
    }

    int y0() {
        f fVar = this.O0;
        if (fVar == null) {
            return 0;
        }
        return fVar.c;
    }

    public void y1(Context context) {
        this.J0 = true;
        j<?> jVar = this.x0;
        Activity activityE = jVar == null ? null : jVar.e();
        if (activityE != null) {
            this.J0 = false;
            x1(activityE);
        }
    }

    void y2() {
        Z1(this.L0, this.X);
        this.y0.U();
    }

    public Object z0() {
        f fVar = this.O0;
        if (fVar == null) {
            return null;
        }
        return fVar.j;
    }

    @Deprecated
    public void z1(Fragment fragment) {
    }
}
