package androidx.fragment.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class h {
    private final j<?> a;

    private h(j<?> jVar) {
        this.a = jVar;
    }

    public static h b(j<?> jVar) {
        return new h((j) ax.p019b0.g.h(jVar, "callbacks == null"));
    }

    public void a(Fragment fragment) {
        j<?> jVar = this.a;
        jVar.k0.m(jVar, jVar, fragment);
    }

    public void c() {
        this.a.k0.z();
    }

    public boolean d(MenuItem menuItem) {
        return this.a.k0.C(menuItem);
    }

    public void e() {
        this.a.k0.D();
    }

    public void f() {
        this.a.k0.F();
    }

    public void g() {
        this.a.k0.O();
    }

    public void h() {
        this.a.k0.S();
    }

    public void i() {
        this.a.k0.T();
    }

    public void j() {
        this.a.k0.V();
    }

    public boolean k() {
        return this.a.k0.c0(true);
    }

    public FragmentManager l() {
        return this.a.k0;
    }

    public void m() {
        this.a.k0.V0();
    }

    public View n(View view, String str, Context context, AttributeSet attributeSet) {
        return this.a.k0.x0().onCreateView(view, str, context, attributeSet);
    }
}
