package androidx.fragment.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class h {
    private final j<?> a;

    private h(j<?> jVar) {
        this.a = jVar;
    }

    public static h b(j<?> jVar) {
        return new h((j) ax.p001a0.g.h(jVar, "callbacks == null"));
    }

    public void a(Fragment fragment) {
        j<?> jVar = this.a;
        jVar.h0.m(jVar, jVar, fragment);
    }

    public void c() {
        this.a.h0.x();
    }

    public boolean d(MenuItem menuItem) {
        return this.a.h0.A(menuItem);
    }

    public void e() {
        this.a.h0.B();
    }

    public void f() {
        this.a.h0.D();
    }

    public void g() {
        this.a.h0.M();
    }

    public void h() {
        this.a.h0.Q();
    }

    public void i() {
        this.a.h0.R();
    }

    public void j() {
        this.a.h0.T();
    }

    public boolean k() {
        return this.a.h0.a0(true);
    }

    public m l() {
        return this.a.h0;
    }

    public void m() {
        this.a.h0.X0();
    }

    public View n(View view, String str, Context context, AttributeSet attributeSet) {
        return this.a.h0.v0().onCreateView(view, str, context, attributeSet);
    }
}
