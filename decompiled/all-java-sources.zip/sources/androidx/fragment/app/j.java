package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: loaded from: classes.dex */
public abstract class j<E> extends ax.A0.e {
    private final Context X;
    private final Handler Y;
    private final int Z;
    final FragmentManager k0;
    private final Activity q;

    j(Activity activity, Context context, Handler handler, int i) {
        this.k0 = new m();
        this.q = activity;
        this.X = (Context) ax.p019b0.g.h(context, "context == null");
        this.Y = (Handler) ax.p019b0.g.h(handler, "handler == null");
        this.Z = i;
    }

    j(f fVar) {
        this(fVar, fVar, new Handler(), 0);
    }

    @Override // ax.A0.e
    public View c(int i) {
        return null;
    }

    @Override // ax.A0.e
    public boolean d() {
        return true;
    }

    Activity e() {
        return this.q;
    }

    Context f() {
        return this.X;
    }

    public Handler g() {
        return this.Y;
    }

    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    public abstract E i();

    public LayoutInflater j() {
        return LayoutInflater.from(this.X);
    }

    @Deprecated
    public void k(Fragment fragment, String[] strArr, int i) {
    }

    public boolean l(String str) {
        return false;
    }

    public void m(Fragment fragment, @SuppressLint({"UnknownNullness"}) Intent intent, int i, Bundle bundle) {
        if (i != -1) {
            throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
        }
        ax.Q.b.l(this.X, intent, bundle);
    }

    @Deprecated
    public void n(Fragment fragment, @SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        if (i != -1) {
            throw new IllegalStateException("Starting intent sender with a requestCode requires a FragmentActivity host");
        }
        ax.P.b.x(this.q, intentSender, i, intent, i2, i3, i4, bundle);
    }

    public void o() {
    }
}
