package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: loaded from: classes.dex */
public abstract class j<E> extends ax.p351z0.e {
    private final Context X;
    private final Handler Y;
    private final int Z;
    final m h0;
    private final Activity q;

    j(f fVar) {
        this(fVar, fVar, new Handler(), 0);
    }

    @Override // ax.p351z0.e
    public View c(int i) {
        return null;
    }

    @Override // ax.p351z0.e
    public boolean d() {
        return true;
    }

    Activity e() {
        return this.q;
    }

    Context g() {
        return this.X;
    }

    public Handler h() {
        return this.Y;
    }

    public void i(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    public abstract E k();

    public LayoutInflater m() {
        return LayoutInflater.from(this.X);
    }

    @Deprecated
    public void n(Fragment fragment, String[] strArr, int i) {
    }

    public boolean o(String str) {
        return false;
    }

    public void p(Fragment fragment, @SuppressLint({"UnknownNullness"}) Intent intent, int i, Bundle bundle) {
        if (i != -1) {
            throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
        }
        ax.P.b.l(this.X, intent, bundle);
    }

    public void t() {
    }

    j(Activity activity, Context context, Handler handler, int i) {
        this.h0 = new n();
        this.q = activity;
        this.X = (Context) ax.p001a0.g.h(context, "context == null");
        this.Y = (Handler) ax.p001a0.g.h(handler, "handler == null");
        this.Z = i;
    }
}
