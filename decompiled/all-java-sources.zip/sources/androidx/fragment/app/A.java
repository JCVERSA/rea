package androidx.fragment.app;

import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
interface A {
    z a(ViewGroup viewGroup);
}
