package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
class n extends m {
    n() {
    }
}
