package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class n implements Parcelable {
    public static final Parcelable.Creator<n> CREATOR = new a();
    ArrayList<String> X;
    C0607b[] Y;
    int Z;
    String k0;
    ArrayList<String> l0;
    ArrayList<c> m0;
    ArrayList<FragmentManager.k> n0;
    ArrayList<String> q;

    class a implements Parcelable.Creator<n> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public n createFromParcel(Parcel parcel) {
            return new n(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public n[] newArray(int i) {
            return new n[i];
        }
    }

    public n() {
        this.k0 = null;
        this.l0 = new ArrayList<>();
        this.m0 = new ArrayList<>();
    }

    public n(Parcel parcel) {
        this.k0 = null;
        this.l0 = new ArrayList<>();
        this.m0 = new ArrayList<>();
        this.q = parcel.createStringArrayList();
        this.X = parcel.createStringArrayList();
        this.Y = (C0607b[]) parcel.createTypedArray(C0607b.CREATOR);
        this.Z = parcel.readInt();
        this.k0 = parcel.readString();
        this.l0 = parcel.createStringArrayList();
        this.m0 = parcel.createTypedArrayList(c.CREATOR);
        this.n0 = parcel.createTypedArrayList(FragmentManager.k.CREATOR);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.q);
        parcel.writeStringList(this.X);
        parcel.writeTypedArray(this.Y, i);
        parcel.writeInt(this.Z);
        parcel.writeString(this.k0);
        parcel.writeStringList(this.l0);
        parcel.writeTypedList(this.m0);
        parcel.writeTypedList(this.n0);
    }
}
