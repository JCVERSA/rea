package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import ax.p015b0.InterfaceC5252x;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: loaded from: classes.dex */
public class f extends ComponentActivity implements ax.O.b.e, ax.O.b.f {
    boolean A0;
    boolean z0;
    final h x0 = h.b(new a());
    final androidx.lifecycle.g y0 = new androidx.lifecycle.g(this);
    boolean B0 = true;

    class a extends j<f> implements ax.P.e, ax.P.f, ax.O.q, ax.O.r, ax.F0.t, ax.p112i.p, ax.p140k.d, ax.p016b1.d, ax.p351z0.k, InterfaceC5252x {
        public a() {
            super(f.this);
        }

        @Override // ax.O.r
        public void B(ax.p001a0.a<ax.O.t> aVar) {
            f.this.B(aVar);
        }

        @Override // ax.F0.t
        public androidx.lifecycle.q J() {
            return f.this.J();
        }

        @Override // ax.O.q
        public void K(ax.p001a0.a<ax.O.i> aVar) {
            f.this.K(aVar);
        }

        @Override // ax.O.r
        public void L(ax.p001a0.a<ax.O.t> aVar) {
            f.this.L(aVar);
        }

        @Override // ax.O.q
        public void N(ax.p001a0.a<ax.O.i> aVar) {
            f.this.N(aVar);
        }

        @Override // ax.P.e
        public void Q(ax.p001a0.a<Configuration> aVar) {
            f.this.Q(aVar);
        }

        @Override // ax.p016b1.d
        public androidx.savedstate.a R() {
            return f.this.R();
        }

        @Override // ax.P.f
        public void W(ax.p001a0.a<Integer> aVar) {
            f.this.W(aVar);
        }

        @Override // ax.P.f
        public void X(ax.p001a0.a<Integer> aVar) {
            f.this.X(aVar);
        }

        @Override // ax.p351z0.k
        public void a(m mVar, Fragment fragment) {
            f.this.E0(fragment);
        }

        @Override // androidx.fragment.app.j, ax.p351z0.e
        public View c(int i) {
            return f.this.findViewById(i);
        }

        @Override // androidx.fragment.app.j, ax.p351z0.e
        public boolean d() {
            Window window = f.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        @Override // ax.F0.g
        public androidx.lifecycle.d f() {
            return f.this.y0;
        }

        @Override // androidx.fragment.app.j
        public void i(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            f.this.dump(str, fileDescriptor, printWriter, strArr);
        }

        @Override // ax.p015b0.InterfaceC5252x
        public void j(ax.p015b0.A a) {
            f.this.j(a);
        }

        @Override // ax.P.e
        public void l(ax.p001a0.a<Configuration> aVar) {
            f.this.l(aVar);
        }

        @Override // androidx.fragment.app.j
        public LayoutInflater m() {
            return f.this.getLayoutInflater().cloneInContext(f.this);
        }

        @Override // androidx.fragment.app.j
        public boolean o(String str) {
            return ax.O.b.s(f.this, str);
        }

        @Override // ax.p112i.p
        public OnBackPressedDispatcher q() {
            return f.this.q();
        }

        @Override // ax.p140k.d
        public ActivityResultRegistry r() {
            return f.this.r();
        }

        @Override // ax.p015b0.InterfaceC5252x
        public void s(ax.p015b0.A a) {
            f.this.s(a);
        }

        @Override // androidx.fragment.app.j
        public void t() {
            u();
        }

        public void u() {
            f.this.l0();
        }

        @Override // androidx.fragment.app.j
        /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
        public f k() {
            return f.this;
        }
    }

    public f() {
        x0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A0(Intent intent) {
        this.x0.m();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B0(Context context) {
        this.x0.a(null);
    }

    private static boolean D0(m mVar, androidx.lifecycle.d.b bVar) {
        boolean zD0 = false;
        for (Fragment fragment : mVar.t0()) {
            if (fragment != null) {
                if (fragment.G0() != null) {
                    zD0 |= D0(fragment.x0(), bVar);
                }
                x xVar = fragment.X0;
                if (xVar != null && xVar.f().b().h(androidx.lifecycle.d.b.STARTED)) {
                    fragment.X0.g(bVar);
                    zD0 = true;
                }
                if (fragment.W0.b().h(androidx.lifecycle.d.b.STARTED)) {
                    fragment.W0.m(bVar);
                    zD0 = true;
                }
            }
        }
        return zD0;
    }

    private void x0() {
        R().h("android:support:lifecycle", new androidx.savedstate.a.c() { // from class: ax.z0.a
            @Override // androidx.savedstate.a.c
            public final Bundle a() {
                return this.a.y0();
            }
        });
        Q(new ax.p001a0.a() { // from class: ax.z0.b
            @Override // ax.p001a0.a
            public final void a(Object obj) {
                this.a.z0((Configuration) obj);
            }
        });
        h0(new ax.p001a0.a() { // from class: ax.z0.c
            @Override // ax.p001a0.a
            public final void a(Object obj) {
                this.a.A0((Intent) obj);
            }
        });
        g0(new ax.p126j.b() { // from class: ax.z0.d
            @Override // ax.p126j.b
            public final void a(Context context) {
                this.a.B0(context);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Bundle y0() {
        C0();
        this.y0.h(androidx.lifecycle.d.a.ON_STOP);
        return new Bundle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z0(Configuration configuration) {
        this.x0.m();
    }

    void C0() {
        while (D0(w(), androidx.lifecycle.d.b.CREATED)) {
        }
    }

    @Deprecated
    public void E0(Fragment fragment) {
    }

    protected void F0() {
        this.y0.h(androidx.lifecycle.d.a.ON_RESUME);
        this.x0.h();
    }

    @Deprecated
    public void G0() {
        l0();
    }

    @Override // ax.O.b.f
    @Deprecated
    public final void b(int i) {
    }

    @Override // android.app.Activity
    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (Y(strArr)) {
            printWriter.print(str);
            printWriter.print("Local FragmentActivity ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this)));
            printWriter.println(" State:");
            String str2 = str + "  ";
            printWriter.print(str2);
            printWriter.print("mCreated=");
            printWriter.print(this.z0);
            printWriter.print(" mResumed=");
            printWriter.print(this.A0);
            printWriter.print(" mStopped=");
            printWriter.print(this.B0);
            if (getApplication() != null) {
                ax.I0.a.c(this).b(str2, fileDescriptor, printWriter, strArr);
            }
            this.x0.l().W(str, fileDescriptor, printWriter, strArr);
        }
    }

    @Deprecated
    public ax.I0.a g() {
        return ax.I0.a.c(this);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        this.x0.m();
        super.onActivityResult(i, i2, intent);
    }

    @Override // androidx.activity.ComponentActivity, ax.O.h, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.y0.h(androidx.lifecycle.d.a.ON_CREATE);
        this.x0.e();
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewW0 = w0(view, str, context, attributeSet);
        return viewW0 == null ? super.onCreateView(view, str, context, attributeSet) : viewW0;
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.x0.f();
        this.y0.h(androidx.lifecycle.d.a.ON_DESTROY);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 6) {
            return this.x0.d(menuItem);
        }
        return false;
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        this.A0 = false;
        this.x0.g();
        this.y0.h(androidx.lifecycle.d.a.ON_PAUSE);
    }

    @Override // android.app.Activity
    protected void onPostResume() {
        super.onPostResume();
        F0();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.x0.m();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // android.app.Activity
    protected void onResume() {
        this.x0.m();
        super.onResume();
        this.A0 = true;
        this.x0.k();
    }

    @Override // android.app.Activity
    protected void onStart() {
        this.x0.m();
        super.onStart();
        this.B0 = false;
        if (!this.z0) {
            this.z0 = true;
            this.x0.c();
        }
        this.x0.k();
        this.y0.h(androidx.lifecycle.d.a.ON_START);
        this.x0.i();
    }

    @Override // android.app.Activity
    public void onStateNotSaved() {
        this.x0.m();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        this.B0 = true;
        C0();
        this.x0.j();
        this.y0.h(androidx.lifecycle.d.a.ON_STOP);
    }

    public m w() {
        return this.x0.l();
    }

    final View w0(View view, String str, Context context, AttributeSet attributeSet) {
        return this.x0.n(view, str, context, attributeSet);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewW0 = w0(null, str, context, attributeSet);
        return viewW0 == null ? super.onCreateView(str, context, attributeSet) : viewW0;
    }
}
