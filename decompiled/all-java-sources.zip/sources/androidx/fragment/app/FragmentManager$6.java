package androidx.fragment.app;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
class FragmentManager$6 implements androidx.lifecycle.f {
    final /* synthetic */ androidx.lifecycle.d X;
    final /* synthetic */ m Y;
    final /* synthetic */ String q;

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
        if (aVar == androidx.lifecycle.d.a.ON_START && ((Bundle) this.Y.k.get(this.q)) != null) {
            throw null;
        }
        if (aVar == androidx.lifecycle.d.a.ON_DESTROY) {
            this.X.c(this);
            this.Y.l.remove(this.q);
        }
    }
}
