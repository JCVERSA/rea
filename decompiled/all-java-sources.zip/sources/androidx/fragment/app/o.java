package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class o implements Parcelable {
    public static final Parcelable.Creator<o> CREATOR = new a();
    ArrayList<String> X;
    C0564b[] Y;
    int Z;
    String h0;
    ArrayList<String> i0;
    ArrayList<c> j0;
    ArrayList<m.k> k0;
    ArrayList<String> q;

    class a implements Parcelable.Creator<o> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public o createFromParcel(Parcel parcel) {
            return new o(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public o[] newArray(int i) {
            return new o[i];
        }
    }

    public o() {
        this.h0 = null;
        this.i0 = new ArrayList<>();
        this.j0 = new ArrayList<>();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.q);
        parcel.writeStringList(this.X);
        parcel.writeTypedArray(this.Y, i);
        parcel.writeInt(this.Z);
        parcel.writeString(this.h0);
        parcel.writeStringList(this.i0);
        parcel.writeTypedList(this.j0);
        parcel.writeTypedList(this.k0);
    }

    public o(Parcel parcel) {
        this.h0 = null;
        this.i0 = new ArrayList<>();
        this.j0 = new ArrayList<>();
        this.q = parcel.createStringArrayList();
        this.X = parcel.createStringArrayList();
        this.Y = (C0564b[]) parcel.createTypedArray(C0564b.CREATOR);
        this.Z = parcel.readInt();
        this.h0 = parcel.readString();
        this.i0 = parcel.createStringArrayList();
        this.j0 = parcel.createTypedArrayList(c.CREATOR);
        this.k0 = parcel.createTypedArrayList(m.k.CREATOR);
    }
}
