package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
class l {
    private final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<>();
    private final m b;

    private static final class a {
        final boolean a;
    }

    l(m mVar) {
        this.b = mVar;
    }

    void a(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().a(fragment, bundle, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void b(Fragment fragment, boolean z) {
        this.b.u0().g();
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().b(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void c(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().c(fragment, bundle, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void d(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().d(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void e(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().e(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void f(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().f(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void g(Fragment fragment, boolean z) {
        this.b.u0().g();
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().g(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void h(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().h(fragment, bundle, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void i(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().i(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void j(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().j(fragment, bundle, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void k(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().k(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void l(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().l(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void m(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().m(fragment, view, bundle, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }

    void n(Fragment fragment, boolean z) {
        Fragment fragmentX0 = this.b.x0();
        if (fragmentX0 != null) {
            fragmentX0.N0().w0().n(fragment, true);
        }
        for (a aVar : this.a) {
            if (!z || aVar.a) {
                aVar.getClass();
                throw null;
            }
        }
    }
}
