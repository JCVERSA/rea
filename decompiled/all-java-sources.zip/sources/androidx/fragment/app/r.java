package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import ax.p035c0.C1839d0;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
class r {
    private final l a;
    private final s b;
    private final Fragment c;
    private boolean d = false;
    private int e = -1;

    class a implements View.OnAttachStateChangeListener {
        final /* synthetic */ View q;

        a(View view) {
            this.q = view;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            this.q.removeOnAttachStateChangeListener(this);
            C1839d0.i0(this.q);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    static /* synthetic */ class b {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[androidx.lifecycle.d.b.values().length];
            a = iArr;
            try {
                iArr[androidx.lifecycle.d.b.RESUMED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[androidx.lifecycle.d.b.STARTED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[androidx.lifecycle.d.b.CREATED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[androidx.lifecycle.d.b.INITIALIZED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    r(l lVar, s sVar, Fragment fragment) {
        this.a = lVar;
        this.b = sVar;
        this.c = fragment;
    }

    r(l lVar, s sVar, Fragment fragment, p pVar) {
        this.a = lVar;
        this.b = sVar;
        this.c = fragment;
        fragment.Y = null;
        fragment.Z = null;
        fragment.y0 = 0;
        fragment.v0 = false;
        fragment.r0 = false;
        Fragment fragment2 = fragment.n0;
        fragment.o0 = fragment2 != null ? fragment2.l0 : null;
        fragment.n0 = null;
        Bundle bundle = pVar.s0;
        if (bundle != null) {
            fragment.X = bundle;
        } else {
            fragment.X = new Bundle();
        }
    }

    r(l lVar, s sVar, ClassLoader classLoader, i iVar, p pVar) {
        this.a = lVar;
        this.b = sVar;
        Fragment fragmentA = pVar.a(iVar, classLoader);
        this.c = fragmentA;
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + fragmentA);
        }
    }

    private boolean l(View view) {
        if (view == this.c.O0) {
            return true;
        }
        for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            if (parent == this.c.O0) {
                return true;
            }
        }
        return false;
    }

    private Bundle q() {
        Bundle bundle = new Bundle();
        this.c.r2(bundle);
        this.a.j(this.c, bundle, false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (this.c.O0 != null) {
            s();
        }
        if (this.c.Y != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", this.c.Y);
        }
        if (this.c.Z != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", this.c.Z);
        }
        if (!this.c.Q0) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", this.c.Q0);
        }
        return bundle;
    }

    void a() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        fragment.X1(fragment.X);
        l lVar = this.a;
        Fragment fragment2 = this.c;
        lVar.a(fragment2, fragment2.X, false);
    }

    void b() {
        int iJ = this.b.j(this.c);
        Fragment fragment = this.c;
        fragment.N0.addView(fragment.O0, iJ);
    }

    void c() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto ATTACHED: " + this.c);
        }
        Fragment fragment = this.c;
        Fragment fragment2 = fragment.n0;
        r rVarN = null;
        if (fragment2 != null) {
            r rVarN2 = this.b.n(fragment2.l0);
            if (rVarN2 == null) {
                throw new IllegalStateException("Fragment " + this.c + " declared target fragment " + this.c.n0 + " that does not belong to this FragmentManager!");
            }
            Fragment fragment3 = this.c;
            fragment3.o0 = fragment3.n0.l0;
            fragment3.n0 = null;
            rVarN = rVarN2;
        } else {
            String str = fragment.o0;
            if (str != null && (rVarN = this.b.n(str)) == null) {
                throw new IllegalStateException("Fragment " + this.c + " declared target fragment " + this.c.o0 + " that does not belong to this FragmentManager!");
            }
        }
        if (rVarN != null) {
            rVarN.m();
        }
        Fragment fragment4 = this.c;
        fragment4.A0 = fragment4.z0.w0();
        Fragment fragment5 = this.c;
        fragment5.C0 = fragment5.z0.z0();
        this.a.g(this.c, false);
        this.c.Y1();
        this.a.b(this.c, false);
    }

    int d() {
        Fragment fragment = this.c;
        if (fragment.z0 == null) {
            return fragment.q;
        }
        int iMin = this.e;
        int i = b.a[fragment.Y0.ordinal()];
        if (i != 1) {
            if (i == 2) {
                iMin = Math.min(iMin, 5);
            } else if (i != 3) {
                iMin = i != 4 ? Math.min(iMin, -1) : Math.min(iMin, 0);
            } else {
                iMin = Math.min(iMin, 1);
            }
        }
        Fragment fragment2 = this.c;
        if (fragment2.u0) {
            if (fragment2.v0) {
                iMin = Math.max(this.e, 2);
                View view = this.c.O0;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = this.e < 4 ? Math.min(iMin, fragment2.q) : Math.min(iMin, 1);
            }
        }
        if (!this.c.r0) {
            iMin = Math.min(iMin, 1);
        }
        Fragment fragment3 = this.c;
        ViewGroup viewGroup = fragment3.N0;
        z.e.b bVarL = viewGroup != null ? z.n(viewGroup, fragment3.J0()).l(this) : null;
        if (bVarL == z.e.b.ADDING) {
            iMin = Math.min(iMin, 6);
        } else if (bVarL == z.e.b.REMOVING) {
            iMin = Math.max(iMin, 3);
        } else {
            Fragment fragment4 = this.c;
            if (fragment4.s0) {
                iMin = fragment4.k1() ? Math.min(iMin, 1) : Math.min(iMin, -1);
            }
        }
        Fragment fragment5 = this.c;
        if (fragment5.P0 && fragment5.q < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + iMin + " for " + this.c);
        }
        return iMin;
    }

    void e() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        if (fragment.W0) {
            fragment.B2(fragment.X);
            this.c.q = 1;
            return;
        }
        this.a.h(fragment, fragment.X, false);
        Fragment fragment2 = this.c;
        fragment2.b2(fragment2.X);
        l lVar = this.a;
        Fragment fragment3 = this.c;
        lVar.c(fragment3, fragment3.X, false);
    }

    void f() {
        String resourceName;
        if (this.c.u0) {
            return;
        }
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.c);
        }
        Fragment fragment = this.c;
        LayoutInflater layoutInflaterH2 = fragment.h2(fragment.X);
        Fragment fragment2 = this.c;
        ViewGroup viewGroup = fragment2.N0;
        if (viewGroup == null) {
            int i = fragment2.E0;
            if (i == 0) {
                viewGroup = null;
            } else {
                if (i == -1) {
                    throw new IllegalArgumentException("Cannot create fragment " + this.c + " for a container view with no id");
                }
                viewGroup = (ViewGroup) fragment2.z0.s0().c(this.c.E0);
                if (viewGroup == null) {
                    Fragment fragment3 = this.c;
                    if (!fragment3.w0) {
                        try {
                            resourceName = fragment3.P0().getResourceName(this.c.E0);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(this.c.E0) + " (" + resourceName + ") for fragment " + this.c);
                    }
                } else if (!(viewGroup instanceof FragmentContainerView)) {
                    ax.B0.c.j(this.c, viewGroup);
                }
            }
        }
        Fragment fragment4 = this.c;
        fragment4.N0 = viewGroup;
        fragment4.d2(layoutInflaterH2, viewGroup, fragment4.X);
        View view = this.c.O0;
        if (view != null) {
            view.setSaveFromParentEnabled(false);
            Fragment fragment5 = this.c;
            fragment5.O0.setTag(ax.p403z0.b.a, fragment5);
            if (viewGroup != null) {
                b();
            }
            Fragment fragment6 = this.c;
            if (fragment6.G0) {
                fragment6.O0.setVisibility(8);
            }
            if (C1839d0.Q(this.c.O0)) {
                C1839d0.i0(this.c.O0);
            } else {
                View view2 = this.c.O0;
                view2.addOnAttachStateChangeListener(new a(view2));
            }
            this.c.u2();
            l lVar = this.a;
            Fragment fragment7 = this.c;
            lVar.m(fragment7, fragment7.O0, fragment7.X, false);
            int visibility = this.c.O0.getVisibility();
            this.c.L2(this.c.O0.getAlpha());
            Fragment fragment8 = this.c;
            if (fragment8.N0 != null && visibility == 0) {
                View viewFindFocus = fragment8.O0.findFocus();
                if (viewFindFocus != null) {
                    this.c.G2(viewFindFocus);
                    if (FragmentManager.J0(2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + this.c);
                    }
                }
                this.c.O0.setAlpha(0.0f);
            }
        }
        this.c.q = 2;
    }

    void g() {
        Fragment fragmentF;
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "movefrom CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        boolean zIsChangingConfigurations = true;
        boolean z = fragment.s0 && !fragment.k1();
        if (z) {
            Fragment fragment2 = this.c;
            if (!fragment2.t0) {
                this.b.B(fragment2.l0, null);
            }
        }
        if (!z && !this.b.p().r(this.c)) {
            String str = this.c.o0;
            if (str != null && (fragmentF = this.b.f(str)) != null && fragmentF.I0) {
                this.c.n0 = fragmentF;
            }
            this.c.q = 0;
            return;
        }
        j<?> jVar = this.c.A0;
        if (jVar instanceof ax.G0.v) {
            zIsChangingConfigurations = this.b.p().o();
        } else if (jVar.f() instanceof Activity) {
            zIsChangingConfigurations = true ^ ((Activity) jVar.f()).isChangingConfigurations();
        }
        if ((z && !this.c.t0) || zIsChangingConfigurations) {
            this.b.p().g(this.c);
        }
        this.c.e2();
        this.a.d(this.c, false);
        for (r rVar : this.b.k()) {
            if (rVar != null) {
                Fragment fragmentK = rVar.k();
                if (this.c.l0.equals(fragmentK.o0)) {
                    fragmentK.n0 = this.c;
                    fragmentK.o0 = null;
                }
            }
        }
        Fragment fragment3 = this.c;
        String str2 = fragment3.o0;
        if (str2 != null) {
            fragment3.n0 = this.b.f(str2);
        }
        this.b.s(this);
    }

    void h() {
        View view;
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + this.c);
        }
        Fragment fragment = this.c;
        ViewGroup viewGroup = fragment.N0;
        if (viewGroup != null && (view = fragment.O0) != null) {
            viewGroup.removeView(view);
        }
        this.c.f2();
        this.a.n(this.c, false);
        Fragment fragment2 = this.c;
        fragment2.N0 = null;
        fragment2.O0 = null;
        fragment2.a1 = null;
        fragment2.b1.n(null);
        this.c.v0 = false;
    }

    void i() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + this.c);
        }
        this.c.g2();
        this.a.e(this.c, false);
        Fragment fragment = this.c;
        fragment.q = -1;
        fragment.A0 = null;
        fragment.C0 = null;
        fragment.z0 = null;
        if ((!fragment.s0 || fragment.k1()) && !this.b.p().r(this.c)) {
            return;
        }
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "initState called for fragment: " + this.c);
        }
        this.c.f1();
    }

    void j() {
        Fragment fragment = this.c;
        if (fragment.u0 && fragment.v0 && !fragment.x0) {
            if (FragmentManager.J0(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.c);
            }
            Fragment fragment2 = this.c;
            fragment2.d2(fragment2.h2(fragment2.X), null, this.c.X);
            View view = this.c.O0;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.c;
                fragment3.O0.setTag(ax.p403z0.b.a, fragment3);
                Fragment fragment4 = this.c;
                if (fragment4.G0) {
                    fragment4.O0.setVisibility(8);
                }
                this.c.u2();
                l lVar = this.a;
                Fragment fragment5 = this.c;
                lVar.m(fragment5, fragment5.O0, fragment5.X, false);
                this.c.q = 2;
            }
        }
    }

    Fragment k() {
        return this.c;
    }

    void m() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        if (this.d) {
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + k());
                return;
            }
            return;
        }
        try {
            this.d = true;
            boolean z = false;
            while (true) {
                int iD = d();
                Fragment fragment = this.c;
                int i = fragment.q;
                if (iD == i) {
                    if (!z && i == -1 && fragment.s0 && !fragment.k1() && !this.c.t0) {
                        if (FragmentManager.J0(3)) {
                            Log.d("FragmentManager", "Cleaning up state of never attached fragment: " + this.c);
                        }
                        this.b.p().g(this.c);
                        this.b.s(this);
                        if (FragmentManager.J0(3)) {
                            Log.d("FragmentManager", "initState called for fragment: " + this.c);
                        }
                        this.c.f1();
                    }
                    Fragment fragment2 = this.c;
                    if (fragment2.U0) {
                        if (fragment2.O0 != null && (viewGroup = fragment2.N0) != null) {
                            z zVarN = z.n(viewGroup, fragment2.J0());
                            if (this.c.G0) {
                                zVarN.c(this);
                            } else {
                                zVarN.e(this);
                            }
                        }
                        Fragment fragment3 = this.c;
                        FragmentManager fragmentManager = fragment3.z0;
                        if (fragmentManager != null) {
                            fragmentManager.H0(fragment3);
                        }
                        Fragment fragment4 = this.c;
                        fragment4.U0 = false;
                        fragment4.H1(fragment4.G0);
                        this.c.B0.K();
                    }
                    return;
                }
                if (iD <= i) {
                    switch (i - 1) {
                        case SubsamplingScaleImageView.ORIENTATION_USE_EXIF /* -1 */:
                            i();
                            break;
                        case 0:
                            if (fragment.t0 && this.b.q(fragment.l0) == null) {
                                r();
                            }
                            g();
                            break;
                        case 1:
                            h();
                            this.c.q = 1;
                            break;
                        case 2:
                            fragment.v0 = false;
                            fragment.q = 2;
                            break;
                        case 3:
                            if (FragmentManager.J0(3)) {
                                Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + this.c);
                            }
                            Fragment fragment5 = this.c;
                            if (fragment5.t0) {
                                r();
                            } else if (fragment5.O0 != null && fragment5.Y == null) {
                                s();
                            }
                            Fragment fragment6 = this.c;
                            if (fragment6.O0 != null && (viewGroup2 = fragment6.N0) != null) {
                                z.n(viewGroup2, fragment6.J0()).d(this);
                            }
                            this.c.q = 3;
                            break;
                        case 4:
                            v();
                            break;
                        case 5:
                            fragment.q = 5;
                            break;
                        case 6:
                            n();
                            break;
                    }
                } else {
                    switch (i + 1) {
                        case 0:
                            c();
                            break;
                        case 1:
                            e();
                            break;
                        case 2:
                            j();
                            f();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            if (fragment.O0 != null && (viewGroup3 = fragment.N0) != null) {
                                z.n(viewGroup3, fragment.J0()).b(z.e.c.h(this.c.O0.getVisibility()), this);
                            }
                            this.c.q = 4;
                            break;
                        case 5:
                            u();
                            break;
                        case 6:
                            fragment.q = 6;
                            break;
                        case 7:
                            p();
                            break;
                    }
                }
                z = true;
            }
        } finally {
            this.d = false;
        }
    }

    void n() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "movefrom RESUMED: " + this.c);
        }
        this.c.m2();
        this.a.f(this.c, false);
    }

    void o(ClassLoader classLoader) {
        Bundle bundle = this.c.X;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        Fragment fragment = this.c;
        fragment.Y = fragment.X.getSparseParcelableArray("android:view_state");
        Fragment fragment2 = this.c;
        fragment2.Z = fragment2.X.getBundle("android:view_registry_state");
        Fragment fragment3 = this.c;
        fragment3.o0 = fragment3.X.getString("android:target_state");
        Fragment fragment4 = this.c;
        if (fragment4.o0 != null) {
            fragment4.p0 = fragment4.X.getInt("android:target_req_state", 0);
        }
        Fragment fragment5 = this.c;
        Boolean bool = fragment5.k0;
        if (bool != null) {
            fragment5.Q0 = bool.booleanValue();
            this.c.k0 = null;
        } else {
            fragment5.Q0 = fragment5.X.getBoolean("android:user_visible_hint", true);
        }
        Fragment fragment6 = this.c;
        if (fragment6.Q0) {
            return;
        }
        fragment6.P0 = true;
    }

    void p() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto RESUMED: " + this.c);
        }
        View viewA0 = this.c.A0();
        if (viewA0 != null && l(viewA0)) {
            boolean zRequestFocus = viewA0.requestFocus();
            if (FragmentManager.J0(2)) {
                StringBuilder sb = new StringBuilder();
                sb.append("requestFocus: Restoring focused view ");
                sb.append(viewA0);
                sb.append(" ");
                sb.append(zRequestFocus ? "succeeded" : "failed");
                sb.append(" on Fragment ");
                sb.append(this.c);
                sb.append(" resulting in focused view ");
                sb.append(this.c.O0.findFocus());
                Log.v("FragmentManager", sb.toString());
            }
        }
        this.c.G2(null);
        this.c.q2();
        this.a.i(this.c, false);
        Fragment fragment = this.c;
        fragment.X = null;
        fragment.Y = null;
        fragment.Z = null;
    }

    void r() {
        p pVar = new p(this.c);
        Fragment fragment = this.c;
        if (fragment.q <= -1 || pVar.s0 != null) {
            pVar.s0 = fragment.X;
        } else {
            Bundle bundleQ = q();
            pVar.s0 = bundleQ;
            if (this.c.o0 != null) {
                if (bundleQ == null) {
                    pVar.s0 = new Bundle();
                }
                pVar.s0.putString("android:target_state", this.c.o0);
                int i = this.c.p0;
                if (i != 0) {
                    pVar.s0.putInt("android:target_req_state", i);
                }
            }
        }
        this.b.B(this.c.l0, pVar);
    }

    void s() {
        if (this.c.O0 == null) {
            return;
        }
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "Saving view state for fragment " + this.c + " with view " + this.c.O0);
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        this.c.O0.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            this.c.Y = sparseArray;
        }
        Bundle bundle = new Bundle();
        this.c.a1.e(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        this.c.Z = bundle;
    }

    void t(int i) {
        this.e = i;
    }

    void u() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "moveto STARTED: " + this.c);
        }
        this.c.s2();
        this.a.k(this.c, false);
    }

    void v() {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "movefrom STARTED: " + this.c);
        }
        this.c.t2();
        this.a.l(this.c, false);
    }
}
