package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import ax.p015b0.Y;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
class r {
    private final l a;
    private final s b;
    private final Fragment c;
    private boolean d = false;
    private int e = -1;

    class a implements View.OnAttachStateChangeListener {
        final /* synthetic */ View q;

        a(View view) {
            this.q = view;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            this.q.removeOnAttachStateChangeListener(this);
            Y.n0(this.q);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    static /* synthetic */ class b {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[androidx.lifecycle.d.b.values().length];
            a = iArr;
            try {
                iArr[androidx.lifecycle.d.b.RESUMED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[androidx.lifecycle.d.b.STARTED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[androidx.lifecycle.d.b.CREATED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[androidx.lifecycle.d.b.INITIALIZED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    r(l lVar, s sVar, Fragment fragment) {
        this.a = lVar;
        this.b = sVar;
        this.c = fragment;
    }

    private boolean l(View view) {
        if (view == this.c.L0) {
            return true;
        }
        for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            if (parent == this.c.L0) {
                return true;
            }
        }
        return false;
    }

    private Bundle q() {
        Bundle bundle = new Bundle();
        this.c.v2(bundle);
        this.a.j(this.c, bundle, false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (this.c.L0 != null) {
            s();
        }
        if (this.c.Y != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", this.c.Y);
        }
        if (this.c.Z != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", this.c.Z);
        }
        if (!this.c.N0) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", this.c.N0);
        }
        return bundle;
    }

    void a() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        fragment.b2(fragment.X);
        l lVar = this.a;
        Fragment fragment2 = this.c;
        lVar.a(fragment2, fragment2.X, false);
    }

    void b() {
        int iJ = this.b.j(this.c);
        Fragment fragment = this.c;
        fragment.K0.addView(fragment.L0, iJ);
    }

    void c() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto ATTACHED: " + this.c);
        }
        Fragment fragment = this.c;
        Fragment fragment2 = fragment.k0;
        r rVarN = null;
        if (fragment2 != null) {
            r rVarN2 = this.b.n(fragment2.i0);
            if (rVarN2 == null) {
                throw new IllegalStateException("Fragment " + this.c + " declared target fragment " + this.c.k0 + " that does not belong to this FragmentManager!");
            }
            Fragment fragment3 = this.c;
            fragment3.l0 = fragment3.k0.i0;
            fragment3.k0 = null;
            rVarN = rVarN2;
        } else {
            String str = fragment.l0;
            if (str != null && (rVarN = this.b.n(str)) == null) {
                throw new IllegalStateException("Fragment " + this.c + " declared target fragment " + this.c.l0 + " that does not belong to this FragmentManager!");
            }
        }
        if (rVarN != null) {
            rVarN.m();
        }
        Fragment fragment4 = this.c;
        fragment4.x0 = fragment4.w0.u0();
        Fragment fragment5 = this.c;
        fragment5.z0 = fragment5.w0.x0();
        this.a.g(this.c, false);
        this.c.c2();
        this.a.b(this.c, false);
    }

    int d() {
        Fragment fragment = this.c;
        if (fragment.w0 == null) {
            return fragment.q;
        }
        int iMin = this.e;
        int i = b.a[fragment.V0.ordinal()];
        if (i != 1) {
            if (i == 2) {
                iMin = Math.min(iMin, 5);
            } else if (i != 3) {
                iMin = i != 4 ? Math.min(iMin, -1) : Math.min(iMin, 0);
            } else {
                iMin = Math.min(iMin, 1);
            }
        }
        Fragment fragment2 = this.c;
        if (fragment2.r0) {
            if (fragment2.s0) {
                iMin = Math.max(this.e, 2);
                View view = this.c.L0;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = this.e < 4 ? Math.min(iMin, fragment2.q) : Math.min(iMin, 1);
            }
        }
        if (!this.c.o0) {
            iMin = Math.min(iMin, 1);
        }
        Fragment fragment3 = this.c;
        ViewGroup viewGroup = fragment3.K0;
        z.e.b bVarL = viewGroup != null ? z.n(viewGroup, fragment3.N0()).l(this) : null;
        if (bVarL == z.e.b.ADDING) {
            iMin = Math.min(iMin, 6);
        } else if (bVarL == z.e.b.REMOVING) {
            iMin = Math.max(iMin, 3);
        } else {
            Fragment fragment4 = this.c;
            if (fragment4.p0) {
                iMin = fragment4.o1() ? Math.min(iMin, 1) : Math.min(iMin, -1);
            }
        }
        Fragment fragment5 = this.c;
        if (fragment5.M0 && fragment5.q < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (m.H0(2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + iMin + " for " + this.c);
        }
        return iMin;
    }

    void e() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        if (fragment.T0) {
            fragment.F2(fragment.X);
            this.c.q = 1;
            return;
        }
        this.a.h(fragment, fragment.X, false);
        Fragment fragment2 = this.c;
        fragment2.f2(fragment2.X);
        l lVar = this.a;
        Fragment fragment3 = this.c;
        lVar.c(fragment3, fragment3.X, false);
    }

    void f() {
        String resourceName;
        if (this.c.r0) {
            return;
        }
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.c);
        }
        Fragment fragment = this.c;
        LayoutInflater layoutInflaterL2 = fragment.l2(fragment.X);
        Fragment fragment2 = this.c;
        ViewGroup viewGroup = fragment2.K0;
        if (viewGroup == null) {
            int i = fragment2.B0;
            if (i == 0) {
                viewGroup = null;
            } else {
                if (i == -1) {
                    throw new IllegalArgumentException("Cannot create fragment " + this.c + " for a container view with no id");
                }
                viewGroup = (ViewGroup) fragment2.w0.q0().c(this.c.B0);
                if (viewGroup == null) {
                    Fragment fragment3 = this.c;
                    if (!fragment3.t0) {
                        try {
                            resourceName = fragment3.T0().getResourceName(this.c.B0);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(this.c.B0) + " (" + resourceName + ") for fragment " + this.c);
                    }
                } else if (!(viewGroup instanceof FragmentContainerView)) {
                    ax.A0.c.k(this.c, viewGroup);
                }
            }
        }
        Fragment fragment4 = this.c;
        fragment4.K0 = viewGroup;
        fragment4.h2(layoutInflaterL2, viewGroup, fragment4.X);
        View view = this.c.L0;
        if (view != null) {
            view.setSaveFromParentEnabled(false);
            Fragment fragment5 = this.c;
            fragment5.L0.setTag(ax.p337y0.b.a, fragment5);
            if (viewGroup != null) {
                b();
            }
            Fragment fragment6 = this.c;
            if (fragment6.D0) {
                fragment6.L0.setVisibility(8);
            }
            if (Y.T(this.c.L0)) {
                Y.n0(this.c.L0);
            } else {
                View view2 = this.c.L0;
                view2.addOnAttachStateChangeListener(new a(view2));
            }
            this.c.y2();
            l lVar = this.a;
            Fragment fragment7 = this.c;
            lVar.m(fragment7, fragment7.L0, fragment7.X, false);
            int visibility = this.c.L0.getVisibility();
            this.c.P2(this.c.L0.getAlpha());
            Fragment fragment8 = this.c;
            if (fragment8.K0 != null && visibility == 0) {
                View viewFindFocus = fragment8.L0.findFocus();
                if (viewFindFocus != null) {
                    this.c.K2(viewFindFocus);
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + this.c);
                    }
                }
                this.c.L0.setAlpha(0.0f);
            }
        }
        this.c.q = 2;
    }

    void g() {
        Fragment fragmentF;
        if (m.H0(3)) {
            Log.d("FragmentManager", "movefrom CREATED: " + this.c);
        }
        Fragment fragment = this.c;
        boolean zIsChangingConfigurations = true;
        boolean z = fragment.p0 && !fragment.o1();
        if (z) {
            Fragment fragment2 = this.c;
            if (!fragment2.q0) {
                this.b.B(fragment2.i0, null);
            }
        }
        if (!z && !this.b.p().q(this.c)) {
            String str = this.c.l0;
            if (str != null && (fragmentF = this.b.f(str)) != null && fragmentF.F0) {
                this.c.k0 = fragmentF;
            }
            this.c.q = 0;
            return;
        }
        j<?> jVar = this.c.x0;
        if (jVar instanceof ax.F0.t) {
            zIsChangingConfigurations = this.b.p().n();
        } else if (jVar.g() instanceof Activity) {
            zIsChangingConfigurations = true ^ ((Activity) jVar.g()).isChangingConfigurations();
        }
        if ((z && !this.c.q0) || zIsChangingConfigurations) {
            this.b.p().f(this.c);
        }
        this.c.i2();
        this.a.d(this.c, false);
        for (r rVar : this.b.k()) {
            if (rVar != null) {
                Fragment fragmentK = rVar.k();
                if (this.c.i0.equals(fragmentK.l0)) {
                    fragmentK.k0 = this.c;
                    fragmentK.l0 = null;
                }
            }
        }
        Fragment fragment3 = this.c;
        String str2 = fragment3.l0;
        if (str2 != null) {
            fragment3.k0 = this.b.f(str2);
        }
        this.b.s(this);
    }

    void h() {
        View view;
        if (m.H0(3)) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + this.c);
        }
        Fragment fragment = this.c;
        ViewGroup viewGroup = fragment.K0;
        if (viewGroup != null && (view = fragment.L0) != null) {
            viewGroup.removeView(view);
        }
        this.c.j2();
        this.a.n(this.c, false);
        Fragment fragment2 = this.c;
        fragment2.K0 = null;
        fragment2.L0 = null;
        fragment2.X0 = null;
        fragment2.Y0.n(null);
        this.c.s0 = false;
    }

    void i() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + this.c);
        }
        this.c.k2();
        this.a.e(this.c, false);
        Fragment fragment = this.c;
        fragment.q = -1;
        fragment.x0 = null;
        fragment.z0 = null;
        fragment.w0 = null;
        if ((!fragment.p0 || fragment.o1()) && !this.b.p().q(this.c)) {
            return;
        }
        if (m.H0(3)) {
            Log.d("FragmentManager", "initState called for fragment: " + this.c);
        }
        this.c.j1();
    }

    void j() {
        Fragment fragment = this.c;
        if (fragment.r0 && fragment.s0 && !fragment.u0) {
            if (m.H0(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.c);
            }
            Fragment fragment2 = this.c;
            fragment2.h2(fragment2.l2(fragment2.X), null, this.c.X);
            View view = this.c.L0;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.c;
                fragment3.L0.setTag(ax.p337y0.b.a, fragment3);
                Fragment fragment4 = this.c;
                if (fragment4.D0) {
                    fragment4.L0.setVisibility(8);
                }
                this.c.y2();
                l lVar = this.a;
                Fragment fragment5 = this.c;
                lVar.m(fragment5, fragment5.L0, fragment5.X, false);
                this.c.q = 2;
            }
        }
    }

    Fragment k() {
        return this.c;
    }

    void m() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        if (this.d) {
            if (m.H0(2)) {
                Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + k());
                return;
            }
            return;
        }
        try {
            this.d = true;
            boolean z = false;
            while (true) {
                int iD = d();
                Fragment fragment = this.c;
                int i = fragment.q;
                if (iD == i) {
                    if (!z && i == -1 && fragment.p0 && !fragment.o1() && !this.c.q0) {
                        if (m.H0(3)) {
                            Log.d("FragmentManager", "Cleaning up state of never attached fragment: " + this.c);
                        }
                        this.b.p().f(this.c);
                        this.b.s(this);
                        if (m.H0(3)) {
                            Log.d("FragmentManager", "initState called for fragment: " + this.c);
                        }
                        this.c.j1();
                    }
                    Fragment fragment2 = this.c;
                    if (fragment2.R0) {
                        if (fragment2.L0 != null && (viewGroup = fragment2.K0) != null) {
                            z zVarN = z.n(viewGroup, fragment2.N0());
                            if (this.c.D0) {
                                zVarN.c(this);
                            } else {
                                zVarN.e(this);
                            }
                        }
                        Fragment fragment3 = this.c;
                        m mVar = fragment3.w0;
                        if (mVar != null) {
                            mVar.F0(fragment3);
                        }
                        Fragment fragment4 = this.c;
                        fragment4.R0 = false;
                        fragment4.L1(fragment4.D0);
                        this.c.y0.I();
                    }
                    return;
                }
                if (iD <= i) {
                    switch (i - 1) {
                        case SubsamplingScaleImageView.ORIENTATION_USE_EXIF /* -1 */:
                            i();
                            break;
                        case 0:
                            if (fragment.q0 && this.b.q(fragment.i0) == null) {
                                r();
                            }
                            g();
                            break;
                        case 1:
                            h();
                            this.c.q = 1;
                            break;
                        case 2:
                            fragment.s0 = false;
                            fragment.q = 2;
                            break;
                        case 3:
                            if (m.H0(3)) {
                                Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + this.c);
                            }
                            Fragment fragment5 = this.c;
                            if (fragment5.q0) {
                                r();
                            } else if (fragment5.L0 != null && fragment5.Y == null) {
                                s();
                            }
                            Fragment fragment6 = this.c;
                            if (fragment6.L0 != null && (viewGroup2 = fragment6.K0) != null) {
                                z.n(viewGroup2, fragment6.N0()).d(this);
                            }
                            this.c.q = 3;
                            break;
                        case 4:
                            v();
                            break;
                        case 5:
                            fragment.q = 5;
                            break;
                        case 6:
                            n();
                            break;
                    }
                } else {
                    switch (i + 1) {
                        case 0:
                            c();
                            break;
                        case 1:
                            e();
                            break;
                        case 2:
                            j();
                            f();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            if (fragment.L0 != null && (viewGroup3 = fragment.K0) != null) {
                                z.n(viewGroup3, fragment.N0()).b(z.e.c.h(this.c.L0.getVisibility()), this);
                            }
                            this.c.q = 4;
                            break;
                        case 5:
                            u();
                            break;
                        case 6:
                            fragment.q = 6;
                            break;
                        case 7:
                            p();
                            break;
                    }
                }
                z = true;
            }
        } finally {
            this.d = false;
        }
    }

    void n() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "movefrom RESUMED: " + this.c);
        }
        this.c.q2();
        this.a.f(this.c, false);
    }

    void o(ClassLoader classLoader) {
        Bundle bundle = this.c.X;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        Fragment fragment = this.c;
        fragment.Y = fragment.X.getSparseParcelableArray("android:view_state");
        Fragment fragment2 = this.c;
        fragment2.Z = fragment2.X.getBundle("android:view_registry_state");
        Fragment fragment3 = this.c;
        fragment3.l0 = fragment3.X.getString("android:target_state");
        Fragment fragment4 = this.c;
        if (fragment4.l0 != null) {
            fragment4.m0 = fragment4.X.getInt("android:target_req_state", 0);
        }
        Fragment fragment5 = this.c;
        Boolean bool = fragment5.h0;
        if (bool != null) {
            fragment5.N0 = bool.booleanValue();
            this.c.h0 = null;
        } else {
            fragment5.N0 = fragment5.X.getBoolean("android:user_visible_hint", true);
        }
        Fragment fragment6 = this.c;
        if (fragment6.N0) {
            return;
        }
        fragment6.M0 = true;
    }

    void p() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto RESUMED: " + this.c);
        }
        View viewE0 = this.c.E0();
        if (viewE0 != null && l(viewE0)) {
            boolean zRequestFocus = viewE0.requestFocus();
            if (m.H0(2)) {
                StringBuilder sb = new StringBuilder();
                sb.append("requestFocus: Restoring focused view ");
                sb.append(viewE0);
                sb.append(" ");
                sb.append(zRequestFocus ? "succeeded" : "failed");
                sb.append(" on Fragment ");
                sb.append(this.c);
                sb.append(" resulting in focused view ");
                sb.append(this.c.L0.findFocus());
                Log.v("FragmentManager", sb.toString());
            }
        }
        this.c.K2(null);
        this.c.u2();
        this.a.i(this.c, false);
        Fragment fragment = this.c;
        fragment.X = null;
        fragment.Y = null;
        fragment.Z = null;
    }

    void r() {
        q qVar = new q(this.c);
        Fragment fragment = this.c;
        if (fragment.q <= -1 || qVar.p0 != null) {
            qVar.p0 = fragment.X;
        } else {
            Bundle bundleQ = q();
            qVar.p0 = bundleQ;
            if (this.c.l0 != null) {
                if (bundleQ == null) {
                    qVar.p0 = new Bundle();
                }
                qVar.p0.putString("android:target_state", this.c.l0);
                int i = this.c.m0;
                if (i != 0) {
                    qVar.p0.putInt("android:target_req_state", i);
                }
            }
        }
        this.b.B(this.c.i0, qVar);
    }

    void s() {
        if (this.c.L0 == null) {
            return;
        }
        if (m.H0(2)) {
            Log.v("FragmentManager", "Saving view state for fragment " + this.c + " with view " + this.c.L0);
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        this.c.L0.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            this.c.Y = sparseArray;
        }
        Bundle bundle = new Bundle();
        this.c.X0.e(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        this.c.Z = bundle;
    }

    void t(int i) {
        this.e = i;
    }

    void u() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "moveto STARTED: " + this.c);
        }
        this.c.w2();
        this.a.k(this.c, false);
    }

    void v() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "movefrom STARTED: " + this.c);
        }
        this.c.x2();
        this.a.l(this.c, false);
    }

    r(l lVar, s sVar, ClassLoader classLoader, i iVar, q qVar) {
        this.a = lVar;
        this.b = sVar;
        Fragment fragmentA = qVar.a(iVar, classLoader);
        this.c = fragmentA;
        if (m.H0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + fragmentA);
        }
    }

    r(l lVar, s sVar, Fragment fragment, q qVar) {
        this.a = lVar;
        this.b = sVar;
        this.c = fragment;
        fragment.Y = null;
        fragment.Z = null;
        fragment.v0 = 0;
        fragment.s0 = false;
        fragment.o0 = false;
        Fragment fragment2 = fragment.k0;
        fragment.l0 = fragment2 != null ? fragment2.i0 : null;
        fragment.k0 = null;
        Bundle bundle = qVar.p0;
        if (bundle != null) {
            fragment.X = bundle;
        } else {
            fragment.X = new Bundle();
        }
    }
}
