package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.fragment.app.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class C0564b implements Parcelable {
    public static final Parcelable.Creator<C0564b> CREATOR = new a();
    final ArrayList<String> X;
    final int[] Y;
    final int[] Z;
    final int h0;
    final String i0;
    final int j0;
    final int k0;
    final CharSequence l0;
    final int m0;
    final CharSequence n0;
    final ArrayList<String> o0;
    final ArrayList<String> p0;
    final int[] q;
    final boolean q0;

    /* JADX INFO: renamed from: androidx.fragment.app.b$a */
    class a implements Parcelable.Creator<C0564b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public C0564b createFromParcel(Parcel parcel) {
            return new C0564b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public C0564b[] newArray(int i) {
            return new C0564b[i];
        }
    }

    C0564b(C0563a c0563a) {
        int size = c0563a.c.size();
        this.q = new int[size * 6];
        if (!c0563a.i) {
            throw new IllegalStateException("Not on back stack");
        }
        this.X = new ArrayList<>(size);
        this.Y = new int[size];
        this.Z = new int[size];
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            t.a aVar = c0563a.c.get(i2);
            int i3 = i + 1;
            this.q[i] = aVar.a;
            ArrayList<String> arrayList = this.X;
            Fragment fragment = aVar.b;
            arrayList.add(fragment != null ? fragment.i0 : null);
            int[] iArr = this.q;
            iArr[i3] = aVar.c ? 1 : 0;
            iArr[i + 2] = aVar.d;
            iArr[i + 3] = aVar.e;
            int i4 = i + 5;
            iArr[i + 4] = aVar.f;
            i += 6;
            iArr[i4] = aVar.g;
            this.Y[i2] = aVar.h.ordinal();
            this.Z[i2] = aVar.i.ordinal();
        }
        this.h0 = c0563a.h;
        this.i0 = c0563a.k;
        this.j0 = c0563a.v;
        this.k0 = c0563a.l;
        this.l0 = c0563a.m;
        this.m0 = c0563a.n;
        this.n0 = c0563a.o;
        this.o0 = c0563a.p;
        this.p0 = c0563a.q;
        this.q0 = c0563a.r;
    }

    private void a(C0563a c0563a) {
        int i = 0;
        int i2 = 0;
        while (true) {
            boolean z = true;
            if (i >= this.q.length) {
                c0563a.h = this.h0;
                c0563a.k = this.i0;
                c0563a.i = true;
                c0563a.l = this.k0;
                c0563a.m = this.l0;
                c0563a.n = this.m0;
                c0563a.o = this.n0;
                c0563a.p = this.o0;
                c0563a.q = this.p0;
                c0563a.r = this.q0;
                return;
            }
            t.a aVar = new t.a();
            int i3 = i + 1;
            aVar.a = this.q[i];
            if (m.H0(2)) {
                Log.v("FragmentManager", "Instantiate " + c0563a + " op #" + i2 + " base fragment #" + this.q[i3]);
            }
            aVar.h = androidx.lifecycle.d.b.values()[this.Y[i2]];
            aVar.i = androidx.lifecycle.d.b.values()[this.Z[i2]];
            int[] iArr = this.q;
            int i4 = i + 2;
            if (iArr[i3] == 0) {
                z = false;
            }
            aVar.c = z;
            int i5 = iArr[i4];
            aVar.d = i5;
            int i6 = iArr[i + 3];
            aVar.e = i6;
            int i7 = i + 5;
            int i8 = iArr[i + 4];
            aVar.f = i8;
            i += 6;
            int i9 = iArr[i7];
            aVar.g = i9;
            c0563a.d = i5;
            c0563a.e = i6;
            c0563a.f = i8;
            c0563a.g = i9;
            c0563a.f(aVar);
            i2++;
        }
    }

    public C0563a b(m mVar) {
        C0563a c0563a = new C0563a(mVar);
        a(c0563a);
        c0563a.v = this.j0;
        for (int i = 0; i < this.X.size(); i++) {
            String str = this.X.get(i);
            if (str != null) {
                c0563a.c.get(i).b = mVar.f0(str);
            }
        }
        c0563a.w(1);
        return c0563a;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.q);
        parcel.writeStringList(this.X);
        parcel.writeIntArray(this.Y);
        parcel.writeIntArray(this.Z);
        parcel.writeInt(this.h0);
        parcel.writeString(this.i0);
        parcel.writeInt(this.j0);
        parcel.writeInt(this.k0);
        TextUtils.writeToParcel(this.l0, parcel, 0);
        parcel.writeInt(this.m0);
        TextUtils.writeToParcel(this.n0, parcel, 0);
        parcel.writeStringList(this.o0);
        parcel.writeStringList(this.p0);
        parcel.writeInt(this.q0 ? 1 : 0);
    }

    C0564b(Parcel parcel) {
        this.q = parcel.createIntArray();
        this.X = parcel.createStringArrayList();
        this.Y = parcel.createIntArray();
        this.Z = parcel.createIntArray();
        this.h0 = parcel.readInt();
        this.i0 = parcel.readString();
        this.j0 = parcel.readInt();
        this.k0 = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.l0 = (CharSequence) creator.createFromParcel(parcel);
        this.m0 = parcel.readInt();
        this.n0 = (CharSequence) creator.createFromParcel(parcel);
        this.o0 = parcel.createStringArrayList();
        this.p0 = parcel.createStringArrayList();
        this.q0 = parcel.readInt() != 0;
    }
}
