package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import ax.p015b0.Y;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
abstract class z {
    private final ViewGroup a;
    final ArrayList<e> b = new ArrayList<>();
    final ArrayList<e> c = new ArrayList<>();
    boolean d = false;
    boolean e = false;

    class a implements Runnable {
        final /* synthetic */ d q;

        a(d dVar) {
            this.q = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (z.this.b.contains(this.q)) {
                this.q.e().g(this.q.f().L0);
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ d q;

        b(d dVar) {
            this.q = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            z.this.b.remove(this.q);
            z.this.c.remove(this.q);
        }
    }

    static /* synthetic */ class c {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] b;

        static {
            int[] iArr = new int[e.b.values().length];
            b = iArr;
            try {
                iArr[e.b.ADDING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[e.b.REMOVING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[e.b.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[e.c.values().length];
            a = iArr2;
            try {
                iArr2[e.c.REMOVED.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[e.c.VISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[e.c.GONE.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[e.c.INVISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    private static class d extends e {
        private final r h;

        d(e.c cVar, e.b bVar, r rVar, ax.X.d dVar) {
            super(cVar, bVar, rVar.k(), dVar);
            this.h = rVar;
        }

        @Override // androidx.fragment.app.z.e
        public void c() {
            super.c();
            this.h.m();
        }

        @Override // androidx.fragment.app.z.e
        void l() {
            if (g() != e.b.ADDING) {
                if (g() == e.b.REMOVING) {
                    Fragment fragmentK = this.h.k();
                    View viewE2 = fragmentK.E2();
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "Clearing focus " + viewE2.findFocus() + " on view " + viewE2 + " for Fragment " + fragmentK);
                    }
                    viewE2.clearFocus();
                    return;
                }
                return;
            }
            Fragment fragmentK2 = this.h.k();
            View viewFindFocus = fragmentK2.L0.findFocus();
            if (viewFindFocus != null) {
                fragmentK2.K2(viewFindFocus);
                if (m.H0(2)) {
                    Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + fragmentK2);
                }
            }
            View viewE3 = f().E2();
            if (viewE3.getParent() == null) {
                this.h.b();
                viewE3.setAlpha(0.0f);
            }
            if (viewE3.getAlpha() == 0.0f && viewE3.getVisibility() == 0) {
                viewE3.setVisibility(4);
            }
            viewE3.setAlpha(fragmentK2.R0());
        }
    }

    static class e {
        private c a;
        private b b;
        private final Fragment c;
        private final List<Runnable> d = new ArrayList();
        private final HashSet<ax.X.d> e = new HashSet<>();
        private boolean f = false;
        private boolean g = false;

        class a implements ax.X.d.a {
            a() {
            }

            @Override // ax.X.d.a
            public void a() {
                e.this.b();
            }
        }

        enum b {
            NONE,
            ADDING,
            REMOVING
        }

        enum c {
            REMOVED,
            VISIBLE,
            GONE,
            INVISIBLE;

            static c h(int i) {
                if (i == 0) {
                    return VISIBLE;
                }
                if (i == 4) {
                    return INVISIBLE;
                }
                if (i == 8) {
                    return GONE;
                }
                throw new IllegalArgumentException("Unknown visibility " + i);
            }

            static c k(View view) {
                return (view.getAlpha() == 0.0f && view.getVisibility() == 0) ? INVISIBLE : h(view.getVisibility());
            }

            void g(View view) {
                int i = c.a[ordinal()];
                if (i == 1) {
                    ViewGroup viewGroup = (ViewGroup) view.getParent();
                    if (viewGroup != null) {
                        if (m.H0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Removing view " + view + " from container " + viewGroup);
                        }
                        viewGroup.removeView(view);
                        return;
                    }
                    return;
                }
                if (i == 2) {
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to VISIBLE");
                    }
                    view.setVisibility(0);
                    return;
                }
                if (i == 3) {
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to GONE");
                    }
                    view.setVisibility(8);
                    return;
                }
                if (i != 4) {
                    return;
                }
                if (m.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to INVISIBLE");
                }
                view.setVisibility(4);
            }
        }

        e(c cVar, b bVar, Fragment fragment, ax.X.d dVar) {
            this.a = cVar;
            this.b = bVar;
            this.c = fragment;
            dVar.c(new a());
        }

        final void a(Runnable runnable) {
            this.d.add(runnable);
        }

        final void b() {
            if (h()) {
                return;
            }
            this.f = true;
            if (this.e.isEmpty()) {
                c();
                return;
            }
            Iterator it = new ArrayList(this.e).iterator();
            while (it.hasNext()) {
                ((ax.X.d) it.next()).a();
            }
        }

        public void c() {
            if (this.g) {
                return;
            }
            if (m.H0(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
            }
            this.g = true;
            Iterator<Runnable> it = this.d.iterator();
            while (it.hasNext()) {
                it.next().run();
            }
        }

        public final void d(ax.X.d dVar) {
            if (this.e.remove(dVar) && this.e.isEmpty()) {
                c();
            }
        }

        public c e() {
            return this.a;
        }

        public final Fragment f() {
            return this.c;
        }

        b g() {
            return this.b;
        }

        final boolean h() {
            return this.f;
        }

        final boolean i() {
            return this.g;
        }

        public final void j(ax.X.d dVar) {
            l();
            this.e.add(dVar);
        }

        final void k(c cVar, b bVar) {
            int i = c.b[bVar.ordinal()];
            if (i == 1) {
                if (this.a == c.REMOVED) {
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.c + " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = " + this.b + " to ADDING.");
                    }
                    this.a = c.VISIBLE;
                    this.b = b.ADDING;
                    return;
                }
                return;
            }
            if (i == 2) {
                if (m.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.c + " mFinalState = " + this.a + " -> REMOVED. mLifecycleImpact  = " + this.b + " to REMOVING.");
                }
                this.a = c.REMOVED;
                this.b = b.REMOVING;
                return;
            }
            if (i == 3 && this.a != c.REMOVED) {
                if (m.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.c + " mFinalState = " + this.a + " -> " + cVar + ". ");
                }
                this.a = cVar;
            }
        }

        void l() {
        }

        public String toString() {
            return "Operation {" + Integer.toHexString(System.identityHashCode(this)) + "} {mFinalState = " + this.a + "} {mLifecycleImpact = " + this.b + "} {mFragment = " + this.c + "}";
        }
    }

    z(ViewGroup viewGroup) {
        this.a = viewGroup;
    }

    private void a(e.c cVar, e.b bVar, r rVar) {
        synchronized (this.b) {
            try {
                ax.X.d dVar = new ax.X.d();
                e eVarH = h(rVar.k());
                if (eVarH != null) {
                    eVarH.k(cVar, bVar);
                    return;
                }
                d dVar2 = new d(cVar, bVar, rVar, dVar);
                this.b.add(dVar2);
                dVar2.a(new a(dVar2));
                dVar2.a(new b(dVar2));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private e h(Fragment fragment) {
        for (e eVar : this.b) {
            if (eVar.f().equals(fragment) && !eVar.h()) {
                return eVar;
            }
        }
        return null;
    }

    private e i(Fragment fragment) {
        for (e eVar : this.c) {
            if (eVar.f().equals(fragment) && !eVar.h()) {
                return eVar;
            }
        }
        return null;
    }

    static z n(ViewGroup viewGroup, m mVar) {
        return o(viewGroup, mVar.z0());
    }

    static z o(ViewGroup viewGroup, A a2) {
        int i = ax.p337y0.b.b;
        Object tag = viewGroup.getTag(i);
        if (tag instanceof z) {
            return (z) tag;
        }
        z zVarA = a2.a(viewGroup);
        viewGroup.setTag(i, zVarA);
        return zVarA;
    }

    private void q() {
        for (e eVar : this.b) {
            if (eVar.g() == e.b.ADDING) {
                eVar.k(e.c.h(eVar.f().E2().getVisibility()), e.b.NONE);
            }
        }
    }

    void b(e.c cVar, r rVar) {
        if (m.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing add operation for fragment " + rVar.k());
        }
        a(cVar, e.b.ADDING, rVar);
    }

    void c(r rVar) {
        if (m.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing hide operation for fragment " + rVar.k());
        }
        a(e.c.GONE, e.b.NONE, rVar);
    }

    void d(r rVar) {
        if (m.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing remove operation for fragment " + rVar.k());
        }
        a(e.c.REMOVED, e.b.REMOVING, rVar);
    }

    void e(r rVar) {
        if (m.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing show operation for fragment " + rVar.k());
        }
        a(e.c.VISIBLE, e.b.NONE, rVar);
    }

    abstract void f(List<e> list, boolean z);

    void g() {
        if (this.e) {
            return;
        }
        if (!Y.T(this.a)) {
            j();
            this.d = false;
            return;
        }
        synchronized (this.b) {
            try {
                if (!this.b.isEmpty()) {
                    ArrayList<e> arrayList = new ArrayList(this.c);
                    this.c.clear();
                    for (e eVar : arrayList) {
                        if (m.H0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + eVar);
                        }
                        eVar.b();
                        if (!eVar.i()) {
                            this.c.add(eVar);
                        }
                    }
                    q();
                    ArrayList arrayList2 = new ArrayList(this.b);
                    this.b.clear();
                    this.c.addAll(arrayList2);
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations");
                    }
                    Iterator it = arrayList2.iterator();
                    while (it.hasNext()) {
                        ((e) it.next()).l();
                    }
                    f(arrayList2, this.d);
                    this.d = false;
                    if (m.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations");
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    void j() {
        if (m.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete");
        }
        boolean zT = Y.T(this.a);
        synchronized (this.b) {
            try {
                q();
                Iterator<e> it = this.b.iterator();
                while (it.hasNext()) {
                    it.next().l();
                }
                for (e eVar : new ArrayList(this.c)) {
                    if (m.H0(2)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("SpecialEffectsController: ");
                        sb.append(zT ? HttpUrl.FRAGMENT_ENCODE_SET : "Container " + this.a + " is not attached to window. ");
                        sb.append("Cancelling running operation ");
                        sb.append(eVar);
                        Log.v("FragmentManager", sb.toString());
                    }
                    eVar.b();
                }
                for (e eVar2 : new ArrayList(this.b)) {
                    if (m.H0(2)) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("SpecialEffectsController: ");
                        sb2.append(zT ? HttpUrl.FRAGMENT_ENCODE_SET : "Container " + this.a + " is not attached to window. ");
                        sb2.append("Cancelling pending operation ");
                        sb2.append(eVar2);
                        Log.v("FragmentManager", sb2.toString());
                    }
                    eVar2.b();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    void k() {
        if (this.e) {
            if (m.H0(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: Forcing postponed operations");
            }
            this.e = false;
            g();
        }
    }

    e.b l(r rVar) {
        e eVarH = h(rVar.k());
        e.b bVarG = eVarH != null ? eVarH.g() : null;
        e eVarI = i(rVar.k());
        return (eVarI == null || !(bVarG == null || bVarG == e.b.NONE)) ? bVarG : eVarI.g();
    }

    public ViewGroup m() {
        return this.a;
    }

    void p() {
        synchronized (this.b) {
            try {
                q();
                this.e = false;
                for (int size = this.b.size() - 1; size >= 0; size--) {
                    e eVar = this.b.get(size);
                    e.c cVarK = e.c.k(eVar.f().L0);
                    e.c cVarE = eVar.e();
                    e.c cVar = e.c.VISIBLE;
                    if (cVarE == cVar && cVarK != cVar) {
                        this.e = eVar.f().q1();
                        break;
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    void r(boolean z) {
        this.d = z;
    }
}
