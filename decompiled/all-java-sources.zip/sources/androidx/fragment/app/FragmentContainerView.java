package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import ax.p015b0.A0;
import ax.p015b0.Y;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {
    private final List<View> h0;
    private View.OnApplyWindowInsetsListener i0;
    private boolean j0;
    private final List<View> q;

    public static final class a {
        public static final a a = new a();

        private a() {
        }

        public final WindowInsets a(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener, View view, WindowInsets windowInsets) {
            ax.p138jb.l.f(onApplyWindowInsetsListener, "onApplyWindowInsetsListener");
            ax.p138jb.l.f(view, "v");
            ax.p138jb.l.f(windowInsets, "insets");
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(view, windowInsets);
            ax.p138jb.l.e(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            return windowInsetsOnApplyWindowInsets;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        ax.p138jb.l.f(context, "context");
    }

    private final void a(View view) {
        if (this.h0.contains(view)) {
            this.q.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        ax.p138jb.l.f(view, "child");
        if (m.B0(view) != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        A0 a0C0;
        ax.p138jb.l.f(windowInsets, "insets");
        A0 a0V = A0.v(windowInsets);
        ax.p138jb.l.e(a0V, "toWindowInsetsCompat(insets)");
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.i0;
        if (onApplyWindowInsetsListener != null) {
            a aVar = a.a;
            ax.p138jb.l.c(onApplyWindowInsetsListener);
            a0C0 = A0.v(aVar.a(onApplyWindowInsetsListener, this, windowInsets));
        } else {
            a0C0 = Y.c0(this, a0V);
        }
        ax.p138jb.l.e(a0C0, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
        if (!a0C0.o()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                Y.i(getChildAt(i), a0C0);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        ax.p138jb.l.f(canvas, "canvas");
        if (this.j0) {
            Iterator<T> it = this.q.iterator();
            while (it.hasNext()) {
                super.drawChild(canvas, (View) it.next(), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j) {
        ax.p138jb.l.f(canvas, "canvas");
        ax.p138jb.l.f(view, "child");
        if (this.j0 && (!this.q.isEmpty()) && this.q.contains(view)) {
            return false;
        }
        return super.drawChild(canvas, view, j);
    }

    @Override // android.view.ViewGroup
    public void endViewTransition(View view) {
        ax.p138jb.l.f(view, "view");
        this.h0.remove(view);
        if (this.q.remove(view)) {
            this.j0 = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends Fragment> F getFragment() {
        return (F) m.k0(this).h0(getId());
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        ax.p138jb.l.f(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                ax.p138jb.l.e(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        ax.p138jb.l.f(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public void removeViewAt(int i) {
        View childAt = getChildAt(i);
        ax.p138jb.l.e(childAt, "view");
        a(childAt);
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public void removeViewInLayout(View view) {
        ax.p138jb.l.f(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public void removeViews(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            ax.p138jb.l.e(childAt, "view");
            a(childAt);
        }
        super.removeViews(i, i2);
    }

    @Override // android.view.ViewGroup
    public void removeViewsInLayout(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            ax.p138jb.l.e(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i, i2);
    }

    public final void setDrawDisappearingViewsLast(boolean z) {
        this.j0 = z;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        ax.p138jb.l.f(onApplyWindowInsetsListener, "listener");
        this.i0 = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public void startViewTransition(View view) {
        ax.p138jb.l.f(view, "view");
        if (view.getParent() == this) {
            this.h0.add(view);
        }
        super.startViewTransition(view);
    }

    public /* synthetic */ FragmentContainerView(Context context, AttributeSet attributeSet, int i, int i2, ax.p138jb.g gVar) {
        this(context, attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, int i) {
        String str;
        super(context, attributeSet, i);
        ax.p138jb.l.f(context, "context");
        this.q = new ArrayList();
        this.h0 = new ArrayList();
        this.j0 = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            int[] iArr = ax.p337y0.c.e;
            ax.p138jb.l.e(iArr, "FragmentContainerView");
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(ax.p337y0.c.f);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, m mVar) {
        String str;
        super(context, attributeSet);
        ax.p138jb.l.f(context, "context");
        ax.p138jb.l.f(attributeSet, "attrs");
        ax.p138jb.l.f(mVar, "fm");
        this.q = new ArrayList();
        this.h0 = new ArrayList();
        this.j0 = true;
        String classAttribute = attributeSet.getClassAttribute();
        int[] iArr = ax.p337y0.c.e;
        ax.p138jb.l.e(iArr, "FragmentContainerView");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(ax.p337y0.c.f) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(ax.p337y0.c.g);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        Fragment fragmentH0 = mVar.h0(id);
        if (classAttribute != null && fragmentH0 == null) {
            if (id == -1) {
                if (string != null) {
                    str = " with tag " + string;
                } else {
                    str = HttpUrl.FRAGMENT_ENCODE_SET;
                }
                throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + str);
            }
            Fragment fragmentA = mVar.s0().a(context.getClassLoader(), classAttribute);
            ax.p138jb.l.e(fragmentA, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            fragmentA.N1(context, attributeSet, null);
            mVar.o().u(true).d(this, fragmentA, string).l();
        }
        mVar.Y0(this);
    }
}
