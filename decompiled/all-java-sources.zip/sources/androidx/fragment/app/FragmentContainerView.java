package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import ax.p035c0.C1839d0;
import ax.p035c0.F0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {
    private final List<View> k0;
    private View.OnApplyWindowInsetsListener l0;
    private boolean m0;
    private final List<View> q;

    public static final class a {
        public static final a a = new a();

        private a() {
        }

        public final WindowInsets a(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener, View view, WindowInsets windowInsets) {
            ax.p335uc.l.f(onApplyWindowInsetsListener, "onApplyWindowInsetsListener");
            ax.p335uc.l.f(view, "v");
            ax.p335uc.l.f(windowInsets, "insets");
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(view, windowInsets);
            ax.p335uc.l.e(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            return windowInsetsOnApplyWindowInsets;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        ax.p335uc.l.f(context, "context");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, int i) {
        String str;
        super(context, attributeSet, i);
        ax.p335uc.l.f(context, "context");
        this.q = new ArrayList();
        this.k0 = new ArrayList();
        this.m0 = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            int[] iArr = ax.p403z0.c.e;
            ax.p335uc.l.e(iArr, "FragmentContainerView");
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(ax.p403z0.c.f);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    public /* synthetic */ FragmentContainerView(Context context, AttributeSet attributeSet, int i, int i2, ax.p335uc.g gVar) {
        this(context, attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, FragmentManager fragmentManager) {
        String str;
        super(context, attributeSet);
        ax.p335uc.l.f(context, "context");
        ax.p335uc.l.f(attributeSet, "attrs");
        ax.p335uc.l.f(fragmentManager, "fm");
        this.q = new ArrayList();
        this.k0 = new ArrayList();
        this.m0 = true;
        String classAttribute = attributeSet.getClassAttribute();
        int[] iArr = ax.p403z0.c.e;
        ax.p335uc.l.e(iArr, "FragmentContainerView");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(ax.p403z0.c.f) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(ax.p403z0.c.g);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        Fragment fragmentJ0 = fragmentManager.j0(id);
        if (classAttribute != null && fragmentJ0 == null) {
            if (id == -1) {
                if (string != null) {
                    str = " with tag " + string;
                } else {
                    str = HttpUrl.FRAGMENT_ENCODE_SET;
                }
                throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + str);
            }
            Fragment fragmentA = fragmentManager.u0().a(context.getClassLoader(), classAttribute);
            ax.p335uc.l.e(fragmentA, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            fragmentA.J1(context, attributeSet, null);
            fragmentManager.o().u(true).d(this, fragmentA, string).l();
        }
        fragmentManager.W0(this);
    }

    private final void a(View view) {
        if (this.k0.contains(view)) {
            this.q.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        ax.p335uc.l.f(view, "child");
        if (FragmentManager.D0(view) != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        F0 f0X;
        ax.p335uc.l.f(windowInsets, "insets");
        F0 f0V = F0.v(windowInsets);
        ax.p335uc.l.e(f0V, "toWindowInsetsCompat(insets)");
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.l0;
        if (onApplyWindowInsetsListener != null) {
            a aVar = a.a;
            ax.p335uc.l.c(onApplyWindowInsetsListener);
            f0X = F0.v(aVar.a(onApplyWindowInsetsListener, this, windowInsets));
        } else {
            f0X = C1839d0.X(this, f0V);
        }
        ax.p335uc.l.e(f0X, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
        if (!f0X.o()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                C1839d0.i(getChildAt(i), f0X);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        ax.p335uc.l.f(canvas, "canvas");
        if (this.m0) {
            Iterator<T> it = this.q.iterator();
            while (it.hasNext()) {
                super.drawChild(canvas, (View) it.next(), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j) {
        ax.p335uc.l.f(canvas, "canvas");
        ax.p335uc.l.f(view, "child");
        if (this.m0 && !this.q.isEmpty() && this.q.contains(view)) {
            return false;
        }
        return super.drawChild(canvas, view, j);
    }

    @Override // android.view.ViewGroup
    public void endViewTransition(View view) {
        ax.p335uc.l.f(view, "view");
        this.k0.remove(view);
        if (this.q.remove(view)) {
            this.m0 = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends Fragment> F getFragment() {
        return (F) FragmentManager.m0(this).j0(getId());
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        ax.p335uc.l.f(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                ax.p335uc.l.e(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        ax.p335uc.l.f(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public void removeViewAt(int i) {
        View childAt = getChildAt(i);
        ax.p335uc.l.e(childAt, "view");
        a(childAt);
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public void removeViewInLayout(View view) {
        ax.p335uc.l.f(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public void removeViews(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            ax.p335uc.l.e(childAt, "view");
            a(childAt);
        }
        super.removeViews(i, i2);
    }

    @Override // android.view.ViewGroup
    public void removeViewsInLayout(int i, int i2) {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            View childAt = getChildAt(i4);
            ax.p335uc.l.e(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i, i2);
    }

    public final void setDrawDisappearingViewsLast(boolean z) {
        this.m0 = z;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        ax.p335uc.l.f(onApplyWindowInsetsListener, "listener");
        this.l0 = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public void startViewTransition(View view) {
        ax.p335uc.l.f(view, "view");
        if (view.getParent() == this) {
            this.k0.add(view);
        }
        super.startViewTransition(view);
    }
}
