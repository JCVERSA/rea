package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public class i {
    private static final ax.B.k<ClassLoader, ax.B.k<String, Class<?>>> a = new ax.B.k<>();

    static boolean b(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(c(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    private static Class<?> c(ClassLoader classLoader, String str) throws ClassNotFoundException {
        ax.B.k<ClassLoader, ax.B.k<String, Class<?>>> kVar = a;
        ax.B.k<String, Class<?>> kVar2 = kVar.get(classLoader);
        if (kVar2 == null) {
            kVar2 = new ax.B.k<>();
            kVar.put(classLoader, kVar2);
        }
        Class<?> cls = kVar2.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        kVar2.put(str, cls2);
        return cls2;
    }

    public static Class<? extends Fragment> d(ClassLoader classLoader, String str) {
        try {
            return c(classLoader, str);
        } catch (ClassCastException e) {
            throw new Fragment.h("Unable to instantiate fragment " + str + ": make sure class is a valid subclass of Fragment", e);
        } catch (ClassNotFoundException e2) {
            throw new Fragment.h("Unable to instantiate fragment " + str + ": make sure class name exists", e2);
        }
    }

    public Fragment a(ClassLoader classLoader, String str) {
        throw null;
    }
}
