package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
final class p implements Parcelable {
    public static final Parcelable.Creator<p> CREATOR = new a();
    final String X;
    final boolean Y;
    final int Z;
    final int k0;
    final String l0;
    final boolean m0;
    final boolean n0;
    final boolean o0;
    final Bundle p0;
    final String q;
    final boolean q0;
    final int r0;
    Bundle s0;

    class a implements Parcelable.Creator<p> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public p createFromParcel(Parcel parcel) {
            return new p(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public p[] newArray(int i) {
            return new p[i];
        }
    }

    p(Parcel parcel) {
        this.q = parcel.readString();
        this.X = parcel.readString();
        this.Y = parcel.readInt() != 0;
        this.Z = parcel.readInt();
        this.k0 = parcel.readInt();
        this.l0 = parcel.readString();
        this.m0 = parcel.readInt() != 0;
        this.n0 = parcel.readInt() != 0;
        this.o0 = parcel.readInt() != 0;
        this.p0 = parcel.readBundle();
        this.q0 = parcel.readInt() != 0;
        this.s0 = parcel.readBundle();
        this.r0 = parcel.readInt();
    }

    p(Fragment fragment) {
        this.q = fragment.getClass().getName();
        this.X = fragment.l0;
        this.Y = fragment.u0;
        this.Z = fragment.D0;
        this.k0 = fragment.E0;
        this.l0 = fragment.F0;
        this.m0 = fragment.I0;
        this.n0 = fragment.s0;
        this.o0 = fragment.H0;
        this.p0 = fragment.m0;
        this.q0 = fragment.G0;
        this.r0 = fragment.Y0.ordinal();
    }

    Fragment a(i iVar, ClassLoader classLoader) {
        Fragment fragmentA = iVar.a(classLoader, this.q);
        Bundle bundle = this.p0;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        fragmentA.F2(this.p0);
        fragmentA.l0 = this.X;
        fragmentA.u0 = this.Y;
        fragmentA.w0 = true;
        fragmentA.D0 = this.Z;
        fragmentA.E0 = this.k0;
        fragmentA.F0 = this.l0;
        fragmentA.I0 = this.m0;
        fragmentA.s0 = this.n0;
        fragmentA.H0 = this.o0;
        fragmentA.G0 = this.q0;
        fragmentA.Y0 = androidx.lifecycle.d.b.values()[this.r0];
        Bundle bundle2 = this.s0;
        if (bundle2 != null) {
            fragmentA.X = bundle2;
            return fragmentA;
        }
        fragmentA.X = new Bundle();
        return fragmentA;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.q);
        sb.append(" (");
        sb.append(this.X);
        sb.append(")}:");
        if (this.Y) {
            sb.append(" fromLayout");
        }
        if (this.k0 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.k0));
        }
        String str = this.l0;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.l0);
        }
        if (this.m0) {
            sb.append(" retainInstance");
        }
        if (this.n0) {
            sb.append(" removing");
        }
        if (this.o0) {
            sb.append(" detached");
        }
        if (this.q0) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.q);
        parcel.writeString(this.X);
        parcel.writeInt(this.Y ? 1 : 0);
        parcel.writeInt(this.Z);
        parcel.writeInt(this.k0);
        parcel.writeString(this.l0);
        parcel.writeInt(this.m0 ? 1 : 0);
        parcel.writeInt(this.n0 ? 1 : 0);
        parcel.writeInt(this.o0 ? 1 : 0);
        parcel.writeBundle(this.p0);
        parcel.writeInt(this.q0 ? 1 : 0);
        parcel.writeBundle(this.s0);
        parcel.writeInt(this.r0);
    }
}
