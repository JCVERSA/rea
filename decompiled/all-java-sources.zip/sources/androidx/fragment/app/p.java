package androidx.fragment.app;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
final class p extends androidx.lifecycle.o {
    private static final androidx.lifecycle.p.b k = new a();
    private final boolean g;
    private final HashMap<String, Fragment> d = new HashMap<>();
    private final HashMap<String, p> e = new HashMap<>();
    private final HashMap<String, androidx.lifecycle.q> f = new HashMap<>();
    private boolean h = false;
    private boolean i = false;
    private boolean j = false;

    class a implements androidx.lifecycle.p.b {
        a() {
        }

        @Override // androidx.lifecycle.p.b
        public <T extends androidx.lifecycle.o> T a(Class<T> cls) {
            return new p(true);
        }

        @Override // androidx.lifecycle.p.b
        public /* synthetic */ androidx.lifecycle.o b(Class cls, ax.H0.a aVar) {
            return ax.F0.r.b(this, cls, aVar);
        }
    }

    p(boolean z) {
        this.g = z;
    }

    private void h(String str) {
        p pVar = this.e.get(str);
        if (pVar != null) {
            pVar.d();
            this.e.remove(str);
        }
        androidx.lifecycle.q qVar = this.f.get(str);
        if (qVar != null) {
            qVar.a();
            this.f.remove(str);
        }
    }

    static p k(androidx.lifecycle.q qVar) {
        return (p) new androidx.lifecycle.p(qVar, k).a(p.class);
    }

    @Override // androidx.lifecycle.o
    protected void d() {
        if (m.H0(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.h = true;
    }

    void e(Fragment fragment) {
        if (this.j) {
            if (m.H0(2)) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else {
            if (this.d.containsKey(fragment.i0)) {
                return;
            }
            this.d.put(fragment.i0, fragment);
            if (m.H0(2)) {
                Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
            }
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || p.class != obj.getClass()) {
            return false;
        }
        p pVar = (p) obj;
        return this.d.equals(pVar.d) && this.e.equals(pVar.e) && this.f.equals(pVar.f);
    }

    void f(Fragment fragment) {
        if (m.H0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        h(fragment.i0);
    }

    void g(String str) {
        if (m.H0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
        }
        h(str);
    }

    public int hashCode() {
        return (((this.d.hashCode() * 31) + this.e.hashCode()) * 31) + this.f.hashCode();
    }

    Fragment i(String str) {
        return this.d.get(str);
    }

    p j(Fragment fragment) {
        p pVar = this.e.get(fragment.i0);
        if (pVar != null) {
            return pVar;
        }
        p pVar2 = new p(this.g);
        this.e.put(fragment.i0, pVar2);
        return pVar2;
    }

    Collection<Fragment> l() {
        return new ArrayList(this.d.values());
    }

    androidx.lifecycle.q m(Fragment fragment) {
        androidx.lifecycle.q qVar = this.f.get(fragment.i0);
        if (qVar != null) {
            return qVar;
        }
        androidx.lifecycle.q qVar2 = new androidx.lifecycle.q();
        this.f.put(fragment.i0, qVar2);
        return qVar2;
    }

    boolean n() {
        return this.h;
    }

    void o(Fragment fragment) {
        if (this.j) {
            if (m.H0(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else {
            if (this.d.remove(fragment.i0) == null || !m.H0(2)) {
                return;
            }
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    void p(boolean z) {
        this.j = z;
    }

    boolean q(Fragment fragment) {
        if (this.d.containsKey(fragment.i0)) {
            return this.g ? this.h : !this.i;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.d.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.e.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
