package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import ax.p035c0.C1839d0;
import ax.p035c0.C1849i0;
import ax.p035c0.L;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
class d extends z {

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[z.e.c.values().length];
            a = iArr;
            try {
                iArr[z.e.c.GONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[z.e.c.INVISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[z.e.c.REMOVED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[z.e.c.VISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ List q;

        b(List list, z.e eVar) {
            this.q = list;
            this.X = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.q.contains(this.X)) {
                this.q.remove(this.X);
                d.this.s(this.X);
            }
        }
    }

    class c extends AnimatorListenerAdapter {
        final /* synthetic */ ViewGroup a;
        final /* synthetic */ View b;
        final /* synthetic */ boolean c;
        final /* synthetic */ z.e d;
        final /* synthetic */ k e;

        c(ViewGroup viewGroup, View view, boolean z, z.e eVar, k kVar) {
            this.a = viewGroup;
            this.b = view;
            this.c = z;
            this.d = eVar;
            this.e = kVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.a.endViewTransition(this.b);
            if (this.c) {
                this.d.e().g(this.b);
            }
            this.e.a();
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.d + " has ended.");
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.d$d, reason: collision with other inner class name */
    class C0019d implements ax.Y.d.a {
        final /* synthetic */ Animator a;
        final /* synthetic */ z.e b;

        C0019d(Animator animator, z.e eVar) {
            this.a = animator;
            this.b = eVar;
        }

        @Override // ax.Y.d.a
        public void a() {
            this.a.end();
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.b + " has been canceled.");
            }
        }
    }

    class e implements Animation.AnimationListener {
        final /* synthetic */ z.e a;
        final /* synthetic */ ViewGroup b;
        final /* synthetic */ View c;
        final /* synthetic */ k d;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                e eVar = e.this;
                eVar.b.endViewTransition(eVar.c);
                e.this.d.a();
            }
        }

        e(z.e eVar, ViewGroup viewGroup, View view, k kVar) {
            this.a = eVar;
            this.b = viewGroup;
            this.c = view;
            this.d = kVar;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.b.post(new a());
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.a + " has ended.");
            }
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.a + " has reached onAnimationStart.");
            }
        }
    }

    class f implements ax.Y.d.a {
        final /* synthetic */ View a;
        final /* synthetic */ ViewGroup b;
        final /* synthetic */ k c;
        final /* synthetic */ z.e d;

        f(View view, ViewGroup viewGroup, k kVar, z.e eVar) {
            this.a = view;
            this.b = viewGroup;
            this.c = kVar;
            this.d = eVar;
        }

        @Override // ax.Y.d.a
        public void a() {
            this.a.clearAnimation();
            this.b.endViewTransition(this.a);
            this.c.a();
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.d + " has been cancelled.");
            }
        }
    }

    class g implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ boolean Y;
        final /* synthetic */ ax.B.a Z;
        final /* synthetic */ z.e q;

        g(z.e eVar, z.e eVar2, boolean z, ax.B.a aVar) {
            this.q = eVar;
            this.X = eVar2;
            this.Y = z;
            this.Z = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            u.a(this.q.f(), this.X.f(), this.Y, this.Z, false);
        }
    }

    class h implements Runnable {
        final /* synthetic */ View X;
        final /* synthetic */ Rect Y;
        final /* synthetic */ w q;

        h(w wVar, View view, Rect rect) {
            this.q = wVar;
            this.X = view;
            this.Y = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.h(this.X, this.Y);
        }
    }

    class i implements Runnable {
        final /* synthetic */ ArrayList q;

        i(ArrayList arrayList) {
            this.q = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            u.d(this.q, 4);
        }
    }

    class j implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ m q;

        j(m mVar, z.e eVar) {
            this.q = mVar;
            this.X = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.a();
            if (FragmentManager.J0(2)) {
                Log.v("FragmentManager", "Transition for operation " + this.X + "has completed");
            }
        }
    }

    private static class k extends l {
        private boolean c;
        private boolean d;
        private androidx.fragment.app.g.a e;

        k(z.e eVar, ax.Y.d dVar, boolean z) {
            super(eVar, dVar);
            this.d = false;
            this.c = z;
        }

        androidx.fragment.app.g.a e(Context context) {
            if (this.d) {
                return this.e;
            }
            androidx.fragment.app.g.a aVarB = androidx.fragment.app.g.b(context, b().f(), b().e() == z.e.c.VISIBLE, this.c);
            this.e = aVarB;
            this.d = true;
            return aVarB;
        }
    }

    private static class l {
        private final z.e a;
        private final ax.Y.d b;

        l(z.e eVar, ax.Y.d dVar) {
            this.a = eVar;
            this.b = dVar;
        }

        void a() {
            this.a.d(this.b);
        }

        z.e b() {
            return this.a;
        }

        ax.Y.d c() {
            return this.b;
        }

        boolean d() {
            z.e.c cVarK = z.e.c.k(this.a.f().O0);
            z.e.c cVarE = this.a.e();
            if (cVarK == cVarE) {
                return true;
            }
            z.e.c cVar = z.e.c.VISIBLE;
            return (cVarK == cVar || cVarE == cVar) ? false : true;
        }
    }

    private static class m extends l {
        private final Object c;
        private final boolean d;
        private final Object e;

        m(z.e eVar, ax.Y.d dVar, boolean z, boolean z2) {
            super(eVar, dVar);
            if (eVar.e() == z.e.c.VISIBLE) {
                this.c = z ? eVar.f().O0() : eVar.f().v0();
                this.d = z ? eVar.f().q0() : eVar.f().p0();
            } else {
                this.c = z ? eVar.f().Q0() : eVar.f().y0();
                this.d = true;
            }
            if (!z2) {
                this.e = null;
            } else if (z) {
                this.e = eVar.f().S0();
            } else {
                this.e = eVar.f().R0();
            }
        }

        private w f(Object obj) {
            if (obj == null) {
                return null;
            }
            w wVar = u.a;
            if (wVar != null && wVar.e(obj)) {
                return wVar;
            }
            w wVar2 = u.b;
            if (wVar2 != null && wVar2.e(obj)) {
                return wVar2;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + b().f() + " is not a valid framework Transition or AndroidX Transition");
        }

        w e() {
            w wVarF = f(this.c);
            w wVarF2 = f(this.e);
            if (wVarF == null || wVarF2 == null || wVarF == wVarF2) {
                return wVarF != null ? wVarF : wVarF2;
            }
            throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + b().f() + " returned Transition " + this.c + " which uses a different Transition  type than its shared element transition " + this.e);
        }

        public Object g() {
            return this.e;
        }

        Object h() {
            return this.c;
        }

        public boolean i() {
            return this.e != null;
        }

        boolean j() {
            return this.d;
        }
    }

    d(ViewGroup viewGroup) {
        super(viewGroup);
    }

    private void w(List<k> list, List<z.e> list2, boolean z, Map<z.e, Boolean> map) {
        z.e eVar;
        k kVar;
        View view;
        ViewGroup viewGroupM = m();
        Context context = viewGroupM.getContext();
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        boolean z2 = false;
        for (k kVar2 : list) {
            if (kVar2.d()) {
                kVar2.a();
            } else {
                androidx.fragment.app.g.a aVarE = kVar2.e(context);
                if (aVarE == null) {
                    kVar2.a();
                } else {
                    Animator animator = aVarE.b;
                    if (animator == null) {
                        arrayList.add(kVar2);
                    } else {
                        z.e eVarB = kVar2.b();
                        Fragment fragmentF = eVarB.f();
                        if (Boolean.TRUE.equals(map.get(eVarB))) {
                            if (FragmentManager.J0(2)) {
                                Log.v("FragmentManager", "Ignoring Animator set on " + fragmentF + " as this Fragment was involved in a Transition.");
                            }
                            kVar2.a();
                        } else {
                            boolean z3 = eVarB.e() == z.e.c.GONE;
                            if (z3) {
                                list2.remove(eVarB);
                            }
                            View view2 = fragmentF.O0;
                            viewGroupM.startViewTransition(view2);
                            ViewGroup viewGroup = viewGroupM;
                            viewGroupM = viewGroup;
                            animator.addListener(new c(viewGroup, view2, z3, eVarB, kVar2));
                            animator.setTarget(view2);
                            animator.start();
                            if (FragmentManager.J0(2)) {
                                Log.v("FragmentManager", "Animator from operation " + eVarB + " has started.");
                            }
                            kVar2.c().c(new C0019d(animator, eVarB));
                            z2 = true;
                        }
                    }
                }
            }
        }
        int size = arrayList.size();
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            k kVar3 = (k) obj;
            z.e eVarB2 = kVar3.b();
            Fragment fragmentF2 = eVarB2.f();
            if (z) {
                if (FragmentManager.J0(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Transitions.");
                }
                kVar3.a();
            } else if (z2) {
                if (FragmentManager.J0(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Animators.");
                }
                kVar3.a();
            } else {
                View view3 = fragmentF2.O0;
                Animation animation = (Animation) ax.p019b0.g.g(((androidx.fragment.app.g.a) ax.p019b0.g.g(kVar3.e(context))).a);
                if (eVarB2.e() != z.e.c.REMOVED) {
                    view3.startAnimation(animation);
                    kVar3.a();
                    eVar = eVarB2;
                    kVar = kVar3;
                    view = view3;
                } else {
                    viewGroupM.startViewTransition(view3);
                    androidx.fragment.app.g.b bVar = new androidx.fragment.app.g.b(animation, viewGroupM, view3);
                    eVar = eVarB2;
                    kVar = kVar3;
                    view = view3;
                    bVar.setAnimationListener(new e(eVar, viewGroupM, view, kVar));
                    view.startAnimation(bVar);
                    if (FragmentManager.J0(2)) {
                        Log.v("FragmentManager", "Animation from operation " + eVar + " has started.");
                    }
                }
                kVar.c().c(new f(view, viewGroupM, kVar, eVar));
            }
        }
    }

    private Map<z.e, Boolean> x(List<m> list, List<z.e> list2, boolean z, z.e eVar, z.e eVar2) {
        String str;
        String str2;
        ArrayList<View> arrayList;
        ArrayList arrayList2;
        ArrayList<View> arrayList3;
        Object obj;
        Rect rect;
        String str3;
        View view;
        View view2;
        Object objK;
        Object objK2;
        z.e eVar3;
        View view3;
        ArrayList<View> arrayList4;
        View view4;
        int i2;
        View view5;
        HashMap map = new HashMap();
        w wVar = null;
        for (m mVar : list) {
            if (!mVar.d()) {
                w wVarE = mVar.e();
                if (wVar == null) {
                    wVar = wVarE;
                } else if (wVarE != null && wVar != wVarE) {
                    throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + mVar.b().f() + " returned Transition " + mVar.h() + " which uses a different Transition  type than other Fragments.");
                }
            }
        }
        if (wVar == null) {
            for (m mVar2 : list) {
                map.put(mVar2.b(), Boolean.FALSE);
                mVar2.a();
            }
        } else {
            View view6 = new View(m().getContext());
            Rect rect2 = new Rect();
            ArrayList<View> arrayList5 = new ArrayList<>();
            ArrayList<View> arrayList6 = new ArrayList<>();
            ax.B.a aVar = new ax.B.a();
            Iterator<m> it = list.iterator();
            Object obj2 = null;
            View view7 = null;
            boolean z2 = false;
            while (true) {
                str = "FragmentManager";
                if (!it.hasNext()) {
                    break;
                }
                m next = it.next();
                if (!next.i() || eVar == null || eVar2 == null) {
                    view3 = view6;
                    arrayList4 = arrayList5;
                    view4 = view7;
                } else {
                    Object objU = wVar.u(wVar.f(next.g()));
                    ArrayList<String> arrayListT0 = eVar2.f().T0();
                    ArrayList<String> arrayListT1 = eVar.f().T0();
                    ArrayList<String> arrayListU0 = eVar.f().U0();
                    int i3 = 0;
                    while (i3 < arrayListU0.size()) {
                        int iIndexOf = arrayListT0.indexOf(arrayListU0.get(i3));
                        ArrayList<String> arrayList7 = arrayListU0;
                        if (iIndexOf != -1) {
                            arrayListT0.set(iIndexOf, arrayListT1.get(i3));
                        }
                        i3++;
                        arrayListU0 = arrayList7;
                    }
                    ArrayList<String> arrayListU1 = eVar2.f().U0();
                    if (z == 0) {
                        eVar.f().z0();
                        eVar2.f().w0();
                    } else {
                        eVar.f().w0();
                        eVar2.f().z0();
                    }
                    int i4 = 0;
                    for (int size = arrayListT0.size(); i4 < size; size = size) {
                        aVar.put(arrayListT0.get(i4), arrayListU1.get(i4));
                        i4++;
                    }
                    if (FragmentManager.J0(2)) {
                        Log.v("FragmentManager", ">>> entering view names <<<");
                        int i5 = 0;
                        for (int size2 = arrayListU1.size(); i5 < size2; size2 = size2) {
                            String str4 = arrayListU1.get(i5);
                            Log.v("FragmentManager", "Name: " + str4);
                            i5++;
                        }
                        Log.v("FragmentManager", ">>> exiting view names <<<");
                        int i6 = 0;
                        for (int size3 = arrayListT0.size(); i6 < size3; size3 = size3) {
                            String str5 = arrayListT0.get(i6);
                            Log.v("FragmentManager", "Name: " + str5);
                            i6++;
                        }
                    }
                    ax.B.a<String, View> aVar2 = new ax.B.a<>();
                    u(aVar2, eVar.f().O0);
                    aVar2.o(arrayListT0);
                    aVar.o(aVar2.keySet());
                    ax.B.a<String, View> aVar3 = new ax.B.a<>();
                    u(aVar3, eVar2.f().O0);
                    aVar3.o(arrayListU1);
                    aVar3.o(aVar.values());
                    u.c(aVar, aVar3);
                    v(aVar2, aVar.keySet());
                    v(aVar3, aVar.values());
                    if (aVar.isEmpty()) {
                        arrayList5.clear();
                        arrayList6.clear();
                        view3 = view6;
                        rect2 = rect2;
                        arrayList4 = arrayList5;
                        aVar = aVar;
                        arrayList6 = arrayList6;
                        obj2 = null;
                    } else {
                        u.a(eVar2.f(), eVar.f(), z, aVar2, true);
                        view4 = view7;
                        L.a(m(), new g(eVar2, eVar, z, aVar3));
                        arrayList5.addAll(aVar2.values());
                        if (arrayListT0.isEmpty()) {
                            i2 = 0;
                        } else {
                            i2 = 0;
                            View view8 = aVar2.get(arrayListT0.get(0));
                            wVar.p(objU, view8);
                            view4 = view8;
                        }
                        arrayList6.addAll(aVar3.values());
                        if (!arrayListU1.isEmpty() && (view5 = aVar3.get(arrayListU1.get(i2))) != null) {
                            L.a(m(), new h(wVar, view5, rect2));
                            z2 = true;
                        }
                        wVar.s(objU, view6, arrayList5);
                        ArrayList<View> arrayList8 = arrayList5;
                        view3 = view6;
                        wVar.n(objU, null, null, null, null, objU, arrayList6);
                        Boolean bool = Boolean.TRUE;
                        map.put(eVar, bool);
                        map.put(eVar2, bool);
                        arrayList4 = arrayList8;
                        obj2 = objU;
                    }
                    arrayList5 = arrayList4;
                    arrayList6 = arrayList6;
                    aVar = aVar;
                    rect2 = rect2;
                    view6 = view3;
                }
                view7 = view4;
                arrayList5 = arrayList4;
                arrayList6 = arrayList6;
                aVar = aVar;
                rect2 = rect2;
                view6 = view3;
            }
            z.e eVar4 = eVar;
            z.e eVar5 = eVar2;
            View view9 = view6;
            ArrayList<View> arrayList9 = arrayList5;
            ax.B.a aVar4 = aVar;
            View view10 = view7;
            Rect rect3 = rect2;
            ArrayList<View> arrayList10 = arrayList6;
            ArrayList arrayList11 = new ArrayList();
            Object obj3 = null;
            Object obj4 = null;
            for (m mVar3 : list) {
                if (mVar3.d()) {
                    map.put(mVar3.b(), Boolean.FALSE);
                    mVar3.a();
                } else {
                    Object objF = wVar.f(mVar3.h());
                    z.e eVarB = mVar3.b();
                    boolean z3 = obj2 != null && (eVarB == eVar4 || eVarB == eVar5);
                    if (objF == null) {
                        if (!z3) {
                            map.put(eVarB, Boolean.FALSE);
                            mVar3.a();
                        }
                        str3 = str;
                        view = view9;
                        arrayList3 = arrayList9;
                        arrayList = arrayList10;
                        rect = rect3;
                        arrayList2 = arrayList11;
                        view2 = view10;
                    } else {
                        Rect rect4 = rect3;
                        ArrayList<View> arrayList12 = new ArrayList<>();
                        ArrayList arrayList13 = arrayList11;
                        t(arrayList12, eVarB.f().O0);
                        if (z3) {
                            if (eVarB == eVar4) {
                                arrayList12.removeAll(arrayList9);
                            } else {
                                arrayList12.removeAll(arrayList10);
                            }
                        }
                        if (arrayList12.isEmpty()) {
                            wVar.a(objF, view9);
                            str3 = str;
                            view = view9;
                            arrayList = arrayList10;
                            objK2 = obj3;
                            objK = obj4;
                            eVar3 = eVarB;
                            view2 = view10;
                            arrayList2 = arrayList13;
                            arrayList3 = arrayList9;
                            obj = objF;
                            rect = rect4;
                        } else {
                            wVar.b(objF, arrayList12);
                            arrayList = arrayList10;
                            String str6 = str;
                            arrayList2 = arrayList13;
                            arrayList3 = arrayList9;
                            obj = objF;
                            rect = rect4;
                            str3 = str6;
                            view = view9;
                            view2 = view10;
                            objK = obj4;
                            objK2 = obj3;
                            wVar.n(obj, objF, arrayList12, null, null, null, null);
                            if (eVarB.e() == z.e.c.GONE) {
                                eVar3 = eVarB;
                                list2.remove(eVar3);
                                ArrayList<View> arrayList14 = new ArrayList<>(arrayList12);
                                arrayList14.remove(eVar3.f().O0);
                                wVar.m(obj, eVar3.f().O0, arrayList14);
                                L.a(m(), new i(arrayList12));
                            } else {
                                eVar3 = eVarB;
                            }
                        }
                        if (eVar3.e() == z.e.c.VISIBLE) {
                            arrayList2.addAll(arrayList12);
                            if (z2) {
                                wVar.o(obj, rect);
                            }
                        } else {
                            wVar.p(obj, view2);
                        }
                        map.put(eVar3, Boolean.TRUE);
                        if (mVar3.j()) {
                            objK2 = wVar.k(objK2, obj, null);
                        } else {
                            objK = wVar.k(objK, obj, null);
                        }
                        obj3 = objK2;
                        obj4 = objK;
                    }
                    arrayList9 = arrayList3;
                    eVar4 = eVar;
                    eVar5 = eVar2;
                    rect3 = rect;
                    arrayList11 = arrayList2;
                    view10 = view2;
                    view9 = view;
                    str = str3;
                    arrayList10 = arrayList;
                }
            }
            String str7 = str;
            ArrayList<View> arrayList15 = arrayList9;
            ArrayList<View> arrayList16 = arrayList10;
            ArrayList arrayList17 = arrayList11;
            Object objJ = wVar.j(obj3, obj4, obj2);
            if (objJ != null) {
                for (m mVar4 : list) {
                    if (!mVar4.d()) {
                        Object objH = mVar4.h();
                        z.e eVarB2 = mVar4.b();
                        boolean z4 = obj2 != null && (eVarB2 == eVar || eVarB2 == eVar2);
                        if (objH == null && !z4) {
                            str2 = str7;
                        } else if (C1839d0.R(m())) {
                            str2 = str7;
                            wVar.q(mVar4.b().f(), objJ, mVar4.c(), new j(mVar4, eVarB2));
                        } else {
                            if (FragmentManager.J0(2)) {
                                str2 = str7;
                                Log.v(str2, "SpecialEffectsController: Container " + m() + " has not been laid out. Completing operation " + eVarB2);
                            } else {
                                str2 = str7;
                            }
                            mVar4.a();
                        }
                        str7 = str2;
                    }
                }
                String str8 = str7;
                if (C1839d0.R(m())) {
                    u.d(arrayList17, 4);
                    ArrayList<String> arrayListL = wVar.l(arrayList16);
                    if (FragmentManager.J0(2)) {
                        Log.v(str8, ">>>>> Beginning transition <<<<<");
                        Log.v(str8, ">>>>> SharedElementFirstOutViews <<<<<");
                        int size4 = arrayList15.size();
                        int i7 = 0;
                        while (i7 < size4) {
                            View view11 = arrayList15.get(i7);
                            i7++;
                            View view12 = view11;
                            Log.v(str8, "View: " + view12 + " Name: " + C1839d0.I(view12));
                        }
                        Log.v(str8, ">>>>> SharedElementLastInViews <<<<<");
                        int size5 = arrayList16.size();
                        int i8 = 0;
                        while (i8 < size5) {
                            View view13 = arrayList16.get(i8);
                            i8++;
                            View view14 = view13;
                            Log.v(str8, "View: " + view14 + " Name: " + C1839d0.I(view14));
                        }
                    }
                    wVar.c(m(), objJ);
                    wVar.r(m(), arrayList15, arrayList16, arrayListL, aVar4);
                    u.d(arrayList17, 0);
                    wVar.t(obj2, arrayList15, arrayList16);
                    return map;
                }
            }
        }
        return map;
    }

    private void y(List<z.e> list) {
        Fragment fragmentF = list.get(list.size() - 1).f();
        for (z.e eVar : list) {
            eVar.f().R0.c = fragmentF.R0.c;
            eVar.f().R0.d = fragmentF.R0.d;
            eVar.f().R0.e = fragmentF.R0.e;
            eVar.f().R0.f = fragmentF.R0.f;
        }
    }

    /* JADX WARN: Code duplicated, block: B:29:0x00a9  */
    @Override // androidx.fragment.app.z
    void f(List<z.e> list, boolean z) {
        int i2;
        z.e eVar = null;
        z.e eVar2 = null;
        for (z.e eVar3 : list) {
            z.e.c cVarK = z.e.c.k(eVar3.f().O0);
            int i3 = a.a[eVar3.e().ordinal()];
            if (i3 == 1 || i3 == 2 || i3 == 3) {
                if (cVarK == z.e.c.VISIBLE && eVar == null) {
                    eVar = eVar3;
                }
            } else if (i3 == 4 && cVarK != z.e.c.VISIBLE) {
                eVar2 = eVar3;
            }
        }
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "Executing operations from " + eVar + " to " + eVar2);
        }
        List<k> arrayList = new ArrayList<>();
        List<m> arrayList2 = new ArrayList<>();
        ArrayList arrayList3 = new ArrayList(list);
        y(list);
        Iterator<z.e> it = list.iterator();
        while (true) {
            i2 = 0;
            z = false;
            boolean z2 = false;
            if (!it.hasNext()) {
                break;
            }
            z.e next = it.next();
            ax.Y.d dVar = new ax.Y.d();
            next.j(dVar);
            arrayList.add(new k(next, dVar, z));
            ax.Y.d dVar2 = new ax.Y.d();
            next.j(dVar2);
            if (z) {
                if (next == eVar) {
                    z2 = true;
                }
            } else if (next == eVar2) {
                z2 = true;
            }
            arrayList2.add(new m(next, dVar2, z, z2));
            next.a(new b(arrayList3, next));
        }
        Map<z.e, Boolean> mapX = x(arrayList2, arrayList3, z, eVar, eVar2);
        w(arrayList, arrayList3, mapX.containsValue(Boolean.TRUE), mapX);
        int size = arrayList3.size();
        while (i2 < size) {
            Object obj = arrayList3.get(i2);
            i2++;
            s((z.e) obj);
        }
        arrayList3.clear();
        if (FragmentManager.J0(2)) {
            Log.v("FragmentManager", "Completed executing operations from " + eVar + " to " + eVar2);
        }
    }

    void s(z.e eVar) {
        eVar.e().g(eVar.f().O0);
    }

    void t(ArrayList<View> arrayList, View view) {
        if (!(view instanceof ViewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(view);
            return;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        if (C1849i0.b(viewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(viewGroup);
            return;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                t(arrayList, childAt);
            }
        }
    }

    void u(Map<String, View> map, View view) {
        String strI = C1839d0.I(view);
        if (strI != null) {
            map.put(strI, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt.getVisibility() == 0) {
                    u(map, childAt);
                }
            }
        }
    }

    void v(ax.B.a<String, View> aVar, Collection<String> collection) {
        Iterator<Map.Entry<String, View>> it = aVar.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(C1839d0.I(it.next().getValue()))) {
                it.remove();
            }
        }
    }
}
