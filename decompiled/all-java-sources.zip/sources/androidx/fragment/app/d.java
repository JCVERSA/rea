package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import ax.p015b0.C5214d0;
import ax.p015b0.K;
import ax.p015b0.Y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
class d extends z {

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[z.e.c.values().length];
            a = iArr;
            try {
                iArr[z.e.c.GONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[z.e.c.INVISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[z.e.c.REMOVED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[z.e.c.VISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ List q;

        b(List list, z.e eVar) {
            this.q = list;
            this.X = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.q.contains(this.X)) {
                this.q.remove(this.X);
                d.this.s(this.X);
            }
        }
    }

    class c extends AnimatorListenerAdapter {
        final /* synthetic */ ViewGroup a;
        final /* synthetic */ View b;
        final /* synthetic */ boolean c;
        final /* synthetic */ z.e d;
        final /* synthetic */ k e;

        c(ViewGroup viewGroup, View view, boolean z, z.e eVar, k kVar) {
            this.a = viewGroup;
            this.b = view;
            this.c = z;
            this.d = eVar;
            this.e = kVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.a.endViewTransition(this.b);
            if (this.c) {
                this.d.e().g(this.b);
            }
            this.e.a();
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.d + " has ended.");
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.d$d, reason: collision with other inner class name */
    class C0017d implements ax.X.d.a {
        final /* synthetic */ Animator a;
        final /* synthetic */ z.e b;

        C0017d(Animator animator, z.e eVar) {
            this.a = animator;
            this.b = eVar;
        }

        @Override // ax.X.d.a
        public void a() {
            this.a.end();
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.b + " has been canceled.");
            }
        }
    }

    class e implements Animation.AnimationListener {
        final /* synthetic */ z.e a;
        final /* synthetic */ ViewGroup b;
        final /* synthetic */ View c;
        final /* synthetic */ k d;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                e eVar = e.this;
                eVar.b.endViewTransition(eVar.c);
                e.this.d.a();
            }
        }

        e(z.e eVar, ViewGroup viewGroup, View view, k kVar) {
            this.a = eVar;
            this.b = viewGroup;
            this.c = view;
            this.d = kVar;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.b.post(new a());
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.a + " has ended.");
            }
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.a + " has reached onAnimationStart.");
            }
        }
    }

    class f implements ax.X.d.a {
        final /* synthetic */ View a;
        final /* synthetic */ ViewGroup b;
        final /* synthetic */ k c;
        final /* synthetic */ z.e d;

        f(View view, ViewGroup viewGroup, k kVar, z.e eVar) {
            this.a = view;
            this.b = viewGroup;
            this.c = kVar;
            this.d = eVar;
        }

        @Override // ax.X.d.a
        public void a() {
            this.a.clearAnimation();
            this.b.endViewTransition(this.a);
            this.c.a();
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.d + " has been cancelled.");
            }
        }
    }

    class g implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ boolean Y;
        final /* synthetic */ ax.B.a Z;
        final /* synthetic */ z.e q;

        g(z.e eVar, z.e eVar2, boolean z, ax.B.a aVar) {
            this.q = eVar;
            this.X = eVar2;
            this.Y = z;
            this.Z = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            u.a(this.q.f(), this.X.f(), this.Y, this.Z, false);
        }
    }

    class h implements Runnable {
        final /* synthetic */ View X;
        final /* synthetic */ Rect Y;
        final /* synthetic */ w q;

        h(w wVar, View view, Rect rect) {
            this.q = wVar;
            this.X = view;
            this.Y = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.h(this.X, this.Y);
        }
    }

    class i implements Runnable {
        final /* synthetic */ ArrayList q;

        i(ArrayList arrayList) {
            this.q = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            u.d(this.q, 4);
        }
    }

    class j implements Runnable {
        final /* synthetic */ z.e X;
        final /* synthetic */ m q;

        j(m mVar, z.e eVar) {
            this.q = mVar;
            this.X = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.a();
            if (androidx.fragment.app.m.H0(2)) {
                Log.v("FragmentManager", "Transition for operation " + this.X + "has completed");
            }
        }
    }

    private static class k extends l {
        private boolean c;
        private boolean d;
        private androidx.fragment.app.g.a e;

        k(z.e eVar, ax.X.d dVar, boolean z) {
            super(eVar, dVar);
            this.d = false;
            this.c = z;
        }

        androidx.fragment.app.g.a e(Context context) {
            if (this.d) {
                return this.e;
            }
            androidx.fragment.app.g.a aVarB = androidx.fragment.app.g.b(context, b().f(), b().e() == z.e.c.VISIBLE, this.c);
            this.e = aVarB;
            this.d = true;
            return aVarB;
        }
    }

    private static class l {
        private final z.e a;
        private final ax.X.d b;

        l(z.e eVar, ax.X.d dVar) {
            this.a = eVar;
            this.b = dVar;
        }

        void a() {
            this.a.d(this.b);
        }

        z.e b() {
            return this.a;
        }

        ax.X.d c() {
            return this.b;
        }

        boolean d() {
            z.e.c cVar;
            z.e.c cVarK = z.e.c.k(this.a.f().L0);
            z.e.c cVarE = this.a.e();
            return cVarK == cVarE || !(cVarK == (cVar = z.e.c.VISIBLE) || cVarE == cVar);
        }
    }

    private static class m extends l {
        private final Object c;
        private final boolean d;
        private final Object e;

        m(z.e eVar, ax.X.d dVar, boolean z, boolean z2) {
            super(eVar, dVar);
            if (eVar.e() == z.e.c.VISIBLE) {
                this.c = z ? eVar.f().S0() : eVar.f().z0();
                this.d = z ? eVar.f().u0() : eVar.f().t0();
            } else {
                this.c = z ? eVar.f().U0() : eVar.f().C0();
                this.d = true;
            }
            if (!z2) {
                this.e = null;
            } else if (z) {
                this.e = eVar.f().W0();
            } else {
                this.e = eVar.f().V0();
            }
        }

        private w f(Object obj) {
            if (obj == null) {
                return null;
            }
            w wVar = u.a;
            if (wVar != null && wVar.e(obj)) {
                return wVar;
            }
            w wVar2 = u.b;
            if (wVar2 != null && wVar2.e(obj)) {
                return wVar2;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + b().f() + " is not a valid framework Transition or AndroidX Transition");
        }

        w e() {
            w wVarF = f(this.c);
            w wVarF2 = f(this.e);
            if (wVarF == null || wVarF2 == null || wVarF == wVarF2) {
                return wVarF != null ? wVarF : wVarF2;
            }
            throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + b().f() + " returned Transition " + this.c + " which uses a different Transition  type than its shared element transition " + this.e);
        }

        public Object g() {
            return this.e;
        }

        Object h() {
            return this.c;
        }

        public boolean i() {
            return this.e != null;
        }

        boolean j() {
            return this.d;
        }
    }

    d(ViewGroup viewGroup) {
        super(viewGroup);
    }

    private void w(List<k> list, List<z.e> list2, boolean z, Map<z.e, Boolean> map) {
        int i2;
        boolean z2;
        Context context;
        View view;
        z.e eVar;
        ViewGroup viewGroupM = m();
        Context context2 = viewGroupM.getContext();
        ArrayList<k> arrayList = new ArrayList();
        Iterator<k> it = list.iterator();
        boolean z3 = false;
        while (true) {
            i2 = 2;
            if (!it.hasNext()) {
                break;
            }
            k next = it.next();
            if (next.d()) {
                next.a();
            } else {
                androidx.fragment.app.g.a aVarE = next.e(context2);
                if (aVarE == null) {
                    next.a();
                } else {
                    Animator animator = aVarE.b;
                    if (animator == null) {
                        arrayList.add(next);
                    } else {
                        z.e eVarB = next.b();
                        Fragment fragmentF = eVarB.f();
                        if (Boolean.TRUE.equals(map.get(eVarB))) {
                            if (androidx.fragment.app.m.H0(2)) {
                                Log.v("FragmentManager", "Ignoring Animator set on " + fragmentF + " as this Fragment was involved in a Transition.");
                            }
                            next.a();
                        } else {
                            boolean z4 = eVarB.e() == z.e.c.GONE;
                            if (z4) {
                                list2.remove(eVarB);
                            }
                            View view2 = fragmentF.L0;
                            viewGroupM.startViewTransition(view2);
                            animator.addListener(new c(viewGroupM, view2, z4, eVarB, next));
                            animator.setTarget(view2);
                            animator.start();
                            if (androidx.fragment.app.m.H0(2)) {
                                StringBuilder sb = new StringBuilder();
                                sb.append("Animator from operation ");
                                eVar = eVarB;
                                sb.append(eVar);
                                sb.append(" has started.");
                                Log.v("FragmentManager", sb.toString());
                            } else {
                                eVar = eVarB;
                            }
                            next.c().c(new C0017d(animator, eVar));
                            z3 = true;
                        }
                    }
                }
            }
        }
        for (k kVar : arrayList) {
            z.e eVarB2 = kVar.b();
            Fragment fragmentF2 = eVarB2.f();
            if (z) {
                if (androidx.fragment.app.m.H0(i2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Transitions.");
                }
                kVar.a();
            } else if (z3) {
                if (androidx.fragment.app.m.H0(i2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Animators.");
                }
                kVar.a();
            } else {
                View view3 = fragmentF2.L0;
                Animation animation = (Animation) ax.p001a0.g.g(((androidx.fragment.app.g.a) ax.p001a0.g.g(kVar.e(context2))).a);
                if (eVarB2.e() != z.e.c.REMOVED) {
                    view3.startAnimation(animation);
                    kVar.a();
                    z2 = z3;
                    context = context2;
                    view = view3;
                } else {
                    viewGroupM.startViewTransition(view3);
                    androidx.fragment.app.g.b bVar = new androidx.fragment.app.g.b(animation, viewGroupM, view3);
                    z2 = z3;
                    context = context2;
                    view = view3;
                    bVar.setAnimationListener(new e(eVarB2, viewGroupM, view3, kVar));
                    view.startAnimation(bVar);
                    if (androidx.fragment.app.m.H0(2)) {
                        Log.v("FragmentManager", "Animation from operation " + eVarB2 + " has started.");
                    }
                }
                kVar.c().c(new f(view, viewGroupM, kVar, eVarB2));
                z3 = z2;
                context2 = context;
                i2 = 2;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private Map<z.e, Boolean> x(List<m> list, List<z.e> list2, boolean z, z.e eVar, z.e eVar2) {
        String str;
        String str2;
        String str3;
        View view;
        Object obj;
        ArrayList<View> arrayList;
        Object obj2;
        ArrayList<View> arrayList2;
        HashMap map;
        View view2;
        Object objK;
        ArrayList<View> arrayList3;
        z.e eVar3;
        HashMap map2;
        z.e eVar4;
        View view3;
        View view4;
        z.e eVar5 = eVar;
        z.e eVar6 = eVar2;
        HashMap map3 = new HashMap();
        w wVar = null;
        for (m mVar : list) {
            if (!mVar.d()) {
                w wVarE = mVar.e();
                if (wVar == null) {
                    wVar = wVarE;
                } else if (wVarE != null && wVar != wVarE) {
                    throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + mVar.b().f() + " returned Transition " + mVar.h() + " which uses a different Transition  type than other Fragments.");
                }
            }
        }
        if (wVar == null) {
            for (m mVar2 : list) {
                map3.put(mVar2.b(), Boolean.FALSE);
                mVar2.a();
            }
            return map3;
        }
        View view5 = new View(m().getContext());
        Rect rect = new Rect();
        ArrayList<View> arrayList4 = new ArrayList<>();
        ArrayList<View> arrayList5 = new ArrayList<>();
        ax.B.a aVar = new ax.B.a();
        Iterator<m> it = list.iterator();
        Object obj3 = null;
        View view6 = null;
        boolean z2 = false;
        while (true) {
            str = "FragmentManager";
            if (!it.hasNext()) {
                break;
            }
            m next = it.next();
            if (!next.i() || eVar5 == null || eVar6 == null) {
                arrayList3 = arrayList5;
                eVar3 = eVar5;
                map2 = map3;
                View view7 = view5;
                eVar4 = eVar6;
                view3 = view7;
                view6 = view6;
            } else {
                Object objU = wVar.u(wVar.f(next.g()));
                ArrayList<String> arrayListX0 = eVar2.f().X0();
                ArrayList<String> arrayListX1 = eVar.f().X0();
                ArrayList<String> arrayListY0 = eVar.f().Y0();
                View view8 = view6;
                int i2 = 0;
                while (i2 < arrayListY0.size()) {
                    int iIndexOf = arrayListX0.indexOf(arrayListY0.get(i2));
                    ArrayList<String> arrayList6 = arrayListY0;
                    if (iIndexOf != -1) {
                        arrayListX0.set(iIndexOf, arrayListX1.get(i2));
                    }
                    i2++;
                    arrayListY0 = arrayList6;
                }
                ArrayList<String> arrayListY1 = eVar2.f().Y0();
                if (z == 0) {
                    eVar.f().D0();
                    eVar2.f().A0();
                } else {
                    eVar.f().A0();
                    eVar2.f().D0();
                }
                int i3 = 0;
                for (int size = arrayListX0.size(); i3 < size; size = size) {
                    aVar.put(arrayListX0.get(i3), arrayListY1.get(i3));
                    i3++;
                }
                if (androidx.fragment.app.m.H0(2)) {
                    Log.v("FragmentManager", ">>> entering view names <<<");
                    for (Iterator<String> it2 = arrayListY1.iterator(); it2.hasNext(); it2 = it2) {
                        Log.v("FragmentManager", "Name: " + it2.next());
                    }
                    Log.v("FragmentManager", ">>> exiting view names <<<");
                    for (Iterator<String> it3 = arrayListX0.iterator(); it3.hasNext(); it3 = it3) {
                        Log.v("FragmentManager", "Name: " + it3.next());
                    }
                }
                ax.B.a<String, View> aVar2 = new ax.B.a<>();
                u(aVar2, eVar.f().L0);
                aVar2.o(arrayListX0);
                aVar.o(aVar2.keySet());
                ax.B.a<String, View> aVar3 = new ax.B.a<>();
                u(aVar3, eVar2.f().L0);
                aVar3.o(arrayListY1);
                aVar3.o(aVar.values());
                u.c(aVar, aVar3);
                v(aVar2, aVar.keySet());
                v(aVar3, aVar.values());
                if (aVar.isEmpty()) {
                    arrayList4.clear();
                    arrayList5.clear();
                    arrayList3 = arrayList5;
                    eVar3 = eVar5;
                    view3 = view5;
                    view6 = view8;
                    obj3 = null;
                    eVar4 = eVar2;
                    map2 = map3;
                } else {
                    u.a(eVar2.f(), eVar.f(), z, aVar2, true);
                    HashMap map4 = map3;
                    View view9 = view5;
                    ArrayList<View> arrayList7 = arrayList5;
                    K.a(m(), new g(eVar2, eVar, z, aVar3));
                    arrayList4.addAll(aVar2.values());
                    if (arrayListX0.isEmpty()) {
                        view6 = view8;
                    } else {
                        view6 = (View) aVar2.get(arrayListX0.get(0));
                        wVar.p(objU, view6);
                    }
                    arrayList3 = arrayList7;
                    arrayList3.addAll(aVar3.values());
                    if (!arrayListY1.isEmpty() && (view4 = (View) aVar3.get(arrayListY1.get(0))) != null) {
                        K.a(m(), new h(wVar, view4, rect));
                        z2 = true;
                    }
                    wVar.s(objU, view9, arrayList4);
                    view3 = view9;
                    wVar.n(objU, null, null, null, null, objU, arrayList3);
                    Boolean bool = Boolean.TRUE;
                    eVar3 = eVar;
                    map2 = map4;
                    map2.put(eVar3, bool);
                    eVar4 = eVar2;
                    map2.put(eVar4, bool);
                    obj3 = objU;
                }
            }
            eVar5 = eVar3;
            arrayList4 = arrayList4;
            rect = rect;
            map3 = map2;
            aVar = aVar;
            arrayList5 = arrayList3;
            wVar = wVar;
            z.e eVar7 = eVar4;
            view5 = view3;
            eVar6 = eVar7;
        }
        View view10 = view6;
        ax.B.a aVar4 = aVar;
        ArrayList<View> arrayList8 = arrayList5;
        z.e eVar8 = eVar5;
        ArrayList<View> arrayList9 = arrayList4;
        Rect rect2 = rect;
        w wVar2 = wVar;
        HashMap map5 = map3;
        View view11 = view5;
        z.e eVar9 = eVar6;
        View view12 = view11;
        ArrayList arrayList10 = new ArrayList();
        Object obj4 = null;
        Object objK2 = null;
        for (m mVar3 : list) {
            if (mVar3.d()) {
                map5.put(mVar3.b(), Boolean.FALSE);
                mVar3.a();
            } else {
                Object objF = wVar2.f(mVar3.h());
                z.e eVarB = mVar3.b();
                boolean z3 = obj3 != null && (eVarB == eVar8 || eVarB == eVar9);
                if (objF == null) {
                    if (!z3) {
                        map5.put(eVarB, Boolean.FALSE);
                        mVar3.a();
                    }
                    arrayList2 = arrayList8;
                    str3 = str;
                    arrayList = arrayList9;
                    view = view12;
                    objK = obj4;
                    map = map5;
                    view2 = view10;
                } else {
                    str3 = str;
                    ArrayList<View> arrayList11 = new ArrayList<>();
                    Object obj5 = obj4;
                    t(arrayList11, eVarB.f().L0);
                    if (z3) {
                        if (eVarB == eVar8) {
                            arrayList11.removeAll(arrayList9);
                        } else {
                            arrayList11.removeAll(arrayList8);
                        }
                    }
                    if (arrayList11.isEmpty()) {
                        wVar2.a(objF, view12);
                        arrayList2 = arrayList8;
                        arrayList = arrayList9;
                        view = view12;
                        obj2 = objK2;
                        map = map5;
                        obj = obj5;
                    } else {
                        wVar2.b(objF, arrayList11);
                        view = view12;
                        obj = obj5;
                        arrayList = arrayList9;
                        obj2 = objK2;
                        arrayList2 = arrayList8;
                        map = map5;
                        wVar2.n(objF, objF, arrayList11, null, null, null, null);
                        if (eVarB.e() == z.e.c.GONE) {
                            list2.remove(eVarB);
                            ArrayList<View> arrayList12 = new ArrayList<>(arrayList11);
                            arrayList12.remove(eVarB.f().L0);
                            wVar2.m(objF, eVarB.f().L0, arrayList12);
                            K.a(m(), new i(arrayList11));
                        }
                    }
                    if (eVarB.e() == z.e.c.VISIBLE) {
                        arrayList10.addAll(arrayList11);
                        if (z2) {
                            wVar2.o(objF, rect2);
                        }
                        view2 = view10;
                    } else {
                        view2 = view10;
                        wVar2.p(objF, view2);
                    }
                    map.put(eVarB, Boolean.TRUE);
                    if (mVar3.j()) {
                        objK2 = wVar2.k(obj2, objF, null);
                        objK = obj;
                    } else {
                        objK = wVar2.k(obj, objF, null);
                        objK2 = obj2;
                    }
                }
                eVar9 = eVar2;
                map5 = map;
                obj4 = objK;
                view10 = view2;
                str = str3;
                view12 = view;
                arrayList9 = arrayList;
                arrayList8 = arrayList2;
            }
        }
        ArrayList<View> arrayList13 = arrayList8;
        String str4 = str;
        ArrayList<View> arrayList14 = arrayList9;
        HashMap map6 = map5;
        Object objJ = wVar2.j(objK2, obj4, obj3);
        if (objJ == null) {
            return map6;
        }
        for (m mVar4 : list) {
            if (!mVar4.d()) {
                Object objH = mVar4.h();
                z.e eVarB2 = mVar4.b();
                HashMap map7 = map6;
                boolean z4 = obj3 != null && (eVarB2 == eVar8 || eVarB2 == eVar2);
                if (objH == null && !z4) {
                    str2 = str4;
                } else if (Y.U(m())) {
                    str2 = str4;
                    wVar2.q(mVar4.b().f(), objJ, mVar4.c(), new j(mVar4, eVarB2));
                } else {
                    if (androidx.fragment.app.m.H0(2)) {
                        str2 = str4;
                        Log.v(str2, "SpecialEffectsController: Container " + m() + " has not been laid out. Completing operation " + eVarB2);
                    } else {
                        str2 = str4;
                    }
                    mVar4.a();
                }
                map6 = map7;
                str4 = str2;
            }
        }
        HashMap map8 = map6;
        String str5 = str4;
        if (!Y.U(m())) {
            return map8;
        }
        u.d(arrayList10, 4);
        ArrayList<String> arrayListL = wVar2.l(arrayList13);
        if (androidx.fragment.app.m.H0(2)) {
            Log.v(str5, ">>>>> Beginning transition <<<<<");
            Log.v(str5, ">>>>> SharedElementFirstOutViews <<<<<");
            for (View view13 : arrayList14) {
                Log.v(str5, "View: " + view13 + " Name: " + Y.L(view13));
            }
            Log.v(str5, ">>>>> SharedElementLastInViews <<<<<");
            for (View view14 : arrayList13) {
                Log.v(str5, "View: " + view14 + " Name: " + Y.L(view14));
            }
        }
        wVar2.c(m(), objJ);
        wVar2.r(m(), arrayList14, arrayList13, arrayListL, aVar4);
        u.d(arrayList10, 0);
        wVar2.t(obj3, arrayList14, arrayList13);
        return map8;
    }

    private void y(List<z.e> list) {
        Fragment fragmentF = list.get(list.size() - 1).f();
        for (z.e eVar : list) {
            eVar.f().O0.c = fragmentF.O0.c;
            eVar.f().O0.d = fragmentF.O0.d;
            eVar.f().O0.e = fragmentF.O0.e;
            eVar.f().O0.f = fragmentF.O0.f;
        }
    }

    /* JADX WARN: Code duplicated, block: B:29:0x00a8  */
    @Override // androidx.fragment.app.z
    void f(List<z.e> list, boolean z) {
        z.e eVar = null;
        z.e eVar2 = null;
        for (z.e eVar3 : list) {
            z.e.c cVarK = z.e.c.k(eVar3.f().L0);
            int i2 = a.a[eVar3.e().ordinal()];
            if (i2 == 1 || i2 == 2 || i2 == 3) {
                if (cVarK == z.e.c.VISIBLE && eVar == null) {
                    eVar = eVar3;
                }
            } else if (i2 == 4 && cVarK != z.e.c.VISIBLE) {
                eVar2 = eVar3;
            }
        }
        if (androidx.fragment.app.m.H0(2)) {
            Log.v("FragmentManager", "Executing operations from " + eVar + " to " + eVar2);
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList(list);
        y(list);
        for (z.e eVar4 : list) {
            ax.X.d dVar = new ax.X.d();
            eVar4.j(dVar);
            arrayList.add(new k(eVar4, dVar, z));
            ax.X.d dVar2 = new ax.X.d();
            eVar4.j(dVar2);
            boolean z2 = false;
            if (z) {
                if (eVar4 == eVar) {
                    z2 = true;
                }
            } else if (eVar4 == eVar2) {
                z2 = true;
            }
            arrayList2.add(new m(eVar4, dVar2, z, z2));
            eVar4.a(new b(arrayList3, eVar4));
        }
        Map<z.e, Boolean> mapX = x(arrayList2, arrayList3, z, eVar, eVar2);
        w(arrayList, arrayList3, mapX.containsValue(Boolean.TRUE), mapX);
        Iterator<z.e> it = arrayList3.iterator();
        while (it.hasNext()) {
            s(it.next());
        }
        arrayList3.clear();
        if (androidx.fragment.app.m.H0(2)) {
            Log.v("FragmentManager", "Completed executing operations from " + eVar + " to " + eVar2);
        }
    }

    void s(z.e eVar) {
        eVar.e().g(eVar.f().L0);
    }

    void t(ArrayList<View> arrayList, View view) {
        if (!(view instanceof ViewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(view);
            return;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        if (C5214d0.b(viewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(viewGroup);
            return;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                t(arrayList, childAt);
            }
        }
    }

    void u(Map<String, View> map, View view) {
        String strL = Y.L(view);
        if (strL != null) {
            map.put(strL, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt.getVisibility() == 0) {
                    u(map, childAt);
                }
            }
        }
    }

    void v(ax.B.a<String, View> aVar, Collection<String> collection) {
        Iterator<Map.Entry<String, View>> it = aVar.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(Y.L(it.next().getValue()))) {
                it.remove();
            }
        }
    }
}
