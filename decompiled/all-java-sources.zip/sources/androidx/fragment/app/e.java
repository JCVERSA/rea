package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public class e extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    private Handler g1;
    private boolean p1;
    private Dialog r1;
    private boolean s1;
    private boolean t1;
    private boolean u1;
    private Runnable h1 = new a();
    private DialogInterface.OnCancelListener i1 = new b();
    private DialogInterface.OnDismissListener j1 = new c();
    private int k1 = 0;
    private int l1 = 0;
    private boolean m1 = true;
    private boolean n1 = true;
    private int o1 = -1;
    private ax.F0.l<ax.F0.g> q1 = new d();
    private boolean v1 = false;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        @SuppressLint({"SyntheticAccessor"})
        public void run() {
            e.this.j1.onDismiss(e.this.r1);
        }
    }

    class b implements DialogInterface.OnCancelListener {
        b() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        @SuppressLint({"SyntheticAccessor"})
        public void onCancel(DialogInterface dialogInterface) {
            if (e.this.r1 != null) {
                e eVar = e.this;
                eVar.onCancel(eVar.r1);
            }
        }
    }

    class c implements DialogInterface.OnDismissListener {
        c() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        @SuppressLint({"SyntheticAccessor"})
        public void onDismiss(DialogInterface dialogInterface) {
            if (e.this.r1 != null) {
                e eVar = e.this;
                eVar.onDismiss(eVar.r1);
            }
        }
    }

    class d implements ax.F0.l<ax.F0.g> {
        d() {
        }

        @Override // ax.F0.l
        @SuppressLint({"SyntheticAccessor"})
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(ax.F0.g gVar) {
            if (gVar == null || !e.this.n1) {
                return;
            }
            View viewE2 = e.this.E2();
            if (viewE2.getParent() != null) {
                throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }
            if (e.this.r1 != null) {
                if (m.H0(3)) {
                    Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + e.this.r1);
                }
                e.this.r1.setContentView(viewE2);
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.e$e, reason: collision with other inner class name */
    class C0018e extends ax.p351z0.e {
        final /* synthetic */ ax.p351z0.e q;

        C0018e(ax.p351z0.e eVar) {
            this.q = eVar;
        }

        @Override // ax.p351z0.e
        public View c(int i) {
            return this.q.d() ? this.q.c(i) : e.this.h3(i);
        }

        @Override // ax.p351z0.e
        public boolean d() {
            return this.q.d() || e.this.i3();
        }
    }

    private void c3(boolean z, boolean z2, boolean z3) {
        if (this.t1) {
            return;
        }
        this.t1 = true;
        this.u1 = false;
        Dialog dialog = this.r1;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.r1.dismiss();
            if (!z2) {
                if (Looper.myLooper() == this.g1.getLooper()) {
                    onDismiss(this.r1);
                } else {
                    this.g1.post(this.h1);
                }
            }
        }
        this.s1 = true;
        if (this.o1 >= 0) {
            if (z3) {
                N0().c1(this.o1, 1);
            } else {
                N0().a1(this.o1, 1, z);
            }
            this.o1 = -1;
            return;
        }
        t tVarO = N0().o();
        tVarO.u(true);
        tVarO.q(this);
        if (z3) {
            tVarO.k();
        } else if (z) {
            tVarO.j();
        } else {
            tVarO.i();
        }
    }

    private void j3(Bundle bundle) {
        if (this.n1 && !this.v1) {
            try {
                this.p1 = true;
                Dialog dialogG3 = g3(bundle);
                this.r1 = dialogG3;
                if (this.n1) {
                    n3(dialogG3, this.k1);
                    Context context = getContext();
                    if (context instanceof Activity) {
                        this.r1.setOwnerActivity((Activity) context);
                    }
                    this.r1.setCancelable(this.m1);
                    this.r1.setOnCancelListener(this.i1);
                    this.r1.setOnDismissListener(this.j1);
                    this.v1 = true;
                } else {
                    this.r1 = null;
                }
            } finally {
                this.p1 = false;
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void B1(Bundle bundle) {
        super.B1(bundle);
        this.g1 = new Handler();
        this.n1 = this.B0 == 0;
        if (bundle != null) {
            this.k1 = bundle.getInt("android:style", 0);
            this.l1 = bundle.getInt("android:theme", 0);
            this.m1 = bundle.getBoolean("android:cancelable", true);
            this.n1 = bundle.getBoolean("android:showsDialog", this.n1);
            this.o1 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void I1() {
        super.I1();
        Dialog dialog = this.r1;
        if (dialog != null) {
            this.s1 = true;
            dialog.setOnDismissListener(null);
            this.r1.dismiss();
            if (!this.t1) {
                onDismiss(this.r1);
            }
            this.r1 = null;
            this.v1 = false;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void J1() {
        super.J1();
        if (!this.u1 && !this.t1) {
            this.t1 = true;
        }
        h1().m(this.q1);
    }

    @Override // androidx.fragment.app.Fragment
    public LayoutInflater K1(Bundle bundle) {
        LayoutInflater layoutInflaterK1 = super.K1(bundle);
        if (this.n1 && !this.p1) {
            j3(bundle);
            if (m.H0(2)) {
                Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
            }
            Dialog dialog = this.r1;
            return dialog != null ? layoutInflaterK1.cloneInContext(dialog.getContext()) : layoutInflaterK1;
        }
        if (m.H0(2)) {
            String str = "getting layout inflater for DialogFragment " + this;
            if (this.n1) {
                Log.d("FragmentManager", "mCreatingDialog = true: " + str);
            } else {
                Log.d("FragmentManager", "mShowsDialog = false: " + str);
            }
        }
        return layoutInflaterK1;
    }

    @Override // androidx.fragment.app.Fragment
    public void W1(Bundle bundle) {
        super.W1(bundle);
        Dialog dialog = this.r1;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i = this.k1;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.l1;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.m1;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.n1;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.o1;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void X1() {
        super.X1();
        Dialog dialog = this.r1;
        if (dialog != null) {
            this.s1 = false;
            dialog.show();
            View decorView = this.r1.getWindow().getDecorView();
            ax.F0.u.a(decorView, this);
            ax.F0.v.a(decorView, this);
            ax.p016b1.e.a(decorView, this);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void Y1() {
        super.Y1();
        Dialog dialog = this.r1;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void a2(Bundle bundle) {
        Bundle bundle2;
        super.a2(bundle);
        if (this.r1 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.r1.onRestoreInstanceState(bundle2);
    }

    public void a3() {
        c3(false, false, false);
    }

    public void b3() {
        c3(true, false, false);
    }

    public Dialog d3() {
        return this.r1;
    }

    public boolean e3() {
        return this.n1;
    }

    public int f3() {
        return this.l1;
    }

    public Dialog g3(Bundle bundle) {
        if (m.H0(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new ax.p112i.j(D2(), f3());
    }

    @Override // androidx.fragment.app.Fragment
    void h2(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.h2(layoutInflater, viewGroup, bundle);
        if (this.L0 != null || this.r1 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.r1.onRestoreInstanceState(bundle2);
    }

    View h3(int i) {
        Dialog dialog = this.r1;
        if (dialog != null) {
            return dialog.findViewById(i);
        }
        return null;
    }

    boolean i3() {
        return this.v1;
    }

    public final Dialog k3() {
        Dialog dialogD3 = d3();
        if (dialogD3 != null) {
            return dialogD3;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    public void l3(boolean z) {
        this.m1 = z;
        Dialog dialog = this.r1;
        if (dialog != null) {
            dialog.setCancelable(z);
        }
    }

    public void m3(boolean z) {
        this.n1 = z;
    }

    public void n3(Dialog dialog, int i) {
        if (i != 1 && i != 2) {
            if (i != 3) {
                return;
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    @Override // androidx.fragment.app.Fragment
    ax.p351z0.e o0() {
        return new C0018e(super.o0());
    }

    public int o3(t tVar, String str) {
        this.t1 = false;
        this.u1 = true;
        tVar.e(this, str);
        this.s1 = false;
        int i = tVar.i();
        this.o1 = i;
        return i;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.s1) {
            return;
        }
        if (m.H0(3)) {
            Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
        }
        c3(true, true, false);
    }

    public void p3(m mVar, String str) {
        this.t1 = false;
        this.u1 = true;
        t tVarO = mVar.o();
        tVarO.u(true);
        tVarO.e(this, str);
        tVarO.i();
    }

    @Override // androidx.fragment.app.Fragment
    @Deprecated
    public void v1(Bundle bundle) {
        super.v1(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public void y1(Context context) {
        super.y1(context);
        h1().i(this.q1);
        if (this.u1) {
            return;
        }
        this.t1 = false;
    }
}
