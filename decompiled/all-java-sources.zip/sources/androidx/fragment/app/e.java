package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public class e extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    private Handler j1;
    private boolean s1;
    private Dialog u1;
    private boolean v1;
    private boolean w1;
    private boolean x1;
    private Runnable k1 = new a();
    private DialogInterface.OnCancelListener l1 = new b();
    private DialogInterface.OnDismissListener m1 = new c();
    private int n1 = 0;
    private int o1 = 0;
    private boolean p1 = true;
    private boolean q1 = true;
    private int r1 = -1;
    private ax.G0.m<ax.G0.h> t1 = new d();
    private boolean y1 = false;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        @SuppressLint({"SyntheticAccessor"})
        public void run() {
            e.this.m1.onDismiss(e.this.u1);
        }
    }

    class b implements DialogInterface.OnCancelListener {
        b() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        @SuppressLint({"SyntheticAccessor"})
        public void onCancel(DialogInterface dialogInterface) {
            if (e.this.u1 != null) {
                e eVar = e.this;
                eVar.onCancel(eVar.u1);
            }
        }
    }

    class c implements DialogInterface.OnDismissListener {
        c() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        @SuppressLint({"SyntheticAccessor"})
        public void onDismiss(DialogInterface dialogInterface) {
            if (e.this.u1 != null) {
                e eVar = e.this;
                eVar.onDismiss(eVar.u1);
            }
        }
    }

    class d implements ax.G0.m<ax.G0.h> {
        d() {
        }

        @Override // ax.G0.m
        @SuppressLint({"SyntheticAccessor"})
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(ax.G0.h hVar) {
            if (hVar == null || !e.this.q1) {
                return;
            }
            View viewA2 = e.this.A2();
            if (viewA2.getParent() != null) {
                throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }
            if (e.this.u1 != null) {
                if (FragmentManager.J0(3)) {
                    Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + e.this.u1);
                }
                e.this.u1.setContentView(viewA2);
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.e$e, reason: collision with other inner class name */
    class C0020e extends ax.A0.e {
        final /* synthetic */ ax.A0.e q;

        C0020e(ax.A0.e eVar) {
            this.q = eVar;
        }

        @Override // ax.A0.e
        public View c(int i) {
            return this.q.d() ? this.q.c(i) : e.this.e3(i);
        }

        @Override // ax.A0.e
        public boolean d() {
            return this.q.d() || e.this.f3();
        }
    }

    private void Z2(boolean z, boolean z2, boolean z3) {
        if (this.w1) {
            return;
        }
        this.w1 = true;
        this.x1 = false;
        Dialog dialog = this.u1;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.u1.dismiss();
            if (!z2) {
                if (Looper.myLooper() == this.j1.getLooper()) {
                    onDismiss(this.u1);
                } else {
                    this.j1.post(this.k1);
                }
            }
        }
        this.v1 = true;
        if (this.r1 >= 0) {
            if (z3) {
                J0().a1(this.r1, 1);
            } else {
                J0().Y0(this.r1, 1, z);
            }
            this.r1 = -1;
            return;
        }
        t tVarO = J0().o();
        tVarO.u(true);
        tVarO.q(this);
        if (z3) {
            tVarO.k();
        } else if (z) {
            tVarO.j();
        } else {
            tVarO.i();
        }
    }

    private void g3(Bundle bundle) {
        if (this.q1 && !this.y1) {
            try {
                this.s1 = true;
                Dialog dialogD3 = d3(bundle);
                this.u1 = dialogD3;
                if (this.q1) {
                    k3(dialogD3, this.n1);
                    Context context = getContext();
                    if (context instanceof Activity) {
                        this.u1.setOwnerActivity((Activity) context);
                    }
                    this.u1.setCancelable(this.p1);
                    this.u1.setOnCancelListener(this.l1);
                    this.u1.setOnDismissListener(this.m1);
                    this.y1 = true;
                } else {
                    this.u1 = null;
                }
            } finally {
                this.s1 = false;
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void E1() {
        super.E1();
        Dialog dialog = this.u1;
        if (dialog != null) {
            this.v1 = true;
            dialog.setOnDismissListener(null);
            this.u1.dismiss();
            if (!this.w1) {
                onDismiss(this.u1);
            }
            this.u1 = null;
            this.y1 = false;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void F1() {
        super.F1();
        if (!this.x1 && !this.w1) {
            this.w1 = true;
        }
        c1().m(this.t1);
    }

    @Override // androidx.fragment.app.Fragment
    public LayoutInflater G1(Bundle bundle) {
        LayoutInflater layoutInflaterG1 = super.G1(bundle);
        if (this.q1 && !this.s1) {
            g3(bundle);
            if (FragmentManager.J0(2)) {
                Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
            }
            Dialog dialog = this.u1;
            if (dialog != null) {
                return layoutInflaterG1.cloneInContext(dialog.getContext());
            }
        } else if (FragmentManager.J0(2)) {
            String str = "getting layout inflater for DialogFragment " + this;
            if (!this.q1) {
                Log.d("FragmentManager", "mShowsDialog = false: " + str);
                return layoutInflaterG1;
            }
            Log.d("FragmentManager", "mCreatingDialog = true: " + str);
        }
        return layoutInflaterG1;
    }

    @Override // androidx.fragment.app.Fragment
    public void S1(Bundle bundle) {
        super.S1(bundle);
        Dialog dialog = this.u1;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i = this.n1;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.o1;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.p1;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.q1;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.r1;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void T1() {
        super.T1();
        Dialog dialog = this.u1;
        if (dialog != null) {
            this.v1 = false;
            dialog.show();
            View decorView = this.u1.getWindow().getDecorView();
            ax.G0.w.a(decorView, this);
            ax.G0.x.a(decorView, this);
            ax.p245p2.e.a(decorView, this);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void U1() {
        super.U1();
        Dialog dialog = this.u1;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void W1(Bundle bundle) {
        Bundle bundle2;
        super.W1(bundle);
        if (this.u1 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.u1.onRestoreInstanceState(bundle2);
    }

    public void X2() {
        Z2(false, false, false);
    }

    public void Y2() {
        Z2(true, false, false);
    }

    public Dialog a3() {
        return this.u1;
    }

    public boolean b3() {
        return this.q1;
    }

    public int c3() {
        return this.o1;
    }

    @Override // androidx.fragment.app.Fragment
    void d2(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.d2(layoutInflater, viewGroup, bundle);
        if (this.O0 != null || this.u1 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.u1.onRestoreInstanceState(bundle2);
    }

    public Dialog d3(Bundle bundle) {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new ax.p130i.n(z2(), c3());
    }

    View e3(int i) {
        Dialog dialog = this.u1;
        if (dialog != null) {
            return dialog.findViewById(i);
        }
        return null;
    }

    boolean f3() {
        return this.y1;
    }

    public final Dialog h3() {
        Dialog dialogA3 = a3();
        if (dialogA3 != null) {
            return dialogA3;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    public void i3(boolean z) {
        this.p1 = z;
        Dialog dialog = this.u1;
        if (dialog != null) {
            dialog.setCancelable(z);
        }
    }

    public void j3(boolean z) {
        this.q1 = z;
    }

    @Override // androidx.fragment.app.Fragment
    ax.A0.e k0() {
        return new C0020e(super.k0());
    }

    public void k3(Dialog dialog, int i) {
        if (i != 1 && i != 2) {
            if (i != 3) {
                return;
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    public int l3(t tVar, String str) {
        this.w1 = false;
        this.x1 = true;
        tVar.e(this, str);
        this.v1 = false;
        int i = tVar.i();
        this.r1 = i;
        return i;
    }

    public void m3(FragmentManager fragmentManager, String str) {
        this.w1 = false;
        this.x1 = true;
        t tVarO = fragmentManager.o();
        tVarO.u(true);
        tVarO.e(this, str);
        tVarO.i();
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.v1) {
            return;
        }
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
        }
        Z2(true, true, false);
    }

    @Override // androidx.fragment.app.Fragment
    @Deprecated
    public void r1(Bundle bundle) {
        super.r1(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public void u1(Context context) {
        super.u1(context);
        c1().i(this.t1);
        if (this.x1) {
            return;
        }
        this.w1 = false;
    }

    @Override // androidx.fragment.app.Fragment
    public void x1(Bundle bundle) {
        super.x1(bundle);
        this.j1 = new Handler();
        this.q1 = this.E0 == 0;
        if (bundle != null) {
            this.n1 = bundle.getInt("android:style", 0);
            this.o1 = bundle.getInt("android:theme", 0);
            this.p1 = bundle.getBoolean("android:cancelable", true);
            this.q1 = bundle.getBoolean("android:showsDialog", this.q1);
            this.r1 = bundle.getInt("android:backStackId", -1);
        }
    }
}
