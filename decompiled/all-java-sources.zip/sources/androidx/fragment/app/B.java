package androidx.fragment.app;

import android.util.AndroidRuntimeException;

/* JADX INFO: loaded from: classes.dex */
final class B extends AndroidRuntimeException {
    public B(String str) {
        super(str);
    }
}
