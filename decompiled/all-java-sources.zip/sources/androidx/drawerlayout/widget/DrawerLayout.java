package androidx.drawerlayout.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import ax.p035c0.C1832a;
import ax.p035c0.C1839d0;
import ax.p035c0.C1869t;
import ax.p035c0.F0;
import ax.p051d0.H;
import ax.p051d0.M;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class DrawerLayout extends ViewGroup {
    private static final int[] U0 = {R.attr.colorPrimaryDark};
    static final int[] V0 = {R.attr.layout_gravity};
    static final boolean W0;
    private static final boolean X0;
    private static boolean Y0;
    private boolean A0;
    private e B0;
    private List<e> C0;
    private float D0;
    private float E0;
    private Drawable F0;
    private Drawable G0;
    private Drawable H0;
    private CharSequence I0;
    private CharSequence J0;
    private Object K0;
    private boolean L0;
    private Drawable M0;
    private Drawable N0;
    private Drawable O0;
    private Drawable P0;
    private final ArrayList<View> Q0;
    private Rect R0;
    private Matrix S0;
    private final M T0;
    private float k0;
    private int l0;
    private int m0;
    private float n0;
    private Paint o0;
    private final ax.p179l0.c p0;
    private final d q;
    private final ax.p179l0.c q0;
    private final h r0;
    private final h s0;
    private int t0;
    private boolean u0;
    private boolean v0;
    private int w0;
    private int x0;
    private int y0;
    private int z0;

    class a implements M {
        a() {
        }

        @Override // ax.p051d0.M
        public boolean a(View view, M.a aVar) {
            if (!DrawerLayout.this.D(view) || DrawerLayout.this.r(view) == 2) {
                return false;
            }
            DrawerLayout.this.f(view);
            return true;
        }
    }

    class b implements View.OnApplyWindowInsetsListener {
        b() {
        }

        @Override // android.view.View.OnApplyWindowInsetsListener
        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            ((DrawerLayout) view).S(windowInsets, windowInsets.getSystemWindowInsetTop() > 0);
            return windowInsets.consumeSystemWindowInsets();
        }
    }

    class c extends C1832a {
        private final Rect d = new Rect();

        c() {
        }

        private void n(H h, ViewGroup viewGroup) {
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                if (DrawerLayout.A(childAt)) {
                    h.c(childAt);
                }
            }
        }

        private void o(H h, H h2) {
            Rect rect = this.d;
            h2.n(rect);
            h.j0(rect);
            h.O0(h2.Y());
            h.A0(h2.y());
            h.m0(h2.q());
            h.q0(h2.t());
            h.s0(h2.N());
            h.v0(h2.P());
            h.g0(h2.I());
            h.H0(h2.V());
            h.a(h2.k());
        }

        @Override // ax.p035c0.C1832a
        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            if (accessibilityEvent.getEventType() != 32) {
                return super.a(view, accessibilityEvent);
            }
            List<CharSequence> text = accessibilityEvent.getText();
            View viewP = DrawerLayout.this.p();
            if (viewP == null) {
                return true;
            }
            CharSequence charSequenceS = DrawerLayout.this.s(DrawerLayout.this.t(viewP));
            if (charSequenceS == null) {
                return true;
            }
            text.add(charSequenceS);
            return true;
        }

        @Override // ax.p035c0.C1832a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            accessibilityEvent.setClassName("androidx.drawerlayout.widget.DrawerLayout");
        }

        @Override // ax.p035c0.C1832a
        public void g(View view, H h) {
            if (DrawerLayout.W0) {
                super.g(view, h);
            } else {
                H hB0 = H.b0(h);
                super.g(view, hB0);
                h.J0(view);
                Object objF = C1839d0.F(view);
                if (objF instanceof View) {
                    h.C0((View) objF);
                }
                o(h, hB0);
                hB0.d0();
                n(h, (ViewGroup) view);
            }
            h.m0("androidx.drawerlayout.widget.DrawerLayout");
            h.u0(false);
            h.v0(false);
            h.e0(H.a.e);
            h.e0(H.a.f);
        }

        @Override // ax.p035c0.C1832a
        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            if (DrawerLayout.W0 || DrawerLayout.A(view)) {
                return super.i(viewGroup, view, accessibilityEvent);
            }
            return false;
        }
    }

    static final class d extends C1832a {
        d() {
        }

        @Override // ax.p035c0.C1832a
        public void g(View view, H h) {
            super.g(view, h);
            if (DrawerLayout.A(view)) {
                return;
            }
            h.C0(null);
        }
    }

    public interface e {
        void a(View view);

        void b(View view);

        void c(int i);

        void d(View view, float f);
    }

    public static class f extends ViewGroup.MarginLayoutParams {
        public int a;
        float b;
        boolean c;
        int d;

        public f(int i, int i2) {
            super(i, i2);
            this.a = 0;
        }

        public f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.a = 0;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.V0);
            this.a = typedArrayObtainStyledAttributes.getInt(0, 0);
            typedArrayObtainStyledAttributes.recycle();
        }

        public f(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.a = 0;
        }

        public f(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.a = 0;
        }

        public f(f fVar) {
            super((ViewGroup.MarginLayoutParams) fVar);
            this.a = 0;
            this.a = fVar.a;
        }
    }

    protected static class g extends ax.p163k0.a {
        public static final Parcelable.Creator<g> CREATOR = new a();
        int Y;
        int Z;
        int k0;
        int l0;
        int m0;

        class a implements Parcelable.ClassLoaderCreator<g> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public g[] newArray(int i) {
                return new g[i];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.Y = 0;
            this.Y = parcel.readInt();
            this.Z = parcel.readInt();
            this.k0 = parcel.readInt();
            this.l0 = parcel.readInt();
            this.m0 = parcel.readInt();
        }

        public g(Parcelable parcelable) {
            super(parcelable);
            this.Y = 0;
        }

        @Override // ax.p163k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeInt(this.Z);
            parcel.writeInt(this.k0);
            parcel.writeInt(this.l0);
            parcel.writeInt(this.m0);
        }
    }

    private class h extends ax.p179l0.c.AbstractC0376c {
        private final int a;
        private ax.p179l0.c b;
        private final Runnable c = new a();

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                h.this.o();
            }
        }

        h(int i) {
            this.a = i;
        }

        private void n() {
            View viewN = DrawerLayout.this.n(this.a == 3 ? 5 : 3);
            if (viewN != null) {
                DrawerLayout.this.f(viewN);
            }
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public int a(View view, int i, int i2) {
            if (DrawerLayout.this.c(view, 3)) {
                return Math.max(-view.getWidth(), Math.min(i, 0));
            }
            int width = DrawerLayout.this.getWidth();
            return Math.max(width - view.getWidth(), Math.min(i, width));
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public int b(View view, int i, int i2) {
            return view.getTop();
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public int d(View view) {
            if (DrawerLayout.this.E(view)) {
                return view.getWidth();
            }
            return 0;
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void f(int i, int i2) {
            View viewN = (i & 1) == 1 ? DrawerLayout.this.n(3) : DrawerLayout.this.n(5);
            if (viewN == null || DrawerLayout.this.r(viewN) != 0) {
                return;
            }
            this.b.b(viewN, i2);
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public boolean g(int i) {
            return false;
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void h(int i, int i2) {
            DrawerLayout.this.postDelayed(this.c, 160L);
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void i(View view, int i) {
            ((f) view.getLayoutParams()).c = false;
            n();
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void j(int i) {
            DrawerLayout.this.X(i, this.b.v());
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void k(View view, int i, int i2, int i3, int i4) {
            int width = view.getWidth();
            float width2 = (DrawerLayout.this.c(view, 3) ? i + width : DrawerLayout.this.getWidth() - i) / width;
            DrawerLayout.this.U(view, width2);
            view.setVisibility(width2 == 0.0f ? 4 : 0);
            DrawerLayout.this.invalidate();
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public void l(View view, float f, float f2) {
            int i;
            float fU = DrawerLayout.this.u(view);
            int width = view.getWidth();
            if (DrawerLayout.this.c(view, 3)) {
                i = (f > 0.0f || (f == 0.0f && fU > 0.5f)) ? 0 : -width;
            } else {
                int width2 = DrawerLayout.this.getWidth();
                if (f < 0.0f || (f == 0.0f && fU > 0.5f)) {
                    width2 -= width;
                }
                i = width2;
            }
            this.b.O(i, view.getTop());
            DrawerLayout.this.invalidate();
        }

        @Override // ax.p179l0.c.AbstractC0376c
        public boolean m(View view, int i) {
            return DrawerLayout.this.E(view) && DrawerLayout.this.c(view, this.a) && DrawerLayout.this.r(view) == 0;
        }

        void o() {
            View viewN;
            int width;
            int iX = this.b.x();
            boolean z = this.a == 3;
            if (z) {
                viewN = DrawerLayout.this.n(3);
                width = (viewN != null ? -viewN.getWidth() : 0) + iX;
            } else {
                viewN = DrawerLayout.this.n(5);
                width = DrawerLayout.this.getWidth() - iX;
            }
            if (viewN != null) {
                if (((!z || viewN.getLeft() >= width) && (z || viewN.getLeft() <= width)) || DrawerLayout.this.r(viewN) != 0) {
                    return;
                }
                f fVar = (f) viewN.getLayoutParams();
                this.b.Q(viewN, width, viewN.getTop());
                fVar.c = true;
                DrawerLayout.this.invalidate();
                n();
                DrawerLayout.this.b();
            }
        }

        public void p() {
            DrawerLayout.this.removeCallbacks(this.c);
        }

        public void q(ax.p179l0.c cVar) {
            this.b = cVar;
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
        W0 = true;
        X0 = true;
        Y0 = i >= 29;
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p291s0.a.a);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q = new d();
        this.m0 = -1728053248;
        this.o0 = new Paint();
        this.v0 = true;
        this.w0 = 3;
        this.x0 = 3;
        this.y0 = 3;
        this.z0 = 3;
        this.M0 = null;
        this.N0 = null;
        this.O0 = null;
        this.P0 = null;
        this.T0 = new a();
        setDescendantFocusability(262144);
        float f2 = getResources().getDisplayMetrics().density;
        this.l0 = (int) ((64.0f * f2) + 0.5f);
        float f3 = f2 * 400.0f;
        h hVar = new h(3);
        this.r0 = hVar;
        h hVar2 = new h(5);
        this.s0 = hVar2;
        ax.p179l0.c cVarN = ax.p179l0.c.n(this, 1.0f, hVar);
        this.p0 = cVarN;
        cVarN.M(1);
        cVarN.N(f3);
        hVar.q(cVarN);
        ax.p179l0.c cVarN2 = ax.p179l0.c.n(this, 1.0f, hVar2);
        this.q0 = cVarN2;
        cVarN2.M(2);
        cVarN2.N(f3);
        hVar2.q(cVarN2);
        setFocusableInTouchMode(true);
        C1839d0.s0(this, 1);
        C1839d0.l0(this, new c());
        setMotionEventSplittingEnabled(false);
        if (C1839d0.y(this)) {
            setOnApplyWindowInsetsListener(new b());
            setSystemUiVisibility(1280);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(U0);
            try {
                this.F0 = typedArrayObtainStyledAttributes.getDrawable(0);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, ax.p291s0.c.b, i, 0);
        try {
            int i2 = ax.p291s0.c.c;
            if (typedArrayObtainStyledAttributes2.hasValue(i2)) {
                this.k0 = typedArrayObtainStyledAttributes2.getDimension(i2, 0.0f);
            } else {
                this.k0 = getResources().getDimension(ax.p291s0.b.a);
            }
            typedArrayObtainStyledAttributes2.recycle();
            this.Q0 = new ArrayList<>();
        } catch (Throwable th2) {
            typedArrayObtainStyledAttributes2.recycle();
            throw th2;
        }
    }

    static boolean A(View view) {
        return (C1839d0.z(view) == 4 || C1839d0.z(view) == 2) ? false : true;
    }

    private boolean H(float f2, float f3, View view) {
        if (this.R0 == null) {
            this.R0 = new Rect();
        }
        view.getHitRect(this.R0);
        return this.R0.contains((int) f2, (int) f3);
    }

    private void I(Drawable drawable, int i) {
        if (drawable == null || !ax.U.a.h(drawable)) {
            return;
        }
        ax.U.a.m(drawable, i);
    }

    private Drawable P() {
        int iB = C1839d0.B(this);
        if (iB == 0) {
            Drawable drawable = this.M0;
            if (drawable != null) {
                I(drawable, iB);
                return this.M0;
            }
        } else {
            Drawable drawable2 = this.N0;
            if (drawable2 != null) {
                I(drawable2, iB);
                return this.N0;
            }
        }
        return this.O0;
    }

    private Drawable Q() {
        int iB = C1839d0.B(this);
        if (iB == 0) {
            Drawable drawable = this.N0;
            if (drawable != null) {
                I(drawable, iB);
                return this.N0;
            }
        } else {
            Drawable drawable2 = this.M0;
            if (drawable2 != null) {
                I(drawable2, iB);
                return this.M0;
            }
        }
        return this.P0;
    }

    private void R() {
        if (X0) {
            return;
        }
        this.G0 = P();
        this.H0 = Q();
    }

    private void V(View view) {
        H.a aVar = H.a.y;
        C1839d0.f0(view, aVar.b());
        if (!D(view) || r(view) == 2) {
            return;
        }
        C1839d0.h0(view, aVar, null, this.T0);
    }

    private void W(View view, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((z || E(childAt)) && !(z && childAt == view)) {
                C1839d0.s0(childAt, 4);
            } else {
                C1839d0.s0(childAt, 1);
            }
        }
    }

    private boolean m(MotionEvent motionEvent, View view) {
        if (!view.getMatrix().isIdentity()) {
            MotionEvent motionEventV = v(motionEvent, view);
            boolean zDispatchGenericMotionEvent = view.dispatchGenericMotionEvent(motionEventV);
            motionEventV.recycle();
            return zDispatchGenericMotionEvent;
        }
        float scrollX = getScrollX() - view.getLeft();
        float scrollY = getScrollY() - view.getTop();
        motionEvent.offsetLocation(scrollX, scrollY);
        boolean zDispatchGenericMotionEvent2 = view.dispatchGenericMotionEvent(motionEvent);
        motionEvent.offsetLocation(-scrollX, -scrollY);
        return zDispatchGenericMotionEvent2;
    }

    private MotionEvent v(MotionEvent motionEvent, View view) {
        float scrollX = getScrollX() - view.getLeft();
        float scrollY = getScrollY() - view.getTop();
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(scrollX, scrollY);
        Matrix matrix = view.getMatrix();
        if (!matrix.isIdentity()) {
            if (this.S0 == null) {
                this.S0 = new Matrix();
            }
            matrix.invert(this.S0);
            motionEventObtain.transform(this.S0);
        }
        return motionEventObtain;
    }

    static String w(int i) {
        if ((i & 3) == 3) {
            return "LEFT";
        }
        return (i & 5) == 5 ? "RIGHT" : Integer.toHexString(i);
    }

    private static boolean x(View view) {
        Drawable background = view.getBackground();
        return background != null && background.getOpacity() == -1;
    }

    private boolean y() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            if (((f) getChildAt(i).getLayoutParams()).c) {
                return true;
            }
        }
        return false;
    }

    private boolean z() {
        return p() != null;
    }

    boolean B(View view) {
        return ((f) view.getLayoutParams()).a == 0;
    }

    public boolean C(int i) {
        View viewN = n(i);
        if (viewN != null) {
            return D(viewN);
        }
        return false;
    }

    public boolean D(View view) {
        if (E(view)) {
            return (((f) view.getLayoutParams()).d & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    boolean E(View view) {
        int iB = C1869t.b(((f) view.getLayoutParams()).a, C1839d0.B(view));
        return ((iB & 3) == 0 && (iB & 5) == 0) ? false : true;
    }

    public boolean F(int i) {
        View viewN = n(i);
        if (viewN != null) {
            return G(viewN);
        }
        return false;
    }

    public boolean G(View view) {
        if (E(view)) {
            return ((f) view.getLayoutParams()).b > 0.0f;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    void J(View view, float f2) {
        float fU = u(view);
        float width = view.getWidth();
        int i = ((int) (width * f2)) - ((int) (fU * width));
        if (!c(view, 3)) {
            i = -i;
        }
        view.offsetLeftAndRight(i);
        U(view, f2);
    }

    public void K(int i) {
        L(i, true);
    }

    public void L(int i, boolean z) {
        View viewN = n(i);
        if (viewN != null) {
            N(viewN, z);
            return;
        }
        throw new IllegalArgumentException("No drawer view found with gravity " + w(i));
    }

    public void M(View view) {
        N(view, true);
    }

    public void N(View view, boolean z) {
        if (!E(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        f fVar = (f) view.getLayoutParams();
        if (this.v0) {
            fVar.b = 1.0f;
            fVar.d = 1;
            W(view, true);
            V(view);
        } else if (z) {
            fVar.d |= 2;
            if (c(view, 3)) {
                this.p0.Q(view, 0, view.getTop());
            } else {
                this.q0.Q(view, getWidth() - view.getWidth(), view.getTop());
            }
        } else {
            J(view, 1.0f);
            X(0, view);
            view.setVisibility(0);
        }
        invalidate();
    }

    public void O(e eVar) {
        List<e> list;
        if (eVar == null || (list = this.C0) == null) {
            return;
        }
        list.remove(eVar);
    }

    public void S(Object obj, boolean z) {
        this.K0 = obj;
        this.L0 = z;
        setWillNotDraw(!z && getBackground() == null);
        requestLayout();
    }

    public void T(int i, int i2) {
        View viewN;
        int iB = C1869t.b(i2, C1839d0.B(this));
        if (i2 == 3) {
            this.w0 = i;
        } else if (i2 == 5) {
            this.x0 = i;
        } else if (i2 == 8388611) {
            this.y0 = i;
        } else if (i2 == 8388613) {
            this.z0 = i;
        }
        if (i != 0) {
            (iB == 3 ? this.p0 : this.q0).a();
        }
        if (i != 1) {
            if (i == 2 && (viewN = n(iB)) != null) {
                M(viewN);
                return;
            }
            return;
        }
        View viewN2 = n(iB);
        if (viewN2 != null) {
            f(viewN2);
        }
    }

    void U(View view, float f2) {
        f fVar = (f) view.getLayoutParams();
        if (f2 == fVar.b) {
            return;
        }
        fVar.b = f2;
        l(view, f2);
    }

    void X(int i, View view) {
        int i2;
        int iA = this.p0.A();
        int iA2 = this.q0.A();
        if (iA == 1 || iA2 == 1) {
            i2 = 1;
        } else {
            i2 = 2;
            if (iA != 2 && iA2 != 2) {
                i2 = 0;
            }
        }
        if (view != null && i == 0) {
            float f2 = ((f) view.getLayoutParams()).b;
            if (f2 == 0.0f) {
                j(view);
            } else if (f2 == 1.0f) {
                k(view);
            }
        }
        if (i2 != this.t0) {
            this.t0 = i2;
            List<e> list = this.C0;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.C0.get(size).c(i2);
                }
            }
        }
    }

    public void a(e eVar) {
        if (eVar == null) {
            return;
        }
        if (this.C0 == null) {
            this.C0 = new ArrayList();
        }
        this.C0.add(eVar);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        if (getDescendantFocusability() == 393216) {
            return;
        }
        int childCount = getChildCount();
        boolean z = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (!E(childAt)) {
                this.Q0.add(childAt);
            } else if (D(childAt)) {
                childAt.addFocusables(arrayList, i, i2);
                z = true;
            }
        }
        if (!z) {
            int size = this.Q0.size();
            for (int i4 = 0; i4 < size; i4++) {
                View view = this.Q0.get(i4);
                if (view.getVisibility() == 0) {
                    view.addFocusables(arrayList, i, i2);
                }
            }
        }
        this.Q0.clear();
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (o() != null || E(view)) {
            C1839d0.s0(view, 4);
        } else {
            C1839d0.s0(view, 1);
        }
        if (W0) {
            return;
        }
        C1839d0.l0(view, this.q);
    }

    void b() {
        if (this.A0) {
            return;
        }
        long jUptimeMillis = SystemClock.uptimeMillis();
        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            getChildAt(i).dispatchTouchEvent(motionEventObtain);
        }
        motionEventObtain.recycle();
        this.A0 = true;
    }

    boolean c(View view, int i) {
        return (t(view) & i) == i;
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof f) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        int childCount = getChildCount();
        float fMax = 0.0f;
        for (int i = 0; i < childCount; i++) {
            fMax = Math.max(fMax, ((f) getChildAt(i).getLayoutParams()).b);
        }
        this.n0 = fMax;
        boolean zM = this.p0.m(true);
        boolean zM2 = this.q0.m(true);
        if (zM || zM2) {
            C1839d0.c0(this);
        }
    }

    public void d(int i) {
        e(i, true);
    }

    @Override // android.view.View
    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.n0 <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        for (int i = childCount - 1; i >= 0; i--) {
            View childAt = getChildAt(i);
            if (H(x, y, childAt) && !B(childAt) && m(motionEvent, childAt)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j) {
        int height = getHeight();
        boolean zB = B(view);
        int width = getWidth();
        int iSave = canvas.save();
        int i = 0;
        if (zB) {
            int childCount = getChildCount();
            int i2 = 0;
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt != view && childAt.getVisibility() == 0 && x(childAt) && E(childAt) && childAt.getHeight() >= height) {
                    if (c(childAt, 3)) {
                        int right = childAt.getRight();
                        if (right > i2) {
                            i2 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i2, 0, width, getHeight());
            i = i2;
        }
        boolean zDrawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(iSave);
        float f2 = this.n0;
        if (f2 > 0.0f && zB) {
            int i4 = this.m0;
            this.o0.setColor((i4 & 16777215) | (((int) ((((-16777216) & i4) >>> 24) * f2)) << 24));
            canvas.drawRect(i, 0.0f, width, getHeight(), this.o0);
            return zDrawChild;
        }
        if (this.G0 != null && c(view, 3)) {
            int intrinsicWidth = this.G0.getIntrinsicWidth();
            int right2 = view.getRight();
            float fMax = Math.max(0.0f, Math.min(right2 / this.p0.x(), 1.0f));
            this.G0.setBounds(right2, view.getTop(), intrinsicWidth + right2, view.getBottom());
            this.G0.setAlpha((int) (fMax * 255.0f));
            this.G0.draw(canvas);
            return zDrawChild;
        }
        if (this.H0 != null && c(view, 5)) {
            int intrinsicWidth2 = this.H0.getIntrinsicWidth();
            int left2 = view.getLeft();
            float fMax2 = Math.max(0.0f, Math.min((getWidth() - left2) / this.q0.x(), 1.0f));
            this.H0.setBounds(left2 - intrinsicWidth2, view.getTop(), left2, view.getBottom());
            this.H0.setAlpha((int) (fMax2 * 255.0f));
            this.H0.draw(canvas);
        }
        return zDrawChild;
    }

    public void e(int i, boolean z) {
        View viewN = n(i);
        if (viewN != null) {
            g(viewN, z);
            return;
        }
        throw new IllegalArgumentException("No drawer view found with gravity " + w(i));
    }

    public void f(View view) {
        g(view, true);
    }

    public void g(View view, boolean z) {
        if (!E(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        f fVar = (f) view.getLayoutParams();
        if (this.v0) {
            fVar.b = 0.0f;
            fVar.d = 0;
        } else if (z) {
            fVar.d |= 4;
            if (c(view, 3)) {
                this.p0.Q(view, -view.getWidth(), view.getTop());
            } else {
                this.q0.Q(view, getWidth(), view.getTop());
            }
        } else {
            J(view, 0.0f);
            X(0, view);
            view.setVisibility(4);
        }
        invalidate();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new f(-1, -1);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new f(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof f) {
            return new f((f) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new f((ViewGroup.MarginLayoutParams) layoutParams) : new f(layoutParams);
    }

    public float getDrawerElevation() {
        if (X0) {
            return this.k0;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.F0;
    }

    public void h() {
        i(false);
    }

    void i(boolean z) {
        int childCount = getChildCount();
        boolean zQ = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            f fVar = (f) childAt.getLayoutParams();
            if (E(childAt) && (!z || fVar.c)) {
                zQ |= c(childAt, 3) ? this.p0.Q(childAt, -childAt.getWidth(), childAt.getTop()) : this.q0.Q(childAt, getWidth(), childAt.getTop());
                fVar.c = false;
            }
        }
        this.r0.p();
        this.s0.p();
        if (zQ) {
            invalidate();
        }
    }

    void j(View view) {
        View rootView;
        f fVar = (f) view.getLayoutParams();
        if ((fVar.d & 1) == 1) {
            fVar.d = 0;
            List<e> list = this.C0;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.C0.get(size).b(view);
                }
            }
            W(view, false);
            V(view);
            if (!hasWindowFocus() || (rootView = getRootView()) == null) {
                return;
            }
            rootView.sendAccessibilityEvent(32);
        }
    }

    void k(View view) {
        f fVar = (f) view.getLayoutParams();
        if ((fVar.d & 1) == 0) {
            fVar.d = 1;
            List<e> list = this.C0;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.C0.get(size).a(view);
                }
            }
            W(view, true);
            V(view);
            if (hasWindowFocus()) {
                sendAccessibilityEvent(32);
            }
        }
    }

    void l(View view, float f2) {
        List<e> list = this.C0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.C0.get(size).d(view, f2);
            }
        }
    }

    View n(int i) {
        int iB = C1869t.b(i, C1839d0.B(this)) & 7;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((t(childAt) & 7) == iB) {
                return childAt;
            }
        }
        return null;
    }

    View o() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((((f) childAt.getLayoutParams()).d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.v0 = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.v0 = true;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.L0 || this.F0 == null) {
            return;
        }
        Object obj = this.K0;
        int systemWindowInsetTop = obj != null ? ((WindowInsets) obj).getSystemWindowInsetTop() : 0;
        if (systemWindowInsetTop > 0) {
            this.F0.setBounds(0, 0, getWidth(), systemWindowInsetTop);
            this.F0.draw(canvas);
        }
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0031  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View viewT;
        int actionMasked = motionEvent.getActionMasked();
        boolean zP = this.p0.P(motionEvent) | this.q0.P(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                i(true);
                this.A0 = false;
            } else if (actionMasked != 2) {
                if (actionMasked == 3) {
                    i(true);
                    this.A0 = false;
                }
            } else if (this.p0.d(3)) {
                this.r0.p();
                this.s0.p();
            }
            z = false;
        } else {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            this.D0 = x;
            this.E0 = y;
            z = this.n0 > 0.0f && (viewT = this.p0.t((int) x, (int) y)) != null && B(viewT);
            this.A0 = false;
        }
        return zP || z || y() || this.A0;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !z()) {
            return super.onKeyDown(i, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View viewP = p();
        if (viewP != null && r(viewP) == 0) {
            h();
        }
        return viewP != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        WindowInsets rootWindowInsets;
        float f2;
        int i5;
        this.u0 = true;
        int i6 = i3 - i;
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (B(childAt)) {
                    int i8 = ((ViewGroup.MarginLayoutParams) fVar).leftMargin;
                    childAt.layout(i8, ((ViewGroup.MarginLayoutParams) fVar).topMargin, childAt.getMeasuredWidth() + i8, ((ViewGroup.MarginLayoutParams) fVar).topMargin + childAt.getMeasuredHeight());
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (c(childAt, 3)) {
                        float f3 = measuredWidth;
                        i5 = (-measuredWidth) + ((int) (fVar.b * f3));
                        f2 = (measuredWidth + i5) / f3;
                    } else {
                        float f4 = measuredWidth;
                        int i9 = i6 - ((int) (fVar.b * f4));
                        f2 = (i6 - i9) / f4;
                        i5 = i9;
                    }
                    boolean z2 = f2 != fVar.b;
                    int i10 = fVar.a & 112;
                    if (i10 == 16) {
                        int i11 = i4 - i2;
                        int i12 = (i11 - measuredHeight) / 2;
                        int i13 = ((ViewGroup.MarginLayoutParams) fVar).topMargin;
                        if (i12 < i13) {
                            i12 = i13;
                        } else {
                            int i14 = i12 + measuredHeight;
                            int i15 = ((ViewGroup.MarginLayoutParams) fVar).bottomMargin;
                            if (i14 > i11 - i15) {
                                i12 = (i11 - i15) - measuredHeight;
                            }
                        }
                        childAt.layout(i5, i12, measuredWidth + i5, measuredHeight + i12);
                    } else if (i10 != 80) {
                        int i16 = ((ViewGroup.MarginLayoutParams) fVar).topMargin;
                        childAt.layout(i5, i16, measuredWidth + i5, measuredHeight + i16);
                    } else {
                        int i17 = i4 - i2;
                        childAt.layout(i5, (i17 - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i5, i17 - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin);
                    }
                    if (z2) {
                        U(childAt, f2);
                    }
                    int i18 = fVar.b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i18) {
                        childAt.setVisibility(i18);
                    }
                }
            }
        }
        if (Y0 && (rootWindowInsets = getRootWindowInsets()) != null) {
            ax.T.b bVarH = F0.v(rootWindowInsets).h();
            ax.p179l0.c cVar = this.p0;
            cVar.L(Math.max(cVar.w(), bVarH.a));
            ax.p179l0.c cVar2 = this.q0;
            cVar2.L(Math.max(cVar2.w(), bVarH.c));
        }
        this.u0 = false;
        this.v0 = false;
    }

    @Override // android.view.View
    @SuppressLint({"WrongConstant"})
    protected void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i2);
        if (mode != 1073741824 || mode2 != 1073741824) {
            if (!isInEditMode()) {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
            if (mode == 0) {
                size = 300;
            }
            if (mode2 == 0) {
                size2 = 300;
            }
        }
        setMeasuredDimension(size, size2);
        boolean z = this.K0 != null && C1839d0.y(this);
        int iB = C1839d0.B(this);
        int childCount = getChildCount();
        boolean z2 = false;
        boolean z3 = false;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (z) {
                    int iB2 = C1869t.b(fVar.a, iB);
                    if (C1839d0.y(childAt)) {
                        WindowInsets windowInsetsReplaceSystemWindowInsets = (WindowInsets) this.K0;
                        if (iB2 == 3) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (iB2 == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsetsReplaceSystemWindowInsets);
                    } else {
                        WindowInsets windowInsetsReplaceSystemWindowInsets2 = (WindowInsets) this.K0;
                        if (iB2 == 3) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        } else if (iB2 == 5) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        }
                        ((ViewGroup.MarginLayoutParams) fVar).leftMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft();
                        ((ViewGroup.MarginLayoutParams) fVar).topMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop();
                        ((ViewGroup.MarginLayoutParams) fVar).rightMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight();
                        ((ViewGroup.MarginLayoutParams) fVar).bottomMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom();
                    }
                }
                if (B(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - ((ViewGroup.MarginLayoutParams) fVar).leftMargin) - ((ViewGroup.MarginLayoutParams) fVar).rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - ((ViewGroup.MarginLayoutParams) fVar).topMargin) - ((ViewGroup.MarginLayoutParams) fVar).bottomMargin, 1073741824));
                } else {
                    if (!E(childAt)) {
                        throw new IllegalStateException("Child " + childAt + " at index " + i3 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    }
                    if (X0) {
                        float fV = C1839d0.v(childAt);
                        float f2 = this.k0;
                        if (fV != f2) {
                            C1839d0.r0(childAt, f2);
                        }
                    }
                    int iT = t(childAt) & 7;
                    boolean z4 = iT == 3;
                    if ((z4 && z2) || (!z4 && z3)) {
                        throw new IllegalStateException("Child drawer has absolute gravity " + w(iT) + " but this DrawerLayout already has a drawer view along that edge");
                    }
                    if (z4) {
                        z2 = true;
                    } else {
                        z3 = true;
                    }
                    childAt.measure(ViewGroup.getChildMeasureSpec(i, this.l0 + ((ViewGroup.MarginLayoutParams) fVar).leftMargin + ((ViewGroup.MarginLayoutParams) fVar).rightMargin, ((ViewGroup.MarginLayoutParams) fVar).width), ViewGroup.getChildMeasureSpec(i2, ((ViewGroup.MarginLayoutParams) fVar).topMargin + ((ViewGroup.MarginLayoutParams) fVar).bottomMargin, ((ViewGroup.MarginLayoutParams) fVar).height));
                }
            }
        }
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        View viewN;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.a());
        int i = gVar.Y;
        if (i != 0 && (viewN = n(i)) != null) {
            M(viewN);
        }
        int i2 = gVar.Z;
        if (i2 != 3) {
            T(i2, 3);
        }
        int i3 = gVar.k0;
        if (i3 != 3) {
            T(i3, 5);
        }
        int i4 = gVar.l0;
        if (i4 != 3) {
            T(i4, 8388611);
        }
        int i5 = gVar.m0;
        if (i5 != 3) {
            T(i5, 8388613);
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i) {
        R();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            f fVar = (f) getChildAt(i).getLayoutParams();
            int i2 = fVar.d;
            boolean z = i2 == 1;
            boolean z2 = i2 == 2;
            if (z || z2) {
                gVar.Y = fVar.a;
                break;
            }
        }
        gVar.Z = this.w0;
        gVar.k0 = this.x0;
        gVar.l0 = this.y0;
        gVar.m0 = this.z0;
        return gVar;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x005d  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View viewO;
        this.p0.F(motionEvent);
        this.q0.F(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            this.D0 = x;
            this.E0 = y;
            this.A0 = false;
        } else if (action == 1) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            View viewT = this.p0.t((int) x2, (int) y2);
            if (viewT != null && B(viewT)) {
                float f2 = x2 - this.D0;
                float f3 = y2 - this.E0;
                int iZ = this.p0.z();
                z = (f2 * f2) + (f3 * f3) >= ((float) (iZ * iZ)) || (viewO = o()) == null || r(viewO) == 2;
            }
            i(z);
        } else if (action == 3) {
            i(true);
            this.A0 = false;
        }
        return true;
    }

    View p() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (E(childAt) && G(childAt)) {
                return childAt;
            }
        }
        return null;
    }

    public int q(int i) {
        int iB = C1839d0.B(this);
        if (i == 3) {
            int i2 = this.w0;
            if (i2 != 3) {
                return i2;
            }
            int i3 = iB == 0 ? this.y0 : this.z0;
            if (i3 != 3) {
                return i3;
            }
            return 0;
        }
        if (i == 5) {
            int i4 = this.x0;
            if (i4 != 3) {
                return i4;
            }
            int i5 = iB == 0 ? this.z0 : this.y0;
            if (i5 != 3) {
                return i5;
            }
            return 0;
        }
        if (i == 8388611) {
            int i6 = this.y0;
            if (i6 != 3) {
                return i6;
            }
            int i7 = iB == 0 ? this.w0 : this.x0;
            if (i7 != 3) {
                return i7;
            }
            return 0;
        }
        if (i != 8388613) {
            return 0;
        }
        int i8 = this.z0;
        if (i8 != 3) {
            return i8;
        }
        int i9 = iB == 0 ? this.x0 : this.w0;
        if (i9 != 3) {
            return i9;
        }
        return 0;
    }

    public int r(View view) {
        if (E(view)) {
            return q(((f) view.getLayoutParams()).a);
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z) {
            i(true);
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.u0) {
            return;
        }
        super.requestLayout();
    }

    public CharSequence s(int i) {
        int iB = C1869t.b(i, C1839d0.B(this));
        if (iB == 3) {
            return this.I0;
        }
        if (iB == 5) {
            return this.J0;
        }
        return null;
    }

    public void setDrawerElevation(float f2) {
        this.k0 = f2;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (E(childAt)) {
                C1839d0.r0(childAt, this.k0);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(e eVar) {
        e eVar2 = this.B0;
        if (eVar2 != null) {
            O(eVar2);
        }
        if (eVar != null) {
            a(eVar);
        }
        this.B0 = eVar;
    }

    public void setDrawerLockMode(int i) {
        T(i, 3);
        T(i, 5);
    }

    public void setScrimColor(int i) {
        this.m0 = i;
        invalidate();
    }

    public void setStatusBarBackground(int i) {
        this.F0 = i != 0 ? ax.Q.b.e(getContext(), i) : null;
        invalidate();
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.F0 = drawable;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i) {
        this.F0 = new ColorDrawable(i);
        invalidate();
    }

    int t(View view) {
        return C1869t.b(((f) view.getLayoutParams()).a, C1839d0.B(this));
    }

    float u(View view) {
        return ((f) view.getLayoutParams()).b;
    }
}
