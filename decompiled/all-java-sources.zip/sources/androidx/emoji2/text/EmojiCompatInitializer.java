package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import ax.X.u;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements ax.p058e1.a<Boolean> {

    static class a extends e.c {
        protected a(Context context) {
            super(new b(context));
            b(1);
        }
    }

    static class b implements e.h {
        private final Context a;

        class a extends e.i {
            final /* synthetic */ e.i a;
            final /* synthetic */ ThreadPoolExecutor b;

            a(e.i iVar, ThreadPoolExecutor threadPoolExecutor) {
                this.a = iVar;
                this.b = threadPoolExecutor;
            }

            @Override // androidx.emoji2.text.e.i
            public void a(Throwable th) {
                try {
                    this.a.a(th);
                } finally {
                    this.b.shutdown();
                }
            }

            @Override // androidx.emoji2.text.e.i
            public void b(l lVar) {
                try {
                    this.a.b(lVar);
                } finally {
                    this.b.shutdown();
                }
            }
        }

        b(Context context) {
            this.a = context.getApplicationContext();
        }

        @Override // androidx.emoji2.text.e.h
        public void a(final e.i iVar) {
            final ThreadPoolExecutor threadPoolExecutorB = androidx.emoji2.text.b.b("EmojiCompatInitializer");
            threadPoolExecutorB.execute(new Runnable() { // from class: androidx.emoji2.text.f
                @Override // java.lang.Runnable
                public final void run() {
                    this.q.d(iVar, threadPoolExecutorB);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public void d(e.i iVar, ThreadPoolExecutor threadPoolExecutor) {
            try {
                i iVarA = androidx.emoji2.text.c.a(this.a);
                if (iVarA == null) {
                    throw new RuntimeException("EmojiCompat font provider not available on this device.");
                }
                iVarA.c(threadPoolExecutor);
                iVarA.a().a(new a(iVar, threadPoolExecutor));
            } catch (Throwable th) {
                iVar.a(th);
                threadPoolExecutor.shutdown();
            }
        }
    }

    static class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                u.a("EmojiCompat.EmojiCompatInitializer.run");
                if (e.i()) {
                    e.c().l();
                }
            } finally {
                u.b();
            }
        }
    }

    @Override // ax.p058e1.a
    public List<Class<? extends ax.p058e1.a<?>>> a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // ax.p058e1.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Boolean b(Context context) {
        e.h(new a(context));
        d(context);
        return Boolean.TRUE;
    }

    void d(Context context) {
        final androidx.lifecycle.d dVarF = ((ax.F0.g) androidx.startup.a.e(context).f(ProcessLifecycleInitializer.class)).f();
        dVarF.a(new ax.F0.b() { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // ax.F0.b
            public void a(ax.F0.g gVar) {
                EmojiCompatInitializer.this.e();
                dVarF.c(this);
            }

            @Override // ax.F0.b
            public /* synthetic */ void b(ax.F0.g gVar) {
                ax.F0.a.a(this, gVar);
            }

            @Override // ax.F0.b
            public /* synthetic */ void c(ax.F0.g gVar) {
                ax.F0.a.d(this, gVar);
            }

            @Override // ax.F0.b
            public /* synthetic */ void e(ax.F0.g gVar) {
                ax.F0.a.b(this, gVar);
            }

            @Override // ax.F0.b
            public /* synthetic */ void f(ax.F0.g gVar) {
                ax.F0.a.e(this, gVar);
            }

            @Override // ax.F0.b
            public /* synthetic */ void h(ax.F0.g gVar) {
                ax.F0.a.c(this, gVar);
            }
        });
    }

    void e() {
        androidx.emoji2.text.b.d().postDelayed(new c(), 500L);
    }
}
