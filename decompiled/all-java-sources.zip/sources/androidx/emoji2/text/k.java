package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import ax.Y.u;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: loaded from: classes.dex */
public class k extends e.b {
    private static final a k = new a();

    public static class a {
        public Typeface a(Context context, ax.Z.k.b bVar) throws PackageManager.NameNotFoundException {
            return ax.Z.k.a(context, null, new ax.Z.k.b[]{bVar});
        }

        public ax.Z.k.a b(Context context, ax.Z.i iVar) throws PackageManager.NameNotFoundException {
            return ax.Z.k.b(context, null, iVar);
        }

        public void c(Context context, ContentObserver contentObserver) {
            context.getContentResolver().unregisterContentObserver(contentObserver);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static class b implements e.g {
        private final Context a;
        private final ax.Z.i b;
        private final a c;
        private final Object d = new Object();
        private Handler e;
        private Executor f;
        private ThreadPoolExecutor g;
        e.h h;
        private ContentObserver i;
        private Runnable j;

        b(Context context, ax.Z.i iVar, a aVar) {
            ax.p019b0.g.h(context, "Context cannot be null");
            ax.p019b0.g.h(iVar, "FontRequest cannot be null");
            this.a = context.getApplicationContext();
            this.b = iVar;
            this.c = aVar;
        }

        private void b() {
            synchronized (this.d) {
                try {
                    this.h = null;
                    ContentObserver contentObserver = this.i;
                    if (contentObserver != null) {
                        this.c.c(this.a, contentObserver);
                        this.i = null;
                    }
                    Handler handler = this.e;
                    if (handler != null) {
                        handler.removeCallbacks(this.j);
                    }
                    this.e = null;
                    ThreadPoolExecutor threadPoolExecutor = this.g;
                    if (threadPoolExecutor != null) {
                        threadPoolExecutor.shutdown();
                    }
                    this.f = null;
                    this.g = null;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        private ax.Z.k.b e() {
            try {
                ax.Z.k.a aVarB = this.c.b(this.a, this.b);
                if (aVarB.c() == 0) {
                    ax.Z.k.b[] bVarArrB = aVarB.b();
                    if (bVarArrB == null || bVarArrB.length == 0) {
                        throw new RuntimeException("fetchFonts failed (empty result)");
                    }
                    return bVarArrB[0];
                }
                throw new RuntimeException("fetchFonts failed (" + aVarB.c() + ")");
            } catch (PackageManager.NameNotFoundException e) {
                throw new RuntimeException("provider not found", e);
            }
        }

        @Override // androidx.emoji2.text.e.g
        public void a(e.h hVar) {
            ax.p019b0.g.h(hVar, "LoaderCallback cannot be null");
            synchronized (this.d) {
                this.h = hVar;
            }
            d();
        }

        void c() {
            synchronized (this.d) {
                try {
                    if (this.h == null) {
                        return;
                    }
                    try {
                        ax.Z.k.b bVarE = e();
                        int iB = bVarE.b();
                        if (iB == 2) {
                            synchronized (this.d) {
                            }
                        }
                        if (iB != 0) {
                            throw new RuntimeException("fetchFonts result is not OK. (" + iB + ")");
                        }
                        try {
                            u.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                            Typeface typefaceA = this.c.a(this.a, bVarE);
                            ByteBuffer byteBufferF = ax.T.m.f(this.a, null, bVarE.d());
                            if (byteBufferF == null || typefaceA == null) {
                                throw new RuntimeException("Unable to open file.");
                            }
                            n nVarB = n.b(typefaceA, byteBufferF);
                            u.b();
                            synchronized (this.d) {
                                try {
                                    e.h hVar = this.h;
                                    if (hVar != null) {
                                        hVar.b(nVarB);
                                    }
                                } catch (Throwable th) {
                                    throw th;
                                }
                            }
                            b();
                        } catch (Throwable th2) {
                            u.b();
                            throw th2;
                        }
                    } catch (Throwable th3) {
                        synchronized (this.d) {
                            try {
                                e.h hVar2 = this.h;
                                if (hVar2 != null) {
                                    hVar2.a(th3);
                                }
                                b();
                            } catch (Throwable th4) {
                                throw th4;
                            }
                        }
                    }
                } catch (Throwable th5) {
                    throw th5;
                }
            }
        }

        void d() {
            synchronized (this.d) {
                try {
                    if (this.h == null) {
                        return;
                    }
                    if (this.f == null) {
                        ThreadPoolExecutor threadPoolExecutorC = androidx.emoji2.text.b.c("emojiCompat");
                        this.g = threadPoolExecutorC;
                        this.f = threadPoolExecutorC;
                    }
                    this.f.execute(new Runnable() { // from class: androidx.emoji2.text.l
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.q.c();
                        }
                    });
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public void f(Executor executor) {
            synchronized (this.d) {
                this.f = executor;
            }
        }
    }

    public k(Context context, ax.Z.i iVar) {
        super(new b(context, iVar, k));
    }

    public k c(Executor executor) {
        ((b) a()).f(executor);
        return this;
    }
}
