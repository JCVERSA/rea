package androidx.emoji2.text;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* JADX INFO: loaded from: classes.dex */
class k {

    private static class a implements c {
        private final ByteBuffer a;

        a(ByteBuffer byteBuffer) {
            this.a = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // androidx.emoji2.text.k.c
        public void a(int i) throws IOException {
            ByteBuffer byteBuffer = this.a;
            byteBuffer.position(byteBuffer.position() + i);
        }

        @Override // androidx.emoji2.text.k.c
        public long b() {
            return this.a.position();
        }

        @Override // androidx.emoji2.text.k.c
        public int c() throws IOException {
            return this.a.getInt();
        }

        @Override // androidx.emoji2.text.k.c
        public long d() throws IOException {
            return k.c(this.a.getInt());
        }

        @Override // androidx.emoji2.text.k.c
        public int readUnsignedShort() throws IOException {
            return k.d(this.a.getShort());
        }
    }

    private static class b {
        private final long a;
        private final long b;

        b(long j, long j2) {
            this.a = j;
            this.b = j2;
        }

        long a() {
            return this.a;
        }
    }

    private interface c {
        void a(int i) throws IOException;

        long b();

        int c() throws IOException;

        long d() throws IOException;

        int readUnsignedShort() throws IOException;
    }

    private static b a(c cVar) throws IOException {
        long jD;
        cVar.a(4);
        int unsignedShort = cVar.readUnsignedShort();
        if (unsignedShort > 100) {
            throw new IOException("Cannot read metadata.");
        }
        cVar.a(6);
        int i = 0;
        while (true) {
            if (i >= unsignedShort) {
                jD = -1;
                break;
            }
            int iC = cVar.c();
            cVar.a(4);
            jD = cVar.d();
            cVar.a(4);
            if (1835365473 == iC) {
                break;
            }
            i++;
        }
        if (jD != -1) {
            cVar.a((int) (jD - cVar.b()));
            cVar.a(12);
            long jD2 = cVar.d();
            for (int i2 = 0; i2 < jD2; i2++) {
                int iC2 = cVar.c();
                long jD3 = cVar.d();
                long jD4 = cVar.d();
                if (1164798569 == iC2 || 1701669481 == iC2) {
                    return new b(jD3 + jD, jD4);
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    static ax.p295v0.b b(ByteBuffer byteBuffer) throws IOException {
        ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
        byteBufferDuplicate.position((int) a(new a(byteBufferDuplicate)).a());
        return ax.p295v0.b.h(byteBufferDuplicate);
    }

    static long c(int i) {
        return ((long) i) & 4294967295L;
    }

    static int d(short s) {
        return s & 65535;
    }
}
