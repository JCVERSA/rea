package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import ax.Y.u;
import java.io.IOException;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class n {
    private final ax.p355w0.b a;
    private final char[] b;
    private final a c = new a(1024);
    private final Typeface d;

    static class a {
        private final SparseArray<a> a;
        private o b;

        private a() {
            this(1);
        }

        a(int i) {
            this.a = new SparseArray<>(i);
        }

        a a(int i) {
            SparseArray<a> sparseArray = this.a;
            if (sparseArray == null) {
                return null;
            }
            return sparseArray.get(i);
        }

        final o b() {
            return this.b;
        }

        void c(o oVar, int i, int i2) {
            a aVarA = a(oVar.b(i));
            if (aVarA == null) {
                aVarA = new a();
                this.a.put(oVar.b(i), aVarA);
            }
            if (i2 > i) {
                aVarA.c(oVar, i + 1, i2);
            } else {
                aVarA.b = oVar;
            }
        }
    }

    private n(Typeface typeface, ax.p355w0.b bVar) {
        this.d = typeface;
        this.a = bVar;
        this.b = new char[bVar.k() * 2];
        a(bVar);
    }

    private void a(ax.p355w0.b bVar) {
        int iK = bVar.k();
        for (int i = 0; i < iK; i++) {
            o oVar = new o(this, i);
            Character.toChars(oVar.f(), this.b, i * 2);
            h(oVar);
        }
    }

    public static n b(Typeface typeface, ByteBuffer byteBuffer) throws IOException {
        try {
            u.a("EmojiCompat.MetadataRepo.create");
            return new n(typeface, m.b(byteBuffer));
        } finally {
            u.b();
        }
    }

    public char[] c() {
        return this.b;
    }

    public ax.p355w0.b d() {
        return this.a;
    }

    int e() {
        return this.a.l();
    }

    a f() {
        return this.c;
    }

    Typeface g() {
        return this.d;
    }

    void h(o oVar) {
        ax.p019b0.g.h(oVar, "emoji metadata cannot be null");
        ax.p019b0.g.b(oVar.c() > 0, "invalid metadata codepoint length");
        this.c.c(oVar, 0, oVar.c() - 1);
    }
}
