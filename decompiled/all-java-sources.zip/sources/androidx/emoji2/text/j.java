package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import java.util.Arrays;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
final class j {
    private final androidx.emoji2.text.e.i a;
    private final n b;
    private androidx.emoji2.text.e.d c;
    private final boolean d;
    private final int[] e;

    private static final class a {
        static int a(CharSequence charSequence, int i, int i2) {
            int length = charSequence.length();
            if (i < 0 || length < i || i2 < 0) {
                return -1;
            }
            while (true) {
                boolean z = false;
                while (i2 != 0) {
                    i--;
                    if (i < 0) {
                        return z ? -1 : 0;
                    }
                    char cCharAt = charSequence.charAt(i);
                    if (z) {
                        if (!Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        i2--;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i2--;
                    } else {
                        if (Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        z = true;
                    }
                }
                return i;
            }
        }

        static int b(CharSequence charSequence, int i, int i2) {
            int length = charSequence.length();
            if (i < 0 || length < i || i2 < 0) {
                return -1;
            }
            while (true) {
                boolean z = false;
                while (i2 != 0) {
                    if (i >= length) {
                        if (z) {
                            return -1;
                        }
                        return length;
                    }
                    char cCharAt = charSequence.charAt(i);
                    if (z) {
                        if (!Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i2--;
                        i++;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i2--;
                        i++;
                    } else {
                        if (Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i++;
                        z = true;
                    }
                }
                return i;
            }
        }
    }

    private static class b implements c<p> {
        public p a;
        private final androidx.emoji2.text.e.i b;

        b(p pVar, androidx.emoji2.text.e.i iVar) {
            this.a = pVar;
            this.b = iVar;
        }

        @Override // androidx.emoji2.text.j.c
        public boolean b(CharSequence charSequence, int i, int i2, o oVar) {
            if (oVar.k()) {
                return true;
            }
            if (this.a == null) {
                this.a = new p(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
            }
            this.a.setSpan(this.b.a(oVar), i, i2, 33);
            return true;
        }

        @Override // androidx.emoji2.text.j.c
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public p a() {
            return this.a;
        }
    }

    private interface c<T> {
        T a();

        boolean b(CharSequence charSequence, int i, int i2, o oVar);
    }

    private static class d implements c<d> {
        private final String a;

        d(String str) {
            this.a = str;
        }

        @Override // androidx.emoji2.text.j.c
        public boolean b(CharSequence charSequence, int i, int i2, o oVar) {
            if (!TextUtils.equals(charSequence.subSequence(i, i2), this.a)) {
                return true;
            }
            oVar.l(true);
            return false;
        }

        @Override // androidx.emoji2.text.j.c
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public d a() {
            return this;
        }
    }

    static final class e {
        private int a = 1;
        private final n.a b;
        private n.a c;
        private n.a d;
        private int e;
        private int f;
        private final boolean g;
        private final int[] h;

        e(n.a aVar, boolean z, int[] iArr) {
            this.b = aVar;
            this.c = aVar;
            this.g = z;
            this.h = iArr;
        }

        private static boolean d(int i) {
            return i == 65039;
        }

        private static boolean f(int i) {
            return i == 65038;
        }

        private int g() {
            this.a = 1;
            this.c = this.b;
            this.f = 0;
            return 1;
        }

        private boolean h() {
            if (this.c.b().j() || d(this.e)) {
                return true;
            }
            if (this.g) {
                if (this.h == null) {
                    return true;
                }
                if (Arrays.binarySearch(this.h, this.c.b().b(0)) < 0) {
                    return true;
                }
            }
            return false;
        }

        int a(int i) {
            n.a aVarA = this.c.a(i);
            int iG = 2;
            if (this.a != 2) {
                if (aVarA == null) {
                    iG = g();
                } else {
                    this.a = 2;
                    this.c = aVarA;
                    this.f = 1;
                }
            } else if (aVarA != null) {
                this.c = aVarA;
                this.f++;
            } else if (f(i)) {
                iG = g();
            } else if (!d(i)) {
                if (this.c.b() != null) {
                    iG = 3;
                    if (this.f != 1 || h()) {
                        this.d = this.c;
                        g();
                    } else {
                        iG = g();
                    }
                } else {
                    iG = g();
                }
            }
            this.e = i;
            return iG;
        }

        o b() {
            return this.c.b();
        }

        o c() {
            return this.d.b();
        }

        boolean e() {
            if (this.a != 2 || this.c.b() == null) {
                return false;
            }
            return this.f > 1 || h();
        }
    }

    j(n nVar, androidx.emoji2.text.e.i iVar, androidx.emoji2.text.e.d dVar, boolean z, int[] iArr, Set<int[]> set) {
        this.a = iVar;
        this.b = nVar;
        this.c = dVar;
        this.d = z;
        this.e = iArr;
        g(set);
    }

    private static boolean a(Editable editable, KeyEvent keyEvent, boolean z) {
        ax.p339v0.c[] cVarArr;
        if (f(keyEvent)) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (!e(selectionStart, selectionEnd) && (cVarArr = (ax.p339v0.c[]) editable.getSpans(selectionStart, selectionEnd, ax.p339v0.c.class)) != null && cVarArr.length > 0) {
            for (ax.p339v0.c cVar : cVarArr) {
                int spanStart = editable.getSpanStart(cVar);
                int spanEnd = editable.getSpanEnd(cVar);
                if ((z && spanStart == selectionStart) || ((!z && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    static boolean b(InputConnection inputConnection, Editable editable, int i, int i2, boolean z) {
        int iMax;
        int iMin;
        if (editable != null && inputConnection != null && i >= 0 && i2 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (e(selectionStart, selectionEnd)) {
                return false;
            }
            if (z) {
                iMax = a.a(editable, selectionStart, Math.max(i, 0));
                iMin = a.b(editable, selectionEnd, Math.max(i2, 0));
                if (iMax == -1 || iMin == -1) {
                    return false;
                }
            } else {
                iMax = Math.max(selectionStart - i, 0);
                iMin = Math.min(selectionEnd + i2, editable.length());
            }
            ax.p339v0.c[] cVarArr = (ax.p339v0.c[]) editable.getSpans(iMax, iMin, ax.p339v0.c.class);
            if (cVarArr != null && cVarArr.length > 0) {
                for (ax.p339v0.c cVar : cVarArr) {
                    int spanStart = editable.getSpanStart(cVar);
                    int spanEnd = editable.getSpanEnd(cVar);
                    iMax = Math.min(spanStart, iMax);
                    iMin = Math.max(spanEnd, iMin);
                }
                int iMax2 = Math.max(iMax, 0);
                int iMin2 = Math.min(iMin, editable.length());
                inputConnection.beginBatchEdit();
                editable.delete(iMax2, iMin2);
                inputConnection.endBatchEdit();
                return true;
            }
        }
        return false;
    }

    static boolean c(Editable editable, int i, KeyEvent keyEvent) {
        boolean zA;
        if (i != 67) {
            zA = i != 112 ? false : a(editable, keyEvent, true);
        } else {
            zA = a(editable, keyEvent, false);
        }
        if (!zA) {
            return false;
        }
        MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
        return true;
    }

    private boolean d(CharSequence charSequence, int i, int i2, o oVar) {
        if (oVar.d() == 0) {
            oVar.m(this.c.a(charSequence, i, i2, oVar.h()));
        }
        return oVar.d() == 2;
    }

    private static boolean e(int i, int i2) {
        return i == -1 || i2 == -1 || i != i2;
    }

    private static boolean f(KeyEvent keyEvent) {
        return !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState());
    }

    private void g(Set<int[]> set) {
        if (set.isEmpty()) {
            return;
        }
        for (int[] iArr : set) {
            String str = new String(iArr, 0, iArr.length);
            i(str, 0, str.length(), 1, true, new d(str));
        }
    }

    private <T> T i(CharSequence charSequence, int i, int i2, int i3, boolean z, c<T> cVar) {
        int iCharCount;
        e eVar = new e(this.b.f(), this.d, this.e);
        int iCodePointAt = Character.codePointAt(charSequence, i);
        int i4 = 0;
        boolean zB = true;
        loop0: while (true) {
            iCharCount = i;
            while (true) {
                if (i >= i2 || i4 >= i3 || !zB) {
                    break loop0;
                }
                int iA = eVar.a(iCodePointAt);
                if (iA == 1) {
                    iCharCount += Character.charCount(Character.codePointAt(charSequence, iCharCount));
                    if (iCharCount < i2) {
                        iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                    }
                    i = iCharCount;
                } else if (iA == 2) {
                    i += Character.charCount(iCodePointAt);
                    if (i < i2) {
                        iCodePointAt = Character.codePointAt(charSequence, i);
                    }
                } else if (iA != 3) {
                }
            }
            if (z || !d(charSequence, iCharCount, i, eVar.c())) {
                zB = cVar.b(charSequence, iCharCount, i, eVar.c());
                i4++;
            }
        }
        if (eVar.e() && i4 < i3 && zB && (z || !d(charSequence, iCharCount, i, eVar.b()))) {
            cVar.b(charSequence, iCharCount, i, eVar.b());
        }
        return cVar.a();
    }

    /* JADX WARN: Code duplicated, block: B:28:0x004b A[Catch: all -> 0x002a, TryCatch #2 {all -> 0x002a, blocks: (B:7:0x000e, B:10:0x0013, B:12:0x0017, B:14:0x0024, B:22:0x003c, B:24:0x0044, B:26:0x0047, B:28:0x004b, B:30:0x0057, B:31:0x005a, B:41:0x0078), top: B:69:0x000e }] */
    /* JADX WARN: Code duplicated, block: B:30:0x0057 A[Catch: all -> 0x002a, TryCatch #2 {all -> 0x002a, blocks: (B:7:0x000e, B:10:0x0013, B:12:0x0017, B:14:0x0024, B:22:0x003c, B:24:0x0044, B:26:0x0047, B:28:0x004b, B:30:0x0057, B:31:0x005a, B:41:0x0078), top: B:69:0x000e }] */
    /* JADX WARN: Code duplicated, block: B:37:0x006f  */
    /* JADX WARN: Code duplicated, block: B:61:0x00b6 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:63:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:72:? A[SYNTHETIC] */
    CharSequence h(CharSequence charSequence, int i, int i2, int i3, boolean z) throws Throwable {
        p pVar;
        CharSequence charSequence2;
        Throwable th;
        int i4;
        int i5;
        ax.p339v0.c[] cVarArr;
        int i6;
        int spanStart;
        boolean z2 = charSequence instanceof ax.p339v0.d;
        if (z2) {
            ((ax.p339v0.d) charSequence).a();
        }
        if (z2) {
            pVar = new p((Spannable) charSequence);
            if (pVar != null) {
                for (ax.p339v0.c cVar : cVarArr) {
                    spanStart = pVar.getSpanStart(cVar);
                    int spanEnd = pVar.getSpanEnd(cVar);
                    if (spanStart != i2) {
                        pVar.removeSpan(cVar);
                    }
                    i = Math.min(spanStart, i);
                    i2 = Math.max(spanEnd, i2);
                }
            }
            i4 = i;
            i5 = i2;
            if (i4 == i5) {
                charSequence2 = charSequence;
                if (!z2) {
                    return charSequence2;
                }
                ((ax.p339v0.d) charSequence2).d();
            } else {
                charSequence2 = charSequence;
                if (!z2) {
                    return charSequence2;
                }
                ((ax.p339v0.d) charSequence2).d();
            }
            return charSequence2;
        }
        try {
            if (charSequence instanceof Spannable) {
                try {
                    pVar = new p((Spannable) charSequence);
                } catch (Throwable th2) {
                    th = th2;
                    charSequence2 = charSequence;
                    th = th;
                    if (!z2) {
                        throw th;
                    }
                    ((ax.p339v0.d) charSequence2).d();
                    throw th;
                }
            } else {
                pVar = (!(charSequence instanceof Spanned) || ((Spanned) charSequence).nextSpanTransition(i + (-1), i2 + 1, ax.p339v0.c.class) > i2) ? null : new p(charSequence);
            }
            if (pVar != null && (cVarArr = (ax.p339v0.c[]) pVar.getSpans(i, i2, ax.p339v0.c.class)) != null && cVarArr.length > 0) {
                while (i6 < r5) {
                    spanStart = pVar.getSpanStart(cVar);
                    int spanEnd2 = pVar.getSpanEnd(cVar);
                    if (spanStart != i2) {
                        pVar.removeSpan(cVar);
                    }
                    i = Math.min(spanStart, i);
                    i2 = Math.max(spanEnd2, i2);
                }
            }
            i4 = i;
            i5 = i2;
            if (i4 == i5 && i4 < charSequence.length()) {
                if (i3 != Integer.MAX_VALUE && pVar != null) {
                    i3 -= ((ax.p339v0.c[]) pVar.getSpans(0, pVar.length(), ax.p339v0.c.class)).length;
                }
                charSequence2 = charSequence;
                try {
                    p pVar2 = (p) i(charSequence2, i4, i5, i3, z, new b(pVar, this.a));
                    if (pVar2 == null) {
                        if (z2) {
                        }
                        return charSequence2;
                    }
                    Spannable spannableB = pVar2.b();
                    if (z2) {
                        ((ax.p339v0.d) charSequence2).d();
                    }
                    return spannableB;
                } catch (Throwable th3) {
                    th = th3;
                    th = th;
                    if (!z2) {
                        throw th;
                    }
                    ((ax.p339v0.d) charSequence2).d();
                    throw th;
                }
            }
            charSequence2 = charSequence;
            if (!z2) {
                return charSequence2;
            }
            ((ax.p339v0.d) charSequence2).d();
            return charSequence2;
        } catch (Throwable th4) {
            th = th4;
            charSequence2 = charSequence;
        }
        if (!z2) {
            throw th;
        }
        ((ax.p339v0.d) charSequence2).d();
        throw th;
    }
}
