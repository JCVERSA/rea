package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import ax.X.u;
import java.io.IOException;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class l {
    private final ax.p295v0.b a;
    private final char[] b;
    private final a c = new a(1024);
    private final Typeface d;

    static class a {
        private final SparseArray<a> a;
        private m b;

        private a() {
            this(1);
        }

        a a(int i) {
            SparseArray<a> sparseArray = this.a;
            if (sparseArray == null) {
                return null;
            }
            return sparseArray.get(i);
        }

        final m b() {
            return this.b;
        }

        void c(m mVar, int i, int i2) {
            a aVarA = a(mVar.b(i));
            if (aVarA == null) {
                aVarA = new a();
                this.a.put(mVar.b(i), aVarA);
            }
            if (i2 > i) {
                aVarA.c(mVar, i + 1, i2);
            } else {
                aVarA.b = mVar;
            }
        }

        a(int i) {
            this.a = new SparseArray<>(i);
        }
    }

    private l(Typeface typeface, ax.p295v0.b bVar) {
        this.d = typeface;
        this.a = bVar;
        this.b = new char[bVar.k() * 2];
        a(bVar);
    }

    private void a(ax.p295v0.b bVar) {
        int iK = bVar.k();
        for (int i = 0; i < iK; i++) {
            m mVar = new m(this, i);
            Character.toChars(mVar.f(), this.b, i * 2);
            h(mVar);
        }
    }

    public static l b(Typeface typeface, ByteBuffer byteBuffer) throws IOException {
        try {
            u.a("EmojiCompat.MetadataRepo.create");
            return new l(typeface, k.b(byteBuffer));
        } finally {
            u.b();
        }
    }

    public char[] c() {
        return this.b;
    }

    public ax.p295v0.b d() {
        return this.a;
    }

    int e() {
        return this.a.l();
    }

    a f() {
        return this.c;
    }

    Typeface g() {
        return this.d;
    }

    void h(m mVar) {
        ax.p001a0.g.h(mVar, "emoji metadata cannot be null");
        ax.p001a0.g.b(mVar.c() > 0, "invalid metadata codepoint length");
        this.c.c(mVar, 0, mVar.c() - 1);
    }
}
