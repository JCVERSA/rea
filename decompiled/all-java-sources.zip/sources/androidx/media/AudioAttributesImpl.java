package androidx.media;

/* JADX INFO: loaded from: classes.dex */
public interface AudioAttributesImpl extends ax.p405z2.b {

    public interface a {
        AudioAttributesImpl i();

        a j(int i);

        a k(int i);
    }

    int a();

    Object b();
}
