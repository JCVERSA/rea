package androidx.media;

import ax.p128j1.b;

/* JADX INFO: loaded from: classes.dex */
public interface AudioAttributesImpl extends b {
}
