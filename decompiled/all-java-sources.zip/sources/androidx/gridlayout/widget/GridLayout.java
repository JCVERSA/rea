package androidx.gridlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.LogPrinter;
import android.util.Pair;
import android.util.Printer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Space;
import ax.p015b0.C5214d0;
import ax.p015b0.Y;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class GridLayout extends ViewGroup {
    public static final i A0;
    public static final i B0;
    public static final i C0;
    public static final i D0;
    public static final i E0;
    public static final i F0;
    public static final i G0;
    public static final i H0;
    public static final i I0;
    static final Printer o0 = new LogPrinter(3, GridLayout.class.getName());
    static final Printer p0 = new a();
    private static final int q0 = ax.B0.b.l;
    private static final int r0 = ax.B0.b.m;
    private static final int s0 = ax.B0.b.j;
    private static final int t0 = ax.B0.b.o;
    private static final int u0 = ax.B0.b.i;
    private static final int v0 = ax.B0.b.n;
    private static final int w0 = ax.B0.b.k;
    static final i x0 = new b();
    private static final i y0;
    private static final i z0;
    final l h0;
    int i0;
    boolean j0;
    int k0;
    int l0;
    int m0;
    Printer n0;
    final l q;

    static class a implements Printer {
        a() {
        }

        @Override // android.util.Printer
        public void println(String str) {
        }
    }

    static class b extends i {
        b() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return Integer.MIN_VALUE;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "UNDEFINED";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return Integer.MIN_VALUE;
        }
    }

    static class c extends i {
        c() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return 0;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "LEADING";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return 0;
        }
    }

    static class d extends i {
        d() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return i;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "TRAILING";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return i;
        }
    }

    static class e extends i {
        final /* synthetic */ i a;
        final /* synthetic */ i b;

        e(i iVar, i iVar2) {
            this.a = iVar;
            this.b = iVar2;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return (Y.C(view) == 1 ? this.b : this.a).a(view, i, i2);
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "SWITCHING[L:" + this.a.c() + ", R:" + this.b.c() + "]";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return (Y.C(view) == 1 ? this.b : this.a).d(view, i);
        }
    }

    static class f extends i {
        f() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return i >> 1;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "CENTER";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return i >> 1;
        }
    }

    static class g extends i {

        class a extends m {
            private int d;

            a() {
            }

            @Override // androidx.gridlayout.widget.GridLayout.m
            protected int a(GridLayout gridLayout, View view, i iVar, int i, boolean z) {
                return Math.max(0, super.a(gridLayout, view, iVar, i, z));
            }

            @Override // androidx.gridlayout.widget.GridLayout.m
            protected void b(int i, int i2) {
                super.b(i, i2);
                this.d = Math.max(this.d, i + i2);
            }

            @Override // androidx.gridlayout.widget.GridLayout.m
            protected void d() {
                super.d();
                this.d = Integer.MIN_VALUE;
            }

            @Override // androidx.gridlayout.widget.GridLayout.m
            protected int e(boolean z) {
                return Math.max(super.e(z), this.d);
            }
        }

        g() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            if (view.getVisibility() == 8) {
                return 0;
            }
            int baseline = view.getBaseline();
            if (baseline == -1) {
                return Integer.MIN_VALUE;
            }
            return baseline;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public m b() {
            return new a();
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "BASELINE";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return 0;
        }
    }

    static class h extends i {
        h() {
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int a(View view, int i, int i2) {
            return Integer.MIN_VALUE;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        String c() {
            return "FILL";
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        int d(View view, int i) {
            return 0;
        }

        @Override // androidx.gridlayout.widget.GridLayout.i
        public int e(View view, int i, int i2) {
            return i2;
        }
    }

    public static abstract class i {
        i() {
        }

        abstract int a(View view, int i, int i2);

        m b() {
            return new m();
        }

        abstract String c();

        abstract int d(View view, int i);

        int e(View view, int i, int i2) {
            return i;
        }

        public String toString() {
            return "Alignment:" + c();
        }
    }

    static final class j {
        public final n a;
        public final p b;
        public boolean c = true;

        public j(n nVar, p pVar) {
            this.a = nVar;
            this.b = pVar;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.a);
            sb.append(" ");
            sb.append(!this.c ? "+>" : "->");
            sb.append(" ");
            sb.append(this.b);
            return sb.toString();
        }
    }

    static final class k<K, V> extends ArrayList<Pair<K, V>> {
        private final Class<V> X;
        private final Class<K> q;

        private k(Class<K> cls, Class<V> cls2) {
            this.q = cls;
            this.X = cls2;
        }

        public static <K, V> k<K, V> e(Class<K> cls, Class<V> cls2) {
            return new k<>(cls, cls2);
        }

        public q<K, V> m() {
            int size = size();
            Object[] objArr = (Object[]) Array.newInstance((Class<?>) this.q, size);
            Object[] objArr2 = (Object[]) Array.newInstance((Class<?>) this.X, size);
            for (int i = 0; i < size; i++) {
                objArr[i] = get(i).first;
                objArr2[i] = get(i).second;
            }
            return new q<>(objArr, objArr2);
        }

        public void n(K k, V v) {
            add(Pair.create(k, v));
        }
    }

    final class l {
        public final boolean a;
        q<r, m> d;
        q<n, p> f;
        q<n, p> h;
        public int[] j;
        public int[] l;
        public j[] n;
        public int[] p;
        public boolean r;
        public int[] t;
        public int b = Integer.MIN_VALUE;
        private int c = Integer.MIN_VALUE;
        public boolean e = false;
        public boolean g = false;
        public boolean i = false;
        public boolean k = false;
        public boolean m = false;
        public boolean o = false;
        public boolean q = false;
        public boolean s = false;
        boolean u = true;
        private p v = new p(0);
        private p w = new p(-100000);

        class a {
            j[] a;
            int b;
            j[][] c;
            int[] d;
            final /* synthetic */ j[] e;

            a(j[] jVarArr) {
                this.e = jVarArr;
                j[] jVarArr2 = new j[jVarArr.length];
                this.a = jVarArr2;
                this.b = jVarArr2.length - 1;
                this.c = l.this.z(jVarArr);
                this.d = new int[l.this.p() + 1];
            }

            j[] a() {
                int length = this.c.length;
                for (int i = 0; i < length; i++) {
                    b(i);
                }
                return this.a;
            }

            void b(int i) {
                int[] iArr = this.d;
                if (iArr[i] != 0) {
                    return;
                }
                iArr[i] = 1;
                for (j jVar : this.c[i]) {
                    b(jVar.a.b);
                    j[] jVarArr = this.a;
                    int i2 = this.b;
                    this.b = i2 - 1;
                    jVarArr[i2] = jVar;
                }
                this.d[i] = 2;
            }
        }

        l(boolean z) {
            this.a = z;
        }

        private boolean A() {
            if (!this.s) {
                this.r = g();
                this.s = true;
            }
            return this.r;
        }

        private void B(List<j> list, n nVar, p pVar) {
            C(list, nVar, pVar, true);
        }

        private void C(List<j> list, n nVar, p pVar, boolean z) {
            if (nVar.b() == 0) {
                return;
            }
            if (z) {
                Iterator<j> it = list.iterator();
                while (it.hasNext()) {
                    if (it.next().a.equals(nVar)) {
                        return;
                    }
                }
            }
            list.add(new j(nVar, pVar));
        }

        private void D(int[] iArr) {
            Arrays.fill(iArr, 0);
        }

        private void H(String str, j[] jVarArr, boolean[] zArr) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (int i = 0; i < jVarArr.length; i++) {
                j jVar = jVarArr[i];
                if (zArr[i]) {
                    arrayList.add(jVar);
                }
                if (!jVar.c) {
                    arrayList2.add(jVar);
                }
            }
            GridLayout.this.n0.println(str + " constraints: " + b(arrayList) + " are inconsistent; permanently removing: " + b(arrayList2) + ". ");
        }

        private boolean I(int[] iArr, j jVar) {
            if (!jVar.c) {
                return false;
            }
            n nVar = jVar.a;
            int i = nVar.a;
            int i2 = nVar.b;
            int i3 = iArr[i] + jVar.b.a;
            if (i3 <= iArr[i2]) {
                return false;
            }
            iArr[i2] = i3;
            return true;
        }

        private void L(int i, int i2) {
            this.v.a = i;
            this.w.a = -i2;
            this.q = false;
        }

        private void M(int i, float f) {
            Arrays.fill(this.t, 0);
            int childCount = GridLayout.this.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = GridLayout.this.getChildAt(i2);
                if (childAt.getVisibility() != 8) {
                    o oVarQ = GridLayout.this.q(childAt);
                    float f2 = (this.a ? oVarQ.b : oVarQ.a).d;
                    if (f2 != 0.0f) {
                        int iRound = Math.round((i * f2) / f);
                        this.t[i2] = iRound;
                        i -= iRound;
                        f -= f2;
                    }
                }
            }
        }

        private int N(int[] iArr) {
            return iArr[p()];
        }

        private boolean O(int[] iArr) {
            return P(n(), iArr);
        }

        private boolean P(j[] jVarArr, int[] iArr) {
            return Q(jVarArr, iArr, true);
        }

        private boolean Q(j[] jVarArr, int[] iArr, boolean z) {
            String str = this.a ? "horizontal" : "vertical";
            int iP = p() + 1;
            boolean[] zArr = null;
            for (int i = 0; i < jVarArr.length; i++) {
                D(iArr);
                for (int i2 = 0; i2 < iP; i2++) {
                    boolean zI = false;
                    for (j jVar : jVarArr) {
                        zI |= I(iArr, jVar);
                    }
                    if (!zI) {
                        if (zArr != null) {
                            H(str, jVarArr, zArr);
                        }
                        return true;
                    }
                }
                if (!z) {
                    return false;
                }
                boolean[] zArr2 = new boolean[jVarArr.length];
                for (int i3 = 0; i3 < iP; i3++) {
                    int length = jVarArr.length;
                    for (int i4 = 0; i4 < length; i4++) {
                        zArr2[i4] = zArr2[i4] | I(iArr, jVarArr[i4]);
                    }
                }
                if (i == 0) {
                    zArr = zArr2;
                }
                for (int i5 = 0; i5 < jVarArr.length; i5++) {
                    if (zArr2[i5]) {
                        j jVar2 = jVarArr[i5];
                        n nVar = jVar2.a;
                        if (nVar.a >= nVar.b) {
                            jVar2.c = false;
                            break;
                        }
                    }
                }
            }
            return true;
        }

        private void R(int[] iArr) {
            Arrays.fill(q(), 0);
            O(iArr);
            boolean z = true;
            int childCount = (this.v.a * GridLayout.this.getChildCount()) + 1;
            if (childCount < 2) {
                return;
            }
            float fD = d();
            int i = -1;
            int i2 = 0;
            while (i2 < childCount) {
                int i3 = (int) ((((long) i2) + ((long) childCount)) / 2);
                F();
                M(i3, fD);
                boolean zQ = Q(n(), iArr, false);
                if (zQ) {
                    i2 = i3 + 1;
                    i = i3;
                } else {
                    childCount = i3;
                }
                z = zQ;
            }
            if (i <= 0 || z) {
                return;
            }
            F();
            M(i, fD);
            O(iArr);
        }

        private j[] S(List<j> list) {
            return T((j[]) list.toArray(new j[list.size()]));
        }

        private j[] T(j[] jVarArr) {
            return new a(jVarArr).a();
        }

        private void a(List<j> list, q<n, p> qVar) {
            int i = 0;
            while (true) {
                n[] nVarArr = qVar.b;
                if (i >= nVarArr.length) {
                    return;
                }
                C(list, nVarArr[i], qVar.c[i], false);
                i++;
            }
        }

        private String b(List<j> list) {
            StringBuilder sb;
            String str = this.a ? "x" : "y";
            StringBuilder sb2 = new StringBuilder();
            boolean z = true;
            for (j jVar : list) {
                if (z) {
                    z = false;
                } else {
                    sb2.append(", ");
                }
                n nVar = jVar.a;
                int i = nVar.a;
                int i2 = nVar.b;
                int i3 = jVar.b.a;
                if (i < i2) {
                    sb = new StringBuilder();
                    sb.append(str);
                    sb.append(i2);
                    sb.append("-");
                    sb.append(str);
                    sb.append(i);
                    sb.append(">=");
                } else {
                    sb = new StringBuilder();
                    sb.append(str);
                    sb.append(i);
                    sb.append("-");
                    sb.append(str);
                    sb.append(i2);
                    sb.append("<=");
                    i3 = -i3;
                }
                sb.append(i3);
                sb2.append(sb.toString());
            }
            return sb2.toString();
        }

        private int c() {
            int childCount = GridLayout.this.getChildCount();
            int iMax = -1;
            for (int i = 0; i < childCount; i++) {
                o oVarQ = GridLayout.this.q(GridLayout.this.getChildAt(i));
                n nVar = (this.a ? oVarQ.b : oVarQ.a).b;
                iMax = Math.max(Math.max(Math.max(iMax, nVar.a), nVar.b), nVar.b());
            }
            if (iMax == -1) {
                return Integer.MIN_VALUE;
            }
            return iMax;
        }

        private float d() {
            int childCount = GridLayout.this.getChildCount();
            float f = 0.0f;
            for (int i = 0; i < childCount; i++) {
                View childAt = GridLayout.this.getChildAt(i);
                if (childAt.getVisibility() != 8) {
                    o oVarQ = GridLayout.this.q(childAt);
                    f += (this.a ? oVarQ.b : oVarQ.a).d;
                }
            }
            return f;
        }

        private void e() {
            r();
            o();
        }

        private void f() {
            for (m mVar : this.d.c) {
                mVar.d();
            }
            int childCount = GridLayout.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = GridLayout.this.getChildAt(i);
                o oVarQ = GridLayout.this.q(childAt);
                boolean z = this.a;
                r rVar = z ? oVarQ.b : oVarQ.a;
                this.d.c(i).c(GridLayout.this, childAt, rVar, this, GridLayout.this.u(childAt, z) + (rVar.d == 0.0f ? 0 : q()[i]));
            }
        }

        private boolean g() {
            int childCount = GridLayout.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = GridLayout.this.getChildAt(i);
                if (childAt.getVisibility() != 8) {
                    o oVarQ = GridLayout.this.q(childAt);
                    if ((this.a ? oVarQ.b : oVarQ.a).d != 0.0f) {
                        return true;
                    }
                }
            }
            return false;
        }

        private void h(q<n, p> qVar, boolean z) {
            for (p pVar : qVar.c) {
                pVar.a();
            }
            m[] mVarArr = s().c;
            for (int i = 0; i < mVarArr.length; i++) {
                int iE = mVarArr[i].e(z);
                p pVarC = qVar.c(i);
                int i2 = pVarC.a;
                if (!z) {
                    iE = -iE;
                }
                pVarC.a = Math.max(i2, iE);
            }
        }

        private void i(int[] iArr) {
            if (A()) {
                R(iArr);
            } else {
                O(iArr);
            }
            if (this.u) {
                return;
            }
            int i = iArr[0];
            int length = iArr.length;
            for (int i2 = 0; i2 < length; i2++) {
                iArr[i2] = iArr[i2] - i;
            }
        }

        private void j(boolean z) {
            int[] iArr = z ? this.j : this.l;
            int childCount = GridLayout.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = GridLayout.this.getChildAt(i);
                if (childAt.getVisibility() != 8) {
                    o oVarQ = GridLayout.this.q(childAt);
                    boolean z2 = this.a;
                    n nVar = (z2 ? oVarQ.b : oVarQ.a).b;
                    int i2 = z ? nVar.a : nVar.b;
                    iArr[i2] = Math.max(iArr[i2], GridLayout.this.s(childAt, z2, z));
                }
            }
        }

        private j[] k() {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            a(arrayList, r());
            a(arrayList2, o());
            if (this.u) {
                int i = 0;
                while (i < p()) {
                    int i2 = i + 1;
                    B(arrayList, new n(i, i2), new p(0));
                    i = i2;
                }
            }
            int iP = p();
            C(arrayList, new n(0, iP), this.v, false);
            C(arrayList2, new n(iP, 0), this.w, false);
            return (j[]) GridLayout.b(S(arrayList), S(arrayList2));
        }

        private q<r, m> l() {
            k kVarE = k.e(r.class, m.class);
            int childCount = GridLayout.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                o oVarQ = GridLayout.this.q(GridLayout.this.getChildAt(i));
                boolean z = this.a;
                r rVar = z ? oVarQ.b : oVarQ.a;
                kVarE.n(rVar, rVar.b(z).b());
            }
            return kVarE.m();
        }

        private q<n, p> m(boolean z) {
            k kVarE = k.e(n.class, p.class);
            r[] rVarArr = s().b;
            int length = rVarArr.length;
            for (int i = 0; i < length; i++) {
                kVarE.n(z ? rVarArr[i].b : rVarArr[i].b.a(), new p());
            }
            return kVarE.m();
        }

        private q<n, p> o() {
            if (this.h == null) {
                this.h = m(false);
            }
            if (!this.i) {
                h(this.h, false);
                this.i = true;
            }
            return this.h;
        }

        private q<n, p> r() {
            if (this.f == null) {
                this.f = m(true);
            }
            if (!this.g) {
                h(this.f, true);
                this.g = true;
            }
            return this.f;
        }

        private int v() {
            if (this.c == Integer.MIN_VALUE) {
                this.c = Math.max(0, c());
            }
            return this.c;
        }

        private int x(int i, int i2) {
            L(i, i2);
            return N(u());
        }

        public void E() {
            this.c = Integer.MIN_VALUE;
            this.d = null;
            this.f = null;
            this.h = null;
            this.j = null;
            this.l = null;
            this.n = null;
            this.p = null;
            this.t = null;
            this.s = false;
            F();
        }

        public void F() {
            this.e = false;
            this.g = false;
            this.i = false;
            this.k = false;
            this.m = false;
            this.o = false;
            this.q = false;
        }

        public void G(int i) {
            L(i, i);
            u();
        }

        public void J(int i) {
            if (i != Integer.MIN_VALUE && i < v()) {
                StringBuilder sb = new StringBuilder();
                sb.append(this.a ? "column" : "row");
                sb.append("Count must be greater than or equal to the maximum of all grid indices ");
                sb.append("(and spans) defined in the LayoutParams of each child");
                GridLayout.w(sb.toString());
            }
            this.b = i;
        }

        public void K(boolean z) {
            this.u = z;
            E();
        }

        public j[] n() {
            if (this.n == null) {
                this.n = k();
            }
            if (!this.o) {
                e();
                this.o = true;
            }
            return this.n;
        }

        public int p() {
            return Math.max(this.b, v());
        }

        public int[] q() {
            if (this.t == null) {
                this.t = new int[GridLayout.this.getChildCount()];
            }
            return this.t;
        }

        public q<r, m> s() {
            if (this.d == null) {
                this.d = l();
            }
            if (!this.e) {
                f();
                this.e = true;
            }
            return this.d;
        }

        public int[] t() {
            if (this.j == null) {
                this.j = new int[p() + 1];
            }
            if (!this.k) {
                j(true);
                this.k = true;
            }
            return this.j;
        }

        public int[] u() {
            if (this.p == null) {
                this.p = new int[p() + 1];
            }
            if (!this.q) {
                i(this.p);
                this.q = true;
            }
            return this.p;
        }

        public int w(int i) {
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            if (mode == Integer.MIN_VALUE) {
                return x(0, size);
            }
            if (mode == 0) {
                return x(0, 100000);
            }
            if (mode != 1073741824) {
                return 0;
            }
            return x(size, size);
        }

        public int[] y() {
            if (this.l == null) {
                this.l = new int[p() + 1];
            }
            if (!this.m) {
                j(false);
                this.m = true;
            }
            return this.l;
        }

        j[][] z(j[] jVarArr) {
            int iP = p() + 1;
            j[][] jVarArr2 = new j[iP][];
            int[] iArr = new int[iP];
            for (j jVar : jVarArr) {
                int i = jVar.a.a;
                iArr[i] = iArr[i] + 1;
            }
            for (int i2 = 0; i2 < iP; i2++) {
                jVarArr2[i2] = new j[iArr[i2]];
            }
            Arrays.fill(iArr, 0);
            for (j jVar2 : jVarArr) {
                int i3 = jVar2.a.a;
                j[] jVarArr3 = jVarArr2[i3];
                int i4 = iArr[i3];
                iArr[i3] = i4 + 1;
                jVarArr3[i4] = jVar2;
            }
            return jVarArr2;
        }
    }

    static class m {
        public int a;
        public int b;
        public int c;

        m() {
            d();
        }

        protected int a(GridLayout gridLayout, View view, i iVar, int i, boolean z) {
            return this.a - iVar.a(view, i, C5214d0.a(gridLayout));
        }

        protected void b(int i, int i2) {
            this.a = Math.max(this.a, i);
            this.b = Math.max(this.b, i2);
        }

        protected final void c(GridLayout gridLayout, View view, r rVar, l lVar, int i) {
            this.c &= rVar.c();
            int iA = rVar.b(lVar.a).a(view, i, C5214d0.a(gridLayout));
            b(iA, i - iA);
        }

        protected void d() {
            this.a = Integer.MIN_VALUE;
            this.b = Integer.MIN_VALUE;
            this.c = 2;
        }

        protected int e(boolean z) {
            if (z || !GridLayout.c(this.c)) {
                return this.a + this.b;
            }
            return 100000;
        }

        public String toString() {
            return "Bounds{before=" + this.a + ", after=" + this.b + '}';
        }
    }

    static final class n {
        public final int a;
        public final int b;

        public n(int i, int i2) {
            this.a = i;
            this.b = i2;
        }

        n a() {
            return new n(this.b, this.a);
        }

        int b() {
            return this.b - this.a;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || n.class != obj.getClass()) {
                return false;
            }
            n nVar = (n) obj;
            return this.b == nVar.b && this.a == nVar.a;
        }

        public int hashCode() {
            return (this.a * 31) + this.b;
        }

        public String toString() {
            return "[" + this.a + ", " + this.b + "]";
        }
    }

    static final class q<K, V> {
        public final int[] a;
        public final K[] b;
        public final V[] c;

        q(K[] kArr, V[] vArr) {
            int[] iArrB = b(kArr);
            this.a = iArrB;
            this.b = (K[]) a(kArr, iArrB);
            this.c = (V[]) a(vArr, iArrB);
        }

        private static <K> K[] a(K[] kArr, int[] iArr) {
            int length = kArr.length;
            K[] kArr2 = (K[]) ((Object[]) Array.newInstance(kArr.getClass().getComponentType(), GridLayout.A(iArr, -1) + 1));
            for (int i = 0; i < length; i++) {
                kArr2[iArr[i]] = kArr[i];
            }
            return kArr2;
        }

        private static <K> int[] b(K[] kArr) {
            int length = kArr.length;
            int[] iArr = new int[length];
            HashMap map = new HashMap();
            for (int i = 0; i < length; i++) {
                K k = kArr[i];
                Integer numValueOf = (Integer) map.get(k);
                if (numValueOf == null) {
                    numValueOf = Integer.valueOf(map.size());
                    map.put(k, numValueOf);
                }
                iArr[i] = numValueOf.intValue();
            }
            return iArr;
        }

        public V c(int i) {
            return this.c[this.a[i]];
        }
    }

    static {
        c cVar = new c();
        y0 = cVar;
        d dVar = new d();
        z0 = dVar;
        A0 = cVar;
        B0 = dVar;
        C0 = cVar;
        D0 = dVar;
        E0 = h(cVar, dVar);
        F0 = h(dVar, cVar);
        G0 = new f();
        H0 = new g();
        I0 = new h();
    }

    public GridLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.q = new l(true);
        this.h0 = new l(false);
        this.i0 = 0;
        this.j0 = false;
        this.k0 = 1;
        this.m0 = 0;
        this.n0 = o0;
        this.l0 = context.getResources().getDimensionPixelOffset(ax.B0.a.a);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.B0.b.h);
        try {
            setRowCount(typedArrayObtainStyledAttributes.getInt(r0, Integer.MIN_VALUE));
            setColumnCount(typedArrayObtainStyledAttributes.getInt(s0, Integer.MIN_VALUE));
            setOrientation(typedArrayObtainStyledAttributes.getInt(q0, 0));
            setUseDefaultMargins(typedArrayObtainStyledAttributes.getBoolean(t0, false));
            setAlignmentMode(typedArrayObtainStyledAttributes.getInt(u0, 1));
            setRowOrderPreserved(typedArrayObtainStyledAttributes.getBoolean(v0, true));
            setColumnOrderPreserved(typedArrayObtainStyledAttributes.getBoolean(w0, true));
        } finally {
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    static int A(int[] iArr, int i2) {
        for (int i3 : iArr) {
            i2 = Math.max(i2, i3);
        }
        return i2;
    }

    private void B(View view, int i2, int i3, int i4, int i5) {
        view.measure(ViewGroup.getChildMeasureSpec(i2, v(view, true), i4), ViewGroup.getChildMeasureSpec(i3, v(view, false), i5));
    }

    private void C(int i2, int i3, boolean z) {
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                o oVarQ = q(childAt);
                if (z) {
                    B(childAt, i2, i3, ((ViewGroup.MarginLayoutParams) oVarQ).width, ((ViewGroup.MarginLayoutParams) oVarQ).height);
                } else {
                    boolean z2 = this.i0 == 0;
                    r rVar = z2 ? oVarQ.b : oVarQ.a;
                    if (rVar.b(z2) == I0) {
                        n nVar = rVar.b;
                        int[] iArrU = (z2 ? this.q : this.h0).u();
                        int iV = (iArrU[nVar.b] - iArrU[nVar.a]) - v(childAt, z2);
                        if (z2) {
                            B(childAt, i2, i3, iV, ((ViewGroup.MarginLayoutParams) oVarQ).height);
                        } else {
                            B(childAt, i2, i3, ((ViewGroup.MarginLayoutParams) oVarQ).width, iV);
                        }
                    }
                }
            }
        }
    }

    private static void D(int[] iArr, int i2, int i3, int i4) {
        int length = iArr.length;
        Arrays.fill(iArr, Math.min(i2, length), Math.min(i3, length), i4);
    }

    private static void E(o oVar, int i2, int i3, int i4, int i5) {
        oVar.d(new n(i2, i3 + i2));
        oVar.c(new n(i4, i5 + i4));
    }

    public static r F(int i2) {
        return G(i2, 1);
    }

    public static r G(int i2, int i3) {
        return H(i2, i3, x0);
    }

    public static r H(int i2, int i3, i iVar) {
        return I(i2, i3, iVar, 0.0f);
    }

    public static r I(int i2, int i3, i iVar, float f2) {
        return new r(i2 != Integer.MIN_VALUE, i2, i3, iVar, f2);
    }

    private void J() {
        boolean z = this.i0 == 0;
        int i2 = (z ? this.q : this.h0).b;
        if (i2 == Integer.MIN_VALUE) {
            i2 = 0;
        }
        int[] iArr = new int[i2];
        int childCount = getChildCount();
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < childCount; i5++) {
            o oVar = (o) getChildAt(i5).getLayoutParams();
            r rVar = z ? oVar.a : oVar.b;
            n nVar = rVar.b;
            boolean z2 = rVar.a;
            int iB = nVar.b();
            if (z2) {
                i3 = nVar.a;
            }
            r rVar2 = z ? oVar.b : oVar.a;
            n nVar2 = rVar2.b;
            boolean z3 = rVar2.a;
            int iE = e(nVar2, z3, i2);
            if (z3) {
                i4 = nVar2.a;
            }
            if (i2 != 0) {
                if (!z2 || !z3) {
                    while (true) {
                        int i6 = i4 + iE;
                        if (i(iArr, i3, i4, i6)) {
                            break;
                        }
                        if (z3) {
                            i3++;
                        } else if (i6 <= i2) {
                            i4++;
                        } else {
                            i3++;
                            i4 = 0;
                        }
                    }
                }
                D(iArr, i4, i4 + iE, i3 + iB);
            }
            if (z) {
                E(oVar, i3, iB, i4, iE);
            } else {
                E(oVar, i4, iE, i3, iB);
            }
            i4 += iE;
        }
    }

    static int a(int i2, int i3) {
        return View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3 + i2), View.MeasureSpec.getMode(i2));
    }

    static <T> T[] b(T[] tArr, T[] tArr2) {
        T[] tArr3 = (T[]) ((Object[]) Array.newInstance(tArr.getClass().getComponentType(), tArr.length + tArr2.length));
        System.arraycopy(tArr, 0, tArr3, 0, tArr.length);
        System.arraycopy(tArr2, 0, tArr3, tArr.length, tArr2.length);
        return tArr3;
    }

    static boolean c(int i2) {
        return (i2 & 2) != 0;
    }

    private void d(o oVar, boolean z) {
        String str = z ? "column" : "row";
        n nVar = (z ? oVar.b : oVar.a).b;
        int i2 = nVar.a;
        if (i2 != Integer.MIN_VALUE && i2 < 0) {
            w(str + " indices must be positive");
        }
        int i3 = (z ? this.q : this.h0).b;
        if (i3 != Integer.MIN_VALUE) {
            if (nVar.b > i3) {
                w(str + " indices (start + span) mustn't exceed the " + str + " count");
            }
            if (nVar.b() > i3) {
                w(str + " span mustn't exceed the " + str + " count");
            }
        }
    }

    private static int e(n nVar, boolean z, int i2) {
        int iB = nVar.b();
        if (i2 == 0) {
            return iB;
        }
        return Math.min(iB, i2 - (z ? Math.min(nVar.a, i2) : 0));
    }

    private int f() {
        int childCount = getChildCount();
        int iHashCode = 1;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                iHashCode = (iHashCode * 31) + ((o) childAt.getLayoutParams()).hashCode();
            }
        }
        return iHashCode;
    }

    private void g() {
        int i2 = this.m0;
        if (i2 == 0) {
            J();
            this.m0 = f();
        } else if (i2 != f()) {
            this.n0.println("The fields of some layout parameters were modified in between layout operations. Check the javadoc for GridLayout.LayoutParams#rowSpec.");
            x();
            g();
        }
    }

    private static i h(i iVar, i iVar2) {
        return new e(iVar, iVar2);
    }

    private static boolean i(int[] iArr, int i2, int i3, int i4) {
        if (i4 > iArr.length) {
            return false;
        }
        while (i3 < i4) {
            if (iArr[i3] > i2) {
                return false;
            }
            i3++;
        }
        return true;
    }

    static i m(int i2, boolean z) {
        int i3 = (i2 & (z ? 7 : 112)) >> (z ? 0 : 4);
        if (i3 == 1) {
            return G0;
        }
        if (i3 == 3) {
            return z ? E0 : A0;
        }
        if (i3 == 5) {
            return z ? F0 : B0;
        }
        if (i3 == 7) {
            return I0;
        }
        if (i3 != 8388611) {
            return i3 != 8388613 ? x0 : D0;
        }
        return C0;
    }

    private int n(View view, o oVar, boolean z, boolean z2) {
        boolean z3;
        boolean z4 = false;
        if (!this.j0) {
            return 0;
        }
        r rVar = z ? oVar.b : oVar.a;
        l lVar = z ? this.q : this.h0;
        n nVar = rVar.b;
        if (z && z()) {
            z3 = !z2;
        } else {
            z3 = z2;
        }
        if (!z3 ? nVar.b == lVar.p() : nVar.a == 0) {
            z4 = true;
        }
        return p(view, z4, z, z2);
    }

    private int o(View view, boolean z, boolean z2) {
        if (view.getClass() == ax.E0.a.class || view.getClass() == Space.class) {
            return 0;
        }
        return this.l0 / 2;
    }

    private int p(View view, boolean z, boolean z2, boolean z3) {
        return o(view, z2, z3);
    }

    private int r(View view, boolean z, boolean z2) {
        if (this.k0 == 1) {
            return s(view, z, z2);
        }
        l lVar = z ? this.q : this.h0;
        int[] iArrT = z2 ? lVar.t() : lVar.y();
        o oVarQ = q(view);
        n nVar = (z ? oVarQ.b : oVarQ.a).b;
        return iArrT[z2 ? nVar.a : nVar.b];
    }

    private int t(View view, boolean z) {
        return z ? view.getMeasuredWidth() : view.getMeasuredHeight();
    }

    private int v(View view, boolean z) {
        return r(view, z, true) + r(view, z, false);
    }

    static void w(String str) {
        throw new IllegalArgumentException(str + ". ");
    }

    private void x() {
        this.m0 = 0;
        l lVar = this.q;
        if (lVar != null) {
            lVar.E();
        }
        l lVar2 = this.h0;
        if (lVar2 != null) {
            lVar2.E();
        }
        y();
    }

    private void y() {
        l lVar = this.q;
        if (lVar == null || this.h0 == null) {
            return;
        }
        lVar.F();
        this.h0.F();
    }

    private boolean z() {
        return Y.C(this) == 1;
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (!(layoutParams instanceof o)) {
            return false;
        }
        o oVar = (o) layoutParams;
        d(oVar, true);
        d(oVar, false);
        return true;
    }

    public int getAlignmentMode() {
        return this.k0;
    }

    public int getColumnCount() {
        return this.q.p();
    }

    public int getOrientation() {
        return this.i0;
    }

    public Printer getPrinter() {
        return this.n0;
    }

    public int getRowCount() {
        return this.h0.p();
    }

    public boolean getUseDefaultMargins() {
        return this.j0;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public o generateDefaultLayoutParams() {
        return new o();
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
    public o generateLayoutParams(AttributeSet attributeSet) {
        return new o(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: l, reason: merged with bridge method [inline-methods] */
    public o generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof o) {
            return new o((o) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new o((ViewGroup.MarginLayoutParams) layoutParams) : new o(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        GridLayout gridLayout = this;
        g();
        int i6 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        gridLayout.q.G((i6 - paddingLeft) - paddingRight);
        gridLayout.h0.G(((i5 - i3) - paddingTop) - paddingBottom);
        int[] iArrU = gridLayout.q.u();
        int[] iArrU2 = gridLayout.h0.u();
        int childCount = getChildCount();
        boolean z2 = false;
        int i7 = 0;
        while (i7 < childCount) {
            View childAt = gridLayout.getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                o oVarQ = gridLayout.q(childAt);
                r rVar = oVarQ.b;
                r rVar2 = oVarQ.a;
                n nVar = rVar.b;
                n nVar2 = rVar2.b;
                int i8 = iArrU[nVar.a];
                int i9 = iArrU2[nVar2.a];
                int i10 = iArrU[nVar.b] - i8;
                int i11 = iArrU2[nVar2.b] - i9;
                int iT = gridLayout.t(childAt, true);
                int iT2 = gridLayout.t(childAt, z2);
                i iVarB = rVar.b(true);
                i iVarB2 = rVar2.b(z2);
                m mVarC = gridLayout.q.s().c(i7);
                m mVarC2 = gridLayout.h0.s().c(i7);
                int iD = iVarB.d(childAt, i10 - mVarC.e(true));
                int iD2 = iVarB2.d(childAt, i11 - mVarC2.e(true));
                int iR = gridLayout.r(childAt, true, true);
                int iR2 = gridLayout.r(childAt, false, true);
                int iR3 = gridLayout.r(childAt, true, false);
                int i12 = iR + iR3;
                int iR4 = iR2 + gridLayout.r(childAt, false, false);
                int iA = mVarC.a(this, childAt, iVarB, iT + i12, true);
                int iA2 = mVarC2.a(this, childAt, iVarB2, iT2 + iR4, false);
                int iE = iVarB.e(childAt, iT, i10 - i12);
                int iE2 = iVarB2.e(childAt, iT2, i11 - iR4);
                int i13 = i8 + iD + iA;
                int i14 = !z() ? paddingLeft + iR + i13 : (((i6 - iE) - paddingRight) - iR3) - i13;
                int i15 = paddingTop + i9 + iD2 + iA2 + iR2;
                if (iE != childAt.getMeasuredWidth() || iE2 != childAt.getMeasuredHeight()) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(iE, 1073741824), View.MeasureSpec.makeMeasureSpec(iE2, 1073741824));
                }
                childAt.layout(i14, i15, iE + i14, iE2 + i15);
            }
            i7++;
            z2 = false;
            gridLayout = this;
            iArrU = iArrU;
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int iW;
        int iW2;
        g();
        y();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int iA = a(i2, -paddingLeft);
        int iA2 = a(i3, -paddingTop);
        C(iA, iA2, true);
        if (this.i0 == 0) {
            iW = this.q.w(iA);
            C(iA, iA2, false);
            iW2 = this.h0.w(iA2);
        } else {
            int iW3 = this.h0.w(iA2);
            C(iA, iA2, false);
            iW = this.q.w(iA);
            iW2 = iW3;
        }
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iW + paddingLeft, getSuggestedMinimumWidth()), i2, 0), View.resolveSizeAndState(Math.max(iW2 + paddingTop, getSuggestedMinimumHeight()), i3, 0));
    }

    final o q(View view) {
        return (o) view.getLayoutParams();
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        super.requestLayout();
        x();
    }

    int s(View view, boolean z, boolean z2) {
        int i2;
        o oVarQ = q(view);
        if (z) {
            i2 = z2 ? ((ViewGroup.MarginLayoutParams) oVarQ).leftMargin : ((ViewGroup.MarginLayoutParams) oVarQ).rightMargin;
        } else {
            i2 = z2 ? ((ViewGroup.MarginLayoutParams) oVarQ).topMargin : ((ViewGroup.MarginLayoutParams) oVarQ).bottomMargin;
        }
        return i2 == Integer.MIN_VALUE ? n(view, oVarQ, z, z2) : i2;
    }

    public void setAlignmentMode(int i2) {
        this.k0 = i2;
        requestLayout();
    }

    public void setColumnCount(int i2) {
        this.q.J(i2);
        x();
        requestLayout();
    }

    public void setColumnOrderPreserved(boolean z) {
        this.q.K(z);
        x();
        requestLayout();
    }

    public void setOrientation(int i2) {
        if (this.i0 != i2) {
            this.i0 = i2;
            x();
            requestLayout();
        }
    }

    public void setPrinter(Printer printer) {
        if (printer == null) {
            printer = p0;
        }
        this.n0 = printer;
    }

    public void setRowCount(int i2) {
        this.h0.J(i2);
        x();
        requestLayout();
    }

    public void setRowOrderPreserved(boolean z) {
        this.h0.K(z);
        x();
        requestLayout();
    }

    public void setUseDefaultMargins(boolean z) {
        this.j0 = z;
        requestLayout();
    }

    final int u(View view, boolean z) {
        if (view.getVisibility() == 8) {
            return 0;
        }
        return t(view, z) + v(view, z);
    }

    static final class p {
        public int a;

        public p() {
            a();
        }

        public void a() {
            this.a = Integer.MIN_VALUE;
        }

        public String toString() {
            return Integer.toString(this.a);
        }

        public p(int i) {
            this.a = i;
        }
    }

    public static class r {
        static final r e = GridLayout.F(Integer.MIN_VALUE);
        final boolean a;
        final n b;
        final i c;
        final float d;

        private r(boolean z, n nVar, i iVar, float f) {
            this.a = z;
            this.b = nVar;
            this.c = iVar;
            this.d = f;
        }

        final r a(n nVar) {
            return new r(this.a, nVar, this.c, this.d);
        }

        public i b(boolean z) {
            i iVar = this.c;
            if (iVar != GridLayout.x0) {
                return iVar;
            }
            if (this.d == 0.0f) {
                return z ? GridLayout.C0 : GridLayout.H0;
            }
            return GridLayout.I0;
        }

        final int c() {
            return (this.c == GridLayout.x0 && this.d == 0.0f) ? 0 : 2;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            r rVar = (r) obj;
            return this.c.equals(rVar.c) && this.b.equals(rVar.b);
        }

        public int hashCode() {
            return (this.b.hashCode() * 31) + this.c.hashCode();
        }

        r(boolean z, int i, int i2, i iVar, float f) {
            this(z, new n(i, i2 + i), iVar, f);
        }
    }

    public static class o extends ViewGroup.MarginLayoutParams {
        private static final n c;
        private static final int d;
        private static final int e;
        private static final int f;
        private static final int g;
        private static final int h;
        private static final int i;
        private static final int j;
        private static final int k;
        private static final int l;
        private static final int m;
        private static final int n;
        private static final int o;
        private static final int p;
        public r a;
        public r b;

        static {
            n nVar = new n(Integer.MIN_VALUE, -2147483647);
            c = nVar;
            d = nVar.b();
            e = ax.B0.b.q;
            f = ax.B0.b.r;
            g = ax.B0.b.s;
            h = ax.B0.b.t;
            i = ax.B0.b.u;
            j = ax.B0.b.v;
            k = ax.B0.b.w;
            l = ax.B0.b.x;
            m = ax.B0.b.z;
            n = ax.B0.b.A;
            o = ax.B0.b.B;
            p = ax.B0.b.y;
        }

        private o(int i2, int i3, int i4, int i5, int i6, int i7, r rVar, r rVar2) {
            super(i2, i3);
            r rVar3 = r.e;
            this.a = rVar3;
            this.b = rVar3;
            setMargins(i4, i5, i6, i7);
            this.a = rVar;
            this.b = rVar2;
        }

        private void a(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.B0.b.p);
            try {
                int i2 = typedArrayObtainStyledAttributes.getInt(p, 0);
                int i3 = typedArrayObtainStyledAttributes.getInt(j, Integer.MIN_VALUE);
                int i4 = k;
                int i5 = d;
                this.b = GridLayout.I(i3, typedArrayObtainStyledAttributes.getInt(i4, i5), GridLayout.m(i2, true), typedArrayObtainStyledAttributes.getFloat(l, 0.0f));
                this.a = GridLayout.I(typedArrayObtainStyledAttributes.getInt(m, Integer.MIN_VALUE), typedArrayObtainStyledAttributes.getInt(n, i5), GridLayout.m(i2, false), typedArrayObtainStyledAttributes.getFloat(o, 0.0f));
            } finally {
                typedArrayObtainStyledAttributes.recycle();
            }
        }

        private void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.B0.b.p);
            try {
                int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(e, Integer.MIN_VALUE);
                ((ViewGroup.MarginLayoutParams) this).leftMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(f, dimensionPixelSize);
                ((ViewGroup.MarginLayoutParams) this).topMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(g, dimensionPixelSize);
                ((ViewGroup.MarginLayoutParams) this).rightMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(h, dimensionPixelSize);
                ((ViewGroup.MarginLayoutParams) this).bottomMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(i, dimensionPixelSize);
            } finally {
                typedArrayObtainStyledAttributes.recycle();
            }
        }

        final void c(n nVar) {
            this.b = this.b.a(nVar);
        }

        final void d(n nVar) {
            this.a = this.a.a(nVar);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            o oVar = (o) obj;
            return this.b.equals(oVar.b) && this.a.equals(oVar.a);
        }

        public int hashCode() {
            return (this.a.hashCode() * 31) + this.b.hashCode();
        }

        @Override // android.view.ViewGroup.LayoutParams
        protected void setBaseAttributes(TypedArray typedArray, int i2, int i3) {
            ((ViewGroup.MarginLayoutParams) this).width = typedArray.getLayoutDimension(i2, -2);
            ((ViewGroup.MarginLayoutParams) this).height = typedArray.getLayoutDimension(i3, -2);
        }

        public o(r rVar, r rVar2) {
            this(-2, -2, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, rVar, rVar2);
        }

        /* JADX WARN: Illegal instructions before constructor call */
        public o() {
            r rVar = r.e;
            this(rVar, rVar);
        }

        public o(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            r rVar = r.e;
            this.a = rVar;
            this.b = rVar;
        }

        public o(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            r rVar = r.e;
            this.a = rVar;
            this.b = rVar;
        }

        public o(o oVar) {
            super((ViewGroup.MarginLayoutParams) oVar);
            r rVar = r.e;
            this.a = rVar;
            this.b = rVar;
            this.a = oVar.a;
            this.b = oVar.b;
        }

        public o(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            r rVar = r.e;
            this.a = rVar;
            this.b = rVar;
            b(context, attributeSet);
            a(context, attributeSet);
        }
    }

    public GridLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
