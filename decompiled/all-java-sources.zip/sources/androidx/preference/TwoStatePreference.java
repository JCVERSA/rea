package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class TwoStatePreference extends Preference {
    protected boolean T0;
    private CharSequence U0;
    private CharSequence V0;
    private boolean W0;
    private boolean X0;

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    @Override // androidx.preference.Preference
    public boolean O0() {
        boolean z;
        if (this.X0) {
            z = this.T0;
        } else {
            z = !this.T0;
        }
        return z || super.O0();
    }

    public boolean T0() {
        return this.T0;
    }

    public void U0(boolean z) {
        boolean z2 = this.T0 != z;
        if (z2 || !this.W0) {
            this.T0 = z;
            this.W0 = true;
            q0(z);
            if (z2) {
                X(O0());
                W();
            }
        }
    }

    public void V0(boolean z) {
        this.X0 = z;
    }

    public void W0(CharSequence charSequence) {
        this.V0 = charSequence;
        if (T0()) {
            return;
        }
        W();
    }

    public void X0(CharSequence charSequence) {
        this.U0 = charSequence;
        if (T0()) {
            W();
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0030  */
    /* JADX WARN: Code duplicated, block: B:20:0x003a  */
    /* JADX WARN: Code duplicated, block: B:23:0x0041  */
    /* JADX WARN: Code duplicated, block: B:26:0x0049  */
    /* JADX WARN: Code duplicated, block: B:28:? A[RETURN, SYNTHETIC] */
    protected void Y0(View view) {
        boolean z;
        int i;
        CharSequence charSequenceM;
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            if (!this.T0 || TextUtils.isEmpty(this.U0)) {
                if (this.T0 || TextUtils.isEmpty(this.V0)) {
                    z = true;
                } else {
                    textView.setText(this.V0);
                }
                if (z) {
                    charSequenceM = M();
                    if (!TextUtils.isEmpty(charSequenceM)) {
                        textView.setText(charSequenceM);
                        z = false;
                    }
                }
                i = z ? 8 : 0;
                if (i != textView.getVisibility()) {
                    textView.setVisibility(i);
                }
            }
            textView.setText(this.U0);
            z = false;
            if (z) {
                charSequenceM = M();
                if (!TextUtils.isEmpty(charSequenceM)) {
                    textView.setText(charSequenceM);
                    z = false;
                }
            }
            if (z) {
            }
            if (i != textView.getVisibility()) {
                textView.setVisibility(i);
            }
        }
    }

    protected void Z0(h hVar) {
        Y0(hVar.N(R.id.summary));
    }

    @Override // androidx.preference.Preference
    protected void d0() {
        super.d0();
        boolean z = !T0();
        if (h(Boolean.valueOf(z))) {
            U0(z);
        }
    }

    @Override // androidx.preference.Preference
    protected Object g0(TypedArray typedArray, int i) {
        return Boolean.valueOf(typedArray.getBoolean(i, false));
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(a.class)) {
            super.k0(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.k0(aVar.getSuperState());
        U0(aVar.q);
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        Parcelable parcelableL0 = super.l0();
        if (T()) {
            return parcelableL0;
        }
        a aVar = new a(parcelableL0);
        aVar.q = T0();
        return aVar;
    }

    @Override // androidx.preference.Preference
    protected void m0(Object obj) {
        if (obj == null) {
            obj = Boolean.FALSE;
        }
        U0(F(((Boolean) obj).booleanValue()));
    }

    static class a extends Preference.b {
        public static final Parcelable.Creator<a> CREATOR = new C0029a();
        boolean q;

        /* JADX INFO: renamed from: androidx.preference.TwoStatePreference$a$a, reason: collision with other inner class name */
        class C0029a implements Parcelable.Creator<a> {
            C0029a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public a createFromParcel(Parcel parcel) {
                return new a(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public a[] newArray(int i) {
                return new a[i];
            }
        }

        a(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt() == 1;
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q ? 1 : 0);
        }

        a(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
