package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import ax.N0.l;
import ax.R.k;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceGroup extends Preference {
    final ax.B.h<String, Long> T0;
    private final Handler U0;
    private final List<Preference> V0;
    private boolean W0;
    private int X0;
    private boolean Y0;
    private int Z0;
    private final Runnable a1;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (this) {
                PreferenceGroup.this.T0.clear();
            }
        }
    }

    public interface b {
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.T0 = new ax.B.h<>();
        this.U0 = new Handler(Looper.getMainLooper());
        this.W0 = true;
        this.X0 = 0;
        this.Y0 = false;
        this.Z0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.a1 = new a();
        this.V0 = new ArrayList();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.A0, i, i2);
        int i3 = l.C0;
        this.W0 = k.b(typedArrayObtainStyledAttributes, i3, i3, true);
        int i4 = l.B0;
        if (typedArrayObtainStyledAttributes.hasValue(i4)) {
            e1(k.d(typedArrayObtainStyledAttributes, i4, i4, SubsamplingScaleImageView.TILE_SIZE_AUTO));
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    private boolean d1(Preference preference) {
        boolean zRemove;
        synchronized (this) {
            try {
                preference.j0();
                if (preference.E() == this) {
                    preference.g(null);
                }
                zRemove = this.V0.remove(preference);
                if (zRemove) {
                    String strB = preference.B();
                    if (strB != null) {
                        this.T0.put(strB, Long.valueOf(preference.w()));
                        this.U0.removeCallbacks(this.a1);
                        this.U0.post(this.a1);
                    }
                    if (this.Y0) {
                        preference.f0();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return zRemove;
    }

    public void T0(Preference preference) {
        U0(preference);
    }

    public boolean U0(Preference preference) {
        long jF;
        if (this.V0.contains(preference)) {
            return true;
        }
        if (preference.B() != null) {
            PreferenceGroup preferenceGroupE = this;
            while (preferenceGroupE.E() != null) {
                preferenceGroupE = preferenceGroupE.E();
            }
            String strB = preference.B();
            if (preferenceGroupE.V0(strB) != null) {
                Log.e("PreferenceGroup", "Found duplicated key: \"" + strB + "\". This can cause unintended behaviour, please use unique keys for every preference.");
            }
        }
        if (preference.D() == Integer.MAX_VALUE) {
            if (this.W0) {
                int i = this.X0;
                this.X0 = i + 1;
                preference.I0(i);
            }
            if (preference instanceof PreferenceGroup) {
                ((PreferenceGroup) preference).f1(this.W0);
            }
        }
        int iBinarySearch = Collections.binarySearch(this.V0, preference);
        if (iBinarySearch < 0) {
            iBinarySearch = (iBinarySearch * (-1)) - 1;
        }
        if (!b1(preference)) {
            return false;
        }
        synchronized (this) {
            this.V0.add(iBinarySearch, preference);
        }
        g gVarK = K();
        String strB2 = preference.B();
        if (strB2 == null || !this.T0.containsKey(strB2)) {
            jF = gVarK.f();
        } else {
            jF = this.T0.get(strB2).longValue();
            this.T0.remove(strB2);
        }
        preference.b0(gVarK, jF);
        preference.g(this);
        if (this.Y0) {
            preference.Z();
        }
        Y();
        return true;
    }

    public <T extends Preference> T V0(CharSequence charSequence) {
        T t;
        if (charSequence == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        if (TextUtils.equals(B(), charSequence)) {
            return this;
        }
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            PreferenceGroup preferenceGroup = (T) Y0(i);
            if (TextUtils.equals(preferenceGroup.B(), charSequence)) {
                return preferenceGroup;
            }
            if ((preferenceGroup instanceof PreferenceGroup) && (t = (T) preferenceGroup.V0(charSequence)) != null) {
                return t;
            }
        }
        return null;
    }

    public int W0() {
        return this.Z0;
    }

    @Override // androidx.preference.Preference
    public void X(boolean z) {
        super.X(z);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).i0(this, z);
        }
    }

    public b X0() {
        return null;
    }

    public Preference Y0(int i) {
        return this.V0.get(i);
    }

    @Override // androidx.preference.Preference
    public void Z() {
        super.Z();
        this.Y0 = true;
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).Z();
        }
    }

    public int Z0() {
        return this.V0.size();
    }

    protected boolean a1() {
        return true;
    }

    protected boolean b1(Preference preference) {
        preference.i0(this, O0());
        return true;
    }

    public boolean c1(Preference preference) {
        boolean zD1 = d1(preference);
        Y();
        return zD1;
    }

    public void e1(int i) {
        if (i != Integer.MAX_VALUE && !Q()) {
            Log.e("PreferenceGroup", getClass().getSimpleName() + " should have a key defined if it contains an expandable preference");
        }
        this.Z0 = i;
    }

    @Override // androidx.preference.Preference
    public void f0() {
        super.f0();
        this.Y0 = false;
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).f0();
        }
    }

    public void f1(boolean z) {
        this.W0 = z;
    }

    void g1() {
        synchronized (this) {
            Collections.sort(this.V0);
        }
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(c.class)) {
            super.k0(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        this.Z0 = cVar.q;
        super.k0(cVar.getSuperState());
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        return new c(super.l0(), this.Z0);
    }

    @Override // androidx.preference.Preference
    protected void n(Bundle bundle) {
        super.n(bundle);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).n(bundle);
        }
    }

    @Override // androidx.preference.Preference
    protected void o(Bundle bundle) {
        super.o(bundle);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).o(bundle);
        }
    }

    static class c extends Preference.b {
        public static final Parcelable.Creator<c> CREATOR = new a();
        int q;

        class a implements Parcelable.Creator<c> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        c(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q);
        }

        c(Parcelable parcelable, int i) {
            super(parcelable);
            this.q = i;
        }
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
