package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import ax.B.k;
import ax.p021b2.l;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceGroup extends Preference {
    final k<String, Long> W0;
    private final Handler X0;
    private final List<Preference> Y0;
    private boolean Z0;
    private int a1;
    private boolean b1;
    private int c1;
    private final Runnable d1;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (this) {
                PreferenceGroup.this.W0.clear();
            }
        }
    }

    public interface b {
    }

    static class c extends Preference.b {
        public static final Parcelable.Creator<c> CREATOR = new a();
        int q;

        class a implements Parcelable.Creator<c> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        c(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt();
        }

        c(Parcelable parcelable, int i) {
            super(parcelable);
            this.q = i;
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q);
        }
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.W0 = new k<>();
        this.X0 = new Handler(Looper.getMainLooper());
        this.Z0 = true;
        this.a1 = 0;
        this.b1 = false;
        this.c1 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.d1 = new a();
        this.Y0 = new ArrayList();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.A0, i, i2);
        int i3 = l.C0;
        this.Z0 = ax.S.k.b(typedArrayObtainStyledAttributes, i3, i3, true);
        int i4 = l.B0;
        if (typedArrayObtainStyledAttributes.hasValue(i4)) {
            e1(ax.S.k.d(typedArrayObtainStyledAttributes, i4, i4, SubsamplingScaleImageView.TILE_SIZE_AUTO));
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    private boolean d1(Preference preference) {
        boolean zRemove;
        synchronized (this) {
            try {
                preference.j0();
                if (preference.E() == this) {
                    preference.g(null);
                }
                zRemove = this.Y0.remove(preference);
                if (zRemove) {
                    String strB = preference.B();
                    if (strB != null) {
                        this.W0.put(strB, Long.valueOf(preference.x()));
                        this.X0.removeCallbacks(this.d1);
                        this.X0.post(this.d1);
                    }
                    if (this.b1) {
                        preference.f0();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return zRemove;
    }

    public void T0(Preference preference) {
        U0(preference);
    }

    public boolean U0(Preference preference) {
        long jF;
        if (this.Y0.contains(preference)) {
            return true;
        }
        if (preference.B() != null) {
            PreferenceGroup preferenceGroupE = this;
            while (preferenceGroupE.E() != null) {
                preferenceGroupE = preferenceGroupE.E();
            }
            String strB = preference.B();
            if (preferenceGroupE.V0(strB) != null) {
                Log.e("PreferenceGroup", "Found duplicated key: \"" + strB + "\". This can cause unintended behaviour, please use unique keys for every preference.");
            }
        }
        if (preference.D() == Integer.MAX_VALUE) {
            if (this.Z0) {
                int i = this.a1;
                this.a1 = i + 1;
                preference.I0(i);
            }
            if (preference instanceof PreferenceGroup) {
                ((PreferenceGroup) preference).f1(this.Z0);
            }
        }
        int iBinarySearch = Collections.binarySearch(this.Y0, preference);
        if (iBinarySearch < 0) {
            iBinarySearch = (iBinarySearch * (-1)) - 1;
        }
        if (!b1(preference)) {
            return false;
        }
        synchronized (this) {
            this.Y0.add(iBinarySearch, preference);
        }
        g gVarK = K();
        String strB2 = preference.B();
        if (strB2 == null || !this.W0.containsKey(strB2)) {
            jF = gVarK.f();
        } else {
            jF = this.W0.get(strB2).longValue();
            this.W0.remove(strB2);
        }
        preference.b0(gVarK, jF);
        preference.g(this);
        if (this.b1) {
            preference.Z();
        }
        Y();
        return true;
    }

    public <T extends Preference> T V0(CharSequence charSequence) {
        T t;
        if (charSequence == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        if (TextUtils.equals(B(), charSequence)) {
            return this;
        }
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            PreferenceGroup preferenceGroup = (T) Y0(i);
            if (TextUtils.equals(preferenceGroup.B(), charSequence)) {
                return preferenceGroup;
            }
            if ((preferenceGroup instanceof PreferenceGroup) && (t = (T) preferenceGroup.V0(charSequence)) != null) {
                return t;
            }
        }
        return null;
    }

    public int W0() {
        return this.c1;
    }

    @Override // androidx.preference.Preference
    public void X(boolean z) {
        super.X(z);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).i0(this, z);
        }
    }

    public b X0() {
        return null;
    }

    public Preference Y0(int i) {
        return this.Y0.get(i);
    }

    @Override // androidx.preference.Preference
    public void Z() {
        super.Z();
        this.b1 = true;
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).Z();
        }
    }

    public int Z0() {
        return this.Y0.size();
    }

    protected boolean a1() {
        return true;
    }

    protected boolean b1(Preference preference) {
        preference.i0(this, O0());
        return true;
    }

    public boolean c1(Preference preference) {
        boolean zD1 = d1(preference);
        Y();
        return zD1;
    }

    public void e1(int i) {
        if (i != Integer.MAX_VALUE && !Q()) {
            Log.e("PreferenceGroup", getClass().getSimpleName() + " should have a key defined if it contains an expandable preference");
        }
        this.c1 = i;
    }

    @Override // androidx.preference.Preference
    public void f0() {
        super.f0();
        this.b1 = false;
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).f0();
        }
    }

    public void f1(boolean z) {
        this.Z0 = z;
    }

    void g1() {
        synchronized (this) {
            Collections.sort(this.Y0);
        }
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(c.class)) {
            super.k0(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        this.c1 = cVar.q;
        super.k0(cVar.getSuperState());
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        return new c(super.l0(), this.c1);
    }

    @Override // androidx.preference.Preference
    protected void o(Bundle bundle) {
        super.o(bundle);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).o(bundle);
        }
    }

    @Override // androidx.preference.Preference
    protected void p(Bundle bundle) {
        super.p(bundle);
        int iZ0 = Z0();
        for (int i = 0; i < iZ0; i++) {
            Y0(i).p(bundle);
        }
    }
}
