package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import ax.N0.l;
import ax.R.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class DialogPreference extends Preference {
    private CharSequence T0;
    private CharSequence U0;
    private Drawable V0;
    private CharSequence W0;
    private CharSequence X0;
    private int Y0;

    public interface a {
        <T extends Preference> T z(CharSequence charSequence);
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.j, i, i2);
        String strO = k.o(typedArrayObtainStyledAttributes, l.t, l.k);
        this.T0 = strO;
        if (strO == null) {
            this.T0 = O();
        }
        this.U0 = k.o(typedArrayObtainStyledAttributes, l.s, l.l);
        this.V0 = k.c(typedArrayObtainStyledAttributes, l.q, l.m);
        this.W0 = k.o(typedArrayObtainStyledAttributes, l.v, l.n);
        this.X0 = k.o(typedArrayObtainStyledAttributes, l.u, l.o);
        this.Y0 = k.n(typedArrayObtainStyledAttributes, l.r, l.p, 0);
        typedArrayObtainStyledAttributes.recycle();
    }

    public Drawable T0() {
        return this.V0;
    }

    public int U0() {
        return this.Y0;
    }

    public CharSequence V0() {
        return this.U0;
    }

    public CharSequence W0() {
        return this.T0;
    }

    public CharSequence X0() {
        return this.X0;
    }

    public CharSequence Y0() {
        return this.W0;
    }

    @Override // androidx.preference.Preference
    protected void d0() {
        K().u(this);
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public DialogPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.N0.f.b, R.attr.dialogPreferenceStyle));
    }
}
