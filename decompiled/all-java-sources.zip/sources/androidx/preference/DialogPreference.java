package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import ax.S.k;
import ax.p021b2.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class DialogPreference extends Preference {
    private CharSequence W0;
    private CharSequence X0;
    private Drawable Y0;
    private CharSequence Z0;
    private CharSequence a1;
    private int b1;

    public interface a {
        <T extends Preference> T w(CharSequence charSequence);
    }

    public DialogPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.p021b2.f.b, R.attr.dialogPreferenceStyle));
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.j, i, i2);
        String strO = k.o(typedArrayObtainStyledAttributes, l.t, l.k);
        this.W0 = strO;
        if (strO == null) {
            this.W0 = O();
        }
        this.X0 = k.o(typedArrayObtainStyledAttributes, l.s, l.l);
        this.Y0 = k.c(typedArrayObtainStyledAttributes, l.q, l.m);
        this.Z0 = k.o(typedArrayObtainStyledAttributes, l.v, l.n);
        this.a1 = k.o(typedArrayObtainStyledAttributes, l.u, l.o);
        this.b1 = k.n(typedArrayObtainStyledAttributes, l.r, l.p, 0);
        typedArrayObtainStyledAttributes.recycle();
    }

    public Drawable T0() {
        return this.Y0;
    }

    public int U0() {
        return this.b1;
    }

    public CharSequence V0() {
        return this.X0;
    }

    public CharSequence W0() {
        return this.W0;
    }

    public CharSequence X0() {
        return this.a1;
    }

    public CharSequence Y0() {
        return this.Z0;
    }

    @Override // androidx.preference.Preference
    protected void d0() {
        K().u(this);
    }
}
