package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import ax.S.k;
import ax.p021b2.l;

/* JADX INFO: loaded from: classes.dex */
public class SwitchPreferenceCompat extends TwoStatePreference {
    private final a b1;
    private CharSequence c1;
    private CharSequence d1;

    private class a implements CompoundButton.OnCheckedChangeListener {
        a() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            if (SwitchPreferenceCompat.this.h(Boolean.valueOf(z))) {
                SwitchPreferenceCompat.this.U0(z);
            } else {
                compoundButton.setChecked(!z);
            }
        }
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p021b2.f.k);
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.b1 = new a();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.Z0, i, i2);
        X0(k.o(typedArrayObtainStyledAttributes, l.h1, l.a1));
        W0(k.o(typedArrayObtainStyledAttributes, l.g1, l.b1));
        b1(k.o(typedArrayObtainStyledAttributes, l.j1, l.d1));
        a1(k.o(typedArrayObtainStyledAttributes, l.i1, l.e1));
        V0(k.b(typedArrayObtainStyledAttributes, l.f1, l.c1, false));
        typedArrayObtainStyledAttributes.recycle();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void c1(View view) {
        boolean z = view instanceof SwitchCompat;
        if (z) {
            ((SwitchCompat) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(this.W0);
        }
        if (z) {
            SwitchCompat switchCompat = (SwitchCompat) view;
            switchCompat.setTextOn(this.c1);
            switchCompat.setTextOff(this.d1);
            switchCompat.setOnCheckedChangeListener(this.b1);
        }
    }

    private void d1(View view) {
        if (((AccessibilityManager) t().getSystemService("accessibility")).isEnabled()) {
            c1(view.findViewById(ax.p021b2.h.f));
            Y0(view.findViewById(R.id.summary));
        }
    }

    public void a1(CharSequence charSequence) {
        this.d1 = charSequence;
        W();
    }

    public void b1(CharSequence charSequence) {
        this.c1 = charSequence;
        W();
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        c1(hVar.N(ax.p021b2.h.f));
        Z0(hVar);
    }

    @Override // androidx.preference.Preference
    protected void p0(View view) {
        super.p0(view);
        d1(view);
    }
}
