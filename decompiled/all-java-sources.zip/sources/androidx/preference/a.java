package androidx.preference;

import android.R;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* JADX INFO: loaded from: classes.dex */
public class a extends c {
    private EditText E1;
    private CharSequence F1;
    private final Runnable G1 = new RunnableC0030a();
    private long H1 = -1;

    /* JADX INFO: renamed from: androidx.preference.a$a, reason: collision with other inner class name */
    class RunnableC0030a implements Runnable {
        RunnableC0030a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a.this.B3();
        }
    }

    public static a A3(String str) {
        a aVar = new a();
        Bundle bundle = new Bundle(1);
        bundle.putString("key", str);
        aVar.J2(bundle);
        return aVar;
    }

    private void C3(boolean z) {
        this.H1 = z ? SystemClock.currentThreadTimeMillis() : -1L;
    }

    private EditTextPreference y3() {
        return (EditTextPreference) q3();
    }

    private boolean z3() {
        long j = this.H1;
        return j != -1 && j + 1000 > SystemClock.currentThreadTimeMillis();
    }

    @Override // androidx.preference.c, androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void B1(Bundle bundle) {
        super.B1(bundle);
        if (bundle == null) {
            this.F1 = y3().a1();
        } else {
            this.F1 = bundle.getCharSequence("EditTextPreferenceDialogFragment.text");
        }
    }

    void B3() {
        if (z3()) {
            EditText editText = this.E1;
            if (editText == null || !editText.isFocused()) {
                C3(false);
            } else if (((InputMethodManager) this.E1.getContext().getSystemService("input_method")).showSoftInput(this.E1, 0)) {
                C3(false);
            } else {
                this.E1.removeCallbacks(this.G1);
                this.E1.postDelayed(this.G1, 50L);
            }
        }
    }

    @Override // androidx.preference.c, androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void W1(Bundle bundle) {
        super.W1(bundle);
        bundle.putCharSequence("EditTextPreferenceDialogFragment.text", this.F1);
    }

    @Override // androidx.preference.c
    protected boolean r3() {
        return true;
    }

    @Override // androidx.preference.c
    protected void s3(View view) {
        super.s3(view);
        EditText editText = (EditText) view.findViewById(R.id.edit);
        this.E1 = editText;
        if (editText == null) {
            throw new IllegalStateException("Dialog view must contain an EditText with id @android:id/edit");
        }
        editText.requestFocus();
        this.E1.setText(this.F1);
        EditText editText2 = this.E1;
        editText2.setSelection(editText2.getText().length());
        y3().Z0();
    }

    @Override // androidx.preference.c
    public void u3(boolean z) {
        if (z) {
            String string = this.E1.getText().toString();
            EditTextPreference editTextPreferenceY3 = y3();
            if (editTextPreferenceY3.h(string)) {
                editTextPreferenceY3.b1(string);
            }
        }
    }

    @Override // androidx.preference.c
    protected void x3() {
        C3(true);
        B3();
    }
}
