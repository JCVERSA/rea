package androidx.preference;

import android.R;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* JADX INFO: loaded from: classes.dex */
public class a extends c {
    private EditText H1;
    private CharSequence I1;
    private final Runnable J1 = new RunnableC0035a();
    private long K1 = -1;

    /* JADX INFO: renamed from: androidx.preference.a$a, reason: collision with other inner class name */
    class RunnableC0035a implements Runnable {
        RunnableC0035a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a.this.y3();
        }
    }

    private EditTextPreference v3() {
        return (EditTextPreference) n3();
    }

    private boolean w3() {
        long j = this.K1;
        return j != -1 && j + 1000 > SystemClock.currentThreadTimeMillis();
    }

    public static a x3(String str) {
        a aVar = new a();
        Bundle bundle = new Bundle(1);
        bundle.putString("key", str);
        aVar.F2(bundle);
        return aVar;
    }

    private void z3(boolean z) {
        this.K1 = z ? SystemClock.currentThreadTimeMillis() : -1L;
    }

    @Override // androidx.preference.c, androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void S1(Bundle bundle) {
        super.S1(bundle);
        bundle.putCharSequence("EditTextPreferenceDialogFragment.text", this.I1);
    }

    @Override // androidx.preference.c
    protected boolean o3() {
        return true;
    }

    @Override // androidx.preference.c
    protected void p3(View view) {
        super.p3(view);
        EditText editText = (EditText) view.findViewById(R.id.edit);
        this.H1 = editText;
        if (editText == null) {
            throw new IllegalStateException("Dialog view must contain an EditText with id @android:id/edit");
        }
        editText.requestFocus();
        this.H1.setText(this.I1);
        EditText editText2 = this.H1;
        editText2.setSelection(editText2.getText().length());
        v3().Z0();
    }

    @Override // androidx.preference.c
    public void r3(boolean z) {
        if (z) {
            String string = this.H1.getText().toString();
            EditTextPreference editTextPreferenceV3 = v3();
            if (editTextPreferenceV3.h(string)) {
                editTextPreferenceV3.b1(string);
            }
        }
    }

    @Override // androidx.preference.c
    protected void u3() {
        z3(true);
        y3();
    }

    @Override // androidx.preference.c, androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void x1(Bundle bundle) {
        super.x1(bundle);
        if (bundle == null) {
            this.I1 = v3().a1();
        } else {
            this.I1 = bundle.getCharSequence("EditTextPreferenceDialogFragment.text");
        }
    }

    void y3() {
        if (w3()) {
            EditText editText = this.H1;
            if (editText == null || !editText.isFocused()) {
                z3(false);
            } else if (((InputMethodManager) this.H1.getContext().getSystemService("input_method")).showSoftInput(this.H1, 0)) {
                z3(false);
            } else {
                this.H1.removeCallbacks(this.J1);
                this.H1.postDelayed(this.J1, 50L);
            }
        }
    }
}
