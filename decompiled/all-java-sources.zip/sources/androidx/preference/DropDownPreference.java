package androidx.preference;

import android.R;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

/* JADX INFO: loaded from: classes.dex */
public class DropDownPreference extends ListPreference {
    private final Context e1;
    private final ArrayAdapter f1;
    private Spinner g1;
    private final AdapterView.OnItemSelectedListener h1;

    class a implements AdapterView.OnItemSelectedListener {
        a() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            if (i >= 0) {
                String string = DropDownPreference.this.c1()[i].toString();
                if (string.equals(DropDownPreference.this.d1()) || !DropDownPreference.this.h(string)) {
                    return;
                }
                DropDownPreference.this.j1(string);
            }
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public DropDownPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.N0.f.c);
    }

    private int l1(String str) {
        CharSequence[] charSequenceArrC1 = c1();
        if (str == null || charSequenceArrC1 == null) {
            return -1;
        }
        for (int length = charSequenceArrC1.length - 1; length >= 0; length--) {
            if (TextUtils.equals(charSequenceArrC1[length].toString(), str)) {
                return length;
            }
        }
        return -1;
    }

    private void m1() {
        this.f1.clear();
        if (a1() != null) {
            for (CharSequence charSequence : a1()) {
                this.f1.add(charSequence.toString());
            }
        }
    }

    @Override // androidx.preference.Preference
    protected void W() {
        super.W();
        ArrayAdapter arrayAdapter = this.f1;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        Spinner spinner = (Spinner) hVar.a.findViewById(ax.N0.h.e);
        this.g1 = spinner;
        spinner.setAdapter((SpinnerAdapter) this.f1);
        this.g1.setOnItemSelectedListener(this.h1);
        this.g1.setSelection(l1(d1()));
        super.c0(hVar);
    }

    @Override // androidx.preference.DialogPreference, androidx.preference.Preference
    protected void d0() {
        this.g1.performClick();
    }

    @Override // androidx.preference.ListPreference
    public void g1(CharSequence[] charSequenceArr) {
        super.g1(charSequenceArr);
        m1();
    }

    protected ArrayAdapter k1() {
        return new ArrayAdapter(this.e1, R.layout.simple_spinner_dropdown_item);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.h1 = new a();
        this.e1 = context;
        this.f1 = k1();
        m1();
    }
}
