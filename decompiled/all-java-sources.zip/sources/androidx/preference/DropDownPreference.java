package androidx.preference;

import android.R;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

/* JADX INFO: loaded from: classes.dex */
public class DropDownPreference extends ListPreference {
    private final Context h1;
    private final ArrayAdapter i1;
    private Spinner j1;
    private final AdapterView.OnItemSelectedListener k1;

    class a implements AdapterView.OnItemSelectedListener {
        a() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            if (i >= 0) {
                String string = DropDownPreference.this.c1()[i].toString();
                if (string.equals(DropDownPreference.this.d1()) || !DropDownPreference.this.h(string)) {
                    return;
                }
                DropDownPreference.this.j1(string);
            }
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public DropDownPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p021b2.f.c);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.k1 = new a();
        this.h1 = context;
        this.i1 = k1();
        m1();
    }

    private int l1(String str) {
        CharSequence[] charSequenceArrC1 = c1();
        if (str == null || charSequenceArrC1 == null) {
            return -1;
        }
        for (int length = charSequenceArrC1.length - 1; length >= 0; length--) {
            if (TextUtils.equals(charSequenceArrC1[length].toString(), str)) {
                return length;
            }
        }
        return -1;
    }

    private void m1() {
        this.i1.clear();
        if (a1() != null) {
            for (CharSequence charSequence : a1()) {
                this.i1.add(charSequence.toString());
            }
        }
    }

    @Override // androidx.preference.Preference
    protected void W() {
        super.W();
        ArrayAdapter arrayAdapter = this.i1;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        Spinner spinner = (Spinner) hVar.a.findViewById(ax.p021b2.h.e);
        this.j1 = spinner;
        spinner.setAdapter((SpinnerAdapter) this.i1);
        this.j1.setOnItemSelectedListener(this.k1);
        this.j1.setSelection(l1(d1()));
        super.c0(hVar);
    }

    @Override // androidx.preference.DialogPreference, androidx.preference.Preference
    protected void d0() {
        this.j1.performClick();
    }

    @Override // androidx.preference.ListPreference
    public void g1(CharSequence[] charSequenceArr) {
        super.g1(charSequenceArr);
        m1();
    }

    protected ArrayAdapter k1() {
        return new ArrayAdapter(this.h1, R.layout.simple_spinner_dropdown_item);
    }
}
