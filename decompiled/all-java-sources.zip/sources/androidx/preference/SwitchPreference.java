package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.Switch;
import ax.S.k;
import ax.p021b2.l;

/* JADX INFO: loaded from: classes.dex */
public class SwitchPreference extends TwoStatePreference {
    private final a b1;
    private CharSequence c1;
    private CharSequence d1;

    private class a implements CompoundButton.OnCheckedChangeListener {
        a() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            if (SwitchPreference.this.h(Boolean.valueOf(z))) {
                SwitchPreference.this.U0(z);
            } else {
                compoundButton.setChecked(!z);
            }
        }
    }

    public SwitchPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.p021b2.f.l, R.attr.switchPreferenceStyle));
    }

    public SwitchPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public SwitchPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.b1 = new a();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.O0, i, i2);
        X0(k.o(typedArrayObtainStyledAttributes, l.W0, l.P0));
        W0(k.o(typedArrayObtainStyledAttributes, l.V0, l.Q0));
        b1(k.o(typedArrayObtainStyledAttributes, l.Y0, l.S0));
        a1(k.o(typedArrayObtainStyledAttributes, l.X0, l.T0));
        V0(k.b(typedArrayObtainStyledAttributes, l.U0, l.R0, false));
        typedArrayObtainStyledAttributes.recycle();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void c1(View view) {
        boolean z = view instanceof Switch;
        if (z) {
            ((Switch) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(this.W0);
        }
        if (z) {
            Switch r4 = (Switch) view;
            r4.setTextOn(this.c1);
            r4.setTextOff(this.d1);
            r4.setOnCheckedChangeListener(this.b1);
        }
    }

    private void d1(View view) {
        if (((AccessibilityManager) t().getSystemService("accessibility")).isEnabled()) {
            c1(view.findViewById(R.id.switch_widget));
            Y0(view.findViewById(R.id.summary));
        }
    }

    public void a1(CharSequence charSequence) {
        this.d1 = charSequence;
        W();
    }

    public void b1(CharSequence charSequence) {
        this.c1 = charSequence;
        W();
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        c1(hVar.N(R.id.switch_widget));
        Z0(hVar);
    }

    @Override // androidx.preference.Preference
    protected void p0(View view) {
        super.p0(view);
        d1(view);
    }
}
