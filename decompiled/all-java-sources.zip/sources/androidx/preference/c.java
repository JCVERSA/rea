package androidx.preference;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends androidx.fragment.app.e implements DialogInterface.OnClickListener {
    private CharSequence A1;
    private CharSequence B1;
    private CharSequence C1;
    private CharSequence D1;
    private int E1;
    private BitmapDrawable F1;
    private int G1;
    private DialogPreference z1;

    private static class a {
        static void a(Window window) {
            window.getDecorView().getWindowInsetsController().show(WindowInsets.Type.ime());
        }
    }

    private void t3(Dialog dialog) {
        Window window = dialog.getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            a.a(window);
        } else {
            u3();
        }
    }

    @Override // androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void S1(Bundle bundle) {
        super.S1(bundle);
        bundle.putCharSequence("PreferenceDialogFragment.title", this.A1);
        bundle.putCharSequence("PreferenceDialogFragment.positiveText", this.B1);
        bundle.putCharSequence("PreferenceDialogFragment.negativeText", this.C1);
        bundle.putCharSequence("PreferenceDialogFragment.message", this.D1);
        bundle.putInt("PreferenceDialogFragment.layout", this.E1);
        BitmapDrawable bitmapDrawable = this.F1;
        if (bitmapDrawable != null) {
            bundle.putParcelable("PreferenceDialogFragment.icon", bitmapDrawable.getBitmap());
        }
    }

    @Override // androidx.fragment.app.e
    public Dialog d3(Bundle bundle) {
        this.G1 = -2;
        androidx.appcompat.app.a.C0008a c0008aH = new androidx.appcompat.app.a.C0008a(z2()).setTitle(this.A1).d(this.F1).l(this.B1, this).h(this.C1, this);
        View viewQ3 = q3(z2());
        if (viewQ3 != null) {
            p3(viewQ3);
            c0008aH.setView(viewQ3);
        } else {
            c0008aH.f(this.D1);
        }
        s3(c0008aH);
        androidx.appcompat.app.a aVarCreate = c0008aH.create();
        if (o3()) {
            t3(aVarCreate);
        }
        return aVarCreate;
    }

    public DialogPreference n3() {
        if (this.z1 == null) {
            this.z1 = (DialogPreference) ((DialogPreference.a) Y0()).w(y2().getString("key"));
        }
        return this.z1;
    }

    protected boolean o3() {
        return false;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        this.G1 = i;
    }

    @Override // androidx.fragment.app.e, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        r3(this.G1 == -1);
    }

    protected void p3(View view) {
        int i;
        View viewFindViewById = view.findViewById(R.id.message);
        if (viewFindViewById != null) {
            CharSequence charSequence = this.D1;
            if (TextUtils.isEmpty(charSequence)) {
                i = 8;
            } else {
                if (viewFindViewById instanceof TextView) {
                    ((TextView) viewFindViewById).setText(charSequence);
                }
                i = 0;
            }
            if (viewFindViewById.getVisibility() != i) {
                viewFindViewById.setVisibility(i);
            }
        }
    }

    protected View q3(Context context) {
        int i = this.E1;
        if (i == 0) {
            return null;
        }
        return D0().inflate(i, (ViewGroup) null);
    }

    public abstract void r3(boolean z);

    protected void s3(androidx.appcompat.app.a.C0008a c0008a) {
    }

    protected void u3() {
    }

    @Override // androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void x1(Bundle bundle) {
        super.x1(bundle);
        ax.G0.h hVarY0 = Y0();
        if (!(hVarY0 instanceof DialogPreference.a)) {
            throw new IllegalStateException("Target fragment must implement TargetFragment interface");
        }
        DialogPreference.a aVar = (DialogPreference.a) hVarY0;
        String string = y2().getString("key");
        if (bundle != null) {
            this.A1 = bundle.getCharSequence("PreferenceDialogFragment.title");
            this.B1 = bundle.getCharSequence("PreferenceDialogFragment.positiveText");
            this.C1 = bundle.getCharSequence("PreferenceDialogFragment.negativeText");
            this.D1 = bundle.getCharSequence("PreferenceDialogFragment.message");
            this.E1 = bundle.getInt("PreferenceDialogFragment.layout", 0);
            Bitmap bitmap = (Bitmap) bundle.getParcelable("PreferenceDialogFragment.icon");
            if (bitmap != null) {
                this.F1 = new BitmapDrawable(P0(), bitmap);
                return;
            }
            return;
        }
        DialogPreference dialogPreference = (DialogPreference) aVar.w(string);
        this.z1 = dialogPreference;
        this.A1 = dialogPreference.W0();
        this.B1 = this.z1.Y0();
        this.C1 = this.z1.X0();
        this.D1 = this.z1.V0();
        this.E1 = this.z1.U0();
        Drawable drawableT0 = this.z1.T0();
        if (drawableT0 == null || (drawableT0 instanceof BitmapDrawable)) {
            this.F1 = (BitmapDrawable) drawableT0;
            return;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(drawableT0.getIntrinsicWidth(), drawableT0.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        drawableT0.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawableT0.draw(canvas);
        this.F1 = new BitmapDrawable(P0(), bitmapCreateBitmap);
    }
}
