package androidx.preference;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends androidx.fragment.app.e implements DialogInterface.OnClickListener {
    private CharSequence A1;
    private int B1;
    private BitmapDrawable C1;
    private int D1;
    private DialogPreference w1;
    private CharSequence x1;
    private CharSequence y1;
    private CharSequence z1;

    private static class a {
        static void a(Window window) {
            window.getDecorView().getWindowInsetsController().show(WindowInsets.Type.ime());
        }
    }

    private void w3(Dialog dialog) {
        Window window = dialog.getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            a.a(window);
        } else {
            x3();
        }
    }

    @Override // androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void B1(Bundle bundle) {
        super.B1(bundle);
        ax.F0.g gVarD1 = d1();
        if (!(gVarD1 instanceof DialogPreference.a)) {
            throw new IllegalStateException("Target fragment must implement TargetFragment interface");
        }
        DialogPreference.a aVar = (DialogPreference.a) gVarD1;
        String string = C2().getString("key");
        if (bundle != null) {
            this.x1 = bundle.getCharSequence("PreferenceDialogFragment.title");
            this.y1 = bundle.getCharSequence("PreferenceDialogFragment.positiveText");
            this.z1 = bundle.getCharSequence("PreferenceDialogFragment.negativeText");
            this.A1 = bundle.getCharSequence("PreferenceDialogFragment.message");
            this.B1 = bundle.getInt("PreferenceDialogFragment.layout", 0);
            Bitmap bitmap = (Bitmap) bundle.getParcelable("PreferenceDialogFragment.icon");
            if (bitmap != null) {
                this.C1 = new BitmapDrawable(T0(), bitmap);
                return;
            }
            return;
        }
        DialogPreference dialogPreference = (DialogPreference) aVar.z(string);
        this.w1 = dialogPreference;
        this.x1 = dialogPreference.W0();
        this.y1 = this.w1.Y0();
        this.z1 = this.w1.X0();
        this.A1 = this.w1.V0();
        this.B1 = this.w1.U0();
        Drawable drawableT0 = this.w1.T0();
        if (drawableT0 == null || (drawableT0 instanceof BitmapDrawable)) {
            this.C1 = (BitmapDrawable) drawableT0;
            return;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(drawableT0.getIntrinsicWidth(), drawableT0.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        drawableT0.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawableT0.draw(canvas);
        this.C1 = new BitmapDrawable(T0(), bitmapCreateBitmap);
    }

    @Override // androidx.fragment.app.e, androidx.fragment.app.Fragment
    public void W1(Bundle bundle) {
        super.W1(bundle);
        bundle.putCharSequence("PreferenceDialogFragment.title", this.x1);
        bundle.putCharSequence("PreferenceDialogFragment.positiveText", this.y1);
        bundle.putCharSequence("PreferenceDialogFragment.negativeText", this.z1);
        bundle.putCharSequence("PreferenceDialogFragment.message", this.A1);
        bundle.putInt("PreferenceDialogFragment.layout", this.B1);
        BitmapDrawable bitmapDrawable = this.C1;
        if (bitmapDrawable != null) {
            bundle.putParcelable("PreferenceDialogFragment.icon", bitmapDrawable.getBitmap());
        }
    }

    @Override // androidx.fragment.app.e
    public Dialog g3(Bundle bundle) {
        this.D1 = -2;
        androidx.appcompat.app.a.C0006a c0006aK = new androidx.appcompat.app.a.C0006a(D2()).t(this.x1).f(this.C1).p(this.y1, this).k(this.z1, this);
        View viewT3 = t3(D2());
        if (viewT3 != null) {
            s3(viewT3);
            c0006aK.u(viewT3);
        } else {
            c0006aK.h(this.A1);
        }
        v3(c0006aK);
        androidx.appcompat.app.a aVarA = c0006aK.a();
        if (r3()) {
            w3(aVarA);
        }
        return aVarA;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        this.D1 = i;
    }

    @Override // androidx.fragment.app.e, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        u3(this.D1 == -1);
    }

    public DialogPreference q3() {
        if (this.w1 == null) {
            this.w1 = (DialogPreference) ((DialogPreference.a) d1()).z(C2().getString("key"));
        }
        return this.w1;
    }

    protected boolean r3() {
        return false;
    }

    protected void s3(View view) {
        int i;
        View viewFindViewById = view.findViewById(R.id.message);
        if (viewFindViewById != null) {
            CharSequence charSequence = this.A1;
            if (TextUtils.isEmpty(charSequence)) {
                i = 8;
            } else {
                if (viewFindViewById instanceof TextView) {
                    ((TextView) viewFindViewById).setText(charSequence);
                }
                i = 0;
            }
            if (viewFindViewById.getVisibility() != i) {
                viewFindViewById.setVisibility(i);
            }
        }
    }

    protected View t3(Context context) {
        int i = this.B1;
        if (i == 0) {
            return null;
        }
        return H0().inflate(i, (ViewGroup) null);
    }

    public abstract void u3(boolean z);

    protected void v3(androidx.appcompat.app.a.C0006a c0006a) {
    }

    protected void x3() {
    }
}
