package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import ax.N0.j;
import ax.N0.l;
import ax.R.k;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class ListPreference extends DialogPreference {
    private CharSequence[] Z0;
    private CharSequence[] a1;
    private String b1;
    private String c1;
    private boolean d1;

    public static final class b implements Preference.g<ListPreference> {
        private static b a;

        private b() {
        }

        public static b b() {
            if (a == null) {
                a = new b();
            }
            return a;
        }

        @Override // androidx.preference.Preference.g
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public CharSequence a(ListPreference listPreference) {
            return TextUtils.isEmpty(listPreference.b1()) ? listPreference.s().getString(j.c) : listPreference.b1();
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.y, i, i2);
        this.Z0 = k.q(typedArrayObtainStyledAttributes, l.B, l.z);
        this.a1 = k.q(typedArrayObtainStyledAttributes, l.C, l.A);
        int i3 = l.D;
        if (k.b(typedArrayObtainStyledAttributes, i3, i3, false)) {
            K0(b.b());
        }
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, l.J, i, i2);
        this.c1 = k.o(typedArrayObtainStyledAttributes2, l.r0, l.R);
        typedArrayObtainStyledAttributes2.recycle();
    }

    private int e1() {
        return Z0(this.b1);
    }

    @Override // androidx.preference.Preference
    public void J0(CharSequence charSequence) {
        super.J0(charSequence);
        if (charSequence == null) {
            this.c1 = null;
        } else {
            this.c1 = charSequence.toString();
        }
    }

    @Override // androidx.preference.Preference
    public CharSequence M() {
        if (N() != null) {
            return N().a(this);
        }
        CharSequence charSequenceB1 = b1();
        CharSequence charSequenceM = super.M();
        String str = this.c1;
        if (str == null) {
            return charSequenceM;
        }
        if (charSequenceB1 == null) {
            charSequenceB1 = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        String str2 = String.format(str, charSequenceB1);
        if (TextUtils.equals(str2, charSequenceM)) {
            return charSequenceM;
        }
        Log.w("ListPreference", "Setting a summary with a String formatting marker is no longer supported. You should use a SummaryProvider instead.");
        return str2;
    }

    public int Z0(String str) {
        CharSequence[] charSequenceArr;
        if (str == null || (charSequenceArr = this.a1) == null) {
            return -1;
        }
        for (int length = charSequenceArr.length - 1; length >= 0; length--) {
            if (TextUtils.equals(this.a1[length].toString(), str)) {
                return length;
            }
        }
        return -1;
    }

    public CharSequence[] a1() {
        return this.Z0;
    }

    public CharSequence b1() {
        CharSequence[] charSequenceArr;
        int iE1 = e1();
        if (iE1 < 0 || (charSequenceArr = this.Z0) == null) {
            return null;
        }
        return charSequenceArr[iE1];
    }

    public CharSequence[] c1() {
        return this.a1;
    }

    public String d1() {
        return this.b1;
    }

    public void f1(int i) {
        g1(s().getResources().getTextArray(i));
    }

    @Override // androidx.preference.Preference
    protected Object g0(TypedArray typedArray, int i) {
        return typedArray.getString(i);
    }

    public void g1(CharSequence[] charSequenceArr) {
        this.Z0 = charSequenceArr;
    }

    public void h1(int i) {
        i1(s().getResources().getTextArray(i));
    }

    public void i1(CharSequence[] charSequenceArr) {
        this.a1 = charSequenceArr;
    }

    public void j1(String str) {
        boolean z = !TextUtils.equals(this.b1, str);
        if (z || !this.d1) {
            this.b1 = str;
            this.d1 = true;
            s0(str);
            if (z) {
                W();
            }
        }
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(a.class)) {
            super.k0(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.k0(aVar.getSuperState());
        j1(aVar.q);
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        Parcelable parcelableL0 = super.l0();
        if (T()) {
            return parcelableL0;
        }
        a aVar = new a(parcelableL0);
        aVar.q = d1();
        return aVar;
    }

    @Override // androidx.preference.Preference
    protected void m0(Object obj) {
        j1(H((String) obj));
    }

    private static class a extends Preference.b {
        public static final Parcelable.Creator<a> CREATOR = new C0027a();
        String q;

        /* JADX INFO: renamed from: androidx.preference.ListPreference$a$a, reason: collision with other inner class name */
        class C0027a implements Parcelable.Creator<a> {
            C0027a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public a createFromParcel(Parcel parcel) {
                return new a(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public a[] newArray(int i) {
                return new a[i];
            }
        }

        a(Parcel parcel) {
            super(parcel);
            this.q = parcel.readString();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeString(this.q);
        }

        a(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public ListPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.N0.f.b, R.attr.dialogPreferenceStyle));
    }
}
