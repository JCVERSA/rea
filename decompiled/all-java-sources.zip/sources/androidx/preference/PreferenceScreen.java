package androidx.preference;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import ax.R.k;

/* JADX INFO: loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {
    private boolean b1;

    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, k.a(context, ax.N0.f.g, R.attr.preferenceScreenStyle));
        this.b1 = true;
    }

    @Override // androidx.preference.PreferenceGroup
    protected boolean a1() {
        return false;
    }

    @Override // androidx.preference.Preference
    protected void d0() {
        g.b bVarG;
        if (y() != null || v() != null || Z0() == 0 || (bVarG = K().g()) == null) {
            return;
        }
        bVarG.d0(this);
    }

    public boolean h1() {
        return this.b1;
    }
}
