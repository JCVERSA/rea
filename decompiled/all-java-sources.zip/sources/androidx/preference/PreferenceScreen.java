package androidx.preference;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import ax.S.k;

/* JADX INFO: loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {
    private boolean e1;

    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, k.a(context, ax.p021b2.f.g, R.attr.preferenceScreenStyle));
        this.e1 = true;
    }

    @Override // androidx.preference.PreferenceGroup
    protected boolean a1() {
        return false;
    }

    @Override // androidx.preference.Preference
    protected void d0() {
        g.b bVarG;
        if (y() != null || w() != null || Z0() == 0 || (bVarG = K().g()) == null) {
            return;
        }
        bVarG.b0(this);
    }

    public boolean h1() {
        return this.e1;
    }
}
