package androidx.preference;

import android.content.Context;
import android.text.TextUtils;
import ax.N0.i;
import ax.N0.j;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
final class b extends Preference {
    private long T0;

    b(Context context, List<Preference> list, long j) {
        super(context);
        T0();
        U0(list);
        this.T0 = j + 1000000;
    }

    private void T0() {
        E0(i.a);
        A0(ax.N0.g.a);
        L0(j.b);
        I0(999);
    }

    private void U0(List<Preference> list) {
        ArrayList arrayList = new ArrayList();
        CharSequence string = null;
        for (Preference preference : list) {
            CharSequence charSequenceO = preference.O();
            boolean z = preference instanceof PreferenceGroup;
            if (z && !TextUtils.isEmpty(charSequenceO)) {
                arrayList.add((PreferenceGroup) preference);
            }
            if (arrayList.contains(preference.E())) {
                if (z) {
                    arrayList.add((PreferenceGroup) preference);
                }
            } else if (!TextUtils.isEmpty(charSequenceO)) {
                string = string == null ? charSequenceO : s().getString(j.e, string, charSequenceO);
            }
        }
        J0(string);
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        hVar.R(false);
    }

    @Override // androidx.preference.Preference
    long w() {
        return this.T0;
    }
}
