package androidx.preference;

import android.content.Context;
import android.text.TextUtils;
import ax.p021b2.i;
import ax.p021b2.j;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
final class b extends Preference {
    private long W0;

    b(Context context, List<Preference> list, long j) {
        super(context);
        T0();
        U0(list);
        this.W0 = j + 1000000;
    }

    private void T0() {
        E0(i.a);
        A0(ax.p021b2.g.a);
        L0(j.b);
        I0(999);
    }

    private void U0(List<Preference> list) {
        ArrayList arrayList = new ArrayList();
        CharSequence string = null;
        for (Preference preference : list) {
            CharSequence charSequenceO = preference.O();
            boolean z = preference instanceof PreferenceGroup;
            if (z && !TextUtils.isEmpty(charSequenceO)) {
                arrayList.add((PreferenceGroup) preference);
            }
            if (arrayList.contains(preference.E())) {
                if (z) {
                    arrayList.add((PreferenceGroup) preference);
                }
            } else if (!TextUtils.isEmpty(charSequenceO)) {
                string = string == null ? charSequenceO : t().getString(j.e, string, charSequenceO);
            }
        }
        J0(string);
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        hVar.R(false);
    }

    @Override // androidx.preference.Preference
    long x() {
        return this.W0;
    }
}
