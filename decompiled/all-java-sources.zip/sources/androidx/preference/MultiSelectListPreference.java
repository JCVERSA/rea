package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import ax.N0.l;
import ax.R.k;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class MultiSelectListPreference extends DialogPreference {
    private CharSequence[] Z0;
    private CharSequence[] a1;
    private Set<String> b1;

    public MultiSelectListPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.b1 = new HashSet();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.E, i, i2);
        this.Z0 = k.q(typedArrayObtainStyledAttributes, l.H, l.F);
        this.a1 = k.q(typedArrayObtainStyledAttributes, l.I, l.G);
        typedArrayObtainStyledAttributes.recycle();
    }

    public CharSequence[] Z0() {
        return this.Z0;
    }

    public CharSequence[] a1() {
        return this.a1;
    }

    public Set<String> b1() {
        return this.b1;
    }

    public void c1(Set<String> set) {
        this.b1.clear();
        this.b1.addAll(set);
        t0(set);
        W();
    }

    @Override // androidx.preference.Preference
    protected Object g0(TypedArray typedArray, int i) {
        CharSequence[] textArray = typedArray.getTextArray(i);
        HashSet hashSet = new HashSet();
        for (CharSequence charSequence : textArray) {
            hashSet.add(charSequence.toString());
        }
        return hashSet;
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(a.class)) {
            super.k0(parcelable);
            return;
        }
        a aVar = (a) parcelable;
        super.k0(aVar.getSuperState());
        c1(aVar.q);
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        Parcelable parcelableL0 = super.l0();
        if (T()) {
            return parcelableL0;
        }
        a aVar = new a(parcelableL0);
        aVar.q = b1();
        return aVar;
    }

    @Override // androidx.preference.Preference
    protected void m0(Object obj) {
        c1(I((Set) obj));
    }

    private static class a extends Preference.b {
        public static final Parcelable.Creator<a> CREATOR = new C0028a();
        Set<String> q;

        /* JADX INFO: renamed from: androidx.preference.MultiSelectListPreference$a$a, reason: collision with other inner class name */
        class C0028a implements Parcelable.Creator<a> {
            C0028a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public a createFromParcel(Parcel parcel) {
                return new a(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public a[] newArray(int i) {
                return new a[i];
            }
        }

        a(Parcel parcel) {
            super(parcel);
            int i = parcel.readInt();
            this.q = new HashSet();
            String[] strArr = new String[i];
            parcel.readStringArray(strArr);
            Collections.addAll(this.q, strArr);
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q.size());
            Set<String> set = this.q;
            parcel.writeStringArray((String[]) set.toArray(new String[set.size()]));
        }

        a(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public MultiSelectListPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public MultiSelectListPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.N0.f.b, R.attr.dialogPreferenceStyle));
    }
}
