package androidx.preference;

import android.R;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import ax.S.k;
import ax.p021b2.i;
import ax.p021b2.j;
import ax.p021b2.l;
import ax.p035c0.C1839d0;
import ax.p051d0.H;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class Preference implements Comparable<Preference> {
    private String A0;
    private Object B0;
    private boolean C0;
    private boolean D0;
    private boolean E0;
    private boolean F0;
    private boolean G0;
    private boolean H0;
    private boolean I0;
    private boolean J0;
    private boolean K0;
    private boolean L0;
    private int M0;
    private int N0;
    private c O0;
    private List<Preference> P0;
    private PreferenceGroup Q0;
    private boolean R0;
    private boolean S0;
    private f T0;
    private g U0;
    private final View.OnClickListener V0;
    private androidx.preference.g X;
    private long Y;
    private boolean Z;
    private d k0;
    private e l0;
    private int m0;
    private int n0;
    private CharSequence o0;
    private CharSequence p0;
    private final Context q;
    private int q0;
    private Drawable r0;
    private String s0;
    private Intent t0;
    private String u0;
    private Bundle v0;
    private boolean w0;
    private boolean x0;
    private boolean y0;
    private boolean z0;

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Preference.this.p0(view);
        }
    }

    public static class b extends AbsSavedState {
        public static final Parcelable.Creator<b> CREATOR = new a();

        class a implements Parcelable.Creator<b> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel) {
                return new b(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public b[] newArray(int i) {
                return new b[i];
            }
        }

        public b(Parcel parcel) {
            super(parcel);
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }
    }

    interface c {
        void a(Preference preference);

        void d(Preference preference);

        void f(Preference preference);
    }

    public interface d {
        boolean a(Preference preference, Object obj);
    }

    public interface e {
        boolean a(Preference preference);
    }

    private static class f implements View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        private final Preference q;

        f(Preference preference) {
            this.q = preference;
        }

        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
            CharSequence charSequenceM = this.q.M();
            if (!this.q.R() || TextUtils.isEmpty(charSequenceM)) {
                return;
            }
            contextMenu.setHeaderTitle(charSequenceM);
            contextMenu.add(0, 0, 0, j.a).setOnMenuItemClickListener(this);
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            ClipboardManager clipboardManager = (ClipboardManager) this.q.t().getSystemService("clipboard");
            CharSequence charSequenceM = this.q.M();
            clipboardManager.setPrimaryClip(ClipData.newPlainText("Preference", charSequenceM));
            Toast.makeText(this.q.t(), this.q.t().getString(j.d, charSequenceM), 0).show();
            return true;
        }
    }

    public interface g<T extends Preference> {
        CharSequence a(T t);
    }

    public Preference(Context context) {
        this(context, null);
    }

    public Preference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.p021b2.f.h, R.attr.preferenceStyle));
    }

    public Preference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public Preference(Context context, AttributeSet attributeSet, int i, int i2) {
        this.m0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.n0 = 0;
        this.w0 = true;
        this.x0 = true;
        this.z0 = true;
        this.C0 = true;
        this.D0 = true;
        this.E0 = true;
        this.F0 = true;
        this.G0 = true;
        this.I0 = true;
        this.L0 = true;
        int i3 = i.b;
        this.M0 = i3;
        this.V0 = new a();
        this.q = context;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.J, i, i2);
        this.q0 = k.n(typedArrayObtainStyledAttributes, l.h0, l.K, 0);
        this.s0 = k.o(typedArrayObtainStyledAttributes, l.k0, l.Q);
        this.o0 = k.p(typedArrayObtainStyledAttributes, l.s0, l.O);
        this.p0 = k.p(typedArrayObtainStyledAttributes, l.r0, l.R);
        this.m0 = k.d(typedArrayObtainStyledAttributes, l.m0, l.S, SubsamplingScaleImageView.TILE_SIZE_AUTO);
        this.u0 = k.o(typedArrayObtainStyledAttributes, l.g0, l.X);
        this.M0 = k.n(typedArrayObtainStyledAttributes, l.l0, l.N, i3);
        this.N0 = k.n(typedArrayObtainStyledAttributes, l.t0, l.T, 0);
        this.w0 = k.b(typedArrayObtainStyledAttributes, l.f0, l.M, true);
        this.x0 = k.b(typedArrayObtainStyledAttributes, l.o0, l.P, true);
        this.z0 = k.b(typedArrayObtainStyledAttributes, l.n0, l.L, true);
        this.A0 = k.o(typedArrayObtainStyledAttributes, l.d0, l.U);
        int i4 = l.a0;
        this.F0 = k.b(typedArrayObtainStyledAttributes, i4, i4, this.x0);
        int i5 = l.b0;
        this.G0 = k.b(typedArrayObtainStyledAttributes, i5, i5, this.x0);
        int i6 = l.c0;
        if (typedArrayObtainStyledAttributes.hasValue(i6)) {
            this.B0 = g0(typedArrayObtainStyledAttributes, i6);
        } else {
            int i7 = l.V;
            if (typedArrayObtainStyledAttributes.hasValue(i7)) {
                this.B0 = g0(typedArrayObtainStyledAttributes, i7);
            }
        }
        this.L0 = k.b(typedArrayObtainStyledAttributes, l.p0, l.W, true);
        int i8 = l.q0;
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i8);
        this.H0 = zHasValue;
        if (zHasValue) {
            this.I0 = k.b(typedArrayObtainStyledAttributes, i8, l.Y, true);
        }
        this.J0 = k.b(typedArrayObtainStyledAttributes, l.i0, l.Z, false);
        int i9 = l.j0;
        this.E0 = k.b(typedArrayObtainStyledAttributes, i9, i9, true);
        int i10 = l.e0;
        this.K0 = k.b(typedArrayObtainStyledAttributes, i10, i10, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void Q0(SharedPreferences.Editor editor) {
        if (this.X.t()) {
            editor.apply();
        }
    }

    private void R0() {
        Preference preferenceS;
        String str = this.A0;
        if (str == null || (preferenceS = s(str)) == null) {
            return;
        }
        preferenceS.S0(this);
    }

    private void S0(Preference preference) {
        List<Preference> list = this.P0;
        if (list != null) {
            list.remove(preference);
        }
    }

    private void q() {
        J();
        if (P0() && L().contains(this.s0)) {
            n0(true, null);
            return;
        }
        Object obj = this.B0;
        if (obj != null) {
            n0(false, obj);
        }
    }

    private void u0() {
        if (TextUtils.isEmpty(this.A0)) {
            return;
        }
        Preference preferenceS = s(this.A0);
        if (preferenceS != null) {
            preferenceS.v0(this);
            return;
        }
        throw new IllegalStateException("Dependency \"" + this.A0 + "\" not found for preference \"" + this.s0 + "\" (title: \"" + ((Object) this.o0) + "\"");
    }

    private void v0(Preference preference) {
        if (this.P0 == null) {
            this.P0 = new ArrayList();
        }
        this.P0.add(preference);
        preference.e0(this, O0());
    }

    private void z0(View view, boolean z) {
        view.setEnabled(z);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                z0(viewGroup.getChildAt(childCount), z);
            }
        }
    }

    public void A0(int i) {
        B0(ax.p226o.a.b(this.q, i));
        this.q0 = i;
    }

    public String B() {
        return this.s0;
    }

    public void B0(Drawable drawable) {
        if (this.r0 != drawable) {
            this.r0 = drawable;
            this.q0 = 0;
            W();
        }
    }

    public final int C() {
        return this.M0;
    }

    public void C0(Intent intent) {
        this.t0 = intent;
    }

    public int D() {
        return this.m0;
    }

    public void D0(String str) {
        this.s0 = str;
        if (!this.y0 || Q()) {
            return;
        }
        w0();
    }

    public PreferenceGroup E() {
        return this.Q0;
    }

    public void E0(int i) {
        this.M0 = i;
    }

    protected boolean F(boolean z) {
        if (!P0()) {
            return z;
        }
        J();
        return this.X.l().getBoolean(this.s0, z);
    }

    final void F0(c cVar) {
        this.O0 = cVar;
    }

    protected int G(int i) {
        if (!P0()) {
            return i;
        }
        J();
        return this.X.l().getInt(this.s0, i);
    }

    public void G0(d dVar) {
        this.k0 = dVar;
    }

    protected String H(String str) {
        if (!P0()) {
            return str;
        }
        J();
        return this.X.l().getString(this.s0, str);
    }

    public void H0(e eVar) {
        this.l0 = eVar;
    }

    public Set<String> I(Set<String> set) {
        if (!P0()) {
            return set;
        }
        J();
        return this.X.l().getStringSet(this.s0, set);
    }

    public void I0(int i) {
        if (i != this.m0) {
            this.m0 = i;
            Y();
        }
    }

    public ax.p021b2.d J() {
        androidx.preference.g gVar = this.X;
        if (gVar != null) {
            gVar.j();
        }
        return null;
    }

    public void J0(CharSequence charSequence) {
        if (N() != null) {
            throw new IllegalStateException("Preference already has a SummaryProvider set.");
        }
        if (TextUtils.equals(this.p0, charSequence)) {
            return;
        }
        this.p0 = charSequence;
        W();
    }

    public androidx.preference.g K() {
        return this.X;
    }

    public final void K0(g gVar) {
        this.U0 = gVar;
        W();
    }

    public SharedPreferences L() {
        if (this.X == null) {
            return null;
        }
        J();
        return this.X.l();
    }

    public void L0(int i) {
        M0(this.q.getString(i));
    }

    public CharSequence M() {
        return N() != null ? N().a(this) : this.p0;
    }

    public void M0(CharSequence charSequence) {
        if (TextUtils.equals(charSequence, this.o0)) {
            return;
        }
        this.o0 = charSequence;
        W();
    }

    public final g N() {
        return this.U0;
    }

    public final void N0(boolean z) {
        if (this.E0 != z) {
            this.E0 = z;
            c cVar = this.O0;
            if (cVar != null) {
                cVar.d(this);
            }
        }
    }

    public CharSequence O() {
        return this.o0;
    }

    public boolean O0() {
        return !S();
    }

    public final int P() {
        return this.N0;
    }

    protected boolean P0() {
        return this.X != null && T() && Q();
    }

    public boolean Q() {
        return !TextUtils.isEmpty(this.s0);
    }

    public boolean R() {
        return this.K0;
    }

    public boolean S() {
        return this.w0 && this.C0 && this.D0;
    }

    public boolean T() {
        return this.z0;
    }

    public boolean U() {
        return this.x0;
    }

    public final boolean V() {
        return this.E0;
    }

    protected void W() {
        c cVar = this.O0;
        if (cVar != null) {
            cVar.f(this);
        }
    }

    public void X(boolean z) {
        List<Preference> list = this.P0;
        if (list == null) {
            return;
        }
        int size = list.size();
        for (int i = 0; i < size; i++) {
            list.get(i).e0(this, z);
        }
    }

    protected void Y() {
        c cVar = this.O0;
        if (cVar != null) {
            cVar.a(this);
        }
    }

    public void Z() {
        u0();
    }

    protected void a0(androidx.preference.g gVar) {
        this.X = gVar;
        if (!this.Z) {
            this.Y = gVar.f();
        }
        q();
    }

    protected void b0(androidx.preference.g gVar, long j) {
        this.Y = j;
        this.Z = true;
        try {
            a0(gVar);
        } finally {
            this.Z = false;
        }
    }

    public void c0(h hVar) {
        Integer numValueOf;
        View view = hVar.a;
        view.setOnClickListener(this.V0);
        view.setId(this.n0);
        TextView textView = (TextView) hVar.N(R.id.summary);
        if (textView != null) {
            CharSequence charSequenceM = M();
            if (TextUtils.isEmpty(charSequenceM)) {
                textView.setVisibility(8);
                numValueOf = null;
            } else {
                textView.setText(charSequenceM);
                textView.setVisibility(0);
                numValueOf = Integer.valueOf(textView.getCurrentTextColor());
            }
        } else {
            numValueOf = null;
        }
        TextView textView2 = (TextView) hVar.N(R.id.title);
        if (textView2 != null) {
            CharSequence charSequenceO = O();
            if (TextUtils.isEmpty(charSequenceO)) {
                textView2.setVisibility(8);
            } else {
                textView2.setText(charSequenceO);
                textView2.setVisibility(0);
                if (this.H0) {
                    textView2.setSingleLine(this.I0);
                }
                if (!U() && S() && numValueOf != null) {
                    textView2.setTextColor(numValueOf.intValue());
                }
            }
        }
        ImageView imageView = (ImageView) hVar.N(R.id.icon);
        if (imageView != null) {
            int i = this.q0;
            if (i != 0 || this.r0 != null) {
                if (this.r0 == null) {
                    this.r0 = ax.p226o.a.b(this.q, i);
                }
                Drawable drawable = this.r0;
                if (drawable != null) {
                    imageView.setImageDrawable(drawable);
                }
            }
            if (this.r0 != null) {
                imageView.setVisibility(0);
            } else {
                imageView.setVisibility(this.J0 ? 4 : 8);
            }
        }
        View viewN = hVar.N(ax.p021b2.h.a);
        if (viewN == null) {
            viewN = hVar.N(R.id.icon_frame);
        }
        if (viewN != null) {
            if (this.r0 != null) {
                viewN.setVisibility(0);
            } else {
                viewN.setVisibility(this.J0 ? 4 : 8);
            }
        }
        if (this.L0) {
            z0(view, S());
        } else {
            z0(view, true);
        }
        boolean zU = U();
        view.setFocusable(zU);
        view.setClickable(zU);
        hVar.R(this.F0);
        hVar.S(this.G0);
        boolean zR = R();
        if (zR && this.T0 == null) {
            this.T0 = new f(this);
        }
        view.setOnCreateContextMenuListener(zR ? this.T0 : null);
        view.setLongClickable(zR);
        if (!zR || zU) {
            return;
        }
        C1839d0.o0(view, null);
    }

    protected void d0() {
    }

    public void e0(Preference preference, boolean z) {
        if (this.C0 == z) {
            this.C0 = !z;
            X(O0());
            W();
        }
    }

    public void f0() {
        R0();
        this.R0 = true;
    }

    void g(PreferenceGroup preferenceGroup) {
        if (preferenceGroup != null && this.Q0 != null) {
            throw new IllegalStateException("This preference already has a parent. You must remove the existing parent before assigning a new one.");
        }
        this.Q0 = preferenceGroup;
    }

    protected Object g0(TypedArray typedArray, int i) {
        return null;
    }

    public boolean h(Object obj) {
        d dVar = this.k0;
        return dVar == null || dVar.a(this, obj);
    }

    @Deprecated
    public void h0(H h) {
    }

    public void i0(Preference preference, boolean z) {
        if (this.D0 == z) {
            this.D0 = !z;
            X(O0());
            W();
        }
    }

    protected void j0() {
        R0();
    }

    final void k() {
        this.R0 = false;
    }

    protected void k0(Parcelable parcelable) {
        this.S0 = true;
        if (parcelable != AbsSavedState.EMPTY_STATE && parcelable != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
    }

    protected Parcelable l0() {
        this.S0 = true;
        return AbsSavedState.EMPTY_STATE;
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public int compareTo(Preference preference) {
        int i = this.m0;
        int i2 = preference.m0;
        if (i != i2) {
            return i - i2;
        }
        CharSequence charSequence = this.o0;
        CharSequence charSequence2 = preference.o0;
        if (charSequence == charSequence2) {
            return 0;
        }
        if (charSequence == null) {
            return 1;
        }
        if (charSequence2 == null) {
            return -1;
        }
        return charSequence.toString().compareToIgnoreCase(preference.o0.toString());
    }

    protected void m0(Object obj) {
    }

    @Deprecated
    protected void n0(boolean z, Object obj) {
        m0(obj);
    }

    void o(Bundle bundle) {
        Parcelable parcelable;
        if (!Q() || (parcelable = bundle.getParcelable(this.s0)) == null) {
            return;
        }
        this.S0 = false;
        k0(parcelable);
        if (!this.S0) {
            throw new IllegalStateException("Derived class did not call super.onRestoreInstanceState()");
        }
    }

    public void o0() {
        androidx.preference.g.c cVarH;
        if (S() && U()) {
            d0();
            e eVar = this.l0;
            if (eVar == null || !eVar.a(this)) {
                androidx.preference.g gVarK = K();
                if ((gVarK == null || (cVarH = gVarK.h()) == null || !cVarH.e0(this)) && this.t0 != null) {
                    t().startActivity(this.t0);
                }
            }
        }
    }

    void p(Bundle bundle) {
        if (Q()) {
            this.S0 = false;
            Parcelable parcelableL0 = l0();
            if (!this.S0) {
                throw new IllegalStateException("Derived class did not call super.onSaveInstanceState()");
            }
            if (parcelableL0 != null) {
                bundle.putParcelable(this.s0, parcelableL0);
            }
        }
    }

    protected void p0(View view) {
        o0();
    }

    protected boolean q0(boolean z) {
        if (!P0()) {
            return false;
        }
        if (z == F(!z)) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putBoolean(this.s0, z);
        Q0(editorE);
        return true;
    }

    protected boolean r0(int i) {
        if (!P0()) {
            return false;
        }
        if (i == G(~i)) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putInt(this.s0, i);
        Q0(editorE);
        return true;
    }

    protected <T extends Preference> T s(String str) {
        androidx.preference.g gVar = this.X;
        if (gVar == null) {
            return null;
        }
        return (T) gVar.a(str);
    }

    protected boolean s0(String str) {
        if (!P0()) {
            return false;
        }
        if (TextUtils.equals(str, H(null))) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putString(this.s0, str);
        Q0(editorE);
        return true;
    }

    public Context t() {
        return this.q;
    }

    public boolean t0(Set<String> set) {
        if (!P0()) {
            return false;
        }
        if (set.equals(I(null))) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putStringSet(this.s0, set);
        Q0(editorE);
        return true;
    }

    public String toString() {
        return v().toString();
    }

    public Bundle u() {
        if (this.v0 == null) {
            this.v0 = new Bundle();
        }
        return this.v0;
    }

    StringBuilder v() {
        StringBuilder sb = new StringBuilder();
        CharSequence charSequenceO = O();
        if (!TextUtils.isEmpty(charSequenceO)) {
            sb.append(charSequenceO);
            sb.append(' ');
        }
        CharSequence charSequenceM = M();
        if (!TextUtils.isEmpty(charSequenceM)) {
            sb.append(charSequenceM);
            sb.append(' ');
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb;
    }

    public String w() {
        return this.u0;
    }

    void w0() {
        if (TextUtils.isEmpty(this.s0)) {
            throw new IllegalStateException("Preference does not have a key assigned.");
        }
        this.y0 = true;
    }

    long x() {
        return this.Y;
    }

    public void x0(Bundle bundle) {
        o(bundle);
    }

    public Intent y() {
        return this.t0;
    }

    public void y0(Bundle bundle) {
        p(bundle);
    }
}
