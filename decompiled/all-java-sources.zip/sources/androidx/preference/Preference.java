package androidx.preference;

import android.R;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import ax.N0.i;
import ax.N0.j;
import ax.N0.l;
import ax.R.k;
import ax.p015b0.Y;
import ax.p029c0.I;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class Preference implements Comparable<Preference> {
    private boolean A0;
    private boolean B0;
    private boolean C0;
    private boolean D0;
    private boolean E0;
    private boolean F0;
    private boolean G0;
    private boolean H0;
    private boolean I0;
    private int J0;
    private int K0;
    private c L0;
    private List<Preference> M0;
    private PreferenceGroup N0;
    private boolean O0;
    private boolean P0;
    private f Q0;
    private g R0;
    private final View.OnClickListener S0;
    private androidx.preference.g X;
    private long Y;
    private boolean Z;
    private d h0;
    private e i0;
    private int j0;
    private int k0;
    private CharSequence l0;
    private CharSequence m0;
    private int n0;
    private Drawable o0;
    private String p0;
    private final Context q;
    private Intent q0;
    private String r0;
    private Bundle s0;
    private boolean t0;
    private boolean u0;
    private boolean v0;
    private boolean w0;
    private String x0;
    private Object y0;
    private boolean z0;

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Preference.this.p0(view);
        }
    }

    public static class b extends AbsSavedState {
        public static final Parcelable.Creator<b> CREATOR = new a();

        class a implements Parcelable.Creator<b> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public b createFromParcel(Parcel parcel) {
                return new b(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public b[] newArray(int i) {
                return new b[i];
            }
        }

        public b(Parcel parcel) {
            super(parcel);
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }
    }

    interface c {
        void a(Preference preference);

        void d(Preference preference);

        void f(Preference preference);
    }

    public interface d {
        boolean a(Preference preference, Object obj);
    }

    public interface e {
        boolean a(Preference preference);
    }

    private static class f implements View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        private final Preference q;

        f(Preference preference) {
            this.q = preference;
        }

        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
            CharSequence charSequenceM = this.q.M();
            if (!this.q.R() || TextUtils.isEmpty(charSequenceM)) {
                return;
            }
            contextMenu.setHeaderTitle(charSequenceM);
            contextMenu.add(0, 0, 0, j.a).setOnMenuItemClickListener(this);
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            ClipboardManager clipboardManager = (ClipboardManager) this.q.s().getSystemService("clipboard");
            CharSequence charSequenceM = this.q.M();
            clipboardManager.setPrimaryClip(ClipData.newPlainText("Preference", charSequenceM));
            Toast.makeText(this.q.s(), this.q.s().getString(j.d, charSequenceM), 0).show();
            return true;
        }
    }

    public interface g<T extends Preference> {
        CharSequence a(T t);
    }

    public Preference(Context context, AttributeSet attributeSet, int i, int i2) {
        this.j0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.k0 = 0;
        this.t0 = true;
        this.u0 = true;
        this.w0 = true;
        this.z0 = true;
        this.A0 = true;
        this.B0 = true;
        this.C0 = true;
        this.D0 = true;
        this.F0 = true;
        this.I0 = true;
        int i3 = i.b;
        this.J0 = i3;
        this.S0 = new a();
        this.q = context;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.J, i, i2);
        this.n0 = k.n(typedArrayObtainStyledAttributes, l.h0, l.K, 0);
        this.p0 = k.o(typedArrayObtainStyledAttributes, l.k0, l.Q);
        this.l0 = k.p(typedArrayObtainStyledAttributes, l.s0, l.O);
        this.m0 = k.p(typedArrayObtainStyledAttributes, l.r0, l.R);
        this.j0 = k.d(typedArrayObtainStyledAttributes, l.m0, l.S, SubsamplingScaleImageView.TILE_SIZE_AUTO);
        this.r0 = k.o(typedArrayObtainStyledAttributes, l.g0, l.X);
        this.J0 = k.n(typedArrayObtainStyledAttributes, l.l0, l.N, i3);
        this.K0 = k.n(typedArrayObtainStyledAttributes, l.t0, l.T, 0);
        this.t0 = k.b(typedArrayObtainStyledAttributes, l.f0, l.M, true);
        this.u0 = k.b(typedArrayObtainStyledAttributes, l.o0, l.P, true);
        this.w0 = k.b(typedArrayObtainStyledAttributes, l.n0, l.L, true);
        this.x0 = k.o(typedArrayObtainStyledAttributes, l.d0, l.U);
        int i4 = l.a0;
        this.C0 = k.b(typedArrayObtainStyledAttributes, i4, i4, this.u0);
        int i5 = l.b0;
        this.D0 = k.b(typedArrayObtainStyledAttributes, i5, i5, this.u0);
        int i6 = l.c0;
        if (typedArrayObtainStyledAttributes.hasValue(i6)) {
            this.y0 = g0(typedArrayObtainStyledAttributes, i6);
        } else {
            int i7 = l.V;
            if (typedArrayObtainStyledAttributes.hasValue(i7)) {
                this.y0 = g0(typedArrayObtainStyledAttributes, i7);
            }
        }
        this.I0 = k.b(typedArrayObtainStyledAttributes, l.p0, l.W, true);
        int i8 = l.q0;
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i8);
        this.E0 = zHasValue;
        if (zHasValue) {
            this.F0 = k.b(typedArrayObtainStyledAttributes, i8, l.Y, true);
        }
        this.G0 = k.b(typedArrayObtainStyledAttributes, l.i0, l.Z, false);
        int i9 = l.j0;
        this.B0 = k.b(typedArrayObtainStyledAttributes, i9, i9, true);
        int i10 = l.e0;
        this.H0 = k.b(typedArrayObtainStyledAttributes, i10, i10, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void Q0(SharedPreferences.Editor editor) {
        if (this.X.t()) {
            editor.apply();
        }
    }

    private void R0() {
        Preference preferenceR;
        String str = this.x0;
        if (str == null || (preferenceR = r(str)) == null) {
            return;
        }
        preferenceR.S0(this);
    }

    private void S0(Preference preference) {
        List<Preference> list = this.M0;
        if (list != null) {
            list.remove(preference);
        }
    }

    private void q() {
        J();
        if (P0() && L().contains(this.p0)) {
            n0(true, null);
            return;
        }
        Object obj = this.y0;
        if (obj != null) {
            n0(false, obj);
        }
    }

    private void u0() {
        if (TextUtils.isEmpty(this.x0)) {
            return;
        }
        Preference preferenceR = r(this.x0);
        if (preferenceR != null) {
            preferenceR.v0(this);
            return;
        }
        throw new IllegalStateException("Dependency \"" + this.x0 + "\" not found for preference \"" + this.p0 + "\" (title: \"" + ((Object) this.l0) + "\"");
    }

    private void v0(Preference preference) {
        if (this.M0 == null) {
            this.M0 = new ArrayList();
        }
        this.M0.add(preference);
        preference.e0(this, O0());
    }

    private void z0(View view, boolean z) {
        view.setEnabled(z);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                z0(viewGroup.getChildAt(childCount), z);
            }
        }
    }

    public void A0(int i) {
        B0(ax.p196o.a.b(this.q, i));
        this.n0 = i;
    }

    public String B() {
        return this.p0;
    }

    public void B0(Drawable drawable) {
        if (this.o0 != drawable) {
            this.o0 = drawable;
            this.n0 = 0;
            W();
        }
    }

    public final int C() {
        return this.J0;
    }

    public void C0(Intent intent) {
        this.q0 = intent;
    }

    public int D() {
        return this.j0;
    }

    public void D0(String str) {
        this.p0 = str;
        if (!this.v0 || Q()) {
            return;
        }
        w0();
    }

    public PreferenceGroup E() {
        return this.N0;
    }

    public void E0(int i) {
        this.J0 = i;
    }

    protected boolean F(boolean z) {
        if (!P0()) {
            return z;
        }
        J();
        return this.X.l().getBoolean(this.p0, z);
    }

    final void F0(c cVar) {
        this.L0 = cVar;
    }

    protected int G(int i) {
        if (!P0()) {
            return i;
        }
        J();
        return this.X.l().getInt(this.p0, i);
    }

    public void G0(d dVar) {
        this.h0 = dVar;
    }

    protected String H(String str) {
        if (!P0()) {
            return str;
        }
        J();
        return this.X.l().getString(this.p0, str);
    }

    public void H0(e eVar) {
        this.i0 = eVar;
    }

    public Set<String> I(Set<String> set) {
        if (!P0()) {
            return set;
        }
        J();
        return this.X.l().getStringSet(this.p0, set);
    }

    public void I0(int i) {
        if (i != this.j0) {
            this.j0 = i;
            Y();
        }
    }

    public ax.N0.d J() {
        androidx.preference.g gVar = this.X;
        if (gVar != null) {
            gVar.j();
        }
        return null;
    }

    public void J0(CharSequence charSequence) {
        if (N() != null) {
            throw new IllegalStateException("Preference already has a SummaryProvider set.");
        }
        if (TextUtils.equals(this.m0, charSequence)) {
            return;
        }
        this.m0 = charSequence;
        W();
    }

    public androidx.preference.g K() {
        return this.X;
    }

    public final void K0(g gVar) {
        this.R0 = gVar;
        W();
    }

    public SharedPreferences L() {
        if (this.X == null) {
            return null;
        }
        J();
        return this.X.l();
    }

    public void L0(int i) {
        M0(this.q.getString(i));
    }

    public CharSequence M() {
        return N() != null ? N().a(this) : this.m0;
    }

    public void M0(CharSequence charSequence) {
        if (TextUtils.equals(charSequence, this.l0)) {
            return;
        }
        this.l0 = charSequence;
        W();
    }

    public final g N() {
        return this.R0;
    }

    public final void N0(boolean z) {
        if (this.B0 != z) {
            this.B0 = z;
            c cVar = this.L0;
            if (cVar != null) {
                cVar.d(this);
            }
        }
    }

    public CharSequence O() {
        return this.l0;
    }

    public boolean O0() {
        return !S();
    }

    public final int P() {
        return this.K0;
    }

    protected boolean P0() {
        return this.X != null && T() && Q();
    }

    public boolean Q() {
        return !TextUtils.isEmpty(this.p0);
    }

    public boolean R() {
        return this.H0;
    }

    public boolean S() {
        return this.t0 && this.z0 && this.A0;
    }

    public boolean T() {
        return this.w0;
    }

    public boolean U() {
        return this.u0;
    }

    public final boolean V() {
        return this.B0;
    }

    protected void W() {
        c cVar = this.L0;
        if (cVar != null) {
            cVar.f(this);
        }
    }

    public void X(boolean z) {
        List<Preference> list = this.M0;
        if (list == null) {
            return;
        }
        int size = list.size();
        for (int i = 0; i < size; i++) {
            list.get(i).e0(this, z);
        }
    }

    protected void Y() {
        c cVar = this.L0;
        if (cVar != null) {
            cVar.a(this);
        }
    }

    public void Z() {
        u0();
    }

    protected void a0(androidx.preference.g gVar) {
        this.X = gVar;
        if (!this.Z) {
            this.Y = gVar.f();
        }
        q();
    }

    protected void b0(androidx.preference.g gVar, long j) {
        this.Y = j;
        this.Z = true;
        try {
            a0(gVar);
        } finally {
            this.Z = false;
        }
    }

    public void c0(h hVar) {
        Integer numValueOf;
        View view = hVar.a;
        view.setOnClickListener(this.S0);
        view.setId(this.k0);
        TextView textView = (TextView) hVar.N(R.id.summary);
        if (textView != null) {
            CharSequence charSequenceM = M();
            if (TextUtils.isEmpty(charSequenceM)) {
                textView.setVisibility(8);
                numValueOf = null;
            } else {
                textView.setText(charSequenceM);
                textView.setVisibility(0);
                numValueOf = Integer.valueOf(textView.getCurrentTextColor());
            }
        } else {
            numValueOf = null;
        }
        TextView textView2 = (TextView) hVar.N(R.id.title);
        if (textView2 != null) {
            CharSequence charSequenceO = O();
            if (TextUtils.isEmpty(charSequenceO)) {
                textView2.setVisibility(8);
            } else {
                textView2.setText(charSequenceO);
                textView2.setVisibility(0);
                if (this.E0) {
                    textView2.setSingleLine(this.F0);
                }
                if (!U() && S() && numValueOf != null) {
                    textView2.setTextColor(numValueOf.intValue());
                }
            }
        }
        ImageView imageView = (ImageView) hVar.N(R.id.icon);
        if (imageView != null) {
            int i = this.n0;
            if (i != 0 || this.o0 != null) {
                if (this.o0 == null) {
                    this.o0 = ax.p196o.a.b(this.q, i);
                }
                Drawable drawable = this.o0;
                if (drawable != null) {
                    imageView.setImageDrawable(drawable);
                }
            }
            if (this.o0 != null) {
                imageView.setVisibility(0);
            } else {
                imageView.setVisibility(this.G0 ? 4 : 8);
            }
        }
        View viewN = hVar.N(ax.N0.h.a);
        if (viewN == null) {
            viewN = hVar.N(R.id.icon_frame);
        }
        if (viewN != null) {
            if (this.o0 != null) {
                viewN.setVisibility(0);
            } else {
                viewN.setVisibility(this.G0 ? 4 : 8);
            }
        }
        if (this.I0) {
            z0(view, S());
        } else {
            z0(view, true);
        }
        boolean zU = U();
        view.setFocusable(zU);
        view.setClickable(zU);
        hVar.R(this.C0);
        hVar.S(this.D0);
        boolean zR = R();
        if (zR && this.Q0 == null) {
            this.Q0 = new f(this);
        }
        view.setOnCreateContextMenuListener(zR ? this.Q0 : null);
        view.setLongClickable(zR);
        if (!zR || zU) {
            return;
        }
        Y.u0(view, null);
    }

    protected void d0() {
    }

    public void e0(Preference preference, boolean z) {
        if (this.z0 == z) {
            this.z0 = !z;
            X(O0());
            W();
        }
    }

    public void f0() {
        R0();
        this.O0 = true;
    }

    void g(PreferenceGroup preferenceGroup) {
        if (preferenceGroup != null && this.N0 != null) {
            throw new IllegalStateException("This preference already has a parent. You must remove the existing parent before assigning a new one.");
        }
        this.N0 = preferenceGroup;
    }

    protected Object g0(TypedArray typedArray, int i) {
        return null;
    }

    public boolean h(Object obj) {
        d dVar = this.h0;
        return dVar == null || dVar.a(this, obj);
    }

    public void i0(Preference preference, boolean z) {
        if (this.A0 == z) {
            this.A0 = !z;
            X(O0());
            W();
        }
    }

    protected void j0() {
        R0();
    }

    final void k() {
        this.O0 = false;
    }

    protected void k0(Parcelable parcelable) {
        this.P0 = true;
        if (parcelable != AbsSavedState.EMPTY_STATE && parcelable != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
    }

    protected Parcelable l0() {
        this.P0 = true;
        return AbsSavedState.EMPTY_STATE;
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public int compareTo(Preference preference) {
        int i = this.j0;
        int i2 = preference.j0;
        if (i != i2) {
            return i - i2;
        }
        CharSequence charSequence = this.l0;
        CharSequence charSequence2 = preference.l0;
        if (charSequence == charSequence2) {
            return 0;
        }
        if (charSequence == null) {
            return 1;
        }
        if (charSequence2 == null) {
            return -1;
        }
        return charSequence.toString().compareToIgnoreCase(preference.l0.toString());
    }

    protected void m0(Object obj) {
    }

    void n(Bundle bundle) {
        Parcelable parcelable;
        if (!Q() || (parcelable = bundle.getParcelable(this.p0)) == null) {
            return;
        }
        this.P0 = false;
        k0(parcelable);
        if (!this.P0) {
            throw new IllegalStateException("Derived class did not call super.onRestoreInstanceState()");
        }
    }

    @Deprecated
    protected void n0(boolean z, Object obj) {
        m0(obj);
    }

    void o(Bundle bundle) {
        if (Q()) {
            this.P0 = false;
            Parcelable parcelableL0 = l0();
            if (!this.P0) {
                throw new IllegalStateException("Derived class did not call super.onSaveInstanceState()");
            }
            if (parcelableL0 != null) {
                bundle.putParcelable(this.p0, parcelableL0);
            }
        }
    }

    public void o0() {
        androidx.preference.g.c cVarH;
        if (S() && U()) {
            d0();
            e eVar = this.i0;
            if (eVar == null || !eVar.a(this)) {
                androidx.preference.g gVarK = K();
                if ((gVarK == null || (cVarH = gVarK.h()) == null || !cVarH.g0(this)) && this.q0 != null) {
                    s().startActivity(this.q0);
                }
            }
        }
    }

    protected void p0(View view) {
        o0();
    }

    protected boolean q0(boolean z) {
        if (!P0()) {
            return false;
        }
        if (z == F(!z)) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putBoolean(this.p0, z);
        Q0(editorE);
        return true;
    }

    protected <T extends Preference> T r(String str) {
        androidx.preference.g gVar = this.X;
        if (gVar == null) {
            return null;
        }
        return (T) gVar.a(str);
    }

    protected boolean r0(int i) {
        if (!P0()) {
            return false;
        }
        if (i == G(~i)) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putInt(this.p0, i);
        Q0(editorE);
        return true;
    }

    public Context s() {
        return this.q;
    }

    protected boolean s0(String str) {
        if (!P0()) {
            return false;
        }
        if (TextUtils.equals(str, H(null))) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putString(this.p0, str);
        Q0(editorE);
        return true;
    }

    public Bundle t() {
        if (this.s0 == null) {
            this.s0 = new Bundle();
        }
        return this.s0;
    }

    public boolean t0(Set<String> set) {
        if (!P0()) {
            return false;
        }
        if (set.equals(I(null))) {
            return true;
        }
        J();
        SharedPreferences.Editor editorE = this.X.e();
        editorE.putStringSet(this.p0, set);
        Q0(editorE);
        return true;
    }

    public String toString() {
        return u().toString();
    }

    StringBuilder u() {
        StringBuilder sb = new StringBuilder();
        CharSequence charSequenceO = O();
        if (!TextUtils.isEmpty(charSequenceO)) {
            sb.append(charSequenceO);
            sb.append(' ');
        }
        CharSequence charSequenceM = M();
        if (!TextUtils.isEmpty(charSequenceM)) {
            sb.append(charSequenceM);
            sb.append(' ');
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb;
    }

    public String v() {
        return this.r0;
    }

    long w() {
        return this.Y;
    }

    void w0() {
        if (TextUtils.isEmpty(this.p0)) {
            throw new IllegalStateException("Preference does not have a key assigned.");
        }
        this.v0 = true;
    }

    public void x0(Bundle bundle) {
        n(bundle);
    }

    public Intent y() {
        return this.q0;
    }

    public void y0(Bundle bundle) {
        o(bundle);
    }

    @Deprecated
    public void h0(I i) {
    }

    public Preference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public Preference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a(context, ax.N0.f.h, R.attr.preferenceStyle));
    }

    public Preference(Context context) {
        this(context, null);
    }
}
