package androidx.preference;

import android.R;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.m;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ax.N0.i;
import ax.N0.k;
import ax.N0.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class d extends Fragment implements g.c, g.a, g.b, DialogPreference.a {
    private g h1;
    RecyclerView i1;
    private boolean j1;
    private boolean k1;
    private Runnable m1;
    private final c g1 = new c();
    private int l1 = i.c;
    private final Handler n1 = new a(Looper.getMainLooper());
    private final Runnable o1 = new b();

    class a extends Handler {
        a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                return;
            }
            d.this.Y2();
        }
    }

    class b implements Runnable {
        b() {
        }

        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = d.this.i1;
            recyclerView.focusableViewAvailable(recyclerView);
        }
    }

    private class c extends RecyclerView.o {
        private Drawable a;
        private int b;
        private boolean c = true;

        c() {
        }

        private boolean o(View view, RecyclerView recyclerView) {
            RecyclerView.F fM0 = recyclerView.m0(view);
            boolean z = false;
            if (!(fM0 instanceof h) || !((h) fM0).P()) {
                return false;
            }
            boolean z2 = this.c;
            int iIndexOfChild = recyclerView.indexOfChild(view);
            if (iIndexOfChild >= recyclerView.getChildCount() - 1) {
                return z2;
            }
            RecyclerView.F fM1 = recyclerView.m0(recyclerView.getChildAt(iIndexOfChild + 1));
            if ((fM1 instanceof h) && ((h) fM1).O()) {
                z = true;
            }
            return z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.o
        public void g(Rect rect, View view, RecyclerView recyclerView, RecyclerView.B b) {
            if (o(view, recyclerView)) {
                rect.bottom = this.b;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.o
        public void k(Canvas canvas, RecyclerView recyclerView, RecyclerView.B b) {
            if (this.a == null) {
                return;
            }
            int childCount = recyclerView.getChildCount();
            int width = recyclerView.getWidth();
            for (int i = 0; i < childCount; i++) {
                View childAt = recyclerView.getChildAt(i);
                if (o(childAt, recyclerView)) {
                    int y = ((int) childAt.getY()) + childAt.getHeight();
                    this.a.setBounds(0, y, width, this.b + y);
                    this.a.draw(canvas);
                }
            }
        }

        public void l(boolean z) {
            this.c = z;
        }

        public void m(Drawable drawable) {
            if (drawable != null) {
                this.b = drawable.getIntrinsicHeight();
            } else {
                this.b = 0;
            }
            this.a = drawable;
            d.this.i1.C0();
        }

        public void n(int i) {
            this.b = i;
            d.this.i1.C0();
        }
    }

    /* JADX INFO: renamed from: androidx.preference.d$d, reason: collision with other inner class name */
    public interface InterfaceC0031d {
        boolean a(d dVar, Preference preference);
    }

    public interface e {
        boolean a(d dVar, Preference preference);
    }

    public interface f {
        boolean a(d dVar, PreferenceScreen preferenceScreen);
    }

    private void j3() {
        if (this.n1.hasMessages(1)) {
            return;
        }
        this.n1.obtainMessage(1).sendToTarget();
    }

    private void k3() {
        if (this.h1 == null) {
            throw new RuntimeException("This should be called after super.onCreate.");
        }
    }

    private void p3() {
        a3().setAdapter(null);
        PreferenceScreen preferenceScreenC3 = c3();
        if (preferenceScreenC3 != null) {
            preferenceScreenC3.f0();
        }
        i3();
    }

    @Override // androidx.fragment.app.Fragment
    public void B1(Bundle bundle) {
        super.B1(bundle);
        TypedValue typedValue = new TypedValue();
        D2().getTheme().resolveAttribute(ax.N0.f.i, typedValue, true);
        int i = typedValue.resourceId;
        if (i == 0) {
            i = k.a;
        }
        D2().getTheme().applyStyle(i, false);
        g gVar = new g(D2());
        this.h1 = gVar;
        gVar.p(this);
        g3(bundle, w0() != null ? w0().getString("androidx.preference.PreferenceFragmentCompat.PREFERENCE_ROOT") : null);
    }

    @Override // androidx.fragment.app.Fragment
    public View F1(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        TypedArray typedArrayObtainStyledAttributes = D2().obtainStyledAttributes(null, l.v0, ax.N0.f.f, 0);
        this.l1 = typedArrayObtainStyledAttributes.getResourceId(l.w0, this.l1);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(l.x0);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(l.y0, -1);
        boolean z = typedArrayObtainStyledAttributes.getBoolean(l.z0, true);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater layoutInflaterCloneInContext = layoutInflater.cloneInContext(D2());
        View viewInflate = layoutInflaterCloneInContext.inflate(this.l1, viewGroup, false);
        View viewFindViewById = viewInflate.findViewById(R.id.list_container);
        if (!(viewFindViewById instanceof ViewGroup)) {
            throw new IllegalStateException("Content has view with id attribute 'android.R.id.list_container' that is not a ViewGroup class");
        }
        ViewGroup viewGroup2 = (ViewGroup) viewFindViewById;
        RecyclerView recyclerViewH3 = h3(layoutInflaterCloneInContext, viewGroup2, bundle);
        if (recyclerViewH3 == null) {
            throw new RuntimeException("Could not create RecyclerView");
        }
        this.i1 = recyclerViewH3;
        recyclerViewH3.j(this.g1);
        l3(drawable);
        if (dimensionPixelSize != -1) {
            m3(dimensionPixelSize);
        }
        this.g1.l(z);
        if (this.i1.getParent() == null) {
            viewGroup2.addView(this.i1);
        }
        this.n1.post(this.o1);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void I1() {
        this.n1.removeCallbacks(this.o1);
        this.n1.removeMessages(1);
        if (this.j1) {
            p3();
        }
        this.i1 = null;
        super.I1();
    }

    @Override // androidx.fragment.app.Fragment
    public void W1(Bundle bundle) {
        super.W1(bundle);
        PreferenceScreen preferenceScreenC3 = c3();
        if (preferenceScreenC3 != null) {
            Bundle bundle2 = new Bundle();
            preferenceScreenC3.y0(bundle2);
            bundle.putBundle("android:preferences", bundle2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void X1() {
        super.X1();
        this.h1.q(this);
        this.h1.o(this);
    }

    public void X2(int i) {
        k3();
        n3(this.h1.m(D2(), i, c3()));
    }

    @Override // androidx.fragment.app.Fragment
    public void Y1() {
        super.Y1();
        this.h1.q(null);
        this.h1.o(null);
    }

    void Y2() {
        PreferenceScreen preferenceScreenC3 = c3();
        if (preferenceScreenC3 != null) {
            a3().setAdapter(e3(preferenceScreenC3));
            preferenceScreenC3.Z();
        }
        d3();
    }

    @Override // androidx.fragment.app.Fragment
    public void Z1(View view, Bundle bundle) {
        Bundle bundle2;
        PreferenceScreen preferenceScreenC3;
        super.Z1(view, bundle);
        if (bundle != null && (bundle2 = bundle.getBundle("android:preferences")) != null && (preferenceScreenC3 = c3()) != null) {
            preferenceScreenC3.x0(bundle2);
        }
        if (this.j1) {
            Y2();
            Runnable runnable = this.m1;
            if (runnable != null) {
                runnable.run();
                this.m1 = null;
            }
        }
        this.k1 = true;
    }

    public Fragment Z2() {
        return null;
    }

    public final RecyclerView a3() {
        return this.i1;
    }

    @Override // androidx.preference.g.a
    public void b0(Preference preference) {
        androidx.fragment.app.e eVarZ3;
        boolean zA = Z2() instanceof InterfaceC0031d ? ((InterfaceC0031d) Z2()).a(this, preference) : false;
        for (Fragment fragmentM0 = this; !zA && fragmentM0 != null; fragmentM0 = fragmentM0.M0()) {
            if (fragmentM0 instanceof InterfaceC0031d) {
                zA = ((InterfaceC0031d) fragmentM0).a(this, preference);
            }
        }
        if (!zA && (getContext() instanceof InterfaceC0031d)) {
            zA = ((InterfaceC0031d) getContext()).a(this, preference);
        }
        if (!zA && (s0() instanceof InterfaceC0031d)) {
            zA = ((InterfaceC0031d) s0()).a(this, preference);
        }
        if (!zA && N0().i0("androidx.preference.PreferenceFragment.DIALOG") == null) {
            if (preference instanceof EditTextPreference) {
                eVarZ3 = androidx.preference.a.A3(preference.B());
            } else if (preference instanceof ListPreference) {
                eVarZ3 = ax.N0.a.z3(preference.B());
            } else {
                if (!(preference instanceof MultiSelectListPreference)) {
                    throw new IllegalArgumentException("Cannot display dialog for an unknown Preference type: " + preference.getClass().getSimpleName() + ". Make sure to implement onPreferenceDisplayDialog() to handle displaying a custom dialog for this Preference.");
                }
                eVarZ3 = ax.N0.b.z3(preference.B());
            }
            eVarZ3.R2(this, 0);
            eVarZ3.p3(N0(), "androidx.preference.PreferenceFragment.DIALOG");
        }
    }

    public g b3() {
        return this.h1;
    }

    public PreferenceScreen c3() {
        return this.h1.k();
    }

    @Override // androidx.preference.g.b
    public void d0(PreferenceScreen preferenceScreen) {
        boolean zA = Z2() instanceof f ? ((f) Z2()).a(this, preferenceScreen) : false;
        for (Fragment fragmentM0 = this; !zA && fragmentM0 != null; fragmentM0 = fragmentM0.M0()) {
            if (fragmentM0 instanceof f) {
                zA = ((f) fragmentM0).a(this, preferenceScreen);
            }
        }
        if (!zA && (getContext() instanceof f)) {
            zA = ((f) getContext()).a(this, preferenceScreen);
        }
        if (zA || !(s0() instanceof f)) {
            return;
        }
        ((f) s0()).a(this, preferenceScreen);
    }

    protected void d3() {
    }

    protected RecyclerView.h e3(PreferenceScreen preferenceScreen) {
        return new androidx.preference.e(preferenceScreen);
    }

    public RecyclerView.p f3() {
        return new LinearLayoutManager(D2());
    }

    @Override // androidx.preference.g.c
    public boolean g0(Preference preference) {
        if (preference.v() == null) {
            return false;
        }
        boolean zA = Z2() instanceof e ? ((e) Z2()).a(this, preference) : false;
        for (Fragment fragmentM0 = this; !zA && fragmentM0 != null; fragmentM0 = fragmentM0.M0()) {
            if (fragmentM0 instanceof e) {
                zA = ((e) fragmentM0).a(this, preference);
            }
        }
        if (!zA && (getContext() instanceof e)) {
            zA = ((e) getContext()).a(this, preference);
        }
        if (!zA && (s0() instanceof e)) {
            zA = ((e) s0()).a(this, preference);
        }
        if (zA) {
            return true;
        }
        Log.w("PreferenceFragment", "onPreferenceStartFragment is not implemented in the parent activity - attempting to use a fallback implementation. You should implement this method so that you can configure the new fragment that will be displayed, and set a transition between the fragments.");
        m mVarN0 = N0();
        Bundle bundleT = preference.t();
        Fragment fragmentA = mVarN0.s0().a(B2().getClassLoader(), preference.v());
        fragmentA.J2(bundleT);
        fragmentA.R2(this, 0);
        mVarN0.o().r(((View) E2().getParent()).getId(), fragmentA).g(null).i();
        return true;
    }

    public abstract void g3(Bundle bundle, String str);

    public RecyclerView h3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView recyclerView;
        if (D2().getPackageManager().hasSystemFeature("android.hardware.type.automotive") && (recyclerView = (RecyclerView) viewGroup.findViewById(ax.N0.h.b)) != null) {
            return recyclerView;
        }
        RecyclerView recyclerView2 = (RecyclerView) layoutInflater.inflate(i.d, viewGroup, false);
        recyclerView2.setLayoutManager(f3());
        recyclerView2.setAccessibilityDelegateCompat(new ax.N0.e(recyclerView2));
        return recyclerView2;
    }

    protected void i3() {
    }

    public void l3(Drawable drawable) {
        this.g1.m(drawable);
    }

    public void m3(int i) {
        this.g1.n(i);
    }

    public void n3(PreferenceScreen preferenceScreen) {
        if (!this.h1.r(preferenceScreen) || preferenceScreen == null) {
            return;
        }
        i3();
        this.j1 = true;
        if (this.k1) {
            j3();
        }
    }

    public void o3(int i, String str) {
        Preference preferenceV0;
        k3();
        PreferenceScreen preferenceScreenM = this.h1.m(D2(), i, null);
        Preference preference = preferenceScreenM;
        if (str != null) {
            preferenceV0 = preferenceScreenM.V0(str);
            if (!(preferenceV0 instanceof PreferenceScreen)) {
                preference = preferenceV0;
                throw new IllegalArgumentException("Preference object with key " + str + " is not a PreferenceScreen");
            }
        }
        preference = preferenceV0;
        n3((PreferenceScreen) preference);
    }

    @Override // androidx.preference.DialogPreference.a
    public <T extends Preference> T z(CharSequence charSequence) {
        g gVar = this.h1;
        if (gVar == null) {
            return null;
        }
        return (T) gVar.a(charSequence);
    }
}
