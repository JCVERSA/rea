package androidx.preference;

import android.R;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ax.p021b2.i;
import ax.p021b2.k;
import ax.p021b2.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class d extends Fragment implements g.c, g.a, g.b, DialogPreference.a {
    private g k1;
    RecyclerView l1;
    private boolean m1;
    private boolean n1;
    private Runnable p1;
    private final c j1 = new c();
    private int o1 = i.c;
    private final Handler q1 = new a(Looper.getMainLooper());
    private final Runnable r1 = new b();

    class a extends Handler {
        a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                return;
            }
            d.this.V2();
        }
    }

    class b implements Runnable {
        b() {
        }

        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = d.this.l1;
            recyclerView.focusableViewAvailable(recyclerView);
        }
    }

    private class c extends RecyclerView.o {
        private Drawable a;
        private int b;
        private boolean c = true;

        c() {
        }

        private boolean o(View view, RecyclerView recyclerView) {
            RecyclerView.F fM0 = recyclerView.m0(view);
            if (!(fM0 instanceof h) || !((h) fM0).P()) {
                return false;
            }
            boolean z = this.c;
            int iIndexOfChild = recyclerView.indexOfChild(view);
            if (iIndexOfChild >= recyclerView.getChildCount() - 1) {
                return z;
            }
            RecyclerView.F fM1 = recyclerView.m0(recyclerView.getChildAt(iIndexOfChild + 1));
            return (fM1 instanceof h) && ((h) fM1).O();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.o
        public void g(Rect rect, View view, RecyclerView recyclerView, RecyclerView.B b) {
            if (o(view, recyclerView)) {
                rect.bottom = this.b;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.o
        public void k(Canvas canvas, RecyclerView recyclerView, RecyclerView.B b) {
            if (this.a == null) {
                return;
            }
            int childCount = recyclerView.getChildCount();
            int width = recyclerView.getWidth();
            for (int i = 0; i < childCount; i++) {
                View childAt = recyclerView.getChildAt(i);
                if (o(childAt, recyclerView)) {
                    int y = ((int) childAt.getY()) + childAt.getHeight();
                    this.a.setBounds(0, y, width, this.b + y);
                    this.a.draw(canvas);
                }
            }
        }

        public void l(boolean z) {
            this.c = z;
        }

        public void m(Drawable drawable) {
            if (drawable != null) {
                this.b = drawable.getIntrinsicHeight();
            } else {
                this.b = 0;
            }
            this.a = drawable;
            d.this.l1.C0();
        }

        public void n(int i) {
            this.b = i;
            d.this.l1.C0();
        }
    }

    /* JADX INFO: renamed from: androidx.preference.d$d, reason: collision with other inner class name */
    public interface InterfaceC0036d {
        boolean a(d dVar, Preference preference);
    }

    public interface e {
        boolean a(d dVar, Preference preference);
    }

    public interface f {
        boolean a(d dVar, PreferenceScreen preferenceScreen);
    }

    private void g3() {
        if (this.q1.hasMessages(1)) {
            return;
        }
        this.q1.obtainMessage(1).sendToTarget();
    }

    private void h3() {
        if (this.k1 == null) {
            throw new RuntimeException("This should be called after super.onCreate.");
        }
    }

    private void m3() {
        X2().setAdapter(null);
        PreferenceScreen preferenceScreenZ2 = Z2();
        if (preferenceScreenZ2 != null) {
            preferenceScreenZ2.f0();
        }
        f3();
    }

    @Override // androidx.fragment.app.Fragment
    public View B1(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        TypedArray typedArrayObtainStyledAttributes = z2().obtainStyledAttributes(null, l.v0, ax.p021b2.f.f, 0);
        this.o1 = typedArrayObtainStyledAttributes.getResourceId(l.w0, this.o1);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(l.x0);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(l.y0, -1);
        boolean z = typedArrayObtainStyledAttributes.getBoolean(l.z0, true);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater layoutInflaterCloneInContext = layoutInflater.cloneInContext(z2());
        View viewInflate = layoutInflaterCloneInContext.inflate(this.o1, viewGroup, false);
        View viewFindViewById = viewInflate.findViewById(R.id.list_container);
        if (!(viewFindViewById instanceof ViewGroup)) {
            throw new IllegalStateException("Content has view with id attribute 'android.R.id.list_container' that is not a ViewGroup class");
        }
        ViewGroup viewGroup2 = (ViewGroup) viewFindViewById;
        RecyclerView recyclerViewE3 = e3(layoutInflaterCloneInContext, viewGroup2, bundle);
        if (recyclerViewE3 == null) {
            throw new RuntimeException("Could not create RecyclerView");
        }
        this.l1 = recyclerViewE3;
        recyclerViewE3.j(this.j1);
        i3(drawable);
        if (dimensionPixelSize != -1) {
            j3(dimensionPixelSize);
        }
        this.j1.l(z);
        if (this.l1.getParent() == null) {
            viewGroup2.addView(this.l1);
        }
        this.q1.post(this.r1);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void E1() {
        this.q1.removeCallbacks(this.r1);
        this.q1.removeMessages(1);
        if (this.m1) {
            m3();
        }
        this.l1 = null;
        super.E1();
    }

    @Override // androidx.fragment.app.Fragment
    public void S1(Bundle bundle) {
        super.S1(bundle);
        PreferenceScreen preferenceScreenZ2 = Z2();
        if (preferenceScreenZ2 != null) {
            Bundle bundle2 = new Bundle();
            preferenceScreenZ2.y0(bundle2);
            bundle.putBundle("android:preferences", bundle2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void T1() {
        super.T1();
        this.k1.q(this);
        this.k1.o(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void U1() {
        super.U1();
        this.k1.q(null);
        this.k1.o(null);
    }

    public void U2(int i) {
        h3();
        k3(this.k1.m(z2(), i, Z2()));
    }

    @Override // androidx.fragment.app.Fragment
    public void V1(View view, Bundle bundle) {
        Bundle bundle2;
        PreferenceScreen preferenceScreenZ2;
        super.V1(view, bundle);
        if (bundle != null && (bundle2 = bundle.getBundle("android:preferences")) != null && (preferenceScreenZ2 = Z2()) != null) {
            preferenceScreenZ2.x0(bundle2);
        }
        if (this.m1) {
            V2();
            Runnable runnable = this.p1;
            if (runnable != null) {
                runnable.run();
                this.p1 = null;
            }
        }
        this.n1 = true;
    }

    void V2() {
        PreferenceScreen preferenceScreenZ2 = Z2();
        if (preferenceScreenZ2 != null) {
            X2().setAdapter(b3(preferenceScreenZ2));
            preferenceScreenZ2.Z();
        }
        a3();
    }

    public Fragment W2() {
        return null;
    }

    public final RecyclerView X2() {
        return this.l1;
    }

    @Override // androidx.preference.g.a
    public void Y(Preference preference) {
        androidx.fragment.app.e eVarW3;
        boolean zA = W2() instanceof InterfaceC0036d ? ((InterfaceC0036d) W2()).a(this, preference) : false;
        for (Fragment fragmentI0 = this; !zA && fragmentI0 != null; fragmentI0 = fragmentI0.I0()) {
            if (fragmentI0 instanceof InterfaceC0036d) {
                zA = ((InterfaceC0036d) fragmentI0).a(this, preference);
            }
        }
        if (!zA && (getContext() instanceof InterfaceC0036d)) {
            zA = ((InterfaceC0036d) getContext()).a(this, preference);
        }
        if (!zA && (o0() instanceof InterfaceC0036d)) {
            zA = ((InterfaceC0036d) o0()).a(this, preference);
        }
        if (!zA && J0().k0("androidx.preference.PreferenceFragment.DIALOG") == null) {
            if (preference instanceof EditTextPreference) {
                eVarW3 = androidx.preference.a.x3(preference.B());
            } else if (preference instanceof ListPreference) {
                eVarW3 = ax.p021b2.a.w3(preference.B());
            } else {
                if (!(preference instanceof MultiSelectListPreference)) {
                    throw new IllegalArgumentException("Cannot display dialog for an unknown Preference type: " + preference.getClass().getSimpleName() + ". Make sure to implement onPreferenceDisplayDialog() to handle displaying a custom dialog for this Preference.");
                }
                eVarW3 = ax.p021b2.b.w3(preference.B());
            }
            eVarW3.N2(this, 0);
            eVarW3.m3(J0(), "androidx.preference.PreferenceFragment.DIALOG");
        }
    }

    public g Y2() {
        return this.k1;
    }

    public PreferenceScreen Z2() {
        return this.k1.k();
    }

    protected void a3() {
    }

    @Override // androidx.preference.g.b
    public void b0(PreferenceScreen preferenceScreen) {
        boolean zA = W2() instanceof f ? ((f) W2()).a(this, preferenceScreen) : false;
        for (Fragment fragmentI0 = this; !zA && fragmentI0 != null; fragmentI0 = fragmentI0.I0()) {
            if (fragmentI0 instanceof f) {
                zA = ((f) fragmentI0).a(this, preferenceScreen);
            }
        }
        if (!zA && (getContext() instanceof f)) {
            zA = ((f) getContext()).a(this, preferenceScreen);
        }
        if (zA || !(o0() instanceof f)) {
            return;
        }
        ((f) o0()).a(this, preferenceScreen);
    }

    protected RecyclerView.h b3(PreferenceScreen preferenceScreen) {
        return new androidx.preference.e(preferenceScreen);
    }

    public RecyclerView.p c3() {
        return new LinearLayoutManager(z2());
    }

    public abstract void d3(Bundle bundle, String str);

    @Override // androidx.preference.g.c
    public boolean e0(Preference preference) {
        if (preference.w() == null) {
            return false;
        }
        boolean zA = W2() instanceof e ? ((e) W2()).a(this, preference) : false;
        for (Fragment fragmentI0 = this; !zA && fragmentI0 != null; fragmentI0 = fragmentI0.I0()) {
            if (fragmentI0 instanceof e) {
                zA = ((e) fragmentI0).a(this, preference);
            }
        }
        if (!zA && (getContext() instanceof e)) {
            zA = ((e) getContext()).a(this, preference);
        }
        if (!zA && (o0() instanceof e)) {
            zA = ((e) o0()).a(this, preference);
        }
        if (zA) {
            return true;
        }
        Log.w("PreferenceFragment", "onPreferenceStartFragment is not implemented in the parent activity - attempting to use a fallback implementation. You should implement this method so that you can configure the new fragment that will be displayed, and set a transition between the fragments.");
        FragmentManager fragmentManagerJ0 = J0();
        Bundle bundleU = preference.u();
        Fragment fragmentA = fragmentManagerJ0.u0().a(x2().getClassLoader(), preference.w());
        fragmentA.F2(bundleU);
        fragmentA.N2(this, 0);
        fragmentManagerJ0.o().r(((View) A2().getParent()).getId(), fragmentA).g(null).i();
        return true;
    }

    public RecyclerView e3(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView recyclerView;
        if (z2().getPackageManager().hasSystemFeature("android.hardware.type.automotive") && (recyclerView = (RecyclerView) viewGroup.findViewById(ax.p021b2.h.b)) != null) {
            return recyclerView;
        }
        RecyclerView recyclerView2 = (RecyclerView) layoutInflater.inflate(i.d, viewGroup, false);
        recyclerView2.setLayoutManager(c3());
        recyclerView2.setAccessibilityDelegateCompat(new ax.p021b2.e(recyclerView2));
        return recyclerView2;
    }

    protected void f3() {
    }

    public void i3(Drawable drawable) {
        this.j1.m(drawable);
    }

    public void j3(int i) {
        this.j1.n(i);
    }

    public void k3(PreferenceScreen preferenceScreen) {
        if (!this.k1.r(preferenceScreen) || preferenceScreen == null) {
            return;
        }
        f3();
        this.m1 = true;
        if (this.n1) {
            g3();
        }
    }

    public void l3(int i, String str) {
        Preference preferenceV0;
        h3();
        PreferenceScreen preferenceScreenM = this.k1.m(z2(), i, null);
        Preference preference = preferenceScreenM;
        if (str != null) {
            preferenceV0 = preferenceScreenM.V0(str);
            if (!(preferenceV0 instanceof PreferenceScreen)) {
                preference = preferenceV0;
                throw new IllegalArgumentException("Preference object with key " + str + " is not a PreferenceScreen");
            }
        }
        preference = preferenceV0;
        k3((PreferenceScreen) preference);
    }

    @Override // androidx.preference.DialogPreference.a
    public <T extends Preference> T w(CharSequence charSequence) {
        g gVar = this.k1;
        if (gVar == null) {
            return null;
        }
        return (T) gVar.a(charSequence);
    }

    @Override // androidx.fragment.app.Fragment
    public void x1(Bundle bundle) {
        super.x1(bundle);
        TypedValue typedValue = new TypedValue();
        z2().getTheme().resolveAttribute(ax.p021b2.f.i, typedValue, true);
        int i = typedValue.resourceId;
        if (i == 0) {
            i = k.a;
        }
        z2().getTheme().applyStyle(i, false);
        g gVar = new g(z2());
        this.k1 = gVar;
        gVar.p(this);
        d3(bundle, s0() != null ? s0().getString("androidx.preference.PreferenceFragmentCompat.PREFERENCE_ROOT") : null);
    }
}
