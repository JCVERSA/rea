package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import ax.p021b2.l;

/* JADX INFO: loaded from: classes.dex */
public class SeekBarPreference extends Preference {
    int W0;
    int X0;
    private int Y0;
    private int Z0;
    boolean a1;
    SeekBar b1;
    private TextView c1;
    boolean d1;
    private boolean e1;
    boolean f1;
    private final SeekBar.OnSeekBarChangeListener g1;
    private final View.OnKeyListener h1;

    class a implements SeekBar.OnSeekBarChangeListener {
        a() {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            if (z) {
                SeekBarPreference seekBarPreference = SeekBarPreference.this;
                if (seekBarPreference.f1 || !seekBarPreference.a1) {
                    seekBarPreference.X0(seekBar);
                    return;
                }
            }
            SeekBarPreference seekBarPreference2 = SeekBarPreference.this;
            seekBarPreference2.Y0(i + seekBarPreference2.X0);
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.a1 = true;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.a1 = false;
            int progress = seekBar.getProgress();
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if (progress + seekBarPreference.X0 != seekBarPreference.W0) {
                seekBarPreference.X0(seekBar);
            }
        }
    }

    class b implements View.OnKeyListener {
        b() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (keyEvent.getAction() != 0) {
                return false;
            }
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if ((!seekBarPreference.d1 && (i == 21 || i == 22)) || i == 23 || i == 66) {
                return false;
            }
            SeekBar seekBar = seekBarPreference.b1;
            if (seekBar != null) {
                return seekBar.onKeyDown(i, keyEvent);
            }
            Log.e("SeekBarPreference", "SeekBar view is null and hence cannot be adjusted.");
            return false;
        }
    }

    private static class c extends Preference.b {
        public static final Parcelable.Creator<c> CREATOR = new a();
        int X;
        int Y;
        int q;

        class a implements Parcelable.Creator<c> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        c(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt();
            this.X = parcel.readInt();
            this.Y = parcel.readInt();
        }

        c(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q);
            parcel.writeInt(this.X);
            parcel.writeInt(this.Y);
        }
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p021b2.f.j);
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.g1 = new a();
        this.h1 = new b();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.H0, i, i2);
        this.X0 = typedArrayObtainStyledAttributes.getInt(l.K0, 0);
        T0(typedArrayObtainStyledAttributes.getInt(l.I0, 100));
        U0(typedArrayObtainStyledAttributes.getInt(l.L0, 0));
        this.d1 = typedArrayObtainStyledAttributes.getBoolean(l.J0, true);
        this.e1 = typedArrayObtainStyledAttributes.getBoolean(l.M0, false);
        this.f1 = typedArrayObtainStyledAttributes.getBoolean(l.N0, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void W0(int i, boolean z) {
        int i2 = this.X0;
        if (i < i2) {
            i = i2;
        }
        int i3 = this.Y0;
        if (i > i3) {
            i = i3;
        }
        if (i != this.W0) {
            this.W0 = i;
            Y0(i);
            r0(i);
            if (z) {
                W();
            }
        }
    }

    public final void T0(int i) {
        int i2 = this.X0;
        if (i < i2) {
            i = i2;
        }
        if (i != this.Y0) {
            this.Y0 = i;
            W();
        }
    }

    public final void U0(int i) {
        if (i != this.Z0) {
            this.Z0 = Math.min(this.Y0 - this.X0, Math.abs(i));
            W();
        }
    }

    public void V0(int i) {
        W0(i, true);
    }

    void X0(SeekBar seekBar) {
        int progress = this.X0 + seekBar.getProgress();
        if (progress != this.W0) {
            if (h(Integer.valueOf(progress))) {
                W0(progress, false);
            } else {
                seekBar.setProgress(this.W0 - this.X0);
                Y0(this.W0);
            }
        }
    }

    void Y0(int i) {
        TextView textView = this.c1;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        hVar.a.setOnKeyListener(this.h1);
        this.b1 = (SeekBar) hVar.N(ax.p021b2.h.c);
        TextView textView = (TextView) hVar.N(ax.p021b2.h.d);
        this.c1 = textView;
        if (this.e1) {
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
            this.c1 = null;
        }
        SeekBar seekBar = this.b1;
        if (seekBar == null) {
            Log.e("SeekBarPreference", "SeekBar view is null in onBindViewHolder.");
            return;
        }
        seekBar.setOnSeekBarChangeListener(this.g1);
        this.b1.setMax(this.Y0 - this.X0);
        int i = this.Z0;
        if (i != 0) {
            this.b1.setKeyProgressIncrement(i);
        } else {
            this.Z0 = this.b1.getKeyProgressIncrement();
        }
        this.b1.setProgress(this.W0 - this.X0);
        Y0(this.W0);
        this.b1.setEnabled(S());
    }

    @Override // androidx.preference.Preference
    protected Object g0(TypedArray typedArray, int i) {
        return Integer.valueOf(typedArray.getInt(i, 0));
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(c.class)) {
            super.k0(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.k0(cVar.getSuperState());
        this.W0 = cVar.q;
        this.X0 = cVar.X;
        this.Y0 = cVar.Y;
        W();
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        Parcelable parcelableL0 = super.l0();
        if (T()) {
            return parcelableL0;
        }
        c cVar = new c(parcelableL0);
        cVar.q = this.W0;
        cVar.X = this.X0;
        cVar.Y = this.Y0;
        return cVar;
    }

    @Override // androidx.preference.Preference
    protected void m0(Object obj) {
        if (obj == null) {
            obj = 0;
        }
        V0(G(((Integer) obj).intValue()));
    }
}
