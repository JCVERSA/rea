package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import ax.N0.l;

/* JADX INFO: loaded from: classes.dex */
public class SeekBarPreference extends Preference {
    int T0;
    int U0;
    private int V0;
    private int W0;
    boolean X0;
    SeekBar Y0;
    private TextView Z0;
    boolean a1;
    private boolean b1;
    boolean c1;
    private final SeekBar.OnSeekBarChangeListener d1;
    private final View.OnKeyListener e1;

    class a implements SeekBar.OnSeekBarChangeListener {
        a() {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            if (z) {
                SeekBarPreference seekBarPreference = SeekBarPreference.this;
                if (seekBarPreference.c1 || !seekBarPreference.X0) {
                    seekBarPreference.X0(seekBar);
                    return;
                }
            }
            SeekBarPreference seekBarPreference2 = SeekBarPreference.this;
            seekBarPreference2.Y0(i + seekBarPreference2.U0);
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.X0 = true;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.X0 = false;
            int progress = seekBar.getProgress();
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if (progress + seekBarPreference.U0 != seekBarPreference.T0) {
                seekBarPreference.X0(seekBar);
            }
        }
    }

    class b implements View.OnKeyListener {
        b() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (keyEvent.getAction() != 0) {
                return false;
            }
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if ((!seekBarPreference.a1 && (i == 21 || i == 22)) || i == 23 || i == 66) {
                return false;
            }
            SeekBar seekBar = seekBarPreference.Y0;
            if (seekBar != null) {
                return seekBar.onKeyDown(i, keyEvent);
            }
            Log.e("SeekBarPreference", "SeekBar view is null and hence cannot be adjusted.");
            return false;
        }
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.d1 = new a();
        this.e1 = new b();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.H0, i, i2);
        this.U0 = typedArrayObtainStyledAttributes.getInt(l.K0, 0);
        T0(typedArrayObtainStyledAttributes.getInt(l.I0, 100));
        U0(typedArrayObtainStyledAttributes.getInt(l.L0, 0));
        this.a1 = typedArrayObtainStyledAttributes.getBoolean(l.J0, true);
        this.b1 = typedArrayObtainStyledAttributes.getBoolean(l.M0, false);
        this.c1 = typedArrayObtainStyledAttributes.getBoolean(l.N0, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void W0(int i, boolean z) {
        int i2 = this.U0;
        if (i < i2) {
            i = i2;
        }
        int i3 = this.V0;
        if (i > i3) {
            i = i3;
        }
        if (i != this.T0) {
            this.T0 = i;
            Y0(i);
            r0(i);
            if (z) {
                W();
            }
        }
    }

    public final void T0(int i) {
        int i2 = this.U0;
        if (i < i2) {
            i = i2;
        }
        if (i != this.V0) {
            this.V0 = i;
            W();
        }
    }

    public final void U0(int i) {
        if (i != this.W0) {
            this.W0 = Math.min(this.V0 - this.U0, Math.abs(i));
            W();
        }
    }

    public void V0(int i) {
        W0(i, true);
    }

    void X0(SeekBar seekBar) {
        int progress = this.U0 + seekBar.getProgress();
        if (progress != this.T0) {
            if (h(Integer.valueOf(progress))) {
                W0(progress, false);
            } else {
                seekBar.setProgress(this.T0 - this.U0);
                Y0(this.T0);
            }
        }
    }

    void Y0(int i) {
        TextView textView = this.Z0;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
    }

    @Override // androidx.preference.Preference
    public void c0(h hVar) {
        super.c0(hVar);
        hVar.a.setOnKeyListener(this.e1);
        this.Y0 = (SeekBar) hVar.N(ax.N0.h.c);
        TextView textView = (TextView) hVar.N(ax.N0.h.d);
        this.Z0 = textView;
        if (this.b1) {
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
            this.Z0 = null;
        }
        SeekBar seekBar = this.Y0;
        if (seekBar == null) {
            Log.e("SeekBarPreference", "SeekBar view is null in onBindViewHolder.");
            return;
        }
        seekBar.setOnSeekBarChangeListener(this.d1);
        this.Y0.setMax(this.V0 - this.U0);
        int i = this.W0;
        if (i != 0) {
            this.Y0.setKeyProgressIncrement(i);
        } else {
            this.W0 = this.Y0.getKeyProgressIncrement();
        }
        this.Y0.setProgress(this.T0 - this.U0);
        Y0(this.T0);
        this.Y0.setEnabled(S());
    }

    @Override // androidx.preference.Preference
    protected Object g0(TypedArray typedArray, int i) {
        return Integer.valueOf(typedArray.getInt(i, 0));
    }

    @Override // androidx.preference.Preference
    protected void k0(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(c.class)) {
            super.k0(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.k0(cVar.getSuperState());
        this.T0 = cVar.q;
        this.U0 = cVar.X;
        this.V0 = cVar.Y;
        W();
    }

    @Override // androidx.preference.Preference
    protected Parcelable l0() {
        Parcelable parcelableL0 = super.l0();
        if (T()) {
            return parcelableL0;
        }
        c cVar = new c(parcelableL0);
        cVar.q = this.T0;
        cVar.X = this.U0;
        cVar.Y = this.V0;
        return cVar;
    }

    @Override // androidx.preference.Preference
    protected void m0(Object obj) {
        if (obj == null) {
            obj = 0;
        }
        V0(G(((Integer) obj).intValue()));
    }

    private static class c extends Preference.b {
        public static final Parcelable.Creator<c> CREATOR = new a();
        int X;
        int Y;
        int q;

        class a implements Parcelable.Creator<c> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i) {
                return new c[i];
            }
        }

        c(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt();
            this.X = parcel.readInt();
            this.Y = parcel.readInt();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q);
            parcel.writeInt(this.X);
            parcel.writeInt(this.Y);
        }

        c(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.N0.f.j);
    }
}
