package androidx.media3.decoder;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public class b extends a {
    public int k0;
    public int l0;
    public ByteBuffer[] m0;
    public int[] n0;
    public int o0;
    private final a.InterfaceC0029a<b> p0;

    @Override // androidx.media3.decoder.a
    public void B() {
        this.p0.a(this);
    }
}
