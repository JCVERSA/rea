package androidx.media3.decoder;

/* JADX INFO: loaded from: classes.dex */
public abstract class a extends ax.V0.a {
    public long X;
    public int Y;
    public boolean Z;

    /* JADX INFO: renamed from: androidx.media3.decoder.a$a, reason: collision with other inner class name */
    public interface InterfaceC0029a<S extends a> {
        void a(S s);
    }

    public abstract void B();

    @Override // ax.V0.a
    public void p() {
        super.p();
        this.X = 0L;
        this.Y = 0;
        this.Z = false;
    }
}
