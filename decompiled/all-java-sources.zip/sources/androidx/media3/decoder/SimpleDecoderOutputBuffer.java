package androidx.media3.decoder;

import ax.S0.C1498a;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* JADX INFO: loaded from: classes.dex */
public class SimpleDecoderOutputBuffer extends a {
    private final a.InterfaceC0029a<SimpleDecoderOutputBuffer> k0;
    public ByteBuffer l0;

    public SimpleDecoderOutputBuffer(a.InterfaceC0029a<SimpleDecoderOutputBuffer> interfaceC0029a) {
        this.k0 = interfaceC0029a;
    }

    @Override // androidx.media3.decoder.a
    public void B() {
        this.k0.a(this);
    }

    public ByteBuffer C(int i) {
        ByteBuffer byteBuffer = (ByteBuffer) C1498a.e(this.l0);
        C1498a.a(i >= byteBuffer.limit());
        ByteBuffer byteBufferOrder = ByteBuffer.allocateDirect(i).order(ByteOrder.nativeOrder());
        int iPosition = byteBuffer.position();
        byteBuffer.position(0);
        byteBufferOrder.put(byteBuffer);
        byteBufferOrder.position(iPosition);
        byteBufferOrder.limit(i);
        this.l0 = byteBufferOrder;
        return byteBufferOrder;
    }

    public ByteBuffer D(long j, int i) {
        this.X = j;
        ByteBuffer byteBuffer = this.l0;
        if (byteBuffer == null || byteBuffer.capacity() < i) {
            this.l0 = ByteBuffer.allocateDirect(i).order(ByteOrder.nativeOrder());
        }
        this.l0.position(0);
        this.l0.limit(i);
        return this.l0;
    }

    @Override // androidx.media3.decoder.a, ax.V0.a
    public void p() {
        super.p();
        ByteBuffer byteBuffer = this.l0;
        if (byteBuffer != null) {
            byteBuffer.clear();
        }
    }
}
