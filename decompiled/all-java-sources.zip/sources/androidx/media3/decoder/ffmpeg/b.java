package androidx.media3.decoder.ffmpeg;

import android.os.Handler;
import ax.P0.C1375v;
import ax.P0.D;
import ax.Q0.o;
import ax.S0.C1498a;
import ax.S0.N;
import ax.S0.d0;
import ax.p004a1.B;
import ax.p004a1.C1740f0;
import ax.p004a1.H;
import ax.p004a1.InterfaceC1761z;

/* JADX INFO: loaded from: classes.dex */
public final class b extends H<ax.W0.a> {
    private static int a1;
    public static final /* synthetic */ int b1 = 0;

    public b() {
        this((Handler) null, (InterfaceC1761z) null, new o[0]);
    }

    public b(Handler handler, InterfaceC1761z interfaceC1761z, B b) {
        super(handler, interfaceC1761z, b);
    }

    public b(Handler handler, InterfaceC1761z interfaceC1761z, o... oVarArr) {
        this(handler, interfaceC1761z, new C1740f0.g().m(oVarArr).k());
    }

    public static int G0() {
        return a1;
    }

    public static void I0(int i) {
        a1 = i;
    }

    private boolean J0(C1375v c1375v) {
        if (!K0(c1375v, 2)) {
            return true;
        }
        if (s0(d0.l0(4, c1375v.G, c1375v.H)) != 2) {
            return false;
        }
        return !"audio/ac3".equals(c1375v.o);
    }

    private boolean K0(C1375v c1375v, int i) {
        return C0(d0.l0(i, c1375v.G, c1375v.H));
    }

    private boolean L0(String str) {
        if (ax.T2.b.i()) {
            return FfmpegLibrary.e(str);
        }
        if (ax.T2.b.a() == 1) {
            return com.google.android.exoplayer2.ext.ffmpeg.FfmpegLibrary.g(str);
        }
        return false;
    }

    @Override // androidx.media3.exoplayer.AbstractC0622h, androidx.media3.exoplayer.N0
    public int A() {
        return 8;
    }

    @Override // ax.p004a1.H
    protected int D0(C1375v c1375v) {
        String str = (String) C1498a.e(c1375v.o);
        if (!ax.T2.b.b() || !D.o(str)) {
            return 0;
        }
        if (!L0(str)) {
            return 1;
        }
        if (K0(c1375v, 2) || K0(c1375v, 4)) {
            return c1375v.P != 0 ? 2 : 4;
        }
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ax.p004a1.H
    /* JADX INFO: renamed from: F0, reason: merged with bridge method [inline-methods] */
    public ax.W0.a m0(C1375v c1375v, ax.V0.b bVar) throws ax.W0.b {
        ax.W0.a aVar;
        N.a("createFfmpegAudioDecoder");
        int i = c1375v.p;
        int i2 = i != -1 ? i : 5760;
        if (ax.T2.b.i()) {
            aVar = new FfmpegAudioDecoder(c1375v, 16, 16, i2, J0(c1375v));
        } else {
            aVar = new com.google.android.exoplayer2.ext.ffmpeg.a(ax.T2.b.f(), c1375v, 16, 16, i2, J0(c1375v), a1);
        }
        N.b();
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ax.p004a1.H
    /* JADX INFO: renamed from: H0, reason: merged with bridge method [inline-methods] */
    public C1375v r0(ax.W0.a aVar) {
        C1498a.e(aVar);
        int iY = aVar.y();
        int iG0 = G0();
        if (iG0 > 0 && iY > iG0) {
            iY = iG0;
        }
        return new C1375v.b().y0("audio/raw").T(iY).z0(aVar.A()).s0(aVar.z()).P();
    }

    @Override // androidx.media3.exoplayer.M0, androidx.media3.exoplayer.N0
    public String getName() {
        return "FfmpegAudioRenderer";
    }
}
