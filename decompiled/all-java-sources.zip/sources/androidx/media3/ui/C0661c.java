package androidx.media3.ui;

import android.graphics.Color;
import ax.S0.d0;

/* JADX INFO: renamed from: androidx.media3.ui.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0661c {
    public static String a(String str) {
        return "." + str + ",." + str + " *";
    }

    public static String b(int i) {
        return d0.G("rgba(%d,%d,%d,%.3f)", Integer.valueOf(Color.red(i)), Integer.valueOf(Color.green(i)), Integer.valueOf(Color.blue(i)), Double.valueOf(((double) Color.alpha(i)) / 255.0d));
    }
}
