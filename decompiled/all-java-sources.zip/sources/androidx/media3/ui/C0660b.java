package androidx.media3.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.media3.ui.C0660b;
import ax.S0.C1498a;
import ax.S0.d0;
import ax.p409z6.C3772df;
import java.util.Collections;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: renamed from: androidx.media3.ui.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0660b extends View implements G {
    private final int A0;
    private final int B0;
    private final int C0;
    private final StringBuilder D0;
    private final Formatter E0;
    private final Runnable F0;
    private final CopyOnWriteArraySet<G.a> G0;
    private final Point H0;
    private final float I0;
    private int J0;
    private long K0;
    private int L0;
    private Rect M0;
    private ValueAnimator N0;
    private float O0;
    private boolean P0;
    private boolean Q0;
    private long R0;
    private long S0;
    private long T0;
    private long U0;
    private int V0;
    private long[] W0;
    private boolean[] X0;
    private final Rect k0;
    private final Rect l0;
    private final Rect m0;
    private final Paint n0;
    private final Paint o0;
    private final Paint p0;
    private final Rect q;
    private final Paint q0;
    private final Paint r0;
    private final Paint s0;
    private final Drawable t0;
    private final int u0;
    private final int v0;
    private final int w0;
    private final int x0;
    private final int y0;
    private final int z0;

    public C0660b(Context context, AttributeSet attributeSet, int i, AttributeSet attributeSet2, int i2) {
        super(context, attributeSet, i);
        this.q = new Rect();
        this.k0 = new Rect();
        this.l0 = new Rect();
        this.m0 = new Rect();
        Paint paint = new Paint();
        this.n0 = paint;
        Paint paint2 = new Paint();
        this.o0 = paint2;
        Paint paint3 = new Paint();
        this.p0 = paint3;
        Paint paint4 = new Paint();
        this.q0 = paint4;
        Paint paint5 = new Paint();
        this.r0 = paint5;
        Paint paint6 = new Paint();
        this.s0 = paint6;
        paint6.setAntiAlias(true);
        this.G0 = new CopyOnWriteArraySet<>();
        this.H0 = new Point();
        float f = context.getResources().getDisplayMetrics().density;
        this.I0 = f;
        this.C0 = e(f, -50);
        int iE = e(f, 4);
        int iE2 = e(f, 26);
        int iE3 = e(f, 4);
        int iE4 = e(f, 12);
        int iE5 = e(f, 0);
        int iE6 = e(f, 16);
        if (attributeSet2 != null) {
            TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet2, ax.p005a2.F.e, i, i2);
            try {
                Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(ax.p005a2.F.p);
                this.t0 = drawable;
                if (drawable != null) {
                    o(drawable);
                    iE2 = Math.max(drawable.getMinimumHeight(), iE2);
                }
                this.u0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.i, iE);
                this.v0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.r, iE2);
                this.w0 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.h, 0);
                this.x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.g, iE3);
                this.y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.q, iE4);
                this.z0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.n, iE5);
                this.A0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p005a2.F.o, iE6);
                int i3 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.l, -1);
                int i4 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.m, -1);
                int i5 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.j, -855638017);
                int i6 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.s, 872415231);
                int i7 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.f, -1291845888);
                int i8 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.k, 872414976);
                paint.setColor(i3);
                paint6.setColor(i4);
                paint2.setColor(i5);
                paint3.setColor(i6);
                paint4.setColor(i7);
                paint5.setColor(i8);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        } else {
            this.u0 = iE;
            this.v0 = iE2;
            this.w0 = 0;
            this.x0 = iE3;
            this.y0 = iE4;
            this.z0 = iE5;
            this.A0 = iE6;
            paint.setColor(-1);
            paint6.setColor(-1);
            paint2.setColor(-855638017);
            paint3.setColor(872415231);
            paint4.setColor(-1291845888);
            paint5.setColor(872414976);
            this.t0 = null;
        }
        StringBuilder sb = new StringBuilder();
        this.D0 = sb;
        this.E0 = new Formatter(sb, Locale.getDefault());
        this.F0 = new Runnable() { // from class: ax.a2.d
            @Override // java.lang.Runnable
            public final void run() {
                this.q.u(false);
            }
        };
        Drawable drawable2 = this.t0;
        if (drawable2 != null) {
            this.B0 = (drawable2.getMinimumWidth() + 1) / 2;
        } else {
            this.B0 = (Math.max(this.z0, Math.max(this.y0, this.A0)) + 1) / 2;
        }
        this.O0 = 1.0f;
        ValueAnimator valueAnimator = new ValueAnimator();
        this.N0 = valueAnimator;
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: ax.a2.e
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                C0660b.c(this.a, valueAnimator2);
            }
        });
        this.S0 = -9223372036854775807L;
        this.K0 = -9223372036854775807L;
        this.J0 = 20;
        setFocusable(true);
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    public static /* synthetic */ void c(C0660b c0660b, ValueAnimator valueAnimator) {
        c0660b.getClass();
        c0660b.O0 = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        c0660b.invalidate(c0660b.q);
    }

    private static int e(float f, int i) {
        return (int) ((i * f) + 0.5f);
    }

    private void f(Canvas canvas) {
        int i;
        if (this.S0 <= 0) {
            return;
        }
        Rect rect = this.m0;
        int iP = d0.p(rect.right, rect.left, this.k0.right);
        int iCenterY = this.m0.centerY();
        Drawable drawable = this.t0;
        if (drawable == null) {
            if (this.Q0 || isFocused()) {
                i = this.A0;
            } else {
                i = isEnabled() ? this.y0 : this.z0;
            }
            canvas.drawCircle(iP, iCenterY, (int) ((i * this.O0) / 2.0f), this.s0);
            return;
        }
        int intrinsicWidth = ((int) (drawable.getIntrinsicWidth() * this.O0)) / 2;
        int intrinsicHeight = ((int) (this.t0.getIntrinsicHeight() * this.O0)) / 2;
        this.t0.setBounds(iP - intrinsicWidth, iCenterY - intrinsicHeight, iP + intrinsicWidth, iCenterY + intrinsicHeight);
        this.t0.draw(canvas);
    }

    private void g(Canvas canvas) {
        int iHeight = this.k0.height();
        int iCenterY = this.k0.centerY() - (iHeight / 2);
        int i = iHeight + iCenterY;
        if (this.S0 <= 0) {
            Rect rect = this.k0;
            canvas.drawRect(rect.left, iCenterY, rect.right, i, this.p0);
            return;
        }
        Rect rect2 = this.l0;
        int i2 = rect2.left;
        int i3 = rect2.right;
        int iMax = Math.max(Math.max(this.k0.left, i3), this.m0.right);
        int i4 = this.k0.right;
        if (iMax < i4) {
            canvas.drawRect(iMax, iCenterY, i4, i, this.p0);
        }
        int iMax2 = Math.max(i2, this.m0.right);
        if (i3 > iMax2) {
            canvas.drawRect(iMax2, iCenterY, i3, i, this.o0);
        }
        if (this.m0.width() > 0) {
            Rect rect3 = this.m0;
            canvas.drawRect(rect3.left, iCenterY, rect3.right, i, this.n0);
        }
        if (this.V0 == 0) {
            return;
        }
        long[] jArr = (long[]) C1498a.e(this.W0);
        boolean[] zArr = (boolean[]) C1498a.e(this.X0);
        int i5 = this.x0 / 2;
        for (int i6 = 0; i6 < this.V0; i6++) {
            int iWidth = ((int) ((((long) this.k0.width()) * d0.q(jArr[i6], 0L, this.S0)) / this.S0)) - i5;
            Rect rect4 = this.k0;
            int iMin = rect4.left + Math.min(rect4.width() - this.x0, Math.max(0, iWidth));
            canvas.drawRect(iMin, iCenterY, iMin + this.x0, i, zArr[i6] ? this.r0 : this.q0);
        }
    }

    private long getPositionIncrement() {
        long j = this.K0;
        if (j != -9223372036854775807L) {
            return j;
        }
        long j2 = this.S0;
        if (j2 == -9223372036854775807L) {
            return 0L;
        }
        return j2 / ((long) this.J0);
    }

    private String getProgressText() {
        return d0.q0(this.D0, this.E0, this.T0);
    }

    private long getScrubberPosition() {
        if (this.k0.width() <= 0 || this.S0 == -9223372036854775807L) {
            return 0L;
        }
        return (((long) this.m0.width()) * this.S0) / ((long) this.k0.width());
    }

    private boolean j(float f, float f2) {
        return this.q.contains((int) f, (int) f2);
    }

    private void k(float f) {
        Rect rect = this.m0;
        Rect rect2 = this.k0;
        rect.right = d0.p((int) f, rect2.left, rect2.right);
    }

    private static int l(float f, int i) {
        return (int) (i / f);
    }

    private Point m(MotionEvent motionEvent) {
        this.H0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        return this.H0;
    }

    private boolean n(long j) {
        long j2 = this.S0;
        if (j2 <= 0) {
            return false;
        }
        long j3 = this.Q0 ? this.R0 : this.T0;
        long jQ = d0.q(j3 + j, 0L, j2);
        if (jQ == j3) {
            return false;
        }
        if (this.Q0) {
            x(jQ);
        } else {
            t(jQ);
        }
        v();
        return true;
    }

    private boolean o(Drawable drawable) {
        return Build.VERSION.SDK_INT >= 23 && p(drawable, getLayoutDirection());
    }

    private static boolean p(Drawable drawable, int i) {
        return Build.VERSION.SDK_INT >= 23 && drawable.setLayoutDirection(i);
    }

    private void q(int i, int i2) {
        Rect rect = this.M0;
        if (rect != null && rect.width() == i && this.M0.height() == i2) {
            return;
        }
        Rect rect2 = new Rect(0, 0, i, i2);
        this.M0 = rect2;
        setSystemGestureExclusionRects(Collections.singletonList(rect2));
    }

    private void t(long j) {
        this.R0 = j;
        this.Q0 = true;
        setPressed(true);
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        Iterator<G.a> it = this.G0.iterator();
        while (it.hasNext()) {
            it.next().P(this, j);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void u(boolean z) {
        removeCallbacks(this.F0);
        this.Q0 = false;
        setPressed(false);
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }
        invalidate();
        Iterator<G.a> it = this.G0.iterator();
        while (it.hasNext()) {
            it.next().l0(this, this.R0, z);
        }
    }

    private void v() {
        this.l0.set(this.k0);
        this.m0.set(this.k0);
        long j = this.Q0 ? this.R0 : this.T0;
        if (this.S0 > 0) {
            int iWidth = (int) ((((long) this.k0.width()) * this.U0) / this.S0);
            Rect rect = this.l0;
            Rect rect2 = this.k0;
            rect.right = Math.min(rect2.left + iWidth, rect2.right);
            int iWidth2 = (int) ((((long) this.k0.width()) * j) / this.S0);
            Rect rect3 = this.m0;
            Rect rect4 = this.k0;
            rect3.right = Math.min(rect4.left + iWidth2, rect4.right);
        } else {
            Rect rect5 = this.l0;
            int i = this.k0.left;
            rect5.right = i;
            this.m0.right = i;
        }
        invalidate(this.q);
    }

    private void w() {
        Drawable drawable = this.t0;
        if (drawable != null && drawable.isStateful() && this.t0.setState(getDrawableState())) {
            invalidate();
        }
    }

    private void x(long j) {
        if (this.R0 == j) {
            return;
        }
        this.R0 = j;
        Iterator<G.a> it = this.G0.iterator();
        while (it.hasNext()) {
            it.next().d0(this, j);
        }
    }

    @Override // androidx.media3.ui.G
    public void a(G.a aVar) {
        C1498a.e(aVar);
        this.G0.add(aVar);
    }

    @Override // androidx.media3.ui.G
    public void b(long[] jArr, boolean[] zArr, int i) {
        C1498a.a(i == 0 || !(jArr == null || zArr == null));
        this.V0 = i;
        this.W0 = jArr;
        this.X0 = zArr;
        v();
    }

    @Override // android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        w();
    }

    @Override // androidx.media3.ui.G
    public long getPreferredUpdateDelay() {
        int iL = l(this.I0, this.k0.width());
        if (iL == 0) {
            return Long.MAX_VALUE;
        }
        long j = this.S0;
        if (j == 0 || j == -9223372036854775807L) {
            return Long.MAX_VALUE;
        }
        return j / ((long) iL);
    }

    public void h(long j) {
        if (this.N0.isStarted()) {
            this.N0.cancel();
        }
        this.N0.setFloatValues(this.O0, 0.0f);
        this.N0.setDuration(j);
        this.N0.start();
    }

    public void i(boolean z) {
        if (this.N0.isStarted()) {
            this.N0.cancel();
        }
        this.P0 = z;
        this.O0 = 0.0f;
        invalidate(this.q);
    }

    @Override // android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.t0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        canvas.save();
        g(canvas);
        f(canvas);
        canvas.restore();
    }

    @Override // android.view.View
    protected void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        if (!this.Q0 || z) {
            return;
        }
        u(false);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        if (accessibilityEvent.getEventType() == 4) {
            accessibilityEvent.getText().add(getProgressText());
        }
        accessibilityEvent.setClassName("android.widget.SeekBar");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.SeekBar");
        accessibilityNodeInfo.setContentDescription(getProgressText());
        if (this.S0 <= 0) {
            return;
        }
        accessibilityNodeInfo.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
        accessibilityNodeInfo.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:11:0x001a  */
    /* JADX WARN: Code duplicated, block: B:13:0x0027  */
    /* JADX WARN: Code duplicated, block: B:15:0x002b  */
    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (isEnabled()) {
            long positionIncrement = getPositionIncrement();
            if (i != 66) {
                switch (i) {
                    case C3772df.zzm /* 21 */:
                        positionIncrement = -positionIncrement;
                        if (n(positionIncrement)) {
                            removeCallbacks(this.F0);
                            postDelayed(this.F0, 1000L);
                            return true;
                        }
                        break;
                    case 22:
                        if (n(positionIncrement)) {
                            removeCallbacks(this.F0);
                            postDelayed(this.F0, 1000L);
                            return true;
                        }
                        break;
                    case 23:
                        if (this.Q0) {
                            u(false);
                            return true;
                        }
                        break;
                }
            } else if (this.Q0) {
                u(false);
                return true;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int paddingBottom;
        int iMax;
        int i5 = i3 - i;
        int i6 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingRight = i5 - getPaddingRight();
        int i7 = this.P0 ? 0 : this.B0;
        if (this.w0 == 1) {
            paddingBottom = (i6 - getPaddingBottom()) - this.v0;
            int paddingBottom2 = i6 - getPaddingBottom();
            int i8 = this.u0;
            iMax = (paddingBottom2 - i8) - Math.max(i7 - (i8 / 2), 0);
        } else {
            paddingBottom = (i6 - this.v0) / 2;
            iMax = (i6 - this.u0) / 2;
        }
        this.q.set(paddingLeft, paddingBottom, paddingRight, this.v0 + paddingBottom);
        Rect rect = this.k0;
        Rect rect2 = this.q;
        rect.set(rect2.left + i7, iMax, rect2.right - i7, this.u0 + iMax);
        if (Build.VERSION.SDK_INT >= 29) {
            q(i5, i6);
        }
        v();
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == 0) {
            size = this.v0;
        } else if (mode != 1073741824) {
            size = Math.min(this.v0, size);
        }
        setMeasuredDimension(View.MeasureSpec.getSize(i), size);
        w();
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i) {
        Drawable drawable = this.t0;
        if (drawable == null || !p(drawable, i)) {
            return;
        }
        invalidate();
    }

    /* JADX WARN: Code duplicated, block: B:23:0x004e  */
    /* JADX WARN: Code duplicated, block: B:25:0x0052  */
    /* JADX WARN: Code duplicated, block: B:27:0x0058  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (isEnabled() && this.S0 > 0) {
            Point pointM = m(motionEvent);
            int i = pointM.x;
            int i2 = pointM.y;
            int action = motionEvent.getAction();
            if (action == 0) {
                float f = i;
                if (j(f, i2)) {
                    k(f);
                    t(getScrubberPosition());
                    v();
                    invalidate();
                    return true;
                }
            } else if (action == 1) {
                if (this.Q0) {
                    u(motionEvent.getAction() == 3);
                    return true;
                }
            } else if (action != 2) {
                if (action == 3) {
                    if (this.Q0) {
                        u(motionEvent.getAction() == 3);
                        return true;
                    }
                }
            } else if (this.Q0) {
                if (i2 < this.C0) {
                    int i3 = this.L0;
                    k(i3 + ((i - i3) / 3));
                } else {
                    this.L0 = i;
                    k(i);
                }
                x(getScrubberPosition());
                v();
                invalidate();
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public boolean performAccessibilityAction(int i, Bundle bundle) {
        if (super.performAccessibilityAction(i, bundle)) {
            return true;
        }
        if (this.S0 <= 0) {
            return false;
        }
        if (i == 8192) {
            if (n(-getPositionIncrement())) {
                u(false);
            }
        } else {
            if (i != 4096) {
                return false;
            }
            if (n(getPositionIncrement())) {
                u(false);
            }
        }
        sendAccessibilityEvent(4);
        return true;
    }

    public void r() {
        if (this.N0.isStarted()) {
            this.N0.cancel();
        }
        this.P0 = false;
        this.O0 = 1.0f;
        invalidate(this.q);
    }

    public void s(long j) {
        if (this.N0.isStarted()) {
            this.N0.cancel();
        }
        this.P0 = false;
        this.N0.setFloatValues(this.O0, 1.0f);
        this.N0.setDuration(j);
        this.N0.start();
    }

    public void setAdMarkerColor(int i) {
        this.q0.setColor(i);
        invalidate(this.q);
    }

    public void setBufferedColor(int i) {
        this.o0.setColor(i);
        invalidate(this.q);
    }

    @Override // androidx.media3.ui.G
    public void setBufferedPosition(long j) {
        if (this.U0 == j) {
            return;
        }
        this.U0 = j;
        v();
    }

    @Override // androidx.media3.ui.G
    public void setDuration(long j) {
        if (this.S0 == j) {
            return;
        }
        this.S0 = j;
        if (this.Q0 && j == -9223372036854775807L) {
            u(true);
        }
        v();
    }

    @Override // android.view.View, androidx.media3.ui.G
    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (!this.Q0 || z) {
            return;
        }
        u(true);
    }

    public void setKeyCountIncrement(int i) {
        C1498a.a(i > 0);
        this.J0 = i;
        this.K0 = -9223372036854775807L;
    }

    public void setKeyTimeIncrement(long j) {
        C1498a.a(j > 0);
        this.J0 = -1;
        this.K0 = j;
    }

    public void setPlayedAdMarkerColor(int i) {
        this.r0.setColor(i);
        invalidate(this.q);
    }

    public void setPlayedColor(int i) {
        this.n0.setColor(i);
        invalidate(this.q);
    }

    @Override // androidx.media3.ui.G
    public void setPosition(long j) {
        if (this.T0 == j) {
            return;
        }
        this.T0 = j;
        setContentDescription(getProgressText());
        v();
    }

    public void setScrubberColor(int i) {
        this.s0.setColor(i);
        invalidate(this.q);
    }

    public void setUnplayedColor(int i) {
        this.p0.setColor(i);
        invalidate(this.q);
    }
}
