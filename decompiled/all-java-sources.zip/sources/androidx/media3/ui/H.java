package androidx.media3.ui;

import android.content.Context;
import android.text.Layout;
import android.util.AttributeSet;
import android.util.Base64;
import android.view.MotionEvent;
import android.webkit.WebView;
import android.widget.FrameLayout;
import ax.S0.C1498a;
import ax.S0.d0;
import ax.p005a2.C1762a;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
final class H extends FrameLayout implements SubtitleView.a {
    private final WebView k0;
    private List<ax.R0.a> l0;
    private C1762a m0;
    private float n0;
    private int o0;
    private float p0;
    private final C0659a q;

    class a extends WebView {
        a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        @Override // android.webkit.WebView, android.view.View
        public boolean onTouchEvent(MotionEvent motionEvent) {
            super.onTouchEvent(motionEvent);
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            super.performClick();
            return false;
        }
    }

    static /* synthetic */ class b {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[Layout.Alignment.values().length];
            a = iArr;
            try {
                iArr[Layout.Alignment.ALIGN_NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[Layout.Alignment.ALIGN_OPPOSITE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[Layout.Alignment.ALIGN_CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public H(Context context) {
        this(context, null);
    }

    public H(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.l0 = Collections.EMPTY_LIST;
        this.m0 = C1762a.g;
        this.n0 = 0.0533f;
        this.o0 = 0;
        this.p0 = 0.08f;
        C0659a c0659a = new C0659a(context, attributeSet);
        this.q = c0659a;
        a aVar = new a(context, attributeSet);
        this.k0 = aVar;
        aVar.setBackgroundColor(0);
        addView(c0659a);
        addView(aVar);
    }

    private static int b(int i) {
        if (i != 1) {
            return i != 2 ? 0 : -100;
        }
        return -50;
    }

    private static String c(Layout.Alignment alignment) {
        if (alignment == null) {
            return "center";
        }
        int i = b.a[alignment.ordinal()];
        if (i != 1) {
            return i != 2 ? "center" : "end";
        }
        return "start";
    }

    private static String d(C1762a c1762a) {
        int i = c1762a.d;
        if (i == 1) {
            return d0.G("1px 1px 0 %1$s, 1px -1px 0 %1$s, -1px 1px 0 %1$s, -1px -1px 0 %1$s", C0661c.b(c1762a.e));
        }
        if (i == 2) {
            return d0.G("0.1em 0.12em 0.15em %s", C0661c.b(c1762a.e));
        }
        if (i != 3) {
            return i != 4 ? "unset" : d0.G("-0.05em -0.05em 0.15em %s", C0661c.b(c1762a.e));
        }
        return d0.G("0.06em 0.08em 0.15em %s", C0661c.b(c1762a.e));
    }

    private String e(int i, float f) {
        float f2 = F.f(i, f, getHeight(), (getHeight() - getPaddingTop()) - getPaddingBottom());
        return f2 == -3.4028235E38f ? "unset" : d0.G("%.2fpx", Float.valueOf(f2 / getContext().getResources().getDisplayMetrics().density));
    }

    private static String f(int i) {
        if (i != 1) {
            return i != 2 ? "horizontal-tb" : "vertical-lr";
        }
        return "vertical-rl";
    }

    private static String h(ax.R0.a aVar) {
        float f = aVar.q;
        if (f == 0.0f) {
            return HttpUrl.FRAGMENT_ENCODE_SET;
        }
        int i = aVar.p;
        return d0.G("%s(%.2fdeg)", (i == 2 || i == 1) ? "skewY" : "skewX", Float.valueOf(f));
    }

    /* JADX WARN: Code duplicated, block: B:27:0x0114  */
    /* JADX WARN: Code duplicated, block: B:28:0x0125  */
    /* JADX WARN: Code duplicated, block: B:31:0x0141  */
    /* JADX WARN: Code duplicated, block: B:32:0x0144  */
    /* JADX WARN: Code duplicated, block: B:35:0x015b  */
    /* JADX WARN: Code duplicated, block: B:37:0x015e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:38:0x0160  */
    /* JADX WARN: Code duplicated, block: B:41:0x0168 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:43:0x016b  */
    /* JADX WARN: Code duplicated, block: B:44:0x016e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:51:0x017a  */
    /* JADX WARN: Code duplicated, block: B:55:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:61:0x01cc  */
    /* JADX WARN: Code duplicated, block: B:65:0x023d  */
    /* JADX WARN: Code duplicated, block: B:66:0x0257  */
    private void i() {
        char c;
        float f;
        String strG;
        int iB;
        boolean z;
        float f2;
        float f3;
        char c2;
        String strG2;
        int i;
        int i2;
        String str;
        String str2;
        String str3;
        z.b bVarA;
        Layout.Alignment alignment;
        String str4;
        boolean z2;
        StringBuilder sb = new StringBuilder();
        char c3 = 0;
        int i3 = 1;
        sb.append(d0.G("<body><div style='-webkit-user-select:none;position:fixed;top:0;bottom:0;left:0;right:0;color:%s;font-size:%s;line-height:%.2f;text-shadow:%s;'>", C0661c.b(this.m0.a), e(this.o0, this.n0), Float.valueOf(1.2f), d(this.m0)));
        HashMap map = new HashMap();
        map.put(C0661c.a("default_bg"), d0.G("background-color:%s;", C0661c.b(this.m0.b)));
        int i4 = 0;
        while (i4 < this.l0.size()) {
            ax.R0.a aVar = this.l0.get(i4);
            float f4 = aVar.h;
            float f5 = f4 != -3.4028235E38f ? f4 * 100.0f : 50.0f;
            int iB2 = b(aVar.i);
            float f6 = aVar.e;
            if (f6 != -3.4028235E38f) {
                c = 4;
                if (aVar.f != i3) {
                    Object[] objArr = new Object[i3];
                    objArr[c3] = Float.valueOf(f6 * 100.0f);
                    strG = d0.G("%.2f%%", objArr);
                    iB = aVar.p == i3 ? -b(aVar.g) : b(aVar.g);
                    z = false;
                    f2 = 100.0f;
                    f = -3.4028235E38f;
                } else {
                    if (f6 >= 0.0f) {
                        f = -3.4028235E38f;
                        Object[] objArr2 = new Object[i3];
                        objArr2[c3] = Float.valueOf(f6 * 1.2f);
                        strG = d0.G("%.2fem", objArr2);
                        iB = 0;
                    } else {
                        f = -3.4028235E38f;
                        Object[] objArr3 = new Object[i3];
                        objArr3[c3] = Float.valueOf(((-f6) - 1.0f) * 1.2f);
                        strG = d0.G("%.2fem", objArr3);
                        iB = 0;
                        z = true;
                    }
                    f2 = 100.0f;
                }
                f3 = aVar.j;
                if (f3 != f) {
                    Float fValueOf = Float.valueOf(f3 * f2);
                    c2 = 0;
                    Object[] objArr4 = new Object[i3];
                    objArr4[0] = fValueOf;
                    strG2 = d0.G("%.2f%%", objArr4);
                } else {
                    c2 = 0;
                    strG2 = "fit-content";
                }
                String strC = c(aVar.b);
                String strF = f(aVar.p);
                String strE = e(aVar.n, aVar.o);
                if (aVar.l) {
                    i = aVar.m;
                } else {
                    i = this.m0.c;
                }
                String strB = C0661c.b(i);
                i2 = aVar.p;
                str = "right";
                str2 = "top";
                if (i2 != 1) {
                    if (i2 != 2) {
                        str = z ? "bottom" : "top";
                        str2 = "left";
                    } else if (!z) {
                        str = "left";
                    }
                } else if (z) {
                    str = "left";
                }
                if (i2 != 2 || i2 == 1) {
                    str3 = "height";
                    iB2 = iB;
                    iB = iB2;
                } else {
                    str3 = "width";
                }
                bVarA = z.a(aVar.a, getContext().getResources().getDisplayMetrics().density);
                for (String str5 : map.keySet()) {
                    String str6 = str3;
                    String str7 = strG;
                    str4 = (String) map.put(str5, (String) map.get(str5));
                    if (str4 != null || str4.equals(map.get(str5))) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    C1498a.g(z2);
                    str3 = str6;
                    strG = str7;
                }
                String str8 = str3;
                String str9 = strG;
                Integer numValueOf = Integer.valueOf(i4);
                Float fValueOf2 = Float.valueOf(f5);
                Integer numValueOf2 = Integer.valueOf(iB2);
                Integer numValueOf3 = Integer.valueOf(iB);
                String strH = h(aVar);
                Object[] objArr5 = new Object[14];
                objArr5[c2] = numValueOf;
                objArr5[1] = str2;
                objArr5[2] = fValueOf2;
                objArr5[3] = str;
                objArr5[c] = str9;
                objArr5[5] = str8;
                objArr5[6] = strG2;
                objArr5[7] = strC;
                objArr5[8] = strF;
                objArr5[9] = strE;
                objArr5[10] = strB;
                objArr5[11] = numValueOf2;
                objArr5[12] = numValueOf3;
                objArr5[13] = strH;
                sb.append(d0.G("<div style='position:absolute;z-index:%s;%s:%.2f%%;%s:%s;%s:%s;text-align:%s;writing-mode:%s;font-size:%s;background-color:%s;transform:translate(%s%%,%s%%)%s;'>", objArr5));
                Object[] objArr6 = new Object[1];
                objArr6[c2] = "default_bg";
                sb.append(d0.G("<span class='%s'>", objArr6));
                alignment = aVar.c;
                if (alignment != null) {
                    Object[] objArr7 = new Object[1];
                    objArr7[c2] = c(alignment);
                    sb.append(d0.G("<span style='display:inline-block; text-align:%s;'>", objArr7));
                    sb.append(bVarA.a);
                    sb.append("</span>");
                } else {
                    sb.append(bVarA.a);
                }
                sb.append("</span>");
                sb.append("</div>");
                i4++;
                i3 = 1;
                c3 = 0;
            } else {
                c = 4;
                f = -3.4028235E38f;
                Object[] objArr8 = new Object[i3];
                objArr8[c3] = Float.valueOf((1.0f - this.p0) * 100.0f);
                strG = d0.G("%.2f%%", objArr8);
                iB = -100;
            }
            z = false;
            f2 = 100.0f;
            f3 = aVar.j;
            if (f3 != f) {
                Float fValueOf3 = Float.valueOf(f3 * f2);
                c2 = 0;
                Object[] objArr9 = new Object[i3];
                objArr9[0] = fValueOf3;
                strG2 = d0.G("%.2f%%", objArr9);
            } else {
                c2 = 0;
                strG2 = "fit-content";
            }
            String strC2 = c(aVar.b);
            String strF2 = f(aVar.p);
            String strE2 = e(aVar.n, aVar.o);
            if (aVar.l) {
                i = aVar.m;
            } else {
                i = this.m0.c;
            }
            String strB2 = C0661c.b(i);
            i2 = aVar.p;
            str = "right";
            str2 = "top";
            if (i2 != 1) {
                if (i2 != 2) {
                    str = z ? "bottom" : "top";
                    str2 = "left";
                } else if (!z) {
                    str = "left";
                }
            } else if (z) {
                str = "left";
            }
            if (i2 != 2) {
                str3 = "height";
                iB2 = iB;
                iB = iB2;
            } else {
                str3 = "height";
                iB2 = iB;
                iB = iB2;
            }
            bVarA = z.a(aVar.a, getContext().getResources().getDisplayMetrics().density);
            while (r13.hasNext()) {
                String str10 = str3;
                String str11 = strG;
                str4 = (String) map.put(str5, (String) map.get(str5));
                if (str4 != null) {
                    z2 = true;
                } else {
                    z2 = true;
                }
                C1498a.g(z2);
                str3 = str10;
                strG = str11;
            }
            String str12 = str3;
            String str13 = strG;
            Integer numValueOf4 = Integer.valueOf(i4);
            Float fValueOf4 = Float.valueOf(f5);
            Integer numValueOf5 = Integer.valueOf(iB2);
            Integer numValueOf6 = Integer.valueOf(iB);
            String strH2 = h(aVar);
            Object[] objArr10 = new Object[14];
            objArr10[c2] = numValueOf4;
            objArr10[1] = str2;
            objArr10[2] = fValueOf4;
            objArr10[3] = str;
            objArr10[c] = str13;
            objArr10[5] = str12;
            objArr10[6] = strG2;
            objArr10[7] = strC2;
            objArr10[8] = strF2;
            objArr10[9] = strE2;
            objArr10[10] = strB2;
            objArr10[11] = numValueOf5;
            objArr10[12] = numValueOf6;
            objArr10[13] = strH2;
            sb.append(d0.G("<div style='position:absolute;z-index:%s;%s:%.2f%%;%s:%s;%s:%s;text-align:%s;writing-mode:%s;font-size:%s;background-color:%s;transform:translate(%s%%,%s%%)%s;'>", objArr10));
            Object[] objArr11 = new Object[1];
            objArr11[c2] = "default_bg";
            sb.append(d0.G("<span class='%s'>", objArr11));
            alignment = aVar.c;
            if (alignment != null) {
                Object[] objArr12 = new Object[1];
                objArr12[c2] = c(alignment);
                sb.append(d0.G("<span style='display:inline-block; text-align:%s;'>", objArr12));
                sb.append(bVarA.a);
                sb.append("</span>");
            } else {
                sb.append(bVarA.a);
            }
            sb.append("</span>");
            sb.append("</div>");
            i4++;
            i3 = 1;
            c3 = 0;
        }
        sb.append("</div></body></html>");
        StringBuilder sb2 = new StringBuilder();
        sb2.append("<html><head><style>");
        for (String str14 : map.keySet()) {
            sb2.append(str14);
            sb2.append("{");
            sb2.append((String) map.get(str14));
            sb2.append("}");
        }
        sb2.append("</style></head>");
        sb.insert(0, (CharSequence) sb2);
        this.k0.loadData(Base64.encodeToString(sb.toString().getBytes(StandardCharsets.UTF_8), 1), "text/html", "base64");
    }

    @Override // androidx.media3.ui.SubtitleView.a
    public void a(List<ax.R0.a> list, C1762a c1762a, float f, int i, float f2) {
        this.m0 = c1762a;
        this.n0 = f;
        this.o0 = i;
        this.p0 = f2;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i2 = 0; i2 < list.size(); i2++) {
            ax.R0.a aVar = list.get(i2);
            if (aVar.d != null) {
                arrayList.add(aVar);
            } else {
                arrayList2.add(aVar);
            }
        }
        if (!this.l0.isEmpty() || !arrayList2.isEmpty()) {
            this.l0 = arrayList2;
            i();
        }
        this.q.a(arrayList, c1762a, f, i, f2);
        invalidate();
    }

    public void g() {
        this.k0.destroy();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (!z || this.l0.isEmpty()) {
            return;
        }
        i();
    }
}
