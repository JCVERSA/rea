package androidx.media3.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/* JADX INFO: loaded from: classes.dex */
public final class AspectRatioFrameLayout extends FrameLayout {
    private float k0;
    private int l0;
    private final c q;

    public interface b {
    }

    private final class c implements Runnable {
        private float X;
        private boolean Y;
        private boolean Z;
        private float q;

        private c() {
        }

        public void a(float f, float f2, boolean z) {
            this.q = f;
            this.X = f2;
            this.Y = z;
            if (this.Z) {
                return;
            }
            this.Z = true;
            AspectRatioFrameLayout.this.post(this);
        }

        @Override // java.lang.Runnable
        public void run() {
            this.Z = false;
            AspectRatioFrameLayout.a(AspectRatioFrameLayout.this);
        }
    }

    public AspectRatioFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.l0 = 0;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, ax.p005a2.F.a, 0, 0);
            try {
                this.l0 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.b, 0);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        }
        this.q = new c();
    }

    static /* synthetic */ b a(AspectRatioFrameLayout aspectRatioFrameLayout) {
        aspectRatioFrameLayout.getClass();
        return null;
    }

    public int getResizeMode() {
        return this.l0;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        float f;
        float f2;
        super.onMeasure(i, i2);
        if (this.k0 <= 0.0f) {
            return;
        }
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        float f3 = measuredWidth;
        float f4 = measuredHeight;
        float f5 = f3 / f4;
        float f6 = (this.k0 / f5) - 1.0f;
        if (Math.abs(f6) <= 0.01f) {
            this.q.a(this.k0, f5, false);
            return;
        }
        int i3 = this.l0;
        if (i3 != 0) {
            if (i3 != 1) {
                if (i3 == 2) {
                    f = this.k0;
                } else if (i3 == 4) {
                    if (f6 > 0.0f) {
                        f = this.k0;
                    } else {
                        f2 = this.k0;
                    }
                }
                measuredWidth = (int) (f4 * f);
            } else {
                f2 = this.k0;
            }
            measuredHeight = (int) (f3 / f2);
        } else if (f6 > 0.0f) {
            f2 = this.k0;
            measuredHeight = (int) (f3 / f2);
        } else {
            f = this.k0;
            measuredWidth = (int) (f4 * f);
        }
        this.q.a(this.k0, f5, true);
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824), View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824));
    }

    public void setAspectRatio(float f) {
        if (this.k0 != f) {
            this.k0 = f;
            requestLayout();
        }
    }

    public void setAspectRatioListener(b bVar) {
    }

    public void setResizeMode(int i) {
        if (this.l0 != i) {
            this.l0 = i;
            requestLayout();
        }
    }
}
