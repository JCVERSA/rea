package androidx.media3.ui;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.LinearLayout;
import ax.P0.C1375v;
import ax.P0.P;
import ax.P0.Q;
import ax.P0.V;
import ax.S0.C1498a;
import ax.Y7.AbstractC1656z;
import ax.p005a2.C1767f;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class TrackSelectionView extends LinearLayout {
    private final LayoutInflater k0;
    private final CheckedTextView l0;
    private final CheckedTextView m0;
    private final b n0;
    private final List<V.a> o0;
    private final Map<P, Q> p0;
    private final int q;
    private boolean q0;
    private boolean r0;
    private ax.p005a2.G s0;
    private CheckedTextView[][] t0;
    private boolean u0;
    private Comparator<c> v0;

    private class b implements View.OnClickListener {
        private b() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            TrackSelectionView.this.c(view);
        }
    }

    private static final class c {
        public final V.a a;
        public final int b;

        public c(V.a aVar, int i) {
            this.a = aVar;
            this.b = i;
        }

        public C1375v a() {
            return this.a.b(this.b);
        }
    }

    public TrackSelectionView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TrackSelectionView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setOrientation(1);
        setSaveFromParentEnabled(false);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(new int[]{R.attr.selectableItemBackground});
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        this.q = resourceId;
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        this.k0 = layoutInflaterFrom;
        b bVar = new b();
        this.n0 = bVar;
        this.s0 = new C1767f(getResources());
        this.o0 = new ArrayList();
        this.p0 = new HashMap();
        CheckedTextView checkedTextView = (CheckedTextView) layoutInflaterFrom.inflate(R.layout.simple_list_item_single_choice, (ViewGroup) this, false);
        this.l0 = checkedTextView;
        checkedTextView.setBackgroundResource(resourceId);
        checkedTextView.setText(ax.p005a2.D.x);
        checkedTextView.setEnabled(false);
        checkedTextView.setFocusable(true);
        checkedTextView.setOnClickListener(bVar);
        checkedTextView.setVisibility(8);
        addView(checkedTextView);
        addView(layoutInflaterFrom.inflate(ax.p005a2.B.a, (ViewGroup) this, false));
        CheckedTextView checkedTextView2 = (CheckedTextView) layoutInflaterFrom.inflate(R.layout.simple_list_item_single_choice, (ViewGroup) this, false);
        this.m0 = checkedTextView2;
        checkedTextView2.setBackgroundResource(resourceId);
        checkedTextView2.setText(ax.p005a2.D.w);
        checkedTextView2.setEnabled(false);
        checkedTextView2.setFocusable(true);
        checkedTextView2.setOnClickListener(bVar);
        addView(checkedTextView2);
    }

    public static Map<P, Q> b(Map<P, Q> map, List<V.a> list, boolean z) {
        HashMap map2 = new HashMap();
        for (int i = 0; i < list.size(); i++) {
            Q q = map.get(list.get(i).a());
            if (q != null && (z || map2.isEmpty())) {
                map2.put(q.a, q);
            }
        }
        return map2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(View view) {
        if (view == this.l0) {
            e();
        } else if (view == this.m0) {
            d();
        } else {
            f(view);
        }
        i();
    }

    private void d() {
        this.u0 = false;
        this.p0.clear();
    }

    private void e() {
        this.u0 = true;
        this.p0.clear();
    }

    private void f(View view) {
        this.u0 = false;
        c cVar = (c) C1498a.e(view.getTag());
        P pA = cVar.a.a();
        int i = cVar.b;
        Q q = this.p0.get(pA);
        if (q == null) {
            if (!this.r0 && !this.p0.isEmpty()) {
                this.p0.clear();
            }
            this.p0.put(pA, new Q(pA, AbstractC1656z.z(Integer.valueOf(i))));
            return;
        }
        ArrayList arrayList = new ArrayList(q.b);
        boolean zIsChecked = ((CheckedTextView) view).isChecked();
        boolean zG = g(cVar.a);
        boolean z = zG || h();
        if (zIsChecked && z) {
            arrayList.remove(Integer.valueOf(i));
            if (arrayList.isEmpty()) {
                this.p0.remove(pA);
                return;
            } else {
                this.p0.put(pA, new Q(pA, arrayList));
                return;
            }
        }
        if (zIsChecked) {
            return;
        }
        if (!zG) {
            this.p0.put(pA, new Q(pA, AbstractC1656z.z(Integer.valueOf(i))));
        } else {
            arrayList.add(Integer.valueOf(i));
            this.p0.put(pA, new Q(pA, arrayList));
        }
    }

    private boolean g(V.a aVar) {
        return this.q0 && aVar.e();
    }

    private boolean h() {
        return this.r0 && this.o0.size() > 1;
    }

    private void i() {
        this.l0.setChecked(this.u0);
        this.m0.setChecked(!this.u0 && this.p0.isEmpty());
        for (int i = 0; i < this.t0.length; i++) {
            Q q = this.p0.get(this.o0.get(i).a());
            int i2 = 0;
            while (true) {
                CheckedTextView[] checkedTextViewArr = this.t0[i];
                if (i2 < checkedTextViewArr.length) {
                    if (q != null) {
                        this.t0[i][i2].setChecked(q.b.contains(Integer.valueOf(((c) C1498a.e(checkedTextViewArr[i2].getTag())).b)));
                    } else {
                        checkedTextViewArr[i2].setChecked(false);
                    }
                    i2++;
                }
            }
        }
    }

    private void j() {
        for (int childCount = getChildCount() - 1; childCount >= 3; childCount--) {
            removeViewAt(childCount);
        }
        if (this.o0.isEmpty()) {
            this.l0.setEnabled(false);
            this.m0.setEnabled(false);
            return;
        }
        this.l0.setEnabled(true);
        this.m0.setEnabled(true);
        this.t0 = new CheckedTextView[this.o0.size()][];
        boolean zH = h();
        for (int i = 0; i < this.o0.size(); i++) {
            V.a aVar = this.o0.get(i);
            boolean zG = g(aVar);
            CheckedTextView[][] checkedTextViewArr = this.t0;
            int i2 = aVar.a;
            checkedTextViewArr[i] = new CheckedTextView[i2];
            c[] cVarArr = new c[i2];
            for (int i3 = 0; i3 < aVar.a; i3++) {
                cVarArr[i3] = new c(aVar, i3);
            }
            Comparator<c> comparator = this.v0;
            if (comparator != null) {
                Arrays.sort(cVarArr, comparator);
            }
            for (int i4 = 0; i4 < i2; i4++) {
                if (i4 == 0) {
                    addView(this.k0.inflate(ax.p005a2.B.a, (ViewGroup) this, false));
                }
                CheckedTextView checkedTextView = (CheckedTextView) this.k0.inflate((zG || zH) ? R.layout.simple_list_item_multiple_choice : R.layout.simple_list_item_single_choice, (ViewGroup) this, false);
                checkedTextView.setBackgroundResource(this.q);
                checkedTextView.setText(this.s0.a(cVarArr[i4].a()));
                checkedTextView.setTag(cVarArr[i4]);
                if (aVar.j(i4)) {
                    checkedTextView.setFocusable(true);
                    checkedTextView.setOnClickListener(this.n0);
                } else {
                    checkedTextView.setFocusable(false);
                    checkedTextView.setEnabled(false);
                }
                this.t0[i][i4] = checkedTextView;
                addView(checkedTextView);
            }
        }
        i();
    }

    public boolean getIsDisabled() {
        return this.u0;
    }

    public Map<P, Q> getOverrides() {
        return this.p0;
    }

    public void setAllowAdaptiveSelections(boolean z) {
        if (this.q0 != z) {
            this.q0 = z;
            j();
        }
    }

    public void setAllowMultipleOverrides(boolean z) {
        if (this.r0 != z) {
            this.r0 = z;
            if (!z && this.p0.size() > 1) {
                Map<P, Q> mapB = b(this.p0, this.o0, false);
                this.p0.clear();
                this.p0.putAll(mapB);
            }
            j();
        }
    }

    public void setShowDisableOption(boolean z) {
        this.l0.setVisibility(z ? 0 : 8);
    }

    public void setTrackNameProvider(ax.p005a2.G g) {
        this.s0 = (ax.p005a2.G) C1498a.e(g);
        j();
    }
}
