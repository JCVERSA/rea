package androidx.media3.ui;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.accessibility.CaptioningManager;
import android.widget.FrameLayout;
import ax.p005a2.C1762a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class SubtitleView extends FrameLayout {
    private C1762a k0;
    private int l0;
    private float m0;
    private float n0;
    private boolean o0;
    private boolean p0;
    private List<ax.R0.a> q;
    private int q0;
    private a r0;
    private View s0;

    interface a {
        void a(List<ax.R0.a> list, C1762a c1762a, float f, int i, float f2);
    }

    public SubtitleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.q = Collections.EMPTY_LIST;
        this.k0 = C1762a.g;
        this.l0 = 0;
        this.m0 = 0.0533f;
        this.n0 = 0.08f;
        this.o0 = true;
        this.p0 = true;
        C0659a c0659a = new C0659a(context);
        this.r0 = c0659a;
        this.s0 = c0659a;
        addView(c0659a);
        this.q0 = 1;
    }

    private ax.R0.a a(ax.R0.a aVar) {
        ax.R0.a.b bVarA = aVar.a();
        if (!this.o0) {
            F.c(bVarA);
        } else if (!this.p0) {
            F.d(bVarA);
        }
        return bVarA.a();
    }

    private void d(int i, float f) {
        this.l0 = i;
        this.m0 = f;
        g();
    }

    private void g() {
        this.r0.a(getCuesWithStylingPreferencesApplied(), this.k0, this.m0, this.l0, this.n0);
    }

    private List<ax.R0.a> getCuesWithStylingPreferencesApplied() {
        if (this.o0 && this.p0) {
            return this.q;
        }
        ArrayList arrayList = new ArrayList(this.q.size());
        for (int i = 0; i < this.q.size(); i++) {
            arrayList.add(a(this.q.get(i)));
        }
        return arrayList;
    }

    private float getUserCaptionFontScale() {
        CaptioningManager captioningManager;
        if (isInEditMode() || (captioningManager = (CaptioningManager) getContext().getSystemService("captioning")) == null || !captioningManager.isEnabled()) {
            return 1.0f;
        }
        return captioningManager.getFontScale();
    }

    private C1762a getUserCaptionStyle() {
        if (isInEditMode()) {
            return C1762a.g;
        }
        CaptioningManager captioningManager = (CaptioningManager) getContext().getSystemService("captioning");
        return (captioningManager == null || !captioningManager.isEnabled()) ? C1762a.g : C1762a.a(captioningManager.getUserStyle());
    }

    private <T extends View & a> void setView(T t) {
        removeView(this.s0);
        View view = this.s0;
        if (view instanceof H) {
            ((H) view).g();
        }
        this.s0 = t;
        this.r0 = t;
        addView(t);
    }

    public void b(int i, float f) {
        Context context = getContext();
        d(2, TypedValue.applyDimension(i, f, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics()));
    }

    public void c(float f, boolean z) {
        d(z ? 1 : 0, f);
    }

    public void e() {
        setStyle(getUserCaptionStyle());
    }

    public void f() {
        setFractionalTextSize(getUserCaptionFontScale() * 0.0533f);
    }

    public void setApplyEmbeddedFontSizes(boolean z) {
        this.p0 = z;
        g();
    }

    public void setApplyEmbeddedStyles(boolean z) {
        this.o0 = z;
        g();
    }

    public void setBottomPaddingFraction(float f) {
        this.n0 = f;
        g();
    }

    public void setCues(List<ax.R0.a> list) {
        if (list == null) {
            list = Collections.EMPTY_LIST;
        }
        this.q = list;
        g();
    }

    public void setFractionalTextSize(float f) {
        c(f, false);
    }

    public void setStyle(C1762a c1762a) {
        this.k0 = c1762a;
        g();
    }

    public void setViewType(int i) {
        if (this.q0 == i) {
            return;
        }
        if (i == 1) {
            setView(new C0659a(getContext()));
        } else {
            if (i != 2) {
                throw new IllegalArgumentException();
            }
            setView(new H(getContext()));
        }
        this.q0 = i;
    }
}
