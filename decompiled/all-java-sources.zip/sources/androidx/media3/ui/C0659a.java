package androidx.media3.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import ax.p005a2.C1762a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: renamed from: androidx.media3.ui.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0659a extends View implements SubtitleView.a {
    private List<ax.R0.a> k0;
    private int l0;
    private float m0;
    private C1762a n0;
    private float o0;
    private final List<C> q;

    public C0659a(Context context) {
        this(context, null);
    }

    public C0659a(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.q = new ArrayList();
        this.k0 = Collections.EMPTY_LIST;
        this.l0 = 0;
        this.m0 = 0.0533f;
        this.n0 = C1762a.g;
        this.o0 = 0.08f;
    }

    private static ax.R0.a b(ax.R0.a aVar) {
        ax.R0.a.b bVarP = aVar.a().k(-3.4028235E38f).l(Integer.MIN_VALUE).p(null);
        if (aVar.f == 0) {
            bVarP.h(1.0f - aVar.e, 0);
        } else {
            bVarP.h((-aVar.e) - 1.0f, 1);
        }
        int i = aVar.g;
        if (i == 0) {
            bVarP.i(2);
        } else if (i == 2) {
            bVarP.i(0);
        }
        return bVarP.a();
    }

    @Override // androidx.media3.ui.SubtitleView.a
    public void a(List<ax.R0.a> list, C1762a c1762a, float f, int i, float f2) {
        this.k0 = list;
        this.n0 = c1762a;
        this.m0 = f;
        this.l0 = i;
        this.o0 = f2;
        while (this.q.size() < list.size()) {
            this.q.add(new C(getContext()));
        }
        invalidate();
    }

    @Override // android.view.View
    public void dispatchDraw(Canvas canvas) {
        List<ax.R0.a> list = this.k0;
        if (list.isEmpty()) {
            return;
        }
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int width = getWidth() - getPaddingRight();
        int paddingBottom = height - getPaddingBottom();
        if (paddingBottom <= paddingTop || width <= paddingLeft) {
            return;
        }
        int i = paddingBottom - paddingTop;
        float f = F.f(this.l0, this.m0, height, i);
        if (f <= 0.0f) {
            return;
        }
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            ax.R0.a aVarB = list.get(i2);
            if (aVarB.p != Integer.MIN_VALUE) {
                aVarB = b(aVarB);
            }
            this.q.get(i2).b(aVarB, this.n0, f, F.f(aVarB.n, aVarB.o, height, i), this.o0, canvas, paddingLeft, paddingTop, width, paddingBottom);
        }
    }
}
