package androidx.media3.ui;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.AttachedSurfaceControl;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.SurfaceSyncGroup;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.image.ImageOutput;
import androidx.media3.ui.PlayerView;
import ax.P0.C1355a;
import ax.P0.C1357c;
import ax.P0.C1368n;
import ax.P0.C1378y;
import ax.P0.I;
import ax.P0.InterfaceC1370p;
import ax.P0.N;
import ax.P0.T;
import ax.P0.V;
import ax.P0.a0;
import ax.S0.C1498a;
import ax.S0.d0;
import ax.Y7.AbstractC1656z;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class PlayerView extends FrameLayout {
    private final Object A0;
    private ax.P0.H B0;
    private boolean C0;
    private d D0;
    private C0662d.m E0;
    private int F0;
    private int G0;
    private Drawable H0;
    private int I0;
    private boolean J0;
    private InterfaceC1370p<? super ax.P0.F> K0;
    private CharSequence L0;
    private int M0;
    private boolean N0;
    private boolean O0;
    private boolean P0;
    private boolean Q0;
    private final AspectRatioFrameLayout k0;
    private final View l0;
    private final View m0;
    private final boolean n0;
    private final f o0;
    private final ImageView p0;
    private final c q;
    private final ImageView q0;
    private final SubtitleView r0;
    private final View s0;
    private final TextView t0;
    private final C0662d u0;
    private final FrameLayout v0;
    private final FrameLayout w0;
    private final Handler x0;
    private final Class<?> y0;
    private final Method z0;

    private static class b {
        public static void a(SurfaceView surfaceView) {
            surfaceView.setSurfaceLifecycle(2);
        }
    }

    private final class c implements ax.P0.H.d, View.OnClickListener, C0662d.m, C0662d.InterfaceC0031d {
        private Object X;
        private final N.b q = new N.b();

        public c() {
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void B(ax.P0.C c) {
            I.n(this, c);
        }

        @Override // ax.P0.H.d
        public void C(ax.R0.c cVar) {
            if (PlayerView.this.r0 != null) {
                PlayerView.this.r0.setCues(cVar.a);
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void D(List list) {
            I.e(this, list);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void K0(int i) {
            I.y(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void M(int i) {
            I.r(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void N(boolean z) {
            I.k(this, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void O(int i) {
            I.v(this, i);
        }

        @Override // androidx.media3.ui.C0662d.InterfaceC0031d
        public void P(boolean z) {
            PlayerView.p(PlayerView.this);
        }

        @Override // ax.P0.H.d
        public void Q(V v) {
            ax.P0.H h = (ax.P0.H) C1498a.e(PlayerView.this.B0);
            N nF0 = h.Z(17) ? h.f0() : N.a;
            if (nF0.q()) {
                this.X = null;
            } else if (!h.Z(30) || h.S().b()) {
                Object obj = this.X;
                if (obj != null) {
                    int iB = nF0.b(obj);
                    if (iB != -1) {
                        if (h.Y() == nF0.f(iB, this.q).c) {
                            return;
                        }
                    }
                    this.X = null;
                }
            } else {
                this.X = nF0.g(h.w(), this.q, true).b;
            }
            PlayerView.this.e0(false);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void R(boolean z) {
            I.i(this, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void S(ax.P0.F f) {
            I.t(this, f);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void T(float f) {
            I.G(this, f);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void U(ax.P0.F f) {
            I.s(this, f);
        }

        @Override // ax.P0.H.d
        public void V(int i) {
            PlayerView.this.a0();
            PlayerView.this.d0();
            PlayerView.this.c0();
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void X(N n, int i) {
            I.C(this, n, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void Z(boolean z) {
            I.z(this, z);
        }

        @Override // ax.P0.H.d
        public void a(a0 a0Var) {
            if (a0Var.equals(a0.e) || PlayerView.this.B0 == null || PlayerView.this.B0.V() == 1) {
                return;
            }
            PlayerView.this.Z();
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void b0(T t) {
            I.D(this, t);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void c(int i) {
            I.b(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void c0(ax.P0.H.b bVar) {
            I.c(this, bVar);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void d(boolean z) {
            I.A(this, z);
        }

        @Override // androidx.media3.ui.C0662d.m
        public void d0(int i) {
            PlayerView.this.b0();
            if (PlayerView.this.D0 != null) {
                PlayerView.this.D0.a(i);
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void e0(int i, boolean z) {
            I.g(this, i, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void f0(boolean z, int i) {
            I.u(this, z, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void g0(C1378y c1378y, int i) {
            I.l(this, c1378y, i);
        }

        @Override // ax.P0.H.d
        public void h0() {
            if (PlayerView.this.l0 != null) {
                PlayerView.this.l0.setVisibility(4);
                if (PlayerView.this.C()) {
                    PlayerView.this.H();
                } else {
                    PlayerView.this.E();
                }
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void i0(ax.P0.H h, ax.P0.H.c cVar) {
            I.h(this, h, cVar);
        }

        @Override // ax.P0.H.d
        public void m0(boolean z, int i) {
            PlayerView.this.a0();
            PlayerView.this.c0();
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void n0(ax.P0.A a) {
            I.m(this, a);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void o0(C1368n c1368n) {
            I.f(this, c1368n);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PlayerView.this.Y();
        }

        @Override // ax.P0.H.d
        public void q0(int i, int i2) {
            if (Build.VERSION.SDK_INT == 34 && (PlayerView.this.m0 instanceof SurfaceView) && PlayerView.this.Q0) {
                f fVar = (f) C1498a.e(PlayerView.this.o0);
                Handler handler = PlayerView.this.x0;
                SurfaceView surfaceView = (SurfaceView) PlayerView.this.m0;
                final PlayerView playerView = PlayerView.this;
                fVar.d(handler, surfaceView, new Runnable() { // from class: ax.a2.n
                    @Override // java.lang.Runnable
                    public final void run() {
                        playerView.invalidate();
                    }
                });
            }
        }

        @Override // ax.P0.H.d
        public void r0(ax.P0.H.e eVar, ax.P0.H.e eVar2, int i) {
            if (PlayerView.this.L() && PlayerView.this.O0) {
                PlayerView.this.G();
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void s0(C1357c c1357c) {
            I.a(this, c1357c);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void t(ax.P0.G g) {
            I.p(this, g);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void t0(boolean z) {
            I.j(this, z);
        }
    }

    public interface d {
        void a(int i);
    }

    public interface e {
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class f {
        SurfaceSyncGroup a;

        private f() {
        }

        public static /* synthetic */ void a(f fVar, SurfaceView surfaceView, Runnable runnable) {
            fVar.getClass();
            AttachedSurfaceControl rootSurfaceControl = surfaceView.getRootSurfaceControl();
            if (rootSurfaceControl == null) {
                return;
            }
            SurfaceSyncGroup surfaceSyncGroupA = ax.p005a2.o.a("exo-sync-b-334901521");
            fVar.a = surfaceSyncGroupA;
            C1498a.g(surfaceSyncGroupA.add(rootSurfaceControl, new Runnable() { // from class: androidx.media3.ui.y
                @Override // java.lang.Runnable
                public final void run() {
                    PlayerView.f.b();
                }
            }));
            runnable.run();
            rootSurfaceControl.applyTransactionOnDraw(ax.p005a2.p.a());
        }

        public static /* synthetic */ void b() {
        }

        public void c() {
            SurfaceSyncGroup surfaceSyncGroup = this.a;
            if (surfaceSyncGroup != null) {
                surfaceSyncGroup.markSyncReady();
                this.a = null;
            }
        }

        public void d(Handler handler, final SurfaceView surfaceView, final Runnable runnable) {
            handler.post(new Runnable() { // from class: androidx.media3.ui.x
                @Override // java.lang.Runnable
                public final void run() {
                    PlayerView.f.a(this.q, surfaceView, runnable);
                }
            });
        }
    }

    public PlayerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PlayerView(Context context, AttributeSet attributeSet, int i) {
        int i2;
        boolean z;
        int i3;
        boolean z2;
        boolean z3;
        boolean z4;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        boolean z5;
        boolean z6;
        a aVar;
        boolean z7;
        Class<ExoPlayer> cls;
        Object objNewProxyInstance;
        Method method;
        boolean z8;
        super(context, attributeSet, i);
        c cVar = new c();
        this.q = cVar;
        this.x0 = new Handler(Looper.getMainLooper());
        if (isInEditMode()) {
            this.k0 = null;
            this.l0 = null;
            this.m0 = null;
            this.n0 = false;
            this.o0 = null;
            this.p0 = null;
            this.q0 = null;
            this.r0 = null;
            this.s0 = null;
            this.t0 = null;
            this.u0 = null;
            this.v0 = null;
            this.w0 = null;
            this.y0 = null;
            this.z0 = null;
            this.A0 = null;
            ImageView imageView = new ImageView(context);
            if (Build.VERSION.SDK_INT >= 23) {
                A(context, getResources(), imageView);
            } else {
                z(context, getResources(), imageView);
            }
            addView(imageView);
            return;
        }
        int i11 = ax.p005a2.B.c;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, ax.p005a2.F.c0, i, 0);
            try {
                int i12 = ax.p005a2.F.o0;
                boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i12);
                int color = typedArrayObtainStyledAttributes.getColor(i12, 0);
                int resourceId = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.k0, i11);
                boolean z9 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.q0, true);
                int i13 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.d0, 1);
                int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.f0, 0);
                int i14 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.i0, 0);
                boolean z10 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.r0, true);
                int i15 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.p0, 1);
                int i16 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.l0, 0);
                i10 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.n0, 5000);
                z3 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.h0, true);
                boolean z11 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.e0, true);
                int integer = typedArrayObtainStyledAttributes.getInteger(ax.p005a2.F.m0, 0);
                this.J0 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.j0, this.J0);
                boolean z12 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.g0, true);
                typedArrayObtainStyledAttributes.recycle();
                i3 = i16;
                z = z10;
                z4 = z12;
                i6 = i15;
                i2 = resourceId;
                z5 = zHasValue;
                i9 = i13;
                i8 = i14;
                z2 = z11;
                i4 = integer;
                z6 = z9;
                i7 = color;
                i5 = resourceId2;
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        } else {
            i2 = i11;
            z = true;
            i3 = 0;
            z2 = true;
            z3 = true;
            z4 = true;
            i4 = 0;
            i5 = 0;
            i6 = 1;
            i7 = 0;
            i8 = 0;
            i9 = 1;
            i10 = 5000;
            z5 = false;
            z6 = true;
        }
        LayoutInflater.from(context).inflate(i2, this);
        setDescendantFocusability(262144);
        AspectRatioFrameLayout aspectRatioFrameLayout = (AspectRatioFrameLayout) findViewById(ax.p005a2.z.i);
        this.k0 = aspectRatioFrameLayout;
        if (aspectRatioFrameLayout != null) {
            T(aspectRatioFrameLayout, i3);
        }
        View viewFindViewById = findViewById(ax.p005a2.z.N);
        this.l0 = viewFindViewById;
        if (viewFindViewById != null && z5) {
            viewFindViewById.setBackgroundColor(i7);
        }
        if (aspectRatioFrameLayout == null || i6 == 0) {
            aVar = null;
            this.m0 = null;
            z7 = false;
        } else {
            ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
            if (i6 != 2) {
                if (i6 == 3) {
                    try {
                        int i17 = ax.p244p1.l.v0;
                        this.m0 = (View) ax.p244p1.l.class.getConstructor(Context.class).newInstance(context);
                        z8 = true;
                    } catch (Exception e2) {
                        throw new IllegalStateException("spherical_gl_surface_view requires an ExoPlayer dependency", e2);
                    }
                } else if (i6 != 4) {
                    SurfaceView surfaceView = new SurfaceView(context);
                    if (Build.VERSION.SDK_INT >= 34) {
                        b.a(surfaceView);
                    }
                    this.m0 = surfaceView;
                } else {
                    try {
                        int i18 = ax.p228o1.x.k0;
                        this.m0 = (View) ax.p228o1.x.class.getConstructor(Context.class).newInstance(context);
                    } catch (Exception e3) {
                        throw new IllegalStateException("video_decoder_gl_surface_view requires an ExoPlayer dependency", e3);
                    }
                }
                this.m0.setLayoutParams(layoutParams);
                this.m0.setOnClickListener(cVar);
                this.m0.setClickable(false);
                aspectRatioFrameLayout.addView(this.m0, 0);
                z7 = z8;
                aVar = null;
            } else {
                this.m0 = new TextureView(context);
            }
            z8 = false;
            this.m0.setLayoutParams(layoutParams);
            this.m0.setOnClickListener(cVar);
            this.m0.setClickable(false);
            aspectRatioFrameLayout.addView(this.m0, 0);
            z7 = z8;
            aVar = null;
        }
        this.n0 = z7;
        this.o0 = Build.VERSION.SDK_INT == 34 ? new f() : null;
        this.v0 = (FrameLayout) findViewById(ax.p005a2.z.a);
        this.w0 = (FrameLayout) findViewById(ax.p005a2.z.B);
        this.p0 = (ImageView) findViewById(ax.p005a2.z.u);
        this.G0 = i8;
        try {
            cls = ExoPlayer.class;
            ImageOutput imageOutput = ImageOutput.a;
            method = cls.getMethod("setImageOutput", ImageOutput.class);
            objNewProxyInstance = Proxy.newProxyInstance(ImageOutput.class.getClassLoader(), new Class[]{ImageOutput.class}, new InvocationHandler() { // from class: ax.a2.k
                @Override // java.lang.reflect.InvocationHandler
                public final Object invoke(Object obj, Method method2, Object[] objArr) {
                    return PlayerView.b(this.a, obj, method2, objArr);
                }
            });
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            cls = null;
            objNewProxyInstance = null;
            method = null;
        }
        this.y0 = cls;
        this.z0 = method;
        this.A0 = objNewProxyInstance;
        ImageView imageView2 = (ImageView) findViewById(ax.p005a2.z.b);
        this.q0 = imageView2;
        this.F0 = (!z6 || i9 == 0 || imageView2 == null) ? 0 : i9;
        if (i5 != 0) {
            this.H0 = ax.Q.b.e(getContext(), i5);
        }
        SubtitleView subtitleView = (SubtitleView) findViewById(ax.p005a2.z.Q);
        this.r0 = subtitleView;
        if (subtitleView != null) {
            subtitleView.e();
            subtitleView.f();
        }
        View viewFindViewById2 = findViewById(ax.p005a2.z.f);
        this.s0 = viewFindViewById2;
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(8);
        }
        this.I0 = i4;
        TextView textView = (TextView) findViewById(ax.p005a2.z.n);
        this.t0 = textView;
        if (textView != null) {
            textView.setVisibility(8);
        }
        int i19 = ax.p005a2.z.j;
        C0662d c0662d = (C0662d) findViewById(i19);
        View viewFindViewById3 = findViewById(ax.p005a2.z.k);
        if (c0662d != null) {
            this.u0 = c0662d;
        } else if (viewFindViewById3 != null) {
            C0662d c0662d2 = new C0662d(context, null, 0, attributeSet);
            this.u0 = c0662d2;
            c0662d2.setId(i19);
            c0662d2.setLayoutParams(viewFindViewById3.getLayoutParams());
            ViewGroup viewGroup = (ViewGroup) viewFindViewById3.getParent();
            int iIndexOfChild = viewGroup.indexOfChild(viewFindViewById3);
            viewGroup.removeView(viewFindViewById3);
            viewGroup.addView(c0662d2, iIndexOfChild);
        } else {
            this.u0 = null;
        }
        C0662d c0662d3 = this.u0;
        this.M0 = c0662d3 != null ? i10 : 0;
        this.P0 = z3;
        this.N0 = z2;
        this.O0 = z4;
        this.C0 = z && c0662d3 != null;
        if (c0662d3 != null) {
            c0662d3.f0();
            this.u0.Y(this.q);
        }
        if (z) {
            setClickable(true);
        }
        b0();
    }

    private static void A(Context context, Resources resources, ImageView imageView) {
        imageView.setImageDrawable(d0.a0(context, resources, ax.p005a2.x.a));
        imageView.setBackgroundColor(resources.getColor(ax.p005a2.v.a, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean C() {
        ax.P0.H h = this.B0;
        return h != null && this.A0 != null && h.Z(30) && h.S().c(4);
    }

    private boolean D() {
        ax.P0.H h = this.B0;
        return h != null && h.Z(30) && h.S().c(2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E() {
        H();
        ImageView imageView = this.p0;
        if (imageView != null) {
            imageView.setImageResource(R.color.transparent);
        }
    }

    private void F() {
        ImageView imageView = this.q0;
        if (imageView != null) {
            imageView.setImageResource(R.color.transparent);
            this.q0.setVisibility(4);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H() {
        ImageView imageView = this.p0;
        if (imageView != null) {
            imageView.setVisibility(4);
        }
    }

    @SuppressLint({"InlinedApi"})
    private boolean J(int i) {
        return i == 19 || i == 270 || i == 22 || i == 271 || i == 20 || i == 269 || i == 21 || i == 268 || i == 23;
    }

    private boolean K() {
        Drawable drawable;
        ImageView imageView = this.p0;
        return (imageView == null || (drawable = imageView.getDrawable()) == null || drawable.getAlpha() == 0) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean L() {
        ax.P0.H h = this.B0;
        return h != null && h.Z(16) && this.B0.j() && this.B0.o();
    }

    private void M(boolean z) {
        if (!(L() && this.O0) && h0()) {
            boolean z2 = this.u0.k0() && this.u0.getShowTimeoutMs() <= 0;
            boolean zU = U();
            if (z || z2 || zU) {
                W(zU);
            }
        }
    }

    private void O(final Bitmap bitmap) {
        this.x0.post(new Runnable() { // from class: ax.a2.l
            @Override // java.lang.Runnable
            public final void run() {
                PlayerView.a(this.q, bitmap);
            }
        });
    }

    private boolean R(ax.P0.H h) {
        byte[] bArr;
        if (h == null || !h.Z(18) || (bArr = h.q0().i) == null) {
            return false;
        }
        return S(new BitmapDrawable(getResources(), BitmapFactory.decodeByteArray(bArr, 0, bArr.length)));
    }

    private boolean S(Drawable drawable) {
        if (this.q0 != null && drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            if (intrinsicWidth > 0 && intrinsicHeight > 0) {
                float width = intrinsicWidth / intrinsicHeight;
                ImageView.ScaleType scaleType = ImageView.ScaleType.FIT_XY;
                if (this.F0 == 2) {
                    width = getWidth() / getHeight();
                    scaleType = ImageView.ScaleType.CENTER_CROP;
                }
                N(this.k0, width);
                this.q0.setScaleType(scaleType);
                this.q0.setImageDrawable(drawable);
                this.q0.setVisibility(0);
                return true;
            }
        }
        return false;
    }

    private static void T(AspectRatioFrameLayout aspectRatioFrameLayout, int i) {
        aspectRatioFrameLayout.setResizeMode(i);
    }

    private boolean U() {
        ax.P0.H h = this.B0;
        if (h == null) {
            return true;
        }
        int iV = h.V();
        if (!this.N0) {
            return false;
        }
        if (this.B0.Z(17) && this.B0.f0().q()) {
            return false;
        }
        return iV == 1 || iV == 4 || !((ax.P0.H) C1498a.e(this.B0)).o();
    }

    private void W(boolean z) {
        if (h0()) {
            this.u0.setShowTimeoutMs(z ? 0 : this.M0);
            this.u0.v0();
        }
    }

    private void X() {
        ImageView imageView = this.p0;
        if (imageView != null) {
            imageView.setVisibility(0);
            f0();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Y() {
        if (!h0() || this.B0 == null) {
            return;
        }
        if (!this.u0.k0()) {
            M(true);
        } else if (this.P0) {
            this.u0.e0();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Z() {
        ax.P0.H h = this.B0;
        a0 a0VarY = h != null ? h.y() : a0.e;
        int i = a0VarY.a;
        int i2 = a0VarY.b;
        N(this.k0, this.n0 ? 0.0f : (i2 == 0 || i == 0) ? 0.0f : (i * a0VarY.d) / i2);
    }

    public static /* synthetic */ void a(PlayerView playerView, Bitmap bitmap) {
        playerView.getClass();
        playerView.setImage(new BitmapDrawable(playerView.getResources(), bitmap));
        if (playerView.D()) {
            return;
        }
        playerView.X();
        playerView.y();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:14:0x0020  */
    public void a0() {
        boolean z;
        if (this.s0 != null) {
            ax.P0.H h = this.B0;
            if (h == null || h.V() != 2) {
                z = false;
            } else {
                int i = this.I0;
                z = true;
                if (i != 2 && (i != 1 || !this.B0.o())) {
                    z = false;
                }
            }
            this.s0.setVisibility(z ? 0 : 8);
        }
    }

    public static /* synthetic */ Object b(PlayerView playerView, Object obj, Method method, Object[] objArr) {
        playerView.getClass();
        if (!method.getName().equals("onImageAvailable")) {
            return null;
        }
        playerView.O((Bitmap) objArr[1]);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b0() {
        C0662d c0662d = this.u0;
        if (c0662d == null || !this.C0) {
            setContentDescription(null);
        } else if (c0662d.k0()) {
            setContentDescription(this.P0 ? getResources().getString(ax.p005a2.D.e) : null);
        } else {
            setContentDescription(getResources().getString(ax.p005a2.D.l));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c0() {
        if (L() && this.O0) {
            G();
        } else {
            M(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d0() {
        InterfaceC1370p<? super ax.P0.F> interfaceC1370p;
        TextView textView = this.t0;
        if (textView != null) {
            CharSequence charSequence = this.L0;
            if (charSequence != null) {
                textView.setText(charSequence);
                this.t0.setVisibility(0);
                return;
            }
            ax.P0.H h = this.B0;
            ax.P0.F fM = h != null ? h.M() : null;
            if (fM == null || (interfaceC1370p = this.K0) == null) {
                this.t0.setVisibility(8);
            } else {
                this.t0.setText((CharSequence) interfaceC1370p.a(fM).second);
                this.t0.setVisibility(0);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e0(boolean z) {
        ax.P0.H h = this.B0;
        boolean z2 = false;
        boolean z3 = (h == null || !h.Z(30) || h.S().b()) ? false : true;
        if (!this.J0 && (!z3 || z)) {
            F();
            y();
            E();
        }
        if (z3) {
            boolean zD = D();
            boolean zC = C();
            if (!zD && !zC) {
                y();
                E();
            }
            View view = this.l0;
            if (view != null && view.getVisibility() == 4 && K()) {
                z2 = true;
            }
            if (zC && !zD && z2) {
                y();
                X();
            } else if (zD && !zC && z2) {
                E();
            }
            if (zD || zC || !g0() || !(R(h) || S(this.H0))) {
                F();
            }
        }
    }

    private void f0() {
        Drawable drawable;
        ImageView imageView = this.p0;
        if (imageView == null || (drawable = imageView.getDrawable()) == null) {
            return;
        }
        int intrinsicWidth = drawable.getIntrinsicWidth();
        int intrinsicHeight = drawable.getIntrinsicHeight();
        if (intrinsicWidth <= 0 || intrinsicHeight <= 0) {
            return;
        }
        float width = intrinsicWidth / intrinsicHeight;
        ImageView.ScaleType scaleType = ImageView.ScaleType.FIT_XY;
        if (this.G0 == 1) {
            width = getWidth() / getHeight();
            scaleType = ImageView.ScaleType.CENTER_CROP;
        }
        if (this.p0.getVisibility() == 0) {
            N(this.k0, width);
        }
        this.p0.setScaleType(scaleType);
    }

    private boolean g0() {
        if (this.F0 == 0) {
            return false;
        }
        C1498a.i(this.q0);
        return true;
    }

    private boolean h0() {
        if (!this.C0) {
            return false;
        }
        C1498a.i(this.u0);
        return true;
    }

    static /* synthetic */ e p(PlayerView playerView) {
        playerView.getClass();
        return null;
    }

    private void setImage(Drawable drawable) {
        ImageView imageView = this.p0;
        if (imageView == null) {
            return;
        }
        imageView.setImageDrawable(drawable);
        f0();
    }

    private void setImageOutput(ax.P0.H h) {
        Class<?> cls = this.y0;
        if (cls == null || !cls.isAssignableFrom(h.getClass())) {
            return;
        }
        try {
            ((Method) C1498a.e(this.z0)).invoke(h, C1498a.e(this.A0));
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    private void x(ax.P0.H h) {
        Class<?> cls = this.y0;
        if (cls == null || !cls.isAssignableFrom(h.getClass())) {
            return;
        }
        try {
            ((Method) C1498a.e(this.z0)).invoke(h, null);
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    private void y() {
        View view = this.l0;
        if (view != null) {
            view.setVisibility(0);
        }
    }

    private static void z(Context context, Resources resources, ImageView imageView) {
        imageView.setImageDrawable(d0.a0(context, resources, ax.p005a2.x.a));
        imageView.setBackgroundColor(resources.getColor(ax.p005a2.v.a));
    }

    public boolean B(KeyEvent keyEvent) {
        return h0() && this.u0.a0(keyEvent);
    }

    public void G() {
        C0662d c0662d = this.u0;
        if (c0662d != null) {
            c0662d.e0();
        }
    }

    public boolean I() {
        C0662d c0662d = this.u0;
        return c0662d != null && c0662d.k0();
    }

    protected void N(AspectRatioFrameLayout aspectRatioFrameLayout, float f2) {
        if (aspectRatioFrameLayout != null) {
            aspectRatioFrameLayout.setAspectRatio(f2);
        }
    }

    public void P() {
        View view = this.m0;
        if (view instanceof GLSurfaceView) {
            ((GLSurfaceView) view).onPause();
        }
    }

    public void Q() {
        View view = this.m0;
        if (view instanceof GLSurfaceView) {
            ((GLSurfaceView) view).onResume();
        }
    }

    public void V() {
        W(U());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        f fVar;
        super.dispatchDraw(canvas);
        if (Build.VERSION.SDK_INT == 34 && (fVar = this.o0) != null && this.Q0) {
            fVar.c();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        ax.P0.H h = this.B0;
        if (h != null && h.Z(16) && this.B0.j()) {
            return super.dispatchKeyEvent(keyEvent);
        }
        boolean zJ = J(keyEvent.getKeyCode());
        if (zJ && h0() && !this.u0.k0()) {
            M(true);
            return true;
        }
        if (B(keyEvent) || super.dispatchKeyEvent(keyEvent)) {
            M(true);
            return true;
        }
        if (zJ && h0()) {
            M(true);
        }
        return false;
    }

    public List<C1355a> getAdOverlayInfos() {
        ArrayList arrayList = new ArrayList();
        FrameLayout frameLayout = this.w0;
        if (frameLayout != null) {
            arrayList.add(new C1355a.C0171a(frameLayout, 4).b("Transparent overlay does not impact viewability").a());
        }
        C0662d c0662d = this.u0;
        if (c0662d != null) {
            arrayList.add(new C1355a.C0171a(c0662d, 1).a());
        }
        return AbstractC1656z.u(arrayList);
    }

    public ViewGroup getAdViewGroup() {
        return (ViewGroup) C1498a.j(this.v0, "exo_ad_overlay must be present for ad playback");
    }

    public int getArtworkDisplayMode() {
        return this.F0;
    }

    public boolean getControllerAutoShow() {
        return this.N0;
    }

    public boolean getControllerHideOnTouch() {
        return this.P0;
    }

    public int getControllerShowTimeoutMs() {
        return this.M0;
    }

    public Drawable getDefaultArtwork() {
        return this.H0;
    }

    public int getImageDisplayMode() {
        return this.G0;
    }

    public FrameLayout getOverlayFrameLayout() {
        return this.w0;
    }

    public ax.P0.H getPlayer() {
        return this.B0;
    }

    public int getResizeMode() {
        C1498a.i(this.k0);
        return this.k0.getResizeMode();
    }

    public SubtitleView getSubtitleView() {
        return this.r0;
    }

    @Deprecated
    public boolean getUseArtwork() {
        return this.F0 != 0;
    }

    public boolean getUseController() {
        return this.C0;
    }

    public View getVideoSurfaceView() {
        return this.m0;
    }

    @Override // android.view.View
    public boolean onTrackballEvent(MotionEvent motionEvent) {
        if (!h0() || this.B0 == null) {
            return false;
        }
        M(true);
        return true;
    }

    @Override // android.view.View
    public boolean performClick() {
        Y();
        return super.performClick();
    }

    public void setArtworkDisplayMode(int i) {
        C1498a.g(i == 0 || this.q0 != null);
        if (this.F0 != i) {
            this.F0 = i;
            e0(false);
        }
    }

    public void setAspectRatioListener(AspectRatioFrameLayout.b bVar) {
        C1498a.i(this.k0);
        this.k0.setAspectRatioListener(bVar);
    }

    public void setControllerAnimationEnabled(boolean z) {
        C1498a.i(this.u0);
        this.u0.setAnimationEnabled(z);
    }

    public void setControllerAutoShow(boolean z) {
        this.N0 = z;
    }

    public void setControllerHideDuringAds(boolean z) {
        this.O0 = z;
    }

    public void setControllerHideOnTouch(boolean z) {
        C1498a.i(this.u0);
        this.P0 = z;
        b0();
    }

    @Deprecated
    public void setControllerOnFullScreenModeChangedListener(C0662d.InterfaceC0031d interfaceC0031d) {
        C1498a.i(this.u0);
        this.u0.setOnFullScreenModeChangedListener(interfaceC0031d);
    }

    public void setControllerShowTimeoutMs(int i) {
        C1498a.i(this.u0);
        this.M0 = i;
        if (this.u0.k0()) {
            V();
        }
    }

    public void setControllerVisibilityListener(d dVar) {
        this.D0 = dVar;
        if (dVar != null) {
            setControllerVisibilityListener((C0662d.m) null);
        }
    }

    @Deprecated
    public void setControllerVisibilityListener(C0662d.m mVar) {
        C1498a.i(this.u0);
        C0662d.m mVar2 = this.E0;
        if (mVar2 == mVar) {
            return;
        }
        if (mVar2 != null) {
            this.u0.s0(mVar2);
        }
        this.E0 = mVar;
        if (mVar != null) {
            this.u0.Y(mVar);
            setControllerVisibilityListener((d) null);
        }
    }

    public void setCustomErrorMessage(CharSequence charSequence) {
        C1498a.g(this.t0 != null);
        this.L0 = charSequence;
        d0();
    }

    public void setDefaultArtwork(Drawable drawable) {
        if (this.H0 != drawable) {
            this.H0 = drawable;
            e0(false);
        }
    }

    public void setEnableComposeSurfaceSyncWorkaround(boolean z) {
        this.Q0 = z;
    }

    public void setErrorMessageProvider(InterfaceC1370p<? super ax.P0.F> interfaceC1370p) {
        if (this.K0 != interfaceC1370p) {
            this.K0 = interfaceC1370p;
            d0();
        }
    }

    public void setFullscreenButtonClickListener(e eVar) {
        C1498a.i(this.u0);
        this.u0.setOnFullScreenModeChangedListener(this.q);
    }

    public void setFullscreenButtonState(boolean z) {
        C1498a.i(this.u0);
        this.u0.B0(z);
    }

    public void setImageDisplayMode(int i) {
        C1498a.g(this.p0 != null);
        if (this.G0 != i) {
            this.G0 = i;
            f0();
        }
    }

    public void setKeepContentOnPlayerReset(boolean z) {
        if (this.J0 != z) {
            this.J0 = z;
            e0(false);
        }
    }

    public void setPlayer(ax.P0.H h) {
        C1498a.g(Looper.myLooper() == Looper.getMainLooper());
        C1498a.a(h == null || h.g0() == Looper.getMainLooper());
        ax.P0.H h2 = this.B0;
        if (h2 == h) {
            return;
        }
        if (h2 != null) {
            h2.k(this.q);
            if (h2.Z(27)) {
                View view = this.m0;
                if (view instanceof TextureView) {
                    h2.x((TextureView) view);
                } else if (view instanceof SurfaceView) {
                    h2.a0((SurfaceView) view);
                }
            }
            x(h2);
        }
        SubtitleView subtitleView = this.r0;
        if (subtitleView != null) {
            subtitleView.setCues(null);
        }
        this.B0 = h;
        if (h0()) {
            this.u0.setPlayer(h);
        }
        a0();
        d0();
        e0(true);
        if (h == null) {
            G();
            return;
        }
        if (h.Z(27)) {
            View view2 = this.m0;
            if (view2 instanceof TextureView) {
                h.n0((TextureView) view2);
            } else if (view2 instanceof SurfaceView) {
                h.E((SurfaceView) view2);
            }
            if (!h.Z(30) || h.S().d(2)) {
                Z();
            }
        }
        if (this.r0 != null && h.Z(28)) {
            this.r0.setCues(h.U().a);
        }
        h.G(this.q);
        setImageOutput(h);
        M(false);
    }

    public void setRepeatToggleModes(int i) {
        C1498a.i(this.u0);
        this.u0.setRepeatToggleModes(i);
    }

    public void setResizeMode(int i) {
        C1498a.i(this.k0);
        this.k0.setResizeMode(i);
    }

    public void setShowBuffering(int i) {
        if (this.I0 != i) {
            this.I0 = i;
            a0();
        }
    }

    public void setShowFastForwardButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowFastForwardButton(z);
    }

    @Deprecated
    public void setShowMultiWindowTimeBar(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowMultiWindowTimeBar(z);
    }

    public void setShowNextButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowNextButton(z);
    }

    public void setShowPlayButtonIfPlaybackIsSuppressed(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowPlayButtonIfPlaybackIsSuppressed(z);
    }

    public void setShowPreviousButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowPreviousButton(z);
    }

    public void setShowRewindButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowRewindButton(z);
    }

    public void setShowShuffleButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowShuffleButton(z);
    }

    public void setShowSubtitleButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowSubtitleButton(z);
    }

    public void setShowVrButton(boolean z) {
        C1498a.i(this.u0);
        this.u0.setShowVrButton(z);
    }

    public void setShutterBackgroundColor(int i) {
        View view = this.l0;
        if (view != null) {
            view.setBackgroundColor(i);
        }
    }

    public void setTimeBarScrubbingEnabled(boolean z) {
        C1498a.i(this.u0);
        this.u0.setTimeBarScrubbingEnabled(z);
    }

    @Deprecated
    public void setUseArtwork(boolean z) {
        setArtworkDisplayMode(!z ? 1 : 0);
    }

    public void setUseController(boolean z) {
        boolean z2 = true;
        C1498a.g((z && this.u0 == null) ? false : true);
        if (!z && !hasOnClickListeners()) {
            z2 = false;
        }
        setClickable(z2);
        if (this.C0 == z) {
            return;
        }
        this.C0 = z;
        if (h0()) {
            this.u0.setPlayer(this.B0);
        } else {
            C0662d c0662d = this.u0;
            if (c0662d != null) {
                c0662d.e0();
                this.u0.setPlayer(null);
            }
        }
        b0();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        View view = this.m0;
        if (view instanceof SurfaceView) {
            view.setVisibility(i);
        }
    }
}
