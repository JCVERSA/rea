package androidx.media3.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ax.P0.C1357c;
import ax.P0.C1368n;
import ax.P0.C1375v;
import ax.P0.C1378y;
import ax.P0.C1379z;
import ax.P0.I;
import ax.P0.N;
import ax.P0.P;
import ax.P0.Q;
import ax.P0.T;
import ax.P0.V;
import ax.P0.a0;
import ax.S0.C1498a;
import ax.S0.C1517u;
import ax.S0.d0;
import ax.Y7.AbstractC1656z;
import ax.p005a2.C1767f;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: renamed from: androidx.media3.ui.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0662d extends FrameLayout {
    private static final float[] N1;
    private final int A0;
    private boolean A1;
    private final ImageView B0;
    private boolean B1;
    private final ImageView C0;
    private boolean C1;
    private final ImageView D0;
    private int D1;
    private final View E0;
    private boolean E1;
    private final View F0;
    private int F1;
    private final TextView G0;
    private int G1;
    private final TextView H0;
    private long[] H1;
    private final ImageView I0;
    private boolean[] I1;
    private final ImageView J0;
    private long[] J1;
    private final ImageView K0;
    private boolean[] K1;
    private final ImageView L0;
    private long L1;
    private final ImageView M0;
    private boolean M1;
    private final ImageView N0;
    private final View O0;
    private final View P0;
    private final View Q0;
    private final TextView R0;
    private final TextView S0;
    private final G T0;
    private final StringBuilder U0;
    private final Formatter V0;
    private final N.b W0;
    private final N.c X0;
    private final Runnable Y0;
    private final Drawable Z0;
    private final Drawable a1;
    private final Drawable b1;
    private final Drawable c1;
    private final Drawable d1;
    private final String e1;
    private final String f1;
    private final String g1;
    private final Drawable h1;
    private final Drawable i1;
    private final float j1;
    private final Resources k0;
    private final float k1;
    private final c l0;
    private final String l1;
    private final Class<?> m0;
    private final String m1;
    private final Method n0;
    private final Drawable n1;
    private final Method o0;
    private final Drawable o1;
    private final Class<?> p0;
    private final String p1;
    private final w q;
    private final Method q0;
    private final String q1;
    private final Method r0;
    private final Drawable r1;
    private final CopyOnWriteArrayList<m> s0;
    private final Drawable s1;
    private final RecyclerView t0;
    private final String t1;
    private final h u0;
    private final String u1;
    private final e v0;
    private ax.P0.H v1;
    private final j w0;
    private InterfaceC0031d w1;
    private final b x0;
    private boolean x1;
    private final ax.p005a2.G y0;
    private boolean y1;
    private final PopupWindow z0;
    private boolean z1;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$b */
    final class b extends l {
        private b() {
            super();
        }

        public static /* synthetic */ void T(b bVar, View view) {
            if (C0662d.this.v1 == null || !C0662d.this.v1.Z(29)) {
                return;
            }
            ((ax.P0.H) d0.i(C0662d.this.v1)).p(C0662d.this.v1.i0().I().G(1).U(1, false).F());
            C0662d.this.u0.Q(1, C0662d.this.getResources().getString(ax.p005a2.D.w));
            C0662d.this.z0.dismiss();
        }

        private boolean U(T t) {
            for (int i = 0; i < this.d.size(); i++) {
                if (t.D.containsKey(this.d.get(i).a.a())) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.media3.ui.C0662d.l
        public void Q(i iVar) {
            iVar.u.setText(ax.p005a2.D.w);
            iVar.v.setVisibility(U(((ax.P0.H) C1498a.e(C0662d.this.v1)).i0()) ? 4 : 0);
            iVar.a.setOnClickListener(new View.OnClickListener() { // from class: androidx.media3.ui.e
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    C0662d.b.T(this.q, view);
                }
            });
        }

        @Override // androidx.media3.ui.C0662d.l
        public void S(String str) {
            C0662d.this.u0.Q(1, str);
        }

        public void V(List<k> list) {
            this.d = list;
            T tI0 = ((ax.P0.H) C1498a.e(C0662d.this.v1)).i0();
            if (list.isEmpty()) {
                C0662d.this.u0.Q(1, C0662d.this.getResources().getString(ax.p005a2.D.x));
                return;
            }
            if (!U(tI0)) {
                C0662d.this.u0.Q(1, C0662d.this.getResources().getString(ax.p005a2.D.w));
                return;
            }
            for (int i = 0; i < list.size(); i++) {
                k kVar = list.get(i);
                if (kVar.a()) {
                    C0662d.this.u0.Q(1, kVar.c);
                    return;
                }
            }
        }
    }

    /* JADX INFO: renamed from: androidx.media3.ui.d$c */
    private final class c implements ax.P0.H.d, G.a, View.OnClickListener, PopupWindow.OnDismissListener {
        private c() {
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void B(ax.P0.C c) {
            I.n(this, c);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void C(ax.R0.c cVar) {
            I.d(this, cVar);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void D(List list) {
            I.e(this, list);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void K0(int i) {
            I.y(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void M(int i) {
            I.r(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void N(boolean z) {
            I.k(this, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void O(int i) {
            I.v(this, i);
        }

        @Override // androidx.media3.ui.G.a
        public void P(G g, long j) {
            C0662d.this.C1 = true;
            if (C0662d.this.S0 != null) {
                C0662d.this.S0.setText(d0.q0(C0662d.this.U0, C0662d.this.V0, j));
            }
            C0662d.this.q.R();
            if (C0662d.this.v1 == null || !C0662d.this.E1) {
                return;
            }
            C0662d c0662d = C0662d.this;
            if (c0662d.j0(c0662d.v1)) {
                try {
                    ((Method) C1498a.e(C0662d.this.n0)).invoke(C0662d.this.v1, Boolean.TRUE);
                    return;
                } catch (IllegalAccessException | InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }
            C0662d c0662d2 = C0662d.this;
            if (c0662d2.i0(c0662d2.v1)) {
                try {
                    ((Method) C1498a.e(C0662d.this.q0)).invoke(C0662d.this.v1, Boolean.TRUE);
                } catch (IllegalAccessException | InvocationTargetException e2) {
                    throw new RuntimeException(e2);
                }
            } else {
                C1517u.h("PlayerControlView", "Time bar scrubbing is enabled, but player is not an ExoPlayer or CompositionPlayer instance, so ignoring (because we can't enable scrubbing mode). player.class=" + ((ax.P0.H) C1498a.e(C0662d.this.v1)).getClass());
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void Q(V v) {
            I.E(this, v);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void R(boolean z) {
            I.i(this, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void S(ax.P0.F f) {
            I.t(this, f);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void T(float f) {
            I.G(this, f);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void U(ax.P0.F f) {
            I.s(this, f);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void V(int i) {
            I.q(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void X(N n, int i) {
            I.C(this, n, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void Z(boolean z) {
            I.z(this, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void a(a0 a0Var) {
            I.F(this, a0Var);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void b0(T t) {
            I.D(this, t);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void c(int i) {
            I.b(this, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void c0(ax.P0.H.b bVar) {
            I.c(this, bVar);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void d(boolean z) {
            I.A(this, z);
        }

        @Override // androidx.media3.ui.G.a
        public void d0(G g, long j) {
            if (C0662d.this.S0 != null) {
                C0662d.this.S0.setText(d0.q0(C0662d.this.U0, C0662d.this.V0, j));
            }
            C0662d c0662d = C0662d.this;
            if (c0662d.m0(c0662d.v1)) {
                C0662d c0662d2 = C0662d.this;
                c0662d2.u0(c0662d2.v1, j);
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void e0(int i, boolean z) {
            I.g(this, i, z);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void f0(boolean z, int i) {
            I.u(this, z, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void g0(C1378y c1378y, int i) {
            I.l(this, c1378y, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void h0() {
            I.x(this);
        }

        @Override // ax.P0.H.d
        public void i0(ax.P0.H h, ax.P0.H.c cVar) {
            if (cVar.a(4, 5, 13)) {
                C0662d.this.D0();
            }
            if (cVar.a(4, 5, 7, 13)) {
                C0662d.this.F0();
            }
            if (cVar.a(8, 13)) {
                C0662d.this.G0();
            }
            if (cVar.a(9, 13)) {
                C0662d.this.K0();
            }
            if (cVar.a(8, 9, 11, 0, 16, 17, 13)) {
                C0662d.this.C0();
            }
            if (cVar.a(11, 0, 13)) {
                C0662d.this.L0();
            }
            if (cVar.a(12, 13)) {
                C0662d.this.E0();
            }
            if (cVar.a(2, 13)) {
                C0662d.this.M0();
            }
        }

        @Override // androidx.media3.ui.G.a
        public void l0(G g, long j, boolean z) {
            C0662d.this.C1 = false;
            if (C0662d.this.v1 != null) {
                if (!z) {
                    C0662d c0662d = C0662d.this;
                    c0662d.u0(c0662d.v1, j);
                }
                C0662d c0662d2 = C0662d.this;
                if (c0662d2.j0(c0662d2.v1)) {
                    try {
                        ((Method) C1498a.e(C0662d.this.n0)).invoke(C0662d.this.v1, Boolean.FALSE);
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    C0662d c0662d3 = C0662d.this;
                    if (c0662d3.i0(c0662d3.v1)) {
                        try {
                            ((Method) C1498a.e(C0662d.this.q0)).invoke(C0662d.this.v1, Boolean.FALSE);
                        } catch (IllegalAccessException | InvocationTargetException e2) {
                            throw new RuntimeException(e2);
                        }
                    }
                }
            }
            C0662d.this.q.S();
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void m0(boolean z, int i) {
            I.o(this, z, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void n0(ax.P0.A a) {
            I.m(this, a);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void o0(C1368n c1368n) {
            I.f(this, c1368n);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ax.P0.H h = C0662d.this.v1;
            if (h == null) {
                return;
            }
            C0662d.this.q.S();
            if (C0662d.this.C0 == view) {
                if (h.Z(9)) {
                    h.l0();
                    return;
                }
                return;
            }
            if (C0662d.this.B0 == view) {
                if (h.Z(7)) {
                    h.L();
                    return;
                }
                return;
            }
            if (C0662d.this.E0 == view) {
                if (h.V() == 4 || !h.Z(12)) {
                    return;
                }
                h.m0();
                return;
            }
            if (C0662d.this.F0 == view) {
                if (h.Z(11)) {
                    h.p0();
                    return;
                }
                return;
            }
            if (C0662d.this.D0 == view) {
                d0.B0(h, C0662d.this.A1);
                return;
            }
            if (C0662d.this.I0 == view) {
                if (h.Z(15)) {
                    h.X(ax.S0.H.a(h.o0(), C0662d.this.G1));
                    return;
                }
                return;
            }
            if (C0662d.this.J0 == view) {
                if (h.Z(14)) {
                    h.s(!h.h0());
                    return;
                }
                return;
            }
            if (C0662d.this.O0 == view) {
                C0662d.this.q.R();
                C0662d c0662d = C0662d.this;
                c0662d.b0(c0662d.u0, C0662d.this.O0);
                return;
            }
            if (C0662d.this.P0 == view) {
                C0662d.this.q.R();
                C0662d c0662d2 = C0662d.this;
                c0662d2.b0(c0662d2.v0, C0662d.this.P0);
            } else if (C0662d.this.Q0 == view) {
                C0662d.this.q.R();
                C0662d c0662d3 = C0662d.this;
                c0662d3.b0(c0662d3.x0, C0662d.this.Q0);
            } else if (C0662d.this.L0 == view) {
                C0662d.this.q.R();
                C0662d c0662d4 = C0662d.this;
                c0662d4.b0(c0662d4.w0, C0662d.this.L0);
            }
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            if (C0662d.this.M1) {
                C0662d.this.q.S();
            }
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void q0(int i, int i2) {
            I.B(this, i, i2);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void r0(ax.P0.H.e eVar, ax.P0.H.e eVar2, int i) {
            I.w(this, eVar, eVar2, i);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void s0(C1357c c1357c) {
            I.a(this, c1357c);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void t(ax.P0.G g) {
            I.p(this, g);
        }

        @Override // ax.P0.H.d
        public /* synthetic */ void t0(boolean z) {
            I.j(this, z);
        }
    }

    /* JADX INFO: renamed from: androidx.media3.ui.d$d, reason: collision with other inner class name */
    @Deprecated
    public interface InterfaceC0031d {
        void P(boolean z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$e */
    final class e extends RecyclerView.h<i> {
        private final String[] d;
        private final float[] e;
        private int f;

        public e(String[] strArr, float[] fArr) {
            this.d = strArr;
            this.e = fArr;
        }

        public static /* synthetic */ void N(e eVar, int i, View view) {
            if (i != eVar.f) {
                C0662d.this.setPlaybackSpeed(eVar.e[i]);
            }
            C0662d.this.z0.dismiss();
        }

        public String O() {
            return this.d[this.f];
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: P, reason: merged with bridge method [inline-methods] */
        public void B(i iVar, final int i) {
            String[] strArr = this.d;
            if (i < strArr.length) {
                iVar.u.setText(strArr[i]);
            }
            if (i == this.f) {
                iVar.a.setSelected(true);
                iVar.v.setVisibility(0);
            } else {
                iVar.a.setSelected(false);
                iVar.v.setVisibility(4);
            }
            iVar.a.setOnClickListener(new View.OnClickListener() { // from class: androidx.media3.ui.f
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    C0662d.e.N(this.q, i, view);
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
        public i D(ViewGroup viewGroup, int i) {
            return new i(LayoutInflater.from(C0662d.this.getContext()).inflate(ax.p005a2.B.f, viewGroup, false));
        }

        public void R(float f) {
            int i = 0;
            int i2 = 0;
            float f2 = Float.MAX_VALUE;
            while (true) {
                float[] fArr = this.e;
                if (i >= fArr.length) {
                    this.f = i2;
                    return;
                }
                float fAbs = Math.abs(f - fArr[i]);
                if (fAbs < f2) {
                    i2 = i;
                    f2 = fAbs;
                }
                i++;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        public int l() {
            return this.d.length;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.ui.d$f */
    public interface f {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$g */
    final class g extends RecyclerView.F {
        private final TextView u;
        private final TextView v;
        private final ImageView w;

        public g(View view) {
            super(view);
            if (Build.VERSION.SDK_INT < 26) {
                view.setFocusable(true);
            }
            this.u = (TextView) view.findViewById(ax.p005a2.z.v);
            this.v = (TextView) view.findViewById(ax.p005a2.z.O);
            this.w = (ImageView) view.findViewById(ax.p005a2.z.t);
            view.setOnClickListener(new View.OnClickListener() { // from class: androidx.media3.ui.g
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    C0662d.g gVar = this.q;
                    C0662d.this.r0(gVar.k());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$h */
    class h extends RecyclerView.h<g> {
        private final String[] d;
        private final String[] e;
        private final Drawable[] f;

        public h(String[] strArr, Drawable[] drawableArr) {
            this.d = strArr;
            this.e = new String[strArr.length];
            this.f = drawableArr;
        }

        private boolean R(int i) {
            if (C0662d.this.v1 == null) {
                return false;
            }
            if (i == 0) {
                return C0662d.this.v1.Z(13);
            }
            if (i != 1) {
                return true;
            }
            return C0662d.this.v1.Z(30) && C0662d.this.v1.Z(29);
        }

        public boolean N() {
            return R(1) || R(0);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: O, reason: merged with bridge method [inline-methods] */
        public void B(g gVar, int i) {
            if (R(i)) {
                gVar.a.setLayoutParams(new RecyclerView.q(-1, -2));
            } else {
                gVar.a.setLayoutParams(new RecyclerView.q(0, 0));
            }
            gVar.u.setText(this.d[i]);
            if (this.e[i] == null) {
                gVar.v.setVisibility(8);
            } else {
                gVar.v.setText(this.e[i]);
            }
            if (this.f[i] == null) {
                gVar.w.setVisibility(8);
            } else {
                gVar.w.setImageDrawable(this.f[i]);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: P, reason: merged with bridge method [inline-methods] */
        public g D(ViewGroup viewGroup, int i) {
            return C0662d.this.new g(LayoutInflater.from(C0662d.this.getContext()).inflate(ax.p005a2.B.e, viewGroup, false));
        }

        public void Q(int i, String str) {
            this.e[i] = str;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        public int l() {
            return this.d.length;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        public long m(int i) {
            return i;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.ui.d$i */
    private static class i extends RecyclerView.F {
        public final TextView u;
        public final View v;

        public i(View view) {
            super(view);
            if (Build.VERSION.SDK_INT < 26) {
                view.setFocusable(true);
            }
            this.u = (TextView) view.findViewById(ax.p005a2.z.R);
            this.v = view.findViewById(ax.p005a2.z.h);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$j */
    final class j extends l {
        private j() {
            super();
        }

        public static /* synthetic */ void T(j jVar, View view) {
            if (C0662d.this.v1 == null || !C0662d.this.v1.Z(29)) {
                return;
            }
            C0662d.this.v1.p(C0662d.this.v1.i0().I().G(3).M(-3).Q(null).S(0).F());
            C0662d.this.z0.dismiss();
        }

        @Override // androidx.media3.ui.C0662d.l, androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: P, reason: merged with bridge method [inline-methods] */
        public void B(i iVar, int i) {
            super.B(iVar, i);
            if (i > 0) {
                iVar.v.setVisibility(this.d.get(i + (-1)).a() ? 0 : 4);
            }
        }

        @Override // androidx.media3.ui.C0662d.l
        public void Q(i iVar) {
            boolean z;
            iVar.u.setText(ax.p005a2.D.x);
            int i = 0;
            while (true) {
                if (i >= this.d.size()) {
                    z = true;
                    break;
                } else {
                    if (this.d.get(i).a()) {
                        z = false;
                        break;
                    }
                    i++;
                }
            }
            iVar.v.setVisibility(z ? 0 : 4);
            iVar.a.setOnClickListener(new View.OnClickListener() { // from class: androidx.media3.ui.h
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    C0662d.j.T(this.q, view);
                }
            });
        }

        @Override // androidx.media3.ui.C0662d.l
        public void S(String str) {
        }

        public void U(List<k> list) {
            boolean z = false;
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).a()) {
                    z = true;
                    break;
                }
            }
            if (C0662d.this.L0 != null) {
                ImageView imageView = C0662d.this.L0;
                C0662d c0662d = C0662d.this;
                imageView.setImageDrawable(z ? c0662d.n1 : c0662d.o1);
                C0662d.this.L0.setContentDescription(z ? C0662d.this.p1 : C0662d.this.q1);
            }
            this.d = list;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$k */
    static final class k {
        public final V.a a;
        public final int b;
        public final String c;

        public k(V v, int i, int i2, String str) {
            this.a = v.a().get(i);
            this.b = i2;
            this.c = str;
        }

        public boolean a() {
            return this.a.i(this.b);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.ui.d$l */
    abstract class l extends RecyclerView.h<i> {
        protected List<k> d = new ArrayList();

        protected l() {
        }

        public static /* synthetic */ void N(l lVar, ax.P0.H h, P p, k kVar, View view) {
            lVar.getClass();
            if (h.Z(29)) {
                h.p(h.i0().I().N(new Q(p, AbstractC1656z.z(Integer.valueOf(kVar.b)))).U(kVar.a.d(), false).F());
                lVar.S(kVar.c);
                C0662d.this.z0.dismiss();
            }
        }

        protected void O() {
            this.d = Collections.EMPTY_LIST;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: P */
        public void B(i iVar, int i) {
            final ax.P0.H h = C0662d.this.v1;
            if (h == null) {
                return;
            }
            if (i == 0) {
                Q(iVar);
                return;
            }
            final k kVar = this.d.get(i - 1);
            final P pA = kVar.a.a();
            boolean z = h.i0().D.get(pA) != null && kVar.a();
            iVar.u.setText(kVar.c);
            iVar.v.setVisibility(z ? 0 : 4);
            iVar.a.setOnClickListener(new View.OnClickListener() { // from class: androidx.media3.ui.i
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    C0662d.l.N(this.q, h, pA, kVar, view);
                }
            });
        }

        protected abstract void Q(i iVar);

        @Override // androidx.recyclerview.widget.RecyclerView.h
        /* JADX INFO: renamed from: R, reason: merged with bridge method [inline-methods] */
        public i D(ViewGroup viewGroup, int i) {
            return new i(LayoutInflater.from(C0662d.this.getContext()).inflate(ax.p005a2.B.f, viewGroup, false));
        }

        protected abstract void S(String str);

        @Override // androidx.recyclerview.widget.RecyclerView.h
        public int l() {
            if (this.d.isEmpty()) {
                return 0;
            }
            return this.d.size() + 1;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.ui.d$m */
    @Deprecated
    public interface m {
        void d0(int i);
    }

    static {
        C1379z.a("media3.ui");
        N1 = new float[]{0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f};
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Code duplicated, block: B:102:0x044a  */
    /* JADX WARN: Code duplicated, block: B:105:0x045b  */
    /* JADX WARN: Code duplicated, block: B:108:0x0482  */
    /* JADX WARN: Code duplicated, block: B:111:0x04f8  */
    /* JADX WARN: Code duplicated, block: B:112:0x0502  */
    /* JADX WARN: Code duplicated, block: B:115:0x0647  */
    /* JADX WARN: Code duplicated, block: B:116:0x0649  */
    /* JADX WARN: Code duplicated, block: B:52:0x028c  */
    /* JADX WARN: Code duplicated, block: B:55:0x02bf  */
    /* JADX WARN: Code duplicated, block: B:58:0x02ce  */
    /* JADX WARN: Code duplicated, block: B:61:0x02dd  */
    /* JADX WARN: Code duplicated, block: B:64:0x02f2  */
    /* JADX WARN: Code duplicated, block: B:65:0x030f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:66:0x0311  */
    /* JADX WARN: Code duplicated, block: B:67:0x035e  */
    /* JADX WARN: Code duplicated, block: B:70:0x037e  */
    /* JADX WARN: Code duplicated, block: B:73:0x0395  */
    /* JADX WARN: Code duplicated, block: B:76:0x03a6  */
    /* JADX WARN: Code duplicated, block: B:79:0x03be  */
    /* JADX WARN: Code duplicated, block: B:82:0x03e2  */
    /* JADX WARN: Code duplicated, block: B:83:0x03ef  */
    /* JADX WARN: Code duplicated, block: B:85:0x03f2  */
    /* JADX WARN: Code duplicated, block: B:86:0x03fa  */
    /* JADX WARN: Code duplicated, block: B:89:0x0402  */
    /* JADX WARN: Code duplicated, block: B:92:0x0419  */
    /* JADX WARN: Code duplicated, block: B:93:0x0426  */
    /* JADX WARN: Code duplicated, block: B:95:0x0429  */
    /* JADX WARN: Code duplicated, block: B:96:0x0431  */
    /* JADX WARN: Code duplicated, block: B:99:0x0439  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v7, types: [androidx.media3.ui.G] */
    /* JADX WARN: Unreachable blocks removed: 1, instructions: 3 */
    public C0662d(Context context, AttributeSet attributeSet, int i2, AttributeSet attributeSet2) throws Throwable {
        final C0662d c0662d;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        boolean z8;
        String str;
        Method method;
        Method method2;
        Method method3;
        Method method4;
        Class<?> cls;
        Method method5;
        ImageView imageView;
        View viewFindViewById;
        View viewFindViewById2;
        View viewFindViewById3;
        int i18;
        G g2;
        View viewFindViewById4;
        Context context2;
        final C0662d c0662d2;
        char c2;
        G g3;
        Resources resources;
        ImageView imageView2;
        ImageView imageView3;
        ImageView imageView4;
        Typeface typefaceG;
        ImageView imageView5;
        TextView textView;
        View view;
        ImageView imageView6;
        TextView textView2;
        View view2;
        ImageView imageView7;
        ImageView imageView8;
        ImageView imageView9;
        PopupWindow popupWindow;
        boolean z9;
        super(context, attributeSet, i2);
        Class<?> cls2 = Boolean.TYPE;
        int i19 = ax.p005a2.B.b;
        int i20 = ax.p005a2.x.g;
        int i21 = ax.p005a2.x.f;
        int i22 = ax.p005a2.x.e;
        int i23 = ax.p005a2.x.n;
        int i24 = ax.p005a2.x.h;
        int resourceId = ax.p005a2.x.o;
        int i25 = ax.p005a2.x.d;
        int i26 = ax.p005a2.x.c;
        int i27 = ax.p005a2.x.j;
        int i28 = ax.p005a2.x.k;
        int i29 = ax.p005a2.x.i;
        String str2 = "isScrubbingModeEnabled";
        int i30 = ax.p005a2.x.m;
        int i31 = ax.p005a2.x.l;
        int i32 = ax.p005a2.x.r;
        int resourceId2 = ax.p005a2.x.q;
        int i33 = ax.p005a2.x.s;
        this.A1 = true;
        this.D1 = 5000;
        this.G1 = 0;
        this.F1 = 200;
        if (attributeSet2 != null) {
            TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet2, ax.p005a2.F.y, i2, 0);
            try {
                int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.A, i19);
                int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.G, i20);
                int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.F, i21);
                int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.E, i22);
                int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.B, i23);
                int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.H, i24);
                resourceId = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.M, resourceId);
                int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.D, i25);
                int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.C, i26);
                int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.J, i27);
                int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.K, i28);
                int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.I, i29);
                int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.W, i30);
                int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.V, i31);
                int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.Y, i32);
                resourceId2 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.X, resourceId2);
                int resourceId17 = typedArrayObtainStyledAttributes.getResourceId(ax.p005a2.F.b0, i33);
                c0662d = this;
                try {
                    c0662d.D1 = typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.T, c0662d.D1);
                    c0662d.G1 = d0(typedArrayObtainStyledAttributes, c0662d.G1);
                    boolean z10 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.Q, true);
                    boolean z11 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.N, true);
                    z5 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.P, true);
                    boolean z12 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.O, true);
                    boolean z13 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.R, false);
                    boolean z14 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.S, false);
                    boolean z15 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.U, false);
                    c0662d.E1 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.a0, false);
                    c0662d.setTimeBarMinUpdateInterval(typedArrayObtainStyledAttributes.getInt(ax.p005a2.F.Z, c0662d.F1));
                    boolean z16 = typedArrayObtainStyledAttributes.getBoolean(ax.p005a2.F.z, true);
                    typedArrayObtainStyledAttributes.recycle();
                    i4 = resourceId7;
                    i5 = resourceId9;
                    i6 = resourceId8;
                    i7 = resourceId10;
                    z6 = z10;
                    z3 = z13;
                    z7 = z11;
                    z4 = z12;
                    z8 = z16;
                    i12 = resourceId11;
                    i13 = resourceId6;
                    i14 = resourceId12;
                    i15 = resourceId5;
                    i16 = resourceId4;
                    i17 = resourceId3;
                    z = z15;
                    i10 = resourceId13;
                    i8 = resourceId16;
                    i3 = resourceId15;
                    i11 = resourceId17;
                    z2 = z14;
                    i9 = resourceId14;
                } catch (Throwable th) {
                    th = th;
                    typedArrayObtainStyledAttributes.recycle();
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } else {
            c0662d = this;
            i3 = i31;
            i4 = i23;
            i5 = i25;
            i6 = i24;
            i7 = i26;
            i8 = i32;
            i9 = i30;
            i10 = i29;
            z = false;
            z2 = false;
            z3 = false;
            z4 = true;
            z5 = true;
            z6 = true;
            z7 = true;
            i11 = i33;
            i12 = i27;
            i13 = i22;
            i14 = i28;
            i15 = i21;
            i16 = i20;
            i17 = i19;
            z8 = true;
        }
        LayoutInflater.from(context).inflate(i17, c0662d);
        c0662d.setDescendantFocusability(262144);
        c0662d.l0 = new c();
        c0662d.s0 = new CopyOnWriteArrayList<>();
        c0662d.W0 = new N.b();
        c0662d.X0 = new N.c();
        StringBuilder sb = new StringBuilder();
        c0662d.U0 = sb;
        int i34 = i11;
        c0662d.V0 = new Formatter(sb, Locale.getDefault());
        c0662d.H1 = new long[0];
        c0662d.I1 = new boolean[0];
        c0662d.J1 = new long[0];
        c0662d.K1 = new boolean[0];
        c0662d.Y0 = new Runnable() { // from class: ax.a2.g
            @Override // java.lang.Runnable
            public final void run() {
                this.q.F0();
            }
        };
        try {
            str = "setScrubbingModeEnabled";
            try {
                try {
                    method = ExoPlayer.class.getMethod(str, cls2);
                    str2 = str2;
                    try {
                        method2 = ExoPlayer.class.getMethod(str2, null);
                    } catch (ClassNotFoundException | NoSuchMethodException unused) {
                        method2 = null;
                    }
                } catch (ClassNotFoundException | NoSuchMethodException unused2) {
                    method = null;
                    method2 = null;
                    Method method6 = method;
                    c0662d.m0 = ExoPlayer.class;
                    c0662d.n0 = method6;
                    c0662d.o0 = method2;
                    cls = Class.forName("androidx.media3.transformer.CompositionPlayer");
                    Class<?>[] clsArr = new Class[1];
                    try {
                        clsArr[0] = cls2;
                        try {
                            method4 = cls.getMethod(str, clsArr);
                            method3 = null;
                            try {
                                method5 = cls.getMethod(str2, null);
                            } catch (ClassNotFoundException | NoSuchMethodException unused3) {
                                method5 = method3;
                            }
                        } catch (ClassNotFoundException | NoSuchMethodException unused4) {
                            method3 = null;
                            method4 = method3;
                            method5 = method3;
                            c0662d.p0 = cls;
                            c0662d.q0 = method4;
                            c0662d.r0 = method5;
                            c0662d.R0 = (TextView) c0662d.findViewById(ax.p005a2.z.m);
                            c0662d.S0 = (TextView) c0662d.findViewById(ax.p005a2.z.E);
                            imageView = (ImageView) c0662d.findViewById(ax.p005a2.z.P);
                            c0662d.L0 = imageView;
                            if (imageView != null) {
                                imageView.setOnClickListener(c0662d.l0);
                            }
                            ImageView imageView10 = (ImageView) c0662d.findViewById(ax.p005a2.z.s);
                            c0662d.M0 = imageView10;
                            h0(imageView10, new View.OnClickListener() { // from class: ax.a2.h
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view3) {
                                    this.q.p0(view3);
                                }
                            });
                            ImageView imageView11 = (ImageView) c0662d.findViewById(ax.p005a2.z.x);
                            c0662d.N0 = imageView11;
                            h0(imageView11, new View.OnClickListener() { // from class: ax.a2.h
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view3) {
                                    this.q.p0(view3);
                                }
                            });
                            viewFindViewById = c0662d.findViewById(ax.p005a2.z.L);
                            c0662d.O0 = viewFindViewById;
                            if (viewFindViewById != null) {
                                viewFindViewById.setOnClickListener(c0662d.l0);
                            }
                            viewFindViewById2 = c0662d.findViewById(ax.p005a2.z.D);
                            c0662d.P0 = viewFindViewById2;
                            if (viewFindViewById2 != null) {
                                viewFindViewById2.setOnClickListener(c0662d.l0);
                            }
                            viewFindViewById3 = c0662d.findViewById(ax.p005a2.z.c);
                            c0662d.Q0 = viewFindViewById3;
                            if (viewFindViewById3 != null) {
                                viewFindViewById3.setOnClickListener(c0662d.l0);
                            }
                            i18 = ax.p005a2.z.G;
                            g2 = (G) c0662d.findViewById(i18);
                            viewFindViewById4 = c0662d.findViewById(ax.p005a2.z.H);
                            if (g2 != null) {
                                c0662d.T0 = g2;
                                context2 = context;
                                c0662d2 = c0662d;
                                c2 = 1;
                            } else if (viewFindViewById4 != null) {
                                context2 = context;
                                c0662d2 = this;
                                c2 = 1;
                                C0660b c0660b = new C0660b(context2, null, 0, attributeSet2, ax.p005a2.E.a);
                                c0660b.setId(i18);
                                c0660b.setLayoutParams(viewFindViewById4.getLayoutParams());
                                ViewGroup viewGroup = (ViewGroup) viewFindViewById4.getParent();
                                int iIndexOfChild = viewGroup.indexOfChild(viewFindViewById4);
                                viewGroup.removeView(viewFindViewById4);
                                viewGroup.addView(c0660b, iIndexOfChild);
                                c0662d2.T0 = c0660b;
                            } else {
                                context2 = context;
                                c0662d2 = c0662d;
                                c2 = 1;
                                c0662d2.T0 = method3;
                            }
                            g3 = c0662d2.T0;
                            if (g3 != null) {
                                g3.a(c0662d2.l0);
                            }
                            resources = context2.getResources();
                            c0662d2.k0 = resources;
                            imageView2 = (ImageView) c0662d2.findViewById(ax.p005a2.z.C);
                            c0662d2.D0 = imageView2;
                            if (imageView2 != null) {
                                imageView2.setOnClickListener(c0662d2.l0);
                            }
                            imageView3 = (ImageView) c0662d2.findViewById(ax.p005a2.z.F);
                            c0662d2.B0 = imageView3;
                            if (imageView3 != null) {
                                imageView3.setImageDrawable(d0.a0(context2, resources, i6));
                                imageView3.setOnClickListener(c0662d2.l0);
                            }
                            imageView4 = (ImageView) c0662d2.findViewById(ax.p005a2.z.y);
                            c0662d2.C0 = imageView4;
                            if (imageView4 != null) {
                                imageView4.setImageDrawable(d0.a0(context2, resources, i13));
                                imageView4.setOnClickListener(c0662d2.l0);
                            }
                            typefaceG = ax.S.h.g(context2, ax.p005a2.y.a);
                            imageView5 = (ImageView) c0662d2.findViewById(ax.p005a2.z.J);
                            textView = (TextView) c0662d2.findViewById(ax.p005a2.z.K);
                            if (imageView5 != null) {
                                imageView5.setImageDrawable(d0.a0(context2, resources, resourceId));
                                c0662d2.F0 = imageView5;
                                c0662d2.H0 = null;
                            } else if (textView != null) {
                                textView.setTypeface(typefaceG);
                                c0662d2.H0 = textView;
                                c0662d2.F0 = textView;
                            } else {
                                c0662d2.H0 = null;
                                c0662d2.F0 = null;
                            }
                            view = c0662d2.F0;
                            if (view != null) {
                                view.setOnClickListener(c0662d2.l0);
                            }
                            imageView6 = (ImageView) c0662d2.findViewById(ax.p005a2.z.q);
                            textView2 = (TextView) c0662d2.findViewById(ax.p005a2.z.r);
                            if (imageView6 != null) {
                                imageView6.setImageDrawable(d0.a0(context2, resources, i4));
                                c0662d2.E0 = imageView6;
                                c0662d2.G0 = null;
                            } else if (textView2 != null) {
                                textView2.setTypeface(typefaceG);
                                c0662d2.G0 = textView2;
                                c0662d2.E0 = textView2;
                            } else {
                                c0662d2.G0 = null;
                                c0662d2.E0 = null;
                            }
                            view2 = c0662d2.E0;
                            if (view2 != null) {
                                view2.setOnClickListener(c0662d2.l0);
                            }
                            imageView7 = (ImageView) c0662d2.findViewById(ax.p005a2.z.I);
                            c0662d2.I0 = imageView7;
                            if (imageView7 != null) {
                                imageView7.setOnClickListener(c0662d2.l0);
                            }
                            imageView8 = (ImageView) c0662d2.findViewById(ax.p005a2.z.M);
                            c0662d2.J0 = imageView8;
                            if (imageView8 != null) {
                                imageView8.setOnClickListener(c0662d2.l0);
                            }
                            c0662d2.j1 = resources.getInteger(ax.p005a2.A.b) / 100.0f;
                            c0662d2.k1 = resources.getInteger(ax.p005a2.A.a) / 100.0f;
                            imageView9 = (ImageView) c0662d2.findViewById(ax.p005a2.z.T);
                            c0662d2.K0 = imageView9;
                            if (imageView9 != null) {
                                imageView9.setImageDrawable(d0.a0(context2, resources, i34));
                                c0662d2.x0(false, imageView9);
                            }
                            w wVar = new w(c0662d2);
                            c0662d2.q = wVar;
                            wVar.T(z8);
                            String string = resources.getString(ax.p005a2.D.h);
                            Drawable drawableA0 = d0.a0(context2, resources, ax.p005a2.x.p);
                            String[] strArr = {string, resources.getString(ax.p005a2.D.y)};
                            Drawable drawableA1 = d0.a0(context2, resources, ax.p005a2.x.b);
                            Drawable[] drawableArr = new Drawable[2];
                            drawableArr[0] = drawableA0;
                            drawableArr[c2] = drawableA1;
                            h hVar = c0662d2.new h(strArr, drawableArr);
                            c0662d2.u0 = hVar;
                            c0662d2.A0 = resources.getDimensionPixelSize(ax.p005a2.w.a);
                            RecyclerView recyclerView = (RecyclerView) LayoutInflater.from(context2).inflate(ax.p005a2.B.d, (ViewGroup) null);
                            c0662d2.t0 = recyclerView;
                            recyclerView.setAdapter(hVar);
                            recyclerView.setLayoutManager(new LinearLayoutManager(c0662d2.getContext()));
                            popupWindow = new PopupWindow((View) recyclerView, -2, -2, true);
                            c0662d2.z0 = popupWindow;
                            if (Build.VERSION.SDK_INT < 23) {
                                popupWindow.setBackgroundDrawable(new ColorDrawable(0));
                            }
                            popupWindow.setOnDismissListener(c0662d2.l0);
                            c0662d2.M1 = true;
                            c0662d2.y0 = new C1767f(c0662d2.getResources());
                            c0662d2.n1 = d0.a0(context2, resources, i8);
                            c0662d2.o1 = d0.a0(context2, resources, resourceId2);
                            c0662d2.p1 = resources.getString(ax.p005a2.D.b);
                            c0662d2.q1 = resources.getString(ax.p005a2.D.a);
                            c0662d2.w0 = new j();
                            c0662d2.x0 = new b();
                            c0662d2.v0 = c0662d2.new e(c0662d2.k0.getStringArray(ax.p005a2.u.a), N1);
                            c0662d2.Z0 = d0.a0(context2, c0662d2.k0, i16);
                            c0662d2.a1 = d0.a0(context2, c0662d2.k0, i15);
                            c0662d2.r1 = d0.a0(context2, c0662d2.k0, i5);
                            c0662d2.s1 = d0.a0(context2, c0662d2.k0, i7);
                            c0662d2.b1 = d0.a0(context2, c0662d2.k0, i12);
                            c0662d2.c1 = d0.a0(context2, c0662d2.k0, i14);
                            c0662d2.d1 = d0.a0(context2, c0662d2.k0, i10);
                            c0662d2.h1 = d0.a0(context2, c0662d2.k0, i9);
                            c0662d2.i1 = d0.a0(context2, c0662d2.k0, i3);
                            c0662d2.t1 = c0662d2.k0.getString(ax.p005a2.D.d);
                            c0662d2.u1 = c0662d2.k0.getString(ax.p005a2.D.c);
                            c0662d2.e1 = c0662d2.k0.getString(ax.p005a2.D.j);
                            c0662d2.f1 = c0662d2.k0.getString(ax.p005a2.D.k);
                            c0662d2.g1 = c0662d2.k0.getString(ax.p005a2.D.i);
                            c0662d2.l1 = c0662d2.k0.getString(ax.p005a2.D.n);
                            c0662d2.m1 = c0662d2.k0.getString(ax.p005a2.D.m);
                            c0662d2.q.U((ViewGroup) c0662d2.findViewById(ax.p005a2.z.e), true);
                            c0662d2.q.U(c0662d2.E0, z7);
                            c0662d2.q.U(c0662d2.F0, z6);
                            c0662d2.q.U(c0662d2.B0, z5);
                            c0662d2.q.U(c0662d2.C0, z4);
                            c0662d2.q.U(c0662d2.J0, z3);
                            c0662d2.q.U(c0662d2.L0, z2);
                            c0662d2.q.U(c0662d2.K0, z);
                            w wVar2 = c0662d2.q;
                            ImageView imageView12 = c0662d2.I0;
                            if (c0662d2.G1 != 0) {
                                z9 = true;
                            } else {
                                z9 = false;
                            }
                            wVar2.U(imageView12, z9);
                            c0662d2.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: ax.a2.i
                                @Override // android.view.View.OnLayoutChangeListener
                                public final void onLayoutChange(View view3, int i35, int i36, int i37, int i38, int i39, int i40, int i41, int i42) {
                                    this.a.q0(view3, i35, i36, i37, i38, i39, i40, i41, i42);
                                }
                            });
                        }
                    } catch (ClassNotFoundException unused5) {
                        method3 = null;
                    } catch (NoSuchMethodException unused6) {
                        method3 = null;
                    }
                    c0662d.p0 = cls;
                    c0662d.q0 = method4;
                    c0662d.r0 = method5;
                    c0662d.R0 = (TextView) c0662d.findViewById(ax.p005a2.z.m);
                    c0662d.S0 = (TextView) c0662d.findViewById(ax.p005a2.z.E);
                    imageView = (ImageView) c0662d.findViewById(ax.p005a2.z.P);
                    c0662d.L0 = imageView;
                    if (imageView != null) {
                        imageView.setOnClickListener(c0662d.l0);
                    }
                    ImageView imageView13 = (ImageView) c0662d.findViewById(ax.p005a2.z.s);
                    c0662d.M0 = imageView13;
                    h0(imageView13, new View.OnClickListener() { // from class: ax.a2.h
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view3) {
                            this.q.p0(view3);
                        }
                    });
                    ImageView imageView14 = (ImageView) c0662d.findViewById(ax.p005a2.z.x);
                    c0662d.N0 = imageView14;
                    h0(imageView14, new View.OnClickListener() { // from class: ax.a2.h
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view3) {
                            this.q.p0(view3);
                        }
                    });
                    viewFindViewById = c0662d.findViewById(ax.p005a2.z.L);
                    c0662d.O0 = viewFindViewById;
                    if (viewFindViewById != null) {
                        viewFindViewById.setOnClickListener(c0662d.l0);
                    }
                    viewFindViewById2 = c0662d.findViewById(ax.p005a2.z.D);
                    c0662d.P0 = viewFindViewById2;
                    if (viewFindViewById2 != null) {
                        viewFindViewById2.setOnClickListener(c0662d.l0);
                    }
                    viewFindViewById3 = c0662d.findViewById(ax.p005a2.z.c);
                    c0662d.Q0 = viewFindViewById3;
                    if (viewFindViewById3 != null) {
                        viewFindViewById3.setOnClickListener(c0662d.l0);
                    }
                    i18 = ax.p005a2.z.G;
                    g2 = (G) c0662d.findViewById(i18);
                    viewFindViewById4 = c0662d.findViewById(ax.p005a2.z.H);
                    if (g2 != null) {
                        c0662d.T0 = g2;
                        context2 = context;
                        c0662d2 = c0662d;
                        c2 = 1;
                    } else if (viewFindViewById4 != null) {
                        context2 = context;
                        c0662d2 = this;
                        c2 = 1;
                        C0660b c0660b2 = new C0660b(context2, null, 0, attributeSet2, ax.p005a2.E.a);
                        c0660b2.setId(i18);
                        c0660b2.setLayoutParams(viewFindViewById4.getLayoutParams());
                        ViewGroup viewGroup2 = (ViewGroup) viewFindViewById4.getParent();
                        int iIndexOfChild2 = viewGroup2.indexOfChild(viewFindViewById4);
                        viewGroup2.removeView(viewFindViewById4);
                        viewGroup2.addView(c0660b2, iIndexOfChild2);
                        c0662d2.T0 = c0660b2;
                    } else {
                        context2 = context;
                        c0662d2 = c0662d;
                        c2 = 1;
                        c0662d2.T0 = method3;
                    }
                    g3 = c0662d2.T0;
                    if (g3 != null) {
                        g3.a(c0662d2.l0);
                    }
                    resources = context2.getResources();
                    c0662d2.k0 = resources;
                    imageView2 = (ImageView) c0662d2.findViewById(ax.p005a2.z.C);
                    c0662d2.D0 = imageView2;
                    if (imageView2 != null) {
                        imageView2.setOnClickListener(c0662d2.l0);
                    }
                    imageView3 = (ImageView) c0662d2.findViewById(ax.p005a2.z.F);
                    c0662d2.B0 = imageView3;
                    if (imageView3 != null) {
                        imageView3.setImageDrawable(d0.a0(context2, resources, i6));
                        imageView3.setOnClickListener(c0662d2.l0);
                    }
                    imageView4 = (ImageView) c0662d2.findViewById(ax.p005a2.z.y);
                    c0662d2.C0 = imageView4;
                    if (imageView4 != null) {
                        imageView4.setImageDrawable(d0.a0(context2, resources, i13));
                        imageView4.setOnClickListener(c0662d2.l0);
                    }
                    typefaceG = ax.S.h.g(context2, ax.p005a2.y.a);
                    imageView5 = (ImageView) c0662d2.findViewById(ax.p005a2.z.J);
                    textView = (TextView) c0662d2.findViewById(ax.p005a2.z.K);
                    if (imageView5 != null) {
                        imageView5.setImageDrawable(d0.a0(context2, resources, resourceId));
                        c0662d2.F0 = imageView5;
                        c0662d2.H0 = null;
                    } else if (textView != null) {
                        textView.setTypeface(typefaceG);
                        c0662d2.H0 = textView;
                        c0662d2.F0 = textView;
                    } else {
                        c0662d2.H0 = null;
                        c0662d2.F0 = null;
                    }
                    view = c0662d2.F0;
                    if (view != null) {
                        view.setOnClickListener(c0662d2.l0);
                    }
                    imageView6 = (ImageView) c0662d2.findViewById(ax.p005a2.z.q);
                    textView2 = (TextView) c0662d2.findViewById(ax.p005a2.z.r);
                    if (imageView6 != null) {
                        imageView6.setImageDrawable(d0.a0(context2, resources, i4));
                        c0662d2.E0 = imageView6;
                        c0662d2.G0 = null;
                    } else if (textView2 != null) {
                        textView2.setTypeface(typefaceG);
                        c0662d2.G0 = textView2;
                        c0662d2.E0 = textView2;
                    } else {
                        c0662d2.G0 = null;
                        c0662d2.E0 = null;
                    }
                    view2 = c0662d2.E0;
                    if (view2 != null) {
                        view2.setOnClickListener(c0662d2.l0);
                    }
                    imageView7 = (ImageView) c0662d2.findViewById(ax.p005a2.z.I);
                    c0662d2.I0 = imageView7;
                    if (imageView7 != null) {
                        imageView7.setOnClickListener(c0662d2.l0);
                    }
                    imageView8 = (ImageView) c0662d2.findViewById(ax.p005a2.z.M);
                    c0662d2.J0 = imageView8;
                    if (imageView8 != null) {
                        imageView8.setOnClickListener(c0662d2.l0);
                    }
                    c0662d2.j1 = resources.getInteger(ax.p005a2.A.b) / 100.0f;
                    c0662d2.k1 = resources.getInteger(ax.p005a2.A.a) / 100.0f;
                    imageView9 = (ImageView) c0662d2.findViewById(ax.p005a2.z.T);
                    c0662d2.K0 = imageView9;
                    if (imageView9 != null) {
                        imageView9.setImageDrawable(d0.a0(context2, resources, i34));
                        c0662d2.x0(false, imageView9);
                    }
                    w wVar3 = new w(c0662d2);
                    c0662d2.q = wVar3;
                    wVar3.T(z8);
                    String string2 = resources.getString(ax.p005a2.D.h);
                    Drawable drawableA2 = d0.a0(context2, resources, ax.p005a2.x.p);
                    String[] strArr2 = {string2, resources.getString(ax.p005a2.D.y)};
                    Drawable drawableA3 = d0.a0(context2, resources, ax.p005a2.x.b);
                    Drawable[] drawableArr2 = new Drawable[2];
                    drawableArr2[0] = drawableA2;
                    drawableArr2[c2] = drawableA3;
                    h hVar2 = c0662d2.new h(strArr2, drawableArr2);
                    c0662d2.u0 = hVar2;
                    c0662d2.A0 = resources.getDimensionPixelSize(ax.p005a2.w.a);
                    RecyclerView recyclerView2 = (RecyclerView) LayoutInflater.from(context2).inflate(ax.p005a2.B.d, (ViewGroup) null);
                    c0662d2.t0 = recyclerView2;
                    recyclerView2.setAdapter(hVar2);
                    recyclerView2.setLayoutManager(new LinearLayoutManager(c0662d2.getContext()));
                    popupWindow = new PopupWindow((View) recyclerView2, -2, -2, true);
                    c0662d2.z0 = popupWindow;
                    if (Build.VERSION.SDK_INT < 23) {
                        popupWindow.setBackgroundDrawable(new ColorDrawable(0));
                    }
                    popupWindow.setOnDismissListener(c0662d2.l0);
                    c0662d2.M1 = true;
                    c0662d2.y0 = new C1767f(c0662d2.getResources());
                    c0662d2.n1 = d0.a0(context2, resources, i8);
                    c0662d2.o1 = d0.a0(context2, resources, resourceId2);
                    c0662d2.p1 = resources.getString(ax.p005a2.D.b);
                    c0662d2.q1 = resources.getString(ax.p005a2.D.a);
                    c0662d2.w0 = new j();
                    c0662d2.x0 = new b();
                    c0662d2.v0 = c0662d2.new e(c0662d2.k0.getStringArray(ax.p005a2.u.a), N1);
                    c0662d2.Z0 = d0.a0(context2, c0662d2.k0, i16);
                    c0662d2.a1 = d0.a0(context2, c0662d2.k0, i15);
                    c0662d2.r1 = d0.a0(context2, c0662d2.k0, i5);
                    c0662d2.s1 = d0.a0(context2, c0662d2.k0, i7);
                    c0662d2.b1 = d0.a0(context2, c0662d2.k0, i12);
                    c0662d2.c1 = d0.a0(context2, c0662d2.k0, i14);
                    c0662d2.d1 = d0.a0(context2, c0662d2.k0, i10);
                    c0662d2.h1 = d0.a0(context2, c0662d2.k0, i9);
                    c0662d2.i1 = d0.a0(context2, c0662d2.k0, i3);
                    c0662d2.t1 = c0662d2.k0.getString(ax.p005a2.D.d);
                    c0662d2.u1 = c0662d2.k0.getString(ax.p005a2.D.c);
                    c0662d2.e1 = c0662d2.k0.getString(ax.p005a2.D.j);
                    c0662d2.f1 = c0662d2.k0.getString(ax.p005a2.D.k);
                    c0662d2.g1 = c0662d2.k0.getString(ax.p005a2.D.i);
                    c0662d2.l1 = c0662d2.k0.getString(ax.p005a2.D.n);
                    c0662d2.m1 = c0662d2.k0.getString(ax.p005a2.D.m);
                    c0662d2.q.U((ViewGroup) c0662d2.findViewById(ax.p005a2.z.e), true);
                    c0662d2.q.U(c0662d2.E0, z7);
                    c0662d2.q.U(c0662d2.F0, z6);
                    c0662d2.q.U(c0662d2.B0, z5);
                    c0662d2.q.U(c0662d2.C0, z4);
                    c0662d2.q.U(c0662d2.J0, z3);
                    c0662d2.q.U(c0662d2.L0, z2);
                    c0662d2.q.U(c0662d2.K0, z);
                    w wVar4 = c0662d2.q;
                    ImageView imageView15 = c0662d2.I0;
                    if (c0662d2.G1 != 0) {
                        z9 = true;
                    } else {
                        z9 = false;
                    }
                    wVar4.U(imageView15, z9);
                    c0662d2.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: ax.a2.i
                        @Override // android.view.View.OnLayoutChangeListener
                        public final void onLayoutChange(View view3, int i35, int i36, int i37, int i38, int i39, int i40, int i41, int i42) {
                            this.a.q0(view3, i35, i36, i37, i38, i39, i40, i41, i42);
                        }
                    });
                }
                cls = Class.forName("androidx.media3.transformer.CompositionPlayer");
                try {
                    Class<?>[] clsArr2 = new Class[1];
                    clsArr2[0] = cls2;
                    method4 = cls.getMethod(str, clsArr2);
                    method3 = null;
                    method5 = cls.getMethod(str2, null);
                } catch (ClassNotFoundException unused7) {
                    method3 = null;
                } catch (NoSuchMethodException unused8) {
                    method3 = null;
                }
            } catch (ClassNotFoundException | NoSuchMethodException unused9) {
                method3 = null;
                method4 = null;
                cls = null;
            }
        } catch (ClassNotFoundException | NoSuchMethodException unused10) {
            str = "setScrubbingModeEnabled";
        }
        Method method7 = method;
        c0662d.m0 = ExoPlayer.class;
        c0662d.n0 = method7;
        c0662d.o0 = method2;
        c0662d.p0 = cls;
        c0662d.q0 = method4;
        c0662d.r0 = method5;
        c0662d.R0 = (TextView) c0662d.findViewById(ax.p005a2.z.m);
        c0662d.S0 = (TextView) c0662d.findViewById(ax.p005a2.z.E);
        imageView = (ImageView) c0662d.findViewById(ax.p005a2.z.P);
        c0662d.L0 = imageView;
        if (imageView != null) {
            imageView.setOnClickListener(c0662d.l0);
        }
        ImageView imageView16 = (ImageView) c0662d.findViewById(ax.p005a2.z.s);
        c0662d.M0 = imageView16;
        h0(imageView16, new View.OnClickListener() { // from class: ax.a2.h
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                this.q.p0(view3);
            }
        });
        ImageView imageView17 = (ImageView) c0662d.findViewById(ax.p005a2.z.x);
        c0662d.N0 = imageView17;
        h0(imageView17, new View.OnClickListener() { // from class: ax.a2.h
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                this.q.p0(view3);
            }
        });
        viewFindViewById = c0662d.findViewById(ax.p005a2.z.L);
        c0662d.O0 = viewFindViewById;
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(c0662d.l0);
        }
        viewFindViewById2 = c0662d.findViewById(ax.p005a2.z.D);
        c0662d.P0 = viewFindViewById2;
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(c0662d.l0);
        }
        viewFindViewById3 = c0662d.findViewById(ax.p005a2.z.c);
        c0662d.Q0 = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(c0662d.l0);
        }
        i18 = ax.p005a2.z.G;
        g2 = (G) c0662d.findViewById(i18);
        viewFindViewById4 = c0662d.findViewById(ax.p005a2.z.H);
        if (g2 != null) {
            c0662d.T0 = g2;
            context2 = context;
            c0662d2 = c0662d;
            c2 = 1;
        } else if (viewFindViewById4 != null) {
            context2 = context;
            c0662d2 = this;
            c2 = 1;
            C0660b c0660b3 = new C0660b(context2, null, 0, attributeSet2, ax.p005a2.E.a);
            c0660b3.setId(i18);
            c0660b3.setLayoutParams(viewFindViewById4.getLayoutParams());
            ViewGroup viewGroup3 = (ViewGroup) viewFindViewById4.getParent();
            int iIndexOfChild3 = viewGroup3.indexOfChild(viewFindViewById4);
            viewGroup3.removeView(viewFindViewById4);
            viewGroup3.addView(c0660b3, iIndexOfChild3);
            c0662d2.T0 = c0660b3;
        } else {
            context2 = context;
            c0662d2 = c0662d;
            c2 = 1;
            c0662d2.T0 = method3;
        }
        g3 = c0662d2.T0;
        if (g3 != null) {
            g3.a(c0662d2.l0);
        }
        resources = context2.getResources();
        c0662d2.k0 = resources;
        imageView2 = (ImageView) c0662d2.findViewById(ax.p005a2.z.C);
        c0662d2.D0 = imageView2;
        if (imageView2 != null) {
            imageView2.setOnClickListener(c0662d2.l0);
        }
        imageView3 = (ImageView) c0662d2.findViewById(ax.p005a2.z.F);
        c0662d2.B0 = imageView3;
        if (imageView3 != null) {
            imageView3.setImageDrawable(d0.a0(context2, resources, i6));
            imageView3.setOnClickListener(c0662d2.l0);
        }
        imageView4 = (ImageView) c0662d2.findViewById(ax.p005a2.z.y);
        c0662d2.C0 = imageView4;
        if (imageView4 != null) {
            imageView4.setImageDrawable(d0.a0(context2, resources, i13));
            imageView4.setOnClickListener(c0662d2.l0);
        }
        typefaceG = ax.S.h.g(context2, ax.p005a2.y.a);
        imageView5 = (ImageView) c0662d2.findViewById(ax.p005a2.z.J);
        textView = (TextView) c0662d2.findViewById(ax.p005a2.z.K);
        if (imageView5 != null) {
            imageView5.setImageDrawable(d0.a0(context2, resources, resourceId));
            c0662d2.F0 = imageView5;
            c0662d2.H0 = null;
        } else if (textView != null) {
            textView.setTypeface(typefaceG);
            c0662d2.H0 = textView;
            c0662d2.F0 = textView;
        } else {
            c0662d2.H0 = null;
            c0662d2.F0 = null;
        }
        view = c0662d2.F0;
        if (view != null) {
            view.setOnClickListener(c0662d2.l0);
        }
        imageView6 = (ImageView) c0662d2.findViewById(ax.p005a2.z.q);
        textView2 = (TextView) c0662d2.findViewById(ax.p005a2.z.r);
        if (imageView6 != null) {
            imageView6.setImageDrawable(d0.a0(context2, resources, i4));
            c0662d2.E0 = imageView6;
            c0662d2.G0 = null;
        } else if (textView2 != null) {
            textView2.setTypeface(typefaceG);
            c0662d2.G0 = textView2;
            c0662d2.E0 = textView2;
        } else {
            c0662d2.G0 = null;
            c0662d2.E0 = null;
        }
        view2 = c0662d2.E0;
        if (view2 != null) {
            view2.setOnClickListener(c0662d2.l0);
        }
        imageView7 = (ImageView) c0662d2.findViewById(ax.p005a2.z.I);
        c0662d2.I0 = imageView7;
        if (imageView7 != null) {
            imageView7.setOnClickListener(c0662d2.l0);
        }
        imageView8 = (ImageView) c0662d2.findViewById(ax.p005a2.z.M);
        c0662d2.J0 = imageView8;
        if (imageView8 != null) {
            imageView8.setOnClickListener(c0662d2.l0);
        }
        c0662d2.j1 = resources.getInteger(ax.p005a2.A.b) / 100.0f;
        c0662d2.k1 = resources.getInteger(ax.p005a2.A.a) / 100.0f;
        imageView9 = (ImageView) c0662d2.findViewById(ax.p005a2.z.T);
        c0662d2.K0 = imageView9;
        if (imageView9 != null) {
            imageView9.setImageDrawable(d0.a0(context2, resources, i34));
            c0662d2.x0(false, imageView9);
        }
        w wVar5 = new w(c0662d2);
        c0662d2.q = wVar5;
        wVar5.T(z8);
        String string3 = resources.getString(ax.p005a2.D.h);
        Drawable drawableA4 = d0.a0(context2, resources, ax.p005a2.x.p);
        String[] strArr3 = {string3, resources.getString(ax.p005a2.D.y)};
        Drawable drawableA5 = d0.a0(context2, resources, ax.p005a2.x.b);
        Drawable[] drawableArr3 = new Drawable[2];
        drawableArr3[0] = drawableA4;
        drawableArr3[c2] = drawableA5;
        h hVar3 = c0662d2.new h(strArr3, drawableArr3);
        c0662d2.u0 = hVar3;
        c0662d2.A0 = resources.getDimensionPixelSize(ax.p005a2.w.a);
        RecyclerView recyclerView3 = (RecyclerView) LayoutInflater.from(context2).inflate(ax.p005a2.B.d, (ViewGroup) null);
        c0662d2.t0 = recyclerView3;
        recyclerView3.setAdapter(hVar3);
        recyclerView3.setLayoutManager(new LinearLayoutManager(c0662d2.getContext()));
        popupWindow = new PopupWindow((View) recyclerView3, -2, -2, true);
        c0662d2.z0 = popupWindow;
        if (Build.VERSION.SDK_INT < 23) {
            popupWindow.setBackgroundDrawable(new ColorDrawable(0));
        }
        popupWindow.setOnDismissListener(c0662d2.l0);
        c0662d2.M1 = true;
        c0662d2.y0 = new C1767f(c0662d2.getResources());
        c0662d2.n1 = d0.a0(context2, resources, i8);
        c0662d2.o1 = d0.a0(context2, resources, resourceId2);
        c0662d2.p1 = resources.getString(ax.p005a2.D.b);
        c0662d2.q1 = resources.getString(ax.p005a2.D.a);
        c0662d2.w0 = new j();
        c0662d2.x0 = new b();
        c0662d2.v0 = c0662d2.new e(c0662d2.k0.getStringArray(ax.p005a2.u.a), N1);
        c0662d2.Z0 = d0.a0(context2, c0662d2.k0, i16);
        c0662d2.a1 = d0.a0(context2, c0662d2.k0, i15);
        c0662d2.r1 = d0.a0(context2, c0662d2.k0, i5);
        c0662d2.s1 = d0.a0(context2, c0662d2.k0, i7);
        c0662d2.b1 = d0.a0(context2, c0662d2.k0, i12);
        c0662d2.c1 = d0.a0(context2, c0662d2.k0, i14);
        c0662d2.d1 = d0.a0(context2, c0662d2.k0, i10);
        c0662d2.h1 = d0.a0(context2, c0662d2.k0, i9);
        c0662d2.i1 = d0.a0(context2, c0662d2.k0, i3);
        c0662d2.t1 = c0662d2.k0.getString(ax.p005a2.D.d);
        c0662d2.u1 = c0662d2.k0.getString(ax.p005a2.D.c);
        c0662d2.e1 = c0662d2.k0.getString(ax.p005a2.D.j);
        c0662d2.f1 = c0662d2.k0.getString(ax.p005a2.D.k);
        c0662d2.g1 = c0662d2.k0.getString(ax.p005a2.D.i);
        c0662d2.l1 = c0662d2.k0.getString(ax.p005a2.D.n);
        c0662d2.m1 = c0662d2.k0.getString(ax.p005a2.D.m);
        c0662d2.q.U((ViewGroup) c0662d2.findViewById(ax.p005a2.z.e), true);
        c0662d2.q.U(c0662d2.E0, z7);
        c0662d2.q.U(c0662d2.F0, z6);
        c0662d2.q.U(c0662d2.B0, z5);
        c0662d2.q.U(c0662d2.C0, z4);
        c0662d2.q.U(c0662d2.J0, z3);
        c0662d2.q.U(c0662d2.L0, z2);
        c0662d2.q.U(c0662d2.K0, z);
        w wVar6 = c0662d2.q;
        ImageView imageView18 = c0662d2.I0;
        if (c0662d2.G1 != 0) {
            z9 = true;
        } else {
            z9 = false;
        }
        wVar6.U(imageView18, z9);
        c0662d2.addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: ax.a2.i
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view3, int i35, int i36, int i37, int i38, int i39, int i40, int i41, int i42) {
                this.a.q0(view3, i35, i36, i37, i38, i39, i40, i41, i42);
            }
        });
    }

    private static void A0(View view, boolean z) {
        if (view == null) {
            return;
        }
        if (z) {
            view.setVisibility(0);
        } else {
            view.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void C0() {
        boolean Z;
        boolean Z2;
        boolean Z3;
        boolean Z4;
        boolean Z5;
        if (n0() && this.y1) {
            ax.P0.H h2 = this.v1;
            if (h2 != null) {
                Z = (this.z1 && Z(h2, this.X0)) ? h2.Z(10) : h2.Z(5);
                Z3 = h2.Z(7);
                Z4 = h2.Z(11);
                Z5 = h2.Z(12);
                Z2 = h2.Z(9);
            } else {
                Z = false;
                Z2 = false;
                Z3 = false;
                Z4 = false;
                Z5 = false;
            }
            if (Z4) {
                H0();
            }
            if (Z5) {
                y0();
            }
            x0(Z3, this.B0);
            x0(Z4, this.F0);
            x0(Z5, this.E0);
            x0(Z2, this.C0);
            G g2 = this.T0;
            if (g2 != null) {
                g2.setEnabled(Z);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void D0() {
        if (n0() && this.y1 && this.D0 != null) {
            boolean zW1 = d0.w1(this.v1, this.A1);
            Drawable drawable = zW1 ? this.Z0 : this.a1;
            int i2 = zW1 ? ax.p005a2.D.g : ax.p005a2.D.f;
            this.D0.setImageDrawable(drawable);
            this.D0.setContentDescription(this.k0.getString(i2));
            x0(d0.u1(this.v1), this.D0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E0() {
        ax.P0.H h2 = this.v1;
        if (h2 == null) {
            return;
        }
        this.v0.R(h2.f().a);
        this.u0.Q(0, this.v0.O());
        I0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void F0() {
        long jQ;
        long jK0;
        if (n0() && this.y1) {
            ax.P0.H h2 = this.v1;
            if (h2 == null || !h2.Z(16)) {
                jQ = 0;
                jK0 = 0;
            } else {
                jQ = this.L1 + h2.Q();
                jK0 = this.L1 + h2.k0();
            }
            TextView textView = this.S0;
            if (textView != null && !this.C1) {
                textView.setText(d0.q0(this.U0, this.V0, jQ));
            }
            G g2 = this.T0;
            if (g2 != null) {
                g2.setPosition(jQ);
                G g3 = this.T0;
                if (m0(h2)) {
                    jK0 = jQ;
                }
                g3.setBufferedPosition(jK0);
            }
            removeCallbacks(this.Y0);
            int iV = h2 == null ? 1 : h2.V();
            if (h2 == null || !h2.i()) {
                if (iV == 4 || iV == 1) {
                    return;
                }
                postDelayed(this.Y0, 1000L);
                return;
            }
            G g4 = this.T0;
            long jMin = Math.min(g4 != null ? g4.getPreferredUpdateDelay() : 1000L, 1000 - (jQ % 1000));
            float f2 = h2.f().a;
            postDelayed(this.Y0, d0.q(f2 > 0.0f ? (long) (jMin / f2) : 1000L, this.F1, 1000L));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G0() {
        ImageView imageView;
        if (n0() && this.y1 && (imageView = this.I0) != null) {
            if (this.G1 == 0) {
                x0(false, imageView);
                return;
            }
            ax.P0.H h2 = this.v1;
            if (h2 == null || !h2.Z(15)) {
                x0(false, this.I0);
                this.I0.setImageDrawable(this.b1);
                this.I0.setContentDescription(this.e1);
                return;
            }
            x0(true, this.I0);
            int iO0 = h2.o0();
            if (iO0 == 0) {
                this.I0.setImageDrawable(this.b1);
                this.I0.setContentDescription(this.e1);
            } else if (iO0 == 1) {
                this.I0.setImageDrawable(this.c1);
                this.I0.setContentDescription(this.f1);
            } else {
                if (iO0 != 2) {
                    return;
                }
                this.I0.setImageDrawable(this.d1);
                this.I0.setContentDescription(this.g1);
            }
        }
    }

    private void H0() {
        ax.P0.H h2 = this.v1;
        int iS0 = (int) ((h2 != null ? h2.s0() : 5000L) / 1000);
        TextView textView = this.H0;
        if (textView != null) {
            textView.setText(String.valueOf(iS0));
        }
        View view = this.F0;
        if (view != null) {
            view.setContentDescription(this.k0.getQuantityString(ax.p005a2.C.b, iS0, Integer.valueOf(iS0)));
        }
    }

    private void I0() {
        x0(this.u0.N(), this.O0);
    }

    private void J0() {
        this.t0.measure(0, 0);
        this.z0.setWidth(Math.min(this.t0.getMeasuredWidth(), getWidth() - (this.A0 * 2)));
        this.z0.setHeight(Math.min(getHeight() - (this.A0 * 2), this.t0.getMeasuredHeight()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K0() {
        ImageView imageView;
        if (n0() && this.y1 && (imageView = this.J0) != null) {
            ax.P0.H h2 = this.v1;
            if (!this.q.A(imageView)) {
                x0(false, this.J0);
                return;
            }
            if (h2 == null || !h2.Z(14)) {
                x0(false, this.J0);
                this.J0.setImageDrawable(this.i1);
                this.J0.setContentDescription(this.m1);
            } else {
                x0(true, this.J0);
                this.J0.setImageDrawable(h2.h0() ? this.h1 : this.i1);
                this.J0.setContentDescription(h2.h0() ? this.l1 : this.m1);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:63:0x0116  */
    public void L0() {
        long jA1;
        int i2;
        N.c cVar;
        long j2;
        ax.P0.H h2 = this.v1;
        if (h2 == null) {
            return;
        }
        this.B1 = this.z1 && Z(h2, this.X0);
        long j3 = 0;
        this.L1 = 0L;
        N nF0 = h2.Z(17) ? h2.f0() : N.a;
        long j4 = -9223372036854775807L;
        if (nF0.q()) {
            if (h2.Z(16)) {
                long jV = h2.v();
                if (jV != -9223372036854775807L) {
                    jA1 = d0.a1(jV);
                } else {
                    jA1 = 0;
                }
            } else {
                jA1 = 0;
            }
            i2 = 0;
        } else {
            int iY = h2.Y();
            boolean z = this.B1;
            int i3 = z ? 0 : iY;
            int iP = z ? nF0.p() - 1 : iY;
            long j5 = 0;
            i2 = 0;
            while (i3 <= iP) {
                if (i3 == iY) {
                    this.L1 = d0.E1(j5);
                }
                nF0.n(i3, this.X0);
                N.c cVar2 = this.X0;
                long j6 = j3;
                if (cVar2.m == j4) {
                    C1498a.g(!this.B1);
                    break;
                }
                int i4 = cVar2.n;
                while (true) {
                    cVar = this.X0;
                    if (i4 <= cVar.o) {
                        nF0.f(i4, this.W0);
                        int iP2 = this.W0.p();
                        int iC = this.W0.c();
                        while (iP2 < iC) {
                            long jF = this.W0.f(iP2);
                            if (jF == Long.MIN_VALUE) {
                                j2 = j4;
                                long j7 = this.W0.d;
                                if (j7 != j2) {
                                    jF = j7;
                                }
                                iP2++;
                                j4 = j2;
                            } else {
                                j2 = j4;
                            }
                            long jO = jF + this.W0.o();
                            if (jO >= j6) {
                                long[] jArr = this.H1;
                                if (i2 == jArr.length) {
                                    int length = jArr.length == 0 ? 1 : jArr.length * 2;
                                    this.H1 = Arrays.copyOf(jArr, length);
                                    this.I1 = Arrays.copyOf(this.I1, length);
                                }
                                this.H1[i2] = d0.E1(j5 + jO);
                                this.I1[i2] = this.W0.q(iP2);
                                i2++;
                            }
                            iP2++;
                            j4 = j2;
                        }
                        i4++;
                    }
                }
                j5 += cVar.m;
                i3++;
                j3 = j6;
            }
            jA1 = j5;
        }
        long jE1 = d0.E1(jA1);
        TextView textView = this.R0;
        if (textView != null) {
            textView.setText(d0.q0(this.U0, this.V0, jE1));
        }
        G g2 = this.T0;
        if (g2 != null) {
            g2.setDuration(jE1);
            int length2 = this.J1.length;
            int i5 = i2 + length2;
            long[] jArr2 = this.H1;
            if (i5 > jArr2.length) {
                this.H1 = Arrays.copyOf(jArr2, i5);
                this.I1 = Arrays.copyOf(this.I1, i5);
            }
            System.arraycopy(this.J1, 0, this.H1, i2, length2);
            System.arraycopy(this.K1, 0, this.I1, i2, length2);
            this.T0.b(this.H1, this.I1, i5);
        }
        F0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M0() {
        g0();
        x0(this.w0.l() > 0, this.L0);
        I0();
    }

    private static boolean Z(ax.P0.H h2, N.c cVar) {
        N nF0;
        int iP;
        if (!h2.Z(17) || (iP = (nF0 = h2.f0()).p()) <= 1 || iP > 100) {
            return false;
        }
        for (int i2 = 0; i2 < iP; i2++) {
            if (nF0.n(i2, cVar).m == -9223372036854775807L) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b0(RecyclerView.h<?> hVar, View view) {
        this.t0.setAdapter(hVar);
        J0();
        this.M1 = false;
        this.z0.dismiss();
        this.M1 = true;
        this.z0.showAsDropDown(view, (getWidth() - this.z0.getWidth()) - this.A0, (-this.z0.getHeight()) - this.A0);
    }

    private AbstractC1656z<k> c0(V v, int i2) {
        AbstractC1656z.a aVar = new AbstractC1656z.a();
        AbstractC1656z<V.a> abstractC1656zA = v.a();
        for (int i3 = 0; i3 < abstractC1656zA.size(); i3++) {
            V.a aVar2 = abstractC1656zA.get(i3);
            if (aVar2.d() == i2) {
                for (int i4 = 0; i4 < aVar2.a; i4++) {
                    if (aVar2.j(i4)) {
                        C1375v c1375vB = aVar2.b(i4);
                        if ((c1375vB.e & 2) == 0) {
                            aVar.a(new k(v, i3, i4, this.y0.a(c1375vB)));
                        }
                    }
                }
            }
        }
        return aVar.k();
    }

    private static int d0(TypedArray typedArray, int i2) {
        return typedArray.getInt(ax.p005a2.F.L, i2);
    }

    private void g0() {
        this.w0.O();
        this.x0.O();
        ax.P0.H h2 = this.v1;
        if (h2 != null && h2.Z(30) && this.v1.Z(29)) {
            V vS = this.v1.S();
            this.x0.V(c0(vS, 1));
            if (this.q.A(this.L0)) {
                this.w0.U(c0(vS, 3));
            } else {
                this.w0.U(AbstractC1656z.y());
            }
        }
    }

    private static void h0(View view, View.OnClickListener onClickListener) {
        if (view == null) {
            return;
        }
        view.setVisibility(8);
        view.setOnClickListener(onClickListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean i0(ax.P0.H h2) {
        Class<?> cls;
        return (h2 == null || (cls = this.p0) == null || !cls.isAssignableFrom(h2.getClass())) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean j0(ax.P0.H h2) {
        Class<?> cls;
        return (h2 == null || (cls = this.m0) == null || !cls.isAssignableFrom(h2.getClass())) ? false : true;
    }

    @SuppressLint({"InlinedApi"})
    private static boolean l0(int i2) {
        return i2 == 90 || i2 == 89 || i2 == 85 || i2 == 79 || i2 == 126 || i2 == 127 || i2 == 87 || i2 == 88;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean m0(ax.P0.H h2) {
        try {
            if (j0(h2) && ((Boolean) C1498a.e(((Method) C1498a.e(this.o0)).invoke(h2, null))).booleanValue()) {
                return true;
            }
            return i0(h2) && ((Boolean) C1498a.e(((Method) C1498a.e(this.r0)).invoke(h2, null))).booleanValue();
        } catch (IllegalAccessException e2) {
            e = e2;
            throw new RuntimeException(e);
        } catch (InvocationTargetException e3) {
            e = e3;
            throw new RuntimeException(e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void p0(View view) {
        B0(!this.x1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void q0(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        int i10 = i5 - i3;
        int i11 = i9 - i7;
        if (!(i4 - i2 == i8 - i6 && i10 == i11) && this.z0.isShowing()) {
            J0();
            this.z0.update(view, (getWidth() - this.z0.getWidth()) - this.A0, (-this.z0.getHeight()) - this.A0, -1, -1);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r0(int i2) {
        if (i2 == 0) {
            b0(this.v0, (View) C1498a.e(this.O0));
        } else if (i2 == 1) {
            b0(this.x0, (View) C1498a.e(this.O0));
        } else {
            this.z0.dismiss();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setPlaybackSpeed(float f2) {
        ax.P0.H h2 = this.v1;
        if (h2 == null || !h2.Z(13)) {
            return;
        }
        ax.P0.H h3 = this.v1;
        h3.d(h3.f().b(f2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void u0(ax.P0.H h2, long j2) {
        if (this.B1) {
            if (h2.Z(17) && h2.Z(10)) {
                N nF0 = h2.f0();
                int iP = nF0.p();
                int i2 = 0;
                while (true) {
                    long jD = nF0.n(i2, this.X0).d();
                    if (j2 < jD) {
                        break;
                    }
                    if (i2 == iP - 1) {
                        j2 = jD;
                        break;
                    } else {
                        j2 -= jD;
                        i2++;
                    }
                }
                h2.m(i2, j2);
            }
        } else if (h2.Z(5)) {
            h2.C0(j2);
        }
        F0();
    }

    private void x0(boolean z, View view) {
        if (view == null) {
            return;
        }
        view.setEnabled(z);
        view.setAlpha(z ? this.j1 : this.k1);
    }

    private void y0() {
        ax.P0.H h2 = this.v1;
        int iO = (int) ((h2 != null ? h2.O() : 15000L) / 1000);
        TextView textView = this.G0;
        if (textView != null) {
            textView.setText(String.valueOf(iO));
        }
        View view = this.E0;
        if (view != null) {
            view.setContentDescription(this.k0.getQuantityString(ax.p005a2.C.a, iO, Integer.valueOf(iO)));
        }
    }

    private void z0(ImageView imageView, boolean z) {
        if (imageView == null) {
            return;
        }
        if (z) {
            imageView.setImageDrawable(this.r1);
            imageView.setContentDescription(this.t1);
        } else {
            imageView.setImageDrawable(this.s1);
            imageView.setContentDescription(this.u1);
        }
    }

    public void B0(boolean z) {
        if (this.x1 == z) {
            return;
        }
        this.x1 = z;
        z0(this.M0, z);
        z0(this.N0, z);
        InterfaceC0031d interfaceC0031d = this.w1;
        if (interfaceC0031d != null) {
            interfaceC0031d.P(z);
        }
    }

    @Deprecated
    public void Y(m mVar) {
        C1498a.e(mVar);
        this.s0.add(mVar);
    }

    public boolean a0(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        ax.P0.H h2 = this.v1;
        if (h2 == null || !l0(keyCode)) {
            return false;
        }
        if (keyEvent.getAction() != 0) {
            return true;
        }
        if (keyCode == 90) {
            if (h2.V() == 4 || !h2.Z(12)) {
                return true;
            }
            h2.m0();
            return true;
        }
        if (keyCode == 89 && h2.Z(11)) {
            h2.p0();
            return true;
        }
        if (keyEvent.getRepeatCount() != 0) {
            return true;
        }
        if (keyCode == 79 || keyCode == 85) {
            d0.B0(h2, this.A1);
            return true;
        }
        if (keyCode == 87) {
            if (!h2.Z(9)) {
                return true;
            }
            h2.l0();
            return true;
        }
        if (keyCode == 88) {
            if (!h2.Z(7)) {
                return true;
            }
            h2.L();
            return true;
        }
        if (keyCode == 126) {
            d0.z0(h2);
            return true;
        }
        if (keyCode != 127) {
            return true;
        }
        d0.y0(h2);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return a0(keyEvent) || super.dispatchKeyEvent(keyEvent);
    }

    public void e0() {
        this.q.C();
    }

    public void f0() {
        this.q.F();
    }

    public ax.P0.H getPlayer() {
        return this.v1;
    }

    public int getRepeatToggleModes() {
        return this.G1;
    }

    public boolean getShowShuffleButton() {
        return this.q.A(this.J0);
    }

    public boolean getShowSubtitleButton() {
        return this.q.A(this.L0);
    }

    public int getShowTimeoutMs() {
        return this.D1;
    }

    public boolean getShowVrButton() {
        return this.q.A(this.K0);
    }

    public boolean k0() {
        return this.q.I();
    }

    public boolean n0() {
        return getVisibility() == 0;
    }

    void o0() {
        Iterator<m> it = this.s0.iterator();
        while (it.hasNext()) {
            it.next().d0(getVisibility());
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.q.K();
        this.y1 = true;
        if (k0()) {
            this.q.S();
        }
        w0();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.q.L();
        this.y1 = false;
        removeCallbacks(this.Y0);
        this.q.R();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        this.q.M(z, i2, i3, i4, i5);
    }

    @Deprecated
    public void s0(m mVar) {
        this.s0.remove(mVar);
    }

    public void setAnimationEnabled(boolean z) {
        this.q.T(z);
    }

    @Deprecated
    public void setOnFullScreenModeChangedListener(InterfaceC0031d interfaceC0031d) {
        this.w1 = interfaceC0031d;
        A0(this.M0, interfaceC0031d != null);
        A0(this.N0, interfaceC0031d != null);
    }

    public void setPlayer(ax.P0.H h2) {
        C1498a.g(Looper.myLooper() == Looper.getMainLooper());
        C1498a.a(h2 == null || h2.g0() == Looper.getMainLooper());
        ax.P0.H h3 = this.v1;
        if (h3 == h2) {
            return;
        }
        if (h3 != null) {
            h3.k(this.l0);
        }
        this.v1 = h2;
        if (h2 != null) {
            h2.G(this.l0);
        }
        w0();
    }

    public void setProgressUpdateListener(f fVar) {
    }

    public void setRepeatToggleModes(int i2) {
        this.G1 = i2;
        ax.P0.H h2 = this.v1;
        if (h2 != null && h2.Z(15)) {
            int iO0 = this.v1.o0();
            if (i2 == 0 && iO0 != 0) {
                this.v1.X(0);
            } else if (i2 == 1 && iO0 == 2) {
                this.v1.X(1);
            } else if (i2 == 2 && iO0 == 1) {
                this.v1.X(2);
            }
        }
        this.q.U(this.I0, i2 != 0);
        G0();
    }

    public void setShowFastForwardButton(boolean z) {
        this.q.U(this.E0, z);
        C0();
    }

    @Deprecated
    public void setShowMultiWindowTimeBar(boolean z) {
        this.z1 = z;
        L0();
    }

    public void setShowNextButton(boolean z) {
        this.q.U(this.C0, z);
        C0();
    }

    public void setShowPlayButtonIfPlaybackIsSuppressed(boolean z) {
        this.A1 = z;
        D0();
    }

    public void setShowPreviousButton(boolean z) {
        this.q.U(this.B0, z);
        C0();
    }

    public void setShowRewindButton(boolean z) {
        this.q.U(this.F0, z);
        C0();
    }

    public void setShowShuffleButton(boolean z) {
        this.q.U(this.J0, z);
        K0();
    }

    public void setShowSubtitleButton(boolean z) {
        this.q.U(this.L0, z);
    }

    public void setShowTimeoutMs(int i2) {
        this.D1 = i2;
        if (k0()) {
            this.q.S();
        }
    }

    public void setShowVrButton(boolean z) {
        this.q.U(this.K0, z);
    }

    public void setTimeBarMinUpdateInterval(int i2) {
        this.F1 = d0.p(i2, 16, 1000);
    }

    public void setTimeBarScrubbingEnabled(boolean z) {
        this.E1 = z;
    }

    public void setVrButtonListener(View.OnClickListener onClickListener) {
        ImageView imageView = this.K0;
        if (imageView != null) {
            imageView.setOnClickListener(onClickListener);
            x0(onClickListener != null, this.K0);
        }
    }

    void t0() {
        ImageView imageView = this.D0;
        if (imageView != null) {
            imageView.requestFocus();
        }
    }

    public void v0() {
        this.q.X();
    }

    void w0() {
        D0();
        C0();
        G0();
        K0();
        M0();
        E0();
        L0();
    }
}
