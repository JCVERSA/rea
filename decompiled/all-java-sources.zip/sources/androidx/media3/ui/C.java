package androidx.media3.ui;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import ax.S0.C1498a;
import ax.S0.C1517u;
import ax.p005a2.C1762a;
import j$.util.Objects;

/* JADX INFO: loaded from: classes.dex */
final class C {
    private int A;
    private int B;
    private int C;
    private int D;
    private StaticLayout E;
    private StaticLayout F;
    private int G;
    private int H;
    private int I;
    private Rect J;
    private final float a;
    private final float b;
    private final float c;
    private final float d;
    private final float e;
    private final TextPaint f;
    private final Paint g;
    private final Paint h;
    private CharSequence i;
    private Layout.Alignment j;
    private Bitmap k;
    private float l;
    private int m;
    private int n;
    private float o;
    private int p;
    private float q;
    private float r;
    private int s;
    private int t;
    private int u;
    private int v;
    private int w;
    private float x;
    private float y;
    private float z;

    public C(Context context) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, new int[]{R.attr.lineSpacingExtra, R.attr.lineSpacingMultiplier}, 0, 0);
        this.e = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.d = typedArrayObtainStyledAttributes.getFloat(1, 1.0f);
        typedArrayObtainStyledAttributes.recycle();
        float fRound = Math.round((context.getResources().getDisplayMetrics().densityDpi * 2.0f) / 160.0f);
        this.a = fRound;
        this.b = fRound;
        this.c = fRound;
        TextPaint textPaint = new TextPaint();
        this.f = textPaint;
        textPaint.setAntiAlias(true);
        textPaint.setSubpixelText(true);
        Paint paint = new Paint();
        this.g = paint;
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint();
        this.h = paint2;
        paint2.setAntiAlias(true);
        paint2.setFilterBitmap(true);
    }

    private static boolean a(CharSequence charSequence, CharSequence charSequence2) {
        if (charSequence != charSequence2) {
            return charSequence != null && charSequence.equals(charSequence2);
        }
        return true;
    }

    private void c(Canvas canvas) {
        canvas.drawBitmap(this.k, (Rect) null, this.J, this.h);
    }

    private void d(Canvas canvas, boolean z) {
        if (z) {
            e(canvas);
            return;
        }
        C1498a.e(this.J);
        C1498a.e(this.k);
        c(canvas);
    }

    private void e(Canvas canvas) {
        Canvas canvas2;
        StaticLayout staticLayout = this.E;
        StaticLayout staticLayout2 = this.F;
        if (staticLayout == null || staticLayout2 == null) {
            return;
        }
        int iSave = canvas.save();
        canvas.translate(this.G, this.H);
        if (Color.alpha(this.u) > 0) {
            this.g.setColor(this.u);
            canvas2 = canvas;
            canvas2.drawRect(-this.I, 0.0f, staticLayout.getWidth() + this.I, staticLayout.getHeight(), this.g);
        } else {
            canvas2 = canvas;
        }
        int i = this.w;
        if (i == 1) {
            this.f.setStrokeJoin(Paint.Join.ROUND);
            this.f.setStrokeWidth(this.a);
            this.f.setColor(this.v);
            this.f.setStyle(Paint.Style.FILL_AND_STROKE);
            staticLayout2.draw(canvas2);
        } else if (i == 2) {
            TextPaint textPaint = this.f;
            float f = this.b;
            float f2 = this.c;
            textPaint.setShadowLayer(f, f2, f2, this.v);
        } else if (i == 3 || i == 4) {
            boolean z = i == 3;
            int i2 = z ? -1 : this.v;
            int i3 = z ? this.v : -1;
            float f3 = this.b / 2.0f;
            this.f.setColor(this.s);
            this.f.setStyle(Paint.Style.FILL);
            float f4 = -f3;
            this.f.setShadowLayer(this.b, f4, f4, i2);
            staticLayout2.draw(canvas2);
            this.f.setShadowLayer(this.b, f3, f3, i3);
        }
        this.f.setColor(this.s);
        this.f.setStyle(Paint.Style.FILL);
        staticLayout.draw(canvas2);
        this.f.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        canvas2.restoreToCount(iSave);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x005b  */
    /* JADX WARN: Code duplicated, block: B:16:0x005e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:17:0x0060  */
    private void f() {
        float f;
        int i;
        float f2;
        Bitmap bitmap = this.k;
        int i2 = this.C;
        int i3 = this.A;
        int i4 = this.D;
        int i5 = this.B;
        float f3 = i2 - i3;
        float f4 = i3 + (this.o * f3);
        float f5 = i4 - i5;
        float f6 = i5 + (this.l * f5);
        int iRound = Math.round(f3 * this.q);
        float f7 = this.r;
        int iRound2 = f7 != -3.4028235E38f ? Math.round(f5 * f7) : Math.round(iRound * (bitmap.getHeight() / bitmap.getWidth()));
        int i6 = this.p;
        if (i6 != 2) {
            if (i6 == 1) {
                f = iRound / 2;
            }
            int iRound3 = Math.round(f4);
            i = this.n;
            if (i == 2) {
                if (i == 1) {
                    f2 = iRound2 / 2;
                }
                int iRound4 = Math.round(f6);
                this.J = new Rect(iRound3, iRound4, iRound + iRound3, iRound2 + iRound4);
            }
            f2 = iRound2;
            f6 -= f2;
            int iRound5 = Math.round(f6);
            this.J = new Rect(iRound3, iRound5, iRound + iRound3, iRound2 + iRound5);
        }
        f = iRound;
        f4 -= f;
        int iRound6 = Math.round(f4);
        i = this.n;
        if (i == 2) {
            if (i == 1) {
                f2 = iRound2 / 2;
            }
            int iRound7 = Math.round(f6);
            this.J = new Rect(iRound6, iRound7, iRound + iRound6, iRound2 + iRound7);
        }
        f2 = iRound2;
        f6 -= f2;
        int iRound8 = Math.round(f6);
        this.J = new Rect(iRound6, iRound8, iRound + iRound6, iRound2 + iRound8);
    }

    private void g() {
        int iMax;
        int iMin;
        int iRound;
        CharSequence charSequence = this.i;
        SpannableStringBuilder spannableStringBuilder = charSequence instanceof SpannableStringBuilder ? (SpannableStringBuilder) charSequence : new SpannableStringBuilder(this.i);
        int i = this.C - this.A;
        int i2 = this.D - this.B;
        this.f.setTextSize(this.x);
        int i3 = (int) ((this.x * 0.125f) + 0.5f);
        int i4 = i3 * 2;
        int i5 = i - i4;
        float f = this.q;
        if (f != -3.4028235E38f) {
            i5 = (int) (i5 * f);
        }
        int i6 = i5;
        String str = "SubtitlePainter";
        if (i6 <= 0) {
            C1517u.h("SubtitlePainter", "Skipped drawing subtitle cue (insufficient space)");
            return;
        }
        if (this.y > 0.0f) {
            spannableStringBuilder.setSpan(new AbsoluteSizeSpan((int) this.y), 0, spannableStringBuilder.length(), 16711680);
        }
        SpannableStringBuilder spannableStringBuilder2 = new SpannableStringBuilder(spannableStringBuilder);
        if (this.w == 1) {
            for (ForegroundColorSpan foregroundColorSpan : (ForegroundColorSpan[]) spannableStringBuilder2.getSpans(0, spannableStringBuilder2.length(), ForegroundColorSpan.class)) {
                spannableStringBuilder2.removeSpan(foregroundColorSpan);
            }
        }
        if (Color.alpha(this.t) > 0) {
            int i7 = this.w;
            if (i7 == 0 || i7 == 2) {
                spannableStringBuilder.setSpan(new BackgroundColorSpan(this.t), 0, spannableStringBuilder.length(), 16711680);
            } else {
                spannableStringBuilder2.setSpan(new BackgroundColorSpan(this.t), 0, spannableStringBuilder2.length(), 16711680);
            }
        }
        Layout.Alignment alignment = this.j;
        if (alignment == null) {
            alignment = Layout.Alignment.ALIGN_CENTER;
        }
        Layout.Alignment alignment2 = alignment;
        StaticLayout staticLayout = new StaticLayout(spannableStringBuilder, this.f, i6, alignment2, this.d, this.e, true);
        this.E = staticLayout;
        int height = staticLayout.getHeight();
        int lineCount = this.E.getLineCount();
        int iMax2 = 0;
        int i8 = 0;
        while (i8 < lineCount) {
            iMax2 = Math.max((int) Math.ceil(this.E.getLineWidth(i8)), iMax2);
            i8++;
            str = str;
        }
        String str2 = str;
        if (this.q == -3.4028235E38f || iMax2 >= i6) {
            i6 = iMax2;
        }
        int i9 = i6 + i4;
        float f2 = this.o;
        if (f2 != -3.4028235E38f) {
            int iRound2 = Math.round(i * f2);
            int i10 = this.A;
            int i11 = iRound2 + i10;
            int i12 = this.p;
            if (i12 == 1) {
                i11 = ((i11 * 2) - i9) / 2;
            } else if (i12 == 2) {
                i11 -= i9;
            }
            iMax = Math.max(i11, i10);
            iMin = Math.min(i9 + iMax, this.C);
        } else {
            iMax = ((i - i9) / 2) + this.A;
            iMin = iMax + i9;
        }
        int i13 = iMin - iMax;
        if (i13 <= 0) {
            C1517u.h(str2, "Skipped drawing subtitle cue (invalid horizontal positioning)");
            return;
        }
        float f3 = this.l;
        if (f3 != -3.4028235E38f) {
            if (this.m == 0) {
                iRound = Math.round(i2 * f3) + this.B;
                int i14 = this.n;
                if (i14 == 2) {
                    iRound -= height;
                } else if (i14 == 1) {
                    iRound = ((iRound * 2) - height) / 2;
                }
            } else {
                int lineBottom = this.E.getLineBottom(0) - this.E.getLineTop(0);
                float f4 = this.l;
                if (f4 >= 0.0f) {
                    iRound = Math.round(f4 * lineBottom) + this.B;
                } else {
                    iRound = Math.round((f4 + 1.0f) * lineBottom) + this.D;
                    iRound -= height;
                }
            }
            int i15 = iRound + height;
            int i16 = this.D;
            if (i15 > i16) {
                iRound = i16 - height;
            } else {
                int i17 = this.B;
                if (iRound < i17) {
                    iRound = i17;
                }
            }
        } else {
            iRound = (this.D - height) - ((int) (i2 * this.z));
        }
        this.E = new StaticLayout(spannableStringBuilder, this.f, i13, alignment2, this.d, this.e, true);
        this.F = new StaticLayout(spannableStringBuilder2, this.f, i13, alignment2, this.d, this.e, true);
        this.G = iMax;
        this.H = iRound;
        this.I = i3;
    }

    public void b(ax.R0.a aVar, C1762a c1762a, float f, float f2, float f3, Canvas canvas, int i, int i2, int i3, int i4) {
        int i5;
        boolean z = aVar.d == null;
        if (!z) {
            i5 = -16777216;
        } else if (TextUtils.isEmpty(aVar.a)) {
            return;
        } else {
            i5 = aVar.l ? aVar.m : c1762a.c;
        }
        if (a(this.i, aVar.a) && Objects.equals(this.j, aVar.b) && this.k == aVar.d && this.l == aVar.e && this.m == aVar.f && Integer.valueOf(this.n).equals(Integer.valueOf(aVar.g)) && this.o == aVar.h && Integer.valueOf(this.p).equals(Integer.valueOf(aVar.i)) && this.q == aVar.j && this.r == aVar.k && this.s == c1762a.a && this.t == c1762a.b && this.u == i5 && this.w == c1762a.d && this.v == c1762a.e && Objects.equals(this.f.getTypeface(), c1762a.f) && this.x == f && this.y == f2 && this.z == f3 && this.A == i && this.B == i2 && this.C == i3 && this.D == i4) {
            d(canvas, z);
            return;
        }
        this.i = aVar.a;
        this.j = aVar.b;
        this.k = aVar.d;
        this.l = aVar.e;
        this.m = aVar.f;
        this.n = aVar.g;
        this.o = aVar.h;
        this.p = aVar.i;
        this.q = aVar.j;
        this.r = aVar.k;
        this.s = c1762a.a;
        this.t = c1762a.b;
        this.u = i5;
        this.w = c1762a.d;
        this.v = c1762a.e;
        this.f.setTypeface(c1762a.f);
        this.x = f;
        this.y = f2;
        this.z = f3;
        this.A = i;
        this.B = i2;
        this.C = i3;
        this.D = i4;
        if (z) {
            C1498a.e(this.i);
            g();
        } else {
            C1498a.e(this.k);
            f();
        }
        d(canvas, z);
    }
}
