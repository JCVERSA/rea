package androidx.media3.ui;

/* JADX INFO: loaded from: classes.dex */
public interface G {

    public interface a {
        void P(G g, long j);

        void d0(G g, long j);

        void l0(G g, long j, boolean z);
    }

    void a(a aVar);

    void b(long[] jArr, boolean[] zArr, int i);

    long getPreferredUpdateDelay();

    void setBufferedPosition(long j);

    void setDuration(long j);

    void setEnabled(boolean z);

    void setPosition(long j);
}
