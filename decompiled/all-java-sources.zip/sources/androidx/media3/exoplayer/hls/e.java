package androidx.media3.exoplayer.hls;

import android.net.Uri;
import ax.E1.m;
import ax.P0.C;
import ax.P0.C1369o;
import ax.P0.C1375v;
import ax.S0.C1498a;
import ax.S0.G;
import ax.S0.M;
import ax.S0.O;
import ax.Y7.AbstractC1656z;
import ax.Z0.I1;
import ax.p260q1.C2225k;
import ax.p260q1.InterfaceC2232s;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.math.BigInteger;
import java.util.List;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import okhttp3.internal.http2.Http2;

/* JADX INFO: loaded from: classes.dex */
final class e extends ax.p148j1.d {
    private static final AtomicInteger O = new AtomicInteger();
    private final boolean A;
    private final boolean B;
    private final I1 C;
    private final long D;
    private ax.p036c1.f E;
    private l F;
    private int G;
    private boolean H;
    private volatile boolean I;
    private boolean J;
    private AbstractC1656z<Integer> K;
    private boolean L;
    private long M;
    private boolean N;
    public final int k;
    public final int l;
    public final Uri m;
    public final boolean n;
    public final int o;
    private final ax.U0.g p;
    private final ax.U0.k q;
    private final ax.p036c1.f r;
    private final boolean s;
    private final boolean t;
    private final M u;
    private final ax.p036c1.e v;
    private final List<C1375v> w;
    private final C1369o x;
    private final ax.E1.h y;
    private final G z;

    private e(ax.p036c1.e eVar, ax.U0.g gVar, ax.U0.k kVar, C1375v c1375v, boolean z, ax.U0.g gVar2, ax.U0.k kVar2, boolean z2, Uri uri, List<C1375v> list, int i, Object obj, long j, long j2, long j3, int i2, boolean z3, int i3, boolean z4, boolean z5, M m, long j4, C1369o c1369o, ax.p036c1.f fVar, ax.E1.h hVar, G g, boolean z6, boolean z7, I1 i1) {
        super(gVar, kVar, c1375v, i, obj, j, j2, j3);
        this.A = z;
        this.o = i2;
        this.M = z3 ? j2 - j : -9223372036854775807L;
        this.l = i3;
        this.q = kVar2;
        this.p = gVar2;
        this.H = kVar2 != null;
        this.B = z2;
        this.m = uri;
        this.s = z5;
        this.u = m;
        this.D = j4;
        this.t = z4;
        this.v = eVar;
        this.w = list;
        this.x = c1369o;
        this.r = fVar;
        this.y = hVar;
        this.z = g;
        this.N = z6;
        this.n = z7;
        this.C = i1;
        this.K = AbstractC1656z.y();
        this.k = O.getAndIncrement();
    }

    private static ax.U0.g h(ax.U0.g gVar, byte[] bArr, byte[] bArr2) {
        if (bArr == null) {
            return gVar;
        }
        C1498a.e(bArr2);
        return new a(gVar, bArr, bArr2);
    }

    public static e j(ax.p036c1.e eVar, ax.U0.g gVar, C1375v c1375v, long j, ax.p052d1.f fVar, c.e eVar2, Uri uri, List<C1375v> list, int i, Object obj, boolean z, ax.p036c1.j jVar, long j2, e eVar3, byte[] bArr, byte[] bArr2, boolean z2, boolean z3, I1 i1, ax.m1.g.a aVar) {
        ax.U0.g gVarH;
        ax.U0.k kVarA;
        boolean z4;
        Uri uri2;
        ax.E1.h hVar;
        G g;
        ax.p036c1.f fVar2;
        ax.d1.f.g gVar2 = eVar2.a;
        ax.U0.k kVarA2 = new ax.U0.k.b().i(O.d(fVar.a, gVar2.q)).h(gVar2.o0).g(gVar2.p0).b(eVar2.d ? 8 : 0).a();
        boolean z5 = bArr != null;
        ax.U0.g gVarH2 = h(gVar, bArr, z5 ? l((String) C1498a.e(gVar2.n0)) : null);
        ax.p052d1.f.C0311f c0311f = gVar2.X;
        if (c0311f != null) {
            boolean z6 = bArr2 != null;
            byte[] bArrL = z6 ? l((String) C1498a.e(c0311f.n0)) : null;
            kVarA = new ax.U0.k.b().i(O.d(fVar.a, c0311f.q)).h(c0311f.o0).g(c0311f.p0).a();
            gVarH = h(gVar, bArr2, bArrL);
            z4 = z6;
        } else {
            gVarH = null;
            kVarA = null;
            z4 = false;
        }
        long j3 = j + gVar2.k0;
        long j4 = j3 + gVar2.Y;
        int i2 = fVar.j + gVar2.Z;
        if (eVar3 != null) {
            ax.U0.k kVar = eVar3.q;
            boolean z7 = kVarA == kVar || (kVarA != null && kVar != null && kVarA.a.equals(kVar.a) && kVarA.g == eVar3.q.g);
            uri2 = uri;
            boolean z8 = uri2.equals(eVar3.m) && eVar3.J;
            hVar = eVar3.y;
            g = eVar3.z;
            fVar2 = (z7 && z8 && !eVar3.L && eVar3.l == i2) ? eVar3.E : null;
        } else {
            uri2 = uri;
            hVar = new ax.E1.h();
            g = new G(10);
            fVar2 = null;
        }
        return new e(eVar, gVarH2, kVarA2, c1375v, z5, gVarH, kVarA, z4, uri2, list, i, obj, j3, j4, eVar2.b, eVar2.c, !eVar2.d, i2, gVar2.q0, z, jVar.a(i2), j2, gVar2.l0, fVar2, hVar, g, z2, z3, i1);
    }

    private void k(ax.U0.g gVar, ax.U0.k kVar, boolean z, boolean z2) throws IOException {
        ax.U0.k kVarE;
        long position;
        long j;
        boolean z3 = false;
        if (z) {
            z3 = this.G != 0;
            kVarE = kVar;
        } else {
            kVarE = kVar.e(this.G);
        }
        try {
            C2225k c2225kV = v(gVar, kVarE, z2);
            if (z3) {
                c2225kV.n(this.G);
            }
            while (!this.I && this.E.b(c2225kV)) {
                try {
                    try {
                    } catch (EOFException e) {
                        if ((this.d.f & Http2.INITIAL_MAX_FRAME_SIZE) == 0) {
                            throw e;
                        }
                        this.E.c();
                        position = c2225kV.getPosition();
                        j = kVar.g;
                    }
                } catch (Throwable th) {
                    this.G = (int) (c2225kV.getPosition() - kVar.g);
                    throw th;
                }
            }
            position = c2225kV.getPosition();
            j = kVar.g;
            this.G = (int) (position - j);
            ax.U0.j.a(gVar);
        } catch (Throwable th2) {
            ax.U0.j.a(gVar);
            throw th2;
        }
    }

    private static byte[] l(String str) {
        if (ax.X7.c.e(str).startsWith("0x")) {
            str = str.substring(2);
        }
        byte[] byteArray = new BigInteger(str, 16).toByteArray();
        byte[] bArr = new byte[16];
        int length = byteArray.length > 16 ? byteArray.length - 16 : 0;
        System.arraycopy(byteArray, length, bArr, (16 - byteArray.length) + length, byteArray.length - length);
        return bArr;
    }

    private void s() throws IOException {
        k(this.i, this.b, this.A, true);
    }

    private void t() throws IOException {
        if (this.H) {
            C1498a.e(this.p);
            C1498a.e(this.q);
            k(this.p, this.q, this.B, false);
            this.G = 0;
            this.H = false;
        }
    }

    private long u(InterfaceC2232s interfaceC2232s) throws Throwable {
        interfaceC2232s.m();
        try {
            this.z.X(10);
            interfaceC2232s.p(this.z.f(), 0, 10);
            if (this.z.P() != 4801587) {
                return -9223372036854775807L;
            }
            this.z.c0(3);
            int iL = this.z.L();
            int i = iL + 10;
            if (i > this.z.b()) {
                byte[] bArrF = this.z.f();
                this.z.X(i);
                System.arraycopy(bArrF, 0, this.z.f(), 0, 10);
            }
            interfaceC2232s.p(this.z.f(), 10, iL);
            C cE = this.y.e(this.z.f(), iL);
            if (cE == null) {
                return -9223372036854775807L;
            }
            int iE = cE.e();
            for (int i2 = 0; i2 < iE; i2++) {
                C.a aVarD = cE.d(i2);
                if (aVarD instanceof m) {
                    m mVar = (m) aVarD;
                    if ("com.apple.streaming.transportStreamTimestamp".equals(mVar.b)) {
                        System.arraycopy(mVar.c, 0, this.z.f(), 0, 8);
                        this.z.b0(0);
                        this.z.a0(8);
                        return this.z.F() & 8589934591L;
                    }
                }
            }
            return -9223372036854775807L;
        } catch (EOFException unused) {
        }
    }

    private C2225k v(ax.U0.g gVar, ax.U0.k kVar, boolean z) throws Throwable {
        ax.p036c1.f fVarE;
        long jF = gVar.f(kVar);
        if (z) {
            try {
                this.u.j(this.s, this.g, this.D);
            } catch (InterruptedException unused) {
                throw new InterruptedIOException();
            } catch (TimeoutException e) {
                throw new IOException(e);
            }
        }
        C2225k c2225k = new C2225k(gVar, kVar.g, jF);
        if (this.E == null) {
            long jU = u(c2225k);
            c2225k.m();
            ax.p036c1.f fVar = this.r;
            if (fVar != null) {
                fVarE = fVar.f();
            } else {
                fVarE = this.v.e(kVar.a, this.d, this.w, this.u, gVar.l(), c2225k, this.C);
                c2225k = c2225k;
            }
            this.E = fVarE;
            if (fVarE.d()) {
                this.F.r0(jU != -9223372036854775807L ? this.u.b(jU) : this.g);
            } else {
                this.F.r0(0L);
            }
            this.F.d0();
            this.E.a(this.F);
        }
        this.F.o0(this.x);
        return c2225k;
    }

    public static boolean y(e eVar, long j, Uri uri, boolean z, c.e eVar2, long j2) {
        if (eVar == null) {
            return false;
        }
        if (uri.equals(eVar.m) && eVar.J) {
            return false;
        }
        return !z || j2 + eVar2.a.k0 < j;
    }

    @Override // ax.m1.o.e
    public void a() throws IOException {
        ax.p036c1.f fVar;
        C1498a.e(this.F);
        if (this.E == null && (fVar = this.r) != null && fVar.e()) {
            this.E = this.r;
            this.H = false;
        }
        t();
        if (this.I) {
            return;
        }
        if (!this.t) {
            s();
        }
        this.J = !this.I;
    }

    @Override // ax.m1.o.e
    public void c() {
        this.I = true;
    }

    public void i() {
        this.N = false;
    }

    public int m(int i) {
        C1498a.g(!this.N);
        if (i >= this.K.size()) {
            return 0;
        }
        return this.K.get(i).intValue();
    }

    public long n() {
        long j = this.M;
        if (j != -9223372036854775807L) {
            return this.g + j;
        }
        return -9223372036854775807L;
    }

    public void o(l lVar, AbstractC1656z<Integer> abstractC1656z) {
        this.F = lVar;
        this.K = abstractC1656z;
    }

    public void p() {
        this.L = true;
    }

    public boolean q() {
        return this.J;
    }

    public boolean r() {
        return this.M != -9223372036854775807L;
    }

    public void w(long j) {
        this.M = j;
    }

    public boolean x() {
        return this.N;
    }
}
