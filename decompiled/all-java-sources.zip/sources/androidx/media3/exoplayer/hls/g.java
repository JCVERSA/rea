package androidx.media3.exoplayer.hls;

import android.net.Uri;
import android.text.TextUtils;
import androidx.media3.exoplayer.C0639p0;
import ax.P0.C1369o;
import ax.P0.C1375v;
import ax.P0.C1377x;
import ax.P0.D;
import ax.P0.P;
import ax.S0.C1498a;
import ax.S0.d0;
import ax.U0.z;
import ax.Y0.Z;
import ax.Y7.AbstractC1656z;
import ax.Y7.I;
import ax.Z0.I1;
import ax.p020b1.InterfaceC1830u;
import ax.p020b1.w;
import ax.p052d1.m;
import ax.p132i1.C;
import ax.p132i1.InterfaceC2103j;
import ax.p132i1.N;
import ax.p132i1.e0;
import ax.p132i1.f0;
import ax.p132i1.q0;
import j$.util.Objects;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
final class g implements C, m.b {
    private q0 A0;
    private int E0;
    private f0 F0;
    private final m X;
    private final ax.p036c1.d Y;
    private final z Z;
    private final w k0;
    private final InterfaceC1830u.a l0;
    private final ax.p196m1.m m0;
    private final N.a n0;
    private final ax.p196m1.b o0;
    private final ax.p036c1.e q;
    private final InterfaceC2103j r0;
    private final boolean s0;
    private final int t0;
    private final boolean u0;
    private final I1 v0;
    private final long x0;
    private C.a y0;
    private int z0;
    private final l.b w0 = new b();
    private final IdentityHashMap<e0, Integer> p0 = new IdentityHashMap<>();
    private final ax.p036c1.j q0 = new ax.p036c1.j();
    private l[] B0 = new l[0];
    private l[] C0 = new l[0];
    private int[][] D0 = new int[0][];

    private class b implements l.b {
        private b() {
        }

        @Override // ax.i1.f0.a
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public void i(l lVar) {
            g.this.y0.i(g.this);
        }

        @Override // androidx.media3.exoplayer.hls.l.b
        public void h() {
            if (g.j(g.this) > 0) {
                return;
            }
            int i = 0;
            for (l lVar : g.this.B0) {
                i += lVar.t().a;
            }
            P[] pArr = new P[i];
            int i2 = 0;
            for (l lVar2 : g.this.B0) {
                int i3 = lVar2.t().a;
                int i4 = 0;
                while (i4 < i3) {
                    pArr[i2] = lVar2.t().c(i4);
                    i4++;
                    i2++;
                }
            }
            g.this.A0 = new q0(pArr);
            g.this.y0.f(g.this);
        }

        @Override // androidx.media3.exoplayer.hls.l.b
        public void j(Uri uri) {
            g.this.X.m(uri);
        }
    }

    public g(ax.p036c1.e eVar, m mVar, ax.p036c1.d dVar, z zVar, ax.p196m1.f fVar, w wVar, InterfaceC1830u.a aVar, ax.p196m1.m mVar2, N.a aVar2, ax.p196m1.b bVar, InterfaceC2103j interfaceC2103j, boolean z, int i, boolean z2, I1 i1, long j) {
        this.q = eVar;
        this.X = mVar;
        this.Y = dVar;
        this.Z = zVar;
        this.k0 = wVar;
        this.l0 = aVar;
        this.m0 = mVar2;
        this.n0 = aVar2;
        this.o0 = bVar;
        this.r0 = interfaceC2103j;
        this.s0 = z;
        this.t0 = i;
        this.u0 = z2;
        this.v0 = i1;
        this.x0 = j;
        this.F0 = interfaceC2103j.empty();
    }

    private static C1375v A(C1375v c1375v, C1375v c1375v2, boolean z) {
        ax.P0.C c;
        int i;
        String str;
        String str2;
        List<C1377x> list;
        String str3;
        int i2;
        int i3;
        AbstractC1656z abstractC1656zY = AbstractC1656z.y();
        if (c1375v2 != null) {
            str2 = c1375v2.k;
            c = c1375v2.l;
            i2 = c1375v2.G;
            i = c1375v2.e;
            i3 = c1375v2.f;
            str = c1375v2.d;
            str3 = c1375v2.b;
            list = c1375v2.c;
        } else {
            String strS = d0.S(c1375v.k, 1);
            c = c1375v.l;
            if (z) {
                i2 = c1375v.G;
                i = c1375v.e;
                i3 = c1375v.f;
                str = c1375v.d;
                str3 = c1375v.b;
                str2 = strS;
                list = c1375v.c;
            } else {
                i = 0;
                str = null;
                str2 = strS;
                list = abstractC1656zY;
                str3 = null;
                i2 = -1;
                i3 = 0;
            }
        }
        return new C1375v.b().j0(c1375v.a).l0(str3).m0(list).W(c1375v.n).y0(D.g(str2)).U(str2).r0(c).S(z ? c1375v.h : -1).t0(z ? c1375v.i : -1).T(i2).A0(i).w0(i3).n0(str).P();
    }

    private static Map<String, C1369o> B(List<C1369o> list) {
        ArrayList arrayList = new ArrayList(list);
        HashMap map = new HashMap();
        int i = 0;
        while (i < arrayList.size()) {
            C1369o c1369oF = list.get(i);
            String str = c1369oF.Y;
            i++;
            int i2 = i;
            while (i2 < arrayList.size()) {
                C1369o c1369o = (C1369o) arrayList.get(i2);
                if (TextUtils.equals(c1369o.Y, str)) {
                    c1369oF = c1369oF.f(c1369o);
                    arrayList.remove(i2);
                } else {
                    i2++;
                }
            }
            map.put(str, c1369oF);
        }
        return map;
    }

    private static C1375v C(C1375v c1375v) {
        String strS = d0.S(c1375v.k, 2);
        return new C1375v.b().j0(c1375v.a).l0(c1375v.b).m0(c1375v.c).W(c1375v.n).y0(D.g(strS)).U(strS).r0(c1375v.l).S(c1375v.h).t0(c1375v.i).F0(c1375v.v).h0(c1375v.w).f0(c1375v.z).A0(c1375v.e).w0(c1375v.f).P();
    }

    static /* synthetic */ int j(g gVar) {
        int i = gVar.z0 - 1;
        gVar.z0 = i;
        return i;
    }

    private void u(long j, List<ax.d1.i.a> list, List<l> list2, List<int[]> list3, Map<String, C1369o> map) {
        ArrayList arrayList = new ArrayList(list.size());
        ArrayList arrayList2 = new ArrayList(list.size());
        ArrayList arrayList3 = new ArrayList(list.size());
        HashSet hashSet = new HashSet();
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i).d;
            if (hashSet.add(str)) {
                arrayList.clear();
                arrayList2.clear();
                arrayList3.clear();
                boolean z = true;
                for (int i2 = 0; i2 < list.size(); i2++) {
                    if (Objects.equals(str, list.get(i2).d)) {
                        ax.d1.i.a aVar = list.get(i2);
                        arrayList3.add(Integer.valueOf(i2));
                        arrayList.add(aVar.a);
                        arrayList2.add(aVar.b);
                        z &= d0.R(aVar.b.k, 1) == 1;
                    }
                }
                String str2 = "audio:" + str;
                l lVarZ = z(str2, 1, (Uri[]) arrayList.toArray((Uri[]) d0.j(new Uri[0])), (C1375v[]) arrayList2.toArray(new C1375v[0]), null, Collections.EMPTY_LIST, map, j);
                list3.add(ax.p027b8.f.o(arrayList3));
                list2.add(lVarZ);
                if (this.s0 && z) {
                    lVarZ.h0(new P[]{new P(str2, (C1375v[]) arrayList2.toArray(new C1375v[0]))}, 0, new int[0]);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:25:0x0064  */
    /* JADX WARN: Code duplicated, block: B:46:0x00b0  */
    private void w(ax.p052d1.i iVar, long j, List<l> list, List<int[]> list2, Map<String, C1369o> map) {
        int i;
        boolean z;
        boolean z2;
        Uri[] uriArr;
        C1375v[] c1375vArr;
        int[] iArr;
        int i2;
        int i3;
        int i4;
        int size = iVar.e.size();
        int[] iArr2 = new int[size];
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < iVar.e.size(); i7++) {
            C1375v c1375v = iVar.e.get(i7).b;
            if (c1375v.w > 0 || d0.S(c1375v.k, 2) != null) {
                iArr2[i7] = 2;
                i5++;
            } else if (d0.S(c1375v.k, 1) != null) {
                iArr2[i7] = 1;
                i6++;
            } else {
                iArr2[i7] = -1;
            }
        }
        if (i5 <= 0) {
            if (i6 < size) {
                i = size - i6;
                z = false;
                z2 = true;
            } else {
                i = size;
                z = false;
            }
            uriArr = new Uri[i];
            c1375vArr = new C1375v[i];
            iArr = new int[i];
            i3 = 0;
            for (i2 = 0; i2 < iVar.e.size(); i2++) {
                if ((z || iArr2[i2] == 2) && (!z2 || iArr2[i2] != 1)) {
                    ax.d1.i.b bVar = iVar.e.get(i2);
                    uriArr[i3] = bVar.a;
                    c1375vArr[i3] = bVar.b;
                    iArr[i3] = i2;
                    i3++;
                }
            }
            String str = c1375vArr[0].k;
            int iR = d0.R(str, 2);
            int iR2 = d0.R(str, 1);
            boolean z3 = (iR2 != 1 || (iR2 == 0 && iVar.g.isEmpty())) && iR <= 1 && iR2 + iR > 0;
            if (!z || iR2 <= 0) {
                i4 = 0;
            } else {
                i4 = 1;
            }
            l lVarZ = z("main", i4, uriArr, c1375vArr, iVar.j, iVar.k, map, j);
            list.add(lVarZ);
            list2.add(iArr);
            if (this.s0 || !z3) {
            }
            ArrayList arrayList = new ArrayList();
            if (iR > 0) {
                C1375v[] c1375vArr2 = new C1375v[i];
                for (int i8 = 0; i8 < i; i8++) {
                    c1375vArr2[i8] = C(c1375vArr[i8]);
                }
                arrayList.add(new P("main", c1375vArr2));
                if (iR2 > 0 && (iVar.j != null || iVar.g.isEmpty())) {
                    arrayList.add(new P("main:audio", A(c1375vArr[0], iVar.j, false)));
                }
                List<C1375v> list3 = iVar.k;
                if (list3 != null) {
                    for (int i9 = 0; i9 < list3.size(); i9++) {
                        arrayList.add(new P("main:cc:" + i9, this.q.d(list3.get(i9))));
                    }
                }
            } else {
                C1375v[] c1375vArr3 = new C1375v[i];
                for (int i10 = 0; i10 < i; i10++) {
                    c1375vArr3[i10] = A(c1375vArr[i10], iVar.j, true);
                }
                arrayList.add(new P("main", c1375vArr3));
            }
            P p = new P("main:id3", new C1375v.b().j0("ID3").y0("application/id3").P());
            arrayList.add(p);
            lVarZ.h0((P[]) arrayList.toArray(new P[0]), 0, arrayList.indexOf(p));
            return;
        }
        i = i5;
        z = true;
        z2 = false;
        uriArr = new Uri[i];
        c1375vArr = new C1375v[i];
        iArr = new int[i];
        i3 = 0;
        while (i2 < iVar.e.size()) {
            if (z) {
                ax.d1.i.b bVar2 = iVar.e.get(i2);
                uriArr[i3] = bVar2.a;
                c1375vArr[i3] = bVar2.b;
                iArr[i3] = i2;
                i3++;
            } else {
                ax.d1.i.b bVar3 = iVar.e.get(i2);
                uriArr[i3] = bVar3.a;
                c1375vArr[i3] = bVar3.b;
                iArr[i3] = i2;
                i3++;
            }
        }
        String str2 = c1375vArr[0].k;
        int iR3 = d0.R(str2, 2);
        int iR4 = d0.R(str2, 1);
        if (iR4 != 1) {
        }
        if (z) {
            i4 = 0;
        } else {
            i4 = 0;
        }
        l lVarZ2 = z("main", i4, uriArr, c1375vArr, iVar.j, iVar.k, map, j);
        list.add(lVarZ2);
        list2.add(iArr);
        if (this.s0) {
        }
    }

    private void x(long j) {
        long j2;
        ax.p052d1.i iVar = (ax.p052d1.i) C1498a.e(this.X.h());
        Map<String, C1369o> mapB = this.u0 ? B(iVar.m) : Collections.EMPTY_MAP;
        boolean zIsEmpty = iVar.e.isEmpty();
        List<ax.d1.i.a> list = iVar.g;
        List<ax.d1.i.a> list2 = iVar.h;
        this.z0 = 0;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (zIsEmpty) {
            j2 = j;
        } else {
            w(iVar, j, arrayList, arrayList2, mapB);
            arrayList = arrayList;
            j2 = j;
        }
        u(j2, list, arrayList, arrayList2, mapB);
        this.E0 = arrayList.size();
        y(j2, list2, arrayList, arrayList2, mapB);
        this.B0 = (l[]) arrayList.toArray(new l[0]);
        this.D0 = (int[][]) arrayList2.toArray(new int[0][]);
        this.z0 = this.B0.length;
        for (int i = 0; i < this.E0; i++) {
            this.B0[i].q0(true);
        }
        for (l lVar : this.B0) {
            lVar.D();
        }
        this.C0 = this.B0;
    }

    private void y(long j, List<ax.d1.i.a> list, List<l> list2, List<int[]> list3, Map<String, C1369o> map) {
        List<ax.d1.i.a> list4 = list;
        int i = 1;
        ArrayList arrayList = new ArrayList(list4.size());
        ArrayList arrayList2 = new ArrayList(list4.size());
        ArrayList arrayList3 = new ArrayList(list4.size());
        HashSet hashSet = new HashSet();
        int i2 = 0;
        int i3 = 0;
        while (i3 < list4.size()) {
            String str = list4.get(i3).d;
            if (hashSet.add(str)) {
                arrayList.clear();
                arrayList2.clear();
                arrayList3.clear();
                for (int i4 = 0; i4 < list4.size(); i4 += i) {
                    if (Objects.equals(str, list4.get(i4).d)) {
                        ax.d1.i.a aVar = list4.get(i4);
                        arrayList3.add(Integer.valueOf(i4));
                        arrayList.add(aVar.a);
                        arrayList2.add(aVar.b);
                    }
                }
                String str2 = "subtitle:" + str;
                C1375v[] c1375vArr = (C1375v[]) arrayList2.toArray(new C1375v[i2]);
                l lVarZ = z(str2, 3, (Uri[]) arrayList.toArray((Uri[]) d0.j(new Uri[i2])), c1375vArr, null, AbstractC1656z.y(), map, j);
                list3.add(ax.p027b8.f.o(arrayList3));
                list2.add(lVarZ);
                int length = c1375vArr.length;
                C1375v[] c1375vArr2 = new C1375v[length];
                for (int i5 = 0; i5 < length; i5++) {
                    c1375vArr2[i5] = this.q.d(c1375vArr[i5]);
                }
                i = 1;
                lVarZ.h0(new P[]{new P(str2, c1375vArr2)}, 0, new int[0]);
            }
            i3 += i;
            list4 = list;
            i2 = 0;
        }
    }

    private l z(String str, int i, Uri[] uriArr, C1375v[] c1375vArr, C1375v c1375v, List<C1375v> list, Map<String, C1369o> map, long j) {
        return new l(str, i, this.w0, new c(this.q, this.X, uriArr, c1375vArr, this.Y, this.Z, this.q0, this.x0, list, this.v0, null), map, this.o0, j, c1375v, this.k0, this.l0, this.m0, this.n0, this.t0);
    }

    public void D() {
        this.X.f(this);
        for (l lVar : this.B0) {
            lVar.j0();
        }
        this.y0 = null;
    }

    @Override // ax.p132i1.C, ax.p132i1.f0
    public boolean a(C0639p0 c0639p0) {
        if (this.A0 != null) {
            return this.F0.a(c0639p0);
        }
        for (l lVar : this.B0) {
            lVar.D();
        }
        return false;
    }

    @Override // ax.p132i1.C, ax.p132i1.f0
    public long b() {
        return this.F0.b();
    }

    @Override // ax.p132i1.C, ax.p132i1.f0
    public boolean c() {
        return this.F0.c();
    }

    @Override // ax.p132i1.C, ax.p132i1.f0
    public long d() {
        return this.F0.d();
    }

    @Override // ax.p132i1.C, ax.p132i1.f0
    public void e(long j) {
        this.F0.e(j);
    }

    @Override // ax.d1.m.b
    public void f() {
        for (l lVar : this.B0) {
            lVar.f0();
        }
        this.y0.i(this);
    }

    /* JADX WARN: Code duplicated, block: B:55:0x00d6  */
    @Override // ax.p132i1.C
    public long g(ax.p180l1.D[] dArr, boolean[] zArr, e0[] e0VarArr, boolean[] zArr2, long j) {
        int[] iArr = new int[dArr.length];
        int[] iArr2 = new int[dArr.length];
        for (int i = 0; i < dArr.length; i++) {
            e0 e0Var = e0VarArr[i];
            iArr[i] = e0Var == null ? -1 : this.p0.get(e0Var).intValue();
            iArr2[i] = -1;
            ax.p180l1.D d = dArr[i];
            if (d != null) {
                P pB = d.b();
                int i2 = 0;
                while (true) {
                    l[] lVarArr = this.B0;
                    if (i2 >= lVarArr.length) {
                        break;
                    }
                    if (lVarArr[i2].t().e(pB) != -1) {
                        iArr2[i] = i2;
                        break;
                    }
                    i2++;
                }
            }
        }
        this.p0.clear();
        int length = dArr.length;
        e0[] e0VarArr2 = new e0[length];
        e0[] e0VarArr3 = new e0[dArr.length];
        ax.p180l1.D[] dArr2 = new ax.p180l1.D[dArr.length];
        l[] lVarArr2 = new l[this.B0.length];
        int i3 = 0;
        int i4 = 0;
        boolean z = false;
        while (i3 < this.B0.length) {
            for (int i5 = 0; i5 < dArr.length; i5++) {
                ax.p180l1.D d2 = null;
                e0VarArr3[i5] = iArr[i5] == i3 ? e0VarArr[i5] : null;
                if (iArr2[i5] == i3) {
                    d2 = dArr[i5];
                }
                dArr2[i5] = d2;
            }
            l lVar = this.B0[i3];
            int[] iArr3 = iArr;
            int i6 = i3;
            int i7 = i4;
            boolean zN0 = lVar.n0(dArr2, zArr, e0VarArr3, zArr2, j, z);
            boolean z2 = false;
            for (int i8 = 0; i8 < dArr.length; i8++) {
                e0 e0Var2 = e0VarArr3[i8];
                if (iArr2[i8] == i6) {
                    C1498a.e(e0Var2);
                    e0VarArr2[i8] = e0Var2;
                    this.p0.put(e0Var2, Integer.valueOf(i6));
                    z2 = true;
                } else if (iArr3[i8] == i6) {
                    C1498a.g(e0Var2 == null);
                }
            }
            if (z2) {
                lVarArr2[i7] = lVar;
                i4 = i7 + 1;
                if (i7 == 0) {
                    lVar.q0(true);
                    if (zN0) {
                        this.q0.b();
                        z = true;
                    } else {
                        l[] lVarArr3 = this.C0;
                        if (lVarArr3.length == 0 || lVar != lVarArr3[0]) {
                            this.q0.b();
                            z = true;
                        }
                    }
                } else {
                    lVar.q0(i6 < this.E0);
                }
            } else {
                i4 = i7;
            }
            i3 = i6 + 1;
            iArr = iArr3;
        }
        System.arraycopy(e0VarArr2, 0, e0VarArr, 0, length);
        l[] lVarArr4 = (l[]) d0.g1(lVarArr2, i4);
        this.C0 = lVarArr4;
        AbstractC1656z abstractC1656zV = AbstractC1656z.v(lVarArr4);
        this.F0 = this.r0.a(abstractC1656zV, I.i(abstractC1656zV, new ax.X7.f() { // from class: androidx.media3.exoplayer.hls.f
            @Override // ax.X7.f
            public final Object apply(Object obj) {
                return ((l) obj).t().d();
            }
        }));
        return j;
    }

    @Override // ax.d1.m.b
    public boolean h(Uri uri, ax.m1.m.c cVar, boolean z) {
        boolean zE0 = true;
        for (l lVar : this.B0) {
            zE0 &= lVar.e0(uri, cVar, z);
        }
        this.y0.i(this);
        return zE0;
    }

    @Override // ax.p132i1.C
    public void l() throws IOException {
        for (l lVar : this.B0) {
            lVar.l();
        }
    }

    @Override // ax.p132i1.C
    public long m(long j) {
        l[] lVarArr = this.C0;
        if (lVarArr.length > 0) {
            boolean zM0 = lVarArr[0].m0(j, false);
            int i = 1;
            while (true) {
                l[] lVarArr2 = this.C0;
                if (i >= lVarArr2.length) {
                    break;
                }
                lVarArr2[i].m0(j, zM0);
                i++;
            }
            if (zM0) {
                this.q0.b();
            }
        }
        return j;
    }

    @Override // ax.p132i1.C
    public void n(C.a aVar, long j) {
        this.y0 = aVar;
        this.X.o(this);
        x(j);
    }

    @Override // ax.p132i1.C
    public long q(long j, Z z) {
        for (l lVar : this.C0) {
            if (lVar.T()) {
                return lVar.q(j, z);
            }
        }
        return j;
    }

    @Override // ax.p132i1.C
    public long s() {
        return -9223372036854775807L;
    }

    @Override // ax.p132i1.C
    public q0 t() {
        return (q0) C1498a.e(this.A0);
    }

    @Override // ax.p132i1.C
    public void v(long j, boolean z) {
        for (l lVar : this.C0) {
            lVar.v(j, z);
        }
    }
}
