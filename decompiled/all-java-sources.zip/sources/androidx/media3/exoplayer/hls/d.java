package androidx.media3.exoplayer.hls;

/* JADX INFO: loaded from: classes.dex */
public final class d {
    public final ax.p052d1.i a;
    public final ax.p052d1.f b;

    d(ax.p052d1.i iVar, ax.p052d1.f fVar) {
        this.a = iVar;
        this.b = fVar;
    }
}
