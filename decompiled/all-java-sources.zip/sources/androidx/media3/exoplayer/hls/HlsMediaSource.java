package androidx.media3.exoplayer.hls;

import android.os.Looper;
import ax.N1.t;
import ax.P0.C1378y;
import ax.P0.C1379z;
import ax.P0.L;
import ax.S0.C1498a;
import ax.S0.d0;
import ax.U0.z;
import ax.p020b1.C1822l;
import ax.p020b1.w;
import ax.p052d1.m;
import ax.p132i1.AbstractC2094a;
import ax.p132i1.C;
import ax.p132i1.C2104k;
import ax.p132i1.F;
import ax.p132i1.InterfaceC2103j;
import ax.p132i1.N;
import ax.p132i1.O;
import ax.p132i1.h0;
import java.io.IOException;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class HlsMediaSource extends AbstractC2094a implements m.e {
    private final ax.p036c1.e h;
    private final ax.p036c1.d i;
    private final InterfaceC2103j j;
    private final w k;
    private final ax.p196m1.m l;
    private final boolean m;
    private final int n;
    private final boolean o;
    private final m p;
    private final long q;
    private final long r;
    private C1378y.g s;
    private z t;
    private C1378y u;

    public static final class Factory implements O {
        private final ax.p036c1.d a;
        private ax.p036c1.e b;
        private t.a c;
        private boolean d;
        private int e;
        private ax.p052d1.l f;
        private m.a g;
        private InterfaceC2103j h;
        private ax.m1.f.a i;
        private ax.p020b1.z j;
        private ax.p196m1.m k;
        private boolean l;
        private int m;
        private boolean n;
        private long o;
        private long p;

        public Factory(ax.U0.g.a aVar) {
            this(new ax.p036c1.b(aVar));
        }

        public Factory(ax.p036c1.d dVar) {
            this.a = (ax.p036c1.d) C1498a.e(dVar);
            this.j = new C1822l();
            this.f = new ax.p052d1.a();
            this.g = ax.p052d1.c.v0;
            this.k = new ax.p196m1.k();
            this.h = new C2104k();
            this.m = 1;
            this.o = -9223372036854775807L;
            this.l = true;
            c(true);
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
        public HlsMediaSource e(C1378y c1378y) {
            C1498a.e(c1378y.b);
            if (this.b == null) {
                this.b = new ax.p036c1.c();
            }
            t.a aVar = this.c;
            if (aVar != null) {
                this.b.a(aVar);
            }
            this.b.c(this.d);
            this.b.b(this.e);
            ax.p036c1.e eVar = this.b;
            ax.p052d1.l eVar2 = this.f;
            List<L> list = c1378y.b.d;
            if (!list.isEmpty()) {
                eVar2 = new ax.p052d1.e(eVar2, list);
            }
            ax.m1.f.a aVar2 = this.i;
            if (aVar2 != null) {
                aVar2.a(c1378y);
            }
            ax.p036c1.d dVar = this.a;
            InterfaceC2103j interfaceC2103j = this.h;
            w wVarA = this.j.a(c1378y);
            ax.p196m1.m mVar = this.k;
            return new HlsMediaSource(c1378y, dVar, eVar, interfaceC2103j, null, wVarA, mVar, this.g.a(this.a, mVar, eVar2, null), this.o, this.l, this.m, this.n, this.p);
        }

        @Override // ax.i1.F.a
        @Deprecated
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public Factory c(boolean z) {
            this.d = z;
            return this;
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public Factory b(int i) {
            this.e = i;
            return this;
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
        public Factory d(ax.m1.f.a aVar) {
            this.i = (ax.m1.f.a) C1498a.e(aVar);
            return this;
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: l, reason: merged with bridge method [inline-methods] */
        public Factory f(ax.p020b1.z zVar) {
            this.j = (ax.p020b1.z) C1498a.f(zVar, "MediaSource.Factory#setDrmSessionManagerProvider no longer handles null by instantiating a new DefaultDrmSessionManagerProvider. Explicitly construct and pass an instance in order to retain the old behavior.");
            return this;
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public Factory g(ax.p196m1.m mVar) {
            this.k = (ax.p196m1.m) C1498a.f(mVar, "MediaSource.Factory#setLoadErrorHandlingPolicy no longer handles null by instantiating a new DefaultLoadErrorHandlingPolicy. Explicitly construct and pass an instance in order to retain the old behavior.");
            return this;
        }

        @Override // ax.i1.F.a
        /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
        public Factory a(t.a aVar) {
            this.c = aVar;
            return this;
        }
    }

    static {
        C1379z.a("media3.exoplayer.hls");
    }

    private HlsMediaSource(C1378y c1378y, ax.p036c1.d dVar, ax.p036c1.e eVar, InterfaceC2103j interfaceC2103j, ax.p196m1.f fVar, w wVar, ax.p196m1.m mVar, m mVar2, long j, boolean z, int i, boolean z2, long j2) {
        this.u = c1378y;
        this.s = c1378y.d;
        this.i = dVar;
        this.h = eVar;
        this.j = interfaceC2103j;
        this.k = wVar;
        this.l = mVar;
        this.p = mVar2;
        this.q = j;
        this.m = z;
        this.n = i;
        this.o = z2;
        this.r = j2;
    }

    private h0 D(ax.p052d1.f fVar, long j, long j2, d dVar) {
        long jE = fVar.h - this.p.e();
        long j3 = fVar.o ? jE + fVar.u : -9223372036854775807L;
        long jH = H(fVar);
        long j4 = this.s.a;
        K(fVar, d0.q(j4 != -9223372036854775807L ? d0.a1(j4) : J(fVar, jH), jH, fVar.u + jH));
        return new h0(j, j2, -9223372036854775807L, j3, fVar.u, jE, I(fVar, jH), true, !fVar.o, fVar.d == 2 && fVar.f, dVar, j(), this.s);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x002e  */
    private h0 E(ax.p052d1.f fVar, long j, long j2, d dVar) {
        long j3;
        if (fVar.e == -9223372036854775807L || fVar.r.isEmpty()) {
            j3 = 0;
        } else if (fVar.g) {
            j3 = fVar.e;
        } else {
            long j4 = fVar.e;
            if (j4 == fVar.u) {
                j3 = fVar.e;
            } else {
                j3 = G(fVar.r, j4).k0;
            }
        }
        long j5 = j3;
        long j6 = fVar.u;
        return new h0(j, j2, -9223372036854775807L, j6, j6, 0L, j5, true, false, true, dVar, j(), null);
    }

    private static ax.d1.f.d F(List<ax.d1.f.d> list, long j) {
        ax.d1.f.d dVar = null;
        for (int i = 0; i < list.size(); i++) {
            ax.d1.f.d dVar2 = list.get(i);
            long j2 = dVar2.k0;
            if (j2 > j || !dVar2.r0) {
                if (j2 > j) {
                    break;
                }
            } else {
                dVar = dVar2;
            }
        }
        return dVar;
    }

    private static ax.p052d1.f.C0311f G(List<ax.p052d1.f.C0311f> list, long j) {
        return list.get(d0.f(list, Long.valueOf(j), true, true));
    }

    private long H(ax.p052d1.f fVar) {
        if (fVar.p) {
            return d0.a1(d0.i0(this.q)) - fVar.e();
        }
        return 0L;
    }

    private long I(ax.p052d1.f fVar, long j) {
        long jA1 = fVar.e;
        if (jA1 == -9223372036854775807L) {
            jA1 = (fVar.u + j) - d0.a1(this.s.a);
        }
        if (fVar.g) {
            return jA1;
        }
        ax.d1.f.d dVarF = F(fVar.s, jA1);
        if (dVarF != null) {
            return dVarF.k0;
        }
        if (fVar.r.isEmpty()) {
            return 0L;
        }
        ax.p052d1.f.C0311f c0311fG = G(fVar.r, jA1);
        ax.d1.f.d dVarF2 = F(c0311fG.s0, jA1);
        return dVarF2 != null ? dVarF2.k0 : c0311fG.k0;
    }

    private static long J(ax.p052d1.f fVar, long j) {
        long j2;
        ax.d1.f.h hVar = fVar.v;
        long j3 = fVar.e;
        if (j3 != -9223372036854775807L) {
            j2 = fVar.u - j3;
        } else {
            long j4 = hVar.d;
            if (j4 == -9223372036854775807L || fVar.n == -9223372036854775807L) {
                long j5 = hVar.c;
                j2 = j5 != -9223372036854775807L ? j5 : fVar.m * 3;
            } else {
                j2 = j4;
            }
        }
        return j2 + j;
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002a  */
    private void K(ax.p052d1.f fVar, long j) {
        boolean z;
        C1378y.g gVar = j().d;
        if (gVar.d == -3.4028235E38f && gVar.e == -3.4028235E38f) {
            ax.d1.f.h hVar = fVar.v;
            if (hVar.c == -9223372036854775807L && hVar.d == -9223372036854775807L) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = false;
        }
        this.s = new C1378y.g.a().k(d0.E1(j)).j(z ? 1.0f : this.s.d).h(z ? 1.0f : this.s.e).f();
    }

    @Override // ax.p132i1.AbstractC2094a
    protected void A(z zVar) {
        this.t = zVar;
        this.k.c((Looper) C1498a.e(Looper.myLooper()), x());
        this.k.d0();
        this.p.d(((C1378y.h) C1498a.e(j().b)).a, u(null), this);
    }

    @Override // ax.p132i1.AbstractC2094a
    protected void C() {
        this.p.stop();
        this.k.h();
    }

    @Override // ax.p132i1.AbstractC2094a, ax.p132i1.F
    public synchronized void a(C1378y c1378y) {
        this.u = c1378y;
    }

    @Override // ax.p132i1.F
    public void e(C c) {
        ((g) c).D();
    }

    @Override // ax.d1.m.e
    public void f(ax.p052d1.f fVar) {
        long jE1 = fVar.p ? d0.E1(fVar.h) : -9223372036854775807L;
        int i = fVar.d;
        long j = (i == 2 || i == 1) ? jE1 : -9223372036854775807L;
        d dVar = new d((ax.p052d1.i) C1498a.e(this.p.h()), fVar);
        B(this.p.g() ? D(fVar, j, jE1, dVar) : E(fVar, j, jE1, dVar));
    }

    @Override // ax.p132i1.F
    public C i(F.b bVar, ax.p196m1.b bVar2, long j) {
        N.a aVarU = u(bVar);
        return new g(this.h, this.p, this.i, this.t, null, this.k, s(bVar), this.l, aVarU, bVar2, this.j, this.m, this.n, this.o, x(), this.r);
    }

    @Override // ax.p132i1.F
    public synchronized C1378y j() {
        return this.u;
    }

    @Override // ax.p132i1.F
    public void k() throws IOException {
        this.p.l();
    }
}
