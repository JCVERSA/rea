package androidx.media3.exoplayer.hls;

import android.net.Uri;
import android.os.SystemClock;
import android.util.Pair;
import androidx.media3.exoplayer.C0639p0;
import ax.P0.C1375v;
import ax.P0.P;
import ax.S0.C1498a;
import ax.S0.O;
import ax.S0.d0;
import ax.U0.z;
import ax.Y0.Z;
import ax.Y7.AbstractC1656z;
import ax.Y7.F;
import ax.Z0.I1;
import ax.p052d1.m;
import ax.p132i1.C2095b;
import ax.p180l1.AbstractC2142c;
import ax.p180l1.D;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import okhttp3.internal.http2.Http2;

/* JADX INFO: loaded from: classes.dex */
class c {
    private final ax.p036c1.e a;
    private final ax.U0.g b;
    private final ax.U0.g c;
    private final ax.p036c1.j d;
    private final Uri[] e;
    private final C1375v[] f;
    private final m g;
    private final P h;
    private final List<C1375v> i;
    private final I1 k;
    private final long l;
    private boolean m;
    private IOException o;
    private Uri p;
    private Uri q;
    private boolean r;
    private D s;
    private long u = -9223372036854775807L;
    private final androidx.media3.exoplayer.hls.b j = new androidx.media3.exoplayer.hls.b(4);
    private byte[] n = d0.f;
    private long t = -9223372036854775807L;

    private static final class a extends ax.p148j1.c {
        private byte[] l;

        public a(ax.U0.g gVar, ax.U0.k kVar, C1375v c1375v, int i, Object obj, byte[] bArr) {
            super(gVar, kVar, 3, c1375v, i, obj, bArr);
        }

        @Override // ax.p148j1.c
        protected void g(byte[] bArr, int i) {
            this.l = Arrays.copyOf(bArr, i);
        }

        public byte[] j() {
            return this.l;
        }
    }

    public static final class b {
        public ax.p148j1.b a;
        public boolean b;
        public Uri c;

        public b() {
            a();
        }

        public void a() {
            this.a = null;
            this.b = false;
            this.c = null;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.hls.c$c, reason: collision with other inner class name */
    static final class C0030c extends ax.p148j1.a {
        private final List<ax.d1.f.g> e;
        private final long f;
        private final String g;

        public C0030c(String str, long j, List<ax.d1.f.g> list) {
            super(0L, list.size() - 1);
            this.g = str;
            this.f = j;
            this.e = list;
        }

        @Override // ax.p148j1.e
        public long a() {
            c();
            return this.f + this.e.get((int) d()).k0;
        }

        @Override // ax.p148j1.e
        public long b() {
            c();
            ax.d1.f.g gVar = this.e.get((int) d());
            return this.f + gVar.k0 + gVar.Y;
        }
    }

    private static final class d extends AbstractC2142c {
        private int i;

        public d(P p, int[] iArr) {
            super(p, iArr);
            this.i = v(p.b(iArr[0]));
        }

        @Override // ax.p180l1.D
        public void c(long j, long j2, long j3, List<? extends ax.p148j1.d> list, ax.p148j1.e[] eVarArr) {
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            if (a(this.i, jElapsedRealtime)) {
                for (int i = this.b - 1; i >= 0; i--) {
                    if (!a(i, jElapsedRealtime)) {
                        this.i = i;
                        return;
                    }
                }
                throw new IllegalStateException();
            }
        }

        @Override // ax.p180l1.D
        public int d() {
            return this.i;
        }

        @Override // ax.p180l1.D
        public int n() {
            return 0;
        }

        @Override // ax.p180l1.D
        public Object q() {
            return null;
        }
    }

    static final class e {
        public final ax.d1.f.g a;
        public final long b;
        public final int c;
        public final boolean d;

        public e(ax.d1.f.g gVar, long j, int i) {
            this.a = gVar;
            this.b = j;
            this.c = i;
            this.d = (gVar instanceof ax.d1.f.d) && ((ax.d1.f.d) gVar).s0;
        }
    }

    public c(ax.p036c1.e eVar, m mVar, Uri[] uriArr, C1375v[] c1375vArr, ax.p036c1.d dVar, z zVar, ax.p036c1.j jVar, long j, List<C1375v> list, I1 i1, ax.p196m1.f fVar) {
        this.a = eVar;
        this.g = mVar;
        this.e = uriArr;
        this.f = c1375vArr;
        this.d = jVar;
        this.l = j;
        this.i = list;
        this.k = i1;
        ax.U0.g gVarA = dVar.a(1);
        this.b = gVarA;
        if (zVar != null) {
            gVarA.d(zVar);
        }
        this.c = dVar.a(3);
        this.h = new P(c1375vArr);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < uriArr.length; i++) {
            if ((c1375vArr[i].f & Http2.INITIAL_MAX_FRAME_SIZE) == 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        this.s = new d(this.h, ax.p027b8.f.o(arrayList));
    }

    private static boolean A(boolean z, ax.p052d1.f fVar, long j, int i, androidx.media3.exoplayer.hls.e eVar, long j2, long j3) {
        if (!z || eVar == null) {
            return false;
        }
        if (j < fVar.k) {
            return true;
        }
        e eVarH = h(fVar, j, i);
        return eVarH != null && j2 + eVarH.a.k0 < j3;
    }

    private void B(ax.p052d1.f fVar) {
        this.t = fVar.o ? -9223372036854775807L : fVar.e() - this.g.e();
    }

    private void b() {
        this.g.b(this.e[this.s.l()]);
    }

    private static Uri e(ax.p052d1.f fVar, ax.d1.f.g gVar) {
        String str;
        if (gVar == null || (str = gVar.m0) == null) {
            return null;
        }
        return O.d(fVar.a, str);
    }

    private Pair<Long, Integer> g(androidx.media3.exoplayer.hls.e eVar, boolean z, ax.p052d1.f fVar, long j, long j2) {
        int i = -1;
        if (eVar != null && !z) {
            if (!eVar.q()) {
                return new Pair<>(Long.valueOf(eVar.j), Integer.valueOf(eVar.o));
            }
            Long lValueOf = Long.valueOf(eVar.o == -1 ? eVar.g() : eVar.j);
            int i2 = eVar.o;
            return new Pair<>(lValueOf, Integer.valueOf(i2 != -1 ? i2 + 1 : -1));
        }
        long j3 = fVar.u + j;
        if (eVar != null && !this.r) {
            j2 = eVar.g;
        }
        if (!fVar.o && j2 >= j3) {
            return new Pair<>(Long.valueOf(fVar.k + ((long) fVar.r.size())), -1);
        }
        long j4 = j2 - j;
        int iF = d0.f(fVar.r, Long.valueOf(j4), true, !this.g.g() || eVar == null);
        long j5 = ((long) iF) + fVar.k;
        if (iF >= 0) {
            ax.p052d1.f.C0311f c0311f = fVar.r.get(iF);
            List<ax.d1.f.d> list = j4 < c0311f.k0 + c0311f.Y ? c0311f.s0 : fVar.s;
            for (int i3 = 0; i3 < list.size(); i3++) {
                ax.d1.f.d dVar = list.get(i3);
                if (j4 < dVar.k0 + dVar.Y) {
                    if (!dVar.r0) {
                        break;
                    }
                    j5 += list == fVar.s ? 1L : 0L;
                    i = i3;
                    break;
                }
            }
        }
        return new Pair<>(Long.valueOf(j5), Integer.valueOf(i));
    }

    private static e h(ax.p052d1.f fVar, long j, int i) {
        int i2 = (int) (j - fVar.k);
        if (i2 == fVar.r.size()) {
            if (i == -1) {
                i = 0;
            }
            if (i < fVar.s.size()) {
                return new e(fVar.s.get(i), j, i);
            }
            return null;
        }
        ax.p052d1.f.C0311f c0311f = fVar.r.get(i2);
        if (i == -1) {
            return new e(c0311f, j, -1);
        }
        if (i < c0311f.s0.size()) {
            return new e(c0311f.s0.get(i), j, i);
        }
        int i3 = i2 + 1;
        if (i3 < fVar.r.size()) {
            return new e(fVar.r.get(i3), j + 1, -1);
        }
        if (fVar.s.isEmpty()) {
            return null;
        }
        return new e(fVar.s.get(0), j + 1, 0);
    }

    static List<ax.d1.f.g> k(ax.p052d1.f fVar, long j, int i) {
        int i2 = (int) (j - fVar.k);
        if (i2 < 0 || fVar.r.size() < i2) {
            return AbstractC1656z.y();
        }
        ArrayList arrayList = new ArrayList();
        if (i2 < fVar.r.size()) {
            if (i != -1) {
                ax.p052d1.f.C0311f c0311f = fVar.r.get(i2);
                if (i == 0) {
                    arrayList.add(c0311f);
                } else if (i < c0311f.s0.size()) {
                    List<ax.d1.f.d> list = c0311f.s0;
                    arrayList.addAll(list.subList(i, list.size()));
                }
                i2++;
            }
            List<ax.p052d1.f.C0311f> list2 = fVar.r;
            arrayList.addAll(list2.subList(i2, list2.size()));
            i = 0;
        }
        if (fVar.n != -9223372036854775807L) {
            int i3 = i != -1 ? i : 0;
            if (i3 < fVar.s.size()) {
                List<ax.d1.f.d> list3 = fVar.s;
                arrayList.addAll(list3.subList(i3, list3.size()));
            }
        }
        return DesugarCollections.unmodifiableList(arrayList);
    }

    private static boolean o(e eVar, ax.p052d1.f fVar) {
        ax.d1.f.g gVar = eVar.a;
        if (!(gVar instanceof ax.d1.f.d)) {
            return fVar.c;
        }
        if (((ax.d1.f.d) gVar).r0) {
            return true;
        }
        return eVar.c == 0 && fVar.c;
    }

    private ax.p148j1.b p(Uri uri, int i, boolean z, ax.m1.g.a aVar) {
        if (uri == null) {
            return null;
        }
        byte[] bArrC = this.j.c(uri);
        if (bArrC != null) {
            this.j.b(uri, bArrC);
            return null;
        }
        return new a(this.c, new ax.U0.k.b().i(uri).b(1).a(), this.f[i], this.s.n(), this.s.q(), this.n);
    }

    private long w(long j) {
        long j2 = this.t;
        if (j2 != -9223372036854775807L) {
            return j2 - j;
        }
        return -9223372036854775807L;
    }

    public ax.p148j1.e[] a(androidx.media3.exoplayer.hls.e eVar, long j) {
        int iC = eVar == null ? -1 : this.h.c(eVar.d);
        int length = this.s.length();
        ax.p148j1.e[] eVarArr = new ax.p148j1.e[length];
        for (int i = 0; i < length; i++) {
            int iJ = this.s.j(i);
            Uri uri = this.e[iJ];
            if (this.g.a(uri)) {
                ax.p052d1.f fVarN = this.g.n(uri, false);
                C1498a.e(fVarN);
                long jE = fVarN.h - this.g.e();
                Pair<Long, Integer> pairG = g(eVar, iJ != iC, fVarN, jE, j);
                eVarArr[i] = new C0030c(fVarN.a, jE, k(fVarN, ((Long) pairG.first).longValue(), ((Integer) pairG.second).intValue()));
            } else {
                eVarArr[i] = ax.p148j1.e.a;
            }
        }
        return eVarArr;
    }

    public long c(long j, Z z) {
        int iD = this.s.d();
        Uri[] uriArr = this.e;
        ax.p052d1.f fVarN = (iD >= uriArr.length || iD == -1) ? null : this.g.n(uriArr[this.s.l()], true);
        if (fVarN == null || fVarN.r.isEmpty()) {
            return j;
        }
        long jE = fVarN.h - this.g.e();
        long j2 = j - jE;
        int iF = d0.f(fVarN.r, Long.valueOf(j2), true, true);
        long j3 = fVarN.r.get(iF).k0;
        return z.a(j2, j3, (!fVarN.c || iF == fVarN.r.size() - 1) ? j3 : fVarN.r.get(iF + 1).k0) + jE;
    }

    public int d(androidx.media3.exoplayer.hls.e eVar) {
        if (eVar.o == -1) {
            return 1;
        }
        ax.p052d1.f fVar = (ax.p052d1.f) C1498a.e(this.g.n(this.e[this.h.c(eVar.d)], false));
        int i = (int) (eVar.j - fVar.k);
        if (i < 0) {
            return 1;
        }
        List<ax.d1.f.d> list = i < fVar.r.size() ? fVar.r.get(i).s0 : fVar.s;
        if (eVar.o >= list.size()) {
            return 2;
        }
        ax.d1.f.d dVar = list.get(eVar.o);
        if (dVar.s0) {
            return 0;
        }
        return Objects.equals(Uri.parse(O.c(fVar.a, dVar.q)), eVar.b.a) ? 1 : 2;
    }

    public void f(C0639p0 c0639p0, long j, long j2, List<androidx.media3.exoplayer.hls.e> list, boolean z, b bVar) {
        int i;
        int i2;
        long j3;
        boolean z2;
        e eVar;
        Uri uri;
        androidx.media3.exoplayer.hls.e eVar2 = list.isEmpty() ? null : (androidx.media3.exoplayer.hls.e) F.e(list);
        int iC = eVar2 == null ? -1 : this.h.c(eVar2.d);
        long j4 = c0639p0.a;
        long jMax = j - j4;
        long jW = w(j4);
        if (eVar2 != null && !this.r) {
            long jD = eVar2.d();
            jMax = Math.max(0L, jMax - jD);
            if (jW != -9223372036854775807L) {
                jW = Math.max(0L, jW - jD);
            }
        }
        this.s.c(j4, jMax, jW, list, a(eVar2, j));
        int iL = this.s.l();
        boolean z3 = iC != iL;
        Uri uri2 = this.e[iL];
        if (!this.g.a(uri2)) {
            bVar.c = uri2;
            this.q = uri2;
            return;
        }
        ax.p052d1.f fVarN = this.g.n(uri2, true);
        C1498a.e(fVarN);
        this.r = fVarN.c;
        B(fVarN);
        long jE = fVarN.h - this.g.e();
        Pair<Long, Integer> pairG = g(eVar2, z3, fVarN, jE, j);
        long jLongValue = ((Long) pairG.first).longValue();
        int iIntValue = ((Integer) pairG.second).intValue();
        androidx.media3.exoplayer.hls.e eVar3 = eVar2;
        boolean z4 = z3;
        int i3 = iC;
        Uri uri3 = uri2;
        ax.p052d1.f fVar = fVarN;
        long j5 = jLongValue;
        if (A(z4, fVar, j5, iIntValue, eVar3, jE, j2)) {
            Uri uri4 = this.e[i3];
            ax.p052d1.f fVarN2 = this.g.n(uri4, true);
            C1498a.e(fVarN2);
            long jE2 = fVarN2.h - this.g.e();
            i = i3;
            i2 = -1;
            Pair<Long, Integer> pairG2 = g(eVar3, false, fVarN2, jE2, j);
            long jLongValue2 = ((Long) pairG2.first).longValue();
            iIntValue = ((Integer) pairG2.second).intValue();
            fVar = fVarN2;
            uri3 = uri4;
            iL = i;
            j5 = jLongValue2;
            j3 = jE2;
        } else {
            i = i3;
            i2 = -1;
            j3 = jE;
        }
        if (iL != i && i != i2) {
            this.g.b(this.e[i]);
        }
        if (j5 < fVar.k) {
            this.o = new C2095b();
            return;
        }
        e eVarH = h(fVar, j5, iIntValue);
        if (eVarH != null) {
            z2 = true;
            eVar = eVarH;
            uri = null;
        } else if (!fVar.o) {
            bVar.c = uri3;
            this.q = uri3;
            return;
        } else if (z || fVar.r.isEmpty()) {
            bVar.b = true;
            return;
        } else {
            eVar = new e((ax.d1.f.g) F.e(fVar.r), (fVar.k + ((long) fVar.r.size())) - 1, i2);
            uri = null;
            z2 = true;
        }
        this.q = uri;
        this.u = SystemClock.elapsedRealtime();
        Uri uriE = e(fVar, eVar.a.X);
        ax.p148j1.b bVarP = p(uriE, iL, z2, null);
        bVar.a = bVarP;
        if (bVarP == null) {
            Uri uriE2 = e(fVar, eVar.a);
            ax.p148j1.b bVarP2 = p(uriE2, iL, false, null);
            bVar.a = bVarP2;
            if (bVarP2 == null) {
                boolean zO = o(eVar, fVar);
                Uri uri5 = uri3;
                boolean zY = androidx.media3.exoplayer.hls.e.y(eVar3, j, uri5, zO, eVar, j3);
                if (zY && eVar.d) {
                    return;
                }
                bVar.a = androidx.media3.exoplayer.hls.e.j(this.a, this.b, this.f[iL], j3, fVar, eVar, uri5, this.i, this.s.n(), this.s.q(), this.m, this.d, this.l, eVar3, this.j.a(uriE2), this.j.a(uriE), zY, zO, this.k, null);
            }
        }
    }

    public int i(long j, List<? extends ax.p148j1.d> list) {
        return (this.o != null || this.s.length() < 2) ? list.size() : this.s.k(j, list);
    }

    public long j(androidx.media3.exoplayer.hls.e eVar) {
        C1498a.g(eVar.o != -1);
        ax.p052d1.f fVar = (ax.p052d1.f) C1498a.e(this.g.n(this.e[this.h.c(eVar.d)], false));
        int i = (int) (eVar.j - fVar.k);
        if (i < 0) {
            return 0L;
        }
        return (i < fVar.r.size() ? fVar.r.get(i).s0 : fVar.s).get(eVar.o).Y;
    }

    public P l() {
        return this.h;
    }

    public D m() {
        return this.s;
    }

    public boolean n() {
        return this.r;
    }

    public boolean q(ax.p148j1.b bVar, long j) {
        D d2 = this.s;
        return d2.o(d2.t(this.h.c(bVar.d)), j);
    }

    public void r() throws IOException {
        IOException iOException = this.o;
        if (iOException != null) {
            throw iOException;
        }
        Uri uri = this.p;
        if (uri == null || !uri.equals(this.q)) {
            return;
        }
        this.g.c(this.p);
    }

    public boolean s(Uri uri) {
        return d0.s(this.e, uri);
    }

    public void t(ax.p148j1.b bVar) {
        if (bVar instanceof a) {
            a aVar = (a) bVar;
            this.n = aVar.h();
            this.j.b(aVar.b.a, (byte[]) C1498a.e(aVar.j()));
        }
    }

    public boolean u(Uri uri, long j) {
        int iT;
        int i = 0;
        while (true) {
            Uri[] uriArr = this.e;
            if (i >= uriArr.length) {
                i = -1;
                break;
            }
            if (uriArr[i].equals(uri)) {
                break;
            }
            i++;
        }
        if (i == -1 || (iT = this.s.t(i)) == -1) {
            return true;
        }
        this.p = uri;
        return j != -9223372036854775807L && this.s.o(iT, j) && this.g.i(uri, j);
    }

    public void v() {
        b();
        this.o = null;
    }

    public void x(boolean z) {
        this.m = z;
    }

    public void y(D d2) {
        b();
        this.s = d2;
    }

    public boolean z(long j, ax.p148j1.b bVar, List<? extends ax.p148j1.d> list) {
        if (this.o != null) {
            return false;
        }
        return this.s.f(j, bVar, list);
    }
}
