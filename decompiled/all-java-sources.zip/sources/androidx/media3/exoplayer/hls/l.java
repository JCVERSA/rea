package androidx.media3.exoplayer.hls;

import android.net.Uri;
import android.os.Handler;
import android.util.SparseIntArray;
import androidx.media3.exoplayer.C0639p0;
import ax.P0.C;
import ax.P0.C1369o;
import ax.P0.C1375v;
import ax.P0.D;
import ax.P0.E;
import ax.P0.InterfaceC1365k;
import ax.P0.P;
import ax.S0.C1498a;
import ax.S0.C1517u;
import ax.S0.G;
import ax.U0.u;
import ax.Y0.O;
import ax.Y0.Z;
import ax.Y7.AbstractC1656z;
import ax.Y7.F;
import ax.p020b1.InterfaceC1830u;
import ax.p020b1.w;
import ax.p132i1.B;
import ax.p132i1.C2117y;
import ax.p132i1.N;
import ax.p132i1.d0;
import ax.p132i1.e0;
import ax.p132i1.f0;
import ax.p132i1.q0;
import ax.p180l1.I;
import ax.p196m1.m;
import ax.p196m1.o;
import ax.p260q1.C2229o;
import ax.p260q1.InterfaceC2233t;
import ax.p260q1.T;
import ax.p260q1.U;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: loaded from: classes.dex */
public final class l implements o.b<ax.p148j1.b>, o.f, f0, InterfaceC2233t, d0.d {
    private static final Set<Integer> e1 = DesugarCollections.unmodifiableSet(new HashSet(Arrays.asList(1, 2, 5)));
    private ax.p148j1.b A0;
    private d[] B0;
    private Set<Integer> D0;
    private SparseIntArray E0;
    private U F0;
    private int G0;
    private int H0;
    private boolean I0;
    private boolean J0;
    private int K0;
    private C1375v L0;
    private C1375v M0;
    private boolean N0;
    private q0 O0;
    private Set<P> P0;
    private int[] Q0;
    private int R0;
    private boolean S0;
    private boolean[] T0;
    private boolean[] U0;
    private long V0;
    private long W0;
    private final int X;
    private boolean X0;
    private final b Y;
    private boolean Y0;
    private final androidx.media3.exoplayer.hls.c Z;
    private boolean Z0;
    private boolean a1;
    private long b1;
    private C1369o c1;
    private e d1;
    private final ax.p196m1.b k0;
    private final C1375v l0;
    private final w m0;
    private final InterfaceC1830u.a n0;
    private final m o0;
    private final String q;
    private final N.a q0;
    private final int r0;
    private final ArrayList<e> t0;
    private final List<e> u0;
    private final Runnable v0;
    private final Runnable w0;
    private final Handler x0;
    private final ArrayList<h> y0;
    private final Map<String, C1369o> z0;
    private final o p0 = new o("Loader:HlsSampleStreamWrapper");
    private final androidx.media3.exoplayer.hls.c.b s0 = new androidx.media3.exoplayer.hls.c.b();
    private int[] C0 = new int[0];

    public interface b extends f0.a<l> {
        void h();

        void j(Uri uri);
    }

    private static class c implements U {
        private static final C1375v g = new C1375v.b().y0("application/id3").P();
        private static final C1375v h = new C1375v.b().y0("application/x-emsg").P();
        private final ax.B1.b a = new ax.B1.b();
        private final U b;
        private final C1375v c;
        private C1375v d;
        private byte[] e;
        private int f;

        public c(U u, int i) {
            this.b = u;
            if (i == 1) {
                this.c = g;
            } else {
                if (i != 3) {
                    throw new IllegalArgumentException("Unknown metadataType: " + i);
                }
                this.c = h;
            }
            this.e = new byte[0];
            this.f = 0;
        }

        private boolean h(ax.B1.a aVar) {
            C1375v c1375vA = aVar.a();
            return c1375vA != null && Objects.equals(this.c.o, c1375vA.o);
        }

        private void i(int i) {
            byte[] bArr = this.e;
            if (bArr.length < i) {
                this.e = Arrays.copyOf(bArr, i + (i / 2));
            }
        }

        private G j(int i, int i2) {
            int i3 = this.f - i2;
            G g2 = new G(Arrays.copyOfRange(this.e, i3 - i, i3));
            byte[] bArr = this.e;
            System.arraycopy(bArr, i3, bArr, 0, i2);
            this.f = i2;
            return g2;
        }

        @Override // ax.p260q1.U
        public /* synthetic */ int a(InterfaceC1365k interfaceC1365k, int i, boolean z) {
            return T.b(this, interfaceC1365k, i, z);
        }

        @Override // ax.p260q1.U
        public void b(G g2, int i, int i2) {
            i(this.f + i);
            g2.q(this.e, this.f, i);
            this.f += i;
        }

        @Override // ax.p260q1.U
        public int c(InterfaceC1365k interfaceC1365k, int i, boolean z, int i2) throws IOException {
            i(this.f + i);
            int iC = interfaceC1365k.c(this.e, this.f, i);
            if (iC != -1) {
                this.f += iC;
                return iC;
            }
            if (z) {
                return -1;
            }
            throw new EOFException();
        }

        @Override // ax.p260q1.U
        public /* synthetic */ void d(long j) {
            T.a(this, j);
        }

        @Override // ax.p260q1.U
        public void e(C1375v c1375v) {
            this.d = c1375v;
            this.b.e(this.c);
        }

        @Override // ax.p260q1.U
        public void f(long j, int i, int i2, int i3, U.a aVar) {
            C1498a.e(this.d);
            G gJ = j(i2, i3);
            if (!Objects.equals(this.d.o, this.c.o)) {
                if (!"application/x-emsg".equals(this.d.o)) {
                    C1517u.h("HlsSampleStreamWrapper", "Ignoring sample for unsupported format: " + this.d.o);
                    return;
                }
                ax.B1.a aVarC = this.a.c(gJ);
                if (!h(aVarC)) {
                    C1517u.h("HlsSampleStreamWrapper", String.format("Ignoring EMSG. Expected it to contain wrapped %s but actual wrapped format: %s", this.c.o, aVarC.a()));
                    return;
                }
                gJ = new G((byte[]) C1498a.e(aVarC.c()));
            }
            int iA = gJ.a();
            this.b.g(gJ, iA);
            this.b.f(j, i, iA, 0, aVar);
        }

        @Override // ax.p260q1.U
        public /* synthetic */ void g(G g2, int i) {
            T.c(this, g2, i);
        }
    }

    private static final class d extends d0 {
        private final Map<String, C1369o> H;
        private C1369o I;

        private d(ax.p196m1.b bVar, w wVar, InterfaceC1830u.a aVar, Map<String, C1369o> map) {
            super(bVar, wVar, aVar);
            this.H = map;
        }

        private C e0(C c) {
            if (c == null) {
                return null;
            }
            int iE = c.e();
            int i = 0;
            int i2 = 0;
            while (true) {
                if (i2 >= iE) {
                    i2 = -1;
                    break;
                }
                C.a aVarD = c.d(i2);
                if ((aVarD instanceof ax.E1.m) && "com.apple.streaming.transportStreamTimestamp".equals(((ax.E1.m) aVarD).b)) {
                    break;
                }
                i2++;
            }
            if (i2 == -1) {
                return c;
            }
            if (iE == 1) {
                return null;
            }
            C.a[] aVarArr = new C.a[iE - 1];
            while (i < iE) {
                if (i != i2) {
                    aVarArr[i < i2 ? i : i - 1] = c.d(i);
                }
                i++;
            }
            return new C(aVarArr);
        }

        @Override // ax.p132i1.d0, ax.p260q1.U
        public void f(long j, int i, int i2, int i3, U.a aVar) {
            super.f(j, i, i2, i3, aVar);
        }

        public void f0(C1369o c1369o) {
            this.I = c1369o;
            G();
        }

        public void g0(e eVar) {
            c0(eVar.k);
        }

        @Override // ax.p132i1.d0
        public C1375v v(C1375v c1375v) {
            C1369o c1369o;
            C1369o c1369o2 = this.I;
            if (c1369o2 == null) {
                c1369o2 = c1375v.s;
            }
            if (c1369o2 != null && (c1369o = this.H.get(c1369o2.Y)) != null) {
                c1369o2 = c1369o;
            }
            C cE0 = e0(c1375v.l);
            if (c1369o2 != c1375v.s || cE0 != c1375v.l) {
                c1375v = c1375v.b().c0(c1369o2).r0(cE0).P();
            }
            return super.v(c1375v);
        }
    }

    public l(String str, int i, b bVar, androidx.media3.exoplayer.hls.c cVar, Map<String, C1369o> map, ax.p196m1.b bVar2, long j, C1375v c1375v, w wVar, InterfaceC1830u.a aVar, m mVar, N.a aVar2, int i2) {
        this.q = str;
        this.X = i;
        this.Y = bVar;
        this.Z = cVar;
        this.z0 = map;
        this.k0 = bVar2;
        this.l0 = c1375v;
        this.m0 = wVar;
        this.n0 = aVar;
        this.o0 = mVar;
        this.q0 = aVar2;
        this.r0 = i2;
        Set<Integer> set = e1;
        this.D0 = new HashSet(set.size());
        this.E0 = new SparseIntArray(set.size());
        this.B0 = new d[0];
        this.U0 = new boolean[0];
        this.T0 = new boolean[0];
        ArrayList<e> arrayList = new ArrayList<>();
        this.t0 = arrayList;
        this.u0 = DesugarCollections.unmodifiableList(arrayList);
        this.y0 = new ArrayList<>();
        this.v0 = new Runnable() { // from class: androidx.media3.exoplayer.hls.j
            @Override // java.lang.Runnable
            public final void run() {
                this.q.W();
            }
        };
        this.w0 = new Runnable() { // from class: androidx.media3.exoplayer.hls.k
            @Override // java.lang.Runnable
            public final void run() {
                this.q.g0();
            }
        };
        this.x0 = ax.S0.d0.A();
        this.V0 = j;
        this.W0 = j;
    }

    private void B() {
        C1375v c1375v;
        int length = this.B0.length;
        int i = 0;
        int i2 = -2;
        int i3 = -1;
        while (true) {
            int i4 = 2;
            if (i >= length) {
                break;
            }
            String str = ((C1375v) C1498a.i(this.B0[i].D())).o;
            if (!D.s(str)) {
                i4 = D.o(str) ? 1 : D.r(str) ? 3 : -2;
            }
            if (O(i4) > O(i2)) {
                i3 = i;
                i2 = i4;
            } else if (i4 == i2 && i3 != -1) {
                i3 = -1;
            }
            i++;
        }
        P pL = this.Z.l();
        int i5 = pL.a;
        this.R0 = -1;
        this.Q0 = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            this.Q0[i6] = i6;
        }
        P[] pArr = new P[length];
        int i7 = 0;
        while (i7 < length) {
            C1375v c1375v2 = (C1375v) C1498a.i(this.B0[i7].D());
            if (i7 == i3) {
                C1375v[] c1375vArr = new C1375v[i5];
                for (int i8 = 0; i8 < i5; i8++) {
                    C1375v c1375vB = pL.b(i8);
                    if (i2 == 1 && (c1375v = this.l0) != null) {
                        c1375vB = c1375vB.m(c1375v);
                    }
                    c1375vArr[i8] = i5 == 1 ? c1375v2.m(c1375vB) : H(c1375vB, c1375v2, true);
                }
                pArr[i7] = new P(this.q, c1375vArr);
                this.R0 = i7;
            } else {
                C1375v c1375v3 = (i2 == 2 && D.o(c1375v2.o)) ? this.l0 : null;
                StringBuilder sb = new StringBuilder();
                sb.append(this.q);
                sb.append(":muxed:");
                sb.append(i7 < i3 ? i7 : i7 - 1);
                pArr[i7] = new P(sb.toString(), H(c1375v3, c1375v2, false));
            }
            i7++;
        }
        this.O0 = G(pArr);
        C1498a.g(this.P0 == null);
        this.P0 = Collections.EMPTY_SET;
    }

    private boolean C(int i) {
        for (int i2 = i; i2 < this.t0.size(); i2++) {
            if (this.t0.get(i2).x()) {
                return false;
            }
        }
        e eVar = this.t0.get(i);
        for (int i3 = 0; i3 < this.B0.length; i3++) {
            if (this.B0[i3].A() > eVar.m(i3)) {
                return false;
            }
        }
        return true;
    }

    private static C2229o E(int i, int i2) {
        C1517u.h("HlsSampleStreamWrapper", "Unmapped track with id " + i + " of type " + i2);
        return new C2229o();
    }

    private d0 F(int i, int i2) {
        int length = this.B0.length;
        boolean z = true;
        if (i2 != 1 && i2 != 2) {
            z = false;
        }
        d dVar = new d(this.k0, this.m0, this.n0, this.z0);
        dVar.Y(this.V0);
        if (z) {
            dVar.f0(this.c1);
        }
        dVar.X(this.b1);
        e eVar = this.d1;
        if (eVar != null) {
            dVar.g0(eVar);
        }
        dVar.a0(this);
        int i3 = length + 1;
        int[] iArrCopyOf = Arrays.copyOf(this.C0, i3);
        this.C0 = iArrCopyOf;
        iArrCopyOf[length] = i;
        this.B0 = (d[]) ax.S0.d0.e1(this.B0, dVar);
        boolean[] zArrCopyOf = Arrays.copyOf(this.U0, i3);
        this.U0 = zArrCopyOf;
        zArrCopyOf[length] = z;
        this.S0 |= z;
        this.D0.add(Integer.valueOf(i2));
        this.E0.append(i2, length);
        if (O(i2) > O(this.G0)) {
            this.H0 = length;
            this.G0 = i2;
        }
        this.T0 = Arrays.copyOf(this.T0, i3);
        return dVar;
    }

    private q0 G(P[] pArr) {
        for (int i = 0; i < pArr.length; i++) {
            P p = pArr[i];
            C1375v[] c1375vArr = new C1375v[p.a];
            for (int i2 = 0; i2 < p.a; i2++) {
                C1375v c1375vB = p.b(i2);
                c1375vArr[i2] = c1375vB.c(this.m0.a(c1375vB));
            }
            pArr[i] = new P(p.b, c1375vArr);
        }
        return new q0(pArr);
    }

    private static C1375v H(C1375v c1375v, C1375v c1375v2, boolean z) {
        String strD;
        String strG;
        if (c1375v == null) {
            return c1375v2;
        }
        int iK = D.k(c1375v2.o);
        if (ax.S0.d0.R(c1375v.k, iK) == 1) {
            strD = ax.S0.d0.S(c1375v.k, iK);
            strG = D.g(strD);
        } else {
            strD = D.d(c1375v.k, c1375v2.o);
            strG = c1375v2.o;
        }
        C1375v.b bVarU = c1375v2.b().j0(c1375v.a).l0(c1375v.b).m0(c1375v.c).n0(c1375v.d).A0(c1375v.e).w0(c1375v.f).S(z ? c1375v.h : -1).t0(z ? c1375v.i : -1).U(strD);
        if (iK == 2) {
            bVarU.F0(c1375v.v).h0(c1375v.w).f0(c1375v.z);
        }
        if (strG != null) {
            bVarU.y0(strG);
        }
        int i = c1375v.G;
        if (i != -1 && iK == 1) {
            bVarU.T(i);
        }
        C cB = c1375v.l;
        if (cB != null) {
            C c2 = c1375v2.l;
            if (c2 != null) {
                cB = c2.b(cB);
            }
            bVarU.r0(cB);
        }
        return bVarU.P();
    }

    private void I(int i) {
        C1498a.g(!this.p0.i());
        while (true) {
            if (i >= this.t0.size()) {
                i = -1;
                break;
            } else if (C(i)) {
                break;
            } else {
                i++;
            }
        }
        if (i == -1) {
            return;
        }
        long j = M().h;
        e eVarJ = J(i);
        if (this.t0.isEmpty()) {
            this.W0 = this.V0;
        } else {
            ((e) F.e(this.t0)).p();
        }
        this.Z0 = false;
        this.q0.y(this.G0, eVarJ.g, j);
    }

    private e J(int i) {
        e eVar = this.t0.get(i);
        ArrayList<e> arrayList = this.t0;
        ax.S0.d0.l1(arrayList, i, arrayList.size());
        for (int i2 = 0; i2 < this.B0.length; i2++) {
            this.B0[i2].s(eVar.m(i2));
        }
        return eVar;
    }

    private boolean K(e eVar) {
        int i = eVar.k;
        int length = this.B0.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (this.T0[i2] && this.B0[i2].N() == i) {
                return false;
            }
        }
        return true;
    }

    private static boolean L(C1375v c1375v, C1375v c1375v2) {
        String str = c1375v.o;
        String str2 = c1375v2.o;
        int iK = D.k(str);
        if (iK != 3) {
            return iK == D.k(str2);
        }
        if (Objects.equals(str, str2)) {
            return !("application/cea-608".equals(str) || "application/cea-708".equals(str)) || c1375v.L == c1375v2.L;
        }
        return false;
    }

    private e M() {
        ArrayList<e> arrayList = this.t0;
        return arrayList.get(arrayList.size() - 1);
    }

    private U N(int i, int i2) {
        C1498a.a(e1.contains(Integer.valueOf(i2)));
        int i3 = this.E0.get(i2, -1);
        if (i3 == -1) {
            return null;
        }
        if (this.D0.add(Integer.valueOf(i2))) {
            this.C0[i3] = i;
        }
        return this.C0[i3] == i ? this.B0[i3] : E(i, i2);
    }

    private static int O(int i) {
        if (i == 1) {
            return 2;
        }
        if (i != 2) {
            return i != 3 ? 0 : 1;
        }
        return 3;
    }

    private void P(e eVar) {
        this.d1 = eVar;
        this.L0 = eVar.d;
        this.W0 = -9223372036854775807L;
        this.t0.add(eVar);
        AbstractC1656z.a aVarQ = AbstractC1656z.q();
        for (d dVar : this.B0) {
            aVarQ.a(Integer.valueOf(dVar.E()));
        }
        eVar.o(this, aVarQ.k());
        for (d dVar2 : this.B0) {
            dVar2.g0(eVar);
            if (eVar.x()) {
                dVar2.d0();
            }
        }
    }

    private static boolean Q(ax.p148j1.b bVar) {
        return bVar instanceof e;
    }

    private boolean R() {
        return this.W0 != -9223372036854775807L;
    }

    private void U() {
        int i = this.O0.a;
        int[] iArr = new int[i];
        this.Q0 = iArr;
        Arrays.fill(iArr, -1);
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            int i4 = 0;
            while (true) {
                d[] dVarArr = this.B0;
                if (i4 >= dVarArr.length) {
                    break;
                }
                if (L((C1375v) C1498a.i(dVarArr[i4].D()), this.O0.c(i3).b(0))) {
                    this.Q0[i3] = i4;
                    break;
                }
                i4++;
            }
        }
        ArrayList<h> arrayList = this.y0;
        int size = arrayList.size();
        while (i2 < size) {
            h hVar = arrayList.get(i2);
            i2++;
            hVar.d();
        }
    }

    private void V(e eVar) {
        if (this.t0.isEmpty()) {
            return;
        }
        if (!M().r()) {
            I(this.t0.size() - 1);
        }
        if (eVar.n && eVar.x()) {
            for (int size = this.t0.size() - 1; size >= 0; size--) {
                long j = this.t0.get(size).g;
                long j2 = eVar.g;
                if (j < j2) {
                    return;
                }
                if (j == j2 && C(size)) {
                    I(size);
                    eVar.i();
                    return;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void W() {
        if (!this.N0 && this.Q0 == null && this.I0) {
            for (d dVar : this.B0) {
                if (dVar.D() == null) {
                    return;
                }
            }
            if (this.O0 != null) {
                U();
                return;
            }
            B();
            p0();
            this.Y.h();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g0() {
        this.I0 = true;
        W();
    }

    private void k0() {
        for (d dVar : this.B0) {
            dVar.T(this.X0);
        }
        this.X0 = false;
    }

    private boolean l0(long j, e eVar) throws Throwable {
        boolean zW;
        int length = this.B0.length;
        int i = 0;
        while (true) {
            boolean z = true;
            if (i >= length) {
                return true;
            }
            d dVar = this.B0[i];
            if (eVar != null) {
                zW = dVar.V(eVar.m(i));
            } else {
                long jB = b();
                if (jB != Long.MIN_VALUE && j >= jB) {
                    z = false;
                }
                zW = dVar.W(j, z);
            }
            if (!zW && (this.U0[i] || !this.S0)) {
                return false;
            }
            i++;
        }
    }

    private void p0() {
        this.J0 = true;
    }

    private void u0(e0[] e0VarArr) {
        this.y0.clear();
        for (e0 e0Var : e0VarArr) {
            if (e0Var != null) {
                this.y0.add((h) e0Var);
            }
        }
    }

    private void z() {
        C1498a.g(this.J0);
        C1498a.e(this.O0);
        C1498a.e(this.P0);
    }

    public int A(int i) {
        z();
        C1498a.e(this.Q0);
        int i2 = this.Q0[i];
        if (i2 == -1) {
            return this.P0.contains(this.O0.c(i)) ? -3 : -2;
        }
        boolean[] zArr = this.T0;
        if (zArr[i2]) {
            return -2;
        }
        zArr[i2] = true;
        return i2;
    }

    public void D() {
        if (this.J0) {
            return;
        }
        a(new C0639p0.b().f(this.V0).d());
    }

    public boolean S(int i) {
        return !R() && this.B0[i].I(this.Z0);
    }

    public boolean T() {
        return this.G0 == 2;
    }

    public void X() throws IOException {
        this.p0.j();
        this.Z.r();
    }

    public void Y(int i) throws IOException {
        X();
        this.B0[i].K();
    }

    @Override // ax.m1.o.b
    /* JADX INFO: renamed from: Z, reason: merged with bridge method [inline-methods] */
    public void p(ax.p148j1.b bVar, long j, long j2, boolean z) {
        this.A0 = null;
        C2117y c2117y = new C2117y(bVar.a, bVar.b, bVar.f(), bVar.e(), j, j2, bVar.b());
        this.o0.a(bVar.a);
        this.q0.m(c2117y, bVar.c, this.X, bVar.d, bVar.e, bVar.f, bVar.g, bVar.h);
        if (z) {
            return;
        }
        if (R() || this.K0 == 0) {
            k0();
        }
        if (this.K0 > 0) {
            this.Y.i(this);
        }
    }

    @Override // ax.p132i1.f0
    public boolean a(C0639p0 c0639p0) {
        List<e> list;
        long j;
        long j2;
        if (this.Z0 || this.p0.i() || this.p0.h()) {
            return false;
        }
        if (R()) {
            List<e> list2 = Collections.EMPTY_LIST;
            long j3 = this.W0;
            for (d dVar : this.B0) {
                dVar.Y(this.W0);
            }
            list = list2;
            j = j3;
            j2 = j;
        } else {
            List<e> list3 = this.u0;
            e eVarM = M();
            long jN = (eVarM.q() && eVarM.r()) ? eVarM.n() : Math.max(this.V0, eVarM.g);
            long jMax = this.V0;
            if (this.I0) {
                for (d dVar2 : this.B0) {
                    jMax = Math.max(jMax, dVar2.y());
                }
            }
            list = list3;
            j = jN;
            j2 = jMax;
        }
        this.s0.a();
        this.Z.f(c0639p0, j, j2, list, this.J0 || !list.isEmpty(), this.s0);
        androidx.media3.exoplayer.hls.c.b bVar = this.s0;
        boolean z = bVar.b;
        ax.p148j1.b bVar2 = bVar.a;
        Uri uri = bVar.c;
        if (z) {
            this.W0 = -9223372036854775807L;
            this.Z0 = true;
            return true;
        }
        if (bVar2 == null) {
            if (uri != null) {
                this.Y.j(uri);
            }
            return false;
        }
        if (Q(bVar2)) {
            e eVar = (e) bVar2;
            V(eVar);
            P(eVar);
        }
        this.A0 = bVar2;
        this.p0.n(bVar2, this, this.o0.c(bVar2.c));
        return true;
    }

    @Override // ax.m1.o.b
    /* JADX INFO: renamed from: a0, reason: merged with bridge method [inline-methods] */
    public void r(ax.p148j1.b bVar, long j, long j2) {
        this.A0 = null;
        this.Z.t(bVar);
        C2117y c2117y = new C2117y(bVar.a, bVar.b, bVar.f(), bVar.e(), j, j2, bVar.b());
        this.o0.a(bVar.a);
        this.q0.p(c2117y, bVar.c, this.X, bVar.d, bVar.e, bVar.f, bVar.g, bVar.h);
        if (this.J0) {
            this.Y.i(this);
        } else {
            a(new C0639p0.b().f(this.V0).d());
        }
    }

    @Override // ax.p132i1.f0
    public long b() {
        if (R()) {
            return this.W0;
        }
        if (this.Z0) {
            return Long.MIN_VALUE;
        }
        return M().h;
    }

    @Override // ax.m1.o.b
    /* JADX INFO: renamed from: b0, reason: merged with bridge method [inline-methods] */
    public o.c j(ax.p148j1.b bVar, long j, long j2, IOException iOException, int i) {
        o.c cVarG;
        int i2;
        boolean zQ = Q(bVar);
        if (zQ && !((e) bVar).r() && (iOException instanceof u) && ((i2 = ((u) iOException).Z) == 410 || i2 == 404)) {
            return o.d;
        }
        long jB = bVar.b();
        C2117y c2117y = new C2117y(bVar.a, bVar.b, bVar.f(), bVar.e(), j, j2, jB);
        m.c cVar = new m.c(c2117y, new B(bVar.c, this.X, bVar.d, bVar.e, bVar.f, ax.S0.d0.E1(bVar.g), ax.S0.d0.E1(bVar.h)), iOException, i);
        m.b bVarD = this.o0.d(I.c(this.Z.m()), cVar);
        boolean zQ2 = (bVarD == null || bVarD.a != 2) ? false : this.Z.q(bVar, bVarD.b);
        if (zQ2) {
            if (zQ && jB == 0) {
                ArrayList<e> arrayList = this.t0;
                C1498a.g(arrayList.remove(arrayList.size() - 1) == bVar);
                if (this.t0.isEmpty()) {
                    this.W0 = this.V0;
                } else {
                    ((e) F.e(this.t0)).p();
                }
            }
            cVarG = o.f;
        } else {
            long jB2 = this.o0.b(cVar);
            cVarG = jB2 != -9223372036854775807L ? o.g(false, jB2) : o.g;
        }
        o.c cVar2 = cVarG;
        boolean zC = cVar2.c();
        this.q0.r(c2117y, bVar.c, this.X, bVar.d, bVar.e, bVar.f, bVar.g, bVar.h, iOException, !zC);
        if (!zC) {
            this.A0 = null;
            this.o0.a(bVar.a);
        }
        if (zQ2) {
            if (!this.J0) {
                a(new C0639p0.b().f(this.V0).d());
                return cVar2;
            }
            this.Y.i(this);
        }
        return cVar2;
    }

    @Override // ax.p132i1.f0
    public boolean c() {
        return this.p0.i();
    }

    @Override // ax.m1.o.b
    /* JADX INFO: renamed from: c0, reason: merged with bridge method [inline-methods] */
    public void k(ax.p148j1.b bVar, long j, long j2, int i) {
        this.q0.v(i == 0 ? new C2117y(bVar.a, bVar.b, j) : new C2117y(bVar.a, bVar.b, bVar.f(), bVar.e(), j, j2, bVar.b()), bVar.c, this.X, bVar.d, bVar.e, bVar.f, bVar.g, bVar.h, i);
    }

    @Override // ax.p132i1.f0
    public long d() {
        if (this.Z0) {
            return Long.MIN_VALUE;
        }
        if (R()) {
            return this.W0;
        }
        long jMax = this.V0;
        e eVarM = M();
        if (!eVarM.q()) {
            if (this.t0.size() > 1) {
                ArrayList<e> arrayList = this.t0;
                eVarM = arrayList.get(arrayList.size() - 2);
            } else {
                eVarM = null;
            }
        }
        if (eVarM != null) {
            jMax = Math.max(jMax, eVarM.h);
        }
        if (this.I0) {
            for (d dVar : this.B0) {
                jMax = Math.max(jMax, dVar.x());
            }
        }
        return jMax;
    }

    public void d0() {
        this.D0.clear();
    }

    @Override // ax.p132i1.f0
    public void e(long j) {
        if (this.p0.h() || R()) {
            return;
        }
        if (this.p0.i()) {
            C1498a.e(this.A0);
            if (this.Z.z(j, this.A0, this.u0)) {
                this.p0.e();
                return;
            }
            return;
        }
        int size = this.u0.size();
        while (size > 0 && this.Z.d(this.u0.get(size - 1)) == 2) {
            size--;
        }
        if (size < this.u0.size()) {
            I(size);
        }
        int i = this.Z.i(j, this.u0);
        if (i < this.t0.size()) {
            I(i);
        }
    }

    public boolean e0(Uri uri, m.c cVar, boolean z) {
        m.b bVarD;
        if (this.Z.s(uri)) {
            return this.Z.u(uri, (z || (bVarD = this.o0.d(I.c(this.Z.m()), cVar)) == null || bVarD.a != 2) ? -9223372036854775807L : bVarD.b);
        }
        return true;
    }

    @Override // ax.m1.o.f
    public void f() {
        for (d dVar : this.B0) {
            dVar.Q();
        }
    }

    public void f0() {
        if (this.t0.isEmpty()) {
            return;
        }
        final e eVar = (e) F.e(this.t0);
        int iD = this.Z.d(eVar);
        if (iD == 1) {
            if (eVar.r()) {
                return;
            }
            eVar.w(this.Z.j(eVar));
        } else if (iD == 0) {
            this.x0.post(new Runnable() { // from class: androidx.media3.exoplayer.hls.i
                @Override // java.lang.Runnable
                public final void run() {
                    this.q.Y.j(eVar.m);
                }
            });
        } else if (iD == 2 && !this.Z0 && this.p0.i()) {
            this.p0.e();
        }
    }

    @Override // ax.p260q1.InterfaceC2233t
    public void h(ax.p260q1.N n) {
    }

    public void h0(P[] pArr, int i, int... iArr) {
        this.O0 = G(pArr);
        this.P0 = new HashSet();
        for (int i2 : iArr) {
            this.P0.add(this.O0.c(i2));
        }
        this.R0 = i;
        Handler handler = this.x0;
        final b bVar = this.Y;
        Objects.requireNonNull(bVar);
        handler.post(new Runnable() { // from class: ax.c1.g
            @Override // java.lang.Runnable
            public final void run() {
                bVar.h();
            }
        });
        p0();
    }

    @Override // ax.i1.d0.d
    public void i(C1375v c1375v) {
        this.x0.post(this.v0);
    }

    public int i0(int i, O o, ax.V0.i iVar, int i2) {
        if (R()) {
            return -3;
        }
        int i3 = 0;
        if (!this.t0.isEmpty()) {
            int i4 = 0;
            while (i4 < this.t0.size() - 1 && K(this.t0.get(i4))) {
                i4++;
            }
            ax.S0.d0.l1(this.t0, 0, i4);
            e eVar = this.t0.get(0);
            C1375v c1375v = eVar.d;
            if (!c1375v.equals(this.M0)) {
                this.q0.j(this.X, c1375v, eVar.e, eVar.f, eVar.g);
            }
            this.M0 = c1375v;
        }
        if (!this.t0.isEmpty() && !this.t0.get(0).r()) {
            return -3;
        }
        int iP = this.B0[i].P(o, iVar, i2, this.Z0);
        if (iP == -5) {
            C1375v c1375vM = (C1375v) C1498a.e(o.b);
            if (i == this.H0) {
                int iE = ax.p027b8.f.e(this.B0[i].N());
                while (i3 < this.t0.size() && this.t0.get(i3).k != iE) {
                    i3++;
                }
                c1375vM = c1375vM.m(i3 < this.t0.size() ? this.t0.get(i3).d : (C1375v) C1498a.e(this.L0));
            }
            o.b = c1375vM;
        }
        return iP;
    }

    public void j0() {
        if (this.J0) {
            for (d dVar : this.B0) {
                dVar.O();
            }
        }
        this.Z.v();
        this.p0.m(this);
        this.x0.removeCallbacksAndMessages(null);
        this.N0 = true;
        this.y0.clear();
    }

    public void l() throws IOException {
        X();
        if (this.Z0 && !this.J0) {
            throw E.a("Loading finished before preparation is complete.", null);
        }
    }

    public boolean m0(long j, boolean z) {
        e eVar;
        this.V0 = j;
        if (R()) {
            this.W0 = j;
            return true;
        }
        if (!this.Z.n()) {
            eVar = null;
            break;
        }
        int i = 0;
        while (true) {
            if (i >= this.t0.size()) {
                eVar = null;
                break;
            }
            eVar = this.t0.get(i);
            if (eVar.g == j) {
                break;
            }
            i++;
        }
        if (this.I0 && !z && !this.t0.isEmpty() && l0(j, eVar)) {
            return false;
        }
        this.W0 = j;
        this.Z0 = false;
        this.t0.clear();
        if (this.p0.i()) {
            if (this.I0) {
                for (d dVar : this.B0) {
                    dVar.q();
                }
            }
            this.p0.e();
        } else {
            this.p0.f();
            k0();
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:69:0x0114  */
    public boolean n0(ax.p180l1.D[] dArr, boolean[] zArr, e0[] e0VarArr, boolean[] zArr2, long j, boolean z) {
        boolean z2;
        z();
        int i = this.K0;
        int i2 = 0;
        for (int i3 = 0; i3 < dArr.length; i3++) {
            h hVar = (h) e0VarArr[i3];
            if (hVar != null && (dArr[i3] == null || !zArr[i3])) {
                this.K0--;
                hVar.f();
                e0VarArr[i3] = null;
            }
        }
        boolean z3 = z || (!this.Y0 ? j == this.V0 : i != 0);
        ax.p180l1.D dM = this.Z.m();
        boolean z4 = z3;
        ax.p180l1.D d2 = dM;
        for (int i4 = 0; i4 < dArr.length; i4++) {
            ax.p180l1.D d3 = dArr[i4];
            if (d3 != null) {
                int iE = this.O0.e(d3.b());
                if (iE == this.R0) {
                    this.Z.y(d3);
                    d2 = d3;
                }
                if (e0VarArr[i4] == null) {
                    this.K0++;
                    h hVar2 = new h(this, iE);
                    e0VarArr[i4] = hVar2;
                    zArr2[i4] = true;
                    if (this.Q0 != null) {
                        hVar2.d();
                        if (!z4) {
                            d dVar = this.B0[this.Q0[iE]];
                            z4 = (dVar.A() == 0 || dVar.W(j, true)) ? false : true;
                        }
                    }
                }
            }
        }
        if (this.K0 == 0) {
            this.Z.v();
            this.M0 = null;
            this.X0 = true;
            this.t0.clear();
            if (this.p0.i()) {
                if (this.I0) {
                    d[] dVarArr = this.B0;
                    int length = dVarArr.length;
                    while (i2 < length) {
                        dVarArr[i2].q();
                        i2++;
                    }
                }
                this.p0.e();
            } else {
                k0();
            }
        } else {
            if (this.t0.isEmpty() || Objects.equals(d2, dM)) {
                z2 = z;
            } else {
                if (!this.Y0) {
                    long j2 = j < 0 ? -j : 0L;
                    e eVarM = M();
                    ax.p180l1.D d4 = d2;
                    d4.c(j, j2, -9223372036854775807L, this.u0, this.Z.a(eVarM, j));
                    if (d4.l() == this.Z.l().c(eVarM.d)) {
                        z2 = z;
                    }
                }
                this.X0 = true;
                z2 = true;
                z4 = true;
            }
            if (z4) {
                m0(j, z2);
                while (i2 < e0VarArr.length) {
                    if (e0VarArr[i2] != null) {
                        zArr2[i2] = true;
                    }
                    i2++;
                }
            }
        }
        u0(e0VarArr);
        this.Y0 = true;
        return z4;
    }

    @Override // ax.p260q1.InterfaceC2233t
    public void o() {
        this.a1 = true;
        this.x0.post(this.w0);
    }

    public void o0(C1369o c1369o) {
        if (Objects.equals(this.c1, c1369o)) {
            return;
        }
        this.c1 = c1369o;
        int i = 0;
        while (true) {
            d[] dVarArr = this.B0;
            if (i >= dVarArr.length) {
                return;
            }
            if (this.U0[i]) {
                dVarArr[i].f0(c1369o);
            }
            i++;
        }
    }

    public long q(long j, Z z) {
        return this.Z.c(j, z);
    }

    public void q0(boolean z) {
        this.Z.x(z);
    }

    public void r0(long j) {
        if (this.b1 != j) {
            this.b1 = j;
            for (d dVar : this.B0) {
                dVar.X(j);
            }
        }
    }

    public int s0(int i, long j) throws Throwable {
        if (R()) {
            return 0;
        }
        d dVar = this.B0[i];
        int iC = dVar.C(j, this.Z0);
        e eVar = (e) F.f(this.t0, null);
        if (eVar != null && !eVar.r()) {
            iC = Math.min(iC, eVar.m(i) - dVar.A());
        }
        dVar.b0(iC);
        return iC;
    }

    public q0 t() {
        z();
        return this.O0;
    }

    public void t0(int i) {
        z();
        C1498a.e(this.Q0);
        int i2 = this.Q0[i];
        C1498a.g(this.T0[i2]);
        this.T0[i2] = false;
    }

    @Override // ax.p260q1.InterfaceC2233t
    public U u(int i, int i2) {
        U uF;
        if (!e1.contains(Integer.valueOf(i2))) {
            int i3 = 0;
            while (true) {
                U[] uArr = this.B0;
                if (i3 >= uArr.length) {
                    uF = null;
                    break;
                }
                if (this.C0[i3] == i) {
                    uF = uArr[i3];
                    break;
                }
                i3++;
            }
        } else {
            uF = N(i, i2);
        }
        if (uF == null) {
            if (this.a1) {
                return E(i, i2);
            }
            uF = F(i, i2);
        }
        if (i2 != 5) {
            return uF;
        }
        if (this.F0 == null) {
            this.F0 = new c(uF, this.r0);
        }
        return this.F0;
    }

    public void v(long j, boolean z) {
        if (!this.I0 || R()) {
            return;
        }
        int length = this.B0.length;
        for (int i = 0; i < length; i++) {
            this.B0[i].p(j, z, this.T0[i]);
        }
    }
}
