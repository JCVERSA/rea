package androidx.media3.exoplayer;

import android.content.Context;
import android.os.Looper;
import androidx.media3.exoplayer.C0626j;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.image.ImageOutput;
import ax.P0.C1357c;
import ax.S0.C1498a;
import ax.S0.InterfaceC1505h;
import ax.Z0.C1706u0;
import ax.Z0.InterfaceC1657a;
import ax.Z0.InterfaceC1663c;
import ax.p260q1.C2228n;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public interface ExoPlayer extends ax.P0.H {

    public interface a {
        void i(boolean z);

        void l(boolean z);
    }

    public static final class b {
        ax.Y0.P A;
        long B;
        long C;
        boolean D;
        boolean E;
        ax.Y0.T F;
        boolean G;
        boolean H;
        String I;
        boolean J;
        X0 K;
        final Context a;
        InterfaceC1505h b;
        long c;
        ax.X7.u<ax.Y0.X> d;
        ax.X7.u<ax.i1.F.a> e;
        ax.X7.u<ax.p180l1.J> f;
        ax.X7.u<InterfaceC0637o0> g;
        ax.X7.u<ax.p196m1.e> h;
        ax.X7.f<InterfaceC1505h, InterfaceC1657a> i;
        Looper j;
        int k;
        ax.P0.J l;
        C1357c m;
        boolean n;
        int o;
        boolean p;
        boolean q;
        boolean r;
        int s;
        int t;
        boolean u;
        ax.Y0.Z v;
        ax.Y0.Y w;
        long x;
        long y;
        long z;

        private b(final Context context, ax.X7.u<ax.Y0.X> uVar, ax.X7.u<ax.i1.F.a> uVar2) {
            this(context, uVar, uVar2, new ax.X7.u() { // from class: ax.Y0.I
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.g(context);
                }
            }, new ax.X7.u() { // from class: ax.Y0.J
                @Override // ax.X7.u
                public final Object get() {
                    return new C0626j();
                }
            }, new ax.X7.u() { // from class: ax.Y0.K
                @Override // ax.X7.u
                public final Object get() {
                    return ax.p196m1.j.n(context);
                }
            }, new ax.X7.f() { // from class: ax.Y0.L
                @Override // ax.X7.f
                public final Object apply(Object obj) {
                    return new C1706u0((InterfaceC1505h) obj);
                }
            });
        }

        private b(Context context, ax.X7.u<ax.Y0.X> uVar, ax.X7.u<ax.i1.F.a> uVar2, ax.X7.u<ax.p180l1.J> uVar3, ax.X7.u<InterfaceC0637o0> uVar4, ax.X7.u<ax.p196m1.e> uVar5, ax.X7.f<InterfaceC1505h, InterfaceC1657a> fVar) {
            this.a = (Context) C1498a.e(context);
            this.d = uVar;
            this.e = uVar2;
            this.f = uVar3;
            this.g = uVar4;
            this.h = uVar5;
            this.i = fVar;
            this.j = ax.S0.d0.X();
            this.m = C1357c.h;
            this.o = 0;
            this.s = 1;
            this.t = 0;
            this.u = true;
            this.v = ax.Y0.Z.g;
            this.x = 5000L;
            this.y = 15000L;
            this.z = 3000L;
            this.w = ax.Y0.Y.i;
            this.A = new C0624i.b().a();
            this.b = InterfaceC1505h.a;
            this.B = 500L;
            this.C = 2000L;
            this.E = true;
            this.I = HttpUrl.FRAGMENT_ENCODE_SET;
            this.k = -1000;
            this.K = new C0630l();
        }

        public b(final Context context, final ax.Y0.X x) {
            this(context, new ax.X7.u() { // from class: ax.Y0.G
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.f(x);
                }
            }, new ax.X7.u() { // from class: ax.Y0.H
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.a(context);
                }
            });
            C1498a.e(x);
        }

        public static /* synthetic */ ax.i1.F.a a(Context context) {
            return new ax.p132i1.r(context, new C2228n());
        }

        public static /* synthetic */ InterfaceC0637o0 b(InterfaceC0637o0 interfaceC0637o0) {
            return interfaceC0637o0;
        }

        public static /* synthetic */ ax.i1.F.a c(ax.i1.F.a aVar) {
            return aVar;
        }

        public static /* synthetic */ ax.p180l1.J e(ax.p180l1.J j) {
            return j;
        }

        public static /* synthetic */ ax.Y0.X f(ax.Y0.X x) {
            return x;
        }

        public static /* synthetic */ ax.p180l1.J g(Context context) {
            return new ax.p180l1.n(context);
        }

        public ExoPlayer h() {
            C1498a.g(!this.G);
            this.G = true;
            return new X(this, null);
        }

        public b i(final InterfaceC0637o0 interfaceC0637o0) {
            C1498a.g(!this.G);
            C1498a.e(interfaceC0637o0);
            this.g = new ax.X7.u() { // from class: ax.Y0.D
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.b(interfaceC0637o0);
                }
            };
            return this;
        }

        public b j(final ax.i1.F.a aVar) {
            C1498a.g(!this.G);
            C1498a.e(aVar);
            this.e = new ax.X7.u() { // from class: ax.Y0.F
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.c(aVar);
                }
            };
            return this;
        }

        public b k(long j) {
            C1498a.a(j > 0);
            C1498a.g(!this.G);
            this.x = j;
            return this;
        }

        public b l(long j) {
            C1498a.a(j > 0);
            C1498a.g(!this.G);
            this.y = j;
            return this;
        }

        public b m(final ax.p180l1.J j) {
            C1498a.g(!this.G);
            C1498a.e(j);
            this.f = new ax.X7.u() { // from class: ax.Y0.E
                @Override // ax.X7.u
                public final Object get() {
                    return ExoPlayer.b.e(j);
                }
            };
            return this;
        }
    }

    public static class c {
        public static final c b = new c(-9223372036854775807L);
        public final long a;

        public c(long j) {
            this.a = j;
        }
    }

    void a(int i);

    int b();

    void c(ax.Y0.Z z);

    void e(InterfaceC1663c interfaceC1663c);

    void h();

    boolean isScrubbingModeEnabled();

    void setImageOutput(ImageOutput imageOutput);

    void setScrubbingModeEnabled(boolean z);
}
