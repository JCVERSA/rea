package androidx.media3.exoplayer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaRoute2Info;
import android.media.MediaRouter2;
import android.media.RouteDiscoveryPreference;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import ax.S0.C1498a;
import ax.S0.C1503f;
import ax.S0.InterfaceC1505h;
import ax.Y0.C1612f;
import ax.Y0.C1616j;
import ax.Y0.C1623q;
import ax.Y0.C1624s;
import ax.Y0.C1629x;
import ax.Y0.C1630y;
import ax.Y7.AbstractC1656z;
import j$.util.Objects;
import java.util.Iterator;
import java.util.concurrent.Executor;

/* JADX INFO: renamed from: androidx.media3.exoplayer.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0630l implements X0 {
    private final X0 a;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.exoplayer.l$b */
    static final class b implements X0 {
        private AudioManager a;
        private AudioDeviceCallback b;
        private C1503f<Boolean> c;

        /* JADX INFO: renamed from: androidx.media3.exoplayer.l$b$a */
        class a extends AudioDeviceCallback {
            a() {
            }

            @Override // android.media.AudioDeviceCallback
            public void onAudioDevicesAdded(AudioDeviceInfo[] audioDeviceInfoArr) {
                b.this.c.g(Boolean.valueOf(b.this.i()));
            }

            @Override // android.media.AudioDeviceCallback
            public void onAudioDevicesRemoved(AudioDeviceInfo[] audioDeviceInfoArr) {
                b.this.c.g(Boolean.valueOf(b.this.i()));
            }
        }

        private b() {
        }

        public static /* synthetic */ void d(b bVar, Context context) {
            AudioManager audioManager;
            C1498a.e(bVar.c);
            if (ax.S0.d0.T0(context) && (audioManager = (AudioManager) context.getSystemService("audio")) != null) {
                bVar.a = audioManager;
                a aVar = bVar.new a();
                bVar.b = aVar;
                audioManager.registerAudioDeviceCallback(aVar, new Handler((Looper) C1498a.e(Looper.myLooper())));
                bVar.c.g(Boolean.valueOf(bVar.i()));
            }
        }

        public static /* synthetic */ void f(b bVar) {
            AudioManager audioManager = bVar.a;
            if (audioManager != null) {
                audioManager.unregisterAudioDeviceCallback(C1612f.a(C1498a.e(bVar.b)));
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean i() {
            for (AudioDeviceInfo audioDeviceInfo : ((AudioManager) C1498a.i(this.a)).getDevices(2)) {
                if (audioDeviceInfo.getType() == 8 || audioDeviceInfo.getType() == 5 || audioDeviceInfo.getType() == 6 || audioDeviceInfo.getType() == 11 || audioDeviceInfo.getType() == 4 || audioDeviceInfo.getType() == 3) {
                    return true;
                }
                int i = Build.VERSION.SDK_INT;
                if (i >= 26 && audioDeviceInfo.getType() == 22) {
                    return true;
                }
                if (i >= 28 && audioDeviceInfo.getType() == 23) {
                    return true;
                }
                if (i >= 31 && (audioDeviceInfo.getType() == 26 || audioDeviceInfo.getType() == 27)) {
                    return true;
                }
                if (i >= 33 && audioDeviceInfo.getType() == 30) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.media3.exoplayer.X0
        public boolean a() {
            C1503f<Boolean> c1503f = this.c;
            if (c1503f == null) {
                return true;
            }
            return c1503f.d().booleanValue();
        }

        @Override // androidx.media3.exoplayer.X0
        public void b(final X0.a aVar, final Context context, Looper looper, Looper looper2, InterfaceC1505h interfaceC1505h) {
            C1503f<Boolean> c1503f = new C1503f<>(Boolean.TRUE, looper2, looper, interfaceC1505h, new C1503f.a() { // from class: androidx.media3.exoplayer.n
                @Override // ax.S0.C1503f.a
                public final void a(Object obj, Object obj2) {
                    aVar.a(((Boolean) obj2).booleanValue());
                }
            });
            this.c = c1503f;
            c1503f.e(new Runnable() { // from class: androidx.media3.exoplayer.o
                @Override // java.lang.Runnable
                public final void run() {
                    C0630l.b.d(this.q, context);
                }
            });
        }

        @Override // androidx.media3.exoplayer.X0
        public void e() {
            ((C1503f) C1498a.e(this.c)).e(new Runnable() { // from class: androidx.media3.exoplayer.m
                @Override // java.lang.Runnable
                public final void run() {
                    C0630l.b.f(this.q);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.exoplayer.l$c */
    static final class c implements X0 {
        private static final RouteDiscoveryPreference e;
        private MediaRouter2 a;
        private MediaRouter2.RouteCallback b;
        private MediaRouter2.ControllerCallback c;
        private C1503f<Boolean> d;

        /* JADX INFO: renamed from: androidx.media3.exoplayer.l$c$a */
        class a extends MediaRouter2.RouteCallback {
            a() {
            }
        }

        /* JADX INFO: renamed from: androidx.media3.exoplayer.l$c$b */
        class b extends MediaRouter2.ControllerCallback {
            b() {
            }

            @Override // android.media.MediaRouter2.ControllerCallback
            public void onControllerUpdated(MediaRouter2.RoutingController routingController) {
                c.this.d.g(Boolean.valueOf(c.k(c.this.a)));
            }
        }

        static {
            C1624s.a();
            e = C1616j.a(AbstractC1656z.y(), false).build();
        }

        private c() {
        }

        public static /* synthetic */ void c(c cVar) {
            C1629x.a(C1498a.e(cVar.a)).unregisterControllerCallback(C1630y.a(C1498a.e(cVar.c)));
            cVar.c = null;
            cVar.a.unregisterRouteCallback(ax.Y0.A.a(C1498a.e(cVar.b)));
        }

        public static /* synthetic */ void f(c cVar, Context context) {
            C1498a.e(cVar.d);
            cVar.a = MediaRouter2.getInstance(context);
            cVar.b = cVar.new a();
            final C1503f<Boolean> c1503f = cVar.d;
            Objects.requireNonNull(c1503f);
            Executor executor = new Executor() { // from class: ax.Y0.B
                @Override // java.util.concurrent.Executor
                public final void execute(Runnable runnable) {
                    c1503f.e(runnable);
                }
            };
            cVar.a.registerRouteCallback(executor, cVar.b, e);
            b bVar = cVar.new b();
            cVar.c = bVar;
            cVar.a.registerControllerCallback(executor, bVar);
            cVar.d.g(Boolean.valueOf(k(cVar.a)));
        }

        private static boolean j(MediaRoute2Info mediaRoute2Info, int i, boolean z) {
            int suitabilityStatus = mediaRoute2Info.getSuitabilityStatus();
            if (suitabilityStatus == 1) {
                return (i == 1 || i == 2) && z;
            }
            return suitabilityStatus == 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static boolean k(MediaRouter2 mediaRouter2) {
            int transferReason = C1629x.a(C1498a.e(mediaRouter2)).getSystemController().getRoutingSessionInfo().getTransferReason();
            boolean zWasTransferInitiatedBySelf = mediaRouter2.getSystemController().wasTransferInitiatedBySelf();
            Iterator it = mediaRouter2.getSystemController().getSelectedRoutes().iterator();
            while (it.hasNext()) {
                if (j(C1623q.a(it.next()), transferReason, zWasTransferInitiatedBySelf)) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.media3.exoplayer.X0
        public boolean a() {
            C1503f<Boolean> c1503f = this.d;
            if (c1503f == null) {
                return true;
            }
            return c1503f.d().booleanValue();
        }

        @Override // androidx.media3.exoplayer.X0
        @SuppressLint({"ThreadSafe"})
        public void b(final X0.a aVar, final Context context, Looper looper, Looper looper2, InterfaceC1505h interfaceC1505h) {
            C1503f<Boolean> c1503f = new C1503f<>(Boolean.TRUE, looper2, looper, interfaceC1505h, new C1503f.a() { // from class: androidx.media3.exoplayer.q
                @Override // ax.S0.C1503f.a
                public final void a(Object obj, Object obj2) {
                    aVar.a(((Boolean) obj2).booleanValue());
                }
            });
            this.d = c1503f;
            c1503f.e(new Runnable() { // from class: androidx.media3.exoplayer.r
                @Override // java.lang.Runnable
                public final void run() {
                    C0630l.c.f(this.q, context);
                }
            });
        }

        @Override // androidx.media3.exoplayer.X0
        public void e() {
            ((C1503f) C1498a.i(this.d)).e(new Runnable() { // from class: androidx.media3.exoplayer.p
                @Override // java.lang.Runnable
                public final void run() {
                    C0630l.c.c(this.q);
                }
            });
        }
    }

    public C0630l() {
        int i = Build.VERSION.SDK_INT;
        if (i >= 35) {
            this.a = new c();
        } else if (i >= 23) {
            this.a = new b();
        } else {
            this.a = null;
        }
    }

    @Override // androidx.media3.exoplayer.X0
    public boolean a() {
        X0 x0 = this.a;
        return x0 == null || x0.a();
    }

    @Override // androidx.media3.exoplayer.X0
    public void b(X0.a aVar, Context context, Looper looper, Looper looper2, InterfaceC1505h interfaceC1505h) {
        X0 x0 = this.a;
        if (x0 != null) {
            x0.b(aVar, context, looper, looper2, interfaceC1505h);
        }
    }

    @Override // androidx.media3.exoplayer.X0
    public void e() {
        X0 x0 = this.a;
        if (x0 != null) {
            x0.e();
        }
    }
}
