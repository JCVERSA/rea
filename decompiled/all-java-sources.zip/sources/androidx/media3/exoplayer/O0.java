package androidx.media3.exoplayer;

import ax.P0.C1375v;
import ax.S0.C1498a;
import j$.util.Objects;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
class O0 {
    private final M0 a;
    private final int b;
    private final M0 c;
    private int d = 0;
    private boolean e = false;
    private boolean f = false;

    public O0(M0 m0, M0 m1, int i) {
        this.a = m0;
        this.b = i;
        this.c = m1;
    }

    private boolean A() {
        return this.d == 3;
    }

    private void C(M0 m0, ax.p132i1.e0 e0Var, C0628k c0628k, long j, boolean z) throws C0643s {
        if (z(m0)) {
            if (e0Var != m0.i()) {
                d(m0, c0628k);
            } else if (z) {
                m0.F(j);
            }
        }
    }

    private void E(boolean z) {
        if (z) {
            if (this.e) {
                this.a.a();
                this.e = false;
                return;
            }
            return;
        }
        if (this.f) {
            ((M0) C1498a.e(this.c)).a();
            this.f = false;
        }
    }

    private int K(M0 m0, C0641q0 c0641q0, ax.p180l1.K k, C0628k c0628k) throws C0643s {
        if (m0 == null || !z(m0) || ((m0 == this.a && w()) || (m0 == this.c && A()))) {
            return 1;
        }
        ax.p132i1.e0 e0VarI = m0.i();
        ax.p132i1.e0[] e0VarArr = c0641q0.c;
        int i = this.b;
        boolean z = e0VarI != e0VarArr[i];
        boolean zC = k.c(i);
        if (zC && !z) {
            return 1;
        }
        if (!m0.G()) {
            m0.t(i(k.c[this.b]), (ax.p132i1.e0) C1498a.e(c0641q0.c[this.b]), c0641q0.n(), c0641q0.m(), c0641q0.h.a);
            return 3;
        }
        if (!m0.c()) {
            return 0;
        }
        d(m0, c0628k);
        if (!zC || u()) {
            E(m0 == this.a);
        }
        return 1;
    }

    private void P(M0 m0, long j) {
        m0.q();
        if (m0 instanceof ax.p164k1.i) {
            ((ax.p164k1.i) m0).y0(j);
        }
    }

    private void Z(boolean z) throws C0643s {
        if (z) {
            ((M0) C1498a.e(this.c)).B(17, this.a);
        } else {
            this.a.B(17, C1498a.e(this.c));
        }
    }

    private void d(M0 m0, C0628k c0628k) {
        C1498a.g(this.a == m0 || this.c == m0);
        if (z(m0)) {
            c0628k.a(m0);
            g(m0);
            m0.e();
        }
    }

    private void g(M0 m0) {
        if (m0.getState() == 2) {
            m0.stop();
        }
    }

    private static C1375v[] i(ax.p180l1.D d) {
        int length = d != null ? d.length() : 0;
        C1375v[] c1375vArr = new C1375v[length];
        for (int i = 0; i < length; i++) {
            c1375vArr[i] = ((ax.p180l1.D) C1498a.e(d)).h(i);
        }
        return c1375vArr;
    }

    private M0 l(C0641q0 c0641q0) {
        if (c0641q0 != null && c0641q0.c[this.b] != null) {
            if (this.a.i() == c0641q0.c[this.b]) {
                return this.a;
            }
            M0 m0 = this.c;
            if (m0 != null && m0.i() == c0641q0.c[this.b]) {
                return this.c;
            }
        }
        return null;
    }

    private boolean p(C0641q0 c0641q0, M0 m0) {
        if (m0 == null) {
            return true;
        }
        ax.p132i1.e0 e0Var = c0641q0.c[this.b];
        if (m0.i() == null || (m0.i() == e0Var && (e0Var == null || m0.n() || q(m0, c0641q0)))) {
            return true;
        }
        C0641q0 c0641q0K = c0641q0.k();
        return c0641q0K != null && c0641q0K.c[this.b] == m0.i();
    }

    private boolean q(M0 m0, C0641q0 c0641q0) {
        C0641q0 c0641q0K = c0641q0.k();
        if (c0641q0.h.g && c0641q0K != null && c0641q0K.f) {
            return (m0 instanceof ax.p164k1.i) || (m0 instanceof ax.p100g1.c) || m0.D() >= c0641q0K.n();
        }
        return false;
    }

    private boolean w() {
        int i = this.d;
        return i == 2 || i == 4;
    }

    private static boolean z(M0 m0) {
        return m0.getState() != 0;
    }

    public void B(ax.p132i1.e0 e0Var, C0628k c0628k, long j, boolean z) throws C0643s {
        C(this.a, e0Var, c0628k, j, z);
        M0 m0 = this.c;
        if (m0 != null) {
            C(m0, e0Var, c0628k, j, z);
        }
    }

    public void D() throws C0643s {
        int i = this.d;
        if (i == 3 || i == 4) {
            Z(i == 4);
            this.d = this.d != 4 ? 1 : 0;
        } else if (i == 2) {
            this.d = 0;
        }
    }

    public void F(ax.p180l1.K k, ax.p180l1.K k2, long j) {
        int i;
        boolean zC = k.c(this.b);
        boolean zC2 = k2.c(this.b);
        M0 m0 = (this.c == null || (i = this.d) == 3 || (i == 0 && z(this.a))) ? this.a : (M0) C1498a.e(this.c);
        if (!zC || m0.G()) {
            return;
        }
        boolean z = m() == -2;
        ax.Y0.W[] wArr = k.b;
        int i2 = this.b;
        ax.Y0.W w = wArr[i2];
        ax.Y0.W w2 = k2.b[i2];
        if (!zC2 || !Objects.equals(w2, w) || z || u()) {
            P(m0, j);
        }
    }

    public void G(C0641q0 c0641q0) throws IOException {
        ((M0) C1498a.e(l(c0641q0))).C();
    }

    public void H() {
        this.a.h();
        this.e = false;
        M0 m0 = this.c;
        if (m0 != null) {
            m0.h();
            this.f = false;
        }
    }

    public void I(long j, long j2) throws C0643s {
        if (z(this.a)) {
            this.a.g(j, j2);
        }
        M0 m0 = this.c;
        if (m0 == null || !z(m0)) {
            return;
        }
        this.c.g(j, j2);
    }

    public int J(C0641q0 c0641q0, ax.p180l1.K k, C0628k c0628k) throws C0643s {
        int iK = K(this.a, c0641q0, k, c0628k);
        return iK == 1 ? K(this.c, c0641q0, k, c0628k) : iK;
    }

    public void L() {
        if (!z(this.a)) {
            E(true);
        }
        M0 m0 = this.c;
        if (m0 == null || z(m0)) {
            return;
        }
        E(false);
    }

    public void M(C0641q0 c0641q0, long j) throws C0643s {
        M0 m0L = l(c0641q0);
        if (m0L != null) {
            m0L.F(j);
        }
    }

    public void N(long j) {
        int i;
        if (z(this.a) && (i = this.d) != 4 && i != 2) {
            P(this.a, j);
        }
        M0 m0 = this.c;
        if (m0 == null || !z(m0) || this.d == 3) {
            return;
        }
        P(this.c, j);
    }

    public void O(C0641q0 c0641q0, long j) {
        P((M0) C1498a.e(l(c0641q0)), j);
    }

    public void Q(float f, float f2) throws C0643s {
        this.a.x(f, f2);
        M0 m0 = this.c;
        if (m0 != null) {
            m0.x(f, f2);
        }
    }

    public void R(ax.Y0.Y y) throws C0643s {
        this.a.B(18, y);
        M0 m0 = this.c;
        if (m0 != null) {
            m0.B(18, y);
        }
    }

    public void S(ax.P0.N n) {
        this.a.r(n);
        M0 m0 = this.c;
        if (m0 != null) {
            m0.r(n);
        }
    }

    public void T(ax.p228o1.z zVar) throws C0643s {
        if (m() != 2) {
            return;
        }
        this.a.B(7, zVar);
        M0 m0 = this.c;
        if (m0 != null) {
            m0.B(7, zVar);
        }
    }

    public void U(Object obj) throws C0643s {
        if (m() != 2) {
            return;
        }
        int i = this.d;
        if (i == 4 || i == 1) {
            ((M0) C1498a.e(this.c)).B(1, obj);
        } else {
            this.a.B(1, obj);
        }
    }

    public void V(float f) throws C0643s {
        if (m() != 1) {
            return;
        }
        this.a.B(2, Float.valueOf(f));
        M0 m0 = this.c;
        if (m0 != null) {
            m0.B(2, Float.valueOf(f));
        }
    }

    public void W() throws C0643s {
        if (this.a.getState() == 1 && this.d != 4) {
            this.a.start();
            return;
        }
        M0 m0 = this.c;
        if (m0 == null || m0.getState() != 1 || this.d == 3) {
            return;
        }
        this.c.start();
    }

    public void X() {
        int i;
        C1498a.g(!u());
        if (z(this.a)) {
            i = 3;
        } else {
            M0 m0 = this.c;
            i = (m0 == null || !z(m0)) ? 2 : 4;
        }
        this.d = i;
    }

    public void Y() {
        if (z(this.a)) {
            g(this.a);
        }
        M0 m0 = this.c;
        if (m0 == null || !z(m0)) {
            return;
        }
        g(this.c);
    }

    public boolean a(C0641q0 c0641q0) {
        M0 m0L = l(c0641q0);
        return m0L == null || m0L.n() || m0L.isReady() || m0L.c();
    }

    public void b(C0628k c0628k) throws C0643s {
        d(this.a, c0628k);
        M0 m0 = this.c;
        if (m0 != null) {
            boolean z = z(m0) && this.d != 3;
            d(this.c, c0628k);
            E(false);
            if (z) {
                Z(true);
            }
        }
        this.d = 0;
    }

    public void c(C0628k c0628k) {
        if (u()) {
            int i = this.d;
            boolean z = i == 4 || i == 2;
            int i2 = i != 4 ? 0 : 1;
            d(z ? this.a : (M0) C1498a.e(this.c), c0628k);
            E(z);
            this.d = i2;
        }
    }

    public void e(ax.Y0.W w, ax.p180l1.D d, ax.p132i1.e0 e0Var, long j, boolean z, boolean z2, long j2, long j3, ax.i1.F.b bVar, C0628k c0628k) throws C0643s {
        C1375v[] c1375vArrI = i(d);
        int i = this.d;
        if (i == 0 || i == 2 || i == 4) {
            this.e = true;
            this.a.s(w, c1375vArrI, e0Var, j, z, z2, j2, j3, bVar);
            c0628k.b(this.a);
        } else {
            this.f = true;
            ((M0) C1498a.e(this.c)).s(w, c1375vArrI, e0Var, j, z, z2, j2, j3, bVar);
            c0628k.b(this.c);
        }
    }

    public void f() {
        if (z(this.a)) {
            this.a.p();
            return;
        }
        M0 m0 = this.c;
        if (m0 == null || !z(m0)) {
            return;
        }
        this.c.p();
    }

    public int h() {
        boolean z = z(this.a);
        M0 m0 = this.c;
        return (z ? 1 : 0) + ((m0 == null || !z(m0)) ? 0 : 1);
    }

    public long j(long j, long j2) {
        long jO = z(this.a) ? this.a.o(j, j2) : Long.MAX_VALUE;
        M0 m0 = this.c;
        return (m0 == null || !z(m0)) ? jO : Math.min(jO, this.c.o(j, j2));
    }

    public long k(C0641q0 c0641q0) {
        M0 m0L = l(c0641q0);
        Objects.requireNonNull(m0L);
        return m0L.D();
    }

    public int m() {
        return this.a.j();
    }

    public void n(int i, Object obj, C0641q0 c0641q0) throws C0643s {
        ((M0) C1498a.e(l(c0641q0))).B(i, obj);
    }

    public boolean o(C0641q0 c0641q0) {
        return p(c0641q0, this.a) && p(c0641q0, this.c);
    }

    public boolean r(C0641q0 c0641q0) {
        return ((M0) C1498a.e(l(c0641q0))).n();
    }

    public boolean s() {
        return this.c != null;
    }

    public boolean t() {
        boolean zC = z(this.a) ? this.a.c() : true;
        M0 m0 = this.c;
        return (m0 == null || !z(m0)) ? zC : zC & this.c.c();
    }

    public boolean u() {
        return w() || A();
    }

    public boolean v(C0641q0 c0641q0) {
        return (w() && l(c0641q0) == this.a) || (A() && l(c0641q0) == this.c);
    }

    public boolean x(C0641q0 c0641q0) {
        return l(c0641q0) != null;
    }

    public boolean y() {
        int i = this.d;
        return (i == 0 || i == 2 || i == 4) ? z(this.a) : z((M0) C1498a.e(this.c));
    }
}
