package androidx.media3.exoplayer;

import ax.S0.C1498a;
import ax.S0.C1517u;
import ax.p132i1.C2098e;
import ax.p132i1.C2111s;
import java.io.IOException;

/* JADX INFO: renamed from: androidx.media3.exoplayer.q0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0641q0 {
    public final ax.p132i1.C a;
    public final Object b;
    public final ax.p132i1.e0[] c;
    public final long d;
    public boolean e;
    public boolean f;
    public boolean g;
    public C0642r0 h;
    public boolean i;
    private final boolean[] j;
    private final N0[] k;
    private final ax.p180l1.J l;
    private final I0 m;
    private C0641q0 n;
    private ax.p132i1.q0 o;
    private ax.p180l1.K p;
    private long q;

    /* JADX INFO: renamed from: androidx.media3.exoplayer.q0$a */
    interface a {
        C0641q0 a(C0642r0 c0642r0, long j);
    }

    public C0641q0(N0[] n0Arr, long j, ax.p180l1.J j2, ax.p196m1.b bVar, I0 i0, C0642r0 c0642r0, ax.p180l1.K k, long j3) {
        this.k = n0Arr;
        this.q = j;
        this.l = j2;
        this.m = i0;
        ax.i1.F.b bVar2 = c0642r0.a;
        this.b = bVar2.a;
        this.h = c0642r0;
        this.d = j3;
        this.o = ax.p132i1.q0.d;
        this.p = k;
        this.c = new ax.p132i1.e0[n0Arr.length];
        this.j = new boolean[n0Arr.length];
        this.a = f(bVar2, i0, bVar, c0642r0.b, c0642r0.d, c0642r0.f);
    }

    private void c(ax.p132i1.e0[] e0VarArr) {
        int i = 0;
        while (true) {
            N0[] n0Arr = this.k;
            if (i >= n0Arr.length) {
                return;
            }
            if (n0Arr[i].j() == -2 && this.p.c(i)) {
                e0VarArr[i] = new C2111s();
            }
            i++;
        }
    }

    private static ax.p132i1.C f(ax.i1.F.b bVar, I0 i0, ax.p196m1.b bVar2, long j, long j2, boolean z) {
        ax.p132i1.C cH = i0.h(bVar, bVar2, j);
        return j2 != -9223372036854775807L ? new C2098e(cH, !z, 0L, j2) : cH;
    }

    private void g() {
        if (!u()) {
            return;
        }
        int i = 0;
        while (true) {
            ax.p180l1.K k = this.p;
            if (i >= k.a) {
                return;
            }
            boolean zC = k.c(i);
            ax.p180l1.D d = this.p.c[i];
            if (zC && d != null) {
                d.e();
            }
            i++;
        }
    }

    private void h(ax.p132i1.e0[] e0VarArr) {
        int i = 0;
        while (true) {
            N0[] n0Arr = this.k;
            if (i >= n0Arr.length) {
                return;
            }
            if (n0Arr[i].j() == -2) {
                e0VarArr[i] = null;
            }
            i++;
        }
    }

    private void i() {
        if (!u()) {
            return;
        }
        int i = 0;
        while (true) {
            ax.p180l1.K k = this.p;
            if (i >= k.a) {
                return;
            }
            boolean zC = k.c(i);
            ax.p180l1.D d = this.p.c[i];
            if (zC && d != null) {
                d.i();
            }
            i++;
        }
    }

    private boolean u() {
        return this.n == null;
    }

    private static void y(I0 i0, ax.p132i1.C c) {
        try {
            if (c instanceof C2098e) {
                i0.z(((C2098e) c).q);
            } else {
                i0.z(c);
            }
        } catch (RuntimeException e) {
            C1517u.d("MediaPeriodHolder", "Period release failed.", e);
        }
    }

    public void A(C0641q0 c0641q0) {
        if (c0641q0 == this.n) {
            return;
        }
        g();
        this.n = c0641q0;
        i();
    }

    public void B(long j) {
        this.q = j;
    }

    public long C(long j) {
        return j - m();
    }

    public long D(long j) {
        return j + m();
    }

    public void E() {
        ax.p132i1.C c = this.a;
        if (c instanceof C2098e) {
            long j = this.h.d;
            if (j == -9223372036854775807L) {
                j = Long.MIN_VALUE;
            }
            ((C2098e) c).x(0L, j);
        }
    }

    public long a(ax.p180l1.K k, long j, boolean z) {
        return b(k, j, z, new boolean[this.k.length]);
    }

    public long b(ax.p180l1.K k, long j, boolean z, boolean[] zArr) {
        int i = 0;
        while (true) {
            boolean z2 = true;
            if (i >= k.a) {
                break;
            }
            boolean[] zArr2 = this.j;
            if (z || !k.b(this.p, i)) {
                z2 = false;
            }
            zArr2[i] = z2;
            i++;
        }
        h(this.c);
        g();
        this.p = k;
        i();
        long jG = this.a.g(k.c, this.j, this.c, zArr, j);
        c(this.c);
        this.g = false;
        int i2 = 0;
        while (true) {
            ax.p132i1.e0[] e0VarArr = this.c;
            if (i2 >= e0VarArr.length) {
                return jG;
            }
            if (e0VarArr[i2] != null) {
                C1498a.g(k.c(i2));
                if (this.k[i2].j() != -2) {
                    this.g = true;
                }
            } else {
                C1498a.g(k.c[i2] == null);
            }
            i2++;
        }
    }

    public boolean d(C0642r0 c0642r0) {
        if (!C0646t0.e(this.h.e, c0642r0.e)) {
            return false;
        }
        C0642r0 c0642r1 = this.h;
        return c0642r1.b == c0642r0.b && c0642r1.a.equals(c0642r0.a);
    }

    public void e(C0639p0 c0639p0) {
        C1498a.g(u());
        this.a.a(c0639p0);
    }

    public long j() {
        if (!this.f) {
            return this.h.b;
        }
        long jD = this.g ? this.a.d() : Long.MIN_VALUE;
        return jD == Long.MIN_VALUE ? this.h.e : jD;
    }

    public C0641q0 k() {
        return this.n;
    }

    public long l() {
        if (this.f) {
            return this.a.b();
        }
        return 0L;
    }

    public long m() {
        return this.q;
    }

    public long n() {
        return this.h.b + this.q;
    }

    public ax.p132i1.q0 o() {
        return this.o;
    }

    public ax.p180l1.K p() {
        return this.p;
    }

    public void q(float f, ax.P0.N n, boolean z) throws C0643s {
        this.f = true;
        this.o = this.a.t();
        ax.p180l1.K kZ = z(f, n, z);
        C0642r0 c0642r0 = this.h;
        long jMax = c0642r0.b;
        long j = c0642r0.e;
        if (j != -9223372036854775807L && jMax >= j) {
            jMax = Math.max(0L, j - 1);
        }
        long jA = a(kZ, jMax, false);
        long j2 = this.q;
        C0642r0 c0642r1 = this.h;
        this.q = j2 + (c0642r1.b - jA);
        this.h = c0642r1.b(jA);
    }

    public boolean r() {
        try {
            if (this.f) {
                for (ax.p132i1.e0 e0Var : this.c) {
                    if (e0Var != null) {
                        e0Var.b();
                    }
                }
            } else {
                this.a.l();
            }
            return false;
        } catch (IOException unused) {
            return true;
        }
    }

    public boolean s() {
        if (this.f) {
            return !this.g || this.a.d() == Long.MIN_VALUE;
        }
        return false;
    }

    public boolean t() {
        if (this.f) {
            return s() || j() - this.h.b >= this.d;
        }
        return false;
    }

    public void v(ax.i1.C.a aVar, long j) {
        this.e = true;
        this.a.n(aVar, j);
    }

    public void w(long j) {
        C1498a.g(u());
        if (this.f) {
            this.a.e(C(j));
        }
    }

    public void x() {
        g();
        y(this.m, this.a);
    }

    public ax.p180l1.K z(float f, ax.P0.N n, boolean z) throws C0643s {
        ax.p180l1.K k = this.l.k(this.k, o(), this.h.a, n);
        for (int i = 0; i < k.a; i++) {
            boolean z2 = true;
            if (k.c(i)) {
                if (k.c[i] == null && this.k[i].j() != -2) {
                    z2 = false;
                }
                C1498a.g(z2);
            } else {
                C1498a.g(k.c[i] == null);
            }
        }
        for (ax.p180l1.D d : k.c) {
            if (d != null) {
                d.p(f);
                d.g(z);
            }
        }
        return k;
    }
}
