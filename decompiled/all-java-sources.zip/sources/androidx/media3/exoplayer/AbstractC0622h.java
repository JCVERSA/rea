package androidx.media3.exoplayer;

import ax.P0.C1375v;
import ax.S0.C1498a;
import ax.S0.InterfaceC1505h;
import ax.Z0.I1;
import j$.util.Objects;
import java.io.IOException;

/* JADX INFO: renamed from: androidx.media3.exoplayer.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0622h implements M0, N0 {
    private final int X;
    private ax.Y0.W Z;
    private int k0;
    private I1 l0;
    private InterfaceC1505h m0;
    private int n0;
    private ax.p132i1.e0 o0;
    private C1375v[] p0;
    private long q0;
    private long r0;
    private boolean t0;
    private boolean u0;
    private ax.i1.F.b w0;
    private N0.a x0;
    private final Object q = new Object();
    private final ax.Y0.O Y = new ax.Y0.O();
    private long s0 = Long.MIN_VALUE;
    private ax.P0.N v0 = ax.P0.N.a;

    public AbstractC0622h(int i) {
        this.X = i;
    }

    private void g0(long j, boolean z) throws C0643s {
        this.t0 = false;
        this.r0 = j;
        this.s0 = j;
        X(j, z);
    }

    public int A() throws C0643s {
        return 0;
    }

    @Override // androidx.media3.exoplayer.K0.b
    public void B(int i, Object obj) throws C0643s {
    }

    @Override // androidx.media3.exoplayer.M0
    public final void C() throws IOException {
        ((ax.p132i1.e0) C1498a.e(this.o0)).b();
    }

    @Override // androidx.media3.exoplayer.M0
    public final long D() {
        return this.s0;
    }

    @Override // androidx.media3.exoplayer.M0
    public final void F(long j) throws C0643s {
        g0(j, false);
    }

    @Override // androidx.media3.exoplayer.M0
    public final boolean G() {
        return this.t0;
    }

    @Override // androidx.media3.exoplayer.M0
    public ax.Y0.S H() {
        return null;
    }

    protected final C0643s I(Throwable th, C1375v c1375v, int i) {
        return J(th, c1375v, false, i);
    }

    protected final C0643s J(Throwable th, C1375v c1375v, boolean z, int i) {
        int i2;
        if (c1375v == null || this.u0) {
            i2 = 4;
        } else {
            this.u0 = true;
            try {
                int i3 = ax.Y0.V.i(b(c1375v));
                this.u0 = false;
                i2 = i3;
            } catch (C0643s unused) {
                this.u0 = false;
                i2 = 4;
            } catch (Throwable th2) {
                this.u0 = false;
                throw th2;
            }
        }
        return C0643s.d(th, getName(), N(), c1375v, i2, this.w0, z, i);
    }

    protected final InterfaceC1505h K() {
        return (InterfaceC1505h) C1498a.e(this.m0);
    }

    protected final ax.Y0.W L() {
        return (ax.Y0.W) C1498a.e(this.Z);
    }

    protected final ax.Y0.O M() {
        this.Y.a();
        return this.Y;
    }

    protected final int N() {
        return this.k0;
    }

    protected final long O() {
        return this.r0;
    }

    protected final I1 P() {
        return (I1) C1498a.e(this.l0);
    }

    protected final C1375v[] Q() {
        return (C1375v[]) C1498a.e(this.p0);
    }

    protected final long R() {
        return this.q0;
    }

    protected final ax.P0.N S() {
        return this.v0;
    }

    protected final boolean T() {
        return n() ? this.t0 : ((ax.p132i1.e0) C1498a.e(this.o0)).isReady();
    }

    protected abstract void U();

    protected void V(boolean z, boolean z2) throws C0643s {
    }

    protected void W() {
    }

    protected abstract void X(long j, boolean z) throws C0643s;

    protected void Y() {
    }

    protected final void Z() {
        N0.a aVar;
        synchronized (this.q) {
            aVar = this.x0;
        }
        if (aVar != null) {
            aVar.a(this);
        }
    }

    @Override // androidx.media3.exoplayer.M0
    public final void a() {
        C1498a.g(this.n0 == 0);
        this.Y.a();
        a0();
    }

    protected void a0() {
    }

    protected void b0() throws C0643s {
    }

    protected void c0() {
    }

    protected void d0(C1375v[] c1375vArr, long j, long j2, ax.i1.F.b bVar) throws C0643s {
    }

    @Override // androidx.media3.exoplayer.M0
    public final void e() {
        C1498a.g(this.n0 == 1);
        this.Y.a();
        this.n0 = 0;
        this.o0 = null;
        this.p0 = null;
        this.t0 = false;
        U();
        this.w0 = null;
    }

    protected void e0(ax.P0.N n) {
    }

    protected final int f0(ax.Y0.O o, ax.V0.i iVar, int i) {
        int iA = ((ax.p132i1.e0) C1498a.e(this.o0)).a(o, iVar, i);
        if (iA != -4) {
            if (iA == -5) {
                C1375v c1375v = (C1375v) C1498a.e(o.b);
                if (c1375v.t != Long.MAX_VALUE) {
                    o.b = c1375v.b().C0(c1375v.t + this.q0).P();
                }
            }
            return iA;
        }
        if (iVar.t()) {
            this.s0 = Long.MIN_VALUE;
            return this.t0 ? -4 : -3;
        }
        long j = iVar.l0 + this.q0;
        iVar.l0 = j;
        this.s0 = Math.max(this.s0, j);
        return iA;
    }

    @Override // androidx.media3.exoplayer.M0
    public final int getState() {
        return this.n0;
    }

    @Override // androidx.media3.exoplayer.M0
    public final void h() {
        C1498a.g(this.n0 == 0);
        Y();
    }

    protected int h0(long j) {
        return ((ax.p132i1.e0) C1498a.e(this.o0)).c(j - this.q0);
    }

    @Override // androidx.media3.exoplayer.M0
    public final ax.p132i1.e0 i() {
        return this.o0;
    }

    @Override // androidx.media3.exoplayer.M0, androidx.media3.exoplayer.N0
    public final int j() {
        return this.X;
    }

    @Override // androidx.media3.exoplayer.N0
    public final void l() {
        synchronized (this.q) {
            this.x0 = null;
        }
    }

    @Override // androidx.media3.exoplayer.M0
    public final void m(int i, I1 i1, InterfaceC1505h interfaceC1505h) {
        this.k0 = i;
        this.l0 = i1;
        this.m0 = interfaceC1505h;
        W();
    }

    @Override // androidx.media3.exoplayer.M0
    public final boolean n() {
        return this.s0 == Long.MIN_VALUE;
    }

    @Override // androidx.media3.exoplayer.M0
    public /* synthetic */ long o(long j, long j2) {
        return ax.Y0.U.b(this, j, j2);
    }

    @Override // androidx.media3.exoplayer.M0
    public /* synthetic */ void p() {
        ax.Y0.U.a(this);
    }

    @Override // androidx.media3.exoplayer.M0
    public final void q() {
        this.t0 = true;
    }

    @Override // androidx.media3.exoplayer.M0
    public final void r(ax.P0.N n) {
        if (Objects.equals(this.v0, n)) {
            return;
        }
        this.v0 = n;
        e0(n);
    }

    @Override // androidx.media3.exoplayer.M0
    public final void s(ax.Y0.W w, C1375v[] c1375vArr, ax.p132i1.e0 e0Var, long j, boolean z, boolean z2, long j2, long j3, ax.i1.F.b bVar) throws C0643s {
        C1498a.g(this.n0 == 0);
        this.Z = w;
        this.w0 = bVar;
        this.n0 = 1;
        V(z, z2);
        t(c1375vArr, e0Var, j2, j3, bVar);
        g0(j2, z);
    }

    @Override // androidx.media3.exoplayer.M0
    public final void start() throws C0643s {
        C1498a.g(this.n0 == 1);
        this.n0 = 2;
        b0();
    }

    @Override // androidx.media3.exoplayer.M0
    public final void stop() {
        C1498a.g(this.n0 == 2);
        this.n0 = 1;
        c0();
    }

    @Override // androidx.media3.exoplayer.M0
    public final void t(C1375v[] c1375vArr, ax.p132i1.e0 e0Var, long j, long j2, ax.i1.F.b bVar) throws C0643s {
        C1498a.g(!this.t0);
        this.o0 = e0Var;
        this.w0 = bVar;
        if (this.s0 == Long.MIN_VALUE) {
            this.s0 = j;
        }
        this.p0 = c1375vArr;
        this.q0 = j2;
        d0(c1375vArr, j, j2, bVar);
    }

    @Override // androidx.media3.exoplayer.M0
    public final N0 u() {
        return this;
    }

    @Override // androidx.media3.exoplayer.N0
    public final void v(N0.a aVar) {
        synchronized (this.q) {
            this.x0 = aVar;
        }
    }

    @Override // androidx.media3.exoplayer.M0
    public /* synthetic */ void x(float f, float f2) throws C0643s {
        ax.Y0.U.c(this, f, f2);
    }
}
