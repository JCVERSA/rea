package androidx.media3.exoplayer;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Looper;
import ax.S0.InterfaceC1505h;
import ax.S0.InterfaceC1514q;

/* JADX INFO: renamed from: androidx.media3.exoplayer.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0614d {
    private final Context a;
    private final a b;
    private final InterfaceC1514q c;
    private boolean d;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: androidx.media3.exoplayer.d$a */
    final class a extends BroadcastReceiver {
        private final b a;
        private final InterfaceC1514q b;

        public a(InterfaceC1514q interfaceC1514q, b bVar) {
            this.b = interfaceC1514q;
            this.a = bVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void b() {
            if (C0614d.this.d) {
                this.a.g();
            }
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("android.media.AUDIO_BECOMING_NOISY".equals(intent.getAction())) {
                this.b.c(new Runnable() { // from class: androidx.media3.exoplayer.c
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.q.b();
                    }
                });
            }
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.d$b */
    public interface b {
        void g();
    }

    public C0614d(Context context, Looper looper, Looper looper2, b bVar, InterfaceC1505h interfaceC1505h) {
        this.a = context.getApplicationContext();
        this.c = interfaceC1505h.d(looper, null);
        this.b = new a(interfaceC1505h.d(looper2, null), bVar);
    }

    @SuppressLint({"UnprotectedReceiver"})
    public void d(boolean z) {
        if (z == this.d) {
            return;
        }
        if (z) {
            this.c.c(new Runnable() { // from class: androidx.media3.exoplayer.a
                @Override // java.lang.Runnable
                public final void run() {
                    C0614d c0614d = this.q;
                    c0614d.a.registerReceiver(c0614d.b, new IntentFilter("android.media.AUDIO_BECOMING_NOISY"));
                }
            });
            this.d = true;
        } else {
            this.c.c(new Runnable() { // from class: androidx.media3.exoplayer.b
                @Override // java.lang.Runnable
                public final void run() {
                    C0614d c0614d = this.q;
                    c0614d.a.unregisterReceiver(c0614d.b);
                }
            });
            this.d = false;
        }
    }
}
