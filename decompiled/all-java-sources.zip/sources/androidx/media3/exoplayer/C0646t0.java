package androidx.media3.exoplayer;

import android.util.Pair;
import ax.S0.C1498a;
import ax.S0.InterfaceC1514q;
import ax.Y7.AbstractC1656z;
import ax.Z0.InterfaceC1657a;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: androidx.media3.exoplayer.t0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0646t0 {
    private final InterfaceC1657a c;
    private final InterfaceC1514q d;
    private final C0641q0.a e;
    private long f;
    private int g;
    private boolean h;
    private ExoPlayer.c i;
    private C0641q0 j;
    private C0641q0 k;
    private C0641q0 l;
    private C0641q0 m;
    private C0641q0 n;
    private int o;
    private Object p;
    private long q;
    private final ax.P0.N.b a = new ax.P0.N.b();
    private final ax.P0.N.c b = new ax.P0.N.c();
    private List<C0641q0> r = new ArrayList();

    public C0646t0(InterfaceC1657a interfaceC1657a, InterfaceC1514q interfaceC1514q, C0641q0.a aVar, ExoPlayer.c cVar) {
        this.c = interfaceC1657a;
        this.d = interfaceC1514q;
        this.e = aVar;
        this.i = cVar;
    }

    private boolean A(Object obj, ax.P0.N n) {
        int iC = n.h(obj, this.a).c();
        int iP = this.a.p();
        if (iC <= 0 || !this.a.s(iP)) {
            return false;
        }
        return iC > 1 || this.a.f(iP) != Long.MIN_VALUE;
    }

    private boolean C(ax.i1.F.b bVar) {
        return !bVar.b() && bVar.e == -1;
    }

    private boolean D(ax.P0.N n, ax.i1.F.b bVar, boolean z) {
        int iB = n.b(bVar.a);
        return !n.n(n.f(iB, this.a).c, this.b).i && n.r(iB, this.a, this.b, this.g, this.h) && z;
    }

    private boolean E(ax.P0.N n, ax.i1.F.b bVar) {
        if (C(bVar)) {
            return n.n(n.h(bVar.a, this.a).c, this.b).o == n.b(bVar.a);
        }
        return false;
    }

    private static boolean H(ax.P0.N.b bVar) {
        int iC = bVar.c();
        if (iC != 0 && ((iC != 1 || !bVar.r(0)) && bVar.s(bVar.p()))) {
            long jI = 0;
            if (bVar.e(0L) == -1) {
                if (bVar.d == 0) {
                    return true;
                }
                int i = iC - (bVar.r(iC + (-1)) ? 2 : 1);
                for (int i2 = 0; i2 <= i; i2++) {
                    jI += bVar.i(i2);
                }
                if (bVar.d <= jI) {
                    return true;
                }
            }
        }
        return false;
    }

    private void J() {
        final AbstractC1656z.a aVarQ = AbstractC1656z.q();
        for (C0641q0 c0641q0K = this.j; c0641q0K != null; c0641q0K = c0641q0K.k()) {
            aVarQ.a(c0641q0K.h.a);
        }
        C0641q0 c0641q0 = this.k;
        final ax.i1.F.b bVar = c0641q0 == null ? null : c0641q0.h.a;
        this.d.c(new Runnable() { // from class: androidx.media3.exoplayer.s0
            @Override // java.lang.Runnable
            public final void run() {
                this.q.c.p0(aVarQ.k(), bVar);
            }
        });
    }

    private void L(List<C0641q0> list) {
        for (int i = 0; i < this.r.size(); i++) {
            this.r.get(i).x();
        }
        this.r = list;
        this.n = null;
        I();
    }

    private C0641q0 O(C0642r0 c0642r0) {
        for (int i = 0; i < this.r.size(); i++) {
            if (this.r.get(i).d(c0642r0)) {
                return this.r.remove(i);
            }
        }
        return null;
    }

    private static ax.i1.F.b P(ax.P0.N n, Object obj, long j, long j2, ax.P0.N.c cVar, ax.P0.N.b bVar) {
        n.h(obj, bVar);
        n.n(bVar.c, cVar);
        for (int iB = n.b(obj); H(bVar) && iB <= cVar.o; iB++) {
            n.g(iB, bVar, true);
            obj = C1498a.e(bVar.b);
        }
        n.h(obj, bVar);
        int iE = bVar.e(j);
        return iE == -1 ? new ax.i1.F.b(obj, j2, bVar.d(j)) : new ax.i1.F.b(obj, iE, bVar.l(iE), j2);
    }

    private long R(ax.P0.N n, Object obj) {
        int iB;
        int i = n.h(obj, this.a).c;
        Object obj2 = this.p;
        if (obj2 != null && (iB = n.b(obj2)) != -1 && n.f(iB, this.a).c == i) {
            return this.q;
        }
        for (C0641q0 c0641q0K = this.j; c0641q0K != null; c0641q0K = c0641q0K.k()) {
            if (c0641q0K.b.equals(obj)) {
                return c0641q0K.h.a.d;
            }
        }
        for (C0641q0 c0641q0K2 = this.j; c0641q0K2 != null; c0641q0K2 = c0641q0K2.k()) {
            int iB2 = n.b(c0641q0K2.b);
            if (iB2 != -1 && n.f(iB2, this.a).c == i) {
                return c0641q0K2.h.a.d;
            }
        }
        long jS = S(obj);
        if (jS != -1) {
            return jS;
        }
        long j = this.f;
        this.f = 1 + j;
        if (this.j == null) {
            this.p = obj;
            this.q = j;
        }
        return j;
    }

    private long S(Object obj) {
        for (int i = 0; i < this.r.size(); i++) {
            C0641q0 c0641q0 = this.r.get(i);
            if (c0641q0.b.equals(obj)) {
                return c0641q0.h.a.d;
            }
        }
        return -1L;
    }

    private int U(ax.P0.N n) {
        ax.P0.N n2;
        C0641q0 c0641q0K = this.j;
        if (c0641q0K == null) {
            return 0;
        }
        int iB = n.b(c0641q0K.b);
        while (true) {
            n2 = n;
            iB = n2.d(iB, this.a, this.b, this.g, this.h);
            while (((C0641q0) C1498a.e(c0641q0K)).k() != null && !c0641q0K.h.h) {
                c0641q0K = c0641q0K.k();
            }
            C0641q0 c0641q0K2 = c0641q0K.k();
            if (iB == -1 || c0641q0K2 == null || n2.b(c0641q0K2.b) != iB) {
                break;
            }
            c0641q0K = c0641q0K2;
            n = n2;
        }
        int iN = N(c0641q0K);
        c0641q0K.h = z(n2, c0641q0K.h);
        return iN;
    }

    static boolean e(long j, long j2) {
        return j == -9223372036854775807L || j == j2;
    }

    private boolean f(C0642r0 c0642r0, C0642r0 c0642r1) {
        return c0642r0.b == c0642r1.b && c0642r0.a.equals(c0642r1.a);
    }

    private Pair<Object, Long> i(ax.P0.N n, Object obj, long j) {
        int iE = n.e(n.h(obj, this.a).c, this.g, this.h);
        if (iE != -1) {
            return n.k(this.b, this.a, iE, -9223372036854775807L, j);
        }
        return null;
    }

    private C0642r0 j(J0 j0) {
        return o(j0.a, j0.b, j0.c, j0.s);
    }

    private C0642r0 k(ax.P0.N n, C0641q0 c0641q0, long j) {
        Object obj;
        long j2;
        C0642r0 c0642r0 = c0641q0.h;
        int iD = n.d(n.b(c0642r0.a.a), this.a, this.b, this.g, this.h);
        if (iD == -1) {
            return null;
        }
        int i = n.g(iD, this.a, true).c;
        Object objE = C1498a.e(this.a.b);
        long j3 = c0642r0.a.d;
        long j4 = 0;
        if (n.n(i, this.b).n == iD) {
            Pair<Object, Long> pairK = n.k(this.b, this.a, i, -9223372036854775807L, Math.max(0L, j));
            if (pairK == null) {
                return null;
            }
            Object obj2 = pairK.first;
            long jLongValue = ((Long) pairK.second).longValue();
            C0641q0 c0641q0K = c0641q0.k();
            if (c0641q0K == null || !c0641q0K.b.equals(obj2)) {
                long jS = S(obj2);
                if (jS == -1) {
                    jS = this.f;
                    this.f = 1 + jS;
                }
                j3 = jS;
            } else {
                j3 = c0641q0K.h.a.d;
            }
            obj = obj2;
            j2 = jLongValue;
            j4 = -9223372036854775807L;
        } else {
            obj = objE;
            j2 = 0;
        }
        ax.i1.F.b bVarP = P(n, obj, j2, j3, this.b, this.a);
        if (j4 != -9223372036854775807L && c0642r0.c != -9223372036854775807L) {
            boolean zA = A(c0642r0.a.a, n);
            if (bVarP.b() && zA) {
                j4 = c0642r0.c;
            } else if (zA) {
                j2 = c0642r0.c;
            }
        }
        return o(n, bVarP, j4, j2);
    }

    private C0642r0 l(ax.P0.N n, C0641q0 c0641q0, long j) {
        C0642r0 c0642r0 = c0641q0.h;
        long jM = (c0641q0.m() + c0642r0.e) - j;
        return c0642r0.h ? k(n, c0641q0, jM) : m(n, c0641q0, jM);
    }

    private C0642r0 m(ax.P0.N n, C0641q0 c0641q0, long j) {
        C0642r0 c0642r0 = c0641q0.h;
        ax.i1.F.b bVar = c0642r0.a;
        n.h(bVar.a, this.a);
        boolean z = c0642r0.g;
        if (!bVar.b()) {
            int i = bVar.e;
            if (i != -1 && this.a.r(i)) {
                return k(n, c0641q0, j);
            }
            int iL = this.a.l(bVar.e);
            boolean z2 = this.a.s(bVar.e) && this.a.h(bVar.e, iL) == 3;
            if (iL == this.a.a(bVar.e) || z2) {
                return q(n, bVar.a, s(n, bVar.a, bVar.e), c0642r0.e, bVar.d, false);
            }
            return p(n, bVar.a, bVar.e, iL, c0642r0.e, bVar.d, z);
        }
        int i2 = bVar.b;
        int iA = this.a.a(i2);
        if (iA == -1) {
            return null;
        }
        int iM = this.a.m(i2, bVar.c);
        if (iM < iA) {
            return p(n, bVar.a, i2, iM, c0642r0.c, bVar.d, z);
        }
        long jLongValue = c0642r0.c;
        if (jLongValue == -9223372036854775807L) {
            ax.P0.N.c cVar = this.b;
            ax.P0.N.b bVar2 = this.a;
            Pair<Object, Long> pairK = n.k(cVar, bVar2, bVar2.c, -9223372036854775807L, Math.max(0L, j));
            if (pairK == null) {
                return null;
            }
            jLongValue = ((Long) pairK.second).longValue();
        }
        return q(n, bVar.a, Math.max(s(n, bVar.a, bVar.b), jLongValue), c0642r0.c, bVar.d, z);
    }

    private C0642r0 o(ax.P0.N n, ax.i1.F.b bVar, long j, long j2) {
        n.h(bVar.a, this.a);
        return bVar.b() ? p(n, bVar.a, bVar.b, bVar.c, j, bVar.d, false) : q(n, bVar.a, j2, j, bVar.d, false);
    }

    private C0642r0 p(ax.P0.N n, Object obj, int i, int i2, long j, long j2, boolean z) {
        ax.i1.F.b bVar = new ax.i1.F.b(obj, i, i2, j2);
        long jB = n.h(bVar.a, this.a).b(bVar.b, bVar.c);
        long jG = i2 == this.a.l(i) ? this.a.g() : 0L;
        boolean zS = this.a.s(bVar.b);
        if (jB != -9223372036854775807L && jG >= jB) {
            jG = Math.max(0L, jB - 1);
        }
        return new C0642r0(bVar, jG, j, -9223372036854775807L, jB, z, zS, false, false, false);
    }

    /* JADX WARN: Code duplicated, block: B:47:0x00b5  */
    private C0642r0 q(ax.P0.N n, Object obj, long j, long j2, long j3, boolean z) {
        boolean z2;
        long j4;
        long jF;
        long j5;
        long jMax = j;
        n.h(obj, this.a);
        int iD = this.a.d(jMax);
        int i = 1;
        if (iD == -1) {
            if (this.a.c() > 0) {
                ax.P0.N.b bVar = this.a;
                z2 = bVar.s(bVar.p());
            }
        } else {
            if (this.a.s(iD)) {
                long jF2 = this.a.f(iD);
                ax.P0.N.b bVar2 = this.a;
                if (jF2 == bVar2.d && bVar2.q(iD)) {
                    iD = -1;
                }
            }
        }
        ax.i1.F.b bVar3 = new ax.i1.F.b(obj, j3, iD);
        boolean zC = C(bVar3);
        boolean zE = E(n, bVar3);
        boolean zD = D(n, bVar3, zC);
        boolean z3 = (iD == -1 || !this.a.s(iD) || this.a.r(iD)) ? false : true;
        boolean z4 = iD != -1 && this.a.r(iD) && this.a.s(iD);
        if (iD == -1 || z4) {
            if (z2) {
                jF = this.a.d;
            } else {
                j4 = -9223372036854775807L;
            }
            if (j4 != -9223372036854775807L || j4 == Long.MIN_VALUE) {
                j5 = this.a.d;
            } else {
                j5 = j4;
            }
            if (j5 != -9223372036854775807L && jMax >= j5) {
                if (!zD && z2) {
                    i = 0;
                }
                jMax = Math.max(0L, j5 - ((long) i));
            }
            return new C0642r0(bVar3, jMax, j2, j4, j5, z, z3, zC, zE, zD);
        }
        jF = this.a.f(iD);
        j4 = jF;
        if (j4 != -9223372036854775807L) {
            j5 = this.a.d;
        } else {
            j5 = this.a.d;
        }
        if (j5 != -9223372036854775807L) {
            if (!zD) {
                i = 0;
            }
            jMax = Math.max(0L, j5 - ((long) i));
        }
        return new C0642r0(bVar3, jMax, j2, j4, j5, z, z3, zC, zE, zD);
    }

    private C0642r0 r(ax.P0.N n, Object obj, long j, long j2) {
        ax.i1.F.b bVarP = P(n, obj, j, j2, this.b, this.a);
        return bVarP.b() ? p(n, bVarP.a, bVarP.b, bVarP.c, j, bVarP.d, false) : q(n, bVarP.a, j, -9223372036854775807L, bVarP.d, false);
    }

    private long s(ax.P0.N n, Object obj, int i) {
        n.h(obj, this.a);
        long jF = this.a.f(i);
        return jF == Long.MIN_VALUE ? this.a.d : jF + this.a.i(i);
    }

    public void B(ax.P0.N n) {
        C0641q0 c0641q0;
        if (this.i.a == -9223372036854775807L || (c0641q0 = this.m) == null) {
            M();
            return;
        }
        ArrayList arrayList = new ArrayList();
        Pair<Object, Long> pairI = i(n, c0641q0.h.a.a, 0L);
        if (pairI != null && !n.n(n.h(pairI.first, this.a).c, this.b).f()) {
            long jS = S(pairI.first);
            if (jS == -1) {
                jS = this.f;
                this.f = 1 + jS;
            }
            C0642r0 c0642r0R = r(n, pairI.first, ((Long) pairI.second).longValue(), jS);
            C0641q0 c0641q0O = O(c0642r0R);
            if (c0641q0O == null) {
                c0641q0O = this.e.a(c0642r0R, (c0641q0.m() + c0641q0.h.e) - c0642r0R.b);
            }
            arrayList.add(c0641q0O);
        }
        L(arrayList);
    }

    public boolean F(ax.p132i1.C c) {
        C0641q0 c0641q0 = this.m;
        return c0641q0 != null && c0641q0.a == c;
    }

    public boolean G(ax.p132i1.C c) {
        C0641q0 c0641q0 = this.n;
        return c0641q0 != null && c0641q0.a == c;
    }

    public void I() {
        C0641q0 c0641q0 = this.n;
        if (c0641q0 == null || c0641q0.t()) {
            this.n = null;
            for (int i = 0; i < this.r.size(); i++) {
                C0641q0 c0641q1 = this.r.get(i);
                if (!c0641q1.t()) {
                    this.n = c0641q1;
                    return;
                }
            }
        }
    }

    public void K(long j) {
        C0641q0 c0641q0 = this.m;
        if (c0641q0 != null) {
            c0641q0.w(j);
        }
    }

    public void M() {
        if (this.r.isEmpty()) {
            return;
        }
        L(new ArrayList());
    }

    public int N(C0641q0 c0641q0) {
        C1498a.i(c0641q0);
        int i = 0;
        if (c0641q0.equals(this.m)) {
            return 0;
        }
        this.m = c0641q0;
        while (c0641q0.k() != null) {
            c0641q0 = (C0641q0) C1498a.e(c0641q0.k());
            if (c0641q0 == this.k) {
                C0641q0 c0641q1 = this.j;
                this.k = c0641q1;
                this.l = c0641q1;
                i = 3;
            }
            if (c0641q0 == this.l) {
                this.l = this.k;
                i |= 2;
            }
            c0641q0.x();
            this.o--;
        }
        ((C0641q0) C1498a.e(this.m)).A(null);
        J();
        return i;
    }

    public ax.i1.F.b Q(ax.P0.N n, Object obj, long j) {
        long jR = R(n, obj);
        n.h(obj, this.a);
        n.n(this.a.c, this.b);
        boolean z = false;
        for (int iB = n.b(obj); iB >= this.b.n; iB--) {
            n.g(iB, this.a, true);
            boolean z2 = this.a.c() > 0;
            z |= z2;
            ax.P0.N.b bVar = this.a;
            if (bVar.e(bVar.d) != -1) {
                obj = C1498a.e(this.a.b);
            }
            if (z && (!z2 || this.a.d != 0)) {
                break;
            }
        }
        return P(n, obj, j, jR, this.b, this.a);
    }

    public boolean T() {
        C0641q0 c0641q0 = this.m;
        if (c0641q0 != null) {
            return !c0641q0.h.j && c0641q0.s() && this.m.h.e != -9223372036854775807L && this.o < 100;
        }
        return true;
    }

    public void V(ax.P0.N n, ExoPlayer.c cVar) {
        this.i = cVar;
        B(n);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x0094  */
    public int W(ax.P0.N n, long j, long j2, long j3) {
        C0642r0 c0642r0Z;
        boolean z;
        C0641q0 c0641q0K = this.j;
        C0641q0 c0641q0 = null;
        while (c0641q0K != null) {
            C0642r0 c0642r0 = c0641q0K.h;
            if (c0641q0 == null) {
                c0642r0Z = z(n, c0642r0);
            } else {
                C0642r0 c0642r0L = l(n, c0641q0, j);
                if (c0642r0L == null || !f(c0642r0, c0642r0L)) {
                    return N(c0641q0);
                }
                c0642r0Z = c0642r0L;
            }
            c0641q0K.h = c0642r0Z.a(c0642r0.c);
            if (c0642r0.e != c0642r0Z.e) {
                c0641q0K.E();
                long j4 = c0642r0Z.e;
                long jD = j4 == -9223372036854775807L ? Long.MAX_VALUE : c0641q0K.D(j4);
                boolean z2 = c0641q0K == this.k && !c0641q0K.h.g && (j2 == Long.MIN_VALUE || j2 >= jD);
                boolean z3 = c0641q0K == this.l && (j3 == Long.MIN_VALUE || j3 >= jD);
                int iN = N(c0641q0K);
                if (iN != 0) {
                    return iN;
                }
                long j5 = c0642r0.e;
                if (j5 == -9223372036854775807L && c0642r0.d == Long.MIN_VALUE) {
                    long j6 = c0642r0Z.d;
                    if (j6 == -9223372036854775807L || j6 == Long.MIN_VALUE) {
                        z = false;
                    } else {
                        z = true;
                    }
                } else {
                    z = false;
                }
                int i = (!z2 || (j5 == -9223372036854775807L && !z)) ? 0 : 1;
                return z3 ? i | 2 : i;
            }
            c0641q0 = c0641q0K;
            c0641q0K = c0641q0K.k();
        }
        return 0;
    }

    public int X(ax.P0.N n, int i) {
        this.g = i;
        return U(n);
    }

    public int Y(ax.P0.N n, boolean z) {
        this.h = z;
        return U(n);
    }

    public C0641q0 b() {
        C0641q0 c0641q0 = this.j;
        if (c0641q0 == null) {
            return null;
        }
        if (c0641q0 == this.k) {
            this.k = c0641q0.k();
        }
        C0641q0 c0641q1 = this.j;
        if (c0641q1 == this.l) {
            this.l = c0641q1.k();
        }
        this.j.x();
        int i = this.o - 1;
        this.o = i;
        if (i == 0) {
            this.m = null;
            C0641q0 c0641q2 = this.j;
            this.p = c0641q2.b;
            this.q = c0641q2.h.a.d;
        }
        this.j = this.j.k();
        J();
        return this.j;
    }

    public C0641q0 c() {
        this.l = ((C0641q0) C1498a.i(this.l)).k();
        J();
        return (C0641q0) C1498a.i(this.l);
    }

    public C0641q0 d() {
        C0641q0 c0641q0 = this.l;
        C0641q0 c0641q1 = this.k;
        if (c0641q0 == c0641q1) {
            this.l = ((C0641q0) C1498a.i(c0641q1)).k();
        }
        this.k = ((C0641q0) C1498a.i(this.k)).k();
        J();
        return (C0641q0) C1498a.i(this.k);
    }

    public void g() {
        if (this.o == 0) {
            return;
        }
        C0641q0 c0641q0K = (C0641q0) C1498a.i(this.j);
        this.p = c0641q0K.b;
        this.q = c0641q0K.h.a.d;
        while (c0641q0K != null) {
            c0641q0K.x();
            c0641q0K = c0641q0K.k();
        }
        this.j = null;
        this.m = null;
        this.k = null;
        this.l = null;
        this.o = 0;
        J();
    }

    public C0641q0 h(C0642r0 c0642r0) {
        C0641q0 c0641q0 = this.m;
        long jM = c0641q0 == null ? 1000000000000L : (c0641q0.m() + this.m.h.e) - c0642r0.b;
        C0641q0 c0641q0O = O(c0642r0);
        if (c0641q0O == null) {
            c0641q0O = this.e.a(c0642r0, jM);
        } else {
            c0641q0O.h = c0642r0;
            c0641q0O.B(jM);
        }
        C0641q0 c0641q1 = this.m;
        if (c0641q1 != null) {
            c0641q1.A(c0641q0O);
        } else {
            this.j = c0641q0O;
            this.k = c0641q0O;
            this.l = c0641q0O;
        }
        this.p = null;
        this.m = c0641q0O;
        this.o++;
        J();
        return c0641q0O;
    }

    public C0641q0 n() {
        return this.m;
    }

    public C0642r0 t(long j, J0 j0) {
        C0641q0 c0641q0 = this.m;
        return c0641q0 == null ? j(j0) : l(j0.a, c0641q0, j);
    }

    public C0641q0 u() {
        return this.j;
    }

    public C0641q0 v(ax.p132i1.C c) {
        for (int i = 0; i < this.r.size(); i++) {
            C0641q0 c0641q0 = this.r.get(i);
            if (c0641q0.a == c) {
                return c0641q0;
            }
        }
        return null;
    }

    public C0641q0 w() {
        return this.n;
    }

    public C0641q0 x() {
        return this.l;
    }

    public C0641q0 y() {
        return this.k;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:23:0x006c  */
    /* JADX WARN: Code duplicated, block: B:28:0x007b  */
    public C0642r0 z(ax.P0.N n, C0642r0 c0642r0) {
        long jK;
        long j;
        int i;
        boolean zS;
        int i2;
        ax.i1.F.b bVar = c0642r0.a;
        boolean zC = C(bVar);
        boolean zE = E(n, bVar);
        boolean zD = D(n, bVar, zC);
        n.h(c0642r0.a.a, this.a);
        long jF = (bVar.b() || (i2 = bVar.e) == -1) ? -9223372036854775807L : this.a.f(i2);
        if (!bVar.b()) {
            if (jF == -9223372036854775807L || jF == Long.MIN_VALUE) {
                jK = this.a.k();
            } else {
                j = jF;
            }
            if (bVar.b()) {
                zS = this.a.s(bVar.b);
            } else {
                i = bVar.e;
                if (i == -1 && this.a.s(i)) {
                    zS = true;
                } else {
                    zS = false;
                }
            }
            return new C0642r0(bVar, c0642r0.b, c0642r0.c, jF, j, c0642r0.f, zS, zC, zE, zD);
        }
        jK = this.a.b(bVar.b, bVar.c);
        j = jK;
        if (bVar.b()) {
            zS = this.a.s(bVar.b);
        } else {
            i = bVar.e;
            if (i == -1) {
                zS = false;
            } else {
                zS = false;
            }
        }
        return new C0642r0(bVar, c0642r0.b, c0642r0.c, jF, j, c0642r0.f, zS, zC, zE, zD);
    }
}
