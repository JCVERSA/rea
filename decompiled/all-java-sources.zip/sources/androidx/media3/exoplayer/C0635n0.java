package androidx.media3.exoplayer;

import android.content.Context;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Pair;
import ax.P0.C1357c;
import ax.P0.C1375v;
import ax.P0.C1378y;
import ax.S0.C1498a;
import ax.S0.C1508k;
import ax.S0.C1517u;
import ax.S0.InterfaceC1505h;
import ax.S0.InterfaceC1514q;
import ax.Y7.AbstractC1656z;
import ax.Z0.I1;
import ax.Z0.InterfaceC1657a;
import ax.p020b1.InterfaceC1824n;
import ax.p132i1.C2095b;
import ax.p409z6.C3772df;
import j$.util.Objects;
import java.io.IOException;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: renamed from: androidx.media3.exoplayer.n0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0635n0 implements Handler.Callback, ax.i1.C.a, ax.l1.J.a, I0.d, C0628k.a, K0.a, C0620g.a, ax.p228o1.z {
    private static final long p1 = ax.S0.d0.E1(10000);
    private final ax.Y0.P A0;
    private final long B0;
    private final I1 C0;
    private final boolean D0;
    private final InterfaceC1657a E0;
    private final InterfaceC1514q F0;
    private final boolean G0;
    private final C0620g H0;
    private ax.Y0.Z I0;
    private ax.Y0.Z K0;
    private boolean L0;
    private boolean M0;
    private h N0;
    private J0 O0;
    private e P0;
    private boolean Q0;
    private boolean R0;
    private boolean S0;
    private boolean T0;
    private boolean V0;
    private int W0;
    private final N0[] X;
    private boolean X0;
    private final boolean[] Y;
    private boolean Y0;
    private final ax.p180l1.J Z;
    private boolean Z0;
    private boolean a1;
    private int b1;
    private h c1;
    private long d1;
    private long e1;
    private int f1;
    private boolean g1;
    private C0643s h1;
    private long i1;
    private final ax.p180l1.K k0;
    private ExoPlayer.c k1;
    private final InterfaceC0637o0 l0;
    private final ax.p196m1.e m0;
    private final InterfaceC1514q n0;
    private boolean n1;
    private final ax.Y0.T o0;
    private final Looper p0;
    private final O0[] q;
    private final ax.P0.N.c q0;
    private final ax.P0.N.b r0;
    private final long s0;
    private final boolean t0;
    private final C0628k u0;
    private final ArrayList<d> v0;
    private final InterfaceC1505h w0;
    private final f x0;
    private final C0646t0 y0;
    private final I0 z0;
    private long m1 = -9223372036854775807L;
    private float o1 = 1.0f;
    private ax.Y0.Y J0 = ax.Y0.Y.i;
    private long j1 = -9223372036854775807L;
    private long U0 = -9223372036854775807L;
    private ax.P0.N l1 = ax.P0.N.a;

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$a */
    class a implements M0.a {
        a() {
        }

        @Override // androidx.media3.exoplayer.M0.a
        public void a() {
            C0635n0.this.Z0 = true;
        }

        @Override // androidx.media3.exoplayer.M0.a
        public void b() {
            if (C0635n0.this.g0() || C0635n0.this.a1) {
                C0635n0.this.n0.f(2);
            }
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$b */
    private static final class b {
        private final List<I0.c> a;
        private final ax.p132i1.g0 b;
        private final int c;
        private final long d;

        private b(List<I0.c> list, ax.p132i1.g0 g0Var, int i, long j) {
            this.a = list;
            this.b = g0Var;
            this.c = i;
            this.d = j;
        }

        /* synthetic */ b(List list, ax.p132i1.g0 g0Var, int i, long j, a aVar) {
            this(list, g0Var, i, j);
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$c */
    private static class c {
        public final int a;
        public final int b;
        public final int c;
        public final ax.p132i1.g0 d;
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$d */
    private static final class d implements Comparable<d> {
        public int X;
        public long Y;
        public Object Z;
        public final K0 q;

        public d(K0 k0) {
            this.q = k0;
        }

        @Override // java.lang.Comparable
        /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
        public int compareTo(d dVar) {
            Object obj = this.Z;
            if ((obj == null) != (dVar.Z == null)) {
                return obj != null ? -1 : 1;
            }
            if (obj == null) {
                return 0;
            }
            int i = this.X - dVar.X;
            return i != 0 ? i : Long.compare(this.Y, dVar.Y);
        }

        public void h(int i, long j, Object obj) {
            this.X = i;
            this.Y = j;
            this.Z = obj;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$e */
    public static final class e {
        private boolean a;
        public J0 b;
        public int c;
        public boolean d;
        public int e;

        public e(J0 j0) {
            this.b = j0;
        }

        public void b(int i) {
            this.a |= i > 0;
            this.c += i;
        }

        public void c(J0 j0) {
            this.a |= this.b != j0;
            this.b = j0;
        }

        public void d(int i) {
            if (this.d && this.e != 5) {
                C1498a.a(i == 5);
                return;
            }
            this.a = true;
            this.d = true;
            this.e = i;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$f */
    public interface f {
        void a(e eVar);
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$g */
    private static final class g {
        public final ax.i1.F.b a;
        public final long b;
        public final long c;
        public final boolean d;
        public final boolean e;
        public final boolean f;

        public g(ax.i1.F.b bVar, long j, long j2, boolean z, boolean z2, boolean z3) {
            this.a = bVar;
            this.b = j;
            this.c = j2;
            this.d = z;
            this.e = z2;
            this.f = z3;
        }
    }

    /* JADX INFO: renamed from: androidx.media3.exoplayer.n0$h */
    private static final class h {
        public final ax.P0.N a;
        public final int b;
        public final long c;

        public h(ax.P0.N n, int i, long j) {
            this.a = n;
            this.b = i;
            this.c = j;
        }
    }

    public C0635n0(Context context, M0[] m0Arr, M0[] m0Arr2, ax.p180l1.J j, ax.p180l1.K k, InterfaceC0637o0 interfaceC0637o0, ax.p196m1.e eVar, int i, boolean z, InterfaceC1657a interfaceC1657a, ax.Y0.Z z2, ax.Y0.P p, long j2, boolean z3, boolean z4, Looper looper, InterfaceC1505h interfaceC1505h, f fVar, I1 i1, ax.Y0.T t, ExoPlayer.c cVar, final ax.p228o1.z zVar) {
        this.x0 = fVar;
        this.Z = j;
        this.k0 = k;
        this.l0 = interfaceC0637o0;
        this.m0 = eVar;
        this.W0 = i;
        this.X0 = z;
        this.I0 = z2;
        this.A0 = p;
        this.B0 = j2;
        this.i1 = j2;
        this.R0 = z3;
        this.D0 = z4;
        this.w0 = interfaceC1505h;
        this.C0 = i1;
        this.k1 = cVar;
        this.E0 = interfaceC1657a;
        this.s0 = interfaceC0637o0.j(i1);
        this.t0 = interfaceC0637o0.c(i1);
        J0 j0K = J0.k(k);
        this.O0 = j0K;
        this.P0 = new e(j0K);
        this.X = new N0[m0Arr.length];
        this.Y = new boolean[m0Arr.length];
        N0.a aVarD = j.d();
        this.q = new O0[m0Arr.length];
        boolean z5 = false;
        for (int i2 = 0; i2 < m0Arr.length; i2++) {
            m0Arr[i2].m(i2, i1, interfaceC1505h);
            this.X[i2] = m0Arr[i2].u();
            if (aVarD != null) {
                this.X[i2].v(aVarD);
            }
            M0 m0 = m0Arr2[i2];
            if (m0 != null) {
                m0.m(i2, i1, interfaceC1505h);
                z5 = true;
            }
            this.q[i2] = new O0(m0Arr[i2], m0Arr2[i2], i2);
        }
        this.G0 = z5;
        this.u0 = new C0628k(this, interfaceC1505h);
        this.v0 = new ArrayList<>();
        this.q0 = new ax.P0.N.c();
        this.r0 = new ax.P0.N.b();
        j.e(this, eVar);
        this.g1 = true;
        InterfaceC1514q interfaceC1514qD = interfaceC1505h.d(looper, null);
        this.F0 = interfaceC1514qD;
        this.y0 = new C0646t0(interfaceC1657a, interfaceC1514qD, new C0641q0.a() { // from class: androidx.media3.exoplayer.l0
            @Override // androidx.media3.exoplayer.C0641q0.a
            public final C0641q0 a(C0642r0 c0642r0, long j3) {
                return this.a.z(c0642r0, j3);
            }
        }, cVar);
        this.z0 = new I0(this, interfaceC1657a, interfaceC1514qD, i1);
        ax.Y0.T t2 = t == null ? new ax.Y0.T() : t;
        this.o0 = t2;
        Looper looperA = t2.a();
        this.p0 = looperA;
        InterfaceC1514q interfaceC1514qD2 = interfaceC1505h.d(looperA, this);
        this.n0 = interfaceC1514qD2;
        this.H0 = new C0620g(context, looperA, this);
        interfaceC1514qD2.j(35, new ax.p228o1.z() { // from class: androidx.media3.exoplayer.m0
            @Override // ax.p228o1.z
            public final void k(long j3, long j4, C1375v c1375v, MediaFormat mediaFormat) {
                C0635n0.n(this.q, zVar, j3, j4, c1375v, mediaFormat);
            }
        }).a();
    }

    private void A(K0 k0) throws C0643s {
        if (k0.i()) {
            return;
        }
        try {
            k0.f().B(k0.h(), k0.d());
        } finally {
            k0.j(true);
        }
    }

    private void A0() throws C0643s {
        C0641q0 c0641q0Y = this.y0.y();
        if (c0641q0Y == null || this.y0.u() == c0641q0Y || c0641q0Y.i || !i2()) {
            return;
        }
        this.y0.y().i = true;
    }

    private void B() {
        if (this.G0 && x()) {
            for (O0 o0 : this.q) {
                int iH = o0.h();
                o0.c(this.u0);
                this.b1 -= iH - o0.h();
            }
            this.m1 = -9223372036854775807L;
        }
    }

    private void B0() throws Throwable {
        a0(this.z0.i(), true);
    }

    private void B1(ax.Y0.Y y) throws C0643s {
        this.J0 = y;
        w();
    }

    private void C(int i) throws C0643s {
        int iH = this.q[i].h();
        this.q[i].b(this.u0);
        s0(i, false);
        this.b1 -= iH;
    }

    private void C0(c cVar) throws Throwable {
        this.P0.b(1);
        a0(this.z0.v(cVar.a, cVar.b, cVar.c, cVar.d), false);
    }

    private void D() throws C0643s {
        for (int i = 0; i < this.q.length; i++) {
            C(i);
        }
        this.m1 = -9223372036854775807L;
    }

    private void D0() {
        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null; c0641q0U = c0641q0U.k()) {
            for (ax.p180l1.D d2 : c0641q0U.p().c) {
                if (d2 != null) {
                    d2.r();
                }
            }
        }
    }

    private void D1(ax.Y0.Z z) {
        this.I0 = z;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0187  */
    /* JADX WARN: Code duplicated, block: B:103:0x0190  */
    /* JADX WARN: Code duplicated, block: B:106:0x0198  */
    /* JADX WARN: Code duplicated, block: B:109:0x019d  */
    /* JADX WARN: Code duplicated, block: B:113:0x01a4  */
    /* JADX WARN: Code duplicated, block: B:116:0x01ab  */
    /* JADX WARN: Code duplicated, block: B:119:0x01b5  */
    /* JADX WARN: Code duplicated, block: B:134:0x013f A[EDGE_INSN: B:134:0x013f->B:84:0x013f BREAK  A[LOOP:1: B:78:0x012c->B:83:0x013c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:136:0x013c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:48:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:53:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:56:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:58:0x00db  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:65:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:73:0x011a  */
    /* JADX WARN: Code duplicated, block: B:77:0x012b  */
    /* JADX WARN: Code duplicated, block: B:80:0x0131  */
    /* JADX WARN: Code duplicated, block: B:82:0x0139  */
    /* JADX WARN: Code duplicated, block: B:86:0x0145  */
    private void E() throws C0643s, IOException {
        boolean z;
        boolean z2;
        long j;
        boolean z3;
        boolean z4;
        boolean z5;
        J0 j0;
        int i;
        int i2;
        O0[] o0Arr;
        J0 j1;
        long jC = this.w0.c();
        this.n0.i(2);
        Z1();
        int i3 = this.O0.e;
        if (i3 == 1 || i3 == 4) {
            return;
        }
        C0641q0 c0641q0U = this.y0.u();
        if (c0641q0U == null) {
            Z0(jC);
            return;
        }
        ax.S0.N.a("doSomeWork");
        e2();
        if (c0641q0U.f) {
            this.e1 = ax.S0.d0.a1(this.w0.b());
            c0641q0U.a.v(this.O0.s - this.s0, this.t0);
            int i4 = 0;
            z = true;
            z2 = true;
            while (true) {
                O0[] o0Arr2 = this.q;
                if (i4 >= o0Arr2.length) {
                    break;
                }
                O0 o0 = o0Arr2[i4];
                if (o0.h() == 0) {
                    s0(i4, false);
                } else {
                    o0.I(this.d1, this.e1);
                    z = z && o0.t();
                    boolean zA = o0.a(c0641q0U);
                    s0(i4, zA);
                    z2 = z2 && zA;
                    if (!zA) {
                        r0(i4);
                    }
                }
                i4++;
            }
        } else {
            c0641q0U.a.l();
            z = true;
            z2 = true;
        }
        long j2 = c0641q0U.h.e;
        if (z && c0641q0U.f) {
            if (j2 != -9223372036854775807L) {
                j = -9223372036854775807L;
                if (j2 <= this.O0.s) {
                }
                if (z3 && this.S0) {
                    this.S0 = false;
                    s1(false, this.O0.n, false, 5);
                }
                if (!z3 && c0641q0U.h.j) {
                    H1(4);
                    V1();
                } else if (this.O0.e != 2 && Q1(z2)) {
                    H1(3);
                    this.h1 = null;
                    if (P1()) {
                        h2(false, false);
                        this.u0.g();
                        S1();
                    }
                } else if (this.O0.e == 3 && (this.b1 != 0 ? !z2 : !k0())) {
                    h2(P1(), false);
                    H1(2);
                    if (this.T0) {
                        F0();
                        this.A0.c();
                    }
                    V1();
                }
                if (this.O0.e == 2) {
                    i2 = 0;
                    while (true) {
                        o0Arr = this.q;
                        if (i2 >= o0Arr.length) {
                            break;
                        }
                        if (o0Arr[i2].x(c0641q0U)) {
                            r0(i2);
                        }
                        i2++;
                    }
                    j1 = this.O0;
                    if (!j1.g || j1.r >= 500000 || !i0(this.y0.n()) || !P1()) {
                        this.j1 = j;
                    } else if (this.j1 == j) {
                        this.j1 = this.w0.b();
                    } else if (this.w0.b() - this.j1 >= 4000) {
                        throw new IllegalStateException("Playback stuck buffering and not loading");
                    }
                } else {
                    this.j1 = j;
                }
                if (P1() || this.O0.e != 3) {
                    z4 = false;
                } else {
                    z4 = true;
                }
                z5 = !this.a1 && this.Z0 && z4;
                j0 = this.O0;
                if (j0.p != z5) {
                    this.O0 = j0.i(z5);
                }
                this.Z0 = false;
                if (!z5 && (i = this.O0.e) != 4 && (z4 || i == 2 || (i == 3 && this.b1 != 0))) {
                    Z0(jC);
                }
                ax.S0.N.b();
            }
            j = -9223372036854775807L;
            z3 = true;
            if (z3) {
                this.S0 = false;
                s1(false, this.O0.n, false, 5);
            }
            if (!z3) {
                if (this.O0.e != 2) {
                    if (this.O0.e == 3) {
                        h2(P1(), false);
                        H1(2);
                        if (this.T0) {
                            F0();
                            this.A0.c();
                        }
                        V1();
                    }
                } else if (this.O0.e == 3) {
                    h2(P1(), false);
                    H1(2);
                    if (this.T0) {
                        F0();
                        this.A0.c();
                    }
                    V1();
                }
            } else if (this.O0.e != 2) {
                if (this.O0.e == 3) {
                    h2(P1(), false);
                    H1(2);
                    if (this.T0) {
                        F0();
                        this.A0.c();
                    }
                    V1();
                }
            } else if (this.O0.e == 3) {
                h2(P1(), false);
                H1(2);
                if (this.T0) {
                    F0();
                    this.A0.c();
                }
                V1();
            }
            if (this.O0.e == 2) {
                i2 = 0;
                while (true) {
                    o0Arr = this.q;
                    if (i2 >= o0Arr.length) {
                        break;
                        break;
                    } else {
                        if (o0Arr[i2].x(c0641q0U)) {
                            r0(i2);
                        }
                        i2++;
                    }
                }
                j1 = this.O0;
                if (!j1.g) {
                    this.j1 = j;
                } else {
                    this.j1 = j;
                }
            } else {
                this.j1 = j;
            }
            if (P1()) {
                z4 = false;
            } else {
                z4 = false;
            }
            if (this.a1) {
            }
            j0 = this.O0;
            if (j0.p != z5) {
                this.O0 = j0.i(z5);
            }
            this.Z0 = false;
            if (!z5) {
                Z0(jC);
            }
            ax.S0.N.b();
        }
        j = -9223372036854775807L;
        z3 = false;
        if (z3) {
            this.S0 = false;
            s1(false, this.O0.n, false, 5);
        }
        if (!z3) {
            if (this.O0.e != 2) {
                if (this.O0.e == 3) {
                    h2(P1(), false);
                    H1(2);
                    if (this.T0) {
                        F0();
                        this.A0.c();
                    }
                    V1();
                }
            } else if (this.O0.e == 3) {
                h2(P1(), false);
                H1(2);
                if (this.T0) {
                    F0();
                    this.A0.c();
                }
                V1();
            }
        } else if (this.O0.e != 2) {
            if (this.O0.e == 3) {
                h2(P1(), false);
                H1(2);
                if (this.T0) {
                    F0();
                    this.A0.c();
                }
                V1();
            }
        } else if (this.O0.e == 3) {
            h2(P1(), false);
            H1(2);
            if (this.T0) {
                F0();
                this.A0.c();
            }
            V1();
        }
        if (this.O0.e == 2) {
            i2 = 0;
            while (true) {
                o0Arr = this.q;
                if (i2 >= o0Arr.length) {
                    break;
                    break;
                } else {
                    if (o0Arr[i2].x(c0641q0U)) {
                        r0(i2);
                    }
                    i2++;
                }
            }
            j1 = this.O0;
            if (!j1.g) {
                this.j1 = j;
            } else {
                this.j1 = j;
            }
        } else {
            this.j1 = j;
        }
        if (P1()) {
            z4 = false;
        } else {
            z4 = false;
        }
        if (this.a1) {
        }
        j0 = this.O0;
        if (j0.p != z5) {
            this.O0 = j0.i(z5);
        }
        this.Z0 = false;
        if (!z5) {
            Z0(jC);
        }
        ax.S0.N.b();
    }

    private void E0(boolean z) {
        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null; c0641q0U = c0641q0U.k()) {
            for (ax.p180l1.D d2 : c0641q0U.p().c) {
                if (d2 != null) {
                    d2.g(z);
                }
            }
        }
    }

    private void F(C0641q0 c0641q0, int i, boolean z, long j) throws C0643s {
        O0 o0 = this.q[i];
        if (o0.y()) {
            return;
        }
        boolean z2 = c0641q0 == this.y0.u();
        ax.p180l1.K kP = c0641q0.p();
        ax.Y0.W w = kP.b[i];
        ax.p180l1.D d2 = kP.c[i];
        boolean z3 = P1() && this.O0.e == 3;
        boolean z4 = !z && z3;
        this.b1++;
        o0.e(w, d2, c0641q0.c[i], this.d1, z4, z2, j, c0641q0.m(), c0641q0.h.a, this.u0);
        o0.n(11, new a(), c0641q0);
        if (z3 && z2) {
            o0.W();
        }
    }

    private void F0() {
        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null; c0641q0U = c0641q0U.k()) {
            for (ax.p180l1.D d2 : c0641q0U.p().c) {
                if (d2 != null) {
                    d2.s();
                }
            }
        }
    }

    private void F1(boolean z) throws C0643s {
        this.X0 = z;
        int iY = this.y0.Y(this.O0.a, z);
        if ((iY & 1) != 0) {
            b1(true);
        } else if ((iY & 2) != 0) {
            B();
        }
        Y(false);
    }

    private void G() throws C0643s {
        H(new boolean[this.q.length], this.y0.y().n());
    }

    private void G1(ax.p132i1.g0 g0Var) throws Throwable {
        this.P0.b(1);
        a0(this.z0.D(g0Var), false);
    }

    private void H(boolean[] zArr, long j) throws C0643s {
        long j2;
        C0641q0 c0641q0Y = this.y0.y();
        ax.p180l1.K kP = c0641q0Y.p();
        for (int i = 0; i < this.q.length; i++) {
            if (!kP.c(i)) {
                this.q[i].L();
            }
        }
        int i2 = 0;
        while (i2 < this.q.length) {
            if (!kP.c(i2) || this.q[i2].x(c0641q0Y)) {
                j2 = j;
            } else {
                j2 = j;
                F(c0641q0Y, i2, zArr[i2], j2);
            }
            i2++;
            j = j2;
        }
    }

    private void H1(int i) {
        J0 j0 = this.O0;
        if (j0.e != i) {
            if (i != 2) {
                this.j1 = -9223372036854775807L;
            }
            if (i != 3 && j0.p) {
                this.O0 = j0.i(false);
            }
            this.O0 = this.O0.h(i);
        }
    }

    private void I0() throws C0643s {
        this.P0.b(1);
        Q0(false, false, false, true);
        this.l0.i(this.C0);
        H1(this.O0.a.q() ? 4 : 2);
        b2();
        this.z0.w(this.m0.d());
        this.n0.f(2);
    }

    private void I1(ax.p228o1.z zVar) throws C0643s {
        for (O0 o0 : this.q) {
            o0.T(zVar);
        }
    }

    private AbstractC1656z<ax.P0.C> J(ax.p180l1.D[] dArr) {
        AbstractC1656z.a aVar = new AbstractC1656z.a();
        boolean z = false;
        for (ax.p180l1.D d2 : dArr) {
            if (d2 != null) {
                ax.P0.C c2 = d2.h(0).l;
                if (c2 == null) {
                    aVar.a(new ax.P0.C(new ax.P0.C.a[0]));
                } else {
                    aVar.a(c2);
                    z = true;
                }
            }
        }
        return z ? aVar.k() : AbstractC1656z.y();
    }

    private long K() {
        J0 j0 = this.O0;
        return M(j0.a, j0.b.a, j0.s);
    }

    private void K0(C1508k c1508k) {
        try {
            Q0(true, false, true, false);
            L0();
            this.l0.f(this.C0);
            this.H0.h();
            this.Z.j();
            H1(1);
        } finally {
            this.n0.k(null);
            this.o0.b();
            c1508k.f();
        }
    }

    private void K1(Object obj, C1508k c1508k) throws C0643s {
        for (O0 o0 : this.q) {
            o0.U(obj);
        }
        int i = this.O0.e;
        if (i == 3 || i == 2) {
            this.n0.f(2);
        }
        if (c1508k != null) {
            c1508k.f();
        }
    }

    private long L() {
        long jMin = this.O0.e == 3 ? 1000L : p1;
        for (O0 o0 : this.q) {
            jMin = Math.min(jMin, ax.S0.d0.E1(o0.j(this.d1, this.e1)));
        }
        if (!this.O0.n()) {
            return jMin;
        }
        C0641q0 c0641q0K = this.y0.u() != null ? this.y0.u().k() : null;
        return (c0641q0K == null || ((float) this.d1) + (((float) ax.S0.d0.a1(jMin)) * this.O0.o.a) < ((float) c0641q0K.n())) ? jMin : Math.min(jMin, p1);
    }

    private void L0() {
        for (int i = 0; i < this.q.length; i++) {
            this.X[i].l();
            this.q[i].H();
        }
    }

    private long M(ax.P0.N n, Object obj, long j) {
        n.n(n.h(obj, this.r0).c, this.q0);
        ax.P0.N.c cVar = this.q0;
        if (cVar.f != -9223372036854775807L && cVar.f()) {
            ax.P0.N.c cVar2 = this.q0;
            if (cVar2.i) {
                return ax.S0.d0.a1(cVar2.a() - this.q0.f) - (j + this.r0.o());
            }
        }
        return -9223372036854775807L;
    }

    private void M0(int i, int i2, ax.p132i1.g0 g0Var) throws Throwable {
        this.P0.b(1);
        a0(this.z0.A(i, i2, g0Var), false);
    }

    private void M1(float f2) throws C0643s {
        this.o1 = f2;
        float f3 = f2 * this.H0.f();
        for (O0 o0 : this.q) {
            o0.V(f3);
        }
    }

    private long N(C0641q0 c0641q0) {
        if (c0641q0 == null) {
            return 0L;
        }
        long jM = c0641q0.m();
        if (!c0641q0.f) {
            return jM;
        }
        int i = 0;
        while (true) {
            O0[] o0Arr = this.q;
            if (i >= o0Arr.length) {
                return jM;
            }
            if (o0Arr[i].x(c0641q0)) {
                long jK = this.q[i].k(c0641q0);
                if (jK == Long.MIN_VALUE) {
                    return Long.MIN_VALUE;
                }
                jM = Math.max(jK, jM);
            }
            i++;
        }
    }

    private boolean N1() {
        C0641q0 c0641q0U;
        C0641q0 c0641q0K;
        return P1() && !this.S0 && (c0641q0U = this.y0.u()) != null && (c0641q0K = c0641q0U.k()) != null && this.d1 >= c0641q0K.n() && c0641q0K.i;
    }

    private Pair<ax.i1.F.b, Long> O(ax.P0.N n) {
        if (n.q()) {
            return Pair.create(J0.l(), 0L);
        }
        Pair<Object, Long> pairJ = n.j(this.q0, this.r0, n.a(this.X0), -9223372036854775807L);
        ax.i1.F.b bVarQ = this.y0.Q(n, pairJ.first, 0L);
        long jLongValue = ((Long) pairJ.second).longValue();
        if (bVarQ.b()) {
            n.h(bVarQ.a, this.r0);
            jLongValue = bVarQ.c == this.r0.l(bVarQ.b) ? this.r0.g() : 0L;
        }
        return Pair.create(bVarQ, Long.valueOf(jLongValue));
    }

    private void O0() throws C0643s {
        float f2 = this.u0.f().a;
        C0641q0 c0641q0Y = this.y0.y();
        ax.p180l1.K k = null;
        boolean z = true;
        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null && c0641q0U.f; c0641q0U = c0641q0U.k()) {
            J0 j0 = this.O0;
            ax.p180l1.K kZ = c0641q0U.z(f2, j0.a, j0.l);
            if (c0641q0U == this.y0.u()) {
                k = kZ;
            }
            if (!kZ.a(c0641q0U.p())) {
                if (z) {
                    C0641q0 c0641q0U2 = this.y0.u();
                    boolean z2 = (this.y0.N(c0641q0U2) & 1) != 0;
                    boolean[] zArr = new boolean[this.q.length];
                    long jB = c0641q0U2.b((ax.p180l1.K) C1498a.e(k), this.O0.s, z2, zArr);
                    J0 j1 = this.O0;
                    boolean z3 = (j1.e == 4 || jB == j1.s) ? false : true;
                    J0 j2 = this.O0;
                    this.O0 = e0(j2.b, jB, j2.c, j2.d, z3, 5);
                    if (z3) {
                        S0(jB);
                    }
                    B();
                    boolean[] zArr2 = new boolean[this.q.length];
                    int i = 0;
                    while (true) {
                        O0[] o0Arr = this.q;
                        if (i >= o0Arr.length) {
                            break;
                        }
                        int iH = o0Arr[i].h();
                        zArr2[i] = this.q[i].y();
                        this.q[i].B(c0641q0U2.c[i], this.u0, this.d1, zArr[i]);
                        if (iH - this.q[i].h() > 0) {
                            s0(i, false);
                        }
                        this.b1 -= iH - this.q[i].h();
                        i++;
                    }
                    H(zArr2, this.d1);
                    c0641q0U2.i = true;
                } else {
                    this.y0.N(c0641q0U);
                    if (c0641q0U.f) {
                        long jMax = Math.max(c0641q0U.h.b, c0641q0U.C(this.d1));
                        if (this.G0 && x() && this.y0.x() == c0641q0U) {
                            B();
                        }
                        c0641q0U.a(kZ, jMax, false);
                    }
                }
                Y(true);
                if (this.O0.e != 4) {
                    m0();
                    e2();
                    this.n0.f(2);
                    return;
                }
                return;
            }
            if (c0641q0U == c0641q0Y) {
                z = false;
            }
        }
    }

    private boolean O1() {
        if (!i0(this.y0.n())) {
            return false;
        }
        C0641q0 c0641q0N = this.y0.n();
        long jT = T(c0641q0N.l());
        InterfaceC0637o0.a aVar = new InterfaceC0637o0.a(this.C0, this.O0.a, c0641q0N.h.a, c0641q0N == this.y0.u() ? c0641q0N.C(this.d1) : c0641q0N.C(this.d1) - c0641q0N.h.b, jT, this.u0.f().a, this.O0.l, this.T0, R1(this.O0.a, c0641q0N.h.a) ? this.A0.b() : -9223372036854775807L, this.U0);
        boolean zB = this.l0.b(aVar);
        C0641q0 c0641q0U = this.y0.u();
        if (zB || !c0641q0U.f || jT >= 500000) {
            return zB;
        }
        if (this.s0 <= 0 && !this.t0) {
            return zB;
        }
        c0641q0U.a.v(this.O0.s, false);
        return this.l0.b(aVar);
    }

    private void P0() throws C0643s {
        O0();
        b1(true);
    }

    private boolean P1() {
        J0 j0 = this.O0;
        return j0.l && j0.n == 0;
    }

    private ax.Y0.Z Q(long j) {
        ax.Y0.Y y;
        Double d2;
        if (!this.L0 || j == -9223372036854775807L || (d2 = (y = this.J0).b) == null || y.c == null) {
            return this.I0;
        }
        double d3 = j;
        double dDoubleValue = d2.doubleValue() * d3;
        RoundingMode roundingMode = RoundingMode.FLOOR;
        long jF = ax.p011a8.a.f(dDoubleValue, roundingMode);
        long jF2 = ax.p011a8.a.f(this.J0.c.doubleValue() * d3, roundingMode);
        ax.Y0.Z z = this.K0;
        if (z == null || z.a != jF || z.b != jF2) {
            this.K0 = new ax.Y0.Z(jF, jF2);
        }
        return this.K0;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0095 A[PHI: r2 r6 r8
      0x0095: PHI (r2v2 ax.i1.F$b) = (r2v1 ax.i1.F$b), (r2v12 ax.i1.F$b) binds: [B:25:0x006b, B:27:0x0090] A[DONT_GENERATE, DONT_INLINE]
      0x0095: PHI (r6v3 long) = (r6v2 long), (r6v9 long) binds: [B:25:0x006b, B:27:0x0090] A[DONT_GENERATE, DONT_INLINE]
      0x0095: PHI (r8v2 long) = (r8v1 long), (r8v6 long) binds: [B:25:0x006b, B:27:0x0090] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:39:0x00dd A[PHI: r0
      0x00dd: PHI (r0v11 ax.P0.N) = (r0v10 ax.P0.N), (r0v10 ax.P0.N), (r0v21 ax.P0.N), (r0v21 ax.P0.N) binds: [B:31:0x00a3, B:33:0x00a7, B:35:0x00b8, B:37:0x00cf] A[DONT_GENERATE, DONT_INLINE]] */
    private void Q0(boolean z, boolean z2, boolean z3, boolean z4) {
        long j;
        long j2;
        ax.P0.N n;
        ax.i1.F.b bVar;
        this.n0.i(2);
        this.M0 = false;
        this.N0 = null;
        this.h1 = null;
        boolean z5 = true;
        h2(false, true);
        this.u0.h();
        this.d1 = 1000000000000L;
        try {
            D();
        } catch (C0643s | RuntimeException e2) {
            C1517u.d("ExoPlayerImplInternal", "Disable failed.", e2);
        }
        if (z) {
            for (O0 o0 : this.q) {
                try {
                    o0.L();
                } catch (RuntimeException e3) {
                    C1517u.d("ExoPlayerImplInternal", "Reset failed.", e3);
                }
            }
        }
        this.b1 = 0;
        J0 j0 = this.O0;
        ax.i1.F.b bVar2 = j0.b;
        long jLongValue = j0.s;
        long j3 = (this.O0.b.b() || l0(this.O0, this.r0)) ? this.O0.c : this.O0.s;
        if (z2) {
            this.c1 = null;
            Pair<ax.i1.F.b, Long> pairO = O(this.O0.a);
            bVar2 = (ax.i1.F.b) pairO.first;
            jLongValue = ((Long) pairO.second).longValue();
            j3 = -9223372036854775807L;
            if (bVar2.equals(this.O0.b)) {
                j = jLongValue;
                j2 = j3;
                z5 = false;
            } else {
                j = jLongValue;
                j2 = -9223372036854775807L;
            }
        } else {
            j = jLongValue;
            j2 = j3;
            z5 = false;
        }
        this.y0.g();
        this.V0 = false;
        ax.P0.N nE = this.O0.a;
        if (z3 && (nE instanceof L0)) {
            nE = ((L0) nE).E(this.z0.q());
            if (bVar2.b != -1) {
                nE.h(bVar2.a, this.r0);
                if (nE.n(this.r0.c, this.q0).f()) {
                    n = nE;
                    bVar = new ax.i1.F.b(bVar2.a, bVar2.d);
                } else {
                    n = nE;
                    bVar = bVar2;
                }
            } else {
                n = nE;
                bVar = bVar2;
            }
        } else {
            n = nE;
            bVar = bVar2;
        }
        J0 j1 = this.O0;
        int i = j1.e;
        C0643s c0643s = z4 ? null : j1.f;
        ax.p132i1.q0 q0Var = z5 ? ax.p132i1.q0.d : j1.h;
        ax.p180l1.K k = z5 ? this.k0 : j1.i;
        List listY = z5 ? AbstractC1656z.y() : j1.j;
        J0 j4 = this.O0;
        this.O0 = new J0(n, bVar, j2, j, i, c0643s, false, q0Var, k, listY, bVar, j4.l, j4.m, j4.n, j4.o, j, 0L, j, 0L, false);
        if (z3) {
            this.y0.M();
            this.z0.y();
        }
    }

    private boolean Q1(boolean z) {
        if (this.b1 == 0) {
            return k0();
        }
        boolean z2 = false;
        if (!z) {
            return false;
        }
        if (!this.O0.g) {
            return true;
        }
        C0641q0 c0641q0U = this.y0.u();
        long jB = R1(this.O0.a, c0641q0U.h.a) ? this.A0.b() : -9223372036854775807L;
        C0641q0 c0641q0N = this.y0.n();
        boolean z3 = c0641q0N.s() && c0641q0N.h.j;
        if (c0641q0N.h.a.b() && !c0641q0N.f) {
            z2 = true;
        }
        if (z3 || z2) {
            return true;
        }
        return this.l0.a(new InterfaceC0637o0.a(this.C0, this.O0.a, c0641q0U.h.a, c0641q0U.C(this.d1), T(c0641q0N.j()), this.u0.f().a, this.O0.l, this.T0, jB, this.U0));
    }

    private long R() {
        if (this.O0.e != 3 || P1()) {
            return p1;
        }
        return 1000L;
    }

    private void R0() {
        C0641q0 c0641q0U = this.y0.u();
        this.S0 = c0641q0U != null && c0641q0U.h.i && this.R0;
    }

    private boolean R1(ax.P0.N n, ax.i1.F.b bVar) {
        if (!bVar.b() && !n.q()) {
            n.n(n.h(bVar.a, this.r0).c, this.q0);
            if (this.q0.f()) {
                ax.P0.N.c cVar = this.q0;
                if (cVar.i && cVar.f != -9223372036854775807L) {
                    return true;
                }
            }
        }
        return false;
    }

    private long S() {
        return T(this.O0.q);
    }

    private void S0(long j) throws C0643s {
        C0641q0 c0641q0U = this.y0.u();
        long jD = c0641q0U == null ? j + 1000000000000L : c0641q0U.D(j);
        this.d1 = jD;
        this.u0.c(jD);
        for (O0 o0 : this.q) {
            o0.M(c0641q0U, this.d1);
        }
        D0();
    }

    private void S1() throws C0643s {
        C0641q0 c0641q0U = this.y0.u();
        if (c0641q0U == null) {
            return;
        }
        ax.p180l1.K kP = c0641q0U.p();
        for (int i = 0; i < this.q.length; i++) {
            if (kP.c(i)) {
                this.q[i].W();
            }
        }
    }

    private long T(long j) {
        C0641q0 c0641q0N = this.y0.n();
        if (c0641q0N == null) {
            return 0L;
        }
        return Math.max(0L, j - c0641q0N.C(this.d1));
    }

    private static void T0(ax.P0.N n, d dVar, ax.P0.N.c cVar, ax.P0.N.b bVar) {
        int i = n.n(n.h(dVar.Z, bVar).c, cVar).o;
        Object obj = n.g(i, bVar, true).b;
        long j = bVar.d;
        dVar.h(i, j != -9223372036854775807L ? j - 1 : Long.MAX_VALUE, obj);
    }

    private void U(int i) throws C0643s {
        J0 j0 = this.O0;
        d2(j0.l, i, j0.n, j0.m);
    }

    private static boolean U0(d dVar, ax.P0.N n, ax.P0.N n2, int i, boolean z, ax.P0.N.c cVar, ax.P0.N.b bVar) {
        Object obj = dVar.Z;
        if (obj == null) {
            Pair<Object, Long> pairX0 = X0(n, new h(dVar.q.g(), dVar.q.c(), dVar.q.e() == Long.MIN_VALUE ? -9223372036854775807L : ax.S0.d0.a1(dVar.q.e())), false, i, z, cVar, bVar);
            if (pairX0 == null) {
                return false;
            }
            dVar.h(n.b(pairX0.first), ((Long) pairX0.second).longValue(), pairX0.first);
            if (dVar.q.e() == Long.MIN_VALUE) {
                T0(n, dVar, cVar, bVar);
            }
            return true;
        }
        int iB = n.b(obj);
        if (iB == -1) {
            return false;
        }
        if (dVar.q.e() == Long.MIN_VALUE) {
            T0(n, dVar, cVar, bVar);
            return true;
        }
        dVar.X = iB;
        n2.h(dVar.Z, bVar);
        if (bVar.f && n2.n(bVar.c, cVar).n == n2.b(dVar.Z)) {
            Pair<Object, Long> pairJ = n.j(cVar, bVar, n.h(dVar.Z, bVar).c, dVar.Y + bVar.o());
            dVar.h(n.b(pairJ.first), ((Long) pairJ.second).longValue(), pairJ.first);
        }
        return true;
    }

    private void U1(boolean z, boolean z2) {
        Q0(z || !this.Y0, false, true, false);
        this.P0.b(z2 ? 1 : 0);
        this.l0.g(this.C0);
        this.H0.n(this.O0.l, 1);
        H1(1);
    }

    private void V() throws C0643s {
        M1(this.o1);
    }

    private void V0(ax.P0.N n, ax.P0.N n2) {
        if (n.q() && n2.q()) {
            return;
        }
        int size = this.v0.size() - 1;
        while (size >= 0) {
            ax.P0.N n3 = n;
            ax.P0.N n4 = n2;
            if (!U0(this.v0.get(size), n3, n4, this.W0, this.X0, this.q0, this.r0)) {
                this.v0.get(size).q.j(false);
                this.v0.remove(size);
            }
            size--;
            n = n3;
            n2 = n4;
        }
        Collections.sort(this.v0);
    }

    private void V1() throws C0643s {
        this.u0.h();
        for (O0 o0 : this.q) {
            o0.Y();
        }
    }

    private void W(ax.p132i1.C c2) {
        if (this.y0.F(c2)) {
            this.y0.K(this.d1);
            m0();
        } else if (this.y0.G(c2)) {
            n0();
        }
    }

    private static g W0(ax.P0.N n, J0 j0, h hVar, C0646t0 c0646t0, int i, boolean z, ax.P0.N.c cVar, ax.P0.N.b bVar) {
        ax.P0.N n2;
        ax.P0.N.b bVar2;
        int i2;
        int iA;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        long jG;
        long j;
        int i3;
        long jLongValue;
        boolean z6;
        boolean z7;
        boolean z8;
        if (n.q()) {
            return new g(J0.l(), 0L, -9223372036854775807L, false, true, false);
        }
        ax.i1.F.b bVar3 = j0.b;
        Object obj = bVar3.a;
        boolean zL0 = l0(j0, bVar);
        long jQ = (j0.b.b() || zL0) ? j0.c : j0.s;
        boolean z9 = false;
        if (hVar != null) {
            n2 = n;
            Pair<Object, Long> pairX0 = X0(n2, hVar, true, i, z, cVar, bVar);
            if (pairX0 == null) {
                iA = n2.a(z);
                jLongValue = jQ;
                z6 = false;
                z7 = false;
                z8 = true;
            } else {
                if (hVar.c == -9223372036854775807L) {
                    iA = n2.h(pairX0.first, bVar).c;
                    jLongValue = jQ;
                    z6 = false;
                } else {
                    obj = pairX0.first;
                    jLongValue = ((Long) pairX0.second).longValue();
                    iA = -1;
                    z6 = true;
                }
                z7 = j0.e == 4;
                z8 = false;
            }
            z4 = z6;
            z2 = z7;
            z3 = z8;
            jQ = jLongValue;
            bVar2 = bVar;
            i2 = -1;
        } else {
            n2 = n;
            bVar2 = bVar;
            if (j0.a.q()) {
                iA = n2.a(z);
            } else if (n2.b(obj) == -1) {
                int iY0 = Y0(cVar, bVar2, i, z, obj, j0.a, n2);
                if (iY0 == -1) {
                    n2 = n2;
                    iY0 = n2.a(z);
                    z5 = true;
                } else {
                    n2 = n2;
                    z5 = false;
                }
                iA = iY0;
                obj = obj;
                bVar2 = bVar2;
                z3 = z5;
                i2 = -1;
                z2 = false;
                z4 = false;
                jQ = jQ;
            } else if (jQ == -9223372036854775807L) {
                iA = n2.h(obj, bVar2).c;
                obj = obj;
            } else if (zL0) {
                j0.a.h(bVar3.a, bVar2);
                if (j0.a.n(bVar2.c, cVar).n == j0.a.b(bVar3.a)) {
                    bVar2 = bVar2;
                    Pair<Object, Long> pairJ = n2.j(cVar, bVar2, n2.h(obj, bVar2).c, bVar2.o() + jQ);
                    obj = pairJ.first;
                    jQ = ((Long) pairJ.second).longValue();
                    i2 = -1;
                } else {
                    bVar2 = bVar2;
                    if (n2.h(obj, bVar2).d != -9223372036854775807L) {
                        i2 = -1;
                        jQ = ax.S0.d0.q(jQ, 0L, bVar2.d - 1);
                        obj = obj;
                    } else {
                        i2 = -1;
                        obj = obj;
                        jQ = jQ;
                    }
                }
                iA = -1;
                z2 = false;
                z3 = false;
                z4 = true;
            } else {
                i2 = -1;
                obj = obj;
                iA = -1;
                z2 = false;
                z3 = false;
                z4 = false;
            }
            i2 = -1;
            z2 = false;
            z3 = false;
            z4 = false;
        }
        if (iA != i2) {
            Pair<Object, Long> pairJ2 = n2.j(cVar, bVar2, iA, -9223372036854775807L);
            obj = pairJ2.first;
            jG = ((Long) pairJ2.second).longValue();
            j = -9223372036854775807L;
        } else {
            jG = jQ;
            j = jG;
        }
        ax.i1.F.b bVarQ = c0646t0.Q(n2, obj, jG);
        int i4 = bVarQ.e;
        boolean z10 = i4 == i2 || ((i3 = bVar3.e) != i2 && i4 >= i3);
        if (bVar3.a.equals(obj) && !bVar3.b() && !bVarQ.b() && z10) {
            z9 = true;
        }
        ax.i1.F.b bVar4 = bVarQ;
        boolean zH0 = h0(zL0, bVar3, jQ, bVar4, n2.h(obj, bVar2), j);
        if (z9 || zH0) {
            bVar4 = bVar3;
        }
        if (bVar4.b()) {
            if (bVar4.equals(bVar3)) {
                jG = j0.s;
            } else {
                n2.h(bVar4.a, bVar2);
                jG = bVar4.c == bVar2.l(bVar4.b) ? bVar2.g() : 0L;
            }
        }
        return new g(bVar4, jG, j, z2, z3, z4);
    }

    private void W1() {
        C0641q0 c0641q0N = this.y0.n();
        boolean z = this.V0 || (c0641q0N != null && c0641q0N.a.c());
        J0 j0 = this.O0;
        if (z != j0.g) {
            this.O0 = j0.b(z);
        }
    }

    private void X(IOException iOException, int i) {
        C0643s c0643sE = C0643s.e(iOException, i);
        C0641q0 c0641q0U = this.y0.u();
        if (c0641q0U != null) {
            c0643sE = c0643sE.c(c0641q0U.h.a);
        }
        C1517u.d("ExoPlayerImplInternal", "Playback error", c0643sE);
        U1(false, false);
        this.O0 = this.O0.f(c0643sE);
    }

    private static Pair<Object, Long> X0(ax.P0.N n, h hVar, boolean z, int i, boolean z2, ax.P0.N.c cVar, ax.P0.N.b bVar) {
        ax.P0.N n2;
        int iY0;
        ax.P0.N n3 = hVar.a;
        if (n.q()) {
            return null;
        }
        if (n3.q()) {
            n2 = n3;
            n2 = n;
        }
        try {
            n2 = n3;
            Pair<Object, Long> pairJ = n2.j(cVar, bVar, hVar.b, hVar.c);
            ax.P0.N n4 = n2;
            if (n.equals(n4)) {
                return pairJ;
            }
            if (n.b(pairJ.first) != -1) {
                return (n4.h(pairJ.first, bVar).f && n4.n(bVar.c, cVar).n == n4.b(pairJ.first)) ? n.j(cVar, bVar, n.h(pairJ.first, bVar).c, hVar.c) : pairJ;
            }
            if (z && (iY0 = Y0(cVar, bVar, i, z2, pairJ.first, n4, n)) != -1) {
                return n.j(cVar, bVar, iY0, -9223372036854775807L);
            }
            return null;
        } catch (IndexOutOfBoundsException unused) {
        }
    }

    private void X1(ax.i1.F.b bVar, ax.p132i1.q0 q0Var, ax.p180l1.K k) {
        C0641q0 c0641q0 = (C0641q0) C1498a.e(this.y0.n());
        this.l0.d(new InterfaceC0637o0.a(this.C0, this.O0.a, bVar, c0641q0 == this.y0.u() ? c0641q0.C(this.d1) : c0641q0.C(this.d1) - c0641q0.h.b, T(c0641q0.j()), this.u0.f().a, this.O0.l, this.T0, R1(this.O0.a, c0641q0.h.a) ? this.A0.b() : -9223372036854775807L, this.U0), q0Var, k.c);
    }

    private void Y(boolean z) {
        C0641q0 c0641q0N = this.y0.n();
        ax.i1.F.b bVar = c0641q0N == null ? this.O0.b : c0641q0N.h.a;
        boolean zEquals = this.O0.k.equals(bVar);
        if (!zEquals) {
            this.O0 = this.O0.c(bVar);
        }
        J0 j0 = this.O0;
        j0.q = c0641q0N == null ? j0.s : c0641q0N.j();
        this.O0.r = S();
        if ((!zEquals || z) && c0641q0N != null && c0641q0N.f) {
            X1(c0641q0N.h.a, c0641q0N.o(), c0641q0N.p());
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0052 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:19:0x0053  */
    static int Y0(ax.P0.N.c cVar, ax.P0.N.b bVar, int i, boolean z, Object obj, ax.P0.N n, ax.P0.N n2) {
        ax.P0.N.b bVar2;
        Object obj2 = n.n(n.h(obj, bVar).c, cVar).a;
        int i2 = 0;
        for (int i3 = 0; i3 < n2.p(); i3++) {
            if (n2.n(i3, cVar).a.equals(obj2)) {
                return i3;
            }
        }
        int iB = n.b(obj);
        int i4 = n.i();
        int iD = iB;
        int iB2 = -1;
        while (i2 < i4 && iB2 == -1) {
            ax.P0.N.c cVar2 = cVar;
            bVar2 = bVar;
            int i5 = i;
            boolean z2 = z;
            ax.P0.N n3 = n;
            iD = n3.d(iD, bVar2, cVar2, i5, z2);
            if (iD == -1) {
                if (iB2 == -1) {
                    return -1;
                }
                return n2.f(iB2, bVar2).c;
            }
            iB2 = n2.b(n3.m(iD));
            i2++;
            n = n3;
            bVar = bVar2;
            cVar = cVar2;
            i = i5;
            z = z2;
        }
        bVar2 = bVar;
        if (iB2 == -1) {
            return -1;
        }
        return n2.f(iB2, bVar2).c;
    }

    private void Y1(int i, int i2, List<C1378y> list) throws Throwable {
        this.P0.b(1);
        a0(this.z0.E(i, i2, list), false);
    }

    private void Z(C0641q0 c0641q0) throws C0643s {
        if (!c0641q0.f) {
            float f2 = this.u0.f().a;
            J0 j0 = this.O0;
            c0641q0.q(f2, j0.a, j0.l);
        }
        X1(c0641q0.h.a, c0641q0.o(), c0641q0.p());
        if (c0641q0 == this.y0.u()) {
            S0(c0641q0.h.b);
            G();
            c0641q0.i = true;
            J0 j1 = this.O0;
            ax.i1.F.b bVar = j1.b;
            long j = c0641q0.h.b;
            this.O0 = e0(bVar, j, j1.c, j, false, 5);
        }
        m0();
    }

    private void Z0(long j) {
        this.n0.h(2, j + (g0() ? L() : R()));
    }

    private void Z1() throws C0643s {
        if (this.O0.a.q() || !this.z0.t()) {
            return;
        }
        boolean zU0 = u0();
        y0();
        z0();
        A0();
        w0();
        x0(zU0);
    }

    /* JADX WARN: Code duplicated, block: B:104:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:107:0x01dc  */
    /* JADX WARN: Code duplicated, block: B:109:0x01e1  */
    /* JADX WARN: Code duplicated, block: B:113:0x0201  */
    /* JADX WARN: Code duplicated, block: B:90:0x019d  */
    /* JADX WARN: Code duplicated, block: B:91:0x019f  */
    /* JADX WARN: Code duplicated, block: B:96:0x01b2  */
    /* JADX WARN: Code duplicated, block: B:98:0x01bc A[ADDED_TO_REGION] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v0, types: [long] */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v12 */
    /* JADX WARN: Type inference failed for: r12v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r21v0 */
    /* JADX WARN: Type inference failed for: r21v1, types: [long] */
    /* JADX WARN: Type inference failed for: r21v10 */
    /* JADX WARN: Type inference failed for: r21v11 */
    /* JADX WARN: Type inference failed for: r21v12 */
    /* JADX WARN: Type inference failed for: r21v13 */
    /* JADX WARN: Type inference failed for: r21v2 */
    /* JADX WARN: Type inference failed for: r21v3 */
    /* JADX WARN: Type inference failed for: r21v4 */
    /* JADX WARN: Type inference failed for: r21v5, types: [long] */
    /* JADX WARN: Type inference failed for: r21v6 */
    /* JADX WARN: Type inference failed for: r21v7 */
    /* JADX WARN: Type inference failed for: r21v8 */
    /* JADX WARN: Type inference failed for: r21v9 */
    /* JADX WARN: Type inference failed for: r26v0, types: [androidx.media3.exoplayer.n0] */
    /* JADX WARN: Type inference failed for: r5v3, types: [long] */
    /* JADX WARN: Type inference failed for: r5v8, types: [long] */
    private void a0(ax.P0.N n, boolean z) throws Throwable {
        ax.P0.N n2;
        ax.i1.F.b bVar;
        ?? r21;
        ?? r12;
        int i;
        long j;
        ax.i1.F.b bVar2;
        Object obj;
        boolean z2;
        int i2;
        ?? r22;
        ?? r23;
        ?? r24;
        boolean z3;
        ?? r25;
        ax.P0.N n3 = n;
        g gVarW0 = W0(n3, this.O0, this.c1, this.y0, this.W0, this.X0, this.q0, this.r0);
        ax.i1.F.b bVar3 = gVarW0.a;
        ?? r13 = gVarW0.c;
        boolean z4 = gVarW0.d;
        long jD1 = gVarW0.b;
        boolean z5 = (this.O0.b.equals(bVar3) && jD1 == this.O0.s) ? false : true;
        try {
            if (gVarW0.e) {
                if (this.O0.e != 1) {
                    H1(4);
                }
                Q0(false, false, false, true);
            }
            for (O0 o0 : this.q) {
                o0.S(n3);
            }
            try {
                if (z5) {
                    r25 = r13;
                    z3 = false;
                    z3 = false;
                    i = 2;
                    if (!n3.q()) {
                        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null; c0641q0U = c0641q0U.k()) {
                            if (c0641q0U.h.a.equals(bVar3)) {
                                r24 = r25;
                                c0641q0U.h = this.y0.z(n3, c0641q0U.h);
                                c0641q0U.E();
                            } else {
                                r24 = r25;
                            }
                        }
                        r24 = r25;
                        jD1 = d1(bVar3, jD1, z4);
                        r24 = r25;
                    }
                } else {
                    try {
                        long jN = 0;
                        long jN2 = this.y0.y() == null ? 0L : N(this.y0.y());
                        if (x() && this.y0.x() != null) {
                            jN = N(this.y0.x());
                        }
                        try {
                            r23 = r13;
                            r13 = 0;
                            z3 = false;
                            z3 = false;
                            z3 = false;
                            i = 2;
                            try {
                                int iW = this.y0.W(n, this.d1, jN2, jN);
                                n3 = n;
                                if ((iW & 1) != 0) {
                                    b1(false);
                                    r24 = r23;
                                } else if ((iW & 2) != 0) {
                                    r24 = r23;
                                    B();
                                    r24 = r23;
                                }
                            } catch (Throwable th) {
                                th = th;
                                n3 = n;
                                r22 = r23;
                                n2 = n3;
                                bVar = bVar3;
                                r12 = r13;
                                r21 = r22;
                                J0 j0 = this.O0;
                                ax.P0.N n4 = j0.a;
                                ax.i1.F.b bVar4 = j0.b;
                                if (gVarW0.f) {
                                    j = jD1;
                                } else {
                                    j = -9223372036854775807L;
                                }
                                bVar2 = bVar;
                                f2(n2, bVar2, n4, bVar4, j, false);
                                if (z5 || r21 != this.O0.c) {
                                    J0 j1 = this.O0;
                                    obj = j1.b.a;
                                    ax.P0.N n5 = j1.a;
                                    if (z5 || !z || n5.q() || n5.h(obj, this.r0).f) {
                                        z2 = false;
                                    } else {
                                        z2 = true;
                                    }
                                    long j2 = this.O0.d;
                                    if (n2.b(obj) == -1) {
                                        i2 = 4;
                                    } else {
                                        i2 = 3;
                                    }
                                    this.O0 = e0(bVar2, jD1, r21, j2, z2, i2);
                                }
                                R0();
                                V0(n2, this.O0.a);
                                this.O0 = this.O0.j(n2);
                                if (!n2.q()) {
                                    this.c1 = null;
                                }
                                Y(r12);
                                this.n0.f(i);
                                throw th;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            n3 = n;
                            r22 = r13;
                            r13 = 0;
                            i = 2;
                            n2 = n3;
                            bVar = bVar3;
                            r12 = r13;
                            r21 = r22;
                            J0 j3 = this.O0;
                            ax.P0.N n6 = j3.a;
                            ax.i1.F.b bVar5 = j3.b;
                            if (gVarW0.f) {
                                j = jD1;
                            } else {
                                j = -9223372036854775807L;
                            }
                            bVar2 = bVar;
                            f2(n2, bVar2, n6, bVar5, j, false);
                            if (z5) {
                                J0 j4 = this.O0;
                                obj = j4.b.a;
                                ax.P0.N n7 = j4.a;
                                if (z5) {
                                    z2 = false;
                                } else {
                                    z2 = false;
                                }
                                long j5 = this.O0.d;
                                if (n2.b(obj) == -1) {
                                    i2 = 4;
                                } else {
                                    i2 = 3;
                                }
                                this.O0 = e0(bVar2, jD1, r21, j5, z2, i2);
                            } else {
                                J0 j6 = this.O0;
                                obj = j6.b.a;
                                ax.P0.N n8 = j6.a;
                                if (z5) {
                                    z2 = false;
                                } else {
                                    z2 = false;
                                }
                                long j7 = this.O0.d;
                                if (n2.b(obj) == -1) {
                                    i2 = 4;
                                } else {
                                    i2 = 3;
                                }
                                this.O0 = e0(bVar2, jD1, r21, j7, z2, i2);
                            }
                            R0();
                            V0(n2, this.O0.a);
                            this.O0 = this.O0.j(n2);
                            if (!n2.q()) {
                                this.c1 = null;
                            }
                            Y(r12);
                            this.n0.f(i);
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                    }
                }
                r24 = r23;
                r24 = r25;
                J0 j8 = this.O0;
                f2(n3, bVar3, j8.a, j8.b, gVarW0.f ? jD1 : -9223372036854775807L, false);
                ax.P0.N n9 = n3;
                if (z5 || r24 != this.O0.c) {
                    J0 j9 = this.O0;
                    Object obj2 = j9.b.a;
                    ax.P0.N n10 = j9.a;
                    this.O0 = e0(bVar3, jD1, r24, this.O0.d, z5 && z && !n10.q() && !n10.h(obj2, this.r0).f, n9.b(obj2) == -1 ? 4 : 3);
                }
                R0();
                V0(n9, this.O0.a);
                this.O0 = this.O0.j(n9);
                if (!n9.q()) {
                    this.c1 = null;
                }
                Y(z3);
                this.n0.f(i);
            } catch (Throwable th4) {
                th = th4;
            }
        } catch (Throwable th5) {
            th = th5;
            n2 = n3;
            bVar = bVar3;
            r21 = r13;
            r12 = 0;
            i = 2;
        }
    }

    private static int a2(int i, int i2) {
        if (i == -1) {
            return 2;
        }
        if (i2 == 2) {
            return 1;
        }
        return i2;
    }

    private void b0(ax.p132i1.C c2) throws C0643s {
        if (this.y0.F(c2)) {
            Z((C0641q0) C1498a.e(this.y0.n()));
            return;
        }
        C0641q0 c0641q0V = this.y0.v(c2);
        if (c0641q0V != null) {
            C1498a.g(!c0641q0V.f);
            float f2 = this.u0.f().a;
            J0 j0 = this.O0;
            c0641q0V.q(f2, j0.a, j0.l);
            if (this.y0.G(c2)) {
                n0();
            }
        }
    }

    private void b1(boolean z) throws C0643s {
        ax.i1.F.b bVar = this.y0.u().h.a;
        long jE1 = e1(bVar, this.O0.s, true, false);
        if (jE1 != this.O0.s) {
            J0 j0 = this.O0;
            this.O0 = e0(bVar, jE1, j0.c, j0.d, z, 5);
        }
    }

    private void b2() throws C0643s {
        J0 j0 = this.O0;
        c2(j0.l, j0.n, j0.m);
    }

    private void c0(ax.P0.G g2, float f2, boolean z, boolean z2) throws C0643s {
        if (z) {
            if (z2) {
                this.P0.b(1);
            }
            this.O0 = this.O0.g(g2);
        }
        j2(g2.a);
        for (O0 o0 : this.q) {
            o0.Q(f2, g2.a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x00aa A[Catch: all -> 0x00ad, TryCatch #2 {all -> 0x00ad, blocks: (B:26:0x00a0, B:28:0x00aa, B:33:0x00b5, B:35:0x00bb, B:36:0x00be, B:38:0x00c5, B:40:0x00cf, B:42:0x00d7, B:46:0x00df, B:48:0x00ef, B:65:0x0122, B:69:0x012f), top: B:90:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:31:0x00b2  */
    /* JADX WARN: Code duplicated, block: B:33:0x00b5 A[Catch: all -> 0x00ad, TryCatch #2 {all -> 0x00ad, blocks: (B:26:0x00a0, B:28:0x00aa, B:33:0x00b5, B:35:0x00bb, B:36:0x00be, B:38:0x00c5, B:40:0x00cf, B:42:0x00d7, B:46:0x00df, B:48:0x00ef, B:65:0x0122, B:69:0x012f), top: B:90:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:35:0x00bb A[Catch: all -> 0x00ad, TryCatch #2 {all -> 0x00ad, blocks: (B:26:0x00a0, B:28:0x00aa, B:33:0x00b5, B:35:0x00bb, B:36:0x00be, B:38:0x00c5, B:40:0x00cf, B:42:0x00d7, B:46:0x00df, B:48:0x00ef, B:65:0x0122, B:69:0x012f), top: B:90:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:38:0x00c5 A[Catch: all -> 0x00ad, TryCatch #2 {all -> 0x00ad, blocks: (B:26:0x00a0, B:28:0x00aa, B:33:0x00b5, B:35:0x00bb, B:36:0x00be, B:38:0x00c5, B:40:0x00cf, B:42:0x00d7, B:46:0x00df, B:48:0x00ef, B:65:0x0122, B:69:0x012f), top: B:90:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:40:0x00cf A[Catch: all -> 0x00ad, TryCatch #2 {all -> 0x00ad, blocks: (B:26:0x00a0, B:28:0x00aa, B:33:0x00b5, B:35:0x00bb, B:36:0x00be, B:38:0x00c5, B:40:0x00cf, B:42:0x00d7, B:46:0x00df, B:48:0x00ef, B:65:0x0122, B:69:0x012f), top: B:90:0x00a0 }] */
    /* JADX WARN: Code duplicated, block: B:47:0x00ee  */
    /* JADX WARN: Code duplicated, block: B:64:0x0121  */
    /* JADX WARN: Code duplicated, block: B:67:0x012c  */
    /* JADX WARN: Code duplicated, block: B:68:0x012e  */
    /* JADX WARN: Code duplicated, block: B:72:0x0137  */
    private void c1(h hVar, boolean z) throws Throwable {
        long jLongValue;
        ax.i1.F.b bVarQ;
        long j;
        boolean z2;
        long j2;
        ax.i1.F.b bVar;
        long j3;
        long jQ;
        boolean z3;
        long jD1;
        long j4;
        ax.i1.F.b bVar2;
        ax.i1.F.b bVar3;
        long j5;
        C0641q0 c0641q0U;
        boolean z4;
        J0 j0;
        int i;
        int i2;
        long j6;
        C0635n0 c0635n0 = this;
        c0635n0.P0.b(z ? 1 : 0);
        if (c0635n0.M0) {
            c0635n0.N0 = hVar;
            return;
        }
        Pair<Object, Long> pairX0 = X0(c0635n0.O0.a, hVar, true, c0635n0.W0, c0635n0.X0, c0635n0.q0, c0635n0.r0);
        try {
            if (pairX0 != null) {
                Object obj = pairX0.first;
                jLongValue = ((Long) pairX0.second).longValue();
                long j7 = hVar.c == -9223372036854775807L ? -9223372036854775807L : jLongValue;
                bVarQ = c0635n0.y0.Q(c0635n0.O0.a, obj, jLongValue);
                if (bVarQ.b()) {
                    c0635n0.O0.a.h(bVarQ.a, c0635n0.r0);
                    jLongValue = c0635n0.r0.l(bVarQ.b) == bVarQ.c ? c0635n0.r0.g() : 0L;
                    j2 = j7;
                    z2 = true;
                } else {
                    j = 0;
                    z2 = hVar.c == -9223372036854775807L;
                    j2 = j7;
                }
                if (c0635n0.O0.a.q()) {
                    if (pairX0 == null) {
                        if (c0635n0.O0.e != 1) {
                            c0635n0.H1(4);
                        }
                        c0635n0.Q0(false, true, false, true);
                    } else {
                        if (bVarQ.equals(c0635n0.O0.b)) {
                            c0641q0U = c0635n0.y0.u();
                            if (c0641q0U == null && c0641q0U.f && jLongValue != j) {
                                jQ = c0641q0U.a.q(jLongValue, c0635n0.Q(c0635n0.q0.m));
                            } else {
                                jQ = jLongValue;
                            }
                            z4 = z2;
                            try {
                                if (ax.S0.d0.E1(jQ) == ax.S0.d0.E1(c0635n0.O0.s) || !((i = (j0 = c0635n0.O0).e) == 2 || i == 3)) {
                                    z2 = z4;
                                } else {
                                    j5 = j0.s;
                                    bVar3 = bVarQ;
                                    i2 = 2;
                                    j6 = j5;
                                    z2 = z4;
                                }
                            } catch (Throwable th) {
                                th = th;
                                z2 = z4;
                                bVar = bVarQ;
                                j3 = jLongValue;
                                c0635n0.O0 = c0635n0.e0(bVar, j3, j2, j3, z2, 2);
                                throw th;
                            }
                        } else {
                            jQ = jLongValue;
                        }
                        c0635n0.M0 = c0635n0.L0;
                        if (c0635n0.O0.e == 4) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        jD1 = c0635n0.d1(bVarQ, jQ, z3);
                        z2 |= jLongValue != jD1;
                        try {
                            J0 j1 = c0635n0.O0;
                            ax.P0.N n = j1.a;
                            j4 = j2;
                            bVar2 = bVarQ;
                            try {
                                c0635n0.f2(n, bVar2, n, j1.b, j4, true);
                                bVar3 = bVar2;
                                j2 = j4;
                                j5 = jD1;
                                i2 = 2;
                                j6 = j5;
                                c0635n0 = this;
                            } catch (Throwable th2) {
                                th = th2;
                                bVar = bVar2;
                                j2 = j4;
                                j3 = jD1;
                                c0635n0.O0 = c0635n0.e0(bVar, j3, j2, j3, z2, 2);
                                throw th;
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            bVar = bVarQ;
                        }
                    }
                    c0635n0.O0 = c0635n0.e0(bVar3, j5, j2, j6, z2, i2);
                    return;
                }
                c0635n0.c1 = hVar;
                bVar3 = bVarQ;
                j5 = jLongValue;
                i2 = 2;
                j6 = j5;
                c0635n0 = this;
                c0635n0.O0 = c0635n0.e0(bVar3, j5, j2, j6, z2, i2);
                return;
            }
            Pair<ax.i1.F.b, Long> pairO = c0635n0.O(c0635n0.O0.a);
            bVarQ = (ax.i1.F.b) pairO.first;
            jLongValue = ((Long) pairO.second).longValue();
            z2 = !c0635n0.O0.a.q();
            j2 = -9223372036854775807L;
            if (c0635n0.O0.a.q()) {
                if (pairX0 == null) {
                    if (c0635n0.O0.e != 1) {
                        c0635n0.H1(4);
                    }
                    c0635n0.Q0(false, true, false, true);
                } else {
                    if (bVarQ.equals(c0635n0.O0.b)) {
                        c0641q0U = c0635n0.y0.u();
                        if (c0641q0U == null) {
                            jQ = jLongValue;
                        } else {
                            jQ = jLongValue;
                        }
                        z4 = z2;
                        if (ax.S0.d0.E1(jQ) == ax.S0.d0.E1(c0635n0.O0.s)) {
                        }
                        z2 = z4;
                    } else {
                        jQ = jLongValue;
                    }
                    c0635n0.M0 = c0635n0.L0;
                    if (c0635n0.O0.e == 4) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    jD1 = c0635n0.d1(bVarQ, jQ, z3);
                    z2 |= jLongValue != jD1;
                    J0 j8 = c0635n0.O0;
                    ax.P0.N n2 = j8.a;
                    j4 = j2;
                    bVar2 = bVarQ;
                    c0635n0.f2(n2, bVar2, n2, j8.b, j4, true);
                    bVar3 = bVar2;
                    j2 = j4;
                    j5 = jD1;
                    i2 = 2;
                    j6 = j5;
                    c0635n0 = this;
                }
                c0635n0.O0 = c0635n0.e0(bVar3, j5, j2, j6, z2, i2);
                return;
            }
            c0635n0.c1 = hVar;
            bVar3 = bVarQ;
            j5 = jLongValue;
            i2 = 2;
            j6 = j5;
            c0635n0 = this;
            c0635n0.O0 = c0635n0.e0(bVar3, j5, j2, j6, z2, i2);
            return;
        } catch (Throwable th4) {
            th = th4;
        }
        j = 0;
    }

    private void c2(boolean z, int i, int i2) throws C0643s {
        d2(z, this.H0.n(z, this.O0.e), i, i2);
    }

    private void d0(ax.P0.G g2, boolean z) throws C0643s {
        c0(g2, g2.a, true, z);
    }

    private long d1(ax.i1.F.b bVar, long j, boolean z) throws C0643s {
        return e1(bVar, j, this.y0.u() != this.y0.y(), z);
    }

    private void d2(boolean z, int i, int i2, int i3) throws C0643s {
        boolean z2 = z && i != -1;
        int iA2 = a2(i, i3);
        int iG2 = g2(i, i2);
        J0 j0 = this.O0;
        if (j0.l == z2 && j0.n == iG2 && j0.m == iA2) {
            return;
        }
        this.O0 = j0.e(z2, iA2, iG2);
        h2(false, false);
        E0(z2);
        if (!P1()) {
            V1();
            e2();
            J0 j1 = this.O0;
            if (j1.p) {
                this.O0 = j1.i(false);
            }
            this.y0.K(this.d1);
            return;
        }
        int i4 = this.O0.e;
        if (i4 == 3) {
            this.u0.g();
            S1();
            this.n0.f(2);
        } else if (i4 == 2) {
            this.n0.f(2);
        }
    }

    private J0 e0(ax.i1.F.b bVar, long j, long j2, long j3, boolean z, int i) {
        List<ax.P0.C> list;
        ax.p132i1.q0 q0Var;
        ax.p180l1.K k;
        this.g1 = (!this.g1 && j == this.O0.s && bVar.equals(this.O0.b)) ? false : true;
        R0();
        J0 j0 = this.O0;
        ax.p132i1.q0 q0Var2 = j0.h;
        ax.p180l1.K k2 = j0.i;
        List<ax.P0.C> listY = j0.j;
        if (this.z0.t()) {
            C0641q0 c0641q0U = this.y0.u();
            ax.p132i1.q0 q0VarO = c0641q0U == null ? ax.p132i1.q0.d : c0641q0U.o();
            ax.p180l1.K kP = c0641q0U == null ? this.k0 : c0641q0U.p();
            AbstractC1656z<ax.P0.C> abstractC1656zJ = J(kP.c);
            if (c0641q0U != null) {
                C0642r0 c0642r0 = c0641q0U.h;
                if (c0642r0.c != j2) {
                    c0641q0U.h = c0642r0.a(j2);
                }
            }
            v0();
            q0Var = q0VarO;
            k = kP;
            list = abstractC1656zJ;
        } else {
            if (!bVar.equals(this.O0.b)) {
                q0Var2 = ax.p132i1.q0.d;
                k2 = this.k0;
                listY = AbstractC1656z.y();
            }
            list = listY;
            q0Var = q0Var2;
            k = k2;
        }
        if (z) {
            this.P0.d(i);
        }
        return this.O0.d(bVar, j, j2, j3, S(), q0Var, k, list);
    }

    private long e1(ax.i1.F.b bVar, long j, boolean z, boolean z2) throws C0643s {
        V1();
        h2(false, true);
        if (z2 || this.O0.e == 3) {
            H1(2);
        }
        C0641q0 c0641q0U = this.y0.u();
        C0641q0 c0641q0K = c0641q0U;
        while (c0641q0K != null && !bVar.equals(c0641q0K.h.a)) {
            c0641q0K = c0641q0K.k();
        }
        if (z || c0641q0U != c0641q0K || (c0641q0K != null && c0641q0K.D(j) < 0)) {
            D();
            if (c0641q0K != null) {
                while (this.y0.u() != c0641q0K) {
                    this.y0.b();
                }
                this.y0.N(c0641q0K);
                c0641q0K.B(1000000000000L);
                G();
                c0641q0K.i = true;
            }
        }
        B();
        if (c0641q0K != null) {
            this.y0.N(c0641q0K);
            if (!c0641q0K.f) {
                c0641q0K.h = c0641q0K.h.b(j);
            } else if (c0641q0K.g) {
                j = c0641q0K.a.m(j);
                c0641q0K.a.v(j - this.s0, this.t0);
            }
            S0(j);
            m0();
        } else {
            this.y0.g();
            S0(j);
        }
        Y(false);
        this.n0.f(2);
        return j;
    }

    private void e2() throws C0643s {
        C0641q0 c0641q0U = this.y0.u();
        if (c0641q0U == null) {
            return;
        }
        long jS = c0641q0U.f ? c0641q0U.a.s() : -9223372036854775807L;
        if (jS != -9223372036854775807L) {
            if (!c0641q0U.s()) {
                this.y0.N(c0641q0U);
                Y(false);
                m0();
            }
            S0(jS);
            if (jS != this.O0.s) {
                J0 j0 = this.O0;
                long j = jS;
                this.O0 = e0(j0.b, j, j0.c, j, true, 5);
            }
        } else {
            long jI = this.u0.i(c0641q0U != this.y0.y());
            this.d1 = jI;
            long jC = c0641q0U.C(jI);
            t0(this.O0.s, jC);
            if (this.u0.z()) {
                boolean z = !this.P0.d;
                J0 j1 = this.O0;
                this.O0 = e0(j1.b, jC, j1.c, jC, z, 6);
            } else {
                this.O0.o(jC);
            }
        }
        this.O0.q = this.y0.n().j();
        this.O0.r = S();
        J0 j2 = this.O0;
        if (j2.l && j2.e == 3 && R1(j2.a, j2.b) && this.O0.o.a == 1.0f) {
            float fA = this.A0.a(K(), this.O0.r);
            if (this.u0.f().a != fA) {
                m1(this.O0.o.b(fA));
                c0(this.O0.o, this.u0.f().a, false, false);
            }
        }
    }

    private boolean f0() {
        C0641q0 c0641q0Y = this.y0.y();
        if (!c0641q0Y.f) {
            return false;
        }
        int i = 0;
        while (true) {
            O0[] o0Arr = this.q;
            if (i >= o0Arr.length) {
                return true;
            }
            if (!o0Arr[i].o(c0641q0Y)) {
                return false;
            }
            i++;
        }
    }

    private void f1(K0 k0) throws C0643s {
        if (k0.e() == -9223372036854775807L) {
            g1(k0);
            return;
        }
        if (this.O0.a.q()) {
            this.v0.add(new d(k0));
            return;
        }
        d dVar = new d(k0);
        ax.P0.N n = this.O0.a;
        if (!U0(dVar, n, n, this.W0, this.X0, this.q0, this.r0)) {
            k0.j(false);
        } else {
            this.v0.add(dVar);
            Collections.sort(this.v0);
        }
    }

    private void f2(ax.P0.N n, ax.i1.F.b bVar, ax.P0.N n2, ax.i1.F.b bVar2, long j, boolean z) throws C0643s {
        if (!R1(n, bVar)) {
            ax.P0.G g2 = bVar.b() ? ax.P0.G.d : this.O0.o;
            if (this.u0.f().equals(g2)) {
                return;
            }
            m1(g2);
            c0(this.O0.o, g2.a, false, false);
            return;
        }
        n.n(n.h(bVar.a, this.r0).c, this.q0);
        this.A0.d((C1378y.g) ax.S0.d0.i(this.q0.j));
        if (j != -9223372036854775807L) {
            this.A0.e(M(n, bVar.a, j));
            return;
        }
        if (!Objects.equals(!n2.q() ? n2.n(n2.h(bVar2.a, this.r0).c, this.q0).a : null, this.q0.a) || z) {
            this.A0.e(-9223372036854775807L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean g0() {
        if (this.D0) {
            return true;
        }
        return this.L0 && this.J0.g;
    }

    private void g1(K0 k0) throws C0643s {
        if (k0.b() != this.p0) {
            this.n0.j(15, k0).a();
            return;
        }
        A(k0);
        int i = this.O0.e;
        if (i == 3 || i == 2) {
            this.n0.f(2);
        }
    }

    private static int g2(int i, int i2) {
        if (i == 0) {
            return 1;
        }
        if (i2 == 1) {
            return 0;
        }
        return i2;
    }

    private static boolean h0(boolean z, ax.i1.F.b bVar, long j, ax.i1.F.b bVar2, ax.P0.N.b bVar3, long j2) {
        if (!z && j == j2 && bVar.a.equals(bVar2.a)) {
            if (bVar.b() && bVar3.s(bVar.b)) {
                return (bVar3.h(bVar.b, bVar.c) == 4 || bVar3.h(bVar.b, bVar.c) == 2) ? false : true;
            }
            if (bVar2.b() && bVar3.s(bVar2.b)) {
                return true;
            }
        }
        return false;
    }

    private void h1(final K0 k0) {
        Looper looperB = k0.b();
        if (looperB.getThread().isAlive()) {
            this.w0.d(looperB, null).c(new Runnable() { // from class: androidx.media3.exoplayer.k0
                @Override // java.lang.Runnable
                public final void run() {
                    C0635n0.o(this.q, k0);
                }
            });
        } else {
            C1517u.h("TAG", "Trying to send message on a dead thread.");
            k0.j(false);
        }
    }

    private void h2(boolean z, boolean z2) {
        this.T0 = z;
        this.U0 = (!z || z2) ? -9223372036854775807L : this.w0.b();
    }

    private boolean i0(C0641q0 c0641q0) {
        return (c0641q0 == null || c0641q0.r() || c0641q0.l() == Long.MIN_VALUE) ? false : true;
    }

    private void i1(long j) {
        for (O0 o0 : this.q) {
            o0.N(j);
        }
    }

    private boolean i2() throws C0643s {
        C0641q0 c0641q0Y = this.y0.y();
        ax.p180l1.K kP = c0641q0Y.p();
        int i = 0;
        boolean z = true;
        while (true) {
            O0[] o0Arr = this.q;
            if (i >= o0Arr.length) {
                break;
            }
            int iH = o0Arr[i].h();
            int iJ = this.q[i].J(c0641q0Y, kP, this.u0);
            if ((iJ & 2) != 0 && this.a1) {
                p1(false);
            }
            this.b1 -= iH - this.q[i].h();
            z &= (iJ & 1) != 0;
            i++;
        }
        if (z) {
            for (int i2 = 0; i2 < this.q.length; i2++) {
                if (kP.c(i2) && !this.q[i2].x(c0641q0Y)) {
                    F(c0641q0Y, i2, false, c0641q0Y.n());
                }
            }
        }
        return z;
    }

    private boolean j0(int i, ax.i1.F.b bVar) {
        if (this.y0.x() == null || !this.y0.x().h.a.equals(bVar)) {
            return false;
        }
        return this.q[i].v(this.y0.x());
    }

    private void j2(float f2) {
        for (C0641q0 c0641q0U = this.y0.u(); c0641q0U != null; c0641q0U = c0641q0U.k()) {
            for (ax.p180l1.D d2 : c0641q0U.p().c) {
                if (d2 != null) {
                    d2.p(f2);
                }
            }
        }
    }

    private boolean k0() {
        C0641q0 c0641q0U = this.y0.u();
        long j = c0641q0U.h.e;
        if (c0641q0U.f) {
            return j == -9223372036854775807L || this.O0.s < j || !P1();
        }
        return false;
    }

    private void k1(C1357c c1357c, boolean z) throws C0643s {
        this.Z.l(c1357c);
        C0620g c0620g = this.H0;
        if (!z) {
            c1357c = null;
        }
        c0620g.k(c1357c);
        b2();
    }

    private static boolean l0(J0 j0, ax.P0.N.b bVar) {
        ax.i1.F.b bVar2 = j0.b;
        ax.P0.N n = j0.a;
        return n.q() || n.h(bVar2.a, bVar).f;
    }

    private void l1(boolean z, C1508k c1508k) {
        if (this.Y0 != z) {
            this.Y0 = z;
            if (!z) {
                for (O0 o0 : this.q) {
                    o0.L();
                }
            }
        }
        if (c1508k != null) {
            c1508k.f();
        }
    }

    private void m0() {
        boolean zO1 = O1();
        this.V0 = zO1;
        if (zO1) {
            C0641q0 c0641q0 = (C0641q0) C1498a.e(this.y0.n());
            c0641q0.e(new C0639p0.b().f(c0641q0.C(this.d1)).g(this.u0.f().a).e(this.U0).d());
        }
        W1();
    }

    private void m1(ax.P0.G g2) {
        this.n0.i(16);
        this.u0.d(g2);
    }

    public static /* synthetic */ void n(C0635n0 c0635n0, ax.p228o1.z zVar, long j, long j2, C1375v c1375v, MediaFormat mediaFormat) {
        c0635n0.getClass();
        zVar.k(j, j2, c1375v, mediaFormat);
        c0635n0.k(j, j2, c1375v, mediaFormat);
    }

    private void n0() {
        this.y0.I();
        C0641q0 c0641q0W = this.y0.w();
        if (c0641q0W != null) {
            if ((!c0641q0W.e || c0641q0W.f) && !c0641q0W.a.c()) {
                if (this.l0.e(this.O0.a, c0641q0W.h.a, c0641q0W.f ? c0641q0W.a.d() : 0L)) {
                    if (c0641q0W.e) {
                        c0641q0W.e(new C0639p0.b().f(c0641q0W.C(this.d1)).g(this.u0.f().a).e(this.U0).d());
                    } else {
                        c0641q0W.v(this, c0641q0W.h.b);
                    }
                }
            }
        }
    }

    private void n1(b bVar) throws Throwable {
        this.P0.b(1);
        if (bVar.c != -1) {
            this.c1 = new h(new L0(bVar.a, bVar.b), bVar.c, bVar.d);
        }
        a0(this.z0.C(bVar.a, bVar.b), false);
    }

    public static /* synthetic */ void o(C0635n0 c0635n0, K0 k0) {
        c0635n0.getClass();
        try {
            c0635n0.A(k0);
        } catch (C0643s e2) {
            C1517u.d("ExoPlayerImplInternal", "Unexpected error delivering message on external thread.", e2);
            throw new RuntimeException(e2);
        }
    }

    private void o0() throws C0643s {
        for (O0 o0 : this.q) {
            o0.D();
        }
    }

    private void p0() {
        this.P0.c(this.O0);
        if (this.P0.a) {
            this.x0.a(this.P0);
            this.P0 = new e(this.O0);
        }
    }

    private void p1(boolean z) {
        if (z == this.a1) {
            return;
        }
        this.a1 = z;
        if (z || !this.O0.p) {
            return;
        }
        this.n0.f(2);
    }

    private void q0() throws C0643s {
        C0641q0 c0641q0X = this.y0.x();
        if (c0641q0X == null) {
            return;
        }
        ax.p180l1.K kP = c0641q0X.p();
        for (int i = 0; i < this.q.length; i++) {
            if (kP.c(i) && this.q[i].s() && !this.q[i].u()) {
                this.q[i].X();
                F(c0641q0X, i, false, c0641q0X.n());
            }
        }
        if (x()) {
            this.m1 = c0641q0X.a.s();
            if (c0641q0X.s()) {
                return;
            }
            this.y0.N(c0641q0X);
            Y(false);
            m0();
        }
    }

    private void q1(boolean z) throws C0643s {
        this.R0 = z;
        R0();
        if (!this.S0 || this.y0.y() == this.y0.u()) {
            return;
        }
        b1(true);
        Y(false);
    }

    private void r0(int i) throws C0643s, IOException {
        O0 o0 = this.q[i];
        try {
            o0.G((C0641q0) C1498a.e(this.y0.u()));
        } catch (IOException | RuntimeException e2) {
            int iM = o0.m();
            if (iM != 3 && iM != 5) {
                throw e2;
            }
            ax.p180l1.K kP = this.y0.u().p();
            C1517u.d("ExoPlayerImplInternal", "Disabling track due to error: " + C1375v.l(kP.c[i].m()), e2);
            ax.p180l1.K k = new ax.p180l1.K((ax.Y0.W[]) kP.b.clone(), (ax.p180l1.D[]) kP.c.clone(), kP.d, kP.e);
            k.b[i] = null;
            k.c[i] = null;
            C(i);
            this.y0.u().a(k, this.O0.s, false);
        }
    }

    private void s0(final int i, final boolean z) {
        boolean[] zArr = this.Y;
        if (zArr[i] != z) {
            zArr[i] = z;
            this.F0.c(new Runnable() { // from class: androidx.media3.exoplayer.j0
                @Override // java.lang.Runnable
                public final void run() {
                    C0635n0 c0635n0 = this.q;
                    int i2 = i;
                    c0635n0.E0.a0(i2, c0635n0.q[i2].m(), z);
                }
            });
        }
    }

    private void s1(boolean z, int i, boolean z2, int i2) throws C0643s {
        this.P0.b(z2 ? 1 : 0);
        c2(z, i, i2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:72:0x0079, code lost:
    
        r3 = null;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private void t0(long j, long j2) throws C0643s {
        if (this.v0.isEmpty() || this.O0.b.b()) {
            return;
        }
        if (this.g1) {
            j--;
            this.g1 = false;
        }
        J0 j0 = this.O0;
        int iB = j0.a.b(j0.b.a);
        int iMin = Math.min(this.f1, this.v0.size());
        d dVar = iMin > 0 ? this.v0.get(iMin - 1) : null;
        while (dVar != null) {
            int i = dVar.X;
            if (i <= iB && (i != iB || dVar.Y <= j)) {
                break;
            }
            int i2 = iMin - 1;
            dVar = i2 > 0 ? this.v0.get(iMin - 2) : null;
            iMin = i2;
        }
        if (iMin < this.v0.size()) {
            d dVar2 = this.v0.get(iMin);
            while (dVar2 != null && dVar2.Z != null) {
                int i3 = dVar2.X;
                if (i3 >= iB && (i3 != iB || dVar2.Y > j)) {
                    break;
                }
                iMin++;
                dVar2 = iMin < this.v0.size() ? this.v0.get(iMin) : null;
            }
            while (dVar2 != null && dVar2.Z != null && dVar2.X == iB) {
                long j3 = dVar2.Y;
                if (j3 <= j || j3 > j2) {
                    break;
                }
                try {
                    g1(dVar2.q);
                    if (dVar2.q.a() || dVar2.q.i()) {
                        this.v0.remove(iMin);
                    } else {
                        iMin++;
                    }
                    dVar2 = iMin < this.v0.size() ? this.v0.get(iMin) : null;
                } catch (Throwable th) {
                    if (dVar2.q.a() || dVar2.q.i()) {
                        this.v0.remove(iMin);
                    }
                    throw th;
                }
            }
            this.f1 = iMin;
        }
    }

    private void u(b bVar, int i) throws Throwable {
        this.P0.b(1);
        I0 i0 = this.z0;
        if (i == -1) {
            i = i0.r();
        }
        a0(i0.f(i, bVar.a, bVar.b), false);
    }

    private boolean u0() throws C0643s {
        C0642r0 c0642r0T;
        this.y0.K(this.d1);
        boolean z = false;
        if (this.y0.T() && (c0642r0T = this.y0.t(this.d1, this.O0)) != null) {
            C0641q0 c0641q0H = this.y0.h(c0642r0T);
            if (!c0641q0H.e) {
                c0641q0H.v(this, c0642r0T.b);
            } else if (c0641q0H.f) {
                this.n0.j(8, c0641q0H.a).a();
            }
            if (this.y0.u() == c0641q0H) {
                S0(c0642r0T.b);
            }
            Y(false);
            z = true;
        }
        if (!this.V0) {
            m0();
            return z;
        }
        this.V0 = i0(this.y0.n());
        W1();
        return z;
    }

    private void u1(ax.P0.G g2) throws C0643s {
        m1(g2);
        d0(this.u0.f(), true);
    }

    private void v() {
        ax.p180l1.K kP = this.y0.u().p();
        for (int i = 0; i < this.q.length; i++) {
            if (kP.c(i)) {
                this.q[i].f();
            }
        }
    }

    private void v0() {
        C0641q0 c0641q0U;
        boolean z;
        if (this.y0.u() == this.y0.y() && (c0641q0U = this.y0.u()) != null) {
            ax.p180l1.K kP = c0641q0U.p();
            boolean z2 = false;
            int i = 0;
            boolean z3 = false;
            while (true) {
                if (i >= this.q.length) {
                    z = true;
                    break;
                }
                if (kP.c(i)) {
                    if (this.q[i].m() != 1) {
                        z = false;
                        break;
                    } else if (kP.b[i].a != 0) {
                        z3 = true;
                    }
                }
                i++;
            }
            if (z3 && z) {
                z2 = true;
            }
            p1(z2);
        }
    }

    private void v1(ExoPlayer.c cVar) {
        this.k1 = cVar;
        this.y0.V(this.O0.a, cVar);
    }

    private void w() throws C0643s {
        for (O0 o0 : this.q) {
            o0.R(this.L0 ? this.J0 : null);
        }
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0047  */
    private void w0() throws C0643s {
        boolean z;
        boolean z2 = false;
        while (N1()) {
            if (z2) {
                p0();
            }
            this.n1 = false;
            C0641q0 c0641q0 = (C0641q0) C1498a.e(this.y0.b());
            if (this.O0.b.a.equals(c0641q0.h.a.a)) {
                ax.i1.F.b bVar = this.O0.b;
                if (bVar.b == -1) {
                    ax.i1.F.b bVar2 = c0641q0.h.a;
                    if (bVar2.b != -1 || bVar.e == bVar2.e) {
                        z = false;
                    } else {
                        z = true;
                    }
                } else {
                    z = false;
                }
            } else {
                z = false;
            }
            C0642r0 c0642r0 = c0641q0.h;
            ax.i1.F.b bVar3 = c0642r0.a;
            long j = c0642r0.b;
            this.O0 = e0(bVar3, j, c0642r0.c, j, !z, 0);
            R0();
            e2();
            if (x() && c0641q0 == this.y0.x()) {
                o0();
            }
            if (this.O0.e == 3) {
                S1();
            }
            v();
            z2 = true;
        }
    }

    private boolean x() {
        if (!this.G0) {
            return false;
        }
        for (O0 o0 : this.q) {
            if (o0.u()) {
                return true;
            }
        }
        return false;
    }

    private void x0(boolean z) {
        if (this.k1.a == -9223372036854775807L) {
            return;
        }
        if (z || !this.O0.a.equals(this.l1)) {
            ax.P0.N n = this.O0.a;
            this.l1 = n;
            this.y0.B(n);
        }
        n0();
    }

    private void x1(int i) throws C0643s {
        this.W0 = i;
        int iX = this.y0.X(this.O0.a, i);
        if ((iX & 1) != 0) {
            b1(true);
        } else if ((iX & 2) != 0) {
            B();
        }
        Y(false);
    }

    private void y() throws C0643s {
        P0();
    }

    private void y0() throws C0643s {
        C0641q0 c0641q0X;
        if (this.S0 || !this.G0 || this.n1 || x() || (c0641q0X = this.y0.x()) == null || c0641q0X != this.y0.y() || c0641q0X.k() == null || !c0641q0X.k().f) {
            return;
        }
        this.y0.c();
        q0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public C0641q0 z(C0642r0 c0642r0, long j) {
        return new C0641q0(this.X, j, this.Z, this.l0.h(), this.z0, c0642r0, this.k0, this.k1.a);
    }

    private void z0() throws C0643s {
        C0641q0 c0641q0Y = this.y0.y();
        if (c0641q0Y == null) {
            return;
        }
        int i = 0;
        if (c0641q0Y.k() == null || this.S0) {
            if (c0641q0Y.h.j || this.S0) {
                O0[] o0Arr = this.q;
                int length = o0Arr.length;
                while (i < length) {
                    O0 o0 = o0Arr[i];
                    if (o0.x(c0641q0Y) && o0.r(c0641q0Y)) {
                        long j = c0641q0Y.h.e;
                        o0.O(c0641q0Y, (j == -9223372036854775807L || j == Long.MIN_VALUE) ? -9223372036854775807L : c0641q0Y.m() + c0641q0Y.h.e);
                    }
                    i++;
                }
                return;
            }
            return;
        }
        if (f0()) {
            if (x() && this.y0.x() == this.y0.y()) {
                return;
            }
            if (c0641q0Y.k().f || this.d1 >= c0641q0Y.k().n()) {
                ax.p180l1.K kP = c0641q0Y.p();
                C0641q0 c0641q0D = this.y0.d();
                ax.p180l1.K kP2 = c0641q0D.p();
                ax.P0.N n = this.O0.a;
                f2(n, c0641q0D.h.a, n, c0641q0Y.h.a, -9223372036854775807L, false);
                if (c0641q0D.f && ((this.G0 && this.m1 != -9223372036854775807L) || c0641q0D.a.s() != -9223372036854775807L)) {
                    this.m1 = -9223372036854775807L;
                    boolean z = this.G0 && !this.n1;
                    if (z) {
                        for (int i2 = 0; i2 < this.q.length; i2++) {
                            if (kP2.c(i2) && this.q[i2].m() != -2 && !ax.P0.D.a(kP2.c[i2].m().o, kP2.c[i2].m().k) && !this.q[i2].u()) {
                                z = false;
                                break;
                            }
                        }
                    }
                    if (!z) {
                        i1(c0641q0D.n());
                        if (c0641q0D.s()) {
                            return;
                        }
                        this.y0.N(c0641q0D);
                        Y(false);
                        m0();
                        return;
                    }
                }
                O0[] o0Arr2 = this.q;
                int length2 = o0Arr2.length;
                while (i < length2) {
                    o0Arr2[i].F(kP, kP2, c0641q0D.n());
                    i++;
                }
            }
        }
    }

    private void z1(boolean z) throws Throwable {
        if (!z) {
            this.M0 = false;
            this.n0.i(37);
            h hVar = this.N0;
            if (hVar != null) {
                c1(hVar, false);
                this.N0 = null;
            }
        }
        this.L0 = z;
        w();
    }

    public void A1(ax.Y0.Y y) {
        this.n0.j(38, y).a();
    }

    public void C1(ax.Y0.Z z) {
        this.n0.j(5, z).a();
    }

    public void E1(boolean z) {
        this.n0.a(12, z ? 1 : 0, 0).a();
    }

    @Override // ax.i1.f0.a
    /* JADX INFO: renamed from: G0, reason: merged with bridge method [inline-methods] */
    public void i(ax.p132i1.C c2) {
        this.n0.j(9, c2).a();
    }

    public void H0() {
        this.n0.d(29).a();
    }

    public void I(long j) {
        this.i1 = j;
    }

    public boolean J0() {
        if (this.Q0 || !this.p0.getThread().isAlive()) {
            return true;
        }
        this.Q0 = true;
        C1508k c1508k = new C1508k(this.w0);
        this.n0.j(7, c1508k).a();
        return c1508k.c(this.B0);
    }

    public boolean J1(Object obj, long j) {
        if (!this.Q0 && this.p0.getThread().isAlive()) {
            C1508k c1508k = new C1508k(this.w0);
            this.n0.j(30, new Pair(obj, c1508k)).a();
            if (j != -9223372036854775807L) {
                return c1508k.c(j);
            }
        }
        return true;
    }

    public void L1(float f2) {
        this.n0.j(32, Float.valueOf(f2)).a();
    }

    public void N0(int i, int i2, ax.p132i1.g0 g0Var) {
        this.n0.g(20, i, i2, g0Var).a();
    }

    public Looper P() {
        return this.p0;
    }

    public void T1() {
        this.n0.d(6).a();
    }

    @Override // ax.l1.J.a
    public void a(M0 m0) {
        this.n0.f(26);
    }

    public void a1(ax.P0.N n, int i, long j) {
        this.n0.j(3, new h(n, i, j)).a();
    }

    @Override // ax.l1.J.a
    public void b() {
        this.n0.f(10);
    }

    @Override // androidx.media3.exoplayer.C0620g.a
    public void c(float f2) {
        this.n0.f(34);
    }

    @Override // androidx.media3.exoplayer.C0620g.a
    public void d(int i) {
        this.n0.a(33, i, 0).a();
    }

    @Override // androidx.media3.exoplayer.I0.d
    public void e() {
        this.n0.i(2);
        this.n0.f(22);
    }

    @Override // ax.i1.C.a
    public void f(ax.p132i1.C c2) {
        this.n0.j(8, c2).a();
    }

    @Override // androidx.media3.exoplayer.K0.a
    public void g(K0 k0) {
        if (!this.Q0 && this.p0.getThread().isAlive()) {
            this.n0.j(14, k0).a();
        } else {
            C1517u.h("ExoPlayerImplInternal", "Ignoring messages sent after release.");
            k0.j(false);
        }
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message message) throws Throwable {
        int i;
        ax.i1.F.b bVar;
        C0641q0 c0641q0Y;
        int i2 = 1000;
        try {
            switch (message.what) {
                case 1:
                    boolean z = message.arg1 != 0;
                    int i3 = message.arg2;
                    s1(z, i3 >> 4, true, i3 & 15);
                    break;
                case 2:
                    E();
                    break;
                case 3:
                    c1((h) message.obj, true);
                    break;
                case 4:
                    u1((ax.P0.G) message.obj);
                    break;
                case 5:
                    D1((ax.Y0.Z) message.obj);
                    break;
                case 6:
                    U1(false, true);
                    break;
                case 7:
                    K0((C1508k) message.obj);
                    return true;
                case 8:
                    b0((ax.p132i1.C) message.obj);
                    break;
                case 9:
                    W((ax.p132i1.C) message.obj);
                    break;
                case 10:
                    O0();
                    break;
                case 11:
                    x1(message.arg1);
                    break;
                case 12:
                    F1(message.arg1 != 0);
                    break;
                case 13:
                    l1(message.arg1 != 0, (C1508k) message.obj);
                    break;
                case 14:
                    f1((K0) message.obj);
                    break;
                case 15:
                    h1((K0) message.obj);
                    break;
                case 16:
                    d0((ax.P0.G) message.obj, false);
                    break;
                case 17:
                    n1((b) message.obj);
                    break;
                case 18:
                    u((b) message.obj, message.arg1);
                    break;
                case 19:
                    C0((c) message.obj);
                    break;
                case 20:
                    M0(message.arg1, message.arg2, (ax.p132i1.g0) message.obj);
                    break;
                case C3772df.zzm /* 21 */:
                    G1((ax.p132i1.g0) message.obj);
                    break;
                case 22:
                    B0();
                    break;
                case 23:
                    q1(message.arg1 != 0);
                    break;
                case 24:
                default:
                    return false;
                case 25:
                    y();
                    break;
                case 26:
                    P0();
                    break;
                case 27:
                    Y1(message.arg1, message.arg2, (List) message.obj);
                    break;
                case 28:
                    v1((ExoPlayer.c) message.obj);
                    break;
                case 29:
                    I0();
                    break;
                case 30:
                    Pair pair = (Pair) message.obj;
                    K1(pair.first, (C1508k) pair.second);
                    break;
                case 31:
                    k1((C1357c) message.obj, message.arg1 != 0);
                    break;
                case 32:
                    M1(((Float) message.obj).floatValue());
                    break;
                case 33:
                    U(message.arg1);
                    break;
                case 34:
                    V();
                    break;
                case 35:
                    I1((ax.p228o1.z) message.obj);
                    break;
                case 36:
                    z1(((Boolean) message.obj).booleanValue());
                    break;
                case 37:
                    this.M0 = false;
                    h hVar = this.N0;
                    if (hVar != null) {
                        c1(hVar, false);
                        this.N0 = null;
                    }
                    break;
                case 38:
                    B1((ax.Y0.Y) message.obj);
                    break;
            }
        } catch (C0643s e2) {
            e = e2;
            if (e.p0 == 1 && (c0641q0Y = this.y0.y()) != null && e.u0 == null) {
                e = e.c(c0641q0Y.h.a);
            }
            if (e.p0 == 1 && (bVar = e.u0) != null && j0(e.r0, bVar)) {
                this.n1 = true;
                B();
                C0641q0 c0641q0X = this.y0.x();
                C0641q0 c0641q0U = this.y0.u();
                if (this.y0.u() != c0641q0X) {
                    while (c0641q0U != null && c0641q0U.k() != c0641q0X) {
                        c0641q0U = c0641q0U.k();
                    }
                }
                this.y0.N(c0641q0U);
                if (this.O0.e != 4) {
                    m0();
                    this.n0.f(2);
                }
            } else {
                C0643s c0643s = this.h1;
                if (c0643s != null) {
                    c0643s.addSuppressed(e);
                    e = this.h1;
                }
                if (e.p0 == 1 && this.y0.u() != this.y0.y()) {
                    while (this.y0.u() != this.y0.y()) {
                        this.y0.b();
                    }
                    C0641q0 c0641q0 = (C0641q0) C1498a.e(this.y0.u());
                    p0();
                    C0642r0 c0642r0 = c0641q0.h;
                    ax.i1.F.b bVar2 = c0642r0.a;
                    long j = c0642r0.b;
                    this.O0 = e0(bVar2, j, c0642r0.c, j, true, 0);
                }
                if (e.v0 && (this.h1 == null || (i = e.q) == 5004 || i == 5003)) {
                    C1517u.i("ExoPlayerImplInternal", "Recoverable renderer error", e);
                    if (this.h1 == null) {
                        this.h1 = e;
                    }
                    InterfaceC1514q interfaceC1514q = this.n0;
                    interfaceC1514q.b(interfaceC1514q.j(25, e));
                } else {
                    C1517u.d("ExoPlayerImplInternal", "Playback error", e);
                    U1(true, false);
                    this.O0 = this.O0.f(e);
                }
            }
        } catch (ax.P0.E e3) {
            int i4 = e3.X;
            if (i4 == 1) {
                i2 = e3.q ? 3001 : 3003;
            } else if (i4 == 4) {
                i2 = e3.q ? 3002 : 3004;
            }
            X(e3, i2);
        } catch (ax.U0.h e4) {
            X(e4, e4.q);
        } catch (InterfaceC1824n.a e5) {
            X(e5, e5.q);
        } catch (C2095b e6) {
            X(e6, 1002);
        } catch (IOException e7) {
            X(e7, 2000);
        } catch (RuntimeException e8) {
            C0643s c0643sF = C0643s.f(e8, ((e8 instanceof IllegalStateException) || (e8 instanceof IllegalArgumentException)) ? 1004 : 1000);
            C1517u.d("ExoPlayerImplInternal", "Playback error", c0643sF);
            U1(true, false);
            this.O0 = this.O0.f(c0643sF);
        }
        p0();
        return true;
    }

    public void j1(C1357c c1357c, boolean z) {
        this.n0.g(31, z ? 1 : 0, 0, c1357c).a();
    }

    @Override // ax.p228o1.z
    public void k(long j, long j2, C1375v c1375v, MediaFormat mediaFormat) {
        if (this.M0) {
            this.n0.d(37).a();
        }
    }

    public void o1(List<I0.c> list, int i, long j, ax.p132i1.g0 g0Var) {
        this.n0.j(17, new b(list, g0Var, i, j, null)).a();
    }

    public void r1(boolean z, int i, int i2) {
        this.n0.a(1, z ? 1 : 0, i | (i2 << 4)).a();
    }

    @Override // androidx.media3.exoplayer.C0628k.a
    public void t(ax.P0.G g2) {
        this.n0.j(16, g2).a();
    }

    public void t1(ax.P0.G g2) {
        this.n0.j(4, g2).a();
    }

    public void w1(int i) {
        this.n0.a(11, i, 0).a();
    }

    public void y1(boolean z) {
        this.n0.j(36, Boolean.valueOf(z)).a();
    }
}
