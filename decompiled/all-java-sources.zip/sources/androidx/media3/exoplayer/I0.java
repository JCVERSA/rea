package androidx.media3.exoplayer;

import android.util.Pair;
import ax.P0.C1378y;
import ax.S0.C1498a;
import ax.S0.C1517u;
import ax.S0.InterfaceC1514q;
import ax.Y0.AbstractC1607a;
import ax.Z0.I1;
import ax.Z0.InterfaceC1657a;
import ax.p020b1.InterfaceC1830u;
import ax.p132i1.C2117y;
import ax.p132i1.C2118z;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
final class I0 {
    private final I1 a;
    private final d e;
    private final InterfaceC1657a h;
    private final InterfaceC1514q i;
    private boolean k;
    private ax.U0.z l;
    private ax.p132i1.g0 j = new ax.i1.g0.a(0);
    private final IdentityHashMap<ax.p132i1.C, c> c = new IdentityHashMap<>();
    private final Map<Object, c> d = new HashMap();
    private final List<c> b = new ArrayList();
    private final HashMap<c, b> f = new HashMap<>();
    private final Set<c> g = new HashSet();

    /* JADX INFO: Access modifiers changed from: private */
    final class a implements ax.p132i1.N, InterfaceC1830u {
        private final c q;

        public a(c cVar) {
            this.q = cVar;
        }

        private Pair<Integer, ax.i1.F.b> R(int i, ax.i1.F.b bVar) {
            ax.i1.F.b bVar2 = null;
            if (bVar != null) {
                ax.i1.F.b bVarN = I0.n(this.q, bVar);
                if (bVarN == null) {
                    return null;
                }
                bVar2 = bVarN;
            }
            return Pair.create(Integer.valueOf(I0.s(this.q, i)), bVar2);
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void P(int i, ax.i1.F.b bVar) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.H0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.P(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void W(int i, ax.i1.F.b bVar, final ax.p132i1.B b) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.w0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.W(((Integer) pair.first).intValue(), (ax.i1.F.b) C1498a.e((ax.i1.F.b) pair.second), b);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void d0(int i, ax.i1.F.b bVar, final C2117y c2117y, final ax.p132i1.B b, final int i2) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.x0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.d0(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, c2117y, b, i2);
                    }
                });
            }
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void e(int i, ax.i1.F.b bVar) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.D0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.e(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void g(int i, ax.i1.F.b bVar, final C2117y c2117y, final ax.p132i1.B b) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.F0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.g(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, c2117y, b);
                    }
                });
            }
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void i(int i, ax.i1.F.b bVar) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.A0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.i(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second);
                    }
                });
            }
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void k(int i, ax.i1.F.b bVar) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.E0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.k(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void l(int i, ax.i1.F.b bVar, final ax.p132i1.B b) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.C0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.l(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, b);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void m(int i, ax.i1.F.b bVar, final C2117y c2117y, final ax.p132i1.B b) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.z0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.m(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, c2117y, b);
                    }
                });
            }
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void n(int i, ax.i1.F.b bVar, final int i2) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.G0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.n(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, i2);
                    }
                });
            }
        }

        @Override // ax.p132i1.N
        public void p(int i, ax.i1.F.b bVar, final C2117y c2117y, final ax.p132i1.B b, final IOException iOException, final boolean z) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.y0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.p(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, c2117y, b, iOException, z);
                    }
                });
            }
        }

        @Override // ax.p020b1.InterfaceC1830u
        public void q(int i, ax.i1.F.b bVar, final Exception exc) {
            final Pair<Integer, ax.i1.F.b> pairR = R(i, bVar);
            if (pairR != null) {
                I0.this.i.c(new Runnable() { // from class: androidx.media3.exoplayer.B0
                    @Override // java.lang.Runnable
                    public final void run() {
                        I0.a aVar = this.q;
                        Pair pair = pairR;
                        I0.this.h.q(((Integer) pair.first).intValue(), (ax.i1.F.b) pair.second, exc);
                    }
                });
            }
        }
    }

    private static final class b {
        public final ax.p132i1.F a;
        public final ax.i1.F.c b;
        public final a c;

        public b(ax.p132i1.F f, ax.i1.F.c cVar, a aVar) {
            this.a = f;
            this.b = cVar;
            this.c = aVar;
        }
    }

    static final class c implements InterfaceC0648u0 {
        public final ax.p132i1.A a;
        public int d;
        public boolean e;
        public final List<ax.i1.F.b> c = new ArrayList();
        public final Object b = new Object();

        public c(ax.p132i1.F f, boolean z) {
            this.a = new ax.p132i1.A(f, z);
        }

        public void a(int i) {
            this.d = i;
            this.e = false;
            this.c.clear();
        }

        @Override // androidx.media3.exoplayer.InterfaceC0648u0
        public Object t0() {
            return this.b;
        }

        @Override // androidx.media3.exoplayer.InterfaceC0648u0
        public ax.P0.N u0() {
            return this.a.W();
        }
    }

    public interface d {
        void e();
    }

    public I0(d dVar, InterfaceC1657a interfaceC1657a, InterfaceC1514q interfaceC1514q, I1 i1) {
        this.a = i1;
        this.e = dVar;
        this.h = interfaceC1657a;
        this.i = interfaceC1514q;
    }

    private void B(int i, int i2) {
        for (int i3 = i2 - 1; i3 >= i; i3--) {
            c cVarRemove = this.b.remove(i3);
            this.d.remove(cVarRemove.b);
            g(i3, -cVarRemove.a.W().p());
            cVarRemove.e = true;
            if (this.k) {
                u(cVarRemove);
            }
        }
    }

    private void g(int i, int i2) {
        while (i < this.b.size()) {
            this.b.get(i).d += i2;
            i++;
        }
    }

    private void j(c cVar) {
        b bVar = this.f.get(cVar);
        if (bVar != null) {
            bVar.a.q(bVar.b);
        }
    }

    private void k() {
        Iterator<c> it = this.g.iterator();
        while (it.hasNext()) {
            c next = it.next();
            if (next.c.isEmpty()) {
                j(next);
                it.remove();
            }
        }
    }

    private void l(c cVar) {
        this.g.add(cVar);
        b bVar = this.f.get(cVar);
        if (bVar != null) {
            bVar.a.d(bVar.b);
        }
    }

    private static Object m(Object obj) {
        return AbstractC1607a.v(obj);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static ax.i1.F.b n(c cVar, ax.i1.F.b bVar) {
        for (int i = 0; i < cVar.c.size(); i++) {
            if (cVar.c.get(i).d == bVar.d) {
                return bVar.a(p(cVar, bVar.a));
            }
        }
        return null;
    }

    private static Object o(Object obj) {
        return AbstractC1607a.w(obj);
    }

    private static Object p(c cVar, Object obj) {
        return AbstractC1607a.y(cVar.b, obj);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int s(c cVar, int i) {
        return i + cVar.d;
    }

    private void u(c cVar) {
        if (cVar.e && cVar.c.isEmpty()) {
            b bVar = (b) C1498a.e(this.f.remove(cVar));
            bVar.a.b(bVar.b);
            bVar.a.g(bVar.c);
            bVar.a.n(bVar.c);
            this.g.remove(cVar);
        }
    }

    private void x(c cVar) {
        ax.p132i1.A a2 = cVar.a;
        ax.i1.F.c cVar2 = new ax.i1.F.c() { // from class: androidx.media3.exoplayer.v0
            @Override // ax.i1.F.c
            public final void a(ax.p132i1.F f, ax.P0.N n) {
                this.a.e.e();
            }
        };
        a aVar = new a(cVar);
        this.f.put(cVar, new b(a2, cVar2, aVar));
        a2.c(ax.S0.d0.C(), aVar);
        a2.p(ax.S0.d0.C(), aVar);
        a2.l(cVar2, this.l, this.a);
    }

    public ax.P0.N A(int i, int i2, ax.p132i1.g0 g0Var) {
        C1498a.a(i >= 0 && i <= i2 && i2 <= r());
        this.j = g0Var;
        B(i, i2);
        return i();
    }

    public ax.P0.N C(List<c> list, ax.p132i1.g0 g0Var) {
        B(0, this.b.size());
        return f(this.b.size(), list, g0Var);
    }

    public ax.P0.N D(ax.p132i1.g0 g0Var) {
        int iR = r();
        if (g0Var.getLength() != iR) {
            g0Var = g0Var.g().e(0, iR);
        }
        this.j = g0Var;
        return i();
    }

    public ax.P0.N E(int i, int i2, List<C1378y> list) {
        C1498a.a(i >= 0 && i <= i2 && i2 <= r());
        C1498a.a(list.size() == i2 - i);
        for (int i3 = i; i3 < i2; i3++) {
            this.b.get(i3).a.a(list.get(i3 - i));
        }
        return i();
    }

    public ax.P0.N f(int i, List<c> list, ax.p132i1.g0 g0Var) {
        if (!list.isEmpty()) {
            this.j = g0Var;
            for (int i2 = i; i2 < list.size() + i; i2++) {
                c cVar = list.get(i2 - i);
                if (i2 > 0) {
                    c cVar2 = this.b.get(i2 - 1);
                    cVar.a(cVar2.d + cVar2.a.W().p());
                } else {
                    cVar.a(0);
                }
                g(i2, cVar.a.W().p());
                this.b.add(i2, cVar);
                this.d.put(cVar.b, cVar);
                if (this.k) {
                    x(cVar);
                    if (this.c.isEmpty()) {
                        this.g.add(cVar);
                    } else {
                        j(cVar);
                    }
                }
            }
        }
        return i();
    }

    public ax.p132i1.C h(ax.i1.F.b bVar, ax.p196m1.b bVar2, long j) {
        Object objO = o(bVar.a);
        ax.i1.F.b bVarA = bVar.a(m(bVar.a));
        c cVar = (c) C1498a.e(this.d.get(objO));
        l(cVar);
        cVar.c.add(bVarA);
        C2118z c2118zI = cVar.a.i(bVarA, bVar2, j);
        this.c.put(c2118zI, cVar);
        k();
        return c2118zI;
    }

    public ax.P0.N i() {
        if (this.b.isEmpty()) {
            return ax.P0.N.a;
        }
        int iP = 0;
        for (int i = 0; i < this.b.size(); i++) {
            c cVar = this.b.get(i);
            cVar.d = iP;
            iP += cVar.a.W().p();
        }
        return new L0(this.b, this.j);
    }

    public ax.p132i1.g0 q() {
        return this.j;
    }

    public int r() {
        return this.b.size();
    }

    public boolean t() {
        return this.k;
    }

    public ax.P0.N v(int i, int i2, int i3, ax.p132i1.g0 g0Var) {
        C1498a.a(i >= 0 && i <= i2 && i2 <= r() && i3 >= 0);
        this.j = g0Var;
        if (i == i2 || i == i3) {
            return i();
        }
        int iMin = Math.min(i, i3);
        int iMax = Math.max(((i2 - i) + i3) - 1, i2 - 1);
        int iP = this.b.get(iMin).d;
        ax.S0.d0.Z0(this.b, i, i2, i3);
        while (iMin <= iMax) {
            c cVar = this.b.get(iMin);
            cVar.d = iP;
            iP += cVar.a.W().p();
            iMin++;
        }
        return i();
    }

    public void w(ax.U0.z zVar) {
        C1498a.g(!this.k);
        this.l = zVar;
        for (int i = 0; i < this.b.size(); i++) {
            c cVar = this.b.get(i);
            x(cVar);
            this.g.add(cVar);
        }
        this.k = true;
    }

    public void y() {
        for (b bVar : this.f.values()) {
            try {
                bVar.a.b(bVar.b);
            } catch (RuntimeException e) {
                C1517u.d("MediaSourceList", "Failed to release child source.", e);
            }
            bVar.a.g(bVar.c);
            bVar.a.n(bVar.c);
        }
        this.f.clear();
        this.g.clear();
        this.k = false;
    }

    public void z(ax.p132i1.C c2) {
        c cVar = (c) C1498a.e(this.c.remove(c2));
        cVar.a.e(c2);
        cVar.c.remove(((C2118z) c2).q);
        if (!this.c.isEmpty()) {
            k();
        }
        u(cVar);
    }
}
