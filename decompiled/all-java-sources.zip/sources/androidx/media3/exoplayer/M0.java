package androidx.media3.exoplayer;

import ax.P0.C1375v;
import ax.S0.InterfaceC1505h;
import ax.Z0.I1;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public interface M0 extends K0.b {

    public interface a {
        void a();

        void b();
    }

    void C() throws IOException;

    long D();

    void F(long j) throws C0643s;

    boolean G();

    ax.Y0.S H();

    void a();

    boolean c();

    void e();

    void g(long j, long j2) throws C0643s;

    String getName();

    int getState();

    void h();

    ax.p132i1.e0 i();

    boolean isReady();

    int j();

    void m(int i, I1 i1, InterfaceC1505h interfaceC1505h);

    boolean n();

    long o(long j, long j2);

    void p();

    void q();

    void r(ax.P0.N n);

    void s(ax.Y0.W w, C1375v[] c1375vArr, ax.p132i1.e0 e0Var, long j, boolean z, boolean z2, long j2, long j3, ax.i1.F.b bVar) throws C0643s;

    void start() throws C0643s;

    void stop();

    void t(C1375v[] c1375vArr, ax.p132i1.e0 e0Var, long j, long j2, ax.i1.F.b bVar) throws C0643s;

    N0 u();

    void x(float f, float f2) throws C0643s;
}
