package androidx.media3.exoplayer;

import android.content.Context;
import android.os.Looper;
import ax.S0.InterfaceC1505h;

/* JADX INFO: loaded from: classes.dex */
public interface X0 {

    public interface a {
        void a(boolean z);
    }

    boolean a();

    void b(a aVar, Context context, Looper looper, Looper looper2, InterfaceC1505h interfaceC1505h);

    void e();
}
