package androidx.media3.exoplayer;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import ax.P0.C1357c;
import ax.S0.C1498a;
import ax.S0.C1517u;
import j$.util.Objects;

/* JADX INFO: renamed from: androidx.media3.exoplayer.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0620g {
    private final ax.X7.u<AudioManager> a;
    private final Handler b;
    private a c;
    private C1357c d;
    private int f;
    private ax.Q0.f h;
    private boolean i;
    private float g = 1.0f;
    private int e = 0;

    /* JADX INFO: renamed from: androidx.media3.exoplayer.g$a */
    public interface a {
        void c(float f);

        void d(int i);
    }

    public C0620g(final Context context, Looper looper, a aVar) {
        this.a = ax.X7.v.a(new ax.X7.u() { // from class: androidx.media3.exoplayer.f
            @Override // ax.X7.u
            public final Object get() {
                return ax.Q0.m.c(context);
            }
        });
        this.c = aVar;
        this.b = new Handler(looper);
    }

    private void c() {
        int i = this.e;
        if (i == 1 || i == 0 || this.h == null) {
            return;
        }
        ax.Q0.m.b(this.a.get(), this.h);
    }

    private static int d(C1357c c1357c) {
        if (c1357c == null) {
            return 0;
        }
        switch (c1357c.c) {
            case 0:
                C1517u.h("AudioFocusManager", "Specify a proper usage in the audio attributes for audio focus handling. Using AUDIOFOCUS_GAIN by default.");
                return 1;
            case 1:
            case 14:
                return 1;
            case 2:
            case 4:
                return 2;
            case 3:
                return 0;
            case 11:
                if (c1357c.a == 1) {
                    return 2;
                }
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 12:
            case 13:
                return 3;
            case 15:
            default:
                C1517u.h("AudioFocusManager", "Unidentified audio usage: " + c1357c.c);
                return 0;
            case 16:
                return 4;
        }
    }

    private void e(int i) {
        a aVar = this.c;
        if (aVar != null) {
            aVar.d(i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(int i) {
        if (i == -3 || i == -2) {
            if (i != -2 && !o()) {
                l(4);
                return;
            } else {
                e(0);
                l(3);
                return;
            }
        }
        if (i == -1) {
            e(-1);
            c();
            l(1);
        } else if (i == 1) {
            l(2);
            e(1);
        } else {
            C1517u.h("AudioFocusManager", "Unknown focus change type: " + i);
        }
    }

    private int i() {
        if (this.e == 2) {
            return 1;
        }
        if (j() == 1) {
            l(2);
            return 1;
        }
        l(1);
        return -1;
    }

    private int j() {
        ax.Q0.f fVar = this.h;
        if (fVar == null || this.i) {
            this.h = (fVar == null ? new ax.Q0.f.b(this.f) : fVar.a()).b((C1357c) C1498a.e(this.d)).d(o()).c(new AudioManager.OnAudioFocusChangeListener() { // from class: androidx.media3.exoplayer.e
                @Override // android.media.AudioManager.OnAudioFocusChangeListener
                public final void onAudioFocusChange(int i) {
                    this.q.g(i);
                }
            }, this.b).a();
            this.i = false;
        }
        return ax.Q0.m.h(this.a.get(), this.h);
    }

    private void l(int i) {
        if (this.e == i) {
            return;
        }
        this.e = i;
        float f = i == 4 ? 0.2f : 1.0f;
        if (this.g == f) {
            return;
        }
        this.g = f;
        a aVar = this.c;
        if (aVar != null) {
            aVar.c(f);
        }
    }

    private boolean m(int i) {
        return i != 1 && this.f == 1;
    }

    private boolean o() {
        C1357c c1357c = this.d;
        return c1357c != null && c1357c.a == 1;
    }

    public float f() {
        return this.g;
    }

    public void h() {
        this.c = null;
        c();
        l(0);
    }

    public void k(C1357c c1357c) {
        if (Objects.equals(this.d, c1357c)) {
            return;
        }
        this.d = c1357c;
        int iD = d(c1357c);
        this.f = iD;
        boolean z = true;
        if (iD != 1 && iD != 0) {
            z = false;
        }
        C1498a.b(z, "Automatic handling of audio focus is only available for USAGE_MEDIA and USAGE_GAME.");
    }

    public int n(boolean z, int i) {
        if (!m(i)) {
            c();
            l(0);
            return 1;
        }
        if (z) {
            return i();
        }
        int i2 = this.e;
        if (i2 != 1) {
            return i2 != 3 ? 1 : 0;
        }
        return -1;
    }
}
