package androidx.media3.exoplayer;

import ax.P0.C1356b;
import ax.Y0.AbstractC1607a;
import ax.p132i1.AbstractC2115w;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
final class L0 extends AbstractC1607a {
    private final int h;
    private final int i;
    private final int[] j;
    private final int[] k;
    private final ax.P0.N[] l;
    private final Object[] m;
    private final HashMap<Object, Integer> n;

    class a extends AbstractC2115w {
        private final ax.P0.N.c f;

        a(ax.P0.N n) {
            super(n);
            this.f = new ax.P0.N.c();
        }

        @Override // ax.p132i1.AbstractC2115w, ax.P0.N
        public ax.P0.N.b g(int i, ax.P0.N.b bVar, boolean z) {
            ax.P0.N.b bVarG = super.g(i, bVar, z);
            if (super.n(bVarG.c, this.f).f()) {
                bVarG.u(bVar.a, bVar.b, bVar.c, bVar.d, bVar.e, C1356b.g, true);
                return bVarG;
            }
            bVarG.f = true;
            return bVarG;
        }
    }

    public L0(Collection<? extends InterfaceC0648u0> collection, ax.p132i1.g0 g0Var) {
        this(G(collection), H(collection), g0Var);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    private L0(ax.P0.N[] nArr, Object[] objArr, ax.p132i1.g0 g0Var) {
        super(false, g0Var);
        int i = 0;
        int length = nArr.length;
        this.l = nArr;
        this.j = new int[length];
        this.k = new int[length];
        this.m = objArr;
        this.n = new HashMap<>();
        int length2 = nArr.length;
        int iP = 0;
        int i2 = 0;
        int i3 = 0;
        while (i < length2) {
            ax.P0.N n = nArr[i];
            this.l[i3] = n;
            this.k[i3] = iP;
            this.j[i3] = i2;
            iP += n.p();
            i2 += this.l[i3].i();
            this.n.put(objArr[i3], Integer.valueOf(i3));
            i++;
            i3++;
        }
        this.h = iP;
        this.i = i2;
    }

    private static ax.P0.N[] G(Collection<? extends InterfaceC0648u0> collection) {
        ax.P0.N[] nArr = new ax.P0.N[collection.size()];
        Iterator<? extends InterfaceC0648u0> it = collection.iterator();
        int i = 0;
        while (it.hasNext()) {
            nArr[i] = it.next().u0();
            i++;
        }
        return nArr;
    }

    private static Object[] H(Collection<? extends InterfaceC0648u0> collection) {
        Object[] objArr = new Object[collection.size()];
        Iterator<? extends InterfaceC0648u0> it = collection.iterator();
        int i = 0;
        while (it.hasNext()) {
            objArr[i] = it.next().t0();
            i++;
        }
        return objArr;
    }

    @Override // ax.Y0.AbstractC1607a
    protected int A(int i) {
        return this.k[i];
    }

    @Override // ax.Y0.AbstractC1607a
    protected ax.P0.N D(int i) {
        return this.l[i];
    }

    public L0 E(ax.p132i1.g0 g0Var) {
        ax.P0.N[] nArr = new ax.P0.N[this.l.length];
        int i = 0;
        while (true) {
            ax.P0.N[] nArr2 = this.l;
            if (i >= nArr2.length) {
                return new L0(nArr, this.m, g0Var);
            }
            nArr[i] = new a(nArr2[i]);
            i++;
        }
    }

    List<ax.P0.N> F() {
        return Arrays.asList(this.l);
    }

    @Override // ax.P0.N
    public int i() {
        return this.i;
    }

    @Override // ax.P0.N
    public int p() {
        return this.h;
    }

    @Override // ax.Y0.AbstractC1607a
    protected int s(Object obj) {
        Integer num = this.n.get(obj);
        if (num == null) {
            return -1;
        }
        return num.intValue();
    }

    @Override // ax.Y0.AbstractC1607a
    protected int t(int i) {
        return ax.S0.d0.g(this.j, i + 1, false, false);
    }

    @Override // ax.Y0.AbstractC1607a
    protected int u(int i) {
        return ax.S0.d0.g(this.k, i + 1, false, false);
    }

    @Override // ax.Y0.AbstractC1607a
    protected Object x(int i) {
        return this.m[i];
    }

    @Override // ax.Y0.AbstractC1607a
    protected int z(int i) {
        return this.j[i];
    }
}
