package androidx.media3.exoplayer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Pair;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import androidx.media3.exoplayer.image.ImageOutput;
import ax.P0.AbstractC1362h;
import ax.P0.C1357c;
import ax.P0.C1368n;
import ax.P0.C1375v;
import ax.P0.C1376w;
import ax.P0.C1378y;
import ax.P0.C1379z;
import ax.S0.C1498a;
import ax.S0.C1503f;
import ax.S0.C1508k;
import ax.S0.C1516t;
import ax.S0.C1517u;
import ax.S0.InterfaceC1505h;
import ax.S0.InterfaceC1514q;
import ax.Y0.C1608b;
import ax.Y0.C1609c;
import ax.Y7.AbstractC1656z;
import ax.Z0.E1;
import ax.Z0.I1;
import ax.Z0.InterfaceC1657a;
import ax.Z0.InterfaceC1663c;
import ax.p004a1.InterfaceC1761z;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: loaded from: classes.dex */
final class X extends AbstractC1362h implements ExoPlayer {
    private final d A;
    private long A0;
    private final C0614d B;
    private final V0 C;
    private final a1 D;
    private final d1 E;
    private final long F;
    private final X0 G;
    private final C1503f<Integer> H;
    private int I;
    private boolean J;
    private int K;
    private int L;
    private boolean M;
    private boolean N;
    private ax.Y7.C<Integer> O;
    private ax.Y0.Y P;
    private ax.Y0.Z Q;
    private ax.p132i1.g0 R;
    private ExoPlayer.c S;
    private boolean T;
    private ax.P0.H.b U;
    private ax.P0.A V;
    private ax.P0.A W;
    private C1375v X;
    private C1375v Y;
    private Object Z;
    private Surface a0;
    final ax.p180l1.K b;
    private SurfaceHolder b0;
    final ax.P0.H.b c;
    private ax.p244p1.l c0;
    private final C1508k d = new C1508k();
    private boolean d0;
    private final Context e;
    private TextureView e0;
    private final ax.P0.H f;
    private int f0;
    private final M0[] g;
    private int g0;
    private final M0[] h;
    private ax.S0.I h0;
    private final ax.p180l1.J i;
    private C1608b i0;
    private final InterfaceC1514q j;
    private C1608b j0;
    private final C0635n0.f k;
    private C1357c k0;
    private final C0635n0 l;
    private float l0;
    private final C1516t<ax.P0.H.d> m;
    private boolean m0;
    private final CopyOnWriteArraySet<ExoPlayer.a> n;
    private ax.R0.c n0;
    private final ax.P0.N.b o;
    private boolean o0;
    private final List<e> p;
    private boolean p0;
    private final boolean q;
    private int q0;
    private final ax.i1.F.a r;
    private ax.P0.J r0;
    private final InterfaceC1657a s;
    private boolean s0;
    private final Looper t;
    private boolean t0;
    private final ax.p196m1.e u;
    private C1368n u0;
    private final long v;
    private ax.P0.a0 v0;
    private final long w;
    private ax.P0.A w0;
    private final long x;
    private J0 x0;
    private final InterfaceC1505h y;
    private int y0;
    private final c z;
    private int z0;

    /* JADX INFO: Access modifiers changed from: private */
    static final class b {
        public static /* synthetic */ void a(Context context, boolean z, X x, I1 i1) {
            E1 e1F0 = E1.F0(context);
            if (e1F0 == null) {
                C1517u.h("ExoPlayerImpl", "MediaMetricsService unavailable.");
                return;
            }
            if (z) {
                x.e(e1F0);
            }
            i1.b(e1F0.M0());
        }

        public static void b(final Context context, final X x, final boolean z, final I1 i1) {
            x.X1().d(x.c2(), null).c(new Runnable() { // from class: androidx.media3.exoplayer.Y
                @Override // java.lang.Runnable
                public final void run() {
                    X.b.a(context, z, x, i1);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class c implements ax.p228o1.P, InterfaceC1761z, ax.p164k1.h, ax.p100g1.b, SurfaceHolder.Callback, TextureView.SurfaceTextureListener, ax.p1.l.b, C0614d.b, V0.b, ExoPlayer.a {
        private c() {
        }

        @Override // ax.p228o1.P
        public void A(Object obj, long j) {
            X.this.s.A(obj, j);
            if (X.this.Z == obj) {
                X.this.m.k(26, new C1516t.a() { // from class: ax.Y0.M
                    @Override // ax.S0.C1516t.a
                    public final void invoke(Object obj2) {
                        ((ax.P0.H.d) obj2).h0();
                    }
                });
            }
        }

        @Override // ax.p100g1.b
        public void B(final ax.P0.C c) {
            X x = X.this;
            x.w0 = x.w0.a().M(c).J();
            ax.P0.A aO1 = X.this.O1();
            if (!aO1.equals(X.this.V)) {
                X.this.V = aO1;
                X.this.m.h(14, new C1516t.a() { // from class: androidx.media3.exoplayer.b0
                    @Override // ax.S0.C1516t.a
                    public final void invoke(Object obj) {
                        ((ax.P0.H.d) obj).n0(X.this.V);
                    }
                });
            }
            X.this.m.h(28, new C1516t.a() { // from class: androidx.media3.exoplayer.c0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).B(c);
                }
            });
            X.this.m.f();
        }

        @Override // ax.p164k1.h
        public void C(final ax.R0.c cVar) {
            X.this.n0 = cVar;
            X.this.m.k(27, new C1516t.a() { // from class: androidx.media3.exoplayer.Z
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).C(cVar);
                }
            });
        }

        @Override // ax.p164k1.h
        public void D(final List<ax.R0.a> list) {
            X.this.m.k(27, new C1516t.a() { // from class: androidx.media3.exoplayer.d0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).D(list);
                }
            });
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void E(C1608b c1608b) {
            X.this.s.E(c1608b);
            X.this.Y = null;
            X.this.j0 = null;
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void F(C1608b c1608b) {
            X.this.j0 = c1608b;
            X.this.s.F(c1608b);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void G(long j) {
            X.this.s.G(j);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void H(Exception exc) {
            X.this.s.H(exc);
        }

        @Override // ax.p228o1.P
        public void I(Exception exc) {
            X.this.s.I(exc);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void J(int i, long j, long j2) {
            X.this.s.J(i, j, j2);
        }

        @Override // ax.p228o1.P
        public void K(C1608b c1608b) {
            X.this.i0 = c1608b;
            X.this.s.K(c1608b);
        }

        @Override // ax.p228o1.P
        public void L(long j, int i) {
            X.this.s.L(j, i);
        }

        @Override // ax.p228o1.P
        public void a(final ax.P0.a0 a0Var) {
            X.this.v0 = a0Var;
            X.this.m.k(25, new C1516t.a() { // from class: androidx.media3.exoplayer.e0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).a(a0Var);
                }
            });
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void b(ax.a1.B.a aVar) {
            X.this.s.b(aVar);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void c(final int i) {
            X.this.H.h(new ax.X7.f() { // from class: androidx.media3.exoplayer.i0
                @Override // ax.X7.f
                public final Object apply(Object obj) {
                    return Integer.valueOf(i);
                }
            }, new ax.X7.f() { // from class: androidx.media3.exoplayer.a0
                @Override // ax.X7.f
                public final Object apply(Object obj) {
                    return Integer.valueOf(i);
                }
            });
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void d(final boolean z) {
            if (X.this.m0 == z) {
                return;
            }
            X.this.m0 = z;
            X.this.m.k(23, new C1516t.a() { // from class: androidx.media3.exoplayer.h0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).d(z);
                }
            });
        }

        @Override // androidx.media3.exoplayer.V0.b
        public void e(int i) {
            final C1368n c1368nS1 = X.S1(X.this.C);
            if (c1368nS1.equals(X.this.u0)) {
                return;
            }
            X.this.u0 = c1368nS1;
            X.this.m.k(29, new C1516t.a() { // from class: androidx.media3.exoplayer.f0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).o0(c1368nS1);
                }
            });
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void f(Exception exc) {
            X.this.s.f(exc);
        }

        @Override // androidx.media3.exoplayer.C0614d.b
        public void g() {
            X.this.E2(false, 3);
        }

        @Override // ax.p1.l.b
        public void h(Surface surface) {
            X.this.A2(null);
        }

        @Override // androidx.media3.exoplayer.ExoPlayer.a
        public /* synthetic */ void i(boolean z) {
            ax.Y0.C.a(this, z);
        }

        @Override // ax.p1.l.b
        public void j(Surface surface) {
            X.this.A2(surface);
        }

        @Override // androidx.media3.exoplayer.V0.b
        public void k(final int i, final boolean z) {
            X.this.m.k(30, new C1516t.a() { // from class: androidx.media3.exoplayer.g0
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).e0(i, z);
                }
            });
        }

        @Override // androidx.media3.exoplayer.ExoPlayer.a
        public void l(boolean z) {
            X.this.H2();
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void o(ax.a1.B.a aVar) {
            X.this.s.o(aVar);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
            X.this.z2(surfaceTexture);
            X.this.m2(i, i2);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            X.this.A2(null);
            X.this.m2(0, 0);
            return true;
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
            X.this.m2(i, i2);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }

        @Override // ax.p228o1.P
        public void r(C1375v c1375v, C1609c c1609c) {
            X.this.X = c1375v;
            X.this.s.r(c1375v, c1609c);
        }

        @Override // ax.p228o1.P
        public void s(String str) {
            X.this.s.s(str);
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            X.this.m2(i2, i3);
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            if (X.this.d0) {
                X.this.A2(surfaceHolder.getSurface());
            }
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            if (X.this.d0) {
                X.this.A2(null);
            }
            X.this.m2(0, 0);
        }

        @Override // ax.p228o1.P
        public void u(String str, long j, long j2) {
            X.this.s.u(str, j, j2);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void v(C1375v c1375v, C1609c c1609c) {
            X.this.Y = c1375v;
            X.this.s.v(c1375v, c1609c);
        }

        @Override // ax.p228o1.P
        public void w(C1608b c1608b) {
            X.this.s.w(c1608b);
            X.this.X = null;
            X.this.i0 = null;
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void x(String str) {
            X.this.s.x(str);
        }

        @Override // ax.p004a1.InterfaceC1761z
        public void y(String str, long j, long j2) {
            X.this.s.y(str, j, j2);
        }

        @Override // ax.p228o1.P
        public void z(int i, long j) {
            X.this.s.z(i, j);
        }
    }

    private static final class d implements ax.p228o1.z, ax.p244p1.a, K0.b {
        private ax.p244p1.a X;
        private ax.p228o1.z Y;
        private ax.p244p1.a Z;
        private ax.p228o1.z q;

        private d() {
        }

        @Override // androidx.media3.exoplayer.K0.b
        public void B(int i, Object obj) {
            if (i == 7) {
                this.q = (ax.p228o1.z) obj;
                return;
            }
            if (i == 8) {
                this.X = (ax.p244p1.a) obj;
                return;
            }
            if (i != 10000) {
                return;
            }
            ax.p244p1.l lVar = (ax.p244p1.l) obj;
            if (lVar == null) {
                this.Y = null;
                this.Z = null;
            } else {
                this.Y = lVar.getVideoFrameMetadataListener();
                this.Z = lVar.getCameraMotionListener();
            }
        }

        @Override // ax.p244p1.a
        public void b(long j, float[] fArr) {
            ax.p244p1.a aVar = this.Z;
            if (aVar != null) {
                aVar.b(j, fArr);
            }
            ax.p244p1.a aVar2 = this.X;
            if (aVar2 != null) {
                aVar2.b(j, fArr);
            }
        }

        @Override // ax.p244p1.a
        public void d() {
            ax.p244p1.a aVar = this.Z;
            if (aVar != null) {
                aVar.d();
            }
            ax.p244p1.a aVar2 = this.X;
            if (aVar2 != null) {
                aVar2.d();
            }
        }

        @Override // ax.p228o1.z
        public void k(long j, long j2, C1375v c1375v, MediaFormat mediaFormat) {
            long j3;
            long j4;
            C1375v c1375v2;
            MediaFormat mediaFormat2;
            ax.p228o1.z zVar = this.Y;
            if (zVar != null) {
                zVar.k(j, j2, c1375v, mediaFormat);
                mediaFormat2 = mediaFormat;
                c1375v2 = c1375v;
                j4 = j2;
                j3 = j;
            } else {
                j3 = j;
                j4 = j2;
                c1375v2 = c1375v;
                mediaFormat2 = mediaFormat;
            }
            ax.p228o1.z zVar2 = this.q;
            if (zVar2 != null) {
                zVar2.k(j3, j4, c1375v2, mediaFormat2);
            }
        }
    }

    private static final class e implements InterfaceC0648u0 {
        private final Object a;
        private final ax.p132i1.F b;
        private ax.P0.N c;

        public e(Object obj, ax.p132i1.A a) {
            this.a = obj;
            this.b = a;
            this.c = a.W();
        }

        public void a(ax.P0.N n) {
            this.c = n;
        }

        @Override // androidx.media3.exoplayer.InterfaceC0648u0
        public Object t0() {
            return this.a;
        }

        @Override // androidx.media3.exoplayer.InterfaceC0648u0
        public ax.P0.N u0() {
            return this.c;
        }
    }

    static {
        C1379z.a("media3.exoplayer");
    }

    @SuppressLint({"HandlerLeak"})
    public X(ExoPlayer.b bVar, ax.P0.H h) {
        Looper looper;
        Looper looper2;
        InterfaceC1505h interfaceC1505h;
        try {
            C1517u.f("ExoPlayerImpl", "Init " + Integer.toHexString(System.identityHashCode(this)) + " [AndroidXMedia3/1.8.1] [" + ax.S0.d0.e + "]");
            this.e = bVar.a.getApplicationContext();
            this.s = bVar.i.apply(bVar.b);
            this.q0 = bVar.k;
            this.r0 = bVar.l;
            this.k0 = bVar.m;
            this.f0 = bVar.s;
            this.g0 = bVar.t;
            this.m0 = bVar.q;
            this.F = bVar.C;
            c cVar = new c();
            this.z = cVar;
            this.A = new d();
            Handler handler = new Handler(bVar.j);
            ax.Y0.X x = bVar.d.get();
            Handler handler2 = handler;
            M0[] m0ArrB = x.b(handler2, cVar, cVar, cVar, cVar);
            this.g = m0ArrB;
            C1498a.g(m0ArrB.length > 0);
            this.h = new M0[m0ArrB.length];
            int i = 0;
            while (true) {
                M0[] m0Arr = this.h;
                if (i >= m0Arr.length) {
                    break;
                }
                M0 m0 = this.g[i];
                c cVar2 = this.z;
                ax.Y0.X x2 = x;
                Handler handler3 = handler2;
                m0Arr[i] = x2.a(m0, handler3, cVar2, cVar2, cVar2, cVar2);
                i++;
                x = x2;
                handler2 = handler3;
            }
            ax.p180l1.J j = bVar.f.get();
            this.i = j;
            this.r = bVar.e.get();
            ax.p196m1.e eVar = bVar.h.get();
            this.u = eVar;
            this.q = bVar.u;
            this.Q = bVar.v;
            this.v = bVar.x;
            this.w = bVar.y;
            this.x = bVar.z;
            this.P = bVar.w;
            this.T = bVar.D;
            Looper looper3 = bVar.j;
            this.t = looper3;
            InterfaceC1505h interfaceC1505h2 = bVar.b;
            this.y = interfaceC1505h2;
            ax.P0.H h2 = h == null ? this : h;
            this.f = h2;
            this.m = new C1516t<>(looper3, interfaceC1505h2, new C1516t.b() { // from class: androidx.media3.exoplayer.C
                @Override // ax.S0.C1516t.b
                public final void a(Object obj, ax.P0.r rVar) {
                    ((ax.P0.H.d) obj).i0(this.a.f, new ax.P0.H.c(rVar));
                }
            });
            this.n = new CopyOnWriteArraySet<>();
            this.p = new ArrayList();
            this.R = new ax.i1.g0.a(0);
            this.S = ExoPlayer.c.b;
            M0[] m0Arr2 = this.g;
            ax.p180l1.K k = new ax.p180l1.K(new ax.Y0.W[m0Arr2.length], new ax.p180l1.D[m0Arr2.length], ax.P0.V.b, null);
            this.b = k;
            this.o = new ax.P0.N.b();
            ax.P0.H.b bVarE = new ax.P0.H.b.a().c(1, 2, 3, 13, 14, 15, 16, 17, 18, 19, 31, 20, 30, 21, 35, 22, 24, 27, 28, 32).d(29, j.h()).d(23, bVar.r).d(25, bVar.r).d(33, bVar.r).d(26, bVar.r).d(34, bVar.r).e();
            this.c = bVarE;
            this.U = new ax.P0.H.b.a().b(bVarE).a(4).a(10).e();
            this.j = interfaceC1505h2.d(looper3, null);
            C0635n0.f fVar = new C0635n0.f() { // from class: androidx.media3.exoplayer.D
                @Override // androidx.media3.exoplayer.C0635n0.f
                public final void a(C0635n0.e eVar2) {
                    X x3 = this.a;
                    x3.j.c(new Runnable() { // from class: androidx.media3.exoplayer.J
                        @Override // java.lang.Runnable
                        public final void run() {
                            x3.h2(eVar2);
                        }
                    });
                }
            };
            this.k = fVar;
            this.x0 = J0.k(k);
            this.s.j0(h2, looper3);
            I1 i1 = new I1(bVar.I);
            C0635n0 c0635n0 = new C0635n0(this.e, this.g, this.h, j, k, bVar.g.get(), eVar, this.I, this.J, this.s, this.Q, bVar.A, bVar.B, this.T, bVar.J, looper3, interfaceC1505h2, fVar, i1, bVar.F, this.S, this.A);
            this.l = c0635n0;
            Looper looperP = c0635n0.P();
            this.l0 = 1.0f;
            this.I = 0;
            ax.P0.A a2 = ax.P0.A.I;
            this.V = a2;
            this.W = a2;
            this.w0 = a2;
            this.y0 = -1;
            this.n0 = ax.R0.c.d;
            this.o0 = true;
            G(this.s);
            eVar.e(new Handler(looper3), this.s);
            L1(this.z);
            long j2 = bVar.c;
            if (j2 > 0) {
                c0635n0.I(j2);
            }
            if (Build.VERSION.SDK_INT >= 31) {
                b.b(this.e, this, bVar.E, i1);
            }
            C1503f<Integer> c1503f = new C1503f<>(0, looperP, looper3, interfaceC1505h2, new C1503f.a() { // from class: androidx.media3.exoplayer.F
                @Override // ax.S0.C1503f.a
                public final void a(Object obj, Object obj2) {
                    this.a.o2(((Integer) obj).intValue(), ((Integer) obj2).intValue());
                }
            });
            this.H = c1503f;
            c1503f.e(new Runnable() { // from class: androidx.media3.exoplayer.G
                @Override // java.lang.Runnable
                public final void run() {
                    X x3 = this.q;
                    x3.H.g(Integer.valueOf(ax.S0.d0.J(x3.e)));
                }
            });
            C0614d c0614d = new C0614d(bVar.a, looperP, bVar.j, this.z, interfaceC1505h2);
            this.B = c0614d;
            c0614d.d(bVar.p);
            if (bVar.H) {
                X0 x0 = bVar.K;
                this.G = x0;
                looper = looper3;
                x0.b(new X0.a() { // from class: androidx.media3.exoplayer.H
                    @Override // androidx.media3.exoplayer.X0.a
                    public final void a(boolean z) {
                        this.a.p2(z);
                    }
                }, this.e, looper, looperP, interfaceC1505h2);
                looperP = looperP;
            } else {
                looper = looper3;
                this.G = null;
            }
            if (bVar.r) {
                Looper looper4 = looperP;
                looper2 = looper4;
                interfaceC1505h = interfaceC1505h2;
                this.C = new V0(bVar.a, this.z, this.k0.b(), looper4, looper, interfaceC1505h2);
            } else {
                looper2 = looperP;
                interfaceC1505h = interfaceC1505h2;
                this.C = null;
            }
            a1 a1Var = new a1(bVar.a, looper2, interfaceC1505h);
            this.D = a1Var;
            a1Var.c(bVar.o != 0);
            d1 d1Var = new d1(bVar.a, looper2, interfaceC1505h);
            this.E = d1Var;
            d1Var.c(bVar.o == 2);
            this.u0 = C1368n.e;
            this.v0 = ax.P0.a0.e;
            this.h0 = ax.S0.I.c;
            c0635n0.A1(this.P);
            c0635n0.j1(this.k0, bVar.n);
            u2(1, 3, this.k0);
            u2(2, 4, Integer.valueOf(this.f0));
            u2(2, 5, Integer.valueOf(this.g0));
            u2(1, 9, Boolean.valueOf(this.m0));
            u2(6, 8, this.A);
            v2(16, Integer.valueOf(this.q0));
        } finally {
            this.d.f();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A2(Object obj) {
        Object obj2 = this.Z;
        boolean z = (obj2 == null || obj2 == obj) ? false : true;
        boolean zJ1 = this.l.J1(obj, z ? this.F : -9223372036854775807L);
        if (z) {
            Object obj3 = this.Z;
            Surface surface = this.a0;
            if (obj3 == surface) {
                surface.release();
                this.a0 = null;
            }
        }
        this.Z = obj;
        if (zJ1) {
            return;
        }
        C2(C0643s.f(new ax.Y0.N(3), 1003));
    }

    private void C2(C0643s c0643s) {
        J0 j0 = this.x0;
        J0 j0C = j0.c(j0.b);
        j0C.q = j0C.s;
        j0C.r = 0L;
        J0 j0J2 = j2(j0C, 1);
        if (c0643s != null) {
            j0J2 = j0J2.f(c0643s);
        }
        this.K++;
        this.l.T1();
        F2(j0J2, 0, false, 5, -9223372036854775807L, -1, false);
    }

    private void D2() {
        ax.P0.H.b bVar = this.U;
        ax.P0.H.b bVarO = ax.S0.d0.O(this.f, this.c);
        this.U = bVarO;
        if (bVarO.equals(bVar)) {
            return;
        }
        this.m.h(13, new C1516t.a() { // from class: androidx.media3.exoplayer.L
            @Override // ax.S0.C1516t.a
            public final void invoke(Object obj) {
                ((ax.P0.H.d) obj).c0(this.a.U);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E2(boolean z, int i) {
        int iR1 = R1(z);
        J0 j0A = this.x0;
        if (j0A.l == z && j0A.n == iR1 && j0A.m == i) {
            return;
        }
        this.K++;
        if (j0A.p) {
            j0A = j0A.a();
        }
        J0 j0E = j0A.e(z, i, iR1);
        this.l.r1(z, i, iR1);
        F2(j0E, 0, false, 5, -9223372036854775807L, -1, false);
    }

    private void F2(final J0 j0, final int i, boolean z, final int i2, long j, int i3, boolean z2) {
        J0 j1 = this.x0;
        this.x0 = j0;
        boolean zEquals = j1.a.equals(j0.a);
        Pair<Boolean, Integer> pairW1 = W1(j0, j1, z, i2, !zEquals, z2);
        boolean zBooleanValue = ((Boolean) pairW1.first).booleanValue();
        final int iIntValue = ((Integer) pairW1.second).intValue();
        final C1378y c1378y = null;
        if (zBooleanValue) {
            if (!j0.a.q()) {
                c1378y = j0.a.n(j0.a.h(j0.b.a, this.o).c, this.a).c;
            }
            this.w0 = ax.P0.A.I;
        }
        if (zBooleanValue || !j1.j.equals(j0.j)) {
            this.w0 = this.w0.a().N(j0.j).J();
        }
        ax.P0.A aO1 = O1();
        boolean zEquals2 = aO1.equals(this.V);
        this.V = aO1;
        boolean z3 = j1.l != j0.l;
        boolean z4 = j1.e != j0.e;
        if (z4 || z3) {
            H2();
        }
        boolean z5 = j1.g;
        boolean z6 = j0.g;
        boolean z7 = z5 != z6;
        if (z7) {
            G2(z6);
        }
        if (!zEquals) {
            this.m.h(0, new C1516t.a() { // from class: androidx.media3.exoplayer.t
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ax.P0.H.d dVar = (ax.P0.H.d) obj;
                    dVar.X(j0.a, i);
                }
            });
        }
        if (z) {
            final ax.P0.H.e eVarF2 = f2(i2, j1, i3);
            final ax.P0.H.e eVarE2 = e2(j);
            this.m.h(11, new C1516t.a() { // from class: androidx.media3.exoplayer.S
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    X.d1(i2, eVarF2, eVarE2, (ax.P0.H.d) obj);
                }
            });
        }
        if (zBooleanValue) {
            this.m.h(1, new C1516t.a() { // from class: androidx.media3.exoplayer.T
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).g0(c1378y, iIntValue);
                }
            });
        }
        if (j1.f != j0.f) {
            this.m.h(10, new C1516t.a() { // from class: androidx.media3.exoplayer.U
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).S(j0.f);
                }
            });
            if (j0.f != null) {
                this.m.h(10, new C1516t.a() { // from class: androidx.media3.exoplayer.V
                    @Override // ax.S0.C1516t.a
                    public final void invoke(Object obj) {
                        ((ax.P0.H.d) obj).U(j0.f);
                    }
                });
            }
        }
        ax.p180l1.K k = j1.i;
        ax.p180l1.K k2 = j0.i;
        if (k != k2) {
            this.i.i(k2.e);
            this.m.h(2, new C1516t.a() { // from class: androidx.media3.exoplayer.W
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).Q(j0.i.d);
                }
            });
        }
        if (!zEquals2) {
            final ax.P0.A a2 = this.V;
            this.m.h(14, new C1516t.a() { // from class: androidx.media3.exoplayer.u
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).n0(a2);
                }
            });
        }
        if (z7) {
            this.m.h(3, new C1516t.a() { // from class: androidx.media3.exoplayer.v
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    X.I0(j0, (ax.P0.H.d) obj);
                }
            });
        }
        if (z4 || z3) {
            this.m.h(-1, new C1516t.a() { // from class: androidx.media3.exoplayer.w
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    J0 j2 = j0;
                    ((ax.P0.H.d) obj).f0(j2.l, j2.e);
                }
            });
        }
        if (z4) {
            this.m.h(4, new C1516t.a() { // from class: androidx.media3.exoplayer.x
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).V(j0.e);
                }
            });
        }
        if (z3 || j1.m != j0.m) {
            this.m.h(5, new C1516t.a() { // from class: androidx.media3.exoplayer.E
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    J0 j2 = j0;
                    ((ax.P0.H.d) obj).m0(j2.l, j2.m);
                }
            });
        }
        if (j1.n != j0.n) {
            this.m.h(6, new C1516t.a() { // from class: androidx.media3.exoplayer.O
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).M(j0.n);
                }
            });
        }
        if (j1.n() != j0.n()) {
            this.m.h(7, new C1516t.a() { // from class: androidx.media3.exoplayer.P
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).t0(j0.n());
                }
            });
        }
        if (!j1.o.equals(j0.o)) {
            this.m.h(12, new C1516t.a() { // from class: androidx.media3.exoplayer.Q
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).t(j0.o);
                }
            });
        }
        D2();
        this.m.f();
        if (j1.p != j0.p) {
            Iterator<ExoPlayer.a> it = this.n.iterator();
            while (it.hasNext()) {
                it.next().l(j0.p);
            }
        }
    }

    private void G2(boolean z) {
        ax.P0.J j = this.r0;
        if (j != null) {
            if (z && !this.s0) {
                j.a(this.q0);
                this.s0 = true;
            } else {
                if (z || !this.s0) {
                    return;
                }
                j.b(this.q0);
                this.s0 = false;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H2() {
        int iV = V();
        if (iV != 1) {
            if (iV == 2 || iV == 3) {
                this.D.d(o() && !i2());
                this.E.d(o());
                return;
            } else if (iV != 4) {
                throw new IllegalStateException();
            }
        }
        this.D.d(false);
        this.E.d(false);
    }

    public static /* synthetic */ void I0(J0 j0, ax.P0.H.d dVar) {
        dVar.N(j0.g);
        dVar.R(j0.g);
    }

    private void I2() {
        this.d.b();
        if (Thread.currentThread() != g0().getThread()) {
            String strG = ax.S0.d0.G("Player is accessed on the wrong thread.\nCurrent thread: '%s'\nExpected thread: '%s'\nSee https://developer.android.com/guide/topics/media/issues/player-accessed-on-wrong-thread", Thread.currentThread().getName(), g0().getThread().getName());
            if (this.o0) {
                throw new IllegalStateException(strG);
            }
            C1517u.i("ExoPlayerImpl", strG, this.p0 ? null : new IllegalStateException());
            this.p0 = true;
        }
    }

    private static ax.P0.T M1(ax.P0.T t, ax.Y7.C<Integer> c2) {
        ax.P0.T.c cVarI = t.I();
        ax.Y7.j0<Integer> it = c2.iterator();
        while (it.hasNext()) {
            cVarI.U(it.next().intValue(), true);
        }
        return cVarI.F();
    }

    private List<I0.c> N1(int i, List<ax.p132i1.F> list) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < list.size(); i2++) {
            I0.c cVar = new I0.c(list.get(i2), this.q);
            arrayList.add(cVar);
            this.p.add(i2 + i, new e(cVar.b, cVar.a));
        }
        this.R = this.R.e(i, arrayList.size());
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public ax.P0.A O1() {
        ax.P0.N nF0 = f0();
        if (nF0.q()) {
            return this.w0;
        }
        return this.w0.a().L(nF0.n(Y(), this.a).c.e).J();
    }

    private int R1(boolean z) {
        if (this.N) {
            return 4;
        }
        X0 x0 = this.G;
        if (x0 == null || x0.a()) {
            return (this.x0.n != 1 || z) ? 0 : 1;
        }
        return 3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static C1368n S1(V0 v0) {
        return new C1368n.b(0).g(v0 != null ? v0.l() : 0).f(v0 != null ? v0.k() : 0).e();
    }

    private ax.P0.N T1() {
        return new L0(this.p, this.R);
    }

    private List<ax.p132i1.F> U1(List<C1378y> list) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.add(this.r.e(list.get(i)));
        }
        return arrayList;
    }

    private K0 V1(K0.b bVar) {
        int iA2 = a2(this.x0);
        C0635n0 c0635n0 = this.l;
        return new K0(c0635n0, bVar, this.x0.a, iA2 == -1 ? 0 : iA2, this.y, c0635n0.P());
    }

    private Pair<Boolean, Integer> W1(J0 j0, J0 j1, boolean z, int i, boolean z2, boolean z3) {
        ax.P0.N n = j1.a;
        ax.P0.N n2 = j0.a;
        if (n2.q() && n.q()) {
            return new Pair<>(Boolean.FALSE, -1);
        }
        int i2 = 3;
        if (n2.q() != n.q()) {
            return new Pair<>(Boolean.TRUE, 3);
        }
        if (n.n(n.h(j1.b.a, this.o).c, this.a).a.equals(n2.n(n2.h(j0.b.a, this.o).c, this.a).a)) {
            if (z && i == 0 && j1.b.d < j0.b.d) {
                return new Pair<>(Boolean.TRUE, 0);
            }
            return (z && i == 1 && z3) ? new Pair<>(Boolean.TRUE, 2) : new Pair<>(Boolean.FALSE, -1);
        }
        if (z && i == 0) {
            i2 = 1;
        } else if (z && i == 1) {
            i2 = 2;
        } else if (!z2) {
            throw new IllegalStateException();
        }
        return new Pair<>(Boolean.TRUE, Integer.valueOf(i2));
    }

    private long Y1(J0 j0) {
        if (!j0.b.b()) {
            return ax.S0.d0.E1(Z1(j0));
        }
        j0.a.h(j0.b.a, this.o);
        return j0.c == -9223372036854775807L ? j0.a.n(a2(j0), this.a).b() : this.o.n() + ax.S0.d0.E1(j0.c);
    }

    private long Z1(J0 j0) {
        if (j0.a.q()) {
            return ax.S0.d0.a1(this.A0);
        }
        long jM = j0.p ? j0.m() : j0.s;
        return j0.b.b() ? jM : q2(j0.a, j0.b, jM);
    }

    private int a2(J0 j0) {
        return j0.a.q() ? this.y0 : j0.a.h(j0.b.a, this.o).c;
    }

    private Pair<Object, Long> b2(ax.P0.N n, ax.P0.N n2, int i, long j) {
        if (n.q() || n2.q()) {
            boolean z = !n.q() && n2.q();
            return l2(n2, z ? -1 : i, z ? -9223372036854775807L : j);
        }
        Pair<Object, Long> pairJ = n.j(this.a, this.o, i, ax.S0.d0.a1(j));
        Object obj = ((Pair) ax.S0.d0.i(pairJ)).first;
        if (n2.b(obj) != -1) {
            return pairJ;
        }
        int iY0 = C0635n0.Y0(this.a, this.o, this.I, this.J, obj, n, n2);
        return iY0 != -1 ? l2(n2, iY0, n2.n(iY0, this.a).b()) : l2(n2, -1, -9223372036854775807L);
    }

    public static /* synthetic */ void d1(int i, ax.P0.H.e eVar, ax.P0.H.e eVar2, ax.P0.H.d dVar) {
        dVar.O(i);
        dVar.r0(eVar, eVar2, i);
    }

    private ax.P0.H.e e2(long j) {
        Object obj;
        C1378y c1378y;
        Object obj2;
        int i;
        int iY = Y();
        if (this.x0.a.q()) {
            obj = null;
            c1378y = null;
            obj2 = null;
            i = -1;
        } else {
            J0 j0 = this.x0;
            Object obj3 = j0.b.a;
            j0.a.h(obj3, this.o);
            int iB = this.x0.a.b(obj3);
            obj2 = obj3;
            obj = this.x0.a.n(iY, this.a).a;
            c1378y = this.a.c;
            i = iB;
        }
        long jE1 = ax.S0.d0.E1(j);
        long jE2 = this.x0.b.b() ? ax.S0.d0.E1(g2(this.x0)) : jE1;
        ax.i1.F.b bVar = this.x0.b;
        return new ax.P0.H.e(obj, iY, c1378y, obj2, i, jE1, jE2, bVar.b, bVar.c);
    }

    private ax.P0.H.e f2(int i, J0 j0, int i2) {
        int i3;
        Object obj;
        C1378y c1378y;
        Object obj2;
        int i4;
        long jG2;
        long jG3;
        ax.P0.N.b bVar = new ax.P0.N.b();
        if (j0.a.q()) {
            i3 = i2;
            obj = null;
            c1378y = null;
            obj2 = null;
            i4 = -1;
        } else {
            Object obj3 = j0.b.a;
            j0.a.h(obj3, bVar);
            int i5 = bVar.c;
            int iB = j0.a.b(obj3);
            Object obj4 = j0.a.n(i5, this.a).a;
            c1378y = this.a.c;
            obj2 = obj3;
            i4 = iB;
            obj = obj4;
            i3 = i5;
        }
        if (i == 0) {
            if (j0.b.b()) {
                ax.i1.F.b bVar2 = j0.b;
                jG2 = bVar.b(bVar2.b, bVar2.c);
                jG3 = g2(j0);
            } else {
                jG2 = j0.b.e != -1 ? g2(this.x0) : bVar.e + bVar.d;
                jG3 = jG2;
            }
        } else if (j0.b.b()) {
            jG2 = j0.s;
            jG3 = g2(j0);
        } else {
            jG2 = bVar.e + j0.s;
            jG3 = jG2;
        }
        long jE1 = ax.S0.d0.E1(jG2);
        long jE2 = ax.S0.d0.E1(jG3);
        ax.i1.F.b bVar3 = j0.b;
        return new ax.P0.H.e(obj, i3, c1378y, obj2, i4, jE1, jE2, bVar3.b, bVar3.c);
    }

    private static long g2(J0 j0) {
        ax.P0.N.c cVar = new ax.P0.N.c();
        ax.P0.N.b bVar = new ax.P0.N.b();
        j0.a.h(j0.b.a, bVar);
        return j0.c == -9223372036854775807L ? j0.a.n(bVar.c, cVar).c() : bVar.o() + j0.c;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void h2(C0635n0.e eVar) {
        boolean z;
        long jQ2;
        int i = this.K - eVar.c;
        this.K = i;
        boolean z2 = true;
        if (eVar.d) {
            this.L = eVar.e;
            this.M = true;
        }
        if (i == 0) {
            ax.P0.N n = eVar.b.a;
            if (!this.x0.a.q() && n.q()) {
                this.y0 = -1;
                this.A0 = 0L;
                this.z0 = 0;
            }
            if (!n.q()) {
                List<ax.P0.N> listF = ((L0) n).F();
                C1498a.g(listF.size() == this.p.size());
                for (int i2 = 0; i2 < listF.size(); i2++) {
                    this.p.get(i2).a(listF.get(i2));
                }
            }
            long j = -9223372036854775807L;
            if (this.M) {
                if (eVar.b.b.equals(this.x0.b) && eVar.b.d == this.x0.s) {
                    z2 = false;
                }
                if (z2) {
                    if (n.q() || eVar.b.b.b()) {
                        jQ2 = eVar.b.d;
                    } else {
                        J0 j0 = eVar.b;
                        jQ2 = q2(n, j0.b, j0.d);
                    }
                    j = jQ2;
                }
                z = z2;
            } else {
                z = false;
            }
            this.M = false;
            F2(eVar.b, 1, z, this.L, j, -1, false);
        }
    }

    private static J0 j2(J0 j0, int i) {
        J0 j0H = j0.h(i);
        return (i == 1 || i == 4) ? j0H.b(false) : j0H;
    }

    private J0 k2(J0 j0, ax.P0.N n, Pair<Object, Long> pair) {
        C1498a.a(n.q() || pair != null);
        ax.P0.N n2 = j0.a;
        long jY1 = Y1(j0);
        J0 j0J = j0.j(n);
        if (n.q()) {
            ax.i1.F.b bVarL = J0.l();
            long jA1 = ax.S0.d0.a1(this.A0);
            J0 j0C = j0J.d(bVarL, jA1, jA1, jA1, 0L, ax.p132i1.q0.d, this.b, AbstractC1656z.y()).c(bVarL);
            j0C.q = j0C.s;
            return j0C;
        }
        Object obj = j0J.b.a;
        boolean zEquals = obj.equals(((Pair) ax.S0.d0.i(pair)).first);
        ax.i1.F.b bVar = !zEquals ? new ax.i1.F.b(pair.first) : j0J.b;
        long jLongValue = ((Long) pair.second).longValue();
        long jA2 = ax.S0.d0.a1(jY1);
        if (!n2.q()) {
            jA2 -= n2.h(obj, this.o).o();
        }
        if (!zEquals || jLongValue < jA2) {
            ax.i1.F.b bVar2 = bVar;
            C1498a.g(!bVar2.b());
            J0 j0C2 = j0J.d(bVar2, jLongValue, jLongValue, jLongValue, 0L, !zEquals ? ax.p132i1.q0.d : j0J.h, !zEquals ? this.b : j0J.i, !zEquals ? AbstractC1656z.y() : j0J.j).c(bVar2);
            j0C2.q = jLongValue;
            return j0C2;
        }
        if (jLongValue != jA2) {
            ax.i1.F.b bVar3 = bVar;
            C1498a.g(!bVar3.b());
            long jMax = Math.max(0L, j0J.r - (jLongValue - jA2));
            long j = j0J.q;
            if (j0J.k.equals(j0J.b)) {
                j = jLongValue + jMax;
            }
            J0 j0D = j0J.d(bVar3, jLongValue, jLongValue, jLongValue, jMax, j0J.h, j0J.i, j0J.j);
            j0D.q = j;
            return j0D;
        }
        int iB = n.b(j0J.k.a);
        if (iB != -1 && n.f(iB, this.o).c == n.h(bVar.a, this.o).c) {
            return j0J;
        }
        n.h(bVar.a, this.o);
        long jB = bVar.b() ? this.o.b(bVar.b, bVar.c) : this.o.d;
        ax.i1.F.b bVar4 = bVar;
        J0 j0C3 = j0J.d(bVar4, j0J.s, j0J.s, j0J.d, jB - j0J.s, j0J.h, j0J.i, j0J.j).c(bVar4);
        j0C3.q = jB;
        return j0C3;
    }

    private Pair<Object, Long> l2(ax.P0.N n, int i, long j) {
        if (n.q()) {
            this.y0 = i;
            if (j == -9223372036854775807L) {
                j = 0;
            }
            this.A0 = j;
            this.z0 = 0;
            return null;
        }
        if (i == -1 || i >= n.p()) {
            i = n.a(this.J);
            j = n.n(i, this.a).b();
        }
        return n.j(this.a, this.o, i, ax.S0.d0.a1(j));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void m2(final int i, final int i2) {
        if (i == this.h0.b() && i2 == this.h0.a()) {
            return;
        }
        this.h0 = new ax.S0.I(i, i2);
        this.m.k(24, new C1516t.a() { // from class: androidx.media3.exoplayer.z
            @Override // ax.S0.C1516t.a
            public final void invoke(Object obj) {
                ((ax.P0.H.d) obj).q0(i, i2);
            }
        });
        u2(2, 14, new ax.S0.I(i, i2));
    }

    private void n2() {
        J0 j0 = this.x0;
        E2(j0.l, j0.m);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void o2(int i, final int i2) {
        I2();
        u2(1, 10, Integer.valueOf(i2));
        u2(2, 10, Integer.valueOf(i2));
        this.m.k(21, new C1516t.a() { // from class: androidx.media3.exoplayer.N
            @Override // ax.S0.C1516t.a
            public final void invoke(Object obj) {
                ((ax.P0.H.d) obj).c(i2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void p2(boolean z) {
        if (this.t0) {
            return;
        }
        if (!z) {
            n2();
        } else if (this.x0.n == 3) {
            n2();
        }
    }

    private long q2(ax.P0.N n, ax.i1.F.b bVar, long j) {
        n.h(bVar.a, this.o);
        return j + this.o.o();
    }

    private J0 r2(J0 j0, int i, int i2) {
        int iA2 = a2(j0);
        long jY1 = Y1(j0);
        ax.P0.N n = j0.a;
        int size = this.p.size();
        this.K++;
        s2(i, i2);
        ax.P0.N nT1 = T1();
        J0 j0K2 = k2(j0, nT1, b2(n, nT1, iA2, jY1));
        int i3 = j0K2.e;
        if (i3 != 1 && i3 != 4 && i < i2 && i2 == size && iA2 >= j0K2.a.p()) {
            j0K2 = j2(j0K2, 4);
        }
        this.l.N0(i, i2, this.R);
        return j0K2;
    }

    private void s2(int i, int i2) {
        for (int i3 = i2 - 1; i3 >= i; i3--) {
            this.p.remove(i3);
        }
        this.R = this.R.a(i, i2);
    }

    private void t2() {
        if (this.c0 != null) {
            V1(this.A).m(10000).l(null).k();
            this.c0.g(this.z);
            this.c0 = null;
        }
        TextureView textureView = this.e0;
        if (textureView != null) {
            if (textureView.getSurfaceTextureListener() != this.z) {
                C1517u.h("ExoPlayerImpl", "SurfaceTextureListener already unset or replaced.");
            } else {
                this.e0.setSurfaceTextureListener(null);
            }
            this.e0 = null;
        }
        SurfaceHolder surfaceHolder = this.b0;
        if (surfaceHolder != null) {
            surfaceHolder.removeCallback(this.z);
            this.b0 = null;
        }
    }

    private void u2(int i, int i2, Object obj) {
        for (M0 m0 : this.g) {
            if (i == -1 || m0.j() == i) {
                V1(m0).m(i2).l(obj).k();
            }
        }
        for (M0 m1 : this.h) {
            if (m1 != null && (i == -1 || m1.j() == i)) {
                V1(m1).m(i2).l(obj).k();
            }
        }
    }

    private void v2(int i, Object obj) {
        u2(-1, i, obj);
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0079  */
    /* JADX WARN: Code duplicated, block: B:34:0x00a5  */
    private void x2(List<ax.p132i1.F> list, int i, long j, boolean z) {
        long j2;
        int i2;
        int i3;
        J0 j0J2;
        boolean z2;
        int iA = i;
        int iA2 = a2(this.x0);
        long jR0 = r0();
        this.K++;
        if (!this.p.isEmpty()) {
            s2(0, this.p.size());
        }
        List<I0.c> listN1 = N1(0, list);
        ax.P0.N nT1 = T1();
        if (!nT1.q() && iA >= nT1.p()) {
            throw new C1376w(nT1, iA, j);
        }
        if (!z) {
            if (iA == -1) {
                i2 = iA2;
                j2 = jR0;
            } else {
                j2 = j;
            }
            J0 j0K2 = k2(this.x0, nT1, l2(nT1, i2, j2));
            i3 = j0K2.e;
            if (i2 != -1 && i3 != 1) {
                if (!nT1.q() || i2 >= nT1.p()) {
                    i3 = 4;
                } else {
                    i3 = 2;
                }
            }
            j0J2 = j2(j0K2, i3);
            this.l.o1(listN1, i2, ax.S0.d0.a1(j2), this.R);
            if (!this.x0.b.a.equals(j0J2.b.a) || this.x0.a.q()) {
                z2 = false;
            } else {
                z2 = true;
            }
            F2(j0J2, 0, z2, 4, Z1(j0J2), -1, false);
        }
        iA = nT1.a(this.J);
        j2 = -9223372036854775807L;
        i2 = iA;
        J0 j0K3 = k2(this.x0, nT1, l2(nT1, i2, j2));
        i3 = j0K3.e;
        if (i2 != -1) {
            if (nT1.q()) {
                i3 = 4;
            } else {
                i3 = 4;
            }
        }
        j0J2 = j2(j0K3, i3);
        this.l.o1(listN1, i2, ax.S0.d0.a1(j2), this.R);
        if (this.x0.b.a.equals(j0J2.b.a)) {
            z2 = false;
        } else {
            z2 = false;
        }
        F2(j0J2, 0, z2, 4, Z1(j0J2), -1, false);
    }

    private void y2(SurfaceHolder surfaceHolder) {
        this.d0 = false;
        this.b0 = surfaceHolder;
        surfaceHolder.addCallback(this.z);
        Surface surface = this.b0.getSurface();
        if (surface == null || !surface.isValid()) {
            m2(0, 0);
        } else {
            Rect surfaceFrame = this.b0.getSurfaceFrame();
            m2(surfaceFrame.width(), surfaceFrame.height());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void z2(SurfaceTexture surfaceTexture) {
        Surface surface = new Surface(surfaceTexture);
        A2(surface);
        this.a0 = surface;
    }

    @Override // ax.P0.H
    public void B(List<C1378y> list, boolean z) {
        I2();
        w2(U1(list), z);
    }

    public void B2(SurfaceHolder surfaceHolder) {
        I2();
        if (surfaceHolder == null) {
            P1();
            return;
        }
        t2();
        this.d0 = true;
        this.b0 = surfaceHolder;
        surfaceHolder.addCallback(this.z);
        Surface surface = surfaceHolder.getSurface();
        if (surface == null || !surface.isValid()) {
            A2(null);
            m2(0, 0);
        } else {
            A2(surface);
            Rect surfaceFrame = surfaceHolder.getSurfaceFrame();
            m2(surfaceFrame.width(), surfaceFrame.height());
        }
    }

    @Override // ax.P0.H
    public int D() {
        I2();
        if (j()) {
            return this.x0.b.c;
        }
        return -1;
    }

    @Override // ax.P0.H
    public void E(SurfaceView surfaceView) {
        I2();
        if (surfaceView instanceof ax.p228o1.y) {
            t2();
            A2(surfaceView);
            y2(surfaceView.getHolder());
        } else {
            if (!(surfaceView instanceof ax.p244p1.l)) {
                B2(surfaceView == null ? null : surfaceView.getHolder());
                return;
            }
            t2();
            this.c0 = (ax.p244p1.l) surfaceView;
            V1(this.A).m(10000).l(this.c0).k();
            this.c0.d(this.z);
            A2(this.c0.getVideoSurface());
            y2(surfaceView.getHolder());
        }
    }

    @Override // ax.P0.H
    public ax.S0.I F() {
        I2();
        return this.h0;
    }

    @Override // ax.P0.H
    public void G(ax.P0.H.d dVar) {
        this.m.c((ax.P0.H.d) C1498a.e(dVar));
    }

    @Override // ax.P0.H
    public void H(int i, int i2) {
        I2();
        C1498a.a(i >= 0 && i2 >= i);
        int size = this.p.size();
        int iMin = Math.min(i2, size);
        if (i >= size || i == iMin) {
            return;
        }
        J0 j0R2 = r2(this.x0, i, iMin);
        F2(j0R2, 0, !j0R2.b.a.equals(this.x0.b.a), 4, Z1(j0R2), -1, false);
    }

    public void L1(ExoPlayer.a aVar) {
        this.n.add(aVar);
    }

    @Override // ax.P0.H
    public void N(boolean z) {
        I2();
        E2(z, 1);
    }

    @Override // ax.P0.H
    public long O() {
        I2();
        return this.w;
    }

    public void P1() {
        I2();
        t2();
        A2(null);
        m2(0, 0);
    }

    @Override // ax.P0.H
    public long Q() {
        I2();
        return Y1(this.x0);
    }

    public void Q1(SurfaceHolder surfaceHolder) {
        I2();
        if (surfaceHolder == null || surfaceHolder != this.b0) {
            return;
        }
        P1();
    }

    @Override // ax.P0.H
    public ax.P0.V S() {
        I2();
        return this.x0.i.d;
    }

    @Override // ax.P0.H
    public ax.R0.c U() {
        I2();
        return this.n0;
    }

    @Override // ax.P0.H
    public int V() {
        I2();
        return this.x0.e;
    }

    @Override // ax.P0.H
    public int W() {
        I2();
        if (j()) {
            return this.x0.b.b;
        }
        return -1;
    }

    @Override // ax.P0.H
    public void X(final int i) {
        I2();
        if (this.I != i) {
            this.I = i;
            this.l.w1(i);
            this.m.h(8, new C1516t.a() { // from class: androidx.media3.exoplayer.B
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).K0(i);
                }
            });
            D2();
            this.m.f();
        }
    }

    public InterfaceC1505h X1() {
        return this.y;
    }

    @Override // ax.P0.H
    public int Y() {
        I2();
        int iA2 = a2(this.x0);
        if (iA2 == -1) {
            return 0;
        }
        return iA2;
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void a(int i) {
        I2();
        if (i == 0) {
            this.D.c(false);
            this.E.c(false);
        } else if (i == 1) {
            this.D.c(true);
            this.E.c(false);
        } else {
            if (i != 2) {
                return;
            }
            this.D.c(true);
            this.E.c(true);
        }
    }

    @Override // ax.P0.H
    public void a0(SurfaceView surfaceView) {
        I2();
        Q1(surfaceView == null ? null : surfaceView.getHolder());
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public int b() {
        I2();
        return this.H.d().intValue();
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void c(ax.Y0.Z z) {
        I2();
        if (z == null) {
            z = ax.Y0.Z.g;
        }
        if (this.Q.equals(z)) {
            return;
        }
        this.Q = z;
        this.l.C1(z);
    }

    @Override // ax.P0.H
    public int c0() {
        I2();
        return this.x0.n;
    }

    public Looper c2() {
        return this.l.P();
    }

    @Override // ax.P0.H
    public void d(ax.P0.G g) {
        I2();
        if (g == null) {
            g = ax.P0.G.d;
        }
        if (this.x0.o.equals(g)) {
            return;
        }
        J0 j0G = this.x0.g(g);
        this.K++;
        this.l.t1(g);
        F2(j0G, 0, false, 5, -9223372036854775807L, -1, false);
    }

    @Override // ax.P0.H
    public void d0() {
        I2();
        J0 j0 = this.x0;
        if (j0.e != 1) {
            return;
        }
        J0 j0F = j0.f(null);
        J0 j0J2 = j2(j0F, j0F.a.q() ? 4 : 2);
        this.K++;
        this.l.H0();
        F2(j0J2, 1, false, 5, -9223372036854775807L, -1, false);
    }

    @Override // ax.P0.H
    /* JADX INFO: renamed from: d2, reason: merged with bridge method [inline-methods] */
    public C0643s M() {
        I2();
        return this.x0.f;
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void e(InterfaceC1663c interfaceC1663c) {
        this.s.k0((InterfaceC1663c) C1498a.e(interfaceC1663c));
    }

    @Override // ax.P0.H
    public long e0() {
        I2();
        if (!j()) {
            return v();
        }
        J0 j0 = this.x0;
        ax.i1.F.b bVar = j0.b;
        j0.a.h(bVar.a, this.o);
        return ax.S0.d0.E1(this.o.b(bVar.b, bVar.c));
    }

    @Override // ax.P0.H
    public ax.P0.G f() {
        I2();
        return this.x0.o;
    }

    @Override // ax.P0.H
    public ax.P0.N f0() {
        I2();
        return this.x0.a;
    }

    @Override // ax.P0.H
    public void g(float f) {
        I2();
        final float fO = ax.S0.d0.o(f, 0.0f, 1.0f);
        if (this.l0 == fO) {
            return;
        }
        this.l0 = fO;
        this.l.L1(fO);
        this.m.k(22, new C1516t.a() { // from class: androidx.media3.exoplayer.y
            @Override // ax.S0.C1516t.a
            public final void invoke(Object obj) {
                ((ax.P0.H.d) obj).T(fO);
            }
        });
    }

    @Override // ax.P0.H
    public Looper g0() {
        return this.t;
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void h() {
        C1517u.f("ExoPlayerImpl", "Release " + Integer.toHexString(System.identityHashCode(this)) + " [AndroidXMedia3/1.8.1] [" + ax.S0.d0.e + "] [" + C1379z.b() + "]");
        I2();
        this.B.d(false);
        V0 v0 = this.C;
        if (v0 != null) {
            v0.n();
        }
        this.D.d(false);
        this.E.d(false);
        X0 x0 = this.G;
        if (x0 != null) {
            x0.e();
        }
        if (!this.l.J0()) {
            this.m.k(10, new C1516t.a() { // from class: androidx.media3.exoplayer.A
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).U(C0643s.f(new ax.Y0.N(1), 1003));
                }
            });
        }
        this.m.i();
        this.j.k(null);
        this.u.g(this.s);
        J0 j0 = this.x0;
        if (j0.p) {
            this.x0 = j0.a();
        }
        J0 j0J2 = j2(this.x0, 1);
        this.x0 = j0J2;
        J0 j0C = j0J2.c(j0J2.b);
        this.x0 = j0C;
        j0C.q = j0C.s;
        this.x0.r = 0L;
        this.s.h();
        t2();
        Surface surface = this.a0;
        if (surface != null) {
            surface.release();
            this.a0 = null;
        }
        if (this.s0) {
            ((ax.P0.J) C1498a.e(this.r0)).b(this.q0);
            this.s0 = false;
        }
        this.n0 = ax.R0.c.d;
        this.t0 = true;
    }

    @Override // ax.P0.H
    public boolean h0() {
        I2();
        return this.J;
    }

    @Override // ax.P0.H
    public ax.P0.T i0() {
        I2();
        ax.P0.T tC = this.i.c();
        return this.N ? tC.I().L(this.O).F() : tC;
    }

    public boolean i2() {
        I2();
        return this.x0.p;
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public boolean isScrubbingModeEnabled() {
        I2();
        return this.N;
    }

    @Override // ax.P0.H
    public boolean j() {
        I2();
        return this.x0.b.b();
    }

    @Override // ax.P0.H
    public void k(ax.P0.H.d dVar) {
        I2();
        this.m.j((ax.P0.H.d) C1498a.e(dVar));
    }

    @Override // ax.P0.H
    public long k0() {
        I2();
        if (this.x0.a.q()) {
            return this.A0;
        }
        J0 j0 = this.x0;
        if (j0.k.d != j0.b.d) {
            return j0.a.n(Y(), this.a).d();
        }
        long j = j0.q;
        if (this.x0.k.b()) {
            J0 j1 = this.x0;
            ax.P0.N.b bVarH = j1.a.h(j1.k.a, this.o);
            long jF = bVarH.f(this.x0.k.b);
            j = jF == Long.MIN_VALUE ? bVarH.d : jF;
        }
        J0 j2 = this.x0;
        return ax.S0.d0.E1(q2(j2.a, j2.k, j));
    }

    @Override // ax.P0.H
    public long l() {
        I2();
        return ax.S0.d0.E1(this.x0.r);
    }

    @Override // ax.P0.H
    public ax.P0.H.b n() {
        I2();
        return this.U;
    }

    @Override // ax.P0.H
    public void n0(TextureView textureView) {
        I2();
        if (textureView == null) {
            P1();
            return;
        }
        t2();
        this.e0 = textureView;
        if (textureView.getSurfaceTextureListener() != null) {
            C1517u.h("ExoPlayerImpl", "Replacing existing SurfaceTextureListener.");
        }
        textureView.setSurfaceTextureListener(this.z);
        SurfaceTexture surfaceTexture = textureView.isAvailable() ? textureView.getSurfaceTexture() : null;
        if (surfaceTexture == null) {
            A2(null);
            m2(0, 0);
        } else {
            z2(surfaceTexture);
            m2(textureView.getWidth(), textureView.getHeight());
        }
    }

    @Override // ax.P0.H
    public boolean o() {
        I2();
        return this.x0.l;
    }

    @Override // ax.P0.H
    public int o0() {
        I2();
        return this.I;
    }

    @Override // ax.P0.H
    public void p(final ax.P0.T t) {
        ax.P0.T tM1;
        I2();
        if (this.i.h()) {
            ax.P0.T tI0 = i0();
            if (this.N) {
                this.O = t.E;
                tM1 = M1(t, this.P.a);
            } else {
                tM1 = t;
            }
            if (!tM1.equals(this.i.c())) {
                this.i.m(tM1);
            }
            if (tI0.equals(t)) {
                return;
            }
            this.m.k(19, new C1516t.a() { // from class: androidx.media3.exoplayer.I
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).b0(t);
                }
            });
        }
    }

    @Override // ax.P0.H
    public ax.P0.A q0() {
        I2();
        return this.V;
    }

    @Override // ax.P0.H
    public long r0() {
        I2();
        return ax.S0.d0.E1(Z1(this.x0));
    }

    @Override // ax.P0.H
    public void s(final boolean z) {
        I2();
        if (this.J != z) {
            this.J = z;
            this.l.E1(z);
            this.m.h(9, new C1516t.a() { // from class: androidx.media3.exoplayer.M
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).Z(z);
                }
            });
            D2();
            this.m.f();
        }
    }

    @Override // ax.P0.H
    public long s0() {
        I2();
        return this.v;
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void setImageOutput(ImageOutput imageOutput) {
        I2();
        u2(4, 15, imageOutput);
    }

    @Override // androidx.media3.exoplayer.ExoPlayer
    public void setScrubbingModeEnabled(boolean z) {
        ax.P0.T tF;
        I2();
        if (z == this.N) {
            return;
        }
        this.N = z;
        if (!this.P.a.isEmpty() && this.i.h()) {
            ax.P0.T tC = this.i.c();
            if (z) {
                this.O = tC.E;
                tF = M1(tC, this.P.a);
            } else {
                tF = tC.I().L(this.O).F();
                this.O = null;
            }
            if (!tF.equals(tC)) {
                this.i.m(tF);
            }
        }
        this.l.y1(z);
        n2();
    }

    @Override // ax.P0.H
    public void stop() {
        I2();
        C2(null);
        this.n0 = new ax.R0.c(AbstractC1656z.y(), this.x0.s);
    }

    @Override // ax.P0.H
    public long t() {
        I2();
        return this.x;
    }

    @Override // ax.P0.H
    public int w() {
        I2();
        if (this.x0.a.q()) {
            return this.z0;
        }
        J0 j0 = this.x0;
        return j0.a.b(j0.b.a);
    }

    public void w2(List<ax.p132i1.F> list, boolean z) {
        I2();
        x2(list, -1, -9223372036854775807L, z);
    }

    @Override // ax.P0.H
    public void x(TextureView textureView) {
        I2();
        if (textureView == null || textureView != this.e0) {
            return;
        }
        P1();
    }

    @Override // ax.P0.H
    public ax.P0.a0 y() {
        I2();
        return this.v0;
    }

    @Override // ax.P0.H
    public void z(final C1357c c1357c, boolean z) {
        I2();
        if (this.t0) {
            return;
        }
        if (!Objects.equals(this.k0, c1357c)) {
            this.k0 = c1357c;
            u2(1, 3, c1357c);
            V0 v0 = this.C;
            if (v0 != null) {
                v0.o(c1357c.b());
            }
            this.m.h(20, new C1516t.a() { // from class: androidx.media3.exoplayer.K
                @Override // ax.S0.C1516t.a
                public final void invoke(Object obj) {
                    ((ax.P0.H.d) obj).s0(c1357c);
                }
            });
        }
        this.l.j1(this.k0, z);
        this.m.f();
    }

    @Override // ax.P0.AbstractC1362h
    protected void z0(int i, long j, int i2, boolean z) {
        I2();
        if (i == -1) {
            return;
        }
        C1498a.a(i >= 0);
        ax.P0.N n = this.x0.a;
        if (n.q() || i < n.p()) {
            this.s.Y();
            this.K++;
            if (j()) {
                C1517u.h("ExoPlayerImpl", "seekTo ignored because an ad is playing");
                C0635n0.e eVar = new C0635n0.e(this.x0);
                eVar.b(1);
                this.k.a(eVar);
                return;
            }
            J0 j0J2 = this.x0;
            int i3 = j0J2.e;
            if (i3 == 3 || (i3 == 4 && !n.q())) {
                j0J2 = j2(this.x0, 2);
            }
            int iY = Y();
            J0 j0K2 = k2(j0J2, n, l2(n, i, j));
            this.l.a1(n, i, ax.S0.d0.a1(j));
            F2(j0K2, 0, true, 1, Z1(j0K2), iY, z);
        }
    }
}
