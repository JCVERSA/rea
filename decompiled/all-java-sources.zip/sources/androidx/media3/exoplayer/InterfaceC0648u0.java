package androidx.media3.exoplayer;

/* JADX INFO: renamed from: androidx.media3.exoplayer.u0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
interface InterfaceC0648u0 {
    Object t0();

    ax.P0.N u0();
}
