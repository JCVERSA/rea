package androidx.media3.exoplayer;

import ax.P0.C1375v;

/* JADX INFO: loaded from: classes.dex */
public interface N0 {

    public interface a {
        void a(M0 m0);
    }

    int A() throws C0643s;

    int b(C1375v c1375v) throws C0643s;

    String getName();

    int j();

    void l();

    void v(a aVar);
}
