package androidx.media3.exoplayer;

import ax.S0.C1498a;
import ax.S0.InterfaceC1505h;

/* JADX INFO: renamed from: androidx.media3.exoplayer.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
final class C0628k implements ax.Y0.S {
    private final a X;
    private M0 Y;
    private ax.Y0.S Z;
    private boolean k0 = true;
    private boolean l0;
    private final ax.Y0.a0 q;

    /* JADX INFO: renamed from: androidx.media3.exoplayer.k$a */
    public interface a {
        void t(ax.P0.G g);
    }

    public C0628k(a aVar, InterfaceC1505h interfaceC1505h) {
        this.X = aVar;
        this.q = new ax.Y0.a0(interfaceC1505h);
    }

    private boolean e(boolean z) {
        M0 m0 = this.Y;
        if (m0 == null || m0.c()) {
            return true;
        }
        if (z && this.Y.getState() != 2) {
            return true;
        }
        if (this.Y.isReady()) {
            return false;
        }
        return z || this.Y.n();
    }

    private void j(boolean z) {
        if (e(z)) {
            this.k0 = true;
            if (this.l0) {
                this.q.b();
                return;
            }
            return;
        }
        ax.Y0.S s = (ax.Y0.S) C1498a.e(this.Z);
        long jW = s.w();
        if (this.k0) {
            if (jW < this.q.w()) {
                this.q.c();
                return;
            } else {
                this.k0 = false;
                if (this.l0) {
                    this.q.b();
                }
            }
        }
        this.q.a(jW);
        ax.P0.G gF = s.f();
        if (gF.equals(this.q.f())) {
            return;
        }
        this.q.d(gF);
        this.X.t(gF);
    }

    public void a(M0 m0) {
        if (m0 == this.Y) {
            this.Z = null;
            this.Y = null;
            this.k0 = true;
        }
    }

    public void b(M0 m0) throws C0643s {
        ax.Y0.S s;
        ax.Y0.S sH = m0.H();
        if (sH == null || sH == (s = this.Z)) {
            return;
        }
        if (s != null) {
            throw C0643s.f(new IllegalStateException("Multiple renderer media clocks enabled."), 1000);
        }
        this.Z = sH;
        this.Y = m0;
        sH.d(this.q.f());
    }

    public void c(long j) {
        this.q.a(j);
    }

    @Override // ax.Y0.S
    public void d(ax.P0.G g) {
        ax.Y0.S s = this.Z;
        if (s != null) {
            s.d(g);
            g = this.Z.f();
        }
        this.q.d(g);
    }

    @Override // ax.Y0.S
    public ax.P0.G f() {
        ax.Y0.S s = this.Z;
        return s != null ? s.f() : this.q.f();
    }

    public void g() {
        this.l0 = true;
        this.q.b();
    }

    public void h() {
        this.l0 = false;
        this.q.c();
    }

    public long i(boolean z) {
        j(z);
        return w();
    }

    @Override // ax.Y0.S
    public long w() {
        return this.k0 ? this.q.w() : ((ax.Y0.S) C1498a.e(this.Z)).w();
    }

    @Override // ax.Y0.S
    public boolean z() {
        return this.k0 ? this.q.z() : ((ax.Y0.S) C1498a.e(this.Z)).z();
    }
}
