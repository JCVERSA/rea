package androidx.media3.exoplayer;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import ax.P0.C1375v;
import ax.S0.C1498a;
import java.io.IOException;

/* JADX INFO: renamed from: androidx.media3.exoplayer.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0643s extends ax.P0.F {
    public final int p0;
    public final String q0;
    public final int r0;
    public final C1375v s0;
    public final int t0;
    public final ax.i1.F.b u0;
    final boolean v0;

    private C0643s(int i, Throwable th, int i2) {
        this(i, th, null, i2, null, -1, null, 4, null, false);
    }

    private C0643s(int i, Throwable th, String str, int i2, String str2, int i3, C1375v c1375v, int i4, ax.i1.F.b bVar, boolean z) {
        this(g(i, str, str2, i3, c1375v, i4), th, i2, i, str2, i3, c1375v, i4, bVar, SystemClock.elapsedRealtime(), z);
    }

    private C0643s(String str, Throwable th, int i, int i2, String str2, int i3, C1375v c1375v, int i4, ax.i1.F.b bVar, long j, boolean z) {
        super(str, th, i, Bundle.EMPTY, j);
        C1498a.a(!z || i2 == 1);
        C1498a.a(th != null || i2 == 3);
        this.p0 = i2;
        this.q0 = str2;
        this.r0 = i3;
        this.s0 = c1375v;
        this.t0 = i4;
        this.u0 = bVar;
        this.v0 = z;
    }

    public static C0643s d(Throwable th, String str, int i, C1375v c1375v, int i2, ax.i1.F.b bVar, boolean z, int i3) {
        return new C0643s(1, th, null, i3, str, i, c1375v, c1375v == null ? 4 : i2, bVar, z);
    }

    public static C0643s e(IOException iOException, int i) {
        return new C0643s(0, iOException, i);
    }

    public static C0643s f(RuntimeException runtimeException, int i) {
        return new C0643s(2, runtimeException, i);
    }

    private static String g(int i, String str, String str2, int i2, C1375v c1375v, int i3) {
        String str3;
        if (i == 0) {
            str3 = "Source error";
        } else if (i != 1) {
            str3 = i != 3 ? "Unexpected runtime error" : "Remote error";
        } else {
            str3 = str2 + " error, index=" + i2 + ", format=" + c1375v + ", format_supported=" + ax.S0.d0.d0(i3);
        }
        if (TextUtils.isEmpty(str)) {
            return str3;
        }
        return str3 + ": " + str;
    }

    C0643s c(ax.i1.F.b bVar) {
        return new C0643s((String) ax.S0.d0.i(getMessage()), getCause(), this.q, this.p0, this.q0, this.r0, this.s0, this.t0, bVar, this.X, this.v0);
    }

    public Exception h() {
        C1498a.g(this.p0 == 1);
        return (Exception) C1498a.e(getCause());
    }

    public IOException i() {
        C1498a.g(this.p0 == 0);
        return (IOException) C1498a.e(getCause());
    }
}
