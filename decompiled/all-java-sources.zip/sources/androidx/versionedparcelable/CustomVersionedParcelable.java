package androidx.versionedparcelable;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements ax.p128j1.b {
}
