package androidx.versionedparcelable;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements ax.p405z2.b {
}
