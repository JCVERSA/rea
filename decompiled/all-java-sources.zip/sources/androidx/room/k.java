package androidx.room;

import java.io.File;

/* JADX INFO: loaded from: classes.dex */
class k implements ax.p030c1.c.InterfaceC0297c {
    private final String a;
    private final File b;
    private final ax.p030c1.c.InterfaceC0297c c;

    k(String str, File file, ax.p030c1.c.InterfaceC0297c interfaceC0297c) {
        this.a = str;
        this.b = file;
        this.c = interfaceC0297c;
    }

    @Override // ax.p030c1.c.InterfaceC0297c
    public ax.p030c1.c a(ax.c1.c.b bVar) {
        return new j(bVar.a, this.a, this.b, bVar.c.a, this.c.a(bVar));
    }
}
