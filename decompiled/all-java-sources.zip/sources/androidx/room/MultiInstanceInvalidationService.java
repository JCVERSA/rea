package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import ax.p111gc.t;
import ax.p197m2.j;
import ax.p197m2.k;
import ax.p335uc.l;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class MultiInstanceInvalidationService extends Service {
    private final Map<Integer, String> X = new LinkedHashMap();
    private final RemoteCallbackList<j> Y = new b();
    private final k.a Z = new a();
    private int q;

    public static final class a extends k.a {
        a() {
        }

        @Override // ax.p197m2.k
        public int k5(j jVar, String str) {
            l.f(jVar, "callback");
            int i = 0;
            if (str == null) {
                return 0;
            }
            RemoteCallbackList<j> remoteCallbackListA = MultiInstanceInvalidationService.this.a();
            MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
            synchronized (remoteCallbackListA) {
                try {
                    multiInstanceInvalidationService.d(multiInstanceInvalidationService.c() + 1);
                    int iC = multiInstanceInvalidationService.c();
                    if (multiInstanceInvalidationService.a().register(jVar, Integer.valueOf(iC))) {
                        multiInstanceInvalidationService.b().put(Integer.valueOf(iC), str);
                        i = iC;
                    } else {
                        multiInstanceInvalidationService.d(multiInstanceInvalidationService.c() - 1);
                        multiInstanceInvalidationService.c();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return i;
        }

        @Override // ax.p197m2.k
        public void k7(int i, String[] strArr) {
            l.f(strArr, "tables");
            RemoteCallbackList<j> remoteCallbackListA = MultiInstanceInvalidationService.this.a();
            MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
            synchronized (remoteCallbackListA) {
                try {
                    String str = multiInstanceInvalidationService.b().get(Integer.valueOf(i));
                    if (str == null) {
                        Log.w("ROOM", "Remote invalidation client ID not registered");
                        return;
                    }
                    int iBeginBroadcast = multiInstanceInvalidationService.a().beginBroadcast();
                    for (int i2 = 0; i2 < iBeginBroadcast; i2++) {
                        try {
                            Object broadcastCookie = multiInstanceInvalidationService.a().getBroadcastCookie(i2);
                            l.d(broadcastCookie, "null cannot be cast to non-null type kotlin.Int");
                            Integer num = (Integer) broadcastCookie;
                            int iIntValue = num.intValue();
                            String str2 = multiInstanceInvalidationService.b().get(num);
                            if (i != iIntValue && l.a(str, str2)) {
                                try {
                                    ((j) multiInstanceInvalidationService.a().getBroadcastItem(i2)).h2(strArr);
                                } catch (RemoteException e) {
                                    Log.w("ROOM", "Error invoking a remote callback", e);
                                }
                            }
                        } catch (Throwable th) {
                            multiInstanceInvalidationService.a().finishBroadcast();
                            throw th;
                        }
                    }
                    multiInstanceInvalidationService.a().finishBroadcast();
                    t tVar = t.a;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // ax.p197m2.k
        public void p2(j jVar, int i) {
            l.f(jVar, "callback");
            RemoteCallbackList<j> remoteCallbackListA = MultiInstanceInvalidationService.this.a();
            MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
            synchronized (remoteCallbackListA) {
                multiInstanceInvalidationService.a().unregister(jVar);
                multiInstanceInvalidationService.b().remove(Integer.valueOf(i));
            }
        }
    }

    public static final class b extends RemoteCallbackList<j> {
        b() {
        }

        @Override // android.os.RemoteCallbackList
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onCallbackDied(j jVar, Object obj) {
            l.f(jVar, "callback");
            l.f(obj, "cookie");
            MultiInstanceInvalidationService.this.b().remove((Integer) obj);
        }
    }

    public final RemoteCallbackList<j> a() {
        return this.Y;
    }

    public final Map<Integer, String> b() {
        return this.X;
    }

    public final int c() {
        return this.q;
    }

    public final void d(int i) {
        this.q = i;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        l.f(intent, "intent");
        return this.Z;
    }
}
