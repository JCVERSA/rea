package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class MultiInstanceInvalidationService extends Service {
    int q = 0;
    final HashMap<Integer, String> X = new HashMap<>();
    final RemoteCallbackList<androidx.room.b> Y = new a();
    private final c.a Z = new b();

    class a extends RemoteCallbackList<androidx.room.b> {
        a() {
        }

        @Override // android.os.RemoteCallbackList
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onCallbackDied(androidx.room.b bVar, Object obj) {
            HashMap<Integer, String> map = MultiInstanceInvalidationService.this.X;
            Integer num = (Integer) obj;
            num.intValue();
            map.remove(num);
        }
    }

    class b extends c.a {
        b() {
        }

        @Override // androidx.room.c
        public int I2(androidx.room.b bVar, String str) {
            if (str == null) {
                return 0;
            }
            synchronized (MultiInstanceInvalidationService.this.Y) {
                try {
                    MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
                    int i = multiInstanceInvalidationService.q + 1;
                    multiInstanceInvalidationService.q = i;
                    if (multiInstanceInvalidationService.Y.register(bVar, Integer.valueOf(i))) {
                        MultiInstanceInvalidationService.this.X.put(Integer.valueOf(i), str);
                        return i;
                    }
                    MultiInstanceInvalidationService.this.q--;
                    return 0;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // androidx.room.c
        public void L6(int i, String[] strArr) {
            synchronized (MultiInstanceInvalidationService.this.Y) {
                try {
                    String str = MultiInstanceInvalidationService.this.X.get(Integer.valueOf(i));
                    if (str == null) {
                        Log.w("ROOM", "Remote invalidation client ID not registered");
                        return;
                    }
                    int iBeginBroadcast = MultiInstanceInvalidationService.this.Y.beginBroadcast();
                    for (int i2 = 0; i2 < iBeginBroadcast; i2++) {
                        try {
                            Integer num = (Integer) MultiInstanceInvalidationService.this.Y.getBroadcastCookie(i2);
                            int iIntValue = num.intValue();
                            String str2 = MultiInstanceInvalidationService.this.X.get(num);
                            if (i != iIntValue && str.equals(str2)) {
                                try {
                                    ((androidx.room.b) MultiInstanceInvalidationService.this.Y.getBroadcastItem(i2)).e2(strArr);
                                } catch (RemoteException e) {
                                    Log.w("ROOM", "Error invoking a remote callback", e);
                                }
                            }
                        } catch (Throwable th) {
                            MultiInstanceInvalidationService.this.Y.finishBroadcast();
                            throw th;
                        }
                    }
                    MultiInstanceInvalidationService.this.Y.finishBroadcast();
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }

        @Override // androidx.room.c
        public void m7(androidx.room.b bVar, int i) {
            synchronized (MultiInstanceInvalidationService.this.Y) {
                MultiInstanceInvalidationService.this.Y.unregister(bVar);
                MultiInstanceInvalidationService.this.X.remove(Integer.valueOf(i));
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.Z;
    }
}
