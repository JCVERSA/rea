package androidx.room;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import j$.util.concurrent.ConcurrentHashMap;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    @Deprecated
    protected volatile ax.p030c1.b a;
    private Executor b;
    private Executor c;
    private ax.p030c1.c d;
    private boolean f;
    boolean g;

    @Deprecated
    protected List<b> h;
    private final ReentrantReadWriteLock i = new ReentrantReadWriteLock();
    private final ThreadLocal<Integer> j = new ThreadLocal<>();
    private final Map<String, Object> k = new ConcurrentHashMap();
    private final e e = e();

    public static class a<T extends h> {
        private final Class<T> a;
        private final String b;
        private final Context c;
        private ArrayList<b> d;
        private Executor e;
        private Executor f;
        private ax.p030c1.c.InterfaceC0297c g;
        private boolean h;
        private boolean j;
        private boolean l;
        private Set<Integer> n;
        private Set<Integer> o;
        private String p;
        private File q;
        private c i = c.AUTOMATIC;
        private boolean k = true;
        private final d m = new d();

        a(Context context, Class<T> cls, String str) {
            this.c = context;
            this.a = cls;
            this.b = str;
        }

        public a<T> a(b bVar) {
            if (this.d == null) {
                this.d = new ArrayList<>();
            }
            this.d.add(bVar);
            return this;
        }

        public a<T> b(ax.Z0.a... aVarArr) {
            if (this.o == null) {
                this.o = new HashSet();
            }
            for (ax.Z0.a aVar : aVarArr) {
                this.o.add(Integer.valueOf(aVar.a));
                this.o.add(Integer.valueOf(aVar.b));
            }
            this.m.b(aVarArr);
            return this;
        }

        public a<T> c() {
            this.h = true;
            return this;
        }

        @SuppressLint({"RestrictedApi"})
        public T d() {
            Executor executor;
            if (this.c == null) {
                throw new IllegalArgumentException("Cannot provide null context for the database.");
            }
            if (this.a == null) {
                throw new IllegalArgumentException("Must provide an abstract class that extends RoomDatabase");
            }
            Executor executor2 = this.e;
            if (executor2 == null && this.f == null) {
                Executor executorF = ax.p294v.c.f();
                this.f = executorF;
                this.e = executorF;
            } else if (executor2 != null && this.f == null) {
                this.f = executor2;
            } else if (executor2 == null && (executor = this.f) != null) {
                this.e = executor;
            }
            Set<Integer> set = this.o;
            if (set != null && this.n != null) {
                for (Integer num : set) {
                    if (this.n.contains(num)) {
                        throw new IllegalArgumentException("Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: " + num);
                    }
                }
            }
            if (this.g == null) {
                this.g = new ax.p044d1.c();
            }
            String str = this.p;
            if (str != null || this.q != null) {
                if (this.b == null) {
                    throw new IllegalArgumentException("Cannot create from asset or file for an in-memory database.");
                }
                if (str != null && this.q != null) {
                    throw new IllegalArgumentException("Both createFromAsset() and createFromFile() was called on this Builder but the database can only be created using one of the two configurations.");
                }
                this.g = new k(str, this.q, this.g);
            }
            Context context = this.c;
            androidx.room.a aVar = new androidx.room.a(context, this.b, this.g, this.m, this.d, this.h, this.i.h(context), this.e, this.f, this.j, this.k, this.l, this.n, this.p, this.q);
            T t = (T) g.b(this.a, "_Impl");
            t.l(aVar);
            return t;
        }

        public a<T> e() {
            this.k = false;
            this.l = true;
            return this;
        }

        public a<T> f(ax.p030c1.c.InterfaceC0297c interfaceC0297c) {
            this.g = interfaceC0297c;
            return this;
        }

        public a<T> g(Executor executor) {
            this.e = executor;
            return this;
        }
    }

    public enum c {
        AUTOMATIC,
        TRUNCATE,
        WRITE_AHEAD_LOGGING;

        private static boolean g(ActivityManager activityManager) {
            return activityManager.isLowRamDevice();
        }

        @SuppressLint({"NewApi"})
        c h(Context context) {
            if (this != AUTOMATIC) {
                return this;
            }
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            return (activityManager == null || g(activityManager)) ? TRUNCATE : WRITE_AHEAD_LOGGING;
        }
    }

    public static class d {
        private HashMap<Integer, TreeMap<Integer, ax.Z0.a>> a = new HashMap<>();

        private void a(ax.Z0.a aVar) {
            int i = aVar.a;
            int i2 = aVar.b;
            TreeMap<Integer, ax.Z0.a> treeMap = this.a.get(Integer.valueOf(i));
            if (treeMap == null) {
                treeMap = new TreeMap<>();
                this.a.put(Integer.valueOf(i), treeMap);
            }
            ax.Z0.a aVar2 = treeMap.get(Integer.valueOf(i2));
            if (aVar2 != null) {
                Log.w("ROOM", "Overriding migration " + aVar2 + " with " + aVar);
            }
            treeMap.put(Integer.valueOf(i2), aVar);
        }

        /* JADX WARN: Code duplicated, block: B:10:0x0019  */
        /* JADX WARN: Code duplicated, block: B:11:0x001e  */
        /* JADX WARN: Code duplicated, block: B:15:0x002c  */
        /* JADX WARN: Code duplicated, block: B:26:0x0050 A[LOOP:0: B:2:0x0000->B:26:0x0050, LOOP_END] */
        /* JADX WARN: Code duplicated, block: B:30:0x0016 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:31:0x004f A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:32:0x003d A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:34:0x004a A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:36:0x0038 A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:9:0x0017 A[DONT_INVERT] */
        private List<ax.Z0.a> d(List<ax.Z0.a> list, boolean z, int i, int i2) {
            TreeMap<Integer, ax.Z0.a> treeMap;
            Set<Integer> setKeySet;
            Iterator<Integer> it;
            int iIntValue;
            boolean z2;
            while (true) {
                if (z) {
                    if (i >= i2) {
                        break;
                    }
                    treeMap = this.a.get(Integer.valueOf(i));
                    if (treeMap == null) {
                        return null;
                    }
                    if (z) {
                        setKeySet = treeMap.descendingKeySet();
                    } else {
                        setKeySet = treeMap.keySet();
                    }
                    it = setKeySet.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            iIntValue = i;
                            z2 = false;
                            break;
                        }
                        Integer next = it.next();
                        iIntValue = next.intValue();
                        if (!z) {
                            if (iIntValue >= i2 && iIntValue < i) {
                                list.add(treeMap.get(next));
                                z2 = true;
                                break;
                            }
                        } else if (iIntValue <= i2 && iIntValue > i) {
                            list.add(treeMap.get(next));
                            z2 = true;
                            break;
                        }
                    }
                    if (!z2) {
                        return null;
                    }
                    i = iIntValue;
                } else {
                    if (i <= i2) {
                        break;
                    }
                    treeMap = this.a.get(Integer.valueOf(i));
                    if (treeMap == null) {
                        return null;
                    }
                    if (z) {
                        setKeySet = treeMap.descendingKeySet();
                    } else {
                        setKeySet = treeMap.keySet();
                    }
                    it = setKeySet.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            iIntValue = i;
                            z2 = false;
                            break;
                        }
                        Integer next2 = it.next();
                        iIntValue = next2.intValue();
                        if (!z) {
                            if (iIntValue <= i2) {
                                continue;
                            }
                        } else if (iIntValue >= i2) {
                            continue;
                        }
                    }
                    if (!z2) {
                        return null;
                    }
                    i = iIntValue;
                }
            }
            return list;
        }

        public void b(ax.Z0.a... aVarArr) {
            for (ax.Z0.a aVar : aVarArr) {
                a(aVar);
            }
        }

        public List<ax.Z0.a> c(int i, int i2) {
            if (i == i2) {
                return Collections.emptyList();
            }
            return d(new ArrayList(), i2 > i, i, i2);
        }
    }

    private static boolean n() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }

    public void a() {
        if (!this.f && n()) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
        }
    }

    public void b() {
        if (!k() && this.j.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
    }

    @Deprecated
    public void c() {
        a();
        ax.p030c1.b bVarN0 = this.d.n0();
        this.e.m(bVarN0);
        bVarN0.u();
    }

    public ax.p030c1.f d(String str) {
        a();
        b();
        return this.d.n0().P(str);
    }

    protected abstract e e();

    protected abstract ax.p030c1.c f(androidx.room.a aVar);

    @Deprecated
    public void g() {
        this.d.n0().s0();
        if (k()) {
            return;
        }
        this.e.f();
    }

    Lock h() {
        return this.i.readLock();
    }

    public ax.p030c1.c i() {
        return this.d;
    }

    public Executor j() {
        return this.b;
    }

    public boolean k() {
        return this.d.n0().I0();
    }

    public void l(androidx.room.a aVar) {
        ax.p030c1.c cVarF = f(aVar);
        this.d = cVarF;
        if (cVarF instanceof j) {
            ((j) cVarF).d(aVar);
        }
        boolean z = aVar.g == c.WRITE_AHEAD_LOGGING;
        this.d.setWriteAheadLoggingEnabled(z);
        this.h = aVar.e;
        this.b = aVar.h;
        this.c = new l(aVar.i);
        this.f = aVar.f;
        this.g = z;
        if (aVar.j) {
            this.e.i(aVar.b, aVar.c);
        }
    }

    protected void m(ax.p030c1.b bVar) {
        this.e.d(bVar);
    }

    public boolean o() {
        ax.p030c1.b bVar = this.a;
        return bVar != null && bVar.isOpen();
    }

    public Cursor p(ax.p030c1.e eVar) {
        return q(eVar, null);
    }

    public Cursor q(ax.p030c1.e eVar, CancellationSignal cancellationSignal) {
        a();
        b();
        return cancellationSignal != null ? this.d.n0().z0(eVar, cancellationSignal) : this.d.n0().S0(eVar);
    }

    @Deprecated
    public void r() {
        this.d.n0().f0();
    }

    public static abstract class b {
        public void a(ax.p030c1.b bVar) {
        }

        public void b(ax.p030c1.b bVar) {
        }

        public void c(ax.p030c1.b bVar) {
        }
    }
}
