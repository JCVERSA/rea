package androidx.room;

import android.content.Context;
import android.util.Log;
import j$.nio.channels.DesugarChannels;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

/* JADX INFO: loaded from: classes.dex */
class j implements ax.p030c1.c {
    private final String X;
    private final File Y;
    private final int Z;
    private final ax.p030c1.c h0;
    private a i0;
    private boolean j0;
    private final Context q;

    j(Context context, String str, File file, int i, ax.p030c1.c cVar) {
        this.q = context;
        this.X = str;
        this.Y = file;
        this.Z = i;
        this.h0 = cVar;
    }

    private void a(File file) throws IOException {
        ReadableByteChannel readableByteChannelConvertMaybeLegacyFileChannelFromLibrary;
        if (this.X != null) {
            readableByteChannelConvertMaybeLegacyFileChannelFromLibrary = Channels.newChannel(this.q.getAssets().open(this.X));
        } else {
            if (this.Y == null) {
                throw new IllegalStateException("copyFromAssetPath and copyFromFile == null!");
            }
            readableByteChannelConvertMaybeLegacyFileChannelFromLibrary = DesugarChannels.convertMaybeLegacyFileChannelFromLibrary(new FileInputStream(this.Y).getChannel());
        }
        File fileCreateTempFile = File.createTempFile("room-copy-helper", ".tmp", this.q.getCacheDir());
        fileCreateTempFile.deleteOnExit();
        ax.p002a1.d.a(readableByteChannelConvertMaybeLegacyFileChannelFromLibrary, DesugarChannels.convertMaybeLegacyFileChannelFromLibrary(new FileOutputStream(fileCreateTempFile).getChannel()));
        File parentFile = file.getParentFile();
        if (parentFile != null && !parentFile.exists() && !parentFile.mkdirs()) {
            throw new IOException("Failed to create directories for " + file.getAbsolutePath());
        }
        if (fileCreateTempFile.renameTo(file)) {
            return;
        }
        throw new IOException("Failed to move intermediate file (" + fileCreateTempFile.getAbsolutePath() + ") to destination (" + file.getAbsolutePath() + ").");
    }

    private void f() {
        String databaseName = getDatabaseName();
        File databasePath = this.q.getDatabasePath(databaseName);
        a aVar = this.i0;
        ax.p002a1.a aVar2 = new ax.p002a1.a(databaseName, this.q.getFilesDir(), aVar == null || aVar.j);
        try {
            aVar2.b();
            if (!databasePath.exists()) {
                try {
                    a(databasePath);
                    aVar2.c();
                    return;
                } catch (IOException e) {
                    throw new RuntimeException("Unable to copy database file.", e);
                }
            }
            if (this.i0 == null) {
                aVar2.c();
                return;
            }
            try {
                int iC = ax.p002a1.c.c(databasePath);
                int i = this.Z;
                if (iC == i) {
                    aVar2.c();
                    return;
                }
                if (this.i0.a(iC, i)) {
                    aVar2.c();
                    return;
                }
                if (this.q.deleteDatabase(databaseName)) {
                    try {
                        a(databasePath);
                    } catch (IOException e2) {
                        Log.w("ROOM", "Unable to copy database file.", e2);
                    }
                } else {
                    Log.w("ROOM", "Failed to delete database file (" + databaseName + ") for a copy destructive migration.");
                }
                aVar2.c();
                return;
            } catch (IOException e3) {
                Log.w("ROOM", "Unable to read database version.", e3);
                aVar2.c();
                return;
            }
        } catch (Throwable th) {
            aVar2.c();
            throw th;
        }
        aVar2.c();
        throw th;
    }

    @Override // ax.p030c1.c, java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() {
        this.h0.close();
        this.j0 = false;
    }

    void d(a aVar) {
        this.i0 = aVar;
    }

    @Override // ax.p030c1.c
    public String getDatabaseName() {
        return this.h0.getDatabaseName();
    }

    @Override // ax.p030c1.c
    public synchronized ax.p030c1.b n0() {
        try {
            if (!this.j0) {
                f();
                this.j0 = true;
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.h0.n0();
    }

    @Override // ax.p030c1.c
    public void setWriteAheadLoggingEnabled(boolean z) {
        this.h0.setWriteAheadLoggingEnabled(z);
    }
}
