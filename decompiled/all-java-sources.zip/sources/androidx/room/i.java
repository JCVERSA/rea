package androidx.room;

import android.database.Cursor;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class i extends ax.c1.c.a {
    private androidx.room.a b;
    private final a c;
    private final String d;
    private final String e;

    public static abstract class a {
        public final int a;

        public a(int i) {
            this.a = i;
        }

        protected abstract void a(ax.p030c1.b bVar);

        protected abstract void b(ax.p030c1.b bVar);

        protected abstract void c(ax.p030c1.b bVar);

        protected abstract void d(ax.p030c1.b bVar);

        protected abstract void e(ax.p030c1.b bVar);

        protected abstract void f(ax.p030c1.b bVar);

        protected abstract b g(ax.p030c1.b bVar);
    }

    public static class b {
        public final boolean a;
        public final String b;

        public b(boolean z, String str) {
            this.a = z;
            this.b = str;
        }
    }

    public i(androidx.room.a aVar, a aVar2, String str, String str2) {
        super(aVar2.a);
        this.b = aVar;
        this.c = aVar2;
        this.d = str;
        this.e = str2;
    }

    private void h(ax.p030c1.b bVar) {
        if (!k(bVar)) {
            b bVarG = this.c.g(bVar);
            if (bVarG.a) {
                this.c.e(bVar);
                l(bVar);
                return;
            } else {
                throw new IllegalStateException("Pre-packaged database has an invalid schema: " + bVarG.b);
            }
        }
        Cursor cursorS0 = bVar.S0(new ax.p030c1.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
        try {
            String string = cursorS0.moveToFirst() ? cursorS0.getString(0) : null;
            cursorS0.close();
            if (!this.d.equals(string) && !this.e.equals(string)) {
                throw new IllegalStateException("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.");
            }
        } catch (Throwable th) {
            cursorS0.close();
            throw th;
        }
    }

    private void i(ax.p030c1.b bVar) {
        bVar.I("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
    }

    private static boolean j(ax.p030c1.b bVar) {
        Cursor cursorP0 = bVar.p0("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
        try {
            boolean z = false;
            if (cursorP0.moveToFirst() && cursorP0.getInt(0) == 0) {
                z = true;
            }
            return z;
        } finally {
            cursorP0.close();
        }
    }

    private static boolean k(ax.p030c1.b bVar) {
        Cursor cursorP0 = bVar.p0("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
        try {
            boolean z = false;
            if (cursorP0.moveToFirst() && cursorP0.getInt(0) != 0) {
                z = true;
            }
            return z;
        } finally {
            cursorP0.close();
        }
    }

    private void l(ax.p030c1.b bVar) {
        i(bVar);
        bVar.I(ax.Y0.b.a(this.d));
    }

    @Override // ax.c1.c.a
    public void b(ax.p030c1.b bVar) {
        super.b(bVar);
    }

    @Override // ax.c1.c.a
    public void d(ax.p030c1.b bVar) {
        boolean zJ = j(bVar);
        this.c.a(bVar);
        if (!zJ) {
            b bVarG = this.c.g(bVar);
            if (!bVarG.a) {
                throw new IllegalStateException("Pre-packaged database has an invalid schema: " + bVarG.b);
            }
        }
        l(bVar);
        this.c.c(bVar);
    }

    @Override // ax.c1.c.a
    public void e(ax.p030c1.b bVar, int i, int i2) {
        g(bVar, i, i2);
    }

    @Override // ax.c1.c.a
    public void f(ax.p030c1.b bVar) {
        super.f(bVar);
        h(bVar);
        this.c.d(bVar);
        this.b = null;
    }

    @Override // ax.c1.c.a
    public void g(ax.p030c1.b bVar, int i, int i2) {
        List<ax.Z0.a> listC;
        androidx.room.a aVar = this.b;
        if (aVar == null || (listC = aVar.d.c(i, i2)) == null) {
            androidx.room.a aVar2 = this.b;
            if (aVar2 != null && !aVar2.a(i, i2)) {
                this.c.b(bVar);
                this.c.a(bVar);
                return;
            }
            throw new IllegalStateException("A migration from " + i + " to " + i2 + " was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.");
        }
        this.c.f(bVar);
        Iterator<ax.Z0.a> it = listC.iterator();
        while (it.hasNext()) {
            it.next().a(bVar);
        }
        b bVarG = this.c.g(bVar);
        if (bVarG.a) {
            this.c.e(bVar);
            l(bVar);
        } else {
            throw new IllegalStateException("Migration didn't properly handle: " + bVarG.b);
        }
    }
}
