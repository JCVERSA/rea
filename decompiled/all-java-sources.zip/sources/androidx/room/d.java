package androidx.room;

import androidx.lifecycle.LiveData;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
class d {
    final Set<LiveData> a = Collections.newSetFromMap(new IdentityHashMap());
    private final h b;

    d(h hVar) {
        this.b = hVar;
    }
}
