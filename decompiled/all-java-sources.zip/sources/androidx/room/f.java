package androidx.room;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
class f {
    final Context a;
    final String b;
    int c;
    final androidx.room.e d;
    final androidx.room.e.c e;
    androidx.room.c f;
    final Executor g;
    final androidx.room.b h = new a();
    final AtomicBoolean i = new AtomicBoolean(false);
    final ServiceConnection j;
    final Runnable k;
    final Runnable l;
    private final Runnable m;

    class a extends androidx.room.b.a {

        /* JADX INFO: renamed from: androidx.room.f$a$a, reason: collision with other inner class name */
        class RunnableC0042a implements Runnable {
            final /* synthetic */ String[] q;

            RunnableC0042a(String[] strArr) {
                this.q = strArr;
            }

            @Override // java.lang.Runnable
            public void run() {
                f.this.d.e(this.q);
            }
        }

        a() {
        }

        @Override // androidx.room.b
        public void e2(String[] strArr) {
            f.this.g.execute(new RunnableC0042a(strArr));
        }
    }

    class b implements ServiceConnection {
        b() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            f.this.f = androidx.room.c.a.F0(iBinder);
            f fVar = f.this;
            fVar.g.execute(fVar.k);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            f fVar = f.this;
            fVar.g.execute(fVar.l);
            f.this.f = null;
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                f fVar = f.this;
                androidx.room.c cVar = fVar.f;
                if (cVar != null) {
                    fVar.c = cVar.I2(fVar.h, fVar.b);
                    f fVar2 = f.this;
                    fVar2.d.a(fVar2.e);
                }
            } catch (RemoteException e) {
                Log.w("ROOM", "Cannot register multi-instance invalidation callback", e);
            }
        }
    }

    class d implements Runnable {
        d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            f fVar = f.this;
            fVar.d.g(fVar.e);
        }
    }

    class e implements Runnable {
        e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            f fVar = f.this;
            fVar.d.g(fVar.e);
            try {
                f fVar2 = f.this;
                androidx.room.c cVar = fVar2.f;
                if (cVar != null) {
                    cVar.m7(fVar2.h, fVar2.c);
                }
            } catch (RemoteException e) {
                Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", e);
            }
            f fVar3 = f.this;
            fVar3.a.unbindService(fVar3.j);
        }
    }

    /* JADX INFO: renamed from: androidx.room.f$f, reason: collision with other inner class name */
    class C0043f extends androidx.room.e.c {
        C0043f(String[] strArr) {
            super(strArr);
        }

        @Override // androidx.room.e.c
        boolean a() {
            return true;
        }

        @Override // androidx.room.e.c
        public void b(Set<String> set) {
            if (f.this.i.get()) {
                return;
            }
            try {
                f fVar = f.this;
                androidx.room.c cVar = fVar.f;
                if (cVar != null) {
                    cVar.L6(fVar.c, (String[]) set.toArray(new String[0]));
                }
            } catch (RemoteException e) {
                Log.w("ROOM", "Cannot broadcast invalidation", e);
            }
        }
    }

    f(Context context, String str, androidx.room.e eVar, Executor executor) {
        b bVar = new b();
        this.j = bVar;
        this.k = new c();
        this.l = new d();
        this.m = new e();
        Context applicationContext = context.getApplicationContext();
        this.a = applicationContext;
        this.b = str;
        this.d = eVar;
        this.g = executor;
        this.e = new C0043f((String[]) eVar.a.keySet().toArray(new String[0]));
        applicationContext.bindService(new Intent(applicationContext, (Class<?>) MultiInstanceInvalidationService.class), bVar, 1);
    }
}
