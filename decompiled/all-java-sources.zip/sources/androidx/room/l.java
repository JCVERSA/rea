package androidx.room;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
class l implements Executor {
    private final ArrayDeque<Runnable> X = new ArrayDeque<>();
    private Runnable Y;
    private final Executor q;

    class a implements Runnable {
        final /* synthetic */ Runnable q;

        a(Runnable runnable) {
            this.q = runnable;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.q.run();
            } finally {
                l.this.a();
            }
        }
    }

    l(Executor executor) {
        this.q = executor;
    }

    synchronized void a() {
        Runnable runnablePoll = this.X.poll();
        this.Y = runnablePoll;
        if (runnablePoll != null) {
            this.q.execute(runnablePoll);
        }
    }

    @Override // java.util.concurrent.Executor
    public synchronized void execute(Runnable runnable) {
        this.X.offer(new a(runnable));
        if (this.Y == null) {
            a();
        }
    }
}
