package androidx.viewpager.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import ax.p035c0.C1832a;
import ax.p035c0.C1839d0;
import ax.p035c0.F0;
import ax.p035c0.I;
import ax.p051d0.H;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ViewPager extends ViewGroup {
    static final int[] n1 = {R.attr.layout_gravity};
    private static final Comparator<f> o1 = new a();
    private static final Interpolator p1 = new b();
    private static final n q1 = new n();
    private float A0;
    private int B0;
    private int C0;
    private boolean D0;
    private boolean E0;
    private boolean F0;
    private int G0;
    private boolean H0;
    private boolean I0;
    private int J0;
    private int K0;
    private int L0;
    private float M0;
    private float N0;
    private float O0;
    private float P0;
    private int Q0;
    private VelocityTracker R0;
    private int S0;
    private int T0;
    private int U0;
    private int V0;
    private boolean W0;
    private EdgeEffect X0;
    private EdgeEffect Y0;
    private boolean Z0;
    private boolean a1;
    private boolean b1;
    private int c1;
    private List<j> d1;
    private j e1;
    private j f1;
    private List<i> g1;
    private k h1;
    private int i1;
    private int j1;
    private final ArrayList<f> k0;
    private ArrayList<View> k1;
    private final f l0;
    private final Runnable l1;
    private final Rect m0;
    private int m1;
    androidx.viewpager.widget.a n0;
    int o0;
    private int p0;
    private int q;
    private Parcelable q0;
    private ClassLoader r0;
    private Scroller s0;
    private boolean t0;
    private l u0;
    private int v0;
    private Drawable w0;
    private int x0;
    private int y0;
    private float z0;

    static class a implements Comparator<f> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return fVar.b - fVar2.b;
        }
    }

    static class b implements Interpolator {
        b() {
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager.this.E();
        }
    }

    class d implements I {
        private final Rect a = new Rect();

        d() {
        }

        @Override // ax.p035c0.I
        public F0 a(View view, F0 f0) {
            F0 f0X = C1839d0.X(view, f0);
            if (f0X.o()) {
                return f0X;
            }
            Rect rect = this.a;
            rect.left = f0X.j();
            rect.top = f0X.l();
            rect.right = f0X.k();
            rect.bottom = f0X.i();
            int childCount = ViewPager.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                F0 f0I = C1839d0.i(ViewPager.this.getChildAt(i), f0X);
                rect.left = Math.min(f0I.j(), rect.left);
                rect.top = Math.min(f0I.l(), rect.top);
                rect.right = Math.min(f0I.k(), rect.right);
                rect.bottom = Math.min(f0I.i(), rect.bottom);
            }
            return f0X.p(rect.left, rect.top, rect.right, rect.bottom);
        }
    }

    @Target({ElementType.TYPE})
    @Inherited
    @Retention(RetentionPolicy.RUNTIME)
    public @interface e {
    }

    static class f {
        Object a;
        int b;
        boolean c;
        float d;
        float e;

        f() {
        }
    }

    public static class g extends ViewGroup.LayoutParams {
        public boolean a;
        public int b;
        float c;
        boolean d;
        int e;
        int f;

        public g() {
            super(-1, -1);
            this.c = 0.0f;
        }

        public g(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.c = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.n1);
            this.b = typedArrayObtainStyledAttributes.getInteger(0, 48);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    class h extends C1832a {
        h() {
        }

        private boolean n() {
            androidx.viewpager.widget.a aVar = ViewPager.this.n0;
            return aVar != null && aVar.e() > 1;
        }

        @Override // ax.p035c0.C1832a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            androidx.viewpager.widget.a aVar;
            super.f(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            accessibilityEvent.setScrollable(n());
            if (accessibilityEvent.getEventType() != 4096 || (aVar = ViewPager.this.n0) == null) {
                return;
            }
            accessibilityEvent.setItemCount(aVar.e());
            accessibilityEvent.setFromIndex(ViewPager.this.o0);
            accessibilityEvent.setToIndex(ViewPager.this.o0);
        }

        @Override // ax.p035c0.C1832a
        public void g(View view, H h) {
            super.g(view, h);
            h.m0(ViewPager.class.getName());
            h.G0(n());
            if (ViewPager.this.canScrollHorizontally(1)) {
                h.a(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                h.a(8192);
            }
        }

        @Override // ax.p035c0.C1832a
        public boolean j(View view, int i, Bundle bundle) {
            if (super.j(view, i, bundle)) {
                return true;
            }
            if (i == 4096) {
                if (!ViewPager.this.canScrollHorizontally(1)) {
                    return false;
                }
                ViewPager viewPager = ViewPager.this;
                viewPager.setCurrentItem(viewPager.o0 + 1);
                return true;
            }
            if (i != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                return false;
            }
            ViewPager viewPager2 = ViewPager.this;
            viewPager2.setCurrentItem(viewPager2.o0 - 1);
            return true;
        }
    }

    public interface i {
        void a(ViewPager viewPager, androidx.viewpager.widget.a aVar, androidx.viewpager.widget.a aVar2);
    }

    public interface j {
        void Q(int i);

        void d(int i);

        void o(int i, float f, int i2);
    }

    public interface k {
        void a(View view, float f);
    }

    private class l extends DataSetObserver {
        l() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            ViewPager.this.h();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ViewPager.this.h();
        }
    }

    public static class m extends ax.p163k0.a {
        public static final Parcelable.Creator<m> CREATOR = new a();
        int Y;
        Parcelable Z;
        ClassLoader k0;

        static class a implements Parcelable.ClassLoaderCreator<m> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public m createFromParcel(Parcel parcel) {
                return new m(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public m createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new m(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public m[] newArray(int i) {
                return new m[i];
            }
        }

        m(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? getClass().getClassLoader() : classLoader;
            this.Y = parcel.readInt();
            this.Z = parcel.readParcelable(classLoader);
            this.k0 = classLoader;
        }

        public m(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.Y + "}";
        }

        @Override // ax.p163k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeParcelable(this.Z, i);
        }
    }

    static class n implements Comparator<View> {
        n() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            g gVar = (g) view.getLayoutParams();
            g gVar2 = (g) view2.getLayoutParams();
            boolean z = gVar.a;
            if (z != gVar2.a) {
                return z ? 1 : -1;
            }
            return gVar.e - gVar2.e;
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.k0 = new ArrayList<>();
        this.l0 = new f();
        this.m0 = new Rect();
        this.p0 = -1;
        this.q0 = null;
        this.r0 = null;
        this.z0 = -3.4028235E38f;
        this.A0 = Float.MAX_VALUE;
        this.G0 = 1;
        this.Q0 = -1;
        this.Z0 = true;
        this.a1 = false;
        this.l1 = new c();
        this.m1 = 0;
        v();
    }

    private boolean C(int i2) {
        if (this.k0.size() == 0) {
            if (this.Z0) {
                return false;
            }
            this.b1 = false;
            y(0, 0.0f, 0);
            if (this.b1) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        f fVarT = t();
        int clientWidth = getClientWidth();
        int i3 = this.v0;
        int i4 = clientWidth + i3;
        float f2 = clientWidth;
        int i5 = fVarT.b;
        float f3 = ((i2 / f2) - fVarT.e) / (fVarT.d + (i3 / f2));
        this.b1 = false;
        y(i5, f3, (int) (i4 * f3));
        if (this.b1) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    private boolean D(float f2) {
        boolean z;
        boolean z2;
        float f3 = this.M0 - f2;
        this.M0 = f2;
        float scrollX = getScrollX() + f3;
        float clientWidth = getClientWidth();
        float f4 = this.z0 * clientWidth;
        float f5 = this.A0 * clientWidth;
        boolean z3 = false;
        f fVar = this.k0.get(0);
        ArrayList<f> arrayList = this.k0;
        f fVar2 = arrayList.get(arrayList.size() - 1);
        if (fVar.b != 0) {
            f4 = fVar.e * clientWidth;
            z = false;
        } else {
            z = true;
        }
        if (fVar2.b != this.n0.e() - 1) {
            f5 = fVar2.e * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (scrollX < f4) {
            if (z) {
                this.X0.onPull(Math.abs(f4 - scrollX) / clientWidth);
                z3 = true;
            }
            scrollX = f4;
        } else if (scrollX > f5) {
            if (z2) {
                this.Y0.onPull(Math.abs(scrollX - f5) / clientWidth);
                z3 = true;
            }
            scrollX = f5;
        }
        int i2 = (int) scrollX;
        this.M0 += scrollX - i2;
        scrollTo(i2, getScrollY());
        C(i2);
        return z3;
    }

    private void G(int i2, int i3, int i4, int i5) {
        if (i3 > 0 && !this.k0.isEmpty()) {
            if (!this.s0.isFinished()) {
                this.s0.setFinalX(getCurrentItem() * getClientWidth());
                return;
            } else {
                scrollTo((int) ((getScrollX() / (((i3 - getPaddingLeft()) - getPaddingRight()) + i5)) * (((i2 - getPaddingLeft()) - getPaddingRight()) + i4)), getScrollY());
                return;
            }
        }
        f fVarU = u(this.o0);
        int iMin = (int) ((fVarU != null ? Math.min(fVarU.e, this.A0) : 0.0f) * ((i2 - getPaddingLeft()) - getPaddingRight()));
        if (iMin != getScrollX()) {
            g(false);
            scrollTo(iMin, getScrollY());
        }
    }

    private void H() {
        int i2 = 0;
        while (i2 < getChildCount()) {
            if (!((g) getChildAt(i2).getLayoutParams()).a) {
                removeViewAt(i2);
                i2--;
            }
            i2++;
        }
    }

    private void K(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    private boolean L() {
        this.Q0 = -1;
        o();
        this.X0.onRelease();
        this.Y0.onRelease();
        return this.X0.isFinished() || this.Y0.isFinished();
    }

    private void M(int i2, boolean z, int i3, boolean z2) {
        f fVarU = u(i2);
        int clientWidth = fVarU != null ? (int) (getClientWidth() * Math.max(this.z0, Math.min(fVarU.e, this.A0))) : 0;
        if (z) {
            S(clientWidth, 0, i3);
            if (z2) {
                k(i2);
                return;
            }
            return;
        }
        if (z2) {
            k(i2);
        }
        g(false);
        scrollTo(clientWidth, 0);
        C(clientWidth);
    }

    private void T() {
        if (this.j1 != 0) {
            ArrayList<View> arrayList = this.k1;
            if (arrayList == null) {
                this.k1 = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                this.k1.add(getChildAt(i2));
            }
            Collections.sort(this.k1, q1);
        }
    }

    private void e(f fVar, int i2, f fVar2) {
        int i3;
        int i4;
        f fVar3;
        f fVar4;
        int iE = this.n0.e();
        int clientWidth = getClientWidth();
        float f2 = clientWidth > 0 ? this.v0 / clientWidth : 0.0f;
        if (fVar2 != null) {
            int i5 = fVar2.b;
            int i6 = fVar.b;
            if (i5 < i6) {
                float fH = fVar2.e + fVar2.d + f2;
                int i7 = i5 + 1;
                int i8 = 0;
                while (i7 <= fVar.b && i8 < this.k0.size()) {
                    f fVar5 = this.k0.get(i8);
                    while (true) {
                        fVar4 = fVar5;
                        if (i7 <= fVar4.b || i8 >= this.k0.size() - 1) {
                            break;
                        }
                        i8++;
                        fVar5 = this.k0.get(i8);
                    }
                    while (i7 < fVar4.b) {
                        fH += this.n0.h(i7) + f2;
                        i7++;
                    }
                    fVar4.e = fH;
                    fH += fVar4.d + f2;
                    i7++;
                }
            } else if (i5 > i6) {
                int size = this.k0.size() - 1;
                float fH2 = fVar2.e;
                while (true) {
                    i5--;
                    if (i5 < fVar.b || size < 0) {
                        break;
                    }
                    f fVar6 = this.k0.get(size);
                    while (true) {
                        fVar3 = fVar6;
                        if (i5 >= fVar3.b || size <= 0) {
                            break;
                        }
                        size--;
                        fVar6 = this.k0.get(size);
                    }
                    while (i5 > fVar3.b) {
                        fH2 -= this.n0.h(i5) + f2;
                        i5--;
                    }
                    fH2 -= fVar3.d + f2;
                    fVar3.e = fH2;
                }
            }
        }
        int size2 = this.k0.size();
        float fH3 = fVar.e;
        int i9 = fVar.b;
        int i10 = i9 - 1;
        this.z0 = i9 == 0 ? fH3 : -3.4028235E38f;
        int i11 = iE - 1;
        this.A0 = i9 == i11 ? (fVar.d + fH3) - 1.0f : Float.MAX_VALUE;
        int i12 = i2 - 1;
        while (i12 >= 0) {
            f fVar7 = this.k0.get(i12);
            while (true) {
                i4 = fVar7.b;
                if (i10 <= i4) {
                    break;
                }
                fH3 -= this.n0.h(i10) + f2;
                i10--;
            }
            fH3 -= fVar7.d + f2;
            fVar7.e = fH3;
            if (i4 == 0) {
                this.z0 = fH3;
            }
            i12--;
            i10--;
        }
        float fH4 = fVar.e + fVar.d + f2;
        int i13 = fVar.b + 1;
        int i14 = i2 + 1;
        while (i14 < size2) {
            f fVar8 = this.k0.get(i14);
            while (true) {
                i3 = fVar8.b;
                if (i13 >= i3) {
                    break;
                }
                fH4 += this.n0.h(i13) + f2;
                i13++;
            }
            if (i3 == i11) {
                this.A0 = (fVar8.d + fH4) - 1.0f;
            }
            fVar8.e = fH4;
            fH4 += fVar8.d + f2;
            i14++;
            i13++;
        }
        this.a1 = false;
    }

    private void g(boolean z) {
        boolean z2 = this.m1 == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.s0.isFinished()) {
                this.s0.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.s0.getCurrX();
                int currY = this.s0.getCurrY();
                if (scrollX != currX || scrollY != currY) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        C(currX);
                    }
                }
            }
        }
        this.F0 = false;
        for (int i2 = 0; i2 < this.k0.size(); i2++) {
            f fVar = this.k0.get(i2);
            if (fVar.c) {
                fVar.c = false;
                z2 = true;
            }
        }
        if (z2) {
            if (z) {
                C1839d0.d0(this, this.l1);
            } else {
                this.l1.run();
            }
        }
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private int i(int i2, float f2, int i3, int i4) {
        if (Math.abs(i4) <= this.U0 || Math.abs(i3) <= this.S0) {
            i2 += (int) (f2 + (i2 >= this.o0 ? 0.4f : 0.6f));
        } else if (i3 <= 0) {
            i2++;
        }
        if (this.k0.size() <= 0) {
            return i2;
        }
        f fVar = this.k0.get(0);
        ArrayList<f> arrayList = this.k0;
        return Math.max(fVar.b, Math.min(i2, arrayList.get(arrayList.size() - 1).b));
    }

    private void j(int i2, float f2, int i3) {
        j jVar = this.e1;
        if (jVar != null) {
            jVar.o(i2, f2, i3);
        }
        List<j> list = this.d1;
        if (list != null) {
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                j jVar2 = this.d1.get(i4);
                if (jVar2 != null) {
                    jVar2.o(i2, f2, i3);
                }
            }
        }
        j jVar3 = this.f1;
        if (jVar3 != null) {
            jVar3.o(i2, f2, i3);
        }
    }

    private void k(int i2) {
        j jVar = this.e1;
        if (jVar != null) {
            jVar.Q(i2);
        }
        List<j> list = this.d1;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                j jVar2 = this.d1.get(i3);
                if (jVar2 != null) {
                    jVar2.Q(i2);
                }
            }
        }
        j jVar3 = this.f1;
        if (jVar3 != null) {
            jVar3.Q(i2);
        }
    }

    private void l(int i2) {
        j jVar = this.e1;
        if (jVar != null) {
            jVar.d(i2);
        }
        List<j> list = this.d1;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                j jVar2 = this.d1.get(i3);
                if (jVar2 != null) {
                    jVar2.d(i2);
                }
            }
        }
        j jVar3 = this.f1;
        if (jVar3 != null) {
            jVar3.d(i2);
        }
    }

    private void n(boolean z) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            getChildAt(i2).setLayerType(z ? this.i1 : 0, null);
        }
    }

    private void o() {
        this.H0 = false;
        this.I0 = false;
        VelocityTracker velocityTracker = this.R0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.R0 = null;
        }
    }

    private Rect q(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left += viewGroup.getLeft();
            rect.right += viewGroup.getRight();
            rect.top += viewGroup.getTop();
            rect.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect;
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.E0 != z) {
            this.E0 = z;
        }
    }

    private f t() {
        int i2;
        int clientWidth = getClientWidth();
        float f2 = 0.0f;
        float scrollX = clientWidth > 0 ? getScrollX() / clientWidth : 0.0f;
        float f3 = clientWidth > 0 ? this.v0 / clientWidth : 0.0f;
        f fVar = null;
        float f4 = 0.0f;
        int i3 = -1;
        int i4 = 0;
        boolean z = true;
        while (i4 < this.k0.size()) {
            f fVar2 = this.k0.get(i4);
            if (!z && fVar2.b != (i2 = i3 + 1)) {
                fVar2 = this.l0;
                fVar2.e = f2 + f4 + f3;
                fVar2.b = i2;
                fVar2.d = this.n0.h(i2);
                i4--;
            }
            f fVar3 = fVar2;
            f2 = fVar3.e;
            float f5 = fVar3.d + f2 + f3;
            if (!z && scrollX < f2) {
                break;
            }
            if (scrollX < f5 || i4 == this.k0.size() - 1) {
                return fVar3;
            }
            int i5 = fVar3.b;
            float f6 = fVar3.d;
            i4++;
            i3 = i5;
            f4 = f6;
            fVar = fVar3;
            z = false;
        }
        return fVar;
    }

    private static boolean w(View view) {
        return view.getClass().getAnnotation(e.class) != null;
    }

    private boolean x(float f2, float f3) {
        if (f2 >= this.K0 || f3 <= 0.0f) {
            return f2 > ((float) (getWidth() - this.K0)) && f3 < 0.0f;
        }
        return true;
    }

    private void z(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.Q0) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.M0 = motionEvent.getX(i2);
            this.Q0 = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.R0;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    boolean A() {
        int i2 = this.o0;
        if (i2 <= 0) {
            return false;
        }
        N(i2 - 1, true);
        return true;
    }

    boolean B() {
        androidx.viewpager.widget.a aVar = this.n0;
        if (aVar == null || this.o0 >= aVar.e() - 1) {
            return false;
        }
        N(this.o0 + 1, true);
        return true;
    }

    void E() {
        F(this.o0);
    }

    /* JADX WARN: Code duplicated, block: B:55:0x00cc A[PHI: r7 r10 r15
      0x00cc: PHI (r7v6 int) = (r7v5 int), (r7v4 int), (r7v9 int) binds: [B:64:0x00f0, B:61:0x00da, B:53:0x00c1] A[DONT_GENERATE, DONT_INLINE]
      0x00cc: PHI (r10v9 int) = (r10v1 int), (r10v8 int), (r10v12 int) binds: [B:64:0x00f0, B:61:0x00da, B:53:0x00c1] A[DONT_GENERATE, DONT_INLINE]
      0x00cc: PHI (r15v7 float) = (r15v5 float), (r15v6 float), (r15v4 float) binds: [B:64:0x00f0, B:61:0x00da, B:53:0x00c1] A[DONT_GENERATE, DONT_INLINE]] */
    void F(int i2) {
        f fVarU;
        String hexString;
        f fVarA;
        f fVarS;
        f fVar;
        int i3 = this.o0;
        if (i3 != i2) {
            fVarU = u(i3);
            this.o0 = i2;
        } else {
            fVarU = null;
        }
        if (this.n0 == null) {
            T();
            return;
        }
        if (this.F0) {
            T();
            return;
        }
        if (getWindowToken() == null) {
            return;
        }
        this.n0.t(this);
        int i4 = this.G0;
        int iMax = Math.max(0, this.o0 - i4);
        int iE = this.n0.e();
        int iMin = Math.min(iE - 1, this.o0 + i4);
        if (iE != this.q) {
            try {
                hexString = getResources().getResourceName(getId());
            } catch (Resources.NotFoundException unused) {
                hexString = Integer.toHexString(getId());
            }
            throw new IllegalStateException("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: " + this.q + ", found: " + iE + " Pager id: " + hexString + " Pager class: " + getClass() + " Problematic adapter: " + this.n0.getClass());
        }
        int i5 = 0;
        while (true) {
            if (i5 < this.k0.size()) {
                fVarA = this.k0.get(i5);
                int i6 = fVarA.b;
                int i7 = this.o0;
                if (i6 >= i7) {
                    if (i6 != i7) {
                        break;
                    } else {
                        break;
                    }
                }
                i5++;
            }
            fVarA = null;
            break;
        }
        if (fVarA == null && iE > 0) {
            fVarA = a(this.o0, i5);
        }
        if (fVarA != null) {
            int i8 = i5 - 1;
            f fVar2 = i8 >= 0 ? this.k0.get(i8) : null;
            int clientWidth = getClientWidth();
            float paddingLeft = clientWidth <= 0 ? 0.0f : (2.0f - fVarA.d) + (getPaddingLeft() / clientWidth);
            float f2 = 0.0f;
            for (int i9 = this.o0 - 1; i9 >= 0; i9--) {
                if (f2 < paddingLeft || i9 >= iMax) {
                    if (fVar2 == null || i9 != fVar2.b) {
                        f2 += a(i9, i8 + 1).d;
                        i5++;
                        if (i8 >= 0) {
                            fVar = this.k0.get(i8);
                        } else {
                            fVar = null;
                        }
                    } else {
                        f2 += fVar2.d;
                        i8--;
                        if (i8 >= 0) {
                            fVar = this.k0.get(i8);
                        } else {
                            fVar = null;
                        }
                    }
                    fVar2 = fVar;
                } else {
                    if (fVar2 == null) {
                        break;
                    }
                    if (i9 == fVar2.b && !fVar2.c) {
                        this.k0.remove(i8);
                        this.n0.b(this, i9, fVar2.a);
                        i8--;
                        i5--;
                        if (i8 >= 0) {
                            fVar = this.k0.get(i8);
                        } else {
                            fVar = null;
                        }
                        fVar2 = fVar;
                    }
                }
            }
            float f3 = fVarA.d;
            int i10 = i5 + 1;
            if (f3 < 2.0f) {
                f fVar3 = i10 < this.k0.size() ? this.k0.get(i10) : null;
                float paddingRight = clientWidth <= 0 ? 0.0f : (getPaddingRight() / clientWidth) + 2.0f;
                int i11 = this.o0;
                while (true) {
                    i11++;
                    if (i11 >= iE) {
                        break;
                    }
                    if (f3 >= paddingRight && i11 > iMin) {
                        if (fVar3 == null) {
                            break;
                        }
                        if (i11 == fVar3.b && !fVar3.c) {
                            this.k0.remove(i10);
                            this.n0.b(this, i11, fVar3.a);
                            if (i10 < this.k0.size()) {
                                fVar3 = this.k0.get(i10);
                            }
                        }
                    } else if (fVar3 == null || i11 != fVar3.b) {
                        f fVarA2 = a(i11, i10);
                        i10++;
                        f3 += fVarA2.d;
                        fVar3 = i10 < this.k0.size() ? this.k0.get(i10) : null;
                    } else {
                        f3 += fVar3.d;
                        i10++;
                        if (i10 < this.k0.size()) {
                            fVar3 = this.k0.get(i10);
                        }
                    }
                }
            }
            e(fVarA, i5, fVarU);
            this.n0.q(this, this.o0, fVarA.a);
        }
        this.n0.d(this);
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            g gVar = (g) childAt.getLayoutParams();
            gVar.f = i12;
            if (!gVar.a && gVar.c == 0.0f && (fVarS = s(childAt)) != null) {
                gVar.c = fVarS.d;
                gVar.e = fVarS.b;
            }
        }
        T();
        if (hasFocus()) {
            View viewFindFocus = findFocus();
            f fVarR = viewFindFocus != null ? r(viewFindFocus) : null;
            if (fVarR == null || fVarR.b != this.o0) {
                for (int i13 = 0; i13 < getChildCount(); i13++) {
                    View childAt2 = getChildAt(i13);
                    f fVarS2 = s(childAt2);
                    if (fVarS2 != null && fVarS2.b == this.o0 && childAt2.requestFocus(2)) {
                        return;
                    }
                }
            }
        }
    }

    public void I(i iVar) {
        List<i> list = this.g1;
        if (list != null) {
            list.remove(iVar);
        }
    }

    public void J(j jVar) {
        List<j> list = this.d1;
        if (list != null) {
            list.remove(jVar);
        }
    }

    public void N(int i2, boolean z) {
        this.F0 = false;
        O(i2, z, false);
    }

    void O(int i2, boolean z, boolean z2) {
        P(i2, z, z2, 0);
    }

    void P(int i2, boolean z, boolean z2, int i3) {
        androidx.viewpager.widget.a aVar = this.n0;
        if (aVar == null || aVar.e() <= 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (!z2 && this.o0 == i2 && this.k0.size() != 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i2 < 0) {
            i2 = 0;
        } else if (i2 >= this.n0.e()) {
            i2 = this.n0.e() - 1;
        }
        int i4 = this.G0;
        int i5 = this.o0;
        if (i2 > i5 + i4 || i2 < i5 - i4) {
            for (int i6 = 0; i6 < this.k0.size(); i6++) {
                this.k0.get(i6).c = true;
            }
        }
        boolean z3 = this.o0 != i2;
        if (!this.Z0) {
            F(i2);
            M(i2, z, i3, z3);
        } else {
            this.o0 = i2;
            if (z3) {
                k(i2);
            }
            requestLayout();
        }
    }

    public void Q(boolean z, k kVar) {
        R(z, kVar, 2);
    }

    public void R(boolean z, k kVar, int i2) {
        boolean z2 = kVar != null;
        boolean z3 = z2 != (this.h1 != null);
        this.h1 = kVar;
        setChildrenDrawingOrderEnabled(z2);
        if (z2) {
            this.j1 = z ? 2 : 1;
            this.i1 = i2;
        } else {
            this.j1 = 0;
        }
        if (z3) {
            E();
        }
    }

    void S(int i2, int i3, int i4) {
        int scrollX;
        int iAbs;
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        Scroller scroller = this.s0;
        if (scroller == null || scroller.isFinished()) {
            scrollX = getScrollX();
        } else {
            scrollX = this.t0 ? this.s0.getCurrX() : this.s0.getStartX();
            this.s0.abortAnimation();
            setScrollingCacheEnabled(false);
        }
        int i5 = scrollX;
        int scrollY = getScrollY();
        int i6 = i2 - i5;
        int i7 = i3 - scrollY;
        if (i6 == 0 && i7 == 0) {
            g(false);
            E();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int clientWidth = getClientWidth();
        int i8 = clientWidth / 2;
        float f2 = clientWidth;
        float f3 = i8;
        float fM = f3 + (m(Math.min(1.0f, (Math.abs(i6) * 1.0f) / f2)) * f3);
        int iAbs2 = Math.abs(i4);
        if (iAbs2 > 0) {
            iAbs = Math.round(Math.abs(fM / iAbs2) * 1000.0f) * 4;
        } else {
            iAbs = (int) (((Math.abs(i6) / ((f2 * this.n0.h(this.o0)) + this.v0)) + 1.0f) * 100.0f);
        }
        int iMin = Math.min(iAbs, 600);
        this.t0 = false;
        this.s0.startScroll(i5, scrollY, i6, i7, iMin);
        C1839d0.c0(this);
    }

    f a(int i2, int i3) {
        f fVar = new f();
        fVar.b = i2;
        fVar.a = this.n0.j(this, i2);
        fVar.d = this.n0.h(i2);
        if (i3 < 0 || i3 >= this.k0.size()) {
            this.k0.add(fVar);
            return fVar;
        }
        this.k0.add(i3, fVar);
        return fVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        f fVarS;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i4 = 0; i4 < getChildCount(); i4++) {
                View childAt = getChildAt(i4);
                if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.o0) {
                    childAt.addFocusables(arrayList, i2, i3);
                }
            }
        }
        if ((descendantFocusability != 262144 || size == arrayList.size()) && isFocusable()) {
            if ((i3 & 1) == 1 && isInTouchMode() && !isFocusableInTouchMode()) {
                return;
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addTouchables(ArrayList<View> arrayList) {
        f fVarS;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.o0) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        g gVar = (g) layoutParams;
        boolean zW = gVar.a | w(view);
        gVar.a = zW;
        if (!this.D0) {
            super.addView(view, i2, layoutParams);
        } else {
            if (zW) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            gVar.d = true;
            addViewInLayout(view, i2, layoutParams);
        }
    }

    public void b(i iVar) {
        if (this.g1 == null) {
            this.g1 = new ArrayList();
        }
        this.g1.add(iVar);
    }

    public void c(j jVar) {
        if (this.d1 == null) {
            this.d1 = new ArrayList();
        }
        this.d1.add(jVar);
    }

    @Override // android.view.View
    public boolean canScrollHorizontally(int i2) {
        if (this.n0 == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        if (i2 < 0) {
            return scrollX > ((int) (((float) clientWidth) * this.z0));
        }
        return i2 > 0 && scrollX < ((int) (((float) clientWidth) * this.A0));
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof g) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        this.t0 = true;
        if (this.s0.isFinished() || !this.s0.computeScrollOffset()) {
            g(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.s0.getCurrX();
        int currY = this.s0.getCurrY();
        if (scrollX != currX || scrollY != currY) {
            scrollTo(currX, currY);
            if (!C(currX)) {
                this.s0.abortAnimation();
                scrollTo(0, currY);
            }
        }
        C1839d0.c0(this);
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00bf  */
    public boolean d(int i2) {
        boolean zA;
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
            break;
        }
        if (viewFindFocus != null) {
            ViewParent parent = viewFindFocus.getParent();
            while (true) {
                if (!(parent instanceof ViewGroup)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(viewFindFocus.getClass().getSimpleName());
                    for (ViewParent parent2 = viewFindFocus.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                        sb.append(" => ");
                        sb.append(parent2.getClass().getSimpleName());
                    }
                    Log.e("ViewPager", "arrowScroll tried to find focus based on non-child current focused view " + sb.toString());
                    viewFindFocus = null;
                    break;
                }
                if (parent == this) {
                    break;
                }
                parent = parent.getParent();
            }
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i2);
        if (viewFindNextFocus == null || viewFindNextFocus == viewFindFocus) {
            if (i2 == 17 || i2 == 1) {
                zA = A();
            } else if (i2 == 66 || i2 == 2) {
                zA = B();
            } else {
                zA = false;
            }
        } else if (i2 == 17) {
            zA = (viewFindFocus == null || q(this.m0, viewFindNextFocus).left < q(this.m0, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : A();
        } else if (i2 == 66) {
            zA = (viewFindFocus == null || q(this.m0, viewFindNextFocus).left > q(this.m0, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : B();
        } else {
            zA = false;
        }
        if (zA) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i2));
        }
        return zA;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || p(keyEvent);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        f fVarS;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.o0 && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        androidx.viewpager.widget.a aVar;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean zDraw = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (aVar = this.n0) != null && aVar.e() > 1)) {
            if (!this.X0.isFinished()) {
                int iSave = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((-height) + getPaddingTop(), this.z0 * width);
                this.X0.setSize(height, width);
                zDraw = this.X0.draw(canvas);
                canvas.restoreToCount(iSave);
            }
            if (!this.Y0.isFinished()) {
                int iSave2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate(-getPaddingTop(), (-(this.A0 + 1.0f)) * width2);
                this.Y0.setSize(height2, width2);
                zDraw |= this.Y0.draw(canvas);
                canvas.restoreToCount(iSave2);
            }
        } else {
            this.X0.finish();
            this.Y0.finish();
        }
        if (zDraw) {
            C1839d0.c0(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.w0;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        drawable.setState(getDrawableState());
    }

    protected boolean f(View view, boolean z, int i2, int i3, int i4) {
        int i5;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i3 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i5 = i4 + scrollY) >= childAt.getTop() && i5 < childAt.getBottom() && f(childAt, true, i2, i6 - childAt.getLeft(), i5 - childAt.getTop())) {
                    return true;
                }
            }
        }
        return z && view.canScrollHorizontally(-i2);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new g();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public androidx.viewpager.widget.a getAdapter() {
        return this.n0;
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        if (this.j1 == 2) {
            i3 = (i2 - 1) - i3;
        }
        return ((g) this.k1.get(i3).getLayoutParams()).f;
    }

    public int getCurrentItem() {
        return this.o0;
    }

    public int getOffscreenPageLimit() {
        return this.G0;
    }

    public int getPageMargin() {
        return this.v0;
    }

    void h() {
        int iE = this.n0.e();
        this.q = iE;
        boolean z = this.k0.size() < (this.G0 * 2) + 1 && this.k0.size() < iE;
        int iMax = this.o0;
        int i2 = 0;
        boolean z2 = false;
        while (i2 < this.k0.size()) {
            f fVar = this.k0.get(i2);
            int iF = this.n0.f(fVar.a);
            if (iF != -1) {
                if (iF == -2) {
                    this.k0.remove(i2);
                    i2--;
                    if (!z2) {
                        this.n0.t(this);
                        z2 = true;
                    }
                    this.n0.b(this, fVar.b, fVar.a);
                    int i3 = this.o0;
                    if (i3 == fVar.b) {
                        iMax = Math.max(0, Math.min(i3, iE - 1));
                    }
                } else {
                    int i4 = fVar.b;
                    if (i4 != iF) {
                        if (i4 == this.o0) {
                            iMax = iF;
                        }
                        fVar.b = iF;
                    }
                }
                z = true;
            }
            i2++;
        }
        if (z2) {
            this.n0.d(this);
        }
        Collections.sort(this.k0, o1);
        if (z) {
            int childCount = getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                g gVar = (g) getChildAt(i5).getLayoutParams();
                if (!gVar.a) {
                    gVar.c = 0.0f;
                }
            }
            O(iMax, false, true);
            requestLayout();
        }
    }

    float m(float f2) {
        return (float) Math.sin((f2 - 0.5f) * 0.47123894f);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.Z0 = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.l1);
        Scroller scroller = this.s0;
        if (scroller != null && !scroller.isFinished()) {
            this.s0.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        int i2;
        float f2;
        super.onDraw(canvas);
        if (this.v0 <= 0 || this.w0 == null || this.k0.size() <= 0 || this.n0 == null) {
            return;
        }
        int scrollX = getScrollX();
        int width = getWidth();
        float f3 = width;
        float f4 = this.v0 / f3;
        int i3 = 0;
        f fVar = this.k0.get(0);
        float f5 = fVar.e;
        int size = this.k0.size();
        int i4 = fVar.b;
        int i5 = this.k0.get(size - 1).b;
        while (i4 < i5) {
            while (true) {
                i2 = fVar.b;
                if (i4 <= i2 || i3 >= size) {
                    break;
                }
                i3++;
                fVar = this.k0.get(i3);
            }
            if (i4 == i2) {
                float f6 = fVar.e;
                float f7 = fVar.d;
                f2 = (f6 + f7) * f3;
                f5 = f6 + f7 + f4;
            } else {
                float fH = this.n0.h(i4);
                f2 = (f5 + fH) * f3;
                f5 += fH + f4;
            }
            if (this.v0 + f2 > scrollX) {
                this.w0.setBounds(Math.round(f2), this.x0, Math.round(this.v0 + f2), this.y0);
                this.w0.draw(canvas);
            }
            if (f2 > scrollX + width) {
                return;
            }
            i4++;
            scrollX = scrollX;
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            L();
            return false;
        }
        if (action != 0) {
            if (this.H0) {
                return true;
            }
            if (this.I0) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent.getX();
            this.O0 = x;
            this.M0 = x;
            float y = motionEvent.getY();
            this.P0 = y;
            this.N0 = y;
            this.Q0 = motionEvent.getPointerId(0);
            this.I0 = false;
            this.t0 = true;
            this.s0.computeScrollOffset();
            if (this.m1 != 2 || Math.abs(this.s0.getFinalX() - this.s0.getCurrX()) <= this.V0) {
                g(false);
                this.H0 = false;
            } else {
                this.s0.abortAnimation();
                this.F0 = false;
                E();
                this.H0 = true;
                K(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i2 = this.Q0;
            if (i2 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i2);
                float x2 = motionEvent.getX(iFindPointerIndex);
                float f2 = x2 - this.M0;
                float fAbs = Math.abs(f2);
                float y2 = motionEvent.getY(iFindPointerIndex);
                float fAbs2 = Math.abs(y2 - this.P0);
                if (f2 != 0.0f && !x(this.M0, f2) && f(this, false, (int) f2, (int) x2, (int) y2)) {
                    this.M0 = x2;
                    this.N0 = y2;
                    this.I0 = true;
                    return false;
                }
                int i3 = this.L0;
                if (fAbs > i3 && fAbs * 0.5f > fAbs2) {
                    this.H0 = true;
                    K(true);
                    setScrollState(1);
                    float f3 = this.O0;
                    float f4 = this.L0;
                    this.M0 = f2 > 0.0f ? f3 + f4 : f3 - f4;
                    this.N0 = y2;
                    setScrollingCacheEnabled(true);
                } else if (fAbs2 > i3) {
                    this.I0 = true;
                }
                if (this.H0 && D(x2)) {
                    C1839d0.c0(this);
                }
            }
        } else if (action == 6) {
            z(motionEvent);
        }
        if (this.R0 == null) {
            this.R0 = VelocityTracker.obtain();
        }
        this.R0.addMovement(motionEvent);
        return this.H0;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0072  */
    /* JADX WARN: Code duplicated, block: B:24:0x0076  */
    /* JADX WARN: Code duplicated, block: B:26:0x007a  */
    /* JADX WARN: Code duplicated, block: B:27:0x007c  */
    /* JADX WARN: Code duplicated, block: B:29:0x008e  */
    /* JADX WARN: Code duplicated, block: B:30:0x0094  */
    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        boolean z2;
        f fVarS;
        int iMax;
        int measuredWidth;
        int iMax2;
        int measuredHeight;
        int childCount = getChildCount();
        int i6 = i4 - i2;
        int i7 = i5 - i3;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a) {
                    int i10 = gVar.b;
                    int i11 = i10 & 7;
                    int i12 = i10 & 112;
                    if (i11 != 1) {
                        if (i11 == 3) {
                            measuredWidth = childAt.getMeasuredWidth() + paddingLeft;
                        } else if (i11 != 5) {
                            measuredWidth = paddingLeft;
                        } else {
                            iMax = (i6 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        if (i12 != 16) {
                            if (i12 != 48) {
                                measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                            } else if (i12 != 80) {
                                measuredHeight = paddingTop;
                            } else {
                                iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                                paddingBottom += childAt.getMeasuredHeight();
                            }
                            int i13 = paddingLeft + scrollX;
                            childAt.layout(i13, paddingTop, childAt.getMeasuredWidth() + i13, paddingTop + childAt.getMeasuredHeight());
                            i8++;
                            paddingTop = measuredHeight;
                            paddingLeft = measuredWidth;
                        } else {
                            iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                        }
                        int i14 = iMax2;
                        measuredHeight = paddingTop;
                        paddingTop = i14;
                        int i15 = paddingLeft + scrollX;
                        childAt.layout(i15, paddingTop, childAt.getMeasuredWidth() + i15, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax = Math.max((i6 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i16 = iMax;
                    measuredWidth = paddingLeft;
                    paddingLeft = i16;
                    if (i12 != 16) {
                        if (i12 != 48) {
                            measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                        } else if (i12 != 80) {
                            measuredHeight = paddingTop;
                        } else {
                            iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                            paddingBottom += childAt.getMeasuredHeight();
                        }
                        int i17 = paddingLeft + scrollX;
                        childAt.layout(i17, paddingTop, childAt.getMeasuredWidth() + i17, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                    }
                    int i18 = iMax2;
                    measuredHeight = paddingTop;
                    paddingTop = i18;
                    int i19 = paddingLeft + scrollX;
                    childAt.layout(i19, paddingTop, childAt.getMeasuredWidth() + i19, paddingTop + childAt.getMeasuredHeight());
                    i8++;
                    paddingTop = measuredHeight;
                    paddingLeft = measuredWidth;
                }
            }
        }
        int i20 = (i6 - paddingLeft) - paddingRight;
        for (int i21 = 0; i21 < childCount; i21++) {
            View childAt2 = getChildAt(i21);
            if (childAt2.getVisibility() != 8) {
                g gVar2 = (g) childAt2.getLayoutParams();
                if (!gVar2.a && (fVarS = s(childAt2)) != null) {
                    float f2 = i20;
                    int i22 = ((int) (fVarS.e * f2)) + paddingLeft;
                    if (gVar2.d) {
                        gVar2.d = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f2 * gVar2.c), 1073741824), View.MeasureSpec.makeMeasureSpec((i7 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i22, paddingTop, childAt2.getMeasuredWidth() + i22, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.x0 = paddingTop;
        this.y0 = i7 - paddingBottom;
        this.c1 = i8;
        if (this.Z0) {
            z2 = false;
            M(this.o0, false, 0, false);
        } else {
            z2 = false;
        }
        this.Z0 = z2;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0081 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x0086  */
    /* JADX WARN: Code duplicated, block: B:35:0x0088  */
    /* JADX WARN: Code duplicated, block: B:38:0x008d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:40:0x0090  */
    /* JADX WARN: Code duplicated, block: B:41:0x0092  */
    /* JADX WARN: Code duplicated, block: B:44:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:45:0x00a7 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:46:0x00a9  */
    /* JADX WARN: Code duplicated, block: B:65:0x00ae A[SYNTHETIC] */
    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        g gVar;
        g gVar2;
        int i4;
        int i5;
        int i6;
        setMeasuredDimension(View.getDefaultSize(0, i2), View.getDefaultSize(0, i3));
        int measuredWidth = getMeasuredWidth();
        this.K0 = Math.min(measuredWidth / 10, this.J0);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        int i7 = 0;
        while (true) {
            boolean z = true;
            int i8 = 1073741824;
            if (i7 >= childCount) {
                break;
            }
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8 && (gVar2 = (g) childAt.getLayoutParams()) != null && gVar2.a) {
                int i9 = gVar2.b;
                int i10 = i9 & 7;
                int i11 = i9 & 112;
                boolean z2 = i11 == 48 || i11 == 80;
                if (i10 != 3 && i10 != 5) {
                    z = false;
                }
                int i12 = Integer.MIN_VALUE;
                if (z2) {
                    i12 = 1073741824;
                } else {
                    i4 = z ? 1073741824 : Integer.MIN_VALUE;
                    i5 = ((ViewGroup.LayoutParams) gVar2).width;
                    if (i5 != -2) {
                        if (i5 == -1) {
                            i5 = paddingLeft;
                        }
                        i12 = 1073741824;
                    } else {
                        i5 = paddingLeft;
                    }
                    i6 = ((ViewGroup.LayoutParams) gVar2).height;
                    if (i6 != -2) {
                        i6 = measuredHeight;
                        i8 = i4;
                    } else if (i6 == -1) {
                        i6 = measuredHeight;
                    }
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                    if (z2) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (z) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
                i5 = ((ViewGroup.LayoutParams) gVar2).width;
                if (i5 != -2) {
                    if (i5 == -1) {
                        i5 = paddingLeft;
                    }
                    i12 = 1073741824;
                } else {
                    i5 = paddingLeft;
                }
                i6 = ((ViewGroup.LayoutParams) gVar2).height;
                if (i6 != -2) {
                    i6 = measuredHeight;
                    i8 = i4;
                } else if (i6 == -1) {
                    i6 = measuredHeight;
                }
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                if (z2) {
                    measuredHeight -= childAt.getMeasuredHeight();
                } else if (z) {
                    paddingLeft -= childAt.getMeasuredWidth();
                }
            }
            i7++;
        }
        this.B0 = View.MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.C0 = View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.D0 = true;
        E();
        this.D0 = false;
        int childCount2 = getChildCount();
        for (int i13 = 0; i13 < childCount2; i13++) {
            View childAt2 = getChildAt(i13);
            if (childAt2.getVisibility() != 8 && ((gVar = (g) childAt2.getLayoutParams()) == null || !gVar.a)) {
                childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (paddingLeft * gVar.c), 1073741824), this.C0);
            }
        }
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i2, Rect rect) {
        int i3;
        int i4;
        int i5;
        f fVarS;
        int childCount = getChildCount();
        if ((i2 & 2) != 0) {
            i4 = childCount;
            i3 = 0;
            i5 = 1;
        } else {
            i3 = childCount - 1;
            i4 = -1;
            i5 = -1;
        }
        while (i3 != i4) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.o0 && childAt.requestFocus(i2, rect)) {
                return true;
            }
            i3 += i5;
        }
        return false;
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof m)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        m mVar = (m) parcelable;
        super.onRestoreInstanceState(mVar.a());
        androidx.viewpager.widget.a aVar = this.n0;
        if (aVar != null) {
            aVar.n(mVar.Z, mVar.k0);
            O(mVar.Y, false, true);
        } else {
            this.p0 = mVar.Y;
            this.q0 = mVar.Z;
            this.r0 = mVar.k0;
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        m mVar = new m(super.onSaveInstanceState());
        mVar.Y = this.o0;
        androidx.viewpager.widget.a aVar = this.n0;
        if (aVar != null) {
            mVar.Z = aVar.o();
        }
        return mVar;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4) {
            int i6 = this.v0;
            G(i2, i4, i6, i6);
        }
    }

    /* JADX WARN: Code duplicated, block: B:53:0x00dc  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        androidx.viewpager.widget.a aVar;
        if (this.W0) {
            return true;
        }
        boolean zL = false;
        if ((motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) || (aVar = this.n0) == null || aVar.e() == 0) {
            return false;
        }
        if (this.R0 == null) {
            this.R0 = VelocityTracker.obtain();
        }
        this.R0.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.s0.abortAnimation();
            this.F0 = false;
            E();
            float x = motionEvent.getX();
            this.O0 = x;
            this.M0 = x;
            float y = motionEvent.getY();
            this.P0 = y;
            this.N0 = y;
            this.Q0 = motionEvent.getPointerId(0);
        } else if (action != 1) {
            if (action != 2) {
                if (action != 3) {
                    if (action == 5) {
                        int actionIndex = motionEvent.getActionIndex();
                        this.M0 = motionEvent.getX(actionIndex);
                        this.Q0 = motionEvent.getPointerId(actionIndex);
                    } else if (action == 6) {
                        z(motionEvent);
                        this.M0 = motionEvent.getX(motionEvent.findPointerIndex(this.Q0));
                    }
                } else if (this.H0) {
                    M(this.o0, true, 0, false);
                    zL = L();
                }
            } else if (!this.H0) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.Q0);
                if (iFindPointerIndex == -1) {
                    zL = L();
                } else {
                    float x2 = motionEvent.getX(iFindPointerIndex);
                    float fAbs = Math.abs(x2 - this.M0);
                    float y2 = motionEvent.getY(iFindPointerIndex);
                    float fAbs2 = Math.abs(y2 - this.N0);
                    if (fAbs > this.L0 && fAbs > fAbs2) {
                        this.H0 = true;
                        K(true);
                        float f2 = this.O0;
                        this.M0 = x2 - f2 > 0.0f ? f2 + this.L0 : f2 - this.L0;
                        this.N0 = y2;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    if (this.H0) {
                        zL = D(motionEvent.getX(motionEvent.findPointerIndex(this.Q0)));
                    }
                }
            } else if (this.H0) {
                zL = D(motionEvent.getX(motionEvent.findPointerIndex(this.Q0)));
            }
        } else if (this.H0) {
            VelocityTracker velocityTracker = this.R0;
            velocityTracker.computeCurrentVelocity(1000, this.T0);
            int xVelocity = (int) velocityTracker.getXVelocity(this.Q0);
            this.F0 = true;
            int clientWidth = getClientWidth();
            int scrollX = getScrollX();
            f fVarT = t();
            float f3 = clientWidth;
            P(i(fVarT.b, ((scrollX / f3) - fVarT.e) / (fVarT.d + (this.v0 / f3)), xVelocity, (int) (motionEvent.getX(motionEvent.findPointerIndex(this.Q0)) - this.O0)), true, true, xVelocity);
            zL = L();
        }
        if (zL) {
            C1839d0.c0(this);
        }
        return true;
    }

    public boolean p(KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0) {
            return false;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode == 21) {
            return keyEvent.hasModifiers(2) ? A() : d(17);
        }
        if (keyCode == 22) {
            return keyEvent.hasModifiers(2) ? B() : d(66);
        }
        if (keyCode != 61) {
            return false;
        }
        if (keyEvent.hasNoModifiers()) {
            return d(2);
        }
        if (keyEvent.hasModifiers(1)) {
            return d(1);
        }
        return false;
    }

    f r(View view) {
        while (true) {
            Object parent = view.getParent();
            if (parent == this) {
                return s(view);
            }
            if (parent == null || !(parent instanceof View)) {
                return null;
            }
            view = (View) parent;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        if (this.D0) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    f s(View view) {
        for (int i2 = 0; i2 < this.k0.size(); i2++) {
            f fVar = this.k0.get(i2);
            if (this.n0.k(view, fVar.a)) {
                return fVar;
            }
        }
        return null;
    }

    public void setAdapter(androidx.viewpager.widget.a aVar) {
        androidx.viewpager.widget.a aVar2 = this.n0;
        if (aVar2 != null) {
            aVar2.r(null);
            this.n0.t(this);
            for (int i2 = 0; i2 < this.k0.size(); i2++) {
                f fVar = this.k0.get(i2);
                this.n0.b(this, fVar.b, fVar.a);
            }
            this.n0.d(this);
            this.k0.clear();
            H();
            this.o0 = 0;
            scrollTo(0, 0);
        }
        androidx.viewpager.widget.a aVar3 = this.n0;
        this.n0 = aVar;
        this.q = 0;
        if (aVar != null) {
            if (this.u0 == null) {
                this.u0 = new l();
            }
            this.n0.r(this.u0);
            this.F0 = false;
            boolean z = this.Z0;
            this.Z0 = true;
            this.q = this.n0.e();
            if (this.p0 >= 0) {
                this.n0.n(this.q0, this.r0);
                O(this.p0, false, true);
                this.p0 = -1;
                this.q0 = null;
                this.r0 = null;
            } else if (z) {
                requestLayout();
            } else {
                E();
            }
        }
        List<i> list = this.g1;
        if (list == null || list.isEmpty()) {
            return;
        }
        int size = this.g1.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.g1.get(i3).a(this, aVar3, aVar);
        }
    }

    public void setCurrentItem(int i2) {
        this.F0 = false;
        O(i2, !this.Z0, false);
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i2 + " too small; defaulting to 1");
            i2 = 1;
        }
        if (i2 != this.G0) {
            this.G0 = i2;
            E();
        }
    }

    @Deprecated
    public void setOnPageChangeListener(j jVar) {
        this.e1 = jVar;
    }

    public void setPageMargin(int i2) {
        int i3 = this.v0;
        this.v0 = i2;
        int width = getWidth();
        G(width, width, i2, i3);
        requestLayout();
    }

    public void setPageMarginDrawable(int i2) {
        setPageMarginDrawable(ax.Q.b.e(getContext(), i2));
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.w0 = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    void setScrollState(int i2) {
        if (this.m1 == i2) {
            return;
        }
        this.m1 = i2;
        if (this.h1 != null) {
            n(i2 != 0);
        }
        l(i2);
    }

    f u(int i2) {
        for (int i3 = 0; i3 < this.k0.size(); i3++) {
            f fVar = this.k0.get(i3);
            if (fVar.b == i2) {
                return fVar;
            }
        }
        return null;
    }

    void v() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.s0 = new Scroller(context, p1);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.L0 = viewConfiguration.getScaledPagingTouchSlop();
        this.S0 = (int) (400.0f * f2);
        this.T0 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.X0 = new EdgeEffect(context);
        this.Y0 = new EdgeEffect(context);
        this.U0 = (int) (25.0f * f2);
        this.V0 = (int) (2.0f * f2);
        this.J0 = (int) (f2 * 16.0f);
        C1839d0.l0(this, new h());
        if (C1839d0.z(this) == 0) {
            C1839d0.s0(this, 1);
        }
        C1839d0.v0(this, new d());
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.w0;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0065  */
    protected void y(int i2, float f2, int i3) {
        int iMax;
        int width;
        int left;
        if (this.c1 > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width2 = getWidth();
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a) {
                    int i5 = gVar.b & 7;
                    if (i5 != 1) {
                        if (i5 == 3) {
                            width = childAt.getWidth() + paddingLeft;
                        } else if (i5 != 5) {
                            width = paddingLeft;
                        } else {
                            iMax = (width2 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        left = (paddingLeft + scrollX) - childAt.getLeft();
                        if (left != 0) {
                            childAt.offsetLeftAndRight(left);
                        }
                        paddingLeft = width;
                    } else {
                        iMax = Math.max((width2 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i6 = iMax;
                    width = paddingLeft;
                    paddingLeft = i6;
                    left = (paddingLeft + scrollX) - childAt.getLeft();
                    if (left != 0) {
                        childAt.offsetLeftAndRight(left);
                    }
                    paddingLeft = width;
                }
            }
        }
        j(i2, f2, i3);
        if (this.h1 != null) {
            int scrollX2 = getScrollX();
            int childCount2 = getChildCount();
            for (int i7 = 0; i7 < childCount2; i7++) {
                View childAt2 = getChildAt(i7);
                if (!((g) childAt2.getLayoutParams()).a) {
                    this.h1.a(childAt2, (childAt2.getLeft() - scrollX2) / getClientWidth());
                }
            }
        }
        this.b1 = true;
    }
}
