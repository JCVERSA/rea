package androidx.viewpager.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import ax.p015b0.A0;
import ax.p015b0.C5207a;
import ax.p015b0.H;
import ax.p015b0.Y;
import ax.p029c0.I;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ViewPager extends ViewGroup {
    static final int[] k1 = {R.attr.layout_gravity};
    private static final Comparator<f> l1 = new a();
    private static final Interpolator m1 = new b();
    private static final n n1 = new n();
    private boolean A0;
    private boolean B0;
    private boolean C0;
    private int D0;
    private boolean E0;
    private boolean F0;
    private int G0;
    private int H0;
    private int I0;
    private float J0;
    private float K0;
    private float L0;
    private float M0;
    private int N0;
    private VelocityTracker O0;
    private int P0;
    private int Q0;
    private int R0;
    private int S0;
    private boolean T0;
    private EdgeEffect U0;
    private EdgeEffect V0;
    private boolean W0;
    private boolean X0;
    private boolean Y0;
    private int Z0;
    private List<j> a1;
    private j b1;
    private j c1;
    private List<i> d1;
    private k e1;
    private int f1;
    private int g1;
    private final ArrayList<f> h0;
    private ArrayList<View> h1;
    private final f i0;
    private final Runnable i1;
    private final Rect j0;
    private int j1;
    androidx.viewpager.widget.a k0;
    int l0;
    private int m0;
    private Parcelable n0;
    private ClassLoader o0;
    private Scroller p0;
    private int q;
    private boolean q0;
    private l r0;
    private int s0;
    private Drawable t0;
    private int u0;
    private int v0;
    private float w0;
    private float x0;
    private int y0;
    private int z0;

    static class a implements Comparator<f> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return fVar.b - fVar2.b;
        }
    }

    static class b implements Interpolator {
        b() {
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager.this.E();
        }
    }

    class d implements H {
        private final Rect a = new Rect();

        d() {
        }

        @Override // ax.p015b0.H
        public A0 a(View view, A0 a0) {
            A0 a0C0 = Y.c0(view, a0);
            if (a0C0.o()) {
                return a0C0;
            }
            Rect rect = this.a;
            rect.left = a0C0.j();
            rect.top = a0C0.l();
            rect.right = a0C0.k();
            rect.bottom = a0C0.i();
            int childCount = ViewPager.this.getChildCount();
            for (int i = 0; i < childCount; i++) {
                A0 a0I = Y.i(ViewPager.this.getChildAt(i), a0C0);
                rect.left = Math.min(a0I.j(), rect.left);
                rect.top = Math.min(a0I.l(), rect.top);
                rect.right = Math.min(a0I.k(), rect.right);
                rect.bottom = Math.min(a0I.i(), rect.bottom);
            }
            return a0C0.p(rect.left, rect.top, rect.right, rect.bottom);
        }
    }

    @Target({ElementType.TYPE})
    @Inherited
    @Retention(RetentionPolicy.RUNTIME)
    public @interface e {
    }

    static class f {
        Object a;
        int b;
        boolean c;
        float d;
        float e;

        f() {
        }
    }

    class h extends C5207a {
        h() {
        }

        private boolean n() {
            androidx.viewpager.widget.a aVar = ViewPager.this.k0;
            return aVar != null && aVar.e() > 1;
        }

        @Override // ax.p015b0.C5207a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            androidx.viewpager.widget.a aVar;
            super.f(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            accessibilityEvent.setScrollable(n());
            if (accessibilityEvent.getEventType() != 4096 || (aVar = ViewPager.this.k0) == null) {
                return;
            }
            accessibilityEvent.setItemCount(aVar.e());
            accessibilityEvent.setFromIndex(ViewPager.this.l0);
            accessibilityEvent.setToIndex(ViewPager.this.l0);
        }

        @Override // ax.p015b0.C5207a
        public void g(View view, I i) {
            super.g(view, i);
            i.m0(ViewPager.class.getName());
            i.G0(n());
            if (ViewPager.this.canScrollHorizontally(1)) {
                i.a(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                i.a(8192);
            }
        }

        @Override // ax.p015b0.C5207a
        public boolean j(View view, int i, Bundle bundle) {
            if (super.j(view, i, bundle)) {
                return true;
            }
            if (i == 4096) {
                if (!ViewPager.this.canScrollHorizontally(1)) {
                    return false;
                }
                ViewPager viewPager = ViewPager.this;
                viewPager.setCurrentItem(viewPager.l0 + 1);
                return true;
            }
            if (i != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                return false;
            }
            ViewPager viewPager2 = ViewPager.this;
            viewPager2.setCurrentItem(viewPager2.l0 - 1);
            return true;
        }
    }

    public interface i {
        void a(ViewPager viewPager, androidx.viewpager.widget.a aVar, androidx.viewpager.widget.a aVar2);
    }

    public interface j {
        void W(int i);

        void d(int i);

        void r(int i, float f, int i2);
    }

    public interface k {
        void a(View view, float f);
    }

    private class l extends DataSetObserver {
        l() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            ViewPager.this.h();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ViewPager.this.h();
        }
    }

    public static class m extends ax.p141k0.a {
        public static final Parcelable.Creator<m> CREATOR = new a();
        int Y;
        Parcelable Z;
        ClassLoader h0;

        static class a implements Parcelable.ClassLoaderCreator<m> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public m createFromParcel(Parcel parcel) {
                return new m(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public m createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new m(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public m[] newArray(int i) {
                return new m[i];
            }
        }

        public m(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.Y + "}";
        }

        @Override // ax.p141k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeParcelable(this.Z, i);
        }

        m(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? getClass().getClassLoader() : classLoader;
            this.Y = parcel.readInt();
            this.Z = parcel.readParcelable(classLoader);
            this.h0 = classLoader;
        }
    }

    static class n implements Comparator<View> {
        n() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            g gVar = (g) view.getLayoutParams();
            g gVar2 = (g) view2.getLayoutParams();
            boolean z = gVar.a;
            if (z != gVar2.a) {
                return z ? 1 : -1;
            }
            return gVar.e - gVar2.e;
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h0 = new ArrayList<>();
        this.i0 = new f();
        this.j0 = new Rect();
        this.m0 = -1;
        this.n0 = null;
        this.o0 = null;
        this.w0 = -3.4028235E38f;
        this.x0 = Float.MAX_VALUE;
        this.D0 = 1;
        this.N0 = -1;
        this.W0 = true;
        this.X0 = false;
        this.i1 = new c();
        this.j1 = 0;
        v();
    }

    private boolean C(int i2) {
        if (this.h0.size() == 0) {
            if (this.W0) {
                return false;
            }
            this.Y0 = false;
            y(0, 0.0f, 0);
            if (this.Y0) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        f fVarT = t();
        int clientWidth = getClientWidth();
        int i3 = this.s0;
        int i4 = clientWidth + i3;
        float f2 = clientWidth;
        int i5 = fVarT.b;
        float f3 = ((i2 / f2) - fVarT.e) / (fVarT.d + (i3 / f2));
        this.Y0 = false;
        y(i5, f3, (int) (i4 * f3));
        if (this.Y0) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    private boolean D(float f2) {
        boolean z;
        boolean z2;
        float f3 = this.J0 - f2;
        this.J0 = f2;
        float scrollX = getScrollX() + f3;
        float clientWidth = getClientWidth();
        float f4 = this.w0 * clientWidth;
        float f5 = this.x0 * clientWidth;
        boolean z3 = false;
        f fVar = this.h0.get(0);
        ArrayList<f> arrayList = this.h0;
        f fVar2 = arrayList.get(arrayList.size() - 1);
        if (fVar.b != 0) {
            f4 = fVar.e * clientWidth;
            z = false;
        } else {
            z = true;
        }
        if (fVar2.b != this.k0.e() - 1) {
            f5 = fVar2.e * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (scrollX < f4) {
            if (z) {
                this.U0.onPull(Math.abs(f4 - scrollX) / clientWidth);
                z3 = true;
            }
            scrollX = f4;
        } else if (scrollX > f5) {
            if (z2) {
                this.V0.onPull(Math.abs(scrollX - f5) / clientWidth);
                z3 = true;
            }
            scrollX = f5;
        }
        int i2 = (int) scrollX;
        this.J0 += scrollX - i2;
        scrollTo(i2, getScrollY());
        C(i2);
        return z3;
    }

    private void G(int i2, int i3, int i4, int i5) {
        if (i3 > 0 && !this.h0.isEmpty()) {
            if (!this.p0.isFinished()) {
                this.p0.setFinalX(getCurrentItem() * getClientWidth());
                return;
            } else {
                scrollTo((int) ((getScrollX() / (((i3 - getPaddingLeft()) - getPaddingRight()) + i5)) * (((i2 - getPaddingLeft()) - getPaddingRight()) + i4)), getScrollY());
                return;
            }
        }
        f fVarU = u(this.l0);
        int iMin = (int) ((fVarU != null ? Math.min(fVarU.e, this.x0) : 0.0f) * ((i2 - getPaddingLeft()) - getPaddingRight()));
        if (iMin != getScrollX()) {
            g(false);
            scrollTo(iMin, getScrollY());
        }
    }

    private void H() {
        int i2 = 0;
        while (i2 < getChildCount()) {
            if (!((g) getChildAt(i2).getLayoutParams()).a) {
                removeViewAt(i2);
                i2--;
            }
            i2++;
        }
    }

    private void K(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    private boolean L() {
        this.N0 = -1;
        o();
        this.U0.onRelease();
        this.V0.onRelease();
        return this.U0.isFinished() || this.V0.isFinished();
    }

    private void M(int i2, boolean z, int i3, boolean z2) {
        f fVarU = u(i2);
        int clientWidth = fVarU != null ? (int) (getClientWidth() * Math.max(this.w0, Math.min(fVarU.e, this.x0))) : 0;
        if (z) {
            S(clientWidth, 0, i3);
            if (z2) {
                k(i2);
                return;
            }
            return;
        }
        if (z2) {
            k(i2);
        }
        g(false);
        scrollTo(clientWidth, 0);
        C(clientWidth);
    }

    private void T() {
        if (this.g1 != 0) {
            ArrayList<View> arrayList = this.h1;
            if (arrayList == null) {
                this.h1 = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                this.h1.add(getChildAt(i2));
            }
            Collections.sort(this.h1, n1);
        }
    }

    private void e(f fVar, int i2, f fVar2) {
        int i3;
        int i4;
        f fVar3;
        f fVar4;
        int iE = this.k0.e();
        int clientWidth = getClientWidth();
        float f2 = clientWidth > 0 ? this.s0 / clientWidth : 0.0f;
        if (fVar2 != null) {
            int i5 = fVar2.b;
            int i6 = fVar.b;
            if (i5 < i6) {
                float fH = fVar2.e + fVar2.d + f2;
                int i7 = i5 + 1;
                int i8 = 0;
                while (i7 <= fVar.b && i8 < this.h0.size()) {
                    f fVar5 = this.h0.get(i8);
                    while (true) {
                        fVar4 = fVar5;
                        if (i7 <= fVar4.b || i8 >= this.h0.size() - 1) {
                            break;
                        }
                        i8++;
                        fVar5 = this.h0.get(i8);
                    }
                    while (i7 < fVar4.b) {
                        fH += this.k0.h(i7) + f2;
                        i7++;
                    }
                    fVar4.e = fH;
                    fH += fVar4.d + f2;
                    i7++;
                }
            } else if (i5 > i6) {
                int size = this.h0.size() - 1;
                float fH2 = fVar2.e;
                while (true) {
                    i5--;
                    if (i5 < fVar.b || size < 0) {
                        break;
                    }
                    f fVar6 = this.h0.get(size);
                    while (true) {
                        fVar3 = fVar6;
                        if (i5 >= fVar3.b || size <= 0) {
                            break;
                        }
                        size--;
                        fVar6 = this.h0.get(size);
                    }
                    while (i5 > fVar3.b) {
                        fH2 -= this.k0.h(i5) + f2;
                        i5--;
                    }
                    fH2 -= fVar3.d + f2;
                    fVar3.e = fH2;
                }
            }
        }
        int size2 = this.h0.size();
        float fH3 = fVar.e;
        int i9 = fVar.b;
        int i10 = i9 - 1;
        this.w0 = i9 == 0 ? fH3 : -3.4028235E38f;
        int i11 = iE - 1;
        this.x0 = i9 == i11 ? (fVar.d + fH3) - 1.0f : Float.MAX_VALUE;
        int i12 = i2 - 1;
        while (i12 >= 0) {
            f fVar7 = this.h0.get(i12);
            while (true) {
                i4 = fVar7.b;
                if (i10 <= i4) {
                    break;
                }
                fH3 -= this.k0.h(i10) + f2;
                i10--;
            }
            fH3 -= fVar7.d + f2;
            fVar7.e = fH3;
            if (i4 == 0) {
                this.w0 = fH3;
            }
            i12--;
            i10--;
        }
        float fH4 = fVar.e + fVar.d + f2;
        int i13 = fVar.b + 1;
        int i14 = i2 + 1;
        while (i14 < size2) {
            f fVar8 = this.h0.get(i14);
            while (true) {
                i3 = fVar8.b;
                if (i13 >= i3) {
                    break;
                }
                fH4 += this.k0.h(i13) + f2;
                i13++;
            }
            if (i3 == i11) {
                this.x0 = (fVar8.d + fH4) - 1.0f;
            }
            fVar8.e = fH4;
            fH4 += fVar8.d + f2;
            i14++;
            i13++;
        }
        this.X0 = false;
    }

    private void g(boolean z) {
        boolean z2 = this.j1 == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.p0.isFinished()) {
                this.p0.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.p0.getCurrX();
                int currY = this.p0.getCurrY();
                if (scrollX != currX || scrollY != currY) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        C(currX);
                    }
                }
            }
        }
        this.C0 = false;
        for (int i2 = 0; i2 < this.h0.size(); i2++) {
            f fVar = this.h0.get(i2);
            if (fVar.c) {
                fVar.c = false;
                z2 = true;
            }
        }
        if (z2) {
            if (z) {
                Y.i0(this, this.i1);
            } else {
                this.i1.run();
            }
        }
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private int i(int i2, float f2, int i3, int i4) {
        if (Math.abs(i4) <= this.R0 || Math.abs(i3) <= this.P0) {
            i2 += (int) (f2 + (i2 >= this.l0 ? 0.4f : 0.6f));
        } else if (i3 <= 0) {
            i2++;
        }
        if (this.h0.size() <= 0) {
            return i2;
        }
        f fVar = this.h0.get(0);
        ArrayList<f> arrayList = this.h0;
        return Math.max(fVar.b, Math.min(i2, arrayList.get(arrayList.size() - 1).b));
    }

    private void j(int i2, float f2, int i3) {
        j jVar = this.b1;
        if (jVar != null) {
            jVar.r(i2, f2, i3);
        }
        List<j> list = this.a1;
        if (list != null) {
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                j jVar2 = this.a1.get(i4);
                if (jVar2 != null) {
                    jVar2.r(i2, f2, i3);
                }
            }
        }
        j jVar3 = this.c1;
        if (jVar3 != null) {
            jVar3.r(i2, f2, i3);
        }
    }

    private void k(int i2) {
        j jVar = this.b1;
        if (jVar != null) {
            jVar.W(i2);
        }
        List<j> list = this.a1;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                j jVar2 = this.a1.get(i3);
                if (jVar2 != null) {
                    jVar2.W(i2);
                }
            }
        }
        j jVar3 = this.c1;
        if (jVar3 != null) {
            jVar3.W(i2);
        }
    }

    private void l(int i2) {
        j jVar = this.b1;
        if (jVar != null) {
            jVar.d(i2);
        }
        List<j> list = this.a1;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                j jVar2 = this.a1.get(i3);
                if (jVar2 != null) {
                    jVar2.d(i2);
                }
            }
        }
        j jVar3 = this.c1;
        if (jVar3 != null) {
            jVar3.d(i2);
        }
    }

    private void n(boolean z) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            getChildAt(i2).setLayerType(z ? this.f1 : 0, null);
        }
    }

    private void o() {
        this.E0 = false;
        this.F0 = false;
        VelocityTracker velocityTracker = this.O0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.O0 = null;
        }
    }

    private Rect q(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left += viewGroup.getLeft();
            rect.right += viewGroup.getRight();
            rect.top += viewGroup.getTop();
            rect.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect;
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.B0 != z) {
            this.B0 = z;
        }
    }

    private f t() {
        int i2;
        int clientWidth = getClientWidth();
        float f2 = 0.0f;
        float scrollX = clientWidth > 0 ? getScrollX() / clientWidth : 0.0f;
        float f3 = clientWidth > 0 ? this.s0 / clientWidth : 0.0f;
        f fVar = null;
        float f4 = 0.0f;
        int i3 = -1;
        int i4 = 0;
        boolean z = true;
        while (i4 < this.h0.size()) {
            f fVar2 = this.h0.get(i4);
            if (!z && fVar2.b != (i2 = i3 + 1)) {
                fVar2 = this.i0;
                fVar2.e = f2 + f4 + f3;
                fVar2.b = i2;
                fVar2.d = this.k0.h(i2);
                i4--;
            }
            f fVar3 = fVar2;
            f2 = fVar3.e;
            float f5 = fVar3.d + f2 + f3;
            if (!z && scrollX < f2) {
                return fVar;
            }
            if (scrollX < f5 || i4 == this.h0.size() - 1) {
                return fVar3;
            }
            int i5 = fVar3.b;
            float f6 = fVar3.d;
            i4++;
            z = false;
            i3 = i5;
            f4 = f6;
            fVar = fVar3;
        }
        return fVar;
    }

    private static boolean w(View view) {
        return view.getClass().getAnnotation(e.class) != null;
    }

    private boolean x(float f2, float f3) {
        return (f2 < ((float) this.H0) && f3 > 0.0f) || (f2 > ((float) (getWidth() - this.H0)) && f3 < 0.0f);
    }

    private void z(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.N0) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.J0 = motionEvent.getX(i2);
            this.N0 = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.O0;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    boolean A() {
        int i2 = this.l0;
        if (i2 <= 0) {
            return false;
        }
        N(i2 - 1, true);
        return true;
    }

    boolean B() {
        androidx.viewpager.widget.a aVar = this.k0;
        if (aVar == null || this.l0 >= aVar.e() - 1) {
            return false;
        }
        N(this.l0 + 1, true);
        return true;
    }

    void E() {
        F(this.l0);
    }

    /* JADX WARN: Code duplicated, block: B:55:0x00cb A[PHI: r7 r10 r15
      0x00cb: PHI (r7v6 int) = (r7v5 int), (r7v4 int), (r7v9 int) binds: [B:64:0x00ef, B:61:0x00d9, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]
      0x00cb: PHI (r10v9 int) = (r10v1 int), (r10v8 int), (r10v12 int) binds: [B:64:0x00ef, B:61:0x00d9, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]
      0x00cb: PHI (r15v7 float) = (r15v5 float), (r15v6 float), (r15v4 float) binds: [B:64:0x00ef, B:61:0x00d9, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]] */
    void F(int i2) {
        f fVarU;
        String hexString;
        f fVarA;
        f fVarS;
        f fVar;
        int i3 = this.l0;
        if (i3 != i2) {
            fVarU = u(i3);
            this.l0 = i2;
        } else {
            fVarU = null;
        }
        if (this.k0 == null) {
            T();
            return;
        }
        if (this.C0) {
            T();
            return;
        }
        if (getWindowToken() == null) {
            return;
        }
        this.k0.t(this);
        int i4 = this.D0;
        int iMax = Math.max(0, this.l0 - i4);
        int iE = this.k0.e();
        int iMin = Math.min(iE - 1, this.l0 + i4);
        if (iE != this.q) {
            try {
                hexString = getResources().getResourceName(getId());
            } catch (Resources.NotFoundException unused) {
                hexString = Integer.toHexString(getId());
            }
            throw new IllegalStateException("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: " + this.q + ", found: " + iE + " Pager id: " + hexString + " Pager class: " + getClass() + " Problematic adapter: " + this.k0.getClass());
        }
        int i5 = 0;
        while (true) {
            if (i5 < this.h0.size()) {
                fVarA = this.h0.get(i5);
                int i6 = fVarA.b;
                int i7 = this.l0;
                if (i6 >= i7) {
                    if (i6 != i7) {
                        break;
                    } else {
                        break;
                    }
                }
                i5++;
            }
            fVarA = null;
            break;
        }
        if (fVarA == null && iE > 0) {
            fVarA = a(this.l0, i5);
        }
        if (fVarA != null) {
            int i8 = i5 - 1;
            f fVar2 = i8 >= 0 ? this.h0.get(i8) : null;
            int clientWidth = getClientWidth();
            float paddingLeft = clientWidth <= 0 ? 0.0f : (2.0f - fVarA.d) + (getPaddingLeft() / clientWidth);
            float f2 = 0.0f;
            for (int i9 = this.l0 - 1; i9 >= 0; i9--) {
                if (f2 < paddingLeft || i9 >= iMax) {
                    if (fVar2 == null || i9 != fVar2.b) {
                        f2 += a(i9, i8 + 1).d;
                        i5++;
                        if (i8 >= 0) {
                            fVar = this.h0.get(i8);
                        } else {
                            fVar = null;
                        }
                    } else {
                        f2 += fVar2.d;
                        i8--;
                        if (i8 >= 0) {
                            fVar = this.h0.get(i8);
                        } else {
                            fVar = null;
                        }
                    }
                    fVar2 = fVar;
                } else {
                    if (fVar2 == null) {
                        break;
                    }
                    if (i9 == fVar2.b && !fVar2.c) {
                        this.h0.remove(i8);
                        this.k0.b(this, i9, fVar2.a);
                        i8--;
                        i5--;
                        if (i8 >= 0) {
                            fVar = this.h0.get(i8);
                        } else {
                            fVar = null;
                        }
                        fVar2 = fVar;
                    }
                }
            }
            float f3 = fVarA.d;
            int i10 = i5 + 1;
            if (f3 < 2.0f) {
                f fVar3 = i10 < this.h0.size() ? this.h0.get(i10) : null;
                float paddingRight = clientWidth <= 0 ? 0.0f : (getPaddingRight() / clientWidth) + 2.0f;
                int i11 = this.l0;
                while (true) {
                    i11++;
                    if (i11 >= iE) {
                        break;
                    }
                    if (f3 >= paddingRight && i11 > iMin) {
                        if (fVar3 == null) {
                            break;
                        }
                        if (i11 == fVar3.b && !fVar3.c) {
                            this.h0.remove(i10);
                            this.k0.b(this, i11, fVar3.a);
                            if (i10 < this.h0.size()) {
                                fVar3 = this.h0.get(i10);
                            }
                        }
                    } else if (fVar3 == null || i11 != fVar3.b) {
                        f fVarA2 = a(i11, i10);
                        i10++;
                        f3 += fVarA2.d;
                        fVar3 = i10 < this.h0.size() ? this.h0.get(i10) : null;
                    } else {
                        f3 += fVar3.d;
                        i10++;
                        if (i10 < this.h0.size()) {
                            fVar3 = this.h0.get(i10);
                        }
                    }
                }
            }
            e(fVarA, i5, fVarU);
            this.k0.q(this, this.l0, fVarA.a);
        }
        this.k0.d(this);
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            g gVar = (g) childAt.getLayoutParams();
            gVar.f = i12;
            if (!gVar.a && gVar.c == 0.0f && (fVarS = s(childAt)) != null) {
                gVar.c = fVarS.d;
                gVar.e = fVarS.b;
            }
        }
        T();
        if (hasFocus()) {
            View viewFindFocus = findFocus();
            f fVarR = viewFindFocus != null ? r(viewFindFocus) : null;
            if (fVarR == null || fVarR.b != this.l0) {
                for (int i13 = 0; i13 < getChildCount(); i13++) {
                    View childAt2 = getChildAt(i13);
                    f fVarS2 = s(childAt2);
                    if (fVarS2 != null && fVarS2.b == this.l0 && childAt2.requestFocus(2)) {
                        return;
                    }
                }
            }
        }
    }

    public void I(i iVar) {
        List<i> list = this.d1;
        if (list != null) {
            list.remove(iVar);
        }
    }

    public void J(j jVar) {
        List<j> list = this.a1;
        if (list != null) {
            list.remove(jVar);
        }
    }

    public void N(int i2, boolean z) {
        this.C0 = false;
        O(i2, z, false);
    }

    void O(int i2, boolean z, boolean z2) {
        P(i2, z, z2, 0);
    }

    void P(int i2, boolean z, boolean z2, int i3) {
        androidx.viewpager.widget.a aVar = this.k0;
        if (aVar == null || aVar.e() <= 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (!z2 && this.l0 == i2 && this.h0.size() != 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i2 < 0) {
            i2 = 0;
        } else if (i2 >= this.k0.e()) {
            i2 = this.k0.e() - 1;
        }
        int i4 = this.D0;
        int i5 = this.l0;
        if (i2 > i5 + i4 || i2 < i5 - i4) {
            for (int i6 = 0; i6 < this.h0.size(); i6++) {
                this.h0.get(i6).c = true;
            }
        }
        boolean z3 = this.l0 != i2;
        if (!this.W0) {
            F(i2);
            M(i2, z, i3, z3);
        } else {
            this.l0 = i2;
            if (z3) {
                k(i2);
            }
            requestLayout();
        }
    }

    public void Q(boolean z, k kVar) {
        R(z, kVar, 2);
    }

    public void R(boolean z, k kVar, int i2) {
        boolean z2 = kVar != null;
        boolean z3 = z2 != (this.e1 != null);
        this.e1 = kVar;
        setChildrenDrawingOrderEnabled(z2);
        if (z2) {
            this.g1 = z ? 2 : 1;
            this.f1 = i2;
        } else {
            this.g1 = 0;
        }
        if (z3) {
            E();
        }
    }

    void S(int i2, int i3, int i4) {
        int scrollX;
        int iAbs;
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        Scroller scroller = this.p0;
        if (scroller == null || scroller.isFinished()) {
            scrollX = getScrollX();
        } else {
            scrollX = this.q0 ? this.p0.getCurrX() : this.p0.getStartX();
            this.p0.abortAnimation();
            setScrollingCacheEnabled(false);
        }
        int i5 = scrollX;
        int scrollY = getScrollY();
        int i6 = i2 - i5;
        int i7 = i3 - scrollY;
        if (i6 == 0 && i7 == 0) {
            g(false);
            E();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int clientWidth = getClientWidth();
        int i8 = clientWidth / 2;
        float f2 = clientWidth;
        float f3 = i8;
        float fM = f3 + (m(Math.min(1.0f, (Math.abs(i6) * 1.0f) / f2)) * f3);
        int iAbs2 = Math.abs(i4);
        if (iAbs2 > 0) {
            iAbs = Math.round(Math.abs(fM / iAbs2) * 1000.0f) * 4;
        } else {
            iAbs = (int) (((Math.abs(i6) / ((f2 * this.k0.h(this.l0)) + this.s0)) + 1.0f) * 100.0f);
        }
        int iMin = Math.min(iAbs, 600);
        this.q0 = false;
        this.p0.startScroll(i5, scrollY, i6, i7, iMin);
        Y.h0(this);
    }

    f a(int i2, int i3) {
        f fVar = new f();
        fVar.b = i2;
        fVar.a = this.k0.j(this, i2);
        fVar.d = this.k0.h(i2);
        if (i3 < 0 || i3 >= this.h0.size()) {
            this.h0.add(fVar);
        } else {
            this.h0.add(i3, fVar);
        }
        return fVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        f fVarS;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i4 = 0; i4 < getChildCount(); i4++) {
                View childAt = getChildAt(i4);
                if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.l0) {
                    childAt.addFocusables(arrayList, i2, i3);
                }
            }
        }
        if ((descendantFocusability != 262144 || size == arrayList.size()) && isFocusable()) {
            if ((i3 & 1) == 1 && isInTouchMode() && !isFocusableInTouchMode()) {
                return;
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addTouchables(ArrayList<View> arrayList) {
        f fVarS;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.l0) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        g gVar = (g) layoutParams;
        boolean zW = gVar.a | w(view);
        gVar.a = zW;
        if (!this.A0) {
            super.addView(view, i2, layoutParams);
        } else {
            if (zW) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            gVar.d = true;
            addViewInLayout(view, i2, layoutParams);
        }
    }

    public void b(i iVar) {
        if (this.d1 == null) {
            this.d1 = new ArrayList();
        }
        this.d1.add(iVar);
    }

    public void c(j jVar) {
        if (this.a1 == null) {
            this.a1 = new ArrayList();
        }
        this.a1.add(jVar);
    }

    @Override // android.view.View
    public boolean canScrollHorizontally(int i2) {
        if (this.k0 == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        if (i2 < 0) {
            return scrollX > ((int) (((float) clientWidth) * this.w0));
        }
        return i2 > 0 && scrollX < ((int) (((float) clientWidth) * this.x0));
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof g) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        this.q0 = true;
        if (this.p0.isFinished() || !this.p0.computeScrollOffset()) {
            g(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.p0.getCurrX();
        int currY = this.p0.getCurrY();
        if (scrollX != currX || scrollY != currY) {
            scrollTo(currX, currY);
            if (!C(currX)) {
                this.p0.abortAnimation();
                scrollTo(0, currY);
            }
        }
        Y.h0(this);
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00bf  */
    public boolean d(int i2) {
        boolean zA;
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
            break;
        }
        if (viewFindFocus != null) {
            ViewParent parent = viewFindFocus.getParent();
            while (true) {
                if (!(parent instanceof ViewGroup)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(viewFindFocus.getClass().getSimpleName());
                    for (ViewParent parent2 = viewFindFocus.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                        sb.append(" => ");
                        sb.append(parent2.getClass().getSimpleName());
                    }
                    Log.e("ViewPager", "arrowScroll tried to find focus based on non-child current focused view " + sb.toString());
                    viewFindFocus = null;
                    break;
                }
                if (parent == this) {
                    break;
                }
                parent = parent.getParent();
            }
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i2);
        if (viewFindNextFocus == null || viewFindNextFocus == viewFindFocus) {
            if (i2 == 17 || i2 == 1) {
                zA = A();
            } else if (i2 == 66 || i2 == 2) {
                zA = B();
            } else {
                zA = false;
            }
        } else if (i2 == 17) {
            zA = (viewFindFocus == null || q(this.j0, viewFindNextFocus).left < q(this.j0, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : A();
        } else if (i2 == 66) {
            zA = (viewFindFocus == null || q(this.j0, viewFindNextFocus).left > q(this.j0, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : B();
        } else {
            zA = false;
        }
        if (zA) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i2));
        }
        return zA;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || p(keyEvent);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        f fVarS;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.l0 && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        androidx.viewpager.widget.a aVar;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean zDraw = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (aVar = this.k0) != null && aVar.e() > 1)) {
            if (!this.U0.isFinished()) {
                int iSave = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((-height) + getPaddingTop(), this.w0 * width);
                this.U0.setSize(height, width);
                zDraw = this.U0.draw(canvas);
                canvas.restoreToCount(iSave);
            }
            if (!this.V0.isFinished()) {
                int iSave2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate(-getPaddingTop(), (-(this.x0 + 1.0f)) * width2);
                this.V0.setSize(height2, width2);
                zDraw |= this.V0.draw(canvas);
                canvas.restoreToCount(iSave2);
            }
        } else {
            this.U0.finish();
            this.V0.finish();
        }
        if (zDraw) {
            Y.h0(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.t0;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        drawable.setState(getDrawableState());
    }

    protected boolean f(View view, boolean z, int i2, int i3, int i4) {
        int i5;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i3 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i5 = i4 + scrollY) >= childAt.getTop() && i5 < childAt.getBottom() && f(childAt, true, i2, i6 - childAt.getLeft(), i5 - childAt.getTop())) {
                    return true;
                }
            }
        }
        return z && view.canScrollHorizontally(-i2);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new g();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public androidx.viewpager.widget.a getAdapter() {
        return this.k0;
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        if (this.g1 == 2) {
            i3 = (i2 - 1) - i3;
        }
        return ((g) this.h1.get(i3).getLayoutParams()).f;
    }

    public int getCurrentItem() {
        return this.l0;
    }

    public int getOffscreenPageLimit() {
        return this.D0;
    }

    public int getPageMargin() {
        return this.s0;
    }

    void h() {
        int iE = this.k0.e();
        this.q = iE;
        boolean z = this.h0.size() < (this.D0 * 2) + 1 && this.h0.size() < iE;
        int iMax = this.l0;
        int i2 = 0;
        boolean z2 = false;
        while (i2 < this.h0.size()) {
            f fVar = this.h0.get(i2);
            int iF = this.k0.f(fVar.a);
            if (iF != -1) {
                if (iF == -2) {
                    this.h0.remove(i2);
                    i2--;
                    if (!z2) {
                        this.k0.t(this);
                        z2 = true;
                    }
                    this.k0.b(this, fVar.b, fVar.a);
                    int i3 = this.l0;
                    if (i3 == fVar.b) {
                        iMax = Math.max(0, Math.min(i3, iE - 1));
                    }
                } else {
                    int i4 = fVar.b;
                    if (i4 != iF) {
                        if (i4 == this.l0) {
                            iMax = iF;
                        }
                        fVar.b = iF;
                    }
                }
                z = true;
            }
            i2++;
        }
        if (z2) {
            this.k0.d(this);
        }
        Collections.sort(this.h0, l1);
        if (z) {
            int childCount = getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                g gVar = (g) getChildAt(i5).getLayoutParams();
                if (!gVar.a) {
                    gVar.c = 0.0f;
                }
            }
            O(iMax, false, true);
            requestLayout();
        }
    }

    float m(float f2) {
        return (float) Math.sin((f2 - 0.5f) * 0.47123894f);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.W0 = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.i1);
        Scroller scroller = this.p0;
        if (scroller != null && !scroller.isFinished()) {
            this.p0.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        int i2;
        float f2;
        super.onDraw(canvas);
        if (this.s0 <= 0 || this.t0 == null || this.h0.size() <= 0 || this.k0 == null) {
            return;
        }
        int scrollX = getScrollX();
        int width = getWidth();
        float f3 = width;
        float f4 = this.s0 / f3;
        int i3 = 0;
        f fVar = this.h0.get(0);
        float f5 = fVar.e;
        int size = this.h0.size();
        int i4 = fVar.b;
        int i5 = this.h0.get(size - 1).b;
        while (i4 < i5) {
            while (true) {
                i2 = fVar.b;
                if (i4 <= i2 || i3 >= size) {
                    break;
                }
                i3++;
                fVar = this.h0.get(i3);
            }
            if (i4 == i2) {
                float f6 = fVar.e;
                float f7 = fVar.d;
                f2 = (f6 + f7) * f3;
                f5 = f6 + f7 + f4;
            } else {
                float fH = this.k0.h(i4);
                f2 = (f5 + fH) * f3;
                f5 += fH + f4;
            }
            if (this.s0 + f2 > scrollX) {
                this.t0.setBounds(Math.round(f2), this.u0, Math.round(this.s0 + f2), this.v0);
                this.t0.draw(canvas);
            }
            if (f2 > scrollX + width) {
                return;
            }
            i4++;
            f4 = f4;
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            L();
            return false;
        }
        if (action != 0) {
            if (this.E0) {
                return true;
            }
            if (this.F0) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent.getX();
            this.L0 = x;
            this.J0 = x;
            float y = motionEvent.getY();
            this.M0 = y;
            this.K0 = y;
            this.N0 = motionEvent.getPointerId(0);
            this.F0 = false;
            this.q0 = true;
            this.p0.computeScrollOffset();
            if (this.j1 != 2 || Math.abs(this.p0.getFinalX() - this.p0.getCurrX()) <= this.S0) {
                g(false);
                this.E0 = false;
            } else {
                this.p0.abortAnimation();
                this.C0 = false;
                E();
                this.E0 = true;
                K(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i2 = this.N0;
            if (i2 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i2);
                float x2 = motionEvent.getX(iFindPointerIndex);
                float f2 = x2 - this.J0;
                float fAbs = Math.abs(f2);
                float y2 = motionEvent.getY(iFindPointerIndex);
                float fAbs2 = Math.abs(y2 - this.M0);
                if (f2 != 0.0f && !x(this.J0, f2) && f(this, false, (int) f2, (int) x2, (int) y2)) {
                    this.J0 = x2;
                    this.K0 = y2;
                    this.F0 = true;
                    return false;
                }
                int i3 = this.I0;
                if (fAbs > i3 && fAbs * 0.5f > fAbs2) {
                    this.E0 = true;
                    K(true);
                    setScrollState(1);
                    float f3 = this.L0;
                    float f4 = this.I0;
                    this.J0 = f2 > 0.0f ? f3 + f4 : f3 - f4;
                    this.K0 = y2;
                    setScrollingCacheEnabled(true);
                } else if (fAbs2 > i3) {
                    this.F0 = true;
                }
                if (this.E0 && D(x2)) {
                    Y.h0(this);
                }
            }
        } else if (action == 6) {
            z(motionEvent);
        }
        if (this.O0 == null) {
            this.O0 = VelocityTracker.obtain();
        }
        this.O0.addMovement(motionEvent);
        return this.E0;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0072  */
    /* JADX WARN: Code duplicated, block: B:24:0x0076  */
    /* JADX WARN: Code duplicated, block: B:26:0x007a  */
    /* JADX WARN: Code duplicated, block: B:27:0x007c  */
    /* JADX WARN: Code duplicated, block: B:29:0x008e  */
    /* JADX WARN: Code duplicated, block: B:30:0x0094  */
    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        boolean z2;
        f fVarS;
        int iMax;
        int measuredWidth;
        int iMax2;
        int measuredHeight;
        int childCount = getChildCount();
        int i6 = i4 - i2;
        int i7 = i5 - i3;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a) {
                    int i10 = gVar.b;
                    int i11 = i10 & 7;
                    int i12 = i10 & 112;
                    if (i11 != 1) {
                        if (i11 == 3) {
                            measuredWidth = childAt.getMeasuredWidth() + paddingLeft;
                        } else if (i11 != 5) {
                            measuredWidth = paddingLeft;
                        } else {
                            iMax = (i6 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        if (i12 != 16) {
                            if (i12 != 48) {
                                measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                            } else if (i12 != 80) {
                                measuredHeight = paddingTop;
                            } else {
                                iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                                paddingBottom += childAt.getMeasuredHeight();
                            }
                            int i13 = paddingLeft + scrollX;
                            childAt.layout(i13, paddingTop, childAt.getMeasuredWidth() + i13, paddingTop + childAt.getMeasuredHeight());
                            i8++;
                            paddingTop = measuredHeight;
                            paddingLeft = measuredWidth;
                        } else {
                            iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                        }
                        int i14 = iMax2;
                        measuredHeight = paddingTop;
                        paddingTop = i14;
                        int i15 = paddingLeft + scrollX;
                        childAt.layout(i15, paddingTop, childAt.getMeasuredWidth() + i15, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax = Math.max((i6 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i16 = iMax;
                    measuredWidth = paddingLeft;
                    paddingLeft = i16;
                    if (i12 != 16) {
                        if (i12 != 48) {
                            measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                        } else if (i12 != 80) {
                            measuredHeight = paddingTop;
                        } else {
                            iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                            paddingBottom += childAt.getMeasuredHeight();
                        }
                        int i17 = paddingLeft + scrollX;
                        childAt.layout(i17, paddingTop, childAt.getMeasuredWidth() + i17, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                    }
                    int i18 = iMax2;
                    measuredHeight = paddingTop;
                    paddingTop = i18;
                    int i19 = paddingLeft + scrollX;
                    childAt.layout(i19, paddingTop, childAt.getMeasuredWidth() + i19, paddingTop + childAt.getMeasuredHeight());
                    i8++;
                    paddingTop = measuredHeight;
                    paddingLeft = measuredWidth;
                }
            }
        }
        int i20 = (i6 - paddingLeft) - paddingRight;
        for (int i21 = 0; i21 < childCount; i21++) {
            View childAt2 = getChildAt(i21);
            if (childAt2.getVisibility() != 8) {
                g gVar2 = (g) childAt2.getLayoutParams();
                if (!gVar2.a && (fVarS = s(childAt2)) != null) {
                    float f2 = i20;
                    int i22 = ((int) (fVarS.e * f2)) + paddingLeft;
                    if (gVar2.d) {
                        gVar2.d = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f2 * gVar2.c), 1073741824), View.MeasureSpec.makeMeasureSpec((i7 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i22, paddingTop, childAt2.getMeasuredWidth() + i22, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.u0 = paddingTop;
        this.v0 = i7 - paddingBottom;
        this.Z0 = i8;
        if (this.W0) {
            z2 = false;
            M(this.l0, false, 0, false);
        } else {
            z2 = false;
        }
        this.W0 = z2;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0081 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x0086  */
    /* JADX WARN: Code duplicated, block: B:35:0x0088  */
    /* JADX WARN: Code duplicated, block: B:38:0x008d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:40:0x0090  */
    /* JADX WARN: Code duplicated, block: B:41:0x0092  */
    /* JADX WARN: Code duplicated, block: B:44:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:45:0x00a7 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:46:0x00a9  */
    /* JADX WARN: Code duplicated, block: B:65:0x00ae A[SYNTHETIC] */
    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        g gVar;
        g gVar2;
        int i4;
        int i5;
        int i6;
        setMeasuredDimension(View.getDefaultSize(0, i2), View.getDefaultSize(0, i3));
        int measuredWidth = getMeasuredWidth();
        this.H0 = Math.min(measuredWidth / 10, this.G0);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        int i7 = 0;
        while (true) {
            boolean z = true;
            int i8 = 1073741824;
            if (i7 >= childCount) {
                break;
            }
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8 && (gVar2 = (g) childAt.getLayoutParams()) != null && gVar2.a) {
                int i9 = gVar2.b;
                int i10 = i9 & 7;
                int i11 = i9 & 112;
                boolean z2 = i11 == 48 || i11 == 80;
                if (i10 != 3 && i10 != 5) {
                    z = false;
                }
                int i12 = Integer.MIN_VALUE;
                if (z2) {
                    i12 = 1073741824;
                } else {
                    i4 = z ? 1073741824 : Integer.MIN_VALUE;
                    i5 = ((ViewGroup.LayoutParams) gVar2).width;
                    if (i5 != -2) {
                        if (i5 == -1) {
                            i5 = paddingLeft;
                        }
                        i12 = 1073741824;
                    } else {
                        i5 = paddingLeft;
                    }
                    i6 = ((ViewGroup.LayoutParams) gVar2).height;
                    if (i6 != -2) {
                        i6 = measuredHeight;
                        i8 = i4;
                    } else if (i6 == -1) {
                        i6 = measuredHeight;
                    }
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                    if (z2) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (z) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
                i5 = ((ViewGroup.LayoutParams) gVar2).width;
                if (i5 != -2) {
                    if (i5 == -1) {
                        i5 = paddingLeft;
                    }
                    i12 = 1073741824;
                } else {
                    i5 = paddingLeft;
                }
                i6 = ((ViewGroup.LayoutParams) gVar2).height;
                if (i6 != -2) {
                    i6 = measuredHeight;
                    i8 = i4;
                } else if (i6 == -1) {
                    i6 = measuredHeight;
                }
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i5, i12), View.MeasureSpec.makeMeasureSpec(i6, i8));
                if (z2) {
                    measuredHeight -= childAt.getMeasuredHeight();
                } else if (z) {
                    paddingLeft -= childAt.getMeasuredWidth();
                }
            }
            i7++;
        }
        this.y0 = View.MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.z0 = View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.A0 = true;
        E();
        this.A0 = false;
        int childCount2 = getChildCount();
        for (int i13 = 0; i13 < childCount2; i13++) {
            View childAt2 = getChildAt(i13);
            if (childAt2.getVisibility() != 8 && ((gVar = (g) childAt2.getLayoutParams()) == null || !gVar.a)) {
                childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (paddingLeft * gVar.c), 1073741824), this.z0);
            }
        }
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i2, Rect rect) {
        int i3;
        int i4;
        int i5;
        f fVarS;
        int childCount = getChildCount();
        if ((i2 & 2) != 0) {
            i4 = childCount;
            i3 = 0;
            i5 = 1;
        } else {
            i3 = childCount - 1;
            i4 = -1;
            i5 = -1;
        }
        while (i3 != i4) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (fVarS = s(childAt)) != null && fVarS.b == this.l0 && childAt.requestFocus(i2, rect)) {
                return true;
            }
            i3 += i5;
        }
        return false;
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof m)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        m mVar = (m) parcelable;
        super.onRestoreInstanceState(mVar.a());
        androidx.viewpager.widget.a aVar = this.k0;
        if (aVar != null) {
            aVar.n(mVar.Z, mVar.h0);
            O(mVar.Y, false, true);
        } else {
            this.m0 = mVar.Y;
            this.n0 = mVar.Z;
            this.o0 = mVar.h0;
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        m mVar = new m(super.onSaveInstanceState());
        mVar.Y = this.l0;
        androidx.viewpager.widget.a aVar = this.k0;
        if (aVar != null) {
            mVar.Z = aVar.o();
        }
        return mVar;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4) {
            int i6 = this.s0;
            G(i2, i4, i6, i6);
        }
    }

    /* JADX WARN: Code duplicated, block: B:53:0x00dc  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        androidx.viewpager.widget.a aVar;
        if (this.T0) {
            return true;
        }
        boolean zL = false;
        if ((motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) || (aVar = this.k0) == null || aVar.e() == 0) {
            return false;
        }
        if (this.O0 == null) {
            this.O0 = VelocityTracker.obtain();
        }
        this.O0.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.p0.abortAnimation();
            this.C0 = false;
            E();
            float x = motionEvent.getX();
            this.L0 = x;
            this.J0 = x;
            float y = motionEvent.getY();
            this.M0 = y;
            this.K0 = y;
            this.N0 = motionEvent.getPointerId(0);
        } else if (action != 1) {
            if (action != 2) {
                if (action != 3) {
                    if (action == 5) {
                        int actionIndex = motionEvent.getActionIndex();
                        this.J0 = motionEvent.getX(actionIndex);
                        this.N0 = motionEvent.getPointerId(actionIndex);
                    } else if (action == 6) {
                        z(motionEvent);
                        this.J0 = motionEvent.getX(motionEvent.findPointerIndex(this.N0));
                    }
                } else if (this.E0) {
                    M(this.l0, true, 0, false);
                    zL = L();
                }
            } else if (!this.E0) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.N0);
                if (iFindPointerIndex == -1) {
                    zL = L();
                } else {
                    float x2 = motionEvent.getX(iFindPointerIndex);
                    float fAbs = Math.abs(x2 - this.J0);
                    float y2 = motionEvent.getY(iFindPointerIndex);
                    float fAbs2 = Math.abs(y2 - this.K0);
                    if (fAbs > this.I0 && fAbs > fAbs2) {
                        this.E0 = true;
                        K(true);
                        float f2 = this.L0;
                        this.J0 = x2 - f2 > 0.0f ? f2 + this.I0 : f2 - this.I0;
                        this.K0 = y2;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    if (this.E0) {
                        zL = D(motionEvent.getX(motionEvent.findPointerIndex(this.N0)));
                    }
                }
            } else if (this.E0) {
                zL = D(motionEvent.getX(motionEvent.findPointerIndex(this.N0)));
            }
        } else if (this.E0) {
            VelocityTracker velocityTracker = this.O0;
            velocityTracker.computeCurrentVelocity(1000, this.Q0);
            int xVelocity = (int) velocityTracker.getXVelocity(this.N0);
            this.C0 = true;
            int clientWidth = getClientWidth();
            int scrollX = getScrollX();
            f fVarT = t();
            float f3 = clientWidth;
            P(i(fVarT.b, ((scrollX / f3) - fVarT.e) / (fVarT.d + (this.s0 / f3)), xVelocity, (int) (motionEvent.getX(motionEvent.findPointerIndex(this.N0)) - this.L0)), true, true, xVelocity);
            zL = L();
        }
        if (zL) {
            Y.h0(this);
        }
        return true;
    }

    public boolean p(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 21) {
                return keyEvent.hasModifiers(2) ? A() : d(17);
            }
            if (keyCode == 22) {
                return keyEvent.hasModifiers(2) ? B() : d(66);
            }
            if (keyCode == 61) {
                if (keyEvent.hasNoModifiers()) {
                    return d(2);
                }
                if (keyEvent.hasModifiers(1)) {
                    return d(1);
                }
            }
        }
        return false;
    }

    f r(View view) {
        while (true) {
            Object parent = view.getParent();
            if (parent == this) {
                return s(view);
            }
            if (parent == null || !(parent instanceof View)) {
                return null;
            }
            view = (View) parent;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        if (this.A0) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    f s(View view) {
        for (int i2 = 0; i2 < this.h0.size(); i2++) {
            f fVar = this.h0.get(i2);
            if (this.k0.k(view, fVar.a)) {
                return fVar;
            }
        }
        return null;
    }

    public void setAdapter(androidx.viewpager.widget.a aVar) {
        androidx.viewpager.widget.a aVar2 = this.k0;
        if (aVar2 != null) {
            aVar2.r(null);
            this.k0.t(this);
            for (int i2 = 0; i2 < this.h0.size(); i2++) {
                f fVar = this.h0.get(i2);
                this.k0.b(this, fVar.b, fVar.a);
            }
            this.k0.d(this);
            this.h0.clear();
            H();
            this.l0 = 0;
            scrollTo(0, 0);
        }
        androidx.viewpager.widget.a aVar3 = this.k0;
        this.k0 = aVar;
        this.q = 0;
        if (aVar != null) {
            if (this.r0 == null) {
                this.r0 = new l();
            }
            this.k0.r(this.r0);
            this.C0 = false;
            boolean z = this.W0;
            this.W0 = true;
            this.q = this.k0.e();
            if (this.m0 >= 0) {
                this.k0.n(this.n0, this.o0);
                O(this.m0, false, true);
                this.m0 = -1;
                this.n0 = null;
                this.o0 = null;
            } else if (z) {
                requestLayout();
            } else {
                E();
            }
        }
        List<i> list = this.d1;
        if (list == null || list.isEmpty()) {
            return;
        }
        int size = this.d1.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.d1.get(i3).a(this, aVar3, aVar);
        }
    }

    public void setCurrentItem(int i2) {
        this.C0 = false;
        O(i2, !this.W0, false);
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i2 + " too small; defaulting to 1");
            i2 = 1;
        }
        if (i2 != this.D0) {
            this.D0 = i2;
            E();
        }
    }

    @Deprecated
    public void setOnPageChangeListener(j jVar) {
        this.b1 = jVar;
    }

    public void setPageMargin(int i2) {
        int i3 = this.s0;
        this.s0 = i2;
        int width = getWidth();
        G(width, width, i2, i3);
        requestLayout();
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.t0 = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    void setScrollState(int i2) {
        if (this.j1 == i2) {
            return;
        }
        this.j1 = i2;
        if (this.e1 != null) {
            n(i2 != 0);
        }
        l(i2);
    }

    f u(int i2) {
        for (int i3 = 0; i3 < this.h0.size(); i3++) {
            f fVar = this.h0.get(i3);
            if (fVar.b == i2) {
                return fVar;
            }
        }
        return null;
    }

    void v() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.p0 = new Scroller(context, m1);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.I0 = viewConfiguration.getScaledPagingTouchSlop();
        this.P0 = (int) (400.0f * f2);
        this.Q0 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.U0 = new EdgeEffect(context);
        this.V0 = new EdgeEffect(context);
        this.R0 = (int) (25.0f * f2);
        this.S0 = (int) (2.0f * f2);
        this.G0 = (int) (f2 * 16.0f);
        Y.q0(this, new h());
        if (Y.A(this) == 0) {
            Y.A0(this, 1);
        }
        Y.E0(this, new d());
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.t0;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0065  */
    protected void y(int i2, float f2, int i3) {
        int iMax;
        int width;
        int left;
        if (this.Z0 > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width2 = getWidth();
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a) {
                    int i5 = gVar.b & 7;
                    if (i5 != 1) {
                        if (i5 == 3) {
                            width = childAt.getWidth() + paddingLeft;
                        } else if (i5 != 5) {
                            width = paddingLeft;
                        } else {
                            iMax = (width2 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        left = (paddingLeft + scrollX) - childAt.getLeft();
                        if (left != 0) {
                            childAt.offsetLeftAndRight(left);
                        }
                        paddingLeft = width;
                    } else {
                        iMax = Math.max((width2 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i6 = iMax;
                    width = paddingLeft;
                    paddingLeft = i6;
                    left = (paddingLeft + scrollX) - childAt.getLeft();
                    if (left != 0) {
                        childAt.offsetLeftAndRight(left);
                    }
                    paddingLeft = width;
                }
            }
        }
        j(i2, f2, i3);
        if (this.e1 != null) {
            int scrollX2 = getScrollX();
            int childCount2 = getChildCount();
            for (int i7 = 0; i7 < childCount2; i7++) {
                View childAt2 = getChildAt(i7);
                if (!((g) childAt2.getLayoutParams()).a) {
                    this.e1.a(childAt2, (childAt2.getLeft() - scrollX2) / getClientWidth());
                }
            }
        }
        this.Y0 = true;
    }

    public static class g extends ViewGroup.LayoutParams {
        public boolean a;
        public int b;
        float c;
        boolean d;
        int e;
        int f;

        public g() {
            super(-1, -1);
            this.c = 0.0f;
        }

        public g(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.c = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.k1);
            this.b = typedArrayObtainStyledAttributes.getInteger(0, 48);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    public void setPageMarginDrawable(int i2) {
        setPageMarginDrawable(ax.P.b.e(getContext(), i2));
    }
}
