package androidx.work;

import ax.F2.f;
import ax.p335uc.l;
import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class ArrayCreatingInputMerger extends f {
    private final Object c(Object obj, Object obj2, Class<?> cls) {
        int length = Array.getLength(obj);
        Object objNewInstance = Array.newInstance(cls, length + 1);
        System.arraycopy(obj, 0, objNewInstance, 0, length);
        Array.set(objNewInstance, length, obj2);
        l.e(objNewInstance, "newArray");
        return objNewInstance;
    }

    private final Object d(Object obj, Object obj2) {
        int length = Array.getLength(obj);
        int length2 = Array.getLength(obj2);
        Class<?> componentType = obj.getClass().getComponentType();
        l.c(componentType);
        Object objNewInstance = Array.newInstance(componentType, length + length2);
        System.arraycopy(obj, 0, objNewInstance, 0, length);
        System.arraycopy(obj2, 0, objNewInstance, length, length2);
        l.e(objNewInstance, "newArray");
        return objNewInstance;
    }

    private final Object e(Object obj, Class<?> cls) {
        Object objNewInstance = Array.newInstance(cls, 1);
        Array.set(objNewInstance, 0, obj);
        l.e(objNewInstance, "newArray");
        return objNewInstance;
    }

    @Override // ax.F2.f
    public b b(List<b> list) throws Throwable {
        l.f(list, "inputs");
        b.a aVar = new b.a();
        HashMap map = new HashMap();
        Iterator<b> it = list.iterator();
        while (it.hasNext()) {
            Map<String, Object> mapH = it.next().h();
            l.e(mapH, "input.keyValueMap");
            for (Map.Entry<String, Object> entry : mapH.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                Class<?> cls = value != null ? value.getClass() : String.class;
                Object obj = map.get(key);
                l.e(key, "key");
                if (obj != null) {
                    Class<?> cls2 = obj.getClass();
                    if (l.a(cls2, cls)) {
                        l.e(value, "value");
                        value = d(obj, value);
                    } else {
                        if (!l.a(cls2.getComponentType(), cls)) {
                            throw new IllegalArgumentException();
                        }
                        value = c(obj, value, cls);
                    }
                } else if (!cls.isArray()) {
                    value = e(value, cls);
                }
                l.e(value, "if (existingValue == nul…      }\n                }");
                map.put(key, value);
            }
        }
        aVar.d(map);
        b bVarA = aVar.a();
        l.e(bVarA, "output.build()");
        return bVarA;
    }
}
