package androidx.work;

import android.content.Context;
import android.net.Network;
import android.net.Uri;
import ax.F2.d;
import ax.F2.t;
import ax.p043c8.e;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    private WorkerParameters X;
    private volatile boolean Y;
    private boolean Z;
    private Context q;

    public static abstract class a {

        /* JADX INFO: renamed from: androidx.work.c$a$a, reason: collision with other inner class name */
        public static final class C0048a extends a {
            private final androidx.work.b a;

            public C0048a() {
                this(androidx.work.b.c);
            }

            public C0048a(androidx.work.b bVar) {
                this.a = bVar;
            }

            public androidx.work.b e() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || C0048a.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((C0048a) obj).a);
            }

            public int hashCode() {
                return (C0048a.class.getName().hashCode() * 31) + this.a.hashCode();
            }

            public String toString() {
                return "Failure {mOutputData=" + this.a + '}';
            }
        }

        public static final class b extends a {
            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return obj != null && b.class == obj.getClass();
            }

            public int hashCode() {
                return b.class.getName().hashCode();
            }

            public String toString() {
                return "Retry";
            }
        }

        /* JADX INFO: renamed from: androidx.work.c$a$c, reason: collision with other inner class name */
        public static final class C0049c extends a {
            private final androidx.work.b a;

            public C0049c() {
                this(androidx.work.b.c);
            }

            public C0049c(androidx.work.b bVar) {
                this.a = bVar;
            }

            public androidx.work.b e() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || C0049c.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((C0049c) obj).a);
            }

            public int hashCode() {
                return (C0049c.class.getName().hashCode() * 31) + this.a.hashCode();
            }

            public String toString() {
                return "Success {mOutputData=" + this.a + '}';
            }
        }

        a() {
        }

        public static a a() {
            return new C0048a();
        }

        public static a b() {
            return new b();
        }

        public static a c() {
            return new C0049c();
        }

        public static a d(androidx.work.b bVar) {
            return new C0049c(bVar);
        }
    }

    public c(Context context, WorkerParameters workerParameters) {
        if (context == null) {
            throw new IllegalArgumentException("Application Context is null");
        }
        if (workerParameters == null) {
            throw new IllegalArgumentException("WorkerParameters is null");
        }
        this.q = context;
        this.X = workerParameters;
    }

    public final Context getApplicationContext() {
        return this.q;
    }

    public Executor getBackgroundExecutor() {
        return this.X.a();
    }

    public e<d> getForegroundInfoAsync() {
        ax.Q2.c cVarU = ax.Q2.c.u();
        cVarU.r(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
        return cVarU;
    }

    public final UUID getId() {
        return this.X.c();
    }

    public final b getInputData() {
        return this.X.d();
    }

    public final Network getNetwork() {
        return this.X.e();
    }

    public final int getRunAttemptCount() {
        return this.X.g();
    }

    public final Set<String> getTags() {
        return this.X.h();
    }

    public ax.R2.c getTaskExecutor() {
        return this.X.i();
    }

    public final List<String> getTriggeredContentAuthorities() {
        return this.X.j();
    }

    public final List<Uri> getTriggeredContentUris() {
        return this.X.k();
    }

    public t getWorkerFactory() {
        return this.X.l();
    }

    public final boolean isStopped() {
        return this.Y;
    }

    public final boolean isUsed() {
        return this.Z;
    }

    public void onStopped() {
    }

    public final e<Void> setForegroundAsync(d dVar) {
        return this.X.b().a(getApplicationContext(), getId(), dVar);
    }

    public e<Void> setProgressAsync(b bVar) {
        return this.X.f().a(getApplicationContext(), getId(), bVar);
    }

    public final void setUsed() {
        this.Z = true;
    }

    public abstract e<a> startWork();

    public final void stop() {
        this.Y = true;
        onStopped();
    }
}
