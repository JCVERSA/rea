package androidx.work;

import android.os.Build;
import ax.p170m1.g;
import ax.p170m1.i;
import ax.p170m1.q;
import ax.p170m1.v;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    final Executor a;
    final Executor b;
    final v c;
    final i d;
    final q e;
    final g f;
    final String g;
    final int h;
    final int i;
    final int j;
    final int k;
    private final boolean l;

    /* JADX INFO: renamed from: androidx.work.a$a, reason: collision with other inner class name */
    class ThreadFactoryC0047a implements ThreadFactory {
        private final AtomicInteger a = new AtomicInteger(0);
        final /* synthetic */ boolean b;

        ThreadFactoryC0047a(boolean z) {
            this.b = z;
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, (this.b ? "WM.task-" : "androidx.work-") + this.a.incrementAndGet());
        }
    }

    public static final class b {
        Executor a;
        v b;
        i c;
        Executor d;
        q e;
        g f;
        String g;
        int h = 4;
        int i = 0;
        int j = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        int k = 20;

        public a a() {
            return new a(this);
        }

        public b b(g gVar) {
            this.f = gVar;
            return this;
        }

        public b c(int i, int i2) {
            if (i2 - i < 1000) {
                throw new IllegalArgumentException("WorkManager needs a range of at least 1000 job ids.");
            }
            this.i = i;
            this.j = i2;
            return this;
        }
    }

    public interface c {
        a a();
    }

    a(b bVar) {
        Executor executor = bVar.a;
        if (executor == null) {
            this.a = a(false);
        } else {
            this.a = executor;
        }
        Executor executor2 = bVar.d;
        if (executor2 == null) {
            this.l = true;
            this.b = a(true);
        } else {
            this.l = false;
            this.b = executor2;
        }
        v vVar = bVar.b;
        if (vVar == null) {
            this.c = v.c();
        } else {
            this.c = vVar;
        }
        i iVar = bVar.c;
        if (iVar == null) {
            this.d = i.c();
        } else {
            this.d = iVar;
        }
        q qVar = bVar.e;
        if (qVar == null) {
            this.e = new ax.p184n1.a();
        } else {
            this.e = qVar;
        }
        this.h = bVar.h;
        this.i = bVar.i;
        this.j = bVar.j;
        this.k = bVar.k;
        this.f = bVar.f;
        this.g = bVar.g;
    }

    private Executor a(boolean z) {
        return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), b(z));
    }

    private ThreadFactory b(boolean z) {
        return new ThreadFactoryC0047a(z);
    }

    public String c() {
        return this.g;
    }

    public g d() {
        return this.f;
    }

    public Executor e() {
        return this.a;
    }

    public i f() {
        return this.d;
    }

    public int g() {
        return this.j;
    }

    public int h() {
        return Build.VERSION.SDK_INT == 23 ? this.k / 2 : this.k;
    }

    public int i() {
        return this.i;
    }

    public int j() {
        return this.h;
    }

    public q k() {
        return this.e;
    }

    public Executor l() {
        return this.b;
    }

    public v m() {
        return this.c;
    }
}
