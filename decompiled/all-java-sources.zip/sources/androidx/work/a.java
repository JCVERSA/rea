package androidx.work;

import android.os.Build;
import ax.F2.g;
import ax.F2.o;
import ax.F2.t;
import ax.G2.C0826d;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    final Executor a;
    final Executor b;
    final t c;
    final g d;
    final o e;
    final ax.p019b0.a<Throwable> f;
    final ax.p019b0.a<Throwable> g;
    final String h;
    final int i;
    final int j;
    final int k;
    final int l;
    private final boolean m;

    /* JADX INFO: renamed from: androidx.work.a$a, reason: collision with other inner class name */
    class ThreadFactoryC0047a implements ThreadFactory {
        private final AtomicInteger a = new AtomicInteger(0);
        final /* synthetic */ boolean b;

        ThreadFactoryC0047a(boolean z) {
            this.b = z;
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, (this.b ? "WM.task-" : "androidx.work-") + this.a.incrementAndGet());
        }
    }

    public static final class b {
        Executor a;
        t b;
        g c;
        Executor d;
        o e;
        ax.p019b0.a<Throwable> f;
        ax.p019b0.a<Throwable> g;
        String h;
        int i = 4;
        int j = 0;
        int k = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        int l = 20;

        public a a() {
            return new a(this);
        }

        public b b(ax.p019b0.a<Throwable> aVar) {
            this.f = aVar;
            return this;
        }

        public b c(int i, int i2) {
            if (i2 - i < 1000) {
                throw new IllegalArgumentException("WorkManager needs a range of at least 1000 job ids.");
            }
            this.j = i;
            this.k = i2;
            return this;
        }

        public b d(ax.p019b0.a<Throwable> aVar) {
            this.g = aVar;
            return this;
        }
    }

    public interface c {
        a a();
    }

    a(b bVar) {
        Executor executor = bVar.a;
        if (executor == null) {
            this.a = a(false);
        } else {
            this.a = executor;
        }
        Executor executor2 = bVar.d;
        if (executor2 == null) {
            this.m = true;
            this.b = a(true);
        } else {
            this.m = false;
            this.b = executor2;
        }
        t tVar = bVar.b;
        if (tVar == null) {
            this.c = t.c();
        } else {
            this.c = tVar;
        }
        g gVar = bVar.c;
        if (gVar == null) {
            this.d = g.c();
        } else {
            this.d = gVar;
        }
        o oVar = bVar.e;
        if (oVar == null) {
            this.e = new C0826d();
        } else {
            this.e = oVar;
        }
        this.i = bVar.i;
        this.j = bVar.j;
        this.k = bVar.k;
        this.l = bVar.l;
        this.f = bVar.f;
        this.g = bVar.g;
        this.h = bVar.h;
    }

    private Executor a(boolean z) {
        return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), b(z));
    }

    private ThreadFactory b(boolean z) {
        return new ThreadFactoryC0047a(z);
    }

    public String c() {
        return this.h;
    }

    public Executor d() {
        return this.a;
    }

    public ax.p019b0.a<Throwable> e() {
        return this.f;
    }

    public g f() {
        return this.d;
    }

    public int g() {
        return this.k;
    }

    public int h() {
        return Build.VERSION.SDK_INT == 23 ? this.l / 2 : this.l;
    }

    public int i() {
        return this.j;
    }

    public int j() {
        return this.i;
    }

    public o k() {
        return this.e;
    }

    public ax.p019b0.a<Throwable> l() {
        return this.g;
    }

    public Executor m() {
        return this.b;
    }

    public t n() {
        return this.c;
    }
}
