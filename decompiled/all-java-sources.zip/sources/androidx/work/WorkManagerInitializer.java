package androidx.work;

import android.content.Context;
import ax.F2.h;
import ax.F2.r;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class WorkManagerInitializer implements ax.p309t2.a<r> {
    private static final String a = h.i("WrkMgrInitializer");

    @Override // ax.p309t2.a
    public List<Class<? extends ax.p309t2.a<?>>> a() {
        return Collections.EMPTY_LIST;
    }

    @Override // ax.p309t2.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public r b(Context context) {
        h.e().a(a, "Initializing WorkManager with default configuration.");
        r.e(context, new a.b().a());
        return r.d(context);
    }
}
