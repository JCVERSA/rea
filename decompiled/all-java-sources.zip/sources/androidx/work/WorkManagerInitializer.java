package androidx.work;

import android.content.Context;
import ax.p170m1.j;
import ax.p170m1.t;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class WorkManagerInitializer implements ax.p058e1.a<t> {
    private static final String a = j.f("WrkMgrInitializer");

    @Override // ax.p058e1.a
    public List<Class<? extends ax.p058e1.a<?>>> a() {
        return Collections.emptyList();
    }

    @Override // ax.p058e1.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public t b(Context context) {
        j.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
        t.e(context, new a.b().a());
        return t.d(context);
    }
}
