package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import ax.p170m1.e;
import ax.p170m1.v;
import ax.p204o7.d;
import ax.p310w1.c;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public abstract class ListenableWorker {
    private WorkerParameters X;
    private volatile boolean Y;
    private boolean Z;
    private boolean h0;
    private Context q;

    public static abstract class a {

        /* JADX INFO: renamed from: androidx.work.ListenableWorker$a$a, reason: collision with other inner class name */
        public static final class C0046a extends a {
            private final androidx.work.b a;

            public C0046a() {
                this(androidx.work.b.c);
            }

            public androidx.work.b e() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || C0046a.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((C0046a) obj).a);
            }

            public int hashCode() {
                return (C0046a.class.getName().hashCode() * 31) + this.a.hashCode();
            }

            public String toString() {
                return "Failure {mOutputData=" + this.a + '}';
            }

            public C0046a(androidx.work.b bVar) {
                this.a = bVar;
            }
        }

        public static final class b extends a {
            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return obj != null && b.class == obj.getClass();
            }

            public int hashCode() {
                return b.class.getName().hashCode();
            }

            public String toString() {
                return "Retry";
            }
        }

        public static final class c extends a {
            private final androidx.work.b a;

            public c() {
                this(androidx.work.b.c);
            }

            public androidx.work.b e() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (obj == null || c.class != obj.getClass()) {
                    return false;
                }
                return this.a.equals(((c) obj).a);
            }

            public int hashCode() {
                return (c.class.getName().hashCode() * 31) + this.a.hashCode();
            }

            public String toString() {
                return "Success {mOutputData=" + this.a + '}';
            }

            public c(androidx.work.b bVar) {
                this.a = bVar;
            }
        }

        a() {
        }

        public static a a() {
            return new C0046a();
        }

        public static a b() {
            return new b();
        }

        public static a c() {
            return new c();
        }

        public static a d(androidx.work.b bVar) {
            return new c(bVar);
        }
    }

    @Keep
    @SuppressLint({"BanKeepAnnotation"})
    public ListenableWorker(Context context, WorkerParameters workerParameters) {
        if (context == null) {
            throw new IllegalArgumentException("Application Context is null");
        }
        if (workerParameters == null) {
            throw new IllegalArgumentException("WorkerParameters is null");
        }
        this.q = context;
        this.X = workerParameters;
    }

    public final Context getApplicationContext() {
        return this.q;
    }

    public Executor getBackgroundExecutor() {
        return this.X.a();
    }

    public d<e> getForegroundInfoAsync() {
        c cVarT = c.t();
        cVarT.q(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
        return cVarT;
    }

    public final UUID getId() {
        return this.X.c();
    }

    public final b getInputData() {
        return this.X.d();
    }

    public final Network getNetwork() {
        return this.X.e();
    }

    public final int getRunAttemptCount() {
        return this.X.g();
    }

    public final Set<String> getTags() {
        return this.X.h();
    }

    public ax.p324x1.a getTaskExecutor() {
        return this.X.i();
    }

    public final List<String> getTriggeredContentAuthorities() {
        return this.X.j();
    }

    public final List<Uri> getTriggeredContentUris() {
        return this.X.k();
    }

    public v getWorkerFactory() {
        return this.X.l();
    }

    public boolean isRunInForeground() {
        return this.h0;
    }

    public final boolean isStopped() {
        return this.Y;
    }

    public final boolean isUsed() {
        return this.Z;
    }

    public void onStopped() {
    }

    public final d<Void> setForegroundAsync(e eVar) {
        this.h0 = true;
        return this.X.b().a(getApplicationContext(), getId(), eVar);
    }

    public d<Void> setProgressAsync(b bVar) {
        return this.X.f().a(getApplicationContext(), getId(), bVar);
    }

    public void setRunInForeground(boolean z) {
        this.h0 = z;
    }

    public final void setUsed() {
        this.Z = true;
    }

    public abstract d<a> startWork();

    public final void stop() {
        this.Y = true;
        onStopped();
    }
}
