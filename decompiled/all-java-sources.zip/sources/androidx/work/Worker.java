package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import ax.p204o7.d;
import ax.p310w1.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class Worker extends ListenableWorker {
    c<ListenableWorker.a> i0;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Worker.this.i0.p(Worker.this.doWork());
            } catch (Throwable th) {
                Worker.this.i0.q(th);
            }
        }
    }

    @Keep
    @SuppressLint({"BanKeepAnnotation"})
    public Worker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public abstract ListenableWorker.a doWork();

    @Override // androidx.work.ListenableWorker
    public final d<ListenableWorker.a> startWork() {
        this.i0 = c.t();
        getBackgroundExecutor().execute(new a());
        return this.i0;
    }
}
