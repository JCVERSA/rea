package androidx.work;

import android.content.Context;
import ax.F2.d;
import ax.p043c8.e;

/* JADX INFO: loaded from: classes.dex */
public abstract class Worker extends c {
    ax.Q2.c<c.a> k0;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Worker.this.k0.q(Worker.this.doWork());
            } catch (Throwable th) {
                Worker.this.k0.r(th);
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ ax.Q2.c q;

        b(ax.Q2.c cVar) {
            this.q = cVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.q.q(Worker.this.getForegroundInfo());
            } catch (Throwable th) {
                this.q.r(th);
            }
        }
    }

    public Worker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    public abstract c.a doWork();

    public d getForegroundInfo() {
        throw new IllegalStateException("Expedited WorkRequests require a Worker to provide an implementation for \n `getForegroundInfo()`");
    }

    @Override // androidx.work.c
    public e<d> getForegroundInfoAsync() {
        ax.Q2.c cVarU = ax.Q2.c.u();
        getBackgroundExecutor().execute(new b(cVarU));
        return cVarU;
    }

    @Override // androidx.work.c
    public final e<c.a> startWork() {
        this.k0 = ax.Q2.c.u();
        getBackgroundExecutor().execute(new a());
        return this.k0;
    }
}
