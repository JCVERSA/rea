package androidx.work.impl;

import android.content.Context;
import androidx.work.impl.WorkDatabase;
import ax.G2.C0825c;
import ax.G2.C0828f;
import ax.G2.C0829g;
import ax.G2.E;
import ax.G2.i;
import ax.G2.j;
import ax.G2.k;
import ax.G2.m;
import ax.G2.n;
import ax.G2.s;
import ax.O2.InterfaceC1354b;
import ax.O2.e;
import ax.O2.o;
import ax.O2.r;
import ax.O2.v;
import ax.O2.z;
import ax.p197m2.t;
import ax.p197m2.u;
import ax.p261q2.h;
import ax.p277r2.f;
import ax.p335uc.g;
import ax.p335uc.l;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public abstract class WorkDatabase extends u {
    public static final a p = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final h c(Context context, h.b bVar) {
            l.f(context, "$context");
            l.f(bVar, "configuration");
            h.b.a aVarA = h.b.f.a(context);
            aVarA.d(bVar.b).c(bVar.c).e(true).a(true);
            return new f().a(aVarA.b());
        }

        public final WorkDatabase b(final Context context, Executor executor, boolean z) {
            l.f(context, "context");
            l.f(executor, "queryExecutor");
            return (WorkDatabase) (z ? t.c(context, WorkDatabase.class).c() : t.a(context, WorkDatabase.class, "androidx.work.workdb").f(new h.c() { // from class: ax.G2.y
                @Override // ax.q2.h.c
                public final ax.p261q2.h a(ax.q2.h.b bVar) {
                    return WorkDatabase.a.c(context, bVar);
                }
            })).g(executor).a(C0825c.a).b(i.c).b(new s(context, 2, 3)).b(j.c).b(k.c).b(new s(context, 5, 6)).b(ax.G2.l.c).b(m.c).b(n.c).b(new E(context)).b(new s(context, 10, 11)).b(C0828f.c).b(C0829g.c).b(ax.G2.h.c).e().d();
        }
    }

    public static final WorkDatabase C(Context context, Executor executor, boolean z) {
        return p.b(context, executor, z);
    }

    public abstract InterfaceC1354b D();

    public abstract e E();

    public abstract ax.O2.j F();

    public abstract o G();

    public abstract r H();

    public abstract v I();

    public abstract z J();
}
