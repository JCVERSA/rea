package androidx.work.impl;

import android.content.Context;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public class a {
    public static ax.Z0.a a = new C0048a(1, 2);
    public static ax.Z0.a b = new b(3, 4);
    public static ax.Z0.a c = new c(4, 5);
    public static ax.Z0.a d = new d(6, 7);
    public static ax.Z0.a e = new e(7, 8);
    public static ax.Z0.a f = new f(8, 9);
    public static ax.Z0.a g = new g(11, 12);

    /* JADX INFO: renamed from: androidx.work.impl.a$a, reason: collision with other inner class name */
    class C0048a extends ax.Z0.a {
        C0048a(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
            bVar.I("DROP TABLE IF EXISTS alarmInfo");
            bVar.I("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
        }
    }

    class b extends ax.Z0.a {
        b(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.I("UPDATE workspec SET schedule_requested_at=0 WHERE state NOT IN (2, 3, 5) AND schedule_requested_at=-1 AND interval_duration<>0");
            }
        }
    }

    class c extends ax.Z0.a {
        c(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
            bVar.I("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
        }
    }

    class d extends ax.Z0.a {
        d(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
        }
    }

    class e extends ax.Z0.a {
        e(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)");
        }
    }

    class f extends ax.Z0.a {
        f(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
        }
    }

    class g extends ax.Z0.a {
        g(int i, int i2) {
            super(i, i2);
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("ALTER TABLE workspec ADD COLUMN `out_of_quota_policy` INTEGER NOT NULL DEFAULT 0");
        }
    }

    public static class h extends ax.Z0.a {
        final Context c;

        public h(Context context, int i, int i2) {
            super(i, i2);
            this.c = context;
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            if (this.b >= 10) {
                bVar.h0("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"reschedule_needed", 1});
            } else {
                this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
            }
        }
    }

    public static class i extends ax.Z0.a {
        final Context c;

        public i(Context context) {
            super(9, 10);
            this.c = context;
        }

        @Override // ax.Z0.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            ax.p296v1.h.b(this.c, bVar);
            ax.p296v1.f.a(this.c, bVar);
        }
    }
}
