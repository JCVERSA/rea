package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import ax.p170m1.j;
import ax.p170m1.l;
import ax.p170m1.t;

/* JADX INFO: loaded from: classes.dex */
public class DiagnosticsReceiver extends BroadcastReceiver {
    private static final String a = j.f("DiagnosticsRcvr");

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        j.c().a(a, "Requesting diagnostics", new Throwable[0]);
        try {
            t.d(context).b(l.d(DiagnosticsWorker.class));
        } catch (IllegalStateException e) {
            j.c().b(a, "WorkManager is not initialized", e);
        }
    }
}
