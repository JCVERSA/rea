package androidx.work.impl.diagnostics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import ax.F2.h;
import ax.F2.j;
import ax.F2.r;

/* JADX INFO: loaded from: classes.dex */
public class DiagnosticsReceiver extends BroadcastReceiver {
    private static final String a = h.i("DiagnosticsRcvr");

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        h.e().a(a, "Requesting diagnostics");
        try {
            r.d(context).b(j.e(DiagnosticsWorker.class));
        } catch (IllegalStateException e) {
            h.e().d(a, "WorkManager is not initialized", e);
        }
    }
}
