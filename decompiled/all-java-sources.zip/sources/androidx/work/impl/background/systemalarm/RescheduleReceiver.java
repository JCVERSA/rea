package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import ax.F2.h;
import ax.G2.D;

/* JADX INFO: loaded from: classes.dex */
public class RescheduleReceiver extends BroadcastReceiver {
    private static final String a = h.i("RescheduleReceiver");

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        h.e().a(a, "Received intent " + intent);
        if (Build.VERSION.SDK_INT < 23) {
            context.startService(b.d(context));
            return;
        }
        try {
            D.k(context).u(goAsync());
        } catch (IllegalStateException e) {
            h.e().d(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e);
        }
    }
}
