package androidx.work.impl.background.systemalarm;

import android.content.Context;
import ax.F2.h;
import ax.G2.t;
import ax.O2.u;
import ax.O2.x;

/* JADX INFO: loaded from: classes.dex */
public class f implements t {
    private static final String X = h.i("SystemAlarmScheduler");
    private final Context q;

    public f(Context context) {
        this.q = context.getApplicationContext();
    }

    private void b(u uVar) {
        h.e().a(X, "Scheduling work with workSpecId " + uVar.a);
        this.q.startService(b.e(this.q, x.a(uVar)));
    }

    @Override // ax.G2.t
    public void a(u... uVarArr) {
        for (u uVar : uVarArr) {
            b(uVar);
        }
    }

    @Override // ax.G2.t
    public boolean c() {
        return true;
    }

    @Override // ax.G2.t
    public void d(String str) {
        this.q.startService(b.h(this.q, str));
    }
}
