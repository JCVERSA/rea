package androidx.work.impl.background.systemalarm;

import android.content.Context;
import ax.p170m1.j;
import ax.p282u1.p;

/* JADX INFO: loaded from: classes.dex */
public class f implements ax.p184n1.e {
    private static final String X = j.f("SystemAlarmScheduler");
    private final Context q;

    public f(Context context) {
        this.q = context.getApplicationContext();
    }

    private void b(p pVar) {
        j.c().a(X, String.format("Scheduling work with workSpecId %s", pVar.a), new Throwable[0]);
        this.q.startService(b.f(this.q, pVar.a));
    }

    @Override // ax.p184n1.e
    public boolean a() {
        return true;
    }

    @Override // ax.p184n1.e
    public void d(String str) {
        this.q.startService(b.g(this.q, str));
    }

    @Override // ax.p184n1.e
    public void e(p... pVarArr) {
        for (p pVar : pVarArr) {
            b(pVar);
        }
    }
}
