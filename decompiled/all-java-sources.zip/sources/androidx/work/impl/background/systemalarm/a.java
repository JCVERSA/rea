package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import ax.F2.h;
import ax.O2.i;
import ax.O2.j;
import ax.O2.l;
import ax.O2.m;
import ax.P2.k;

/* JADX INFO: loaded from: classes.dex */
class a {
    private static final String a = h.i("Alarms");

    /* JADX INFO: renamed from: androidx.work.impl.background.systemalarm.a$a, reason: collision with other inner class name */
    static class C0050a {
        static void a(AlarmManager alarmManager, int i, long j, PendingIntent pendingIntent) {
            alarmManager.setExact(i, j, pendingIntent);
        }
    }

    public static void a(Context context, WorkDatabase workDatabase, m mVar) {
        j jVarF = workDatabase.F();
        i iVarE = jVarF.e(mVar);
        if (iVarE != null) {
            b(context, mVar, iVarE.c);
            h.e().a(a, "Removing SystemIdInfo for workSpecId (" + mVar + ")");
            jVarF.a(mVar);
        }
    }

    private static void b(Context context, m mVar, int i) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent service = PendingIntent.getService(context, i, b.b(context, mVar), Build.VERSION.SDK_INT >= 23 ? 603979776 : 536870912);
        if (service == null || alarmManager == null) {
            return;
        }
        h.e().a(a, "Cancelling existing alarm with (workSpecId, systemId) (" + mVar + ", " + i + ")");
        alarmManager.cancel(service);
    }

    public static void c(Context context, WorkDatabase workDatabase, m mVar, long j) {
        j jVarF = workDatabase.F();
        i iVarE = jVarF.e(mVar);
        if (iVarE != null) {
            b(context, mVar, iVarE.c);
            d(context, mVar, iVarE.c, j);
        } else {
            int iC = new k(workDatabase).c();
            jVarF.c(l.a(mVar, iC));
            d(context, mVar, iC, j);
        }
    }

    private static void d(Context context, m mVar, int i, long j) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent service = PendingIntent.getService(context, i, b.b(context, mVar), Build.VERSION.SDK_INT >= 23 ? 201326592 : 134217728);
        if (alarmManager != null) {
            C0050a.a(alarmManager, 0, j, service);
        }
    }
}
