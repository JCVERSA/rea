package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import ax.p170m1.j;
import ax.p282u1.g;
import ax.p282u1.h;

/* JADX INFO: loaded from: classes.dex */
class a {
    private static final String a = j.f("Alarms");

    public static void a(Context context, ax.p184n1.j jVar, String str) {
        h hVarY = jVar.o().y();
        g gVarC = hVarY.c(str);
        if (gVarC != null) {
            b(context, str, gVarC.b);
            j.c().a(a, String.format("Removing SystemIdInfo for workSpecId (%s)", str), new Throwable[0]);
            hVarY.d(str);
        }
    }

    private static void b(Context context, String str, int i) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent service = PendingIntent.getService(context, i, b.b(context, str), Build.VERSION.SDK_INT >= 23 ? 603979776 : 536870912);
        if (service == null || alarmManager == null) {
            return;
        }
        j.c().a(a, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", str, Integer.valueOf(i)), new Throwable[0]);
        alarmManager.cancel(service);
    }

    public static void c(Context context, ax.p184n1.j jVar, String str, long j) {
        WorkDatabase workDatabaseO = jVar.o();
        h hVarY = workDatabaseO.y();
        g gVarC = hVarY.c(str);
        if (gVarC != null) {
            b(context, str, gVarC.b);
            d(context, str, gVarC.b, j);
        } else {
            int iB = new ax.p296v1.f(workDatabaseO).b();
            hVarY.b(new g(str, iB));
            d(context, str, iB, j);
        }
    }

    private static void d(Context context, String str, int i, long j) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent service = PendingIntent.getService(context, i, b.b(context, str), Build.VERSION.SDK_INT >= 23 ? 201326592 : 134217728);
        if (alarmManager != null) {
            alarmManager.setExact(0, j, service);
        }
    }
}
