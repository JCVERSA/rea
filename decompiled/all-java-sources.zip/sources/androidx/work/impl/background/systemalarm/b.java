package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import ax.p170m1.j;
import ax.p282u1.p;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class b implements ax.p184n1.b {
    private static final String Z = j.f("CommandHandler");
    private final Map<String, ax.p184n1.b> X = new HashMap();
    private final Object Y = new Object();
    private final Context q;

    b(Context context) {
        this.q = context;
    }

    static Intent a(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_CONSTRAINTS_CHANGED");
        return intent;
    }

    static Intent b(Context context, String str) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_DELAY_MET");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    static Intent d(Context context, String str, boolean z) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_EXECUTION_COMPLETED");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        intent.putExtra("KEY_NEEDS_RESCHEDULE", z);
        return intent;
    }

    static Intent e(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_RESCHEDULE");
        return intent;
    }

    static Intent f(Context context, String str) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_SCHEDULE_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    static Intent g(Context context, String str) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    private void h(Intent intent, int i, e eVar) {
        j.c().a(Z, String.format("Handling constraints changed %s", intent), new Throwable[0]);
        new c(this.q, i, eVar).a();
    }

    private void i(Intent intent, int i, e eVar) {
        Bundle extras = intent.getExtras();
        synchronized (this.Y) {
            try {
                String string = extras.getString("KEY_WORKSPEC_ID");
                j jVarC = j.c();
                String str = Z;
                jVarC.a(str, String.format("Handing delay met for %s", string), new Throwable[0]);
                if (this.X.containsKey(string)) {
                    j.c().a(str, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", string), new Throwable[0]);
                } else {
                    d dVar = new d(this.q, i, string, eVar);
                    this.X.put(string, dVar);
                    dVar.e();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void j(Intent intent, int i) {
        Bundle extras = intent.getExtras();
        String string = extras.getString("KEY_WORKSPEC_ID");
        boolean z = extras.getBoolean("KEY_NEEDS_RESCHEDULE");
        j.c().a(Z, String.format("Handling onExecutionCompleted %s, %s", intent, Integer.valueOf(i)), new Throwable[0]);
        c(string, z);
    }

    private void k(Intent intent, int i, e eVar) {
        j.c().a(Z, String.format("Handling reschedule %s, %s", intent, Integer.valueOf(i)), new Throwable[0]);
        eVar.g().s();
    }

    private void l(Intent intent, int i, e eVar) {
        String string = intent.getExtras().getString("KEY_WORKSPEC_ID");
        j jVarC = j.c();
        String str = Z;
        jVarC.a(str, String.format("Handling schedule work for %s", string), new Throwable[0]);
        WorkDatabase workDatabaseO = eVar.g().o();
        workDatabaseO.c();
        try {
            p pVarM = workDatabaseO.B().m(string);
            if (pVarM == null) {
                j.c().h(str, "Skipping scheduling " + string + " because it's no longer in the DB", new Throwable[0]);
                return;
            }
            if (pVarM.b.g()) {
                j.c().h(str, "Skipping scheduling " + string + "because it is finished.", new Throwable[0]);
                return;
            }
            long jA = pVarM.a();
            if (pVarM.b()) {
                j.c().a(str, String.format("Opportunistically setting an alarm for %s at %s", string, Long.valueOf(jA)), new Throwable[0]);
                a.c(this.q, eVar.g(), string, jA);
                eVar.k(new e.b(eVar, a(this.q), i));
            } else {
                j.c().a(str, String.format("Setting up Alarms for %s at %s", string, Long.valueOf(jA)), new Throwable[0]);
                a.c(this.q, eVar.g(), string, jA);
            }
            workDatabaseO.r();
        } finally {
            workDatabaseO.g();
        }
    }

    private void m(Intent intent, e eVar) {
        String string = intent.getExtras().getString("KEY_WORKSPEC_ID");
        j.c().a(Z, String.format("Handing stopWork work for %s", string), new Throwable[0]);
        eVar.g().x(string);
        a.a(this.q, eVar.g(), string);
        eVar.c(string, false);
    }

    private static boolean n(Bundle bundle, String... strArr) {
        if (bundle == null || bundle.isEmpty()) {
            return false;
        }
        for (String str : strArr) {
            if (bundle.get(str) == null) {
                return false;
            }
        }
        return true;
    }

    @Override // ax.p184n1.b
    public void c(String str, boolean z) {
        synchronized (this.Y) {
            try {
                ax.p184n1.b bVarRemove = this.X.remove(str);
                if (bVarRemove != null) {
                    bVarRemove.c(str, z);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    boolean o() {
        boolean z;
        synchronized (this.Y) {
            z = !this.X.isEmpty();
        }
        return z;
    }

    void p(Intent intent, int i, e eVar) {
        String action = intent.getAction();
        if ("ACTION_CONSTRAINTS_CHANGED".equals(action)) {
            h(intent, i, eVar);
            return;
        }
        if ("ACTION_RESCHEDULE".equals(action)) {
            k(intent, i, eVar);
            return;
        }
        if (!n(intent.getExtras(), "KEY_WORKSPEC_ID")) {
            j.c().b(Z, String.format("Invalid request for %s, requires %s.", action, "KEY_WORKSPEC_ID"), new Throwable[0]);
            return;
        }
        if ("ACTION_SCHEDULE_WORK".equals(action)) {
            l(intent, i, eVar);
            return;
        }
        if ("ACTION_DELAY_MET".equals(action)) {
            i(intent, i, eVar);
            return;
        }
        if ("ACTION_STOP_WORK".equals(action)) {
            m(intent, eVar);
        } else if ("ACTION_EXECUTION_COMPLETED".equals(action)) {
            j(intent, i);
        } else {
            j.c().h(Z, String.format("Ignoring intent %s", intent), new Throwable[0]);
        }
    }
}
