package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import ax.F2.h;
import ax.G2.InterfaceC0827e;
import ax.G2.v;
import ax.G2.w;
import ax.O2.m;
import ax.O2.u;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class b implements InterfaceC0827e {
    private static final String k0 = h.i("CommandHandler");
    private final Map<m, d> X = new HashMap();
    private final Object Y = new Object();
    private final w Z;
    private final Context q;

    b(Context context, w wVar) {
        this.q = context;
        this.Z = wVar;
    }

    static Intent a(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_CONSTRAINTS_CHANGED");
        return intent;
    }

    static Intent b(Context context, m mVar) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_DELAY_MET");
        return s(intent, mVar);
    }

    static Intent c(Context context, m mVar, boolean z) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_EXECUTION_COMPLETED");
        intent.putExtra("KEY_NEEDS_RESCHEDULE", z);
        return s(intent, mVar);
    }

    static Intent d(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_RESCHEDULE");
        return intent;
    }

    static Intent e(Context context, m mVar) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_SCHEDULE_WORK");
        return s(intent, mVar);
    }

    static Intent g(Context context, m mVar) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        return s(intent, mVar);
    }

    static Intent h(Context context, String str) {
        Intent intent = new Intent(context, (Class<?>) SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    private void i(Intent intent, int i, e eVar) {
        h.e().a(k0, "Handling constraints changed " + intent);
        new c(this.q, i, eVar).a();
    }

    private void j(Intent intent, int i, e eVar) {
        synchronized (this.Y) {
            try {
                m mVarR = r(intent);
                h hVarE = h.e();
                String str = k0;
                hVarE.a(str, "Handing delay met for " + mVarR);
                if (this.X.containsKey(mVarR)) {
                    h.e().a(str, "WorkSpec " + mVarR + " is is already being handled for ACTION_DELAY_MET");
                } else {
                    d dVar = new d(this.q, i, eVar, this.Z.d(mVarR));
                    this.X.put(mVarR, dVar);
                    dVar.g();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void k(Intent intent, int i) {
        m mVarR = r(intent);
        boolean z = intent.getExtras().getBoolean("KEY_NEEDS_RESCHEDULE");
        h.e().a(k0, "Handling onExecutionCompleted " + intent + ", " + i);
        f(mVarR, z);
    }

    private void l(Intent intent, int i, e eVar) {
        h.e().a(k0, "Handling reschedule " + intent + ", " + i);
        eVar.g().t();
    }

    private void m(Intent intent, int i, e eVar) {
        m mVarR = r(intent);
        h hVarE = h.e();
        String str = k0;
        hVarE.a(str, "Handling schedule work for " + mVarR);
        WorkDatabase workDatabaseP = eVar.g().p();
        workDatabaseP.e();
        try {
            u uVarN = workDatabaseP.I().n(mVarR.b());
            if (uVarN == null) {
                h.e().k(str, "Skipping scheduling " + mVarR + " because it's no longer in the DB");
                return;
            }
            if (uVarN.b.h()) {
                h.e().k(str, "Skipping scheduling " + mVarR + "because it is finished.");
                return;
            }
            long jA = uVarN.a();
            if (uVarN.f()) {
                h.e().a(str, "Opportunistically setting an alarm for " + mVarR + "at " + jA);
                a.c(this.q, workDatabaseP, mVarR, jA);
                eVar.e().a().execute(new e.b(eVar, a(this.q), i));
            } else {
                h.e().a(str, "Setting up Alarms for " + mVarR + "at " + jA);
                a.c(this.q, workDatabaseP, mVarR, jA);
            }
            workDatabaseP.A();
        } finally {
            workDatabaseP.i();
        }
    }

    private void n(Intent intent, e eVar) {
        List<v> listC;
        Bundle extras = intent.getExtras();
        String string = extras.getString("KEY_WORKSPEC_ID");
        if (extras.containsKey("KEY_WORKSPEC_GENERATION")) {
            int i = extras.getInt("KEY_WORKSPEC_GENERATION");
            listC = new ArrayList<>(1);
            v vVarB = this.Z.b(new m(string, i));
            if (vVarB != null) {
                listC.add(vVarB);
            }
        } else {
            listC = this.Z.c(string);
        }
        for (v vVar : listC) {
            h.e().a(k0, "Handing stopWork work for " + string);
            eVar.g().y(vVar);
            a.a(this.q, eVar.g().p(), vVar.a());
            eVar.f(vVar.a(), false);
        }
    }

    private static boolean o(Bundle bundle, String... strArr) {
        if (bundle == null || bundle.isEmpty()) {
            return false;
        }
        for (String str : strArr) {
            if (bundle.get(str) == null) {
                return false;
            }
        }
        return true;
    }

    static m r(Intent intent) {
        return new m(intent.getStringExtra("KEY_WORKSPEC_ID"), intent.getIntExtra("KEY_WORKSPEC_GENERATION", 0));
    }

    private static Intent s(Intent intent, m mVar) {
        intent.putExtra("KEY_WORKSPEC_ID", mVar.b());
        intent.putExtra("KEY_WORKSPEC_GENERATION", mVar.a());
        return intent;
    }

    @Override // ax.G2.InterfaceC0827e
    public void f(m mVar, boolean z) {
        synchronized (this.Y) {
            try {
                d dVarRemove = this.X.remove(mVar);
                this.Z.b(mVar);
                if (dVarRemove != null) {
                    dVarRemove.h(z);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    boolean p() {
        boolean z;
        synchronized (this.Y) {
            z = !this.X.isEmpty();
        }
        return z;
    }

    void q(Intent intent, int i, e eVar) {
        String action = intent.getAction();
        if ("ACTION_CONSTRAINTS_CHANGED".equals(action)) {
            i(intent, i, eVar);
            return;
        }
        if ("ACTION_RESCHEDULE".equals(action)) {
            l(intent, i, eVar);
            return;
        }
        if (!o(intent.getExtras(), "KEY_WORKSPEC_ID")) {
            h.e().c(k0, "Invalid request for " + action + " , requires KEY_WORKSPEC_ID .");
            return;
        }
        if ("ACTION_SCHEDULE_WORK".equals(action)) {
            m(intent, i, eVar);
            return;
        }
        if ("ACTION_DELAY_MET".equals(action)) {
            j(intent, i, eVar);
            return;
        }
        if ("ACTION_STOP_WORK".equals(action)) {
            n(intent, eVar);
            return;
        }
        if ("ACTION_EXECUTION_COMPLETED".equals(action)) {
            k(intent, i);
            return;
        }
        h.e().k(k0, "Ignoring intent " + intent);
    }
}
