package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import ax.F2.h;
import ax.G2.D;
import ax.G2.InterfaceC0827e;
import ax.G2.r;
import ax.G2.w;
import ax.O2.m;
import ax.P2.E;
import ax.P2.y;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class e implements InterfaceC0827e {
    static final String q0 = h.i("SystemAlarmDispatcher");
    final ax.R2.c X;
    private final E Y;
    private final r Z;
    private final D k0;
    final androidx.work.impl.background.systemalarm.b l0;
    final List<Intent> m0;
    Intent n0;
    private c o0;
    private w p0;
    final Context q;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (e.this.m0) {
                e eVar = e.this;
                eVar.n0 = eVar.m0.get(0);
            }
            Intent intent = e.this.n0;
            if (intent != null) {
                String action = intent.getAction();
                int intExtra = e.this.n0.getIntExtra("KEY_START_ID", 0);
                h hVarE = h.e();
                String str = e.q0;
                hVarE.a(str, "Processing command " + e.this.n0 + ", " + intExtra);
                PowerManager.WakeLock wakeLockB = y.b(e.this.q, action + " (" + intExtra + ")");
                try {
                    h.e().a(str, "Acquiring operation wake lock (" + action + ") " + wakeLockB);
                    wakeLockB.acquire();
                    e eVar2 = e.this;
                    eVar2.l0.q(eVar2.n0, intExtra, eVar2);
                    h.e().a(str, "Releasing operation wake lock (" + action + ") " + wakeLockB);
                    wakeLockB.release();
                    e.this.X.a().execute(new d(e.this));
                } catch (Throwable th) {
                    try {
                        h.e().d(e.q0, "Unexpected error in onHandleIntent", th);
                        h hVarE2 = h.e();
                    } finally {
                        h.e().a(e.q0, "Releasing operation wake lock (" + action + ") " + wakeLockB);
                        wakeLockB.release();
                        e.this.X.a().execute(new d(e.this));
                    }
                }
            }
        }
    }

    static class b implements Runnable {
        private final Intent X;
        private final int Y;
        private final e q;

        b(e eVar, Intent intent, int i) {
            this.q = eVar;
            this.X = intent;
            this.Y = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.a(this.X, this.Y);
        }
    }

    interface c {
        void a();
    }

    static class d implements Runnable {
        private final e q;

        d(e eVar) {
            this.q = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.c();
        }
    }

    e(Context context) {
        this(context, null, null);
    }

    e(Context context, r rVar, D d2) {
        Context applicationContext = context.getApplicationContext();
        this.q = applicationContext;
        this.p0 = new w();
        this.l0 = new androidx.work.impl.background.systemalarm.b(applicationContext, this.p0);
        d2 = d2 == null ? D.k(context) : d2;
        this.k0 = d2;
        this.Y = new E(d2.i().k());
        rVar = rVar == null ? d2.m() : rVar;
        this.Z = rVar;
        this.X = d2.q();
        rVar.g(this);
        this.m0 = new ArrayList();
        this.n0 = null;
    }

    private void b() {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException("Needs to be invoked on the main thread.");
        }
    }

    private boolean i(String str) {
        b();
        synchronized (this.m0) {
            try {
                Iterator<Intent> it = this.m0.iterator();
                while (it.hasNext()) {
                    if (str.equals(it.next().getAction())) {
                        return true;
                    }
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void k() {
        b();
        PowerManager.WakeLock wakeLockB = y.b(this.q, "ProcessCommand");
        try {
            wakeLockB.acquire();
            this.k0.q().c(new a());
        } finally {
            wakeLockB.release();
        }
    }

    public boolean a(Intent intent, int i) {
        h hVarE = h.e();
        String str = q0;
        hVarE.a(str, "Adding command " + intent + " (" + i + ")");
        b();
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            h.e().k(str, "Unknown command. Ignoring");
            return false;
        }
        if ("ACTION_CONSTRAINTS_CHANGED".equals(action) && i("ACTION_CONSTRAINTS_CHANGED")) {
            return false;
        }
        intent.putExtra("KEY_START_ID", i);
        synchronized (this.m0) {
            try {
                boolean zIsEmpty = this.m0.isEmpty();
                this.m0.add(intent);
                if (zIsEmpty) {
                    k();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return true;
    }

    void c() {
        h hVarE = h.e();
        String str = q0;
        hVarE.a(str, "Checking if commands are complete.");
        b();
        synchronized (this.m0) {
            try {
                if (this.n0 != null) {
                    h.e().a(str, "Removing command " + this.n0);
                    if (!this.m0.remove(0).equals(this.n0)) {
                        throw new IllegalStateException("Dequeue-d command is not the first.");
                    }
                    this.n0 = null;
                }
                ax.R2.a aVarB = this.X.b();
                if (!this.l0.p() && this.m0.isEmpty() && !aVarB.B()) {
                    h.e().a(str, "No more commands & intents.");
                    c cVar = this.o0;
                    if (cVar != null) {
                        cVar.a();
                    }
                } else if (!this.m0.isEmpty()) {
                    k();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    r d() {
        return this.Z;
    }

    ax.R2.c e() {
        return this.X;
    }

    @Override // ax.G2.InterfaceC0827e
    public void f(m mVar, boolean z) {
        this.X.a().execute(new b(this, androidx.work.impl.background.systemalarm.b.c(this.q, mVar, z), 0));
    }

    D g() {
        return this.k0;
    }

    E h() {
        return this.Y;
    }

    void j() {
        h.e().a(q0, "Destroying SystemAlarmDispatcher");
        this.Z.l(this);
        this.o0 = null;
    }

    void l(c cVar) {
        if (this.o0 != null) {
            h.e().c(q0, "A completion listener for SystemAlarmDispatcher already exists.");
        } else {
            this.o0 = cVar;
        }
    }
}
