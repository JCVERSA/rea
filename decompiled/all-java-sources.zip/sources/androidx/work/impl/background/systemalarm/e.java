package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import ax.p170m1.j;
import ax.p296v1.k;
import ax.p296v1.n;
import ax.p296v1.r;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class e implements ax.p184n1.b {
    static final String n0 = j.f("SystemAlarmDispatcher");
    private final ax.p324x1.a X;
    private final r Y;
    private final ax.p184n1.d Z;
    private final ax.p184n1.j h0;
    final androidx.work.impl.background.systemalarm.b i0;
    private final Handler j0;
    final List<Intent> k0;
    Intent l0;
    private c m0;
    final Context q;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            e eVar;
            d dVar;
            synchronized (e.this.k0) {
                e eVar2 = e.this;
                eVar2.l0 = eVar2.k0.get(0);
            }
            Intent intent = e.this.l0;
            if (intent != null) {
                String action = intent.getAction();
                int intExtra = e.this.l0.getIntExtra("KEY_START_ID", 0);
                j jVarC = j.c();
                String str = e.n0;
                jVarC.a(str, String.format("Processing command %s, %s", e.this.l0, Integer.valueOf(intExtra)), new Throwable[0]);
                PowerManager.WakeLock wakeLockB = n.b(e.this.q, String.format("%s (%s)", action, Integer.valueOf(intExtra)));
                try {
                    j.c().a(str, String.format("Acquiring operation wake lock (%s) %s", action, wakeLockB), new Throwable[0]);
                    wakeLockB.acquire();
                    e eVar3 = e.this;
                    eVar3.i0.p(eVar3.l0, intExtra, eVar3);
                    j.c().a(str, String.format("Releasing operation wake lock (%s) %s", action, wakeLockB), new Throwable[0]);
                    wakeLockB.release();
                    eVar = e.this;
                    dVar = new d(eVar);
                } catch (Throwable th) {
                    try {
                        j jVarC2 = j.c();
                        String str2 = e.n0;
                        jVarC2.b(str2, "Unexpected error in onHandleIntent", th);
                        j.c().a(str2, String.format("Releasing operation wake lock (%s) %s", action, wakeLockB), new Throwable[0]);
                        wakeLockB.release();
                        eVar = e.this;
                        dVar = new d(eVar);
                    } catch (Throwable th2) {
                        j.c().a(e.n0, String.format("Releasing operation wake lock (%s) %s", action, wakeLockB), new Throwable[0]);
                        wakeLockB.release();
                        e eVar4 = e.this;
                        eVar4.k(new d(eVar4));
                        throw th2;
                    }
                }
                eVar.k(dVar);
            }
        }
    }

    static class b implements Runnable {
        private final Intent X;
        private final int Y;
        private final e q;

        b(e eVar, Intent intent, int i) {
            this.q = eVar;
            this.X = intent;
            this.Y = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.a(this.X, this.Y);
        }
    }

    interface c {
        void a();
    }

    static class d implements Runnable {
        private final e q;

        d(e eVar) {
            this.q = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.d();
        }
    }

    e(Context context) {
        this(context, null, null);
    }

    private void b() {
        if (this.j0.getLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException("Needs to be invoked on the main thread.");
        }
    }

    private boolean i(String str) {
        b();
        synchronized (this.k0) {
            try {
                Iterator<Intent> it = this.k0.iterator();
                while (it.hasNext()) {
                    if (str.equals(it.next().getAction())) {
                        return true;
                    }
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void l() {
        b();
        PowerManager.WakeLock wakeLockB = n.b(this.q, "ProcessCommand");
        try {
            wakeLockB.acquire();
            this.h0.p().b(new a());
        } finally {
            wakeLockB.release();
        }
    }

    public boolean a(Intent intent, int i) {
        j jVarC = j.c();
        String str = n0;
        jVarC.a(str, String.format("Adding command %s (%s)", intent, Integer.valueOf(i)), new Throwable[0]);
        b();
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            j.c().h(str, "Unknown command. Ignoring", new Throwable[0]);
            return false;
        }
        if ("ACTION_CONSTRAINTS_CHANGED".equals(action) && i("ACTION_CONSTRAINTS_CHANGED")) {
            return false;
        }
        intent.putExtra("KEY_START_ID", i);
        synchronized (this.k0) {
            try {
                boolean z = !this.k0.isEmpty();
                this.k0.add(intent);
                if (!z) {
                    l();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return true;
    }

    @Override // ax.p184n1.b
    public void c(String str, boolean z) {
        k(new b(this, androidx.work.impl.background.systemalarm.b.d(this.q, str, z), 0));
    }

    void d() {
        j jVarC = j.c();
        String str = n0;
        jVarC.a(str, "Checking if commands are complete.", new Throwable[0]);
        b();
        synchronized (this.k0) {
            try {
                if (this.l0 != null) {
                    j.c().a(str, String.format("Removing command %s", this.l0), new Throwable[0]);
                    if (!this.k0.remove(0).equals(this.l0)) {
                        throw new IllegalStateException("Dequeue-d command is not the first.");
                    }
                    this.l0 = null;
                }
                k kVarC = this.X.c();
                if (!this.i0.o() && this.k0.isEmpty() && !kVarC.a()) {
                    j.c().a(str, "No more commands & intents.", new Throwable[0]);
                    c cVar = this.m0;
                    if (cVar != null) {
                        cVar.a();
                    }
                } else if (!this.k0.isEmpty()) {
                    l();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    ax.p184n1.d e() {
        return this.Z;
    }

    ax.p324x1.a f() {
        return this.X;
    }

    ax.p184n1.j g() {
        return this.h0;
    }

    r h() {
        return this.Y;
    }

    void j() {
        j.c().a(n0, "Destroying SystemAlarmDispatcher", new Throwable[0]);
        this.Z.i(this);
        this.Y.a();
        this.m0 = null;
    }

    void k(Runnable runnable) {
        this.j0.post(runnable);
    }

    void m(c cVar) {
        if (this.m0 != null) {
            j.c().b(n0, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
        } else {
            this.m0 = cVar;
        }
    }

    e(Context context, ax.p184n1.d dVar, ax.p184n1.j jVar) {
        Context applicationContext = context.getApplicationContext();
        this.q = applicationContext;
        this.i0 = new androidx.work.impl.background.systemalarm.b(applicationContext);
        this.Y = new r();
        jVar = jVar == null ? ax.p184n1.j.k(context) : jVar;
        this.h0 = jVar;
        dVar = dVar == null ? jVar.m() : dVar;
        this.Z = dVar;
        this.X = jVar.p();
        dVar.d(this);
        this.k0 = new ArrayList();
        this.l0 = null;
        this.j0 = new Handler(Looper.getMainLooper());
    }
}
