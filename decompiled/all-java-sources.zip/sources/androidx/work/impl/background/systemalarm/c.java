package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import ax.F2.h;
import ax.O2.u;
import ax.O2.x;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
class c {
    private static final String e = h.i("ConstraintsCmdHandler");
    private final Context a;
    private final int b;
    private final e c;
    private final ax.K2.e d;

    c(Context context, int i, e eVar) {
        this.a = context;
        this.b = i;
        this.c = eVar;
        this.d = new ax.K2.e(eVar.g().o(), (ax.K2.c) null);
    }

    void a() {
        List<u> listF = this.c.g().p().I().f();
        ConstraintProxy.a(this.a, listF);
        this.d.b(listF);
        ArrayList arrayList = new ArrayList(listF.size());
        long jCurrentTimeMillis = System.currentTimeMillis();
        for (u uVar : listF) {
            String str = uVar.a;
            if (jCurrentTimeMillis >= uVar.a() && (!uVar.f() || this.d.e(str))) {
                arrayList.add(uVar);
            }
        }
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            u uVar2 = (u) obj;
            String str2 = uVar2.a;
            Intent intentB = b.b(this.a, x.a(uVar2));
            h.e().a(e, "Creating a delay_met command for workSpec with id (" + str2 + ")");
            this.c.e().a().execute(new e.b(this.c, intentB, this.b));
        }
        this.d.a();
    }
}
