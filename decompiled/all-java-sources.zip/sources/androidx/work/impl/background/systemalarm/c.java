package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import ax.p170m1.j;
import ax.p282u1.p;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
class c {
    private static final String e = j.f("ConstraintsCmdHandler");
    private final Context a;
    private final int b;
    private final e c;
    private final ax.p226q1.d d;

    c(Context context, int i, e eVar) {
        this.a = context;
        this.b = i;
        this.c = eVar;
        this.d = new ax.p226q1.d(context, eVar.f(), null);
    }

    void a() {
        List<p> listE = this.c.g().o().B().e();
        ConstraintProxy.a(this.a, listE);
        this.d.d(listE);
        ArrayList arrayList = new ArrayList(listE.size());
        long jCurrentTimeMillis = System.currentTimeMillis();
        for (p pVar : listE) {
            String str = pVar.a;
            if (jCurrentTimeMillis >= pVar.a() && (!pVar.b() || this.d.c(str))) {
                arrayList.add(pVar);
            }
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            String str2 = ((p) it.next()).a;
            Intent intentB = b.b(this.a, str2);
            j.c().a(e, String.format("Creating a delay_met command for workSpec with id (%s)", str2), new Throwable[0]);
            e eVar = this.c;
            eVar.k(new e.b(eVar, intentB, this.b));
        }
        this.d.e();
    }
}
