package androidx.work.impl.background.systemalarm;

import android.content.Intent;
import ax.F2.h;
import ax.G0.j;
import ax.P2.y;

/* JADX INFO: loaded from: classes.dex */
public class SystemAlarmService extends j implements e.c {
    private static final String Z = h.i("SystemAlarmService");
    private e X;
    private boolean Y;

    private void e() {
        e eVar = new e(this);
        this.X = eVar;
        eVar.l(this);
    }

    @Override // androidx.work.impl.background.systemalarm.e.c
    public void a() {
        this.Y = true;
        h.e().a(Z, "All commands completed in dispatcher");
        y.a();
        stopSelf();
    }

    @Override // ax.G0.j, android.app.Service
    public void onCreate() {
        super.onCreate();
        e();
        this.Y = false;
    }

    @Override // ax.G0.j, android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.Y = true;
        this.X.j();
    }

    @Override // ax.G0.j, android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.Y) {
            h.e().f(Z, "Re-initializing SystemAlarmDispatcher after a request to shut-down.");
            this.X.j();
            e();
            this.Y = false;
        }
        if (intent == null) {
            return 3;
        }
        this.X.a(intent, i2);
        return 3;
    }
}
