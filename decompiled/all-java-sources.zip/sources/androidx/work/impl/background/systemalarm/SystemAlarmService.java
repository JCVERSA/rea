package androidx.work.impl.background.systemalarm;

import android.content.Intent;
import ax.F0.i;
import ax.p170m1.j;
import ax.p296v1.n;

/* JADX INFO: loaded from: classes.dex */
public class SystemAlarmService extends i implements e.c {
    private static final String Z = j.f("SystemAlarmService");
    private e X;
    private boolean Y;

    private void e() {
        e eVar = new e(this);
        this.X = eVar;
        eVar.m(this);
    }

    @Override // androidx.work.impl.background.systemalarm.e.c
    public void a() {
        this.Y = true;
        j.c().a(Z, "All commands completed in dispatcher", new Throwable[0]);
        n.a();
        stopSelf();
    }

    @Override // ax.F0.i, android.app.Service
    public void onCreate() {
        super.onCreate();
        e();
        this.Y = false;
    }

    @Override // ax.F0.i, android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.Y = true;
        this.X.j();
    }

    @Override // ax.F0.i, android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.Y) {
            j.c().d(Z, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
            this.X.j();
            e();
            this.Y = false;
        }
        if (intent == null) {
            return 3;
        }
        this.X.a(intent, i2);
        return 3;
    }
}
