package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.os.PowerManager;
import ax.F2.h;
import ax.G2.v;
import ax.M2.o;
import ax.O2.m;
import ax.O2.u;
import ax.O2.x;
import ax.P2.E;
import ax.P2.y;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public class d implements ax.K2.c, E.a {
    private static final String s0 = h.i("DelayMetCommandHandler");
    private final int X;
    private final m Y;
    private final e Z;
    private final ax.K2.e k0;
    private final Object l0;
    private int m0;
    private final Executor n0;
    private final Executor o0;
    private PowerManager.WakeLock p0;
    private final Context q;
    private boolean q0;
    private final v r0;

    d(Context context, int i, e eVar, v vVar) {
        this.q = context;
        this.X = i;
        this.Z = eVar;
        this.Y = vVar.a();
        this.r0 = vVar;
        o oVarO = eVar.g().o();
        this.n0 = eVar.e().b();
        this.o0 = eVar.e().a();
        this.k0 = new ax.K2.e(oVarO, this);
        this.q0 = false;
        this.m0 = 0;
        this.l0 = new Object();
    }

    private void f() {
        synchronized (this.l0) {
            try {
                this.k0.a();
                this.Z.h().b(this.Y);
                PowerManager.WakeLock wakeLock = this.p0;
                if (wakeLock != null && wakeLock.isHeld()) {
                    h.e().a(s0, "Releasing wakelock " + this.p0 + "for WorkSpec " + this.Y);
                    this.p0.release();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void i() {
        if (this.m0 != 0) {
            h.e().a(s0, "Already started work for " + this.Y);
            return;
        }
        this.m0 = 1;
        h.e().a(s0, "onAllConstraintsMet for " + this.Y);
        if (this.Z.d().n(this.r0)) {
            this.Z.h().a(this.Y, 600000L, this);
        } else {
            f();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void j() {
        String strB = this.Y.b();
        if (this.m0 >= 2) {
            h.e().a(s0, "Already stopped work for " + strB);
            return;
        }
        this.m0 = 2;
        h hVarE = h.e();
        String str = s0;
        hVarE.a(str, "Stopping work for WorkSpec " + strB);
        this.o0.execute(new e.b(this.Z, b.g(this.q, this.Y), this.X));
        if (!this.Z.d().k(this.Y.b())) {
            h.e().a(str, "Processor does not have WorkSpec " + strB + ". No need to reschedule");
            return;
        }
        h.e().a(str, "WorkSpec " + strB + " needs to be rescheduled");
        this.o0.execute(new e.b(this.Z, b.e(this.q, this.Y), this.X));
    }

    @Override // ax.P2.E.a
    public void a(m mVar) {
        h.e().a(s0, "Exceeded time limits on execution for " + mVar);
        this.n0.execute(new ax.I2.a(this));
    }

    @Override // ax.K2.c
    public void b(List<u> list) {
        this.n0.execute(new ax.I2.a(this));
    }

    @Override // ax.K2.c
    public void e(List<u> list) {
        Iterator<u> it = list.iterator();
        while (it.hasNext()) {
            if (x.a(it.next()).equals(this.Y)) {
                this.n0.execute(new Runnable() { // from class: ax.I2.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.q.i();
                    }
                });
                return;
            }
        }
    }

    void g() {
        String strB = this.Y.b();
        this.p0 = y.b(this.q, strB + " (" + this.X + ")");
        h hVarE = h.e();
        String str = s0;
        hVarE.a(str, "Acquiring wakelock " + this.p0 + "for WorkSpec " + strB);
        this.p0.acquire();
        u uVarN = this.Z.g().p().I().n(strB);
        if (uVarN == null) {
            this.n0.execute(new ax.I2.a(this));
            return;
        }
        boolean zF = uVarN.f();
        this.q0 = zF;
        if (zF) {
            this.k0.b(Collections.singletonList(uVarN));
            return;
        }
        h.e().a(str, "No constraints for " + strB);
        e(Collections.singletonList(uVarN));
    }

    void h(boolean z) {
        h.e().a(s0, "onExecuted " + this.Y + ", " + z);
        f();
        if (z) {
            this.o0.execute(new e.b(this.Z, b.e(this.q, this.Y), this.X));
        }
        if (this.q0) {
            this.o0.execute(new e.b(this.Z, b.a(this.q), this.X));
        }
    }
}
