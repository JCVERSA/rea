package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import ax.p170m1.j;
import ax.p282u1.p;
import ax.p296v1.n;
import ax.p296v1.r;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class d implements ax.p226q1.c, ax.p184n1.b, r.b {
    private static final String m0 = j.f("DelayMetCommandHandler");
    private final int X;
    private final String Y;
    private final e Z;
    private final ax.p226q1.d h0;
    private PowerManager.WakeLock k0;
    private final Context q;
    private boolean l0 = false;
    private int j0 = 0;
    private final Object i0 = new Object();

    d(Context context, int i, String str, e eVar) {
        this.q = context;
        this.X = i;
        this.Z = eVar;
        this.Y = str;
        this.h0 = new ax.p226q1.d(context, eVar.f(), this);
    }

    private void d() {
        synchronized (this.i0) {
            try {
                this.h0.e();
                this.Z.h().c(this.Y);
                PowerManager.WakeLock wakeLock = this.k0;
                if (wakeLock != null && wakeLock.isHeld()) {
                    j.c().a(m0, String.format("Releasing wakelock %s for WorkSpec %s", this.k0, this.Y), new Throwable[0]);
                    this.k0.release();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void g() {
        synchronized (this.i0) {
            try {
                if (this.j0 < 2) {
                    this.j0 = 2;
                    j jVarC = j.c();
                    String str = m0;
                    jVarC.a(str, String.format("Stopping work for WorkSpec %s", this.Y), new Throwable[0]);
                    Intent intentG = b.g(this.q, this.Y);
                    e eVar = this.Z;
                    eVar.k(new e.b(eVar, intentG, this.X));
                    if (this.Z.e().g(this.Y)) {
                        j.c().a(str, String.format("WorkSpec %s needs to be rescheduled", this.Y), new Throwable[0]);
                        Intent intentF = b.f(this.q, this.Y);
                        e eVar2 = this.Z;
                        eVar2.k(new e.b(eVar2, intentF, this.X));
                    } else {
                        j.c().a(str, String.format("Processor does not have WorkSpec %s. No need to reschedule ", this.Y), new Throwable[0]);
                    }
                } else {
                    j.c().a(m0, String.format("Already stopped work for %s", this.Y), new Throwable[0]);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // ax.v1.r.b
    public void a(String str) {
        j.c().a(m0, String.format("Exceeded time limits on execution for %s", str), new Throwable[0]);
        g();
    }

    @Override // ax.p226q1.c
    public void b(List<String> list) {
        g();
    }

    @Override // ax.p184n1.b
    public void c(String str, boolean z) {
        j.c().a(m0, String.format("onExecuted %s, %s", str, Boolean.valueOf(z)), new Throwable[0]);
        d();
        if (z) {
            Intent intentF = b.f(this.q, this.Y);
            e eVar = this.Z;
            eVar.k(new e.b(eVar, intentF, this.X));
        }
        if (this.l0) {
            Intent intentA = b.a(this.q);
            e eVar2 = this.Z;
            eVar2.k(new e.b(eVar2, intentA, this.X));
        }
    }

    void e() {
        this.k0 = n.b(this.q, String.format("%s (%s)", this.Y, Integer.valueOf(this.X)));
        j jVarC = j.c();
        String str = m0;
        jVarC.a(str, String.format("Acquiring wakelock %s for WorkSpec %s", this.k0, this.Y), new Throwable[0]);
        this.k0.acquire();
        p pVarM = this.Z.g().o().B().m(this.Y);
        if (pVarM == null) {
            g();
            return;
        }
        boolean zB = pVarM.b();
        this.l0 = zB;
        if (zB) {
            this.h0.d(Collections.singletonList(pVarM));
        } else {
            j.c().a(str, String.format("No constraints for %s", this.Y), new Throwable[0]);
            f(Collections.singletonList(this.Y));
        }
    }

    @Override // ax.p226q1.c
    public void f(List<String> list) {
        if (list.contains(this.Y)) {
            synchronized (this.i0) {
                try {
                    if (this.j0 == 0) {
                        this.j0 = 1;
                        j.c().a(m0, String.format("onAllConstraintsMet for %s", this.Y), new Throwable[0]);
                        if (this.Z.e().j(this.Y)) {
                            this.Z.h().b(this.Y, 600000L, this);
                        } else {
                            d();
                        }
                    } else {
                        j.c().a(m0, String.format("Already started work for %s", this.Y), new Throwable[0]);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }
}
