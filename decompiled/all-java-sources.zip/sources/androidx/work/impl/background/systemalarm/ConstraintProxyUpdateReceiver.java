package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import ax.p170m1.j;
import ax.p296v1.g;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
    static final String a = j.f("ConstrntProxyUpdtRecvr");

    class a implements Runnable {
        final /* synthetic */ Context X;
        final /* synthetic */ BroadcastReceiver.PendingResult Y;
        final /* synthetic */ Intent q;

        a(Intent intent, Context context, BroadcastReceiver.PendingResult pendingResult) {
            this.q = intent;
            this.X = context;
            this.Y = pendingResult;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                boolean booleanExtra = this.q.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
                boolean booleanExtra2 = this.q.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
                boolean booleanExtra3 = this.q.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
                boolean booleanExtra4 = this.q.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
                j.c().a(ConstraintProxyUpdateReceiver.a, String.format("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", Boolean.valueOf(booleanExtra), Boolean.valueOf(booleanExtra2), Boolean.valueOf(booleanExtra3), Boolean.valueOf(booleanExtra4)), new Throwable[0]);
                g.a(this.X, ConstraintProxy.BatteryNotLowProxy.class, booleanExtra);
                g.a(this.X, ConstraintProxy.BatteryChargingProxy.class, booleanExtra2);
                g.a(this.X, ConstraintProxy.StorageNotLowProxy.class, booleanExtra3);
                g.a(this.X, ConstraintProxy.NetworkStateProxy.class, booleanExtra4);
            } finally {
                this.Y.finish();
            }
        }
    }

    public static Intent a(Context context, boolean z, boolean z2, boolean z3, boolean z4) {
        Intent intent = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
        intent.setComponent(new ComponentName(context, (Class<?>) ConstraintProxyUpdateReceiver.class));
        intent.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", z).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", z2).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", z3).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", z4);
        return intent;
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if ("androidx.work.impl.background.systemalarm.UpdateProxies".equals(action)) {
            ax.p184n1.j.k(context).p().b(new a(intent, context, goAsync()));
        } else {
            j.c().a(a, String.format("Ignoring unknown action %s", action), new Throwable[0]);
        }
    }
}
