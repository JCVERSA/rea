package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import ax.p170m1.j;
import ax.p184n1.b;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class SystemJobService extends JobService implements b {
    private static final String Y = j.f("SystemJobService");
    private final Map<String, JobParameters> X = new HashMap();
    private ax.p184n1.j q;

    private static String a(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras == null || !extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return extras.getString("EXTRA_WORK_SPEC_ID");
        } catch (NullPointerException unused) {
            return null;
        }
    }

    @Override // ax.p184n1.b
    public void c(String str, boolean z) {
        JobParameters jobParametersRemove;
        j.c().a(Y, String.format("%s executed on JobScheduler", str), new Throwable[0]);
        synchronized (this.X) {
            jobParametersRemove = this.X.remove(str);
        }
        if (jobParametersRemove != null) {
            jobFinished(jobParametersRemove, z);
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        try {
            ax.p184n1.j jVarK = ax.p184n1.j.k(getApplicationContext());
            this.q = jVarK;
            jVarK.m().d(this);
        } catch (IllegalStateException unused) {
            if (!Application.class.equals(getApplication().getClass())) {
                throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
            }
            j.c().h(Y, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        ax.p184n1.j jVar = this.q;
        if (jVar != null) {
            jVar.m().i(this);
        }
    }

    @Override // android.app.job.JobService
    public boolean onStartJob(JobParameters jobParameters) {
        WorkerParameters.a aVar;
        if (this.q == null) {
            j.c().a(Y, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
            jobFinished(jobParameters, true);
            return false;
        }
        String strA = a(jobParameters);
        if (TextUtils.isEmpty(strA)) {
            j.c().b(Y, "WorkSpec id not found!", new Throwable[0]);
            return false;
        }
        synchronized (this.X) {
            try {
                if (this.X.containsKey(strA)) {
                    j.c().a(Y, String.format("Job is already being executed by SystemJobService: %s", strA), new Throwable[0]);
                    return false;
                }
                j.c().a(Y, String.format("onStartJob for %s", strA), new Throwable[0]);
                this.X.put(strA, jobParameters);
                int i = Build.VERSION.SDK_INT;
                if (i >= 24) {
                    aVar = new WorkerParameters.a();
                    if (jobParameters.getTriggeredContentUris() != null) {
                        aVar.b = Arrays.asList(jobParameters.getTriggeredContentUris());
                    }
                    if (jobParameters.getTriggeredContentAuthorities() != null) {
                        aVar.a = Arrays.asList(jobParameters.getTriggeredContentAuthorities());
                    }
                    if (i >= 28) {
                        aVar.c = jobParameters.getNetwork();
                    }
                } else {
                    aVar = null;
                }
                this.q.v(strA, aVar);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // android.app.job.JobService
    public boolean onStopJob(JobParameters jobParameters) {
        if (this.q == null) {
            j.c().a(Y, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
            return true;
        }
        String strA = a(jobParameters);
        if (TextUtils.isEmpty(strA)) {
            j.c().b(Y, "WorkSpec id not found!", new Throwable[0]);
            return false;
        }
        j.c().a(Y, String.format("onStopJob for %s", strA), new Throwable[0]);
        synchronized (this.X) {
            this.X.remove(strA);
        }
        this.q.x(strA);
        return !this.q.m().f(strA);
    }
}
