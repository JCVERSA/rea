package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.PersistableBundle;
import androidx.work.WorkerParameters;
import ax.F2.h;
import ax.G2.D;
import ax.G2.InterfaceC0827e;
import ax.G2.v;
import ax.G2.w;
import ax.O2.m;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class SystemJobService extends JobService implements InterfaceC0827e {
    private static final String Z = h.i("SystemJobService");
    private final Map<m, JobParameters> X = new HashMap();
    private final w Y = new w();
    private D q;

    static class a {
        static String[] a(JobParameters jobParameters) {
            return jobParameters.getTriggeredContentAuthorities();
        }

        static Uri[] b(JobParameters jobParameters) {
            return jobParameters.getTriggeredContentUris();
        }
    }

    static class b {
        static Network a(JobParameters jobParameters) {
            return jobParameters.getNetwork();
        }
    }

    private static m a(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras == null || !extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return new m(extras.getString("EXTRA_WORK_SPEC_ID"), extras.getInt("EXTRA_WORK_SPEC_GENERATION"));
        } catch (NullPointerException unused) {
            return null;
        }
    }

    @Override // ax.G2.InterfaceC0827e
    public void f(m mVar, boolean z) {
        JobParameters jobParametersRemove;
        h.e().a(Z, mVar.b() + " executed on JobScheduler");
        synchronized (this.X) {
            jobParametersRemove = this.X.remove(mVar);
        }
        this.Y.b(mVar);
        if (jobParametersRemove != null) {
            jobFinished(jobParametersRemove, z);
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        try {
            D dK = D.k(getApplicationContext());
            this.q = dK;
            dK.m().g(this);
        } catch (IllegalStateException unused) {
            if (!Application.class.equals(getApplication().getClass())) {
                throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
            }
            h.e().k(Z, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.");
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        D d = this.q;
        if (d != null) {
            d.m().l(this);
        }
    }

    @Override // android.app.job.JobService
    public boolean onStartJob(JobParameters jobParameters) {
        WorkerParameters.a aVar;
        if (this.q == null) {
            h.e().a(Z, "WorkManager is not initialized; requesting retry.");
            jobFinished(jobParameters, true);
            return false;
        }
        m mVarA = a(jobParameters);
        if (mVarA == null) {
            h.e().c(Z, "WorkSpec id not found!");
            return false;
        }
        synchronized (this.X) {
            try {
                if (this.X.containsKey(mVarA)) {
                    h.e().a(Z, "Job is already being executed by SystemJobService: " + mVarA);
                    return false;
                }
                h.e().a(Z, "onStartJob for " + mVarA);
                this.X.put(mVarA, jobParameters);
                int i = Build.VERSION.SDK_INT;
                if (i >= 24) {
                    aVar = new WorkerParameters.a();
                    if (a.b(jobParameters) != null) {
                        aVar.b = Arrays.asList(a.b(jobParameters));
                    }
                    if (a.a(jobParameters) != null) {
                        aVar.a = Arrays.asList(a.a(jobParameters));
                    }
                    if (i >= 28) {
                        aVar.c = b.a(jobParameters);
                    }
                } else {
                    aVar = null;
                }
                this.q.w(this.Y.d(mVarA), aVar);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // android.app.job.JobService
    public boolean onStopJob(JobParameters jobParameters) {
        if (this.q == null) {
            h.e().a(Z, "WorkManager is not initialized; requesting retry.");
            return true;
        }
        m mVarA = a(jobParameters);
        if (mVarA == null) {
            h.e().c(Z, "WorkSpec id not found!");
            return false;
        }
        h.e().a(Z, "onStopJob for " + mVarA);
        synchronized (this.X) {
            this.X.remove(mVarA);
        }
        v vVarB = this.Y.b(mVarA);
        if (vVarB != null) {
            this.q.y(vVarB);
        }
        return !this.q.m().j(mVarA.b());
    }
}
