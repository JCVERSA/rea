package androidx.work.impl.utils;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.ApplicationExitInfo;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteDiskIOException;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteTableLockedException;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.a;
import androidx.work.impl.WorkDatabase;
import ax.F2.h;
import ax.F2.q;
import ax.G2.A;
import ax.G2.D;
import ax.J2.l;
import ax.O2.r;
import ax.O2.u;
import ax.O2.v;
import ax.P2.f;
import ax.P2.s;
import ax.P2.t;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public class ForceStopRunnable implements Runnable {
    private static final String k0 = h.i("ForceStopRunnable");
    private static final long l0 = TimeUnit.DAYS.toMillis(3650);
    private final D X;
    private final s Y;
    private int Z = 0;
    private final Context q;

    public static class BroadcastReceiver extends android.content.BroadcastReceiver {
        private static final String a = h.i("ForceStopRunnable$Rcvr");

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !"ACTION_FORCE_STOP_RESCHEDULE".equals(intent.getAction())) {
                return;
            }
            h.e().j(a, "Rescheduling alarm that keeps track of force-stops.");
            ForceStopRunnable.g(context);
        }
    }

    public ForceStopRunnable(Context context, D d) {
        this.q = context.getApplicationContext();
        this.X = d;
        this.Y = d.l();
    }

    static Intent c(Context context) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, (Class<?>) BroadcastReceiver.class));
        intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
        return intent;
    }

    private static PendingIntent d(Context context, int i) {
        return PendingIntent.getBroadcast(context, -1, c(context), i);
    }

    @SuppressLint({"ClassVerificationFailure"})
    static void g(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent pendingIntentD = d(context, Build.VERSION.SDK_INT >= 31 ? 167772160 : 134217728);
        long jCurrentTimeMillis = System.currentTimeMillis() + l0;
        if (alarmManager != null) {
            alarmManager.setExact(0, jCurrentTimeMillis, pendingIntentD);
        }
    }

    public boolean a() {
        boolean zI = Build.VERSION.SDK_INT >= 23 ? l.i(this.q, this.X) : false;
        WorkDatabase workDatabaseP = this.X.p();
        v vVarI = workDatabaseP.I();
        r rVarH = workDatabaseP.H();
        workDatabaseP.e();
        try {
            List<u> listI = vVarI.i();
            boolean z = (listI == null || listI.isEmpty()) ? false : true;
            if (z) {
                for (u uVar : listI) {
                    vVarI.h(q.ENQUEUED, uVar.a);
                    vVarI.b(uVar.a, -1L);
                }
            }
            rVarH.U();
            workDatabaseP.A();
            workDatabaseP.i();
            return z || zI;
        } catch (Throwable th) {
            workDatabaseP.i();
            throw th;
        }
    }

    public void b() {
        boolean zA = a();
        if (h()) {
            h.e().a(k0, "Rescheduling Workers.");
            this.X.t();
            this.X.l().e(false);
        } else if (e()) {
            h.e().a(k0, "Application was force-stopped, rescheduling.");
            this.X.t();
            this.Y.d(System.currentTimeMillis());
        } else if (zA) {
            h.e().a(k0, "Found unfinished work, scheduling it.");
            ax.G2.u.b(this.X.i(), this.X.p(), this.X.n());
        }
    }

    @SuppressLint({"ClassVerificationFailure"})
    public boolean e() {
        try {
            int i = Build.VERSION.SDK_INT;
            PendingIntent pendingIntentD = d(this.q, i >= 31 ? 570425344 : 536870912);
            if (i >= 30) {
                if (pendingIntentD != null) {
                    pendingIntentD.cancel();
                }
                List historicalProcessExitReasons = ((ActivityManager) this.q.getSystemService("activity")).getHistoricalProcessExitReasons(null, 0, 0);
                if (historicalProcessExitReasons != null && !historicalProcessExitReasons.isEmpty()) {
                    long jA = this.Y.a();
                    for (int i2 = 0; i2 < historicalProcessExitReasons.size(); i2++) {
                        ApplicationExitInfo applicationExitInfoA = f.a(historicalProcessExitReasons.get(i2));
                        if (applicationExitInfoA.getReason() == 10 && applicationExitInfoA.getTimestamp() >= jA) {
                            return true;
                        }
                    }
                }
            } else if (pendingIntentD == null) {
                g(this.q);
                return true;
            }
            return false;
        } catch (IllegalArgumentException e) {
            e = e;
            h.e().l(k0, "Ignoring exception", e);
            return true;
        } catch (SecurityException e2) {
            e = e2;
            h.e().l(k0, "Ignoring exception", e);
            return true;
        }
    }

    public boolean f() {
        a aVarI = this.X.i();
        if (TextUtils.isEmpty(aVarI.c())) {
            h.e().a(k0, "The default process name was not specified.");
            return true;
        }
        boolean zB = t.b(this.q, aVarI);
        h.e().a(k0, "Is default app process = " + zB);
        return zB;
    }

    public boolean h() {
        return this.X.l().b();
    }

    public void i(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        int i;
        try {
            if (!f()) {
                this.X.s();
                return;
            }
            while (true) {
                try {
                    A.d(this.q);
                    h.e().a(k0, "Performing cleanup operations.");
                    try {
                        b();
                        break;
                    } catch (SQLiteAccessPermException | SQLiteCantOpenDatabaseException | SQLiteConstraintException | SQLiteDatabaseCorruptException | SQLiteDatabaseLockedException | SQLiteDiskIOException | SQLiteTableLockedException e) {
                        i = this.Z + 1;
                        this.Z = i;
                        if (i >= 3) {
                            h hVarE = h.e();
                            String str = k0;
                            hVarE.d(str, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
                            IllegalStateException illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
                            ax.p019b0.a<Throwable> aVarE = this.X.i().e();
                            if (aVarE == null) {
                                throw illegalStateException;
                            }
                            h.e().b(str, "Routing exception to the specified exception handler", illegalStateException);
                            aVarE.accept(illegalStateException);
                            break;
                        }
                        h.e().b(k0, "Retrying after " + (((long) i) * 300), e);
                        i(((long) this.Z) * 300);
                    }
                    h.e().b(k0, "Retrying after " + (((long) i) * 300), e);
                    i(((long) this.Z) * 300);
                } catch (SQLiteException e2) {
                    h.e().c(k0, "Unexpected SQLite exception during migrations");
                    IllegalStateException illegalStateException2 = new IllegalStateException("Unexpected SQLite exception during migrations", e2);
                    ax.p019b0.a<Throwable> aVarE2 = this.X.i().e();
                    if (aVarE2 == null) {
                        throw illegalStateException2;
                    }
                    aVarE2.accept(illegalStateException2);
                }
            }
            this.X.s();
        } catch (Throwable th) {
            this.X.s();
            throw th;
        }
    }
}
