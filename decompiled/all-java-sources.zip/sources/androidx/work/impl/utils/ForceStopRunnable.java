package androidx.work.impl.utils;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import ax.X.a;
import ax.p170m1.g;
import ax.p170m1.j;
import ax.p170m1.s;
import ax.p184n1.f;
import ax.p184n1.h;
import ax.p212p1.l;
import ax.p282u1.n;
import ax.p282u1.p;
import ax.p282u1.q;
import ax.p296v1.d;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public class ForceStopRunnable implements Runnable {
    private static final String Z = j.f("ForceStopRunnable");
    private static final long h0 = TimeUnit.DAYS.toMillis(3650);
    private final ax.p184n1.j X;
    private int Y = 0;
    private final Context q;

    public static class BroadcastReceiver extends android.content.BroadcastReceiver {
        private static final String a = j.f("ForceStopRunnable$Rcvr");

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !"ACTION_FORCE_STOP_RESCHEDULE".equals(intent.getAction())) {
                return;
            }
            j.c().g(a, "Rescheduling alarm that keeps track of force-stops.", new Throwable[0]);
            ForceStopRunnable.g(context);
        }
    }

    public ForceStopRunnable(Context context, ax.p184n1.j jVar) {
        this.q = context.getApplicationContext();
        this.X = jVar;
    }

    static Intent c(Context context) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, (Class<?>) BroadcastReceiver.class));
        intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
        return intent;
    }

    private static PendingIntent d(Context context, int i) {
        return PendingIntent.getBroadcast(context, -1, c(context), i);
    }

    @SuppressLint({"ClassVerificationFailure"})
    static void g(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        PendingIntent pendingIntentD = d(context, a.b() ? 167772160 : 134217728);
        long jCurrentTimeMillis = System.currentTimeMillis() + h0;
        if (alarmManager != null) {
            alarmManager.setExact(0, jCurrentTimeMillis, pendingIntentD);
        }
    }

    public boolean a() {
        boolean zI = Build.VERSION.SDK_INT >= 23 ? l.i(this.q, this.X) : false;
        WorkDatabase workDatabaseO = this.X.o();
        q qVarB = workDatabaseO.B();
        n nVarA = workDatabaseO.A();
        workDatabaseO.c();
        try {
            List<p> listH = qVarB.h();
            boolean z = (listH == null || listH.isEmpty()) ? false : true;
            if (z) {
                for (p pVar : listH) {
                    qVarB.g(s.ENQUEUED, pVar.a);
                    qVarB.a(pVar.a, -1L);
                }
            }
            nVarA.a();
            workDatabaseO.r();
            workDatabaseO.g();
            return z || zI;
        } catch (Throwable th) {
            workDatabaseO.g();
            throw th;
        }
    }

    public void b() {
        boolean zA = a();
        if (h()) {
            j.c().a(Z, "Rescheduling Workers.", new Throwable[0]);
            this.X.s();
            this.X.l().c(false);
        } else if (e()) {
            j.c().a(Z, "Application was force-stopped, rescheduling.", new Throwable[0]);
            this.X.s();
        } else if (zA) {
            j.c().a(Z, "Found unfinished work, scheduling it.", new Throwable[0]);
            f.b(this.X.i(), this.X.o(), this.X.n());
        }
    }

    @SuppressLint({"ClassVerificationFailure"})
    public boolean e() {
        try {
            PendingIntent pendingIntentD = d(this.q, a.b() ? 570425344 : 536870912);
            if (Build.VERSION.SDK_INT >= 30) {
                if (pendingIntentD != null) {
                    pendingIntentD.cancel();
                }
                List historicalProcessExitReasons = ((ActivityManager) this.q.getSystemService("activity")).getHistoricalProcessExitReasons(null, 0, 0);
                if (historicalProcessExitReasons != null && !historicalProcessExitReasons.isEmpty()) {
                    for (int i = 0; i < historicalProcessExitReasons.size(); i++) {
                        if (d.a(historicalProcessExitReasons.get(i)).getReason() == 10) {
                            return true;
                        }
                    }
                }
            } else if (pendingIntentD == null) {
                g(this.q);
                return true;
            }
            return false;
        } catch (IllegalArgumentException e) {
            e = e;
            j.c().h(Z, "Ignoring exception", e);
            return true;
        } catch (SecurityException e2) {
            e = e2;
            j.c().h(Z, "Ignoring exception", e);
            return true;
        }
    }

    public boolean f() {
        androidx.work.a aVarI = this.X.i();
        if (TextUtils.isEmpty(aVarI.c())) {
            j.c().a(Z, "The default process name was not specified.", new Throwable[0]);
            return true;
        }
        boolean zB = ax.p296v1.j.b(this.q, aVarI);
        j.c().a(Z, String.format("Is default app process = %s", Boolean.valueOf(zB)), new Throwable[0]);
        return zB;
    }

    boolean h() {
        return this.X.l().a();
    }

    public void i(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        int i;
        try {
            if (!f()) {
                this.X.r();
                return;
            }
            while (true) {
                h.e(this.q);
                j.c().a(Z, "Performing cleanup operations.", new Throwable[0]);
                try {
                    b();
                    break;
                } catch (SQLiteAccessPermException | SQLiteCantOpenDatabaseException | SQLiteConstraintException | SQLiteDatabaseCorruptException | SQLiteDatabaseLockedException | SQLiteTableLockedException e) {
                    i = this.Y + 1;
                    this.Y = i;
                    if (i >= 3) {
                        j jVarC = j.c();
                        String str = Z;
                        jVarC.b(str, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
                        IllegalStateException illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", e);
                        g gVarD = this.X.i().d();
                        if (gVarD == null) {
                            throw illegalStateException;
                        }
                        j.c().a(str, "Routing exception to the specified exception handler", illegalStateException);
                        gVarD.a(illegalStateException);
                        break;
                    }
                    j.c().a(Z, String.format("Retrying after %s", Long.valueOf(((long) i) * 300)), e);
                    i(((long) this.Y) * 300);
                }
                j.c().a(Z, String.format("Retrying after %s", Long.valueOf(((long) i) * 300)), e);
                i(((long) this.Y) * 300);
            }
            this.X.r();
        } catch (Throwable th) {
            this.X.r();
            throw th;
        }
    }
}
