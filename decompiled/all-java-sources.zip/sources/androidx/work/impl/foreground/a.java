package androidx.work.impl.foreground;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import ax.p170m1.e;
import ax.p170m1.j;
import ax.p226q1.c;
import ax.p226q1.d;
import ax.p282u1.p;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/* JADX INFO: loaded from: classes.dex */
public class a implements c, ax.p184n1.b {
    static final String n0 = j.f("SystemFgDispatcher");
    private ax.p184n1.j X;
    private final ax.p324x1.a Y;
    final Object Z = new Object();
    String h0;
    final Map<String, e> i0;
    final Map<String, p> j0;
    final Set<p> k0;
    final d l0;
    private b m0;
    private Context q;

    /* JADX INFO: renamed from: androidx.work.impl.foreground.a$a, reason: collision with other inner class name */
    class RunnableC0049a implements Runnable {
        final /* synthetic */ String X;
        final /* synthetic */ WorkDatabase q;

        RunnableC0049a(WorkDatabase workDatabase, String str) {
            this.q = workDatabase;
            this.X = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            p pVarM = this.q.B().m(this.X);
            if (pVarM == null || !pVarM.b()) {
                return;
            }
            synchronized (a.this.Z) {
                a.this.j0.put(this.X, pVarM);
                a.this.k0.add(pVarM);
                a aVar = a.this;
                aVar.l0.d(aVar.k0);
            }
        }
    }

    interface b {
        void b(int i, int i2, Notification notification);

        void c(int i, Notification notification);

        void d(int i);

        void stop();
    }

    a(Context context) {
        this.q = context;
        ax.p184n1.j jVarK = ax.p184n1.j.k(context);
        this.X = jVarK;
        ax.p324x1.a aVarP = jVarK.p();
        this.Y = aVarP;
        this.h0 = null;
        this.i0 = new LinkedHashMap();
        this.k0 = new HashSet();
        this.j0 = new HashMap();
        this.l0 = new d(this.q, aVarP, this);
        this.X.m().d(this);
    }

    public static Intent a(Context context, String str, e eVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_NOTIFY");
        intent.putExtra("KEY_NOTIFICATION_ID", eVar.c());
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", eVar.a());
        intent.putExtra("KEY_NOTIFICATION", eVar.b());
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    public static Intent d(Context context, String str, e eVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_START_FOREGROUND");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        intent.putExtra("KEY_NOTIFICATION_ID", eVar.c());
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", eVar.a());
        intent.putExtra("KEY_NOTIFICATION", eVar.b());
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    public static Intent e(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_STOP_FOREGROUND");
        return intent;
    }

    private void g(Intent intent) {
        j.c().d(n0, String.format("Stopping foreground work for %s", intent), new Throwable[0]);
        String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
        if (stringExtra == null || TextUtils.isEmpty(stringExtra)) {
            return;
        }
        this.X.f(UUID.fromString(stringExtra));
    }

    private void h(Intent intent) {
        int iA = 0;
        int intExtra = intent.getIntExtra("KEY_NOTIFICATION_ID", 0);
        int intExtra2 = intent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
        String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
        Notification notification = (Notification) intent.getParcelableExtra("KEY_NOTIFICATION");
        j.c().a(n0, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", Integer.valueOf(intExtra), stringExtra, Integer.valueOf(intExtra2)), new Throwable[0]);
        if (notification == null || this.m0 == null) {
            return;
        }
        this.i0.put(stringExtra, new e(intExtra, notification, intExtra2));
        if (TextUtils.isEmpty(this.h0)) {
            this.h0 = stringExtra;
            this.m0.b(intExtra, intExtra2, notification);
            return;
        }
        this.m0.c(intExtra, notification);
        if (intExtra2 == 0 || Build.VERSION.SDK_INT < 29) {
            return;
        }
        Iterator<Map.Entry<String, e>> it = this.i0.entrySet().iterator();
        while (it.hasNext()) {
            iA |= it.next().getValue().a();
        }
        e eVar = this.i0.get(this.h0);
        if (eVar != null) {
            this.m0.b(eVar.c(), iA, eVar.b());
        }
    }

    private void i(Intent intent) {
        j.c().d(n0, String.format("Started foreground service %s", intent), new Throwable[0]);
        this.Y.b(new RunnableC0049a(this.X.o(), intent.getStringExtra("KEY_WORKSPEC_ID")));
    }

    @Override // ax.p226q1.c
    public void b(List<String> list) {
        if (list.isEmpty()) {
            return;
        }
        for (String str : list) {
            j.c().a(n0, String.format("Constraints unmet for WorkSpec %s", str), new Throwable[0]);
            this.X.w(str);
        }
    }

    @Override // ax.p184n1.b
    public void c(String str, boolean z) {
        Map.Entry<String, e> entry;
        synchronized (this.Z) {
            try {
                p pVarRemove = this.j0.remove(str);
                if (pVarRemove != null ? this.k0.remove(pVarRemove) : false) {
                    this.l0.d(this.k0);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        e eVarRemove = this.i0.remove(str);
        if (str.equals(this.h0) && this.i0.size() > 0) {
            Iterator<Map.Entry<String, e>> it = this.i0.entrySet().iterator();
            Map.Entry<String, e> next = it.next();
            while (true) {
                entry = next;
                if (!it.hasNext()) {
                    break;
                } else {
                    next = it.next();
                }
            }
            this.h0 = entry.getKey();
            if (this.m0 != null) {
                e value = entry.getValue();
                this.m0.b(value.c(), value.a(), value.b());
                this.m0.d(value.c());
            }
        }
        b bVar = this.m0;
        if (eVarRemove == null || bVar == null) {
            return;
        }
        j.c().a(n0, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", Integer.valueOf(eVarRemove.c()), str, Integer.valueOf(eVarRemove.a())), new Throwable[0]);
        bVar.d(eVarRemove.c());
    }

    @Override // ax.p226q1.c
    public void f(List<String> list) {
    }

    void j(Intent intent) {
        j.c().d(n0, "Stopping foreground service", new Throwable[0]);
        b bVar = this.m0;
        if (bVar != null) {
            bVar.stop();
        }
    }

    void k() {
        this.m0 = null;
        synchronized (this.Z) {
            this.l0.e();
        }
        this.X.m().i(this);
    }

    void l(Intent intent) {
        String action = intent.getAction();
        if ("ACTION_START_FOREGROUND".equals(action)) {
            i(intent);
            h(intent);
        } else if ("ACTION_NOTIFY".equals(action)) {
            h(intent);
        } else if ("ACTION_CANCEL_WORK".equals(action)) {
            g(intent);
        } else if ("ACTION_STOP_FOREGROUND".equals(action)) {
            j(intent);
        }
    }

    void m(b bVar) {
        if (this.m0 != null) {
            j.c().b(n0, "A callback already exists.", new Throwable[0]);
        } else {
            this.m0 = bVar;
        }
    }
}
