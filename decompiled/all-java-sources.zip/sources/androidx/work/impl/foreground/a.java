package androidx.work.impl.foreground;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import ax.F2.d;
import ax.F2.h;
import ax.G2.D;
import ax.G2.InterfaceC0827e;
import ax.K2.c;
import ax.K2.e;
import ax.O2.m;
import ax.O2.u;
import ax.O2.x;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/* JADX INFO: loaded from: classes.dex */
public class a implements c, InterfaceC0827e {
    static final String q0 = h.i("SystemFgDispatcher");
    private D X;
    private final ax.R2.c Y;
    final Object Z = new Object();
    m k0;
    final Map<m, d> l0;
    final Map<m, u> m0;
    final Set<u> n0;
    final ax.K2.d o0;
    private b p0;
    private Context q;

    /* JADX INFO: renamed from: androidx.work.impl.foreground.a$a, reason: collision with other inner class name */
    class RunnableC0051a implements Runnable {
        final /* synthetic */ String q;

        RunnableC0051a(String str) {
            this.q = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            u uVarH = a.this.X.m().h(this.q);
            if (uVarH == null || !uVarH.f()) {
                return;
            }
            synchronized (a.this.Z) {
                a.this.m0.put(x.a(uVarH), uVarH);
                a.this.n0.add(uVarH);
                a aVar = a.this;
                aVar.o0.b(aVar.n0);
            }
        }
    }

    interface b {
        void b(int i, int i2, Notification notification);

        void c(int i, Notification notification);

        void d(int i);

        void stop();
    }

    a(Context context) {
        this.q = context;
        D dK = D.k(context);
        this.X = dK;
        this.Y = dK.q();
        this.k0 = null;
        this.l0 = new LinkedHashMap();
        this.n0 = new HashSet();
        this.m0 = new HashMap();
        this.o0 = new e(this.X.o(), this);
        this.X.m().g(this);
    }

    public static Intent c(Context context, m mVar, d dVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_NOTIFY");
        intent.putExtra("KEY_NOTIFICATION_ID", dVar.c());
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", dVar.a());
        intent.putExtra("KEY_NOTIFICATION", dVar.b());
        intent.putExtra("KEY_WORKSPEC_ID", mVar.b());
        intent.putExtra("KEY_GENERATION", mVar.a());
        return intent;
    }

    public static Intent d(Context context, m mVar, d dVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_START_FOREGROUND");
        intent.putExtra("KEY_WORKSPEC_ID", mVar.b());
        intent.putExtra("KEY_GENERATION", mVar.a());
        intent.putExtra("KEY_NOTIFICATION_ID", dVar.c());
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", dVar.a());
        intent.putExtra("KEY_NOTIFICATION", dVar.b());
        return intent;
    }

    public static Intent g(Context context) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_STOP_FOREGROUND");
        return intent;
    }

    private void h(Intent intent) {
        h.e().f(q0, "Stopping foreground work for " + intent);
        String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
        if (stringExtra == null || TextUtils.isEmpty(stringExtra)) {
            return;
        }
        this.X.f(UUID.fromString(stringExtra));
    }

    private void i(Intent intent) {
        int iA = 0;
        int intExtra = intent.getIntExtra("KEY_NOTIFICATION_ID", 0);
        int intExtra2 = intent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
        String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
        m mVar = new m(stringExtra, intent.getIntExtra("KEY_GENERATION", 0));
        Notification notification = (Notification) intent.getParcelableExtra("KEY_NOTIFICATION");
        h.e().a(q0, "Notifying with (id:" + intExtra + ", workSpecId: " + stringExtra + ", notificationType :" + intExtra2 + ")");
        if (notification == null || this.p0 == null) {
            return;
        }
        this.l0.put(mVar, new d(intExtra, notification, intExtra2));
        if (this.k0 == null) {
            this.k0 = mVar;
            this.p0.b(intExtra, intExtra2, notification);
            return;
        }
        this.p0.c(intExtra, notification);
        if (intExtra2 == 0 || Build.VERSION.SDK_INT < 29) {
            return;
        }
        Iterator<Map.Entry<m, d>> it = this.l0.entrySet().iterator();
        while (it.hasNext()) {
            iA |= it.next().getValue().a();
        }
        d dVar = this.l0.get(this.k0);
        if (dVar != null) {
            this.p0.b(dVar.c(), iA, dVar.b());
        }
    }

    private void j(Intent intent) {
        h.e().f(q0, "Started foreground service " + intent);
        this.Y.c(new RunnableC0051a(intent.getStringExtra("KEY_WORKSPEC_ID")));
    }

    @Override // ax.K2.c
    public void b(List<u> list) {
        if (list.isEmpty()) {
            return;
        }
        for (u uVar : list) {
            String str = uVar.a;
            h.e().a(q0, "Constraints unmet for WorkSpec " + str);
            this.X.x(x.a(uVar));
        }
    }

    @Override // ax.K2.c
    public void e(List<u> list) {
    }

    @Override // ax.G2.InterfaceC0827e
    public void f(m mVar, boolean z) {
        Map.Entry<m, d> entry;
        synchronized (this.Z) {
            try {
                u uVarRemove = this.m0.remove(mVar);
                if (uVarRemove != null ? this.n0.remove(uVarRemove) : false) {
                    this.o0.b(this.n0);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        d dVarRemove = this.l0.remove(mVar);
        if (mVar.equals(this.k0) && this.l0.size() > 0) {
            Iterator<Map.Entry<m, d>> it = this.l0.entrySet().iterator();
            Map.Entry<m, d> next = it.next();
            while (true) {
                entry = next;
                if (!it.hasNext()) {
                    break;
                } else {
                    next = it.next();
                }
            }
            this.k0 = entry.getKey();
            if (this.p0 != null) {
                d value = entry.getValue();
                this.p0.b(value.c(), value.a(), value.b());
                this.p0.d(value.c());
            }
        }
        b bVar = this.p0;
        if (dVarRemove == null || bVar == null) {
            return;
        }
        h.e().a(q0, "Removing Notification (id: " + dVarRemove.c() + ", workSpecId: " + mVar + ", notificationType: " + dVarRemove.a());
        bVar.d(dVarRemove.c());
    }

    void k(Intent intent) {
        h.e().f(q0, "Stopping foreground service");
        b bVar = this.p0;
        if (bVar != null) {
            bVar.stop();
        }
    }

    void l() {
        this.p0 = null;
        synchronized (this.Z) {
            this.o0.a();
        }
        this.X.m().l(this);
    }

    void m(Intent intent) {
        String action = intent.getAction();
        if ("ACTION_START_FOREGROUND".equals(action)) {
            j(intent);
            i(intent);
        } else if ("ACTION_NOTIFY".equals(action)) {
            i(intent);
        } else if ("ACTION_CANCEL_WORK".equals(action)) {
            h(intent);
        } else if ("ACTION_STOP_FOREGROUND".equals(action)) {
            k(intent);
        }
    }

    void n(b bVar) {
        if (this.p0 != null) {
            h.e().c(q0, "A callback already exists.");
        } else {
            this.p0 = bVar;
        }
    }
}
