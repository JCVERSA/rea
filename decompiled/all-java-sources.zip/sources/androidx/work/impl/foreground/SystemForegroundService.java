package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import ax.F0.i;
import ax.p170m1.j;

/* JADX INFO: loaded from: classes.dex */
public class SystemForegroundService extends i implements androidx.work.impl.foreground.a.b {
    private static final String i0 = j.f("SystemFgService");
    private static SystemForegroundService j0 = null;
    private Handler X;
    private boolean Y;
    androidx.work.impl.foreground.a Z;
    NotificationManager h0;

    class a implements Runnable {
        final /* synthetic */ Notification X;
        final /* synthetic */ int Y;
        final /* synthetic */ int q;

        a(int i, Notification notification, int i2) {
            this.q = i;
            this.X = notification;
            this.Y = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (Build.VERSION.SDK_INT >= 29) {
                SystemForegroundService.this.startForeground(this.q, this.X, this.Y);
            } else {
                SystemForegroundService.this.startForeground(this.q, this.X);
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ Notification X;
        final /* synthetic */ int q;

        b(int i, Notification notification) {
            this.q = i;
            this.X = notification;
        }

        @Override // java.lang.Runnable
        public void run() {
            SystemForegroundService.this.h0.notify(this.q, this.X);
        }
    }

    class c implements Runnable {
        final /* synthetic */ int q;

        c(int i) {
            this.q = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            SystemForegroundService.this.h0.cancel(this.q);
        }
    }

    private void e() {
        this.X = new Handler(Looper.getMainLooper());
        this.h0 = (NotificationManager) getApplicationContext().getSystemService("notification");
        androidx.work.impl.foreground.a aVar = new androidx.work.impl.foreground.a(getApplicationContext());
        this.Z = aVar;
        aVar.m(this);
    }

    @Override // androidx.work.impl.foreground.a.b
    public void b(int i, int i2, Notification notification) {
        this.X.post(new a(i, notification, i2));
    }

    @Override // androidx.work.impl.foreground.a.b
    public void c(int i, Notification notification) {
        this.X.post(new b(i, notification));
    }

    @Override // androidx.work.impl.foreground.a.b
    public void d(int i) {
        this.X.post(new c(i));
    }

    @Override // ax.F0.i, android.app.Service
    public void onCreate() {
        super.onCreate();
        j0 = this;
        e();
    }

    @Override // ax.F0.i, android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.Z.k();
    }

    @Override // ax.F0.i, android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.Y) {
            j.c().d(i0, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
            this.Z.k();
            e();
            this.Y = false;
        }
        if (intent == null) {
            return 3;
        }
        this.Z.l(intent);
        return 3;
    }

    @Override // androidx.work.impl.foreground.a.b
    public void stop() {
        this.Y = true;
        j.c().a(i0, "All commands completed.", new Throwable[0]);
        if (Build.VERSION.SDK_INT >= 26) {
            stopForeground(true);
        }
        j0 = null;
        stopSelf();
    }
}
