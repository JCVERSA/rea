package androidx.work.impl.foreground;

import android.app.ForegroundServiceStartNotAllowedException;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import ax.F2.h;
import ax.G0.j;

/* JADX INFO: loaded from: classes.dex */
public class SystemForegroundService extends j implements androidx.work.impl.foreground.a.b {
    private static final String l0 = h.i("SystemFgService");
    private static SystemForegroundService m0 = null;
    private Handler X;
    private boolean Y;
    androidx.work.impl.foreground.a Z;
    NotificationManager k0;

    class a implements Runnable {
        final /* synthetic */ Notification X;
        final /* synthetic */ int Y;
        final /* synthetic */ int q;

        a(int i, Notification notification, int i2) {
            this.q = i;
            this.X = notification;
            this.Y = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            int i = Build.VERSION.SDK_INT;
            if (i >= 31) {
                e.a(SystemForegroundService.this, this.q, this.X, this.Y);
            } else if (i >= 29) {
                d.a(SystemForegroundService.this, this.q, this.X, this.Y);
            } else {
                SystemForegroundService.this.startForeground(this.q, this.X);
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ Notification X;
        final /* synthetic */ int q;

        b(int i, Notification notification) {
            this.q = i;
            this.X = notification;
        }

        @Override // java.lang.Runnable
        public void run() {
            SystemForegroundService.this.k0.notify(this.q, this.X);
        }
    }

    class c implements Runnable {
        final /* synthetic */ int q;

        c(int i) {
            this.q = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            SystemForegroundService.this.k0.cancel(this.q);
        }
    }

    static class d {
        static void a(Service service, int i, Notification notification, int i2) {
            service.startForeground(i, notification, i2);
        }
    }

    static class e {
        static void a(Service service, int i, Notification notification, int i2) {
            try {
                service.startForeground(i, notification, i2);
            } catch (ForegroundServiceStartNotAllowedException e) {
                h.e().l(SystemForegroundService.l0, "Unable to start foreground service", e);
            }
        }
    }

    private void f() {
        this.X = new Handler(Looper.getMainLooper());
        this.k0 = (NotificationManager) getApplicationContext().getSystemService("notification");
        androidx.work.impl.foreground.a aVar = new androidx.work.impl.foreground.a(getApplicationContext());
        this.Z = aVar;
        aVar.n(this);
    }

    @Override // androidx.work.impl.foreground.a.b
    public void b(int i, int i2, Notification notification) {
        this.X.post(new a(i, notification, i2));
    }

    @Override // androidx.work.impl.foreground.a.b
    public void c(int i, Notification notification) {
        this.X.post(new b(i, notification));
    }

    @Override // androidx.work.impl.foreground.a.b
    public void d(int i) {
        this.X.post(new c(i));
    }

    @Override // ax.G0.j, android.app.Service
    public void onCreate() {
        super.onCreate();
        m0 = this;
        f();
    }

    @Override // ax.G0.j, android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.Z.l();
    }

    @Override // ax.G0.j, android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (this.Y) {
            h.e().f(l0, "Re-initializing SystemForegroundService after a request to shut-down.");
            this.Z.l();
            f();
            this.Y = false;
        }
        if (intent == null) {
            return 3;
        }
        this.Z.m(intent);
        return 3;
    }

    @Override // androidx.work.impl.foreground.a.b
    public void stop() {
        this.Y = true;
        h.e().a(l0, "All commands completed.");
        if (Build.VERSION.SDK_INT >= 26) {
            stopForeground(true);
        }
        m0 = null;
        stopSelf();
    }
}
