package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import ax.p170m1.j;
import ax.p204o7.d;
import ax.p226q1.c;
import ax.p282u1.p;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintTrackingWorker extends ListenableWorker implements c {
    private static final String n0 = j.f("ConstraintTrkngWrkr");
    private WorkerParameters i0;
    final Object j0;
    volatile boolean k0;
    ax.p310w1.c<ListenableWorker.a> l0;
    private ListenableWorker m0;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ConstraintTrackingWorker.this.e();
        }
    }

    class b implements Runnable {
        final /* synthetic */ d q;

        b(d dVar) {
            this.q = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (ConstraintTrackingWorker.this.j0) {
                try {
                    if (ConstraintTrackingWorker.this.k0) {
                        ConstraintTrackingWorker.this.d();
                    } else {
                        ConstraintTrackingWorker.this.l0.r(this.q);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public ConstraintTrackingWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        this.i0 = workerParameters;
        this.j0 = new Object();
        this.k0 = false;
        this.l0 = ax.p310w1.c.t();
    }

    public WorkDatabase a() {
        return ax.p184n1.j.k(getApplicationContext()).o();
    }

    @Override // ax.p226q1.c
    public void b(List<String> list) {
        j.c().a(n0, String.format("Constraints changed for %s", list), new Throwable[0]);
        synchronized (this.j0) {
            this.k0 = true;
        }
    }

    void c() {
        this.l0.p(ListenableWorker.a.a());
    }

    void d() {
        this.l0.p(ListenableWorker.a.b());
    }

    void e() {
        String strI = getInputData().i("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
        if (TextUtils.isEmpty(strI)) {
            j.c().b(n0, "No worker to delegate to.", new Throwable[0]);
            c();
            return;
        }
        ListenableWorker listenableWorkerB = getWorkerFactory().b(getApplicationContext(), strI, this.i0);
        this.m0 = listenableWorkerB;
        if (listenableWorkerB == null) {
            j.c().a(n0, "No worker to delegate to.", new Throwable[0]);
            c();
            return;
        }
        p pVarM = a().B().m(getId().toString());
        if (pVarM == null) {
            c();
            return;
        }
        ax.p226q1.d dVar = new ax.p226q1.d(getApplicationContext(), getTaskExecutor(), this);
        dVar.d(Collections.singletonList(pVarM));
        if (!dVar.c(getId().toString())) {
            j.c().a(n0, String.format("Constraints not met for delegate %s. Requesting retry.", strI), new Throwable[0]);
            d();
            return;
        }
        j.c().a(n0, String.format("Constraints met for delegate %s", strI), new Throwable[0]);
        try {
            d<ListenableWorker.a> dVarStartWork = this.m0.startWork();
            dVarStartWork.g(new b(dVarStartWork), getBackgroundExecutor());
        } catch (Throwable th) {
            j jVarC = j.c();
            String str = n0;
            jVarC.a(str, String.format("Delegated worker %s threw exception in startWork.", strI), th);
            synchronized (this.j0) {
                try {
                    if (this.k0) {
                        j.c().a(str, "Constraints were unmet, Retrying.", new Throwable[0]);
                        d();
                    } else {
                        c();
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    @Override // ax.p226q1.c
    public void f(List<String> list) {
    }

    @Override // androidx.work.ListenableWorker
    public ax.p324x1.a getTaskExecutor() {
        return ax.p184n1.j.k(getApplicationContext()).p();
    }

    @Override // androidx.work.ListenableWorker
    public boolean isRunInForeground() {
        ListenableWorker listenableWorker = this.m0;
        return listenableWorker != null && listenableWorker.isRunInForeground();
    }

    @Override // androidx.work.ListenableWorker
    public void onStopped() {
        super.onStopped();
        ListenableWorker listenableWorker = this.m0;
        if (listenableWorker == null || listenableWorker.isStopped()) {
            return;
        }
        this.m0.stop();
    }

    @Override // androidx.work.ListenableWorker
    public d<ListenableWorker.a> startWork() {
        getBackgroundExecutor().execute(new a());
        return this.l0;
    }
}
