package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.WorkerParameters;
import androidx.work.c;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import ax.F2.h;
import ax.G2.D;
import ax.K2.e;
import ax.M2.o;
import ax.O2.u;
import ax.O2.v;
import ax.p111gc.t;
import ax.p127hc.C2093o;
import ax.p335uc.l;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ConstraintTrackingWorker extends c implements ax.K2.c {
    private final WorkerParameters k0;
    private final Object l0;
    private volatile boolean m0;
    private final ax.Q2.c<c.a> n0;
    private c o0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ConstraintTrackingWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        l.f(context, "appContext");
        l.f(workerParameters, "workerParameters");
        this.k0 = workerParameters;
        this.l0 = new Object();
        this.n0 = ax.Q2.c.u();
    }

    private final void d() {
        if (this.n0.isCancelled()) {
            return;
        }
        String strI = getInputData().i("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
        h hVarE = h.e();
        l.e(hVarE, "get()");
        if (strI == null || strI.length() == 0) {
            hVarE.c(ax.S2.c.a, "No worker to delegate to.");
            ax.Q2.c<c.a> cVar = this.n0;
            l.e(cVar, "future");
            ax.S2.c.d(cVar);
            return;
        }
        c cVarB = getWorkerFactory().b(getApplicationContext(), strI, this.k0);
        this.o0 = cVarB;
        if (cVarB == null) {
            hVarE.a(ax.S2.c.a, "No worker to delegate to.");
            ax.Q2.c<c.a> cVar2 = this.n0;
            l.e(cVar2, "future");
            ax.S2.c.d(cVar2);
            return;
        }
        D dK = D.k(getApplicationContext());
        l.e(dK, "getInstance(applicationContext)");
        v vVarI = dK.p().I();
        String string = getId().toString();
        l.e(string, "id.toString()");
        u uVarN = vVarI.n(string);
        if (uVarN == null) {
            ax.Q2.c<c.a> cVar3 = this.n0;
            l.e(cVar3, "future");
            ax.S2.c.d(cVar3);
            return;
        }
        o oVarO = dK.o();
        l.e(oVarO, "workManagerImpl.trackers");
        e eVar = new e(oVarO, this);
        eVar.b(C2093o.d(uVarN));
        String string2 = getId().toString();
        l.e(string2, "id.toString()");
        if (!eVar.e(string2)) {
            hVarE.a(ax.S2.c.a, "Constraints not met for delegate " + strI + ". Requesting retry.");
            ax.Q2.c<c.a> cVar4 = this.n0;
            l.e(cVar4, "future");
            ax.S2.c.e(cVar4);
            return;
        }
        hVarE.a(ax.S2.c.a, "Constraints met for delegate " + strI);
        try {
            c cVar5 = this.o0;
            l.c(cVar5);
            final ax.p043c8.e<c.a> eVarStartWork = cVar5.startWork();
            l.e(eVarStartWork, "delegate!!.startWork()");
            eVarStartWork.h(new Runnable() { // from class: ax.S2.b
                @Override // java.lang.Runnable
                public final void run() {
                    ConstraintTrackingWorker.f(this.q, eVarStartWork);
                }
            }, getBackgroundExecutor());
        } catch (Throwable th) {
            hVarE.b(ax.S2.c.a, "Delegated worker " + strI + " threw exception in startWork.", th);
            synchronized (this.l0) {
                try {
                    if (!this.m0) {
                        ax.Q2.c<c.a> cVar6 = this.n0;
                        l.e(cVar6, "future");
                        ax.S2.c.d(cVar6);
                    } else {
                        hVarE.a(ax.S2.c.a, "Constraints were unmet, Retrying.");
                        ax.Q2.c<c.a> cVar7 = this.n0;
                        l.e(cVar7, "future");
                        ax.S2.c.e(cVar7);
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void f(ConstraintTrackingWorker constraintTrackingWorker, ax.p043c8.e eVar) {
        l.f(constraintTrackingWorker, "this$0");
        l.f(eVar, "$innerFuture");
        synchronized (constraintTrackingWorker.l0) {
            try {
                if (constraintTrackingWorker.m0) {
                    ax.Q2.c<c.a> cVar = constraintTrackingWorker.n0;
                    l.e(cVar, "future");
                    ax.S2.c.e(cVar);
                } else {
                    constraintTrackingWorker.n0.s(eVar);
                }
                t tVar = t.a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void g(ConstraintTrackingWorker constraintTrackingWorker) {
        l.f(constraintTrackingWorker, "this$0");
        constraintTrackingWorker.d();
    }

    @Override // ax.K2.c
    public void b(List<u> list) {
        l.f(list, "workSpecs");
        h.e().a(ax.S2.c.a, "Constraints changed for " + list);
        synchronized (this.l0) {
            this.m0 = true;
            t tVar = t.a;
        }
    }

    @Override // ax.K2.c
    public void e(List<u> list) {
        l.f(list, "workSpecs");
    }

    @Override // androidx.work.c
    public void onStopped() {
        super.onStopped();
        c cVar = this.o0;
        if (cVar == null || cVar.isStopped()) {
            return;
        }
        cVar.stop();
    }

    @Override // androidx.work.c
    public ax.p043c8.e<c.a> startWork() {
        getBackgroundExecutor().execute(new Runnable() { // from class: ax.S2.a
            @Override // java.lang.Runnable
            public final void run() {
                ConstraintTrackingWorker.g(this.q);
            }
        });
        ax.Q2.c<c.a> cVar = this.n0;
        l.e(cVar, "future");
        return cVar;
    }
}
