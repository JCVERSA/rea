package androidx.work.impl.workers;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import ax.p170m1.j;
import ax.p282u1.g;
import ax.p282u1.h;
import ax.p282u1.k;
import ax.p282u1.p;
import ax.p282u1.q;
import ax.p282u1.t;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public class DiagnosticsWorker extends Worker {
    private static final String j0 = j.f("DiagnosticsWrkr");

    public DiagnosticsWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    private static String a(p pVar, String str, Integer num, String str2) {
        return String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", pVar.a, pVar.c, num, pVar.b.name(), str, str2);
    }

    private static String c(k kVar, t tVar, h hVar, List<p> list) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", Build.VERSION.SDK_INT >= 23 ? "Job Id" : "Alarm Id"));
        for (p pVar : list) {
            g gVarC = hVar.c(pVar.a);
            sb.append(a(pVar, TextUtils.join(",", kVar.b(pVar.a)), gVarC != null ? Integer.valueOf(gVarC.b) : null, TextUtils.join(",", tVar.b(pVar.a))));
        }
        return sb.toString();
    }

    @Override // androidx.work.Worker
    public ListenableWorker.a doWork() {
        WorkDatabase workDatabaseO = ax.p184n1.j.k(getApplicationContext()).o();
        q qVarB = workDatabaseO.B();
        k kVarZ = workDatabaseO.z();
        t tVarC = workDatabaseO.C();
        h hVarY = workDatabaseO.y();
        List<p> listC = qVarB.c(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L));
        List<p> listH = qVarB.h();
        List<p> listS = qVarB.s(200);
        if (listC != null && !listC.isEmpty()) {
            j jVarC = j.c();
            String str = j0;
            jVarC.d(str, "Recently completed work:\n\n", new Throwable[0]);
            j.c().d(str, c(kVarZ, tVarC, hVarY, listC), new Throwable[0]);
        }
        if (listH != null && !listH.isEmpty()) {
            j jVarC2 = j.c();
            String str2 = j0;
            jVarC2.d(str2, "Running work:\n\n", new Throwable[0]);
            j.c().d(str2, c(kVarZ, tVarC, hVarY, listH), new Throwable[0]);
        }
        if (listS != null && !listS.isEmpty()) {
            j jVarC3 = j.c();
            String str3 = j0;
            jVarC3.d(str3, "Enqueued work:\n\n", new Throwable[0]);
            j.c().d(str3, c(kVarZ, tVarC, hVarY, listS), new Throwable[0]);
        }
        return ListenableWorker.a.c();
    }
}
