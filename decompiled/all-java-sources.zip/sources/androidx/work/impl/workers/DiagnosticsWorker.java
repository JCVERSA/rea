package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.c;
import androidx.work.impl.WorkDatabase;
import ax.F2.h;
import ax.G2.D;
import ax.O2.j;
import ax.O2.o;
import ax.O2.u;
import ax.O2.v;
import ax.O2.z;
import ax.S2.d;
import ax.p335uc.l;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public final class DiagnosticsWorker extends Worker {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DiagnosticsWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        l.f(context, "context");
        l.f(workerParameters, "parameters");
    }

    @Override // androidx.work.Worker
    public c.a doWork() {
        D dK = D.k(getApplicationContext());
        l.e(dK, "getInstance(applicationContext)");
        WorkDatabase workDatabaseP = dK.p();
        l.e(workDatabaseP, "workManager.workDatabase");
        v vVarI = workDatabaseP.I();
        o oVarG = workDatabaseP.G();
        z zVarJ = workDatabaseP.J();
        j jVarF = workDatabaseP.F();
        List<u> listD = vVarI.d(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L));
        List<u> listI = vVarI.i();
        List<u> listT = vVarI.t(200);
        if (!listD.isEmpty()) {
            h.e().f(d.a, "Recently completed work:\n\n");
            h.e().f(d.a, d.d(oVarG, zVarJ, jVarF, listD));
        }
        if (!listI.isEmpty()) {
            h.e().f(d.a, "Running work:\n\n");
            h.e().f(d.a, d.d(oVarG, zVarJ, jVarF, listI));
        }
        if (!listT.isEmpty()) {
            h.e().f(d.a, "Enqueued work:\n\n");
            h.e().f(d.a, d.d(oVarG, zVarJ, jVarF, listT));
        }
        c.a aVarC = c.a.c();
        l.e(aVarC, "success()");
        return aVarC;
    }
}
