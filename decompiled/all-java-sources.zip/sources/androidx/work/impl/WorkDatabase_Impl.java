package androidx.work.impl;

import androidx.room.i;
import ax.p030c1.c;
import ax.p282u1.b;
import ax.p282u1.e;
import ax.p282u1.f;
import ax.p282u1.h;
import ax.p282u1.k;
import ax.p282u1.l;
import ax.p282u1.n;
import ax.p282u1.o;
import ax.p282u1.q;
import ax.p282u1.r;
import ax.p282u1.t;
import ax.p282u1.u;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

/* JADX INFO: loaded from: classes.dex */
public final class WorkDatabase_Impl extends WorkDatabase {
    private volatile q m;
    private volatile b n;
    private volatile t o;
    private volatile h p;
    private volatile k q;
    private volatile n r;
    private volatile e s;

    @Override // androidx.work.impl.WorkDatabase
    public n A() {
        n nVar;
        if (this.r != null) {
            return this.r;
        }
        synchronized (this) {
            try {
                if (this.r == null) {
                    this.r = new o(this);
                }
                nVar = this.r;
            } catch (Throwable th) {
                throw th;
            }
        }
        return nVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public q B() {
        q qVar;
        if (this.m != null) {
            return this.m;
        }
        synchronized (this) {
            try {
                if (this.m == null) {
                    this.m = new r(this);
                }
                qVar = this.m;
            } catch (Throwable th) {
                throw th;
            }
        }
        return qVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public t C() {
        t tVar;
        if (this.o != null) {
            return this.o;
        }
        synchronized (this) {
            try {
                if (this.o == null) {
                    this.o = new u(this);
                }
                tVar = this.o;
            } catch (Throwable th) {
                throw th;
            }
        }
        return tVar;
    }

    @Override // androidx.room.h
    protected androidx.room.e e() {
        return new androidx.room.e(this, new HashMap(0), new HashMap(0), "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference");
    }

    @Override // androidx.room.h
    protected c f(androidx.room.a aVar) {
        return aVar.a.a(c.b.a(aVar.b).c(aVar.c).b(new i(aVar, new a(12), "c103703e120ae8cc73c9248622f3cd1e", "49f946663a8deb7054212b8adda248c6")).a());
    }

    @Override // androidx.work.impl.WorkDatabase
    public b t() {
        b bVar;
        if (this.n != null) {
            return this.n;
        }
        synchronized (this) {
            try {
                if (this.n == null) {
                    this.n = new ax.p282u1.c(this);
                }
                bVar = this.n;
            } catch (Throwable th) {
                throw th;
            }
        }
        return bVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public e x() {
        e eVar;
        if (this.s != null) {
            return this.s;
        }
        synchronized (this) {
            try {
                if (this.s == null) {
                    this.s = new f(this);
                }
                eVar = this.s;
            } catch (Throwable th) {
                throw th;
            }
        }
        return eVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public h y() {
        h hVar;
        if (this.p != null) {
            return this.p;
        }
        synchronized (this) {
            try {
                if (this.p == null) {
                    this.p = new ax.p282u1.i(this);
                }
                hVar = this.p;
            } catch (Throwable th) {
                throw th;
            }
        }
        return hVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public k z() {
        k kVar;
        if (this.q != null) {
            return this.q;
        }
        synchronized (this) {
            try {
                if (this.q == null) {
                    this.q = new l(this);
                }
                kVar = this.q;
            } catch (Throwable th) {
                throw th;
            }
        }
        return kVar;
    }

    class a extends i.a {
        a(int i) {
            super(i);
        }

        @Override // androidx.room.i.a
        public void a(ax.p030c1.b bVar) {
            bVar.I("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
            bVar.I("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
            bVar.I("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
            bVar.I("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
            bVar.I("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            bVar.I("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            bVar.I("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            bVar.I("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
        }

        @Override // androidx.room.i.a
        public void b(ax.p030c1.b bVar) {
            bVar.I("DROP TABLE IF EXISTS `Dependency`");
            bVar.I("DROP TABLE IF EXISTS `WorkSpec`");
            bVar.I("DROP TABLE IF EXISTS `WorkTag`");
            bVar.I("DROP TABLE IF EXISTS `SystemIdInfo`");
            bVar.I("DROP TABLE IF EXISTS `WorkName`");
            bVar.I("DROP TABLE IF EXISTS `WorkProgress`");
            bVar.I("DROP TABLE IF EXISTS `Preference`");
            if (((androidx.room.h) WorkDatabase_Impl.this).h != null) {
                int size = ((androidx.room.h) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((androidx.room.h.b) ((androidx.room.h) WorkDatabase_Impl.this).h.get(i)).b(bVar);
                }
            }
        }

        @Override // androidx.room.i.a
        protected void c(ax.p030c1.b bVar) {
            if (((androidx.room.h) WorkDatabase_Impl.this).h != null) {
                int size = ((androidx.room.h) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((androidx.room.h.b) ((androidx.room.h) WorkDatabase_Impl.this).h.get(i)).a(bVar);
                }
            }
        }

        @Override // androidx.room.i.a
        public void d(ax.p030c1.b bVar) {
            ((androidx.room.h) WorkDatabase_Impl.this).a = bVar;
            bVar.I("PRAGMA foreign_keys = ON");
            WorkDatabase_Impl.this.m(bVar);
            if (((androidx.room.h) WorkDatabase_Impl.this).h != null) {
                int size = ((androidx.room.h) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((androidx.room.h.b) ((androidx.room.h) WorkDatabase_Impl.this).h.get(i)).c(bVar);
                }
            }
        }

        @Override // androidx.room.i.a
        public void f(ax.p030c1.b bVar) {
            ax.p002a1.c.a(bVar);
        }

        @Override // androidx.room.i.a
        protected i.b g(ax.p030c1.b bVar) {
            HashMap map = new HashMap(2);
            map.put("work_spec_id", new ax.a1.f.a("work_spec_id", "TEXT", true, 1, null, 1));
            map.put("prerequisite_id", new ax.a1.f.a("prerequisite_id", "TEXT", true, 2, null, 1));
            HashSet hashSet = new HashSet(2);
            hashSet.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            hashSet.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("prerequisite_id"), Arrays.asList("id")));
            HashSet hashSet2 = new HashSet(2);
            hashSet2.add(new ax.a1.f.d("index_Dependency_work_spec_id", false, Arrays.asList("work_spec_id")));
            hashSet2.add(new ax.a1.f.d("index_Dependency_prerequisite_id", false, Arrays.asList("prerequisite_id")));
            ax.p002a1.f fVar = new ax.p002a1.f("Dependency", map, hashSet, hashSet2);
            ax.p002a1.f fVarA = ax.p002a1.f.a(bVar, "Dependency");
            if (!fVar.equals(fVarA)) {
                return new i.b(false, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n" + fVar + "\n Found:\n" + fVarA);
            }
            HashMap map2 = new HashMap(25);
            map2.put("id", new ax.a1.f.a("id", "TEXT", true, 1, null, 1));
            map2.put("state", new ax.a1.f.a("state", "INTEGER", true, 0, null, 1));
            map2.put("worker_class_name", new ax.a1.f.a("worker_class_name", "TEXT", true, 0, null, 1));
            map2.put("input_merger_class_name", new ax.a1.f.a("input_merger_class_name", "TEXT", false, 0, null, 1));
            map2.put("input", new ax.a1.f.a("input", "BLOB", true, 0, null, 1));
            map2.put("output", new ax.a1.f.a("output", "BLOB", true, 0, null, 1));
            map2.put("initial_delay", new ax.a1.f.a("initial_delay", "INTEGER", true, 0, null, 1));
            map2.put("interval_duration", new ax.a1.f.a("interval_duration", "INTEGER", true, 0, null, 1));
            map2.put("flex_duration", new ax.a1.f.a("flex_duration", "INTEGER", true, 0, null, 1));
            map2.put("run_attempt_count", new ax.a1.f.a("run_attempt_count", "INTEGER", true, 0, null, 1));
            map2.put("backoff_policy", new ax.a1.f.a("backoff_policy", "INTEGER", true, 0, null, 1));
            map2.put("backoff_delay_duration", new ax.a1.f.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
            map2.put("period_start_time", new ax.a1.f.a("period_start_time", "INTEGER", true, 0, null, 1));
            map2.put("minimum_retention_duration", new ax.a1.f.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
            map2.put("schedule_requested_at", new ax.a1.f.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
            map2.put("run_in_foreground", new ax.a1.f.a("run_in_foreground", "INTEGER", true, 0, null, 1));
            map2.put("out_of_quota_policy", new ax.a1.f.a("out_of_quota_policy", "INTEGER", true, 0, null, 1));
            map2.put("required_network_type", new ax.a1.f.a("required_network_type", "INTEGER", false, 0, null, 1));
            map2.put("requires_charging", new ax.a1.f.a("requires_charging", "INTEGER", true, 0, null, 1));
            map2.put("requires_device_idle", new ax.a1.f.a("requires_device_idle", "INTEGER", true, 0, null, 1));
            map2.put("requires_battery_not_low", new ax.a1.f.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
            map2.put("requires_storage_not_low", new ax.a1.f.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
            map2.put("trigger_content_update_delay", new ax.a1.f.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
            map2.put("trigger_max_content_delay", new ax.a1.f.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
            map2.put("content_uri_triggers", new ax.a1.f.a("content_uri_triggers", "BLOB", false, 0, null, 1));
            HashSet hashSet3 = new HashSet(0);
            HashSet hashSet4 = new HashSet(2);
            hashSet4.add(new ax.a1.f.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList("schedule_requested_at")));
            hashSet4.add(new ax.a1.f.d("index_WorkSpec_period_start_time", false, Arrays.asList("period_start_time")));
            ax.p002a1.f fVar2 = new ax.p002a1.f("WorkSpec", map2, hashSet3, hashSet4);
            ax.p002a1.f fVarA2 = ax.p002a1.f.a(bVar, "WorkSpec");
            if (!fVar2.equals(fVarA2)) {
                return new i.b(false, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n" + fVar2 + "\n Found:\n" + fVarA2);
            }
            HashMap map3 = new HashMap(2);
            map3.put("tag", new ax.a1.f.a("tag", "TEXT", true, 1, null, 1));
            map3.put("work_spec_id", new ax.a1.f.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet5 = new HashSet(1);
            hashSet5.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet6 = new HashSet(1);
            hashSet6.add(new ax.a1.f.d("index_WorkTag_work_spec_id", false, Arrays.asList("work_spec_id")));
            ax.p002a1.f fVar3 = new ax.p002a1.f("WorkTag", map3, hashSet5, hashSet6);
            ax.p002a1.f fVarA3 = ax.p002a1.f.a(bVar, "WorkTag");
            if (!fVar3.equals(fVarA3)) {
                return new i.b(false, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n" + fVar3 + "\n Found:\n" + fVarA3);
            }
            HashMap map4 = new HashMap(2);
            map4.put("work_spec_id", new ax.a1.f.a("work_spec_id", "TEXT", true, 1, null, 1));
            map4.put("system_id", new ax.a1.f.a("system_id", "INTEGER", true, 0, null, 1));
            HashSet hashSet7 = new HashSet(1);
            hashSet7.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            ax.p002a1.f fVar4 = new ax.p002a1.f("SystemIdInfo", map4, hashSet7, new HashSet(0));
            ax.p002a1.f fVarA4 = ax.p002a1.f.a(bVar, "SystemIdInfo");
            if (!fVar4.equals(fVarA4)) {
                return new i.b(false, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n" + fVar4 + "\n Found:\n" + fVarA4);
            }
            HashMap map5 = new HashMap(2);
            map5.put("name", new ax.a1.f.a("name", "TEXT", true, 1, null, 1));
            map5.put("work_spec_id", new ax.a1.f.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet8 = new HashSet(1);
            hashSet8.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet9 = new HashSet(1);
            hashSet9.add(new ax.a1.f.d("index_WorkName_work_spec_id", false, Arrays.asList("work_spec_id")));
            ax.p002a1.f fVar5 = new ax.p002a1.f("WorkName", map5, hashSet8, hashSet9);
            ax.p002a1.f fVarA5 = ax.p002a1.f.a(bVar, "WorkName");
            if (!fVar5.equals(fVarA5)) {
                return new i.b(false, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n" + fVar5 + "\n Found:\n" + fVarA5);
            }
            HashMap map6 = new HashMap(2);
            map6.put("work_spec_id", new ax.a1.f.a("work_spec_id", "TEXT", true, 1, null, 1));
            map6.put("progress", new ax.a1.f.a("progress", "BLOB", true, 0, null, 1));
            HashSet hashSet10 = new HashSet(1);
            hashSet10.add(new ax.a1.f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            ax.p002a1.f fVar6 = new ax.p002a1.f("WorkProgress", map6, hashSet10, new HashSet(0));
            ax.p002a1.f fVarA6 = ax.p002a1.f.a(bVar, "WorkProgress");
            if (!fVar6.equals(fVarA6)) {
                return new i.b(false, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n" + fVar6 + "\n Found:\n" + fVarA6);
            }
            HashMap map7 = new HashMap(2);
            map7.put("key", new ax.a1.f.a("key", "TEXT", true, 1, null, 1));
            map7.put("long_value", new ax.a1.f.a("long_value", "INTEGER", false, 0, null, 1));
            ax.p002a1.f fVar7 = new ax.p002a1.f("Preference", map7, new HashSet(0), new HashSet(0));
            ax.p002a1.f fVarA7 = ax.p002a1.f.a(bVar, "Preference");
            if (fVar7.equals(fVarA7)) {
                return new i.b(true, null);
            }
            return new i.b(false, "Preference(androidx.work.impl.model.Preference).\n Expected:\n" + fVar7 + "\n Found:\n" + fVarA7);
        }

        @Override // androidx.room.i.a
        public void e(ax.p030c1.b bVar) {
        }
    }
}
