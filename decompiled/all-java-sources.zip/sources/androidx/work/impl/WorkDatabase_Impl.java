package androidx.work.impl;

import ax.O2.A;
import ax.O2.InterfaceC1354b;
import ax.O2.c;
import ax.O2.e;
import ax.O2.f;
import ax.O2.j;
import ax.O2.k;
import ax.O2.o;
import ax.O2.p;
import ax.O2.r;
import ax.O2.s;
import ax.O2.v;
import ax.O2.z;
import ax.p197m2.u;
import ax.p197m2.w;
import ax.p229o2.d;
import ax.p261q2.g;
import ax.p261q2.h;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class WorkDatabase_Impl extends WorkDatabase {
    private volatile v q;
    private volatile InterfaceC1354b r;
    private volatile z s;
    private volatile j t;
    private volatile o u;
    private volatile r v;
    private volatile e w;

    class a extends w.b {
        a(int i) {
            super(i);
        }

        @Override // ax.m2.w.b
        public void a(g gVar) {
            gVar.D("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
            gVar.D("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `last_enqueue_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `period_count` INTEGER NOT NULL DEFAULT 0, `generation` INTEGER NOT NULL DEFAULT 0, `required_network_type` INTEGER NOT NULL, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB NOT NULL, PRIMARY KEY(`id`))");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_WorkSpec_last_enqueue_time` ON `WorkSpec` (`last_enqueue_time`)");
            gVar.D("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
            gVar.D("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `generation` INTEGER NOT NULL DEFAULT 0, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`, `generation`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            gVar.D("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            gVar.D("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
            gVar.D("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            gVar.D("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            gVar.D("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            gVar.D("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '5181942b9ebc31ce68dacb56c16fd79f')");
        }

        @Override // ax.m2.w.b
        public void b(g gVar) {
            gVar.D("DROP TABLE IF EXISTS `Dependency`");
            gVar.D("DROP TABLE IF EXISTS `WorkSpec`");
            gVar.D("DROP TABLE IF EXISTS `WorkTag`");
            gVar.D("DROP TABLE IF EXISTS `SystemIdInfo`");
            gVar.D("DROP TABLE IF EXISTS `WorkName`");
            gVar.D("DROP TABLE IF EXISTS `WorkProgress`");
            gVar.D("DROP TABLE IF EXISTS `Preference`");
            if (((u) WorkDatabase_Impl.this).h != null) {
                int size = ((u) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((u.b) ((u) WorkDatabase_Impl.this).h.get(i)).b(gVar);
                }
            }
        }

        @Override // ax.m2.w.b
        public void c(g gVar) {
            if (((u) WorkDatabase_Impl.this).h != null) {
                int size = ((u) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((u.b) ((u) WorkDatabase_Impl.this).h.get(i)).a(gVar);
                }
            }
        }

        @Override // ax.m2.w.b
        public void d(g gVar) {
            ((u) WorkDatabase_Impl.this).a = gVar;
            gVar.D("PRAGMA foreign_keys = ON");
            WorkDatabase_Impl.this.u(gVar);
            if (((u) WorkDatabase_Impl.this).h != null) {
                int size = ((u) WorkDatabase_Impl.this).h.size();
                for (int i = 0; i < size; i++) {
                    ((u.b) ((u) WorkDatabase_Impl.this).h.get(i)).c(gVar);
                }
            }
        }

        @Override // ax.m2.w.b
        public void e(g gVar) {
        }

        @Override // ax.m2.w.b
        public void f(g gVar) throws IOException {
            ax.p229o2.b.a(gVar);
        }

        @Override // ax.m2.w.b
        public w.c g(g gVar) {
            HashMap map = new HashMap(2);
            map.put("work_spec_id", new d.a("work_spec_id", "TEXT", true, 1, null, 1));
            map.put("prerequisite_id", new d.a("prerequisite_id", "TEXT", true, 2, null, 1));
            HashSet hashSet = new HashSet(2);
            hashSet.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            hashSet.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("prerequisite_id"), Arrays.asList("id")));
            HashSet hashSet2 = new HashSet(2);
            hashSet2.add(new d.e("index_Dependency_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
            hashSet2.add(new d.e("index_Dependency_prerequisite_id", false, Arrays.asList("prerequisite_id"), Arrays.asList("ASC")));
            d dVar = new d("Dependency", map, hashSet, hashSet2);
            d dVarA = d.a(gVar, "Dependency");
            if (!dVar.equals(dVarA)) {
                return new w.c(false, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n" + dVar + "\n Found:\n" + dVarA);
            }
            HashMap map2 = new HashMap(27);
            map2.put("id", new d.a("id", "TEXT", true, 1, null, 1));
            map2.put("state", new d.a("state", "INTEGER", true, 0, null, 1));
            map2.put("worker_class_name", new d.a("worker_class_name", "TEXT", true, 0, null, 1));
            map2.put("input_merger_class_name", new d.a("input_merger_class_name", "TEXT", false, 0, null, 1));
            map2.put("input", new d.a("input", "BLOB", true, 0, null, 1));
            map2.put("output", new d.a("output", "BLOB", true, 0, null, 1));
            map2.put("initial_delay", new d.a("initial_delay", "INTEGER", true, 0, null, 1));
            map2.put("interval_duration", new d.a("interval_duration", "INTEGER", true, 0, null, 1));
            map2.put("flex_duration", new d.a("flex_duration", "INTEGER", true, 0, null, 1));
            map2.put("run_attempt_count", new d.a("run_attempt_count", "INTEGER", true, 0, null, 1));
            map2.put("backoff_policy", new d.a("backoff_policy", "INTEGER", true, 0, null, 1));
            map2.put("backoff_delay_duration", new d.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
            map2.put("last_enqueue_time", new d.a("last_enqueue_time", "INTEGER", true, 0, null, 1));
            map2.put("minimum_retention_duration", new d.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
            map2.put("schedule_requested_at", new d.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
            map2.put("run_in_foreground", new d.a("run_in_foreground", "INTEGER", true, 0, null, 1));
            map2.put("out_of_quota_policy", new d.a("out_of_quota_policy", "INTEGER", true, 0, null, 1));
            map2.put("period_count", new d.a("period_count", "INTEGER", true, 0, "0", 1));
            map2.put("generation", new d.a("generation", "INTEGER", true, 0, "0", 1));
            map2.put("required_network_type", new d.a("required_network_type", "INTEGER", true, 0, null, 1));
            map2.put("requires_charging", new d.a("requires_charging", "INTEGER", true, 0, null, 1));
            map2.put("requires_device_idle", new d.a("requires_device_idle", "INTEGER", true, 0, null, 1));
            map2.put("requires_battery_not_low", new d.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
            map2.put("requires_storage_not_low", new d.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
            map2.put("trigger_content_update_delay", new d.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
            map2.put("trigger_max_content_delay", new d.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
            map2.put("content_uri_triggers", new d.a("content_uri_triggers", "BLOB", true, 0, null, 1));
            HashSet hashSet3 = new HashSet(0);
            HashSet hashSet4 = new HashSet(2);
            hashSet4.add(new d.e("index_WorkSpec_schedule_requested_at", false, Arrays.asList("schedule_requested_at"), Arrays.asList("ASC")));
            hashSet4.add(new d.e("index_WorkSpec_last_enqueue_time", false, Arrays.asList("last_enqueue_time"), Arrays.asList("ASC")));
            d dVar2 = new d("WorkSpec", map2, hashSet3, hashSet4);
            d dVarA2 = d.a(gVar, "WorkSpec");
            if (!dVar2.equals(dVarA2)) {
                return new w.c(false, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n" + dVar2 + "\n Found:\n" + dVarA2);
            }
            HashMap map3 = new HashMap(2);
            map3.put("tag", new d.a("tag", "TEXT", true, 1, null, 1));
            map3.put("work_spec_id", new d.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet5 = new HashSet(1);
            hashSet5.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet6 = new HashSet(1);
            hashSet6.add(new d.e("index_WorkTag_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
            d dVar3 = new d("WorkTag", map3, hashSet5, hashSet6);
            d dVarA3 = d.a(gVar, "WorkTag");
            if (!dVar3.equals(dVarA3)) {
                return new w.c(false, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n" + dVar3 + "\n Found:\n" + dVarA3);
            }
            HashMap map4 = new HashMap(3);
            map4.put("work_spec_id", new d.a("work_spec_id", "TEXT", true, 1, null, 1));
            map4.put("generation", new d.a("generation", "INTEGER", true, 2, "0", 1));
            map4.put("system_id", new d.a("system_id", "INTEGER", true, 0, null, 1));
            HashSet hashSet7 = new HashSet(1);
            hashSet7.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            d dVar4 = new d("SystemIdInfo", map4, hashSet7, new HashSet(0));
            d dVarA4 = d.a(gVar, "SystemIdInfo");
            if (!dVar4.equals(dVarA4)) {
                return new w.c(false, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n" + dVar4 + "\n Found:\n" + dVarA4);
            }
            HashMap map5 = new HashMap(2);
            map5.put("name", new d.a("name", "TEXT", true, 1, null, 1));
            map5.put("work_spec_id", new d.a("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet hashSet8 = new HashSet(1);
            hashSet8.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            HashSet hashSet9 = new HashSet(1);
            hashSet9.add(new d.e("index_WorkName_work_spec_id", false, Arrays.asList("work_spec_id"), Arrays.asList("ASC")));
            d dVar5 = new d("WorkName", map5, hashSet8, hashSet9);
            d dVarA5 = d.a(gVar, "WorkName");
            if (!dVar5.equals(dVarA5)) {
                return new w.c(false, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n" + dVar5 + "\n Found:\n" + dVarA5);
            }
            HashMap map6 = new HashMap(2);
            map6.put("work_spec_id", new d.a("work_spec_id", "TEXT", true, 1, null, 1));
            map6.put("progress", new d.a("progress", "BLOB", true, 0, null, 1));
            HashSet hashSet10 = new HashSet(1);
            hashSet10.add(new d.c("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            d dVar6 = new d("WorkProgress", map6, hashSet10, new HashSet(0));
            d dVarA6 = d.a(gVar, "WorkProgress");
            if (!dVar6.equals(dVarA6)) {
                return new w.c(false, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n" + dVar6 + "\n Found:\n" + dVarA6);
            }
            HashMap map7 = new HashMap(2);
            map7.put("key", new d.a("key", "TEXT", true, 1, null, 1));
            map7.put("long_value", new d.a("long_value", "INTEGER", false, 0, null, 1));
            d dVar7 = new d("Preference", map7, new HashSet(0), new HashSet(0));
            d dVarA7 = d.a(gVar, "Preference");
            if (dVar7.equals(dVarA7)) {
                return new w.c(true, null);
            }
            return new w.c(false, "Preference(androidx.work.impl.model.Preference).\n Expected:\n" + dVar7 + "\n Found:\n" + dVarA7);
        }
    }

    @Override // androidx.work.impl.WorkDatabase
    public InterfaceC1354b D() {
        InterfaceC1354b interfaceC1354b;
        if (this.r != null) {
            return this.r;
        }
        synchronized (this) {
            try {
                if (this.r == null) {
                    this.r = new c(this);
                }
                interfaceC1354b = this.r;
            } catch (Throwable th) {
                throw th;
            }
        }
        return interfaceC1354b;
    }

    @Override // androidx.work.impl.WorkDatabase
    public e E() {
        e eVar;
        if (this.w != null) {
            return this.w;
        }
        synchronized (this) {
            try {
                if (this.w == null) {
                    this.w = new f(this);
                }
                eVar = this.w;
            } catch (Throwable th) {
                throw th;
            }
        }
        return eVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public j F() {
        j jVar;
        if (this.t != null) {
            return this.t;
        }
        synchronized (this) {
            try {
                if (this.t == null) {
                    this.t = new k(this);
                }
                jVar = this.t;
            } catch (Throwable th) {
                throw th;
            }
        }
        return jVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public o G() {
        o oVar;
        if (this.u != null) {
            return this.u;
        }
        synchronized (this) {
            try {
                if (this.u == null) {
                    this.u = new p(this);
                }
                oVar = this.u;
            } catch (Throwable th) {
                throw th;
            }
        }
        return oVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public r H() {
        r rVar;
        if (this.v != null) {
            return this.v;
        }
        synchronized (this) {
            try {
                if (this.v == null) {
                    this.v = new s(this);
                }
                rVar = this.v;
            } catch (Throwable th) {
                throw th;
            }
        }
        return rVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public v I() {
        v vVar;
        if (this.q != null) {
            return this.q;
        }
        synchronized (this) {
            try {
                if (this.q == null) {
                    this.q = new ax.O2.w(this);
                }
                vVar = this.q;
            } catch (Throwable th) {
                throw th;
            }
        }
        return vVar;
    }

    @Override // androidx.work.impl.WorkDatabase
    public z J() {
        z zVar;
        if (this.s != null) {
            return this.s;
        }
        synchronized (this) {
            try {
                if (this.s == null) {
                    this.s = new A(this);
                }
                zVar = this.s;
            } catch (Throwable th) {
                throw th;
            }
        }
        return zVar;
    }

    @Override // ax.p197m2.u
    protected ax.p197m2.o g() {
        return new ax.p197m2.o(this, new HashMap(0), new HashMap(0), "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference");
    }

    @Override // ax.p197m2.u
    protected h h(ax.p197m2.f fVar) {
        return fVar.c.a(h.b.a(fVar.a).d(fVar.b).c(new w(fVar, new a(16), "5181942b9ebc31ce68dacb56c16fd79f", "ae2044fb577e65ee8bb576ca48a2f06e")).b());
    }

    @Override // ax.p197m2.u
    public List<ax.p213n2.b> j(Map<Class<? extends ax.p213n2.a>, ax.p213n2.a> map) {
        return Arrays.asList(new androidx.work.impl.a(), new b());
    }

    @Override // ax.p197m2.u
    public Set<Class<? extends ax.p213n2.a>> o() {
        return new HashSet();
    }

    @Override // ax.p197m2.u
    protected Map<Class<?>, List<Class<?>>> p() {
        HashMap map = new HashMap();
        map.put(v.class, ax.O2.w.v());
        map.put(InterfaceC1354b.class, c.e());
        map.put(z.class, A.d());
        map.put(j.class, k.h());
        map.put(o.class, p.c());
        map.put(r.class, s.a());
        map.put(e.class, f.c());
        map.put(ax.O2.g.class, ax.O2.h.a());
        return map;
    }
}
