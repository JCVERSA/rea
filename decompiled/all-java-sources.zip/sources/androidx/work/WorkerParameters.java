package androidx.work;

import android.net.Network;
import android.net.Uri;
import ax.F2.e;
import ax.F2.m;
import ax.F2.t;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class WorkerParameters {
    private UUID a;
    private b b;
    private Set<String> c;
    private a d;
    private int e;
    private Executor f;
    private ax.R2.c g;
    private t h;
    private m i;
    private e j;
    private int k;

    public static class a {
        public List<String> a;
        public List<Uri> b;
        public Network c;

        public a() {
            List list = Collections.EMPTY_LIST;
            this.a = list;
            this.b = list;
        }
    }

    public WorkerParameters(UUID uuid, b bVar, Collection<String> collection, a aVar, int i, int i2, Executor executor, ax.R2.c cVar, t tVar, m mVar, e eVar) {
        this.a = uuid;
        this.b = bVar;
        this.c = new HashSet(collection);
        this.d = aVar;
        this.e = i;
        this.k = i2;
        this.f = executor;
        this.g = cVar;
        this.h = tVar;
        this.i = mVar;
        this.j = eVar;
    }

    public Executor a() {
        return this.f;
    }

    public e b() {
        return this.j;
    }

    public UUID c() {
        return this.a;
    }

    public b d() {
        return this.b;
    }

    public Network e() {
        return this.d.c;
    }

    public m f() {
        return this.i;
    }

    public int g() {
        return this.e;
    }

    public Set<String> h() {
        return this.c;
    }

    public ax.R2.c i() {
        return this.g;
    }

    public List<String> j() {
        return this.d.a;
    }

    public List<Uri> k() {
        return this.d.b;
    }

    public t l() {
        return this.h;
    }
}
