package androidx.work;

import android.net.Network;
import android.net.Uri;
import ax.p170m1.f;
import ax.p170m1.o;
import ax.p170m1.v;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class WorkerParameters {
    private UUID a;
    private b b;
    private Set<String> c;
    private a d;
    private int e;
    private Executor f;
    private ax.p324x1.a g;
    private v h;
    private o i;
    private f j;

    public static class a {
        public List<String> a = Collections.emptyList();
        public List<Uri> b = Collections.emptyList();
        public Network c;
    }

    public WorkerParameters(UUID uuid, b bVar, Collection<String> collection, a aVar, int i, Executor executor, ax.p324x1.a aVar2, v vVar, o oVar, f fVar) {
        this.a = uuid;
        this.b = bVar;
        this.c = new HashSet(collection);
        this.d = aVar;
        this.e = i;
        this.f = executor;
        this.g = aVar2;
        this.h = vVar;
        this.i = oVar;
        this.j = fVar;
    }

    public Executor a() {
        return this.f;
    }

    public f b() {
        return this.j;
    }

    public UUID c() {
        return this.a;
    }

    public b d() {
        return this.b;
    }

    public Network e() {
        return this.d.c;
    }

    public o f() {
        return this.i;
    }

    public int g() {
        return this.e;
    }

    public Set<String> h() {
        return this.c;
    }

    public ax.p324x1.a i() {
        return this.g;
    }

    public List<String> j() {
        return this.d.a;
    }

    public List<Uri> k() {
        return this.d.b;
    }

    public v l() {
        return this.h;
    }
}
