package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.f;
import ax.p016b1.d;
import ax.p138jb.g;
import ax.p138jb.l;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class Recreator implements f {
    public static final a X = new a(null);
    private final d q;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public static final class b implements androidx.savedstate.a.c {
        private final Set<String> a;

        public b(androidx.savedstate.a aVar) {
            l.f(aVar, "registry");
            this.a = new LinkedHashSet();
            aVar.h("androidx.savedstate.Restarter", this);
        }

        @Override // androidx.savedstate.a.c
        public Bundle a() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList<>(this.a));
            return bundle;
        }

        public final void b(String str) {
            l.f(str, "className");
            this.a.add(str);
        }
    }

    public Recreator(d dVar) {
        l.f(dVar, "owner");
        this.q = dVar;
    }

    private final void g(String str) {
        try {
            Class<? extends U> clsAsSubclass = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(androidx.savedstate.a.InterfaceC0044a.class);
            l.e(clsAsSubclass, "{\n                Class.…class.java)\n            }");
            try {
                Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(null);
                declaredConstructor.setAccessible(true);
                try {
                    Object objNewInstance = declaredConstructor.newInstance(null);
                    l.e(objNewInstance, "{\n                constr…wInstance()\n            }");
                    ((androidx.savedstate.a.InterfaceC0044a) objNewInstance).a(this.q);
                } catch (Exception e) {
                    throw new RuntimeException("Failed to instantiate " + str, e);
                }
            } catch (NoSuchMethodException e2) {
                throw new IllegalStateException("Class " + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e2);
            }
        } catch (ClassNotFoundException e3) {
            throw new RuntimeException("Class " + str + " wasn't found", e3);
        }
    }

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
        l.f(gVar, "source");
        l.f(aVar, "event");
        if (aVar != androidx.lifecycle.d.a.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        gVar.f().c(this);
        Bundle bundleB = this.q.R().b("androidx.savedstate.Restarter");
        if (bundleB == null) {
            return;
        }
        ArrayList<String> stringArrayList = bundleB.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        Iterator<String> it = stringArrayList.iterator();
        while (it.hasNext()) {
            g(it.next());
        }
    }
}
