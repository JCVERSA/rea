package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.f;
import androidx.savedstate.a;
import ax.p016b1.d;
import ax.p138jb.g;
import ax.p138jb.l;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"RestrictedApi"})
public final class a {
    private static final b g = new b(null);
    private boolean b;
    private Bundle c;
    private boolean d;
    private Recreator.b e;
    private final ax.p308w.b<String, c> a = new ax.p308w.b<>();
    private boolean f = true;

    /* JADX INFO: renamed from: androidx.savedstate.a$a, reason: collision with other inner class name */
    public interface InterfaceC0044a {
        void a(d dVar);
    }

    private static final class b {
        private b() {
        }

        public /* synthetic */ b(g gVar) {
            this();
        }
    }

    public interface c {
        Bundle a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(a aVar, ax.F0.g gVar, androidx.lifecycle.d.a aVar2) {
        l.f(aVar, "this$0");
        l.f(gVar, "<anonymous parameter 0>");
        l.f(aVar2, "event");
        if (aVar2 == androidx.lifecycle.d.a.ON_START) {
            aVar.f = true;
        } else if (aVar2 == androidx.lifecycle.d.a.ON_STOP) {
            aVar.f = false;
        }
    }

    public final Bundle b(String str) {
        l.f(str, "key");
        if (!this.d) {
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component".toString());
        }
        Bundle bundle = this.c;
        if (bundle == null) {
            return null;
        }
        Bundle bundle2 = bundle != null ? bundle.getBundle(str) : null;
        Bundle bundle3 = this.c;
        if (bundle3 != null) {
            bundle3.remove(str);
        }
        Bundle bundle4 = this.c;
        if (bundle4 == null || bundle4.isEmpty()) {
            this.c = null;
        }
        return bundle2;
    }

    public final c c(String str) {
        l.f(str, "key");
        for (Map.Entry<String, c> entry : this.a) {
            l.e(entry, "components");
            String key = entry.getKey();
            c value = entry.getValue();
            if (l.a(key, str)) {
                return value;
            }
        }
        return null;
    }

    public final void e(androidx.lifecycle.d dVar) {
        l.f(dVar, "lifecycle");
        if (!(!this.b)) {
            throw new IllegalStateException("SavedStateRegistry was already attached.".toString());
        }
        dVar.a(new f() { // from class: ax.b1.b
            @Override // androidx.lifecycle.f
            public final void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                a.d(this.q, gVar, aVar);
            }
        });
        this.b = true;
    }

    public final void f(Bundle bundle) {
        if (!this.b) {
            throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).".toString());
        }
        if (!(!this.d)) {
            throw new IllegalStateException("SavedStateRegistry was already restored.".toString());
        }
        this.c = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
        this.d = true;
    }

    public final void g(Bundle bundle) {
        l.f(bundle, "outBundle");
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = this.c;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        ax.p308w.b<String, c>.d dVarJ = this.a.j();
        l.e(dVarJ, "this.components.iteratorWithAdditions()");
        while (dVarJ.hasNext()) {
            Map.Entry next = dVarJ.next();
            bundle2.putBundle((String) next.getKey(), ((c) next.getValue()).a());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public final void h(String str, c cVar) {
        l.f(str, "key");
        l.f(cVar, "provider");
        if (this.a.o(str, cVar) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered".toString());
        }
    }

    public final void i(Class<? extends InterfaceC0044a> cls) {
        l.f(cls, "clazz");
        if (!this.f) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState".toString());
        }
        Recreator.b bVar = this.e;
        if (bVar == null) {
            bVar = new Recreator.b(this);
        }
        this.e = bVar;
        try {
            cls.getDeclaredConstructor(null);
            Recreator.b bVar2 = this.e;
            if (bVar2 != null) {
                String name = cls.getName();
                l.e(name, "clazz.name");
                bVar2.b(name);
            }
        } catch (NoSuchMethodException e) {
            throw new IllegalArgumentException("Class " + cls.getSimpleName() + " must have default constructor in order to be automatically recreated", e);
        }
    }
}
