package androidx.viewpager2.adapter;

import androidx.lifecycle.d;
import androidx.lifecycle.f;
import ax.F0.g;

/* JADX INFO: loaded from: classes.dex */
class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements f {
    @Override // androidx.lifecycle.f
    public void d(g gVar, d.a aVar) {
        throw null;
    }
}
