package androidx.viewpager2.adapter;

import androidx.lifecycle.d;
import androidx.lifecycle.f;
import ax.G0.h;

/* JADX INFO: loaded from: classes.dex */
class FragmentStateAdapter$1 implements f {
    @Override // androidx.lifecycle.f
    public void b(h hVar, d.a aVar) {
        throw null;
    }
}
