package androidx.viewpager2.adapter;

import android.os.Handler;
import androidx.lifecycle.d;
import androidx.lifecycle.f;
import ax.F0.g;

/* JADX INFO: loaded from: classes.dex */
class FragmentStateAdapter$4 implements f {
    final /* synthetic */ Runnable X;
    final /* synthetic */ Handler q;

    @Override // androidx.lifecycle.f
    public void d(g gVar, d.a aVar) {
        if (aVar == d.a.ON_DESTROY) {
            this.q.removeCallbacks(this.X);
            gVar.f().c(this);
        }
    }
}
