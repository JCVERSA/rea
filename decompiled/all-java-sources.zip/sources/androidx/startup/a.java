package androidx.startup;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import ax.p309t2.c;
import ax.p357w2.b;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    private static volatile a d;
    private static final Object e = new Object();
    final Context c;
    final Set<Class<? extends ax.p309t2.a<?>>> b = new HashSet();
    final Map<Class<?>, Object> a = new HashMap();

    a(Context context) {
        this.c = context.getApplicationContext();
    }

    private <T> T d(Class<? extends ax.p309t2.a<?>> cls, Set<Class<?>> set) {
        T t;
        if (b.d()) {
            try {
                b.a(cls.getSimpleName());
            } catch (Throwable th) {
                b.b();
                throw th;
            }
        }
        if (set.contains(cls)) {
            throw new IllegalStateException(String.format("Cannot initialize %s. Cycle detected.", cls.getName()));
        }
        if (this.a.containsKey(cls)) {
            t = (T) this.a.get(cls);
        } else {
            set.add(cls);
            try {
                ax.p309t2.a<?> aVarNewInstance = cls.getDeclaredConstructor(null).newInstance(null);
                List<Class<? extends ax.p309t2.a<?>>> listA = aVarNewInstance.a();
                if (!listA.isEmpty()) {
                    for (Class<? extends ax.p309t2.a<?>> cls2 : listA) {
                        if (!this.a.containsKey(cls2)) {
                            d(cls2, set);
                        }
                    }
                }
                t = (T) aVarNewInstance.b(this.c);
                set.remove(cls);
                this.a.put(cls, t);
            } catch (Throwable th2) {
                throw new c(th2);
            }
        }
        b.b();
        return t;
    }

    public static a e(Context context) {
        if (d == null) {
            synchronized (e) {
                try {
                    if (d == null) {
                        d = new a(context);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return d;
    }

    void a() {
        try {
            try {
                b.a("Startup");
                b(this.c.getPackageManager().getProviderInfo(new ComponentName(this.c.getPackageName(), InitializationProvider.class.getName()), 128).metaData);
                b.b();
            } catch (PackageManager.NameNotFoundException e2) {
                throw new c(e2);
            }
        } catch (Throwable th) {
            b.b();
            throw th;
        }
    }

    void b(Bundle bundle) {
        String string = this.c.getString(ax.p309t2.b.a);
        if (bundle != null) {
            try {
                HashSet hashSet = new HashSet();
                for (String str : bundle.keySet()) {
                    if (string.equals(bundle.getString(str, null))) {
                        Class<?> cls = Class.forName(str);
                        if (ax.p309t2.a.class.isAssignableFrom(cls)) {
                            this.b.add((Class<? extends ax.p309t2.a<?>>) cls);
                        }
                    }
                }
                Iterator<Class<? extends ax.p309t2.a<?>>> it = this.b.iterator();
                while (it.hasNext()) {
                    d(it.next(), hashSet);
                }
            } catch (ClassNotFoundException e2) {
                throw new c(e2);
            }
        }
    }

    <T> T c(Class<? extends ax.p309t2.a<?>> cls) {
        T t;
        synchronized (e) {
            try {
                t = (T) this.a.get(cls);
                if (t == null) {
                    t = (T) d(cls, new HashSet());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return t;
    }

    public <T> T f(Class<? extends ax.p309t2.a<T>> cls) {
        return (T) c(cls);
    }

    public boolean g(Class<? extends ax.p309t2.a<?>> cls) {
        return this.b.contains(cls);
    }
}
