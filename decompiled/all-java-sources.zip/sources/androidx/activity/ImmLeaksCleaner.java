package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.f;
import ax.p111gc.h;
import ax.p111gc.i;
import ax.p335uc.g;
import ax.p335uc.l;
import ax.p335uc.m;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public final class ImmLeaksCleaner implements f {
    public static final c X = new c(null);
    private static final h<a> Y = i.a(b.q);
    private final Activity q;

    public static abstract class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public abstract boolean a(InputMethodManager inputMethodManager);

        public abstract Object b(InputMethodManager inputMethodManager);

        public abstract View c(InputMethodManager inputMethodManager);
    }

    static final class b extends m implements ax.p319tc.a<a> {
        public static final b q = new b();

        b() {
            super(0);
        }

        @Override // ax.p319tc.a
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final a invoke() {
            try {
                Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
                declaredField.setAccessible(true);
                Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
                declaredField2.setAccessible(true);
                Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
                declaredField3.setAccessible(true);
                l.e(declaredField3, "hField");
                l.e(declaredField, "servedViewField");
                l.e(declaredField2, "nextServedViewField");
                return new e(declaredField3, declaredField, declaredField2);
            } catch (NoSuchFieldException unused) {
                return d.a;
            }
        }
    }

    @SuppressLint({"SoonBlockedPrivateApi"})
    public static final class c {
        private c() {
        }

        public /* synthetic */ c(g gVar) {
            this();
        }

        public final a a() {
            return (a) ImmLeaksCleaner.Y.getValue();
        }
    }

    public static final class d extends a {
        public static final d a = new d();

        private d() {
            super(null);
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public boolean a(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            return false;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public Object b(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            return null;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public View c(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            return null;
        }
    }

    public static final class e extends a {
        private final Field a;
        private final Field b;
        private final Field c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(Field field, Field field2, Field field3) {
            super(null);
            l.f(field, "hField");
            l.f(field2, "servedViewField");
            l.f(field3, "nextServedViewField");
            this.a = field;
            this.b = field2;
            this.c = field3;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public boolean a(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            try {
                this.c.set(inputMethodManager, null);
                return true;
            } catch (IllegalAccessException unused) {
                return false;
            }
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public Object b(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            try {
                return this.a.get(inputMethodManager);
            } catch (IllegalAccessException unused) {
                return null;
            }
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public View c(InputMethodManager inputMethodManager) {
            l.f(inputMethodManager, "<this>");
            try {
                return (View) this.b.get(inputMethodManager);
            } catch (ClassCastException | IllegalAccessException unused) {
                return null;
            }
        }
    }

    public ImmLeaksCleaner(Activity activity) {
        l.f(activity, "activity");
        this.q = activity;
    }

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
        l.f(hVar, "source");
        l.f(aVar, "event");
        if (aVar != androidx.lifecycle.d.a.ON_DESTROY) {
            return;
        }
        Object systemService = this.q.getSystemService("input_method");
        l.d(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
        InputMethodManager inputMethodManager = (InputMethodManager) systemService;
        a aVarA = X.a();
        Object objB = aVarA.b(inputMethodManager);
        if (objB == null) {
            return;
        }
        synchronized (objB) {
            View viewC = aVarA.c(inputMethodManager);
            if (viewC == null) {
                return;
            }
            if (viewC.isAttachedToWindow()) {
                return;
            }
            boolean zA = aVarA.a(inputMethodManager);
            if (zA) {
                inputMethodManager.isActive();
            }
        }
    }
}
