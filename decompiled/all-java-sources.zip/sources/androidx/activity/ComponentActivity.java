package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.k;
import ax.F0.t;
import ax.F0.u;
import ax.F0.v;
import ax.O.h;
import ax.O.i;
import ax.O.q;
import ax.O.r;
import ax.p015b0.A;
import ax.p015b0.C5254y;
import ax.p015b0.InterfaceC5252x;
import ax.p112i.l;
import ax.p112i.m;
import ax.p112i.p;
import ax.p112i.s;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public class ComponentActivity extends h implements ax.F0.g, t, androidx.lifecycle.c, ax.p016b1.d, p, ax.p140k.d, ax.P.e, ax.P.f, q, r, InterfaceC5252x, m {
    final ax.p126j.a Y = new ax.p126j.a();
    private final C5254y Z = new C5254y(new Runnable() { // from class: ax.i.d
        @Override // java.lang.Runnable
        public final void run() {
            this.q.l0();
        }
    });
    private final androidx.lifecycle.g h0 = new androidx.lifecycle.g(this);
    final ax.p016b1.c i0;
    private androidx.lifecycle.q j0;
    private OnBackPressedDispatcher k0;
    final f l0;
    final l m0;
    private int n0;
    private final AtomicInteger o0;
    private final ActivityResultRegistry p0;
    private final CopyOnWriteArrayList<ax.p001a0.a<Configuration>> q0;
    private final CopyOnWriteArrayList<ax.p001a0.a<Integer>> r0;
    private final CopyOnWriteArrayList<ax.p001a0.a<Intent>> s0;
    private final CopyOnWriteArrayList<ax.p001a0.a<i>> t0;
    private final CopyOnWriteArrayList<ax.p001a0.a<ax.O.t>> u0;
    private boolean v0;
    private boolean w0;

    class a extends ActivityResultRegistry {

        /* JADX INFO: renamed from: androidx.activity.ComponentActivity$a$a, reason: collision with other inner class name */
        class RunnableC0005a implements Runnable {
            final /* synthetic */ ax.p154l.a.C0384a X;
            final /* synthetic */ int q;

            RunnableC0005a(int i, ax.p154l.a.C0384a c0384a) {
                this.q = i;
                this.X = c0384a;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.c(this.q, this.X.a());
            }
        }

        class b implements Runnable {
            final /* synthetic */ IntentSender.SendIntentException X;
            final /* synthetic */ int q;

            b(int i, IntentSender.SendIntentException sendIntentException) {
                this.q = i;
                this.X = sendIntentException;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.b(this.q, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", this.X));
            }
        }

        a() {
        }

        @Override // androidx.activity.result.ActivityResultRegistry
        public <I, O> void f(int i, ax.p154l.a<I, O> aVar, I i2, ax.O.c cVar) {
            Bundle bundle;
            ComponentActivity componentActivity = ComponentActivity.this;
            ax.p154l.a.C0384a<O> c0384aB = aVar.b(componentActivity, i2);
            if (c0384aB != null) {
                new Handler(Looper.getMainLooper()).post(new RunnableC0005a(i, c0384aB));
                return;
            }
            Intent intentA = aVar.a(componentActivity, i2);
            if (intentA.getExtras() != null && intentA.getExtras().getClassLoader() == null) {
                intentA.setExtrasClassLoader(componentActivity.getClassLoader());
            }
            if (intentA.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
                Bundle bundleExtra = intentA.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                intentA.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                bundle = bundleExtra;
            } else {
                bundle = null;
            }
            if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intentA.getAction())) {
                String[] stringArrayExtra = intentA.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (stringArrayExtra == null) {
                    stringArrayExtra = new String[0];
                }
                ax.O.b.r(componentActivity, stringArrayExtra, i);
                return;
            }
            if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intentA.getAction())) {
                ax.O.b.t(componentActivity, intentA, i, bundle);
                return;
            }
            ax.p140k.e eVar = (ax.p140k.e) intentA.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
            try {
                ax.O.b.u(componentActivity, eVar.d(), i, eVar.a(), eVar.b(), eVar.c(), 0, bundle);
            } catch (IntentSender.SendIntentException e) {
                new Handler(Looper.getMainLooper()).post(new b(i, e));
            }
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                ComponentActivity.super.onBackPressed();
            } catch (IllegalStateException e) {
                if (!TextUtils.equals(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e;
                }
            } catch (NullPointerException e2) {
                if (!TextUtils.equals(e2.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                    throw e2;
                }
            }
        }
    }

    static class c {
        static void a(View view) {
            view.cancelPendingInputEvents();
        }
    }

    static class d {
        static OnBackInvokedDispatcher a(Activity activity) {
            return activity.getOnBackInvokedDispatcher();
        }
    }

    static final class e {
        Object a;
        androidx.lifecycle.q b;

        e() {
        }
    }

    private interface f extends Executor {
        void H(View view);

        void h();
    }

    class g implements f, ViewTreeObserver.OnDrawListener, Runnable {
        Runnable X;
        final long q = SystemClock.uptimeMillis() + 10000;
        boolean Y = false;

        g() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            Runnable runnable = this.X;
            if (runnable != null) {
                runnable.run();
                this.X = null;
            }
        }

        @Override // androidx.activity.ComponentActivity.f
        public void H(View view) {
            if (this.Y) {
                return;
            }
            this.Y = true;
            view.getViewTreeObserver().addOnDrawListener(this);
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            this.X = runnable;
            View decorView = ComponentActivity.this.getWindow().getDecorView();
            if (!this.Y) {
                decorView.postOnAnimation(new Runnable() { // from class: androidx.activity.a
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.q.b();
                    }
                });
            } else if (Looper.myLooper() == Looper.getMainLooper()) {
                decorView.invalidate();
            } else {
                decorView.postInvalidate();
            }
        }

        @Override // androidx.activity.ComponentActivity.f
        public void h() {
            ComponentActivity.this.getWindow().getDecorView().removeCallbacks(this);
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnDrawListener
        public void onDraw() {
            Runnable runnable = this.X;
            if (runnable == null) {
                if (SystemClock.uptimeMillis() > this.q) {
                    this.Y = false;
                    ComponentActivity.this.getWindow().getDecorView().post(this);
                    return;
                }
                return;
            }
            runnable.run();
            this.X = null;
            if (ComponentActivity.this.m0.c()) {
                this.Y = false;
                ComponentActivity.this.getWindow().getDecorView().post(this);
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }
    }

    public ComponentActivity() {
        ax.p016b1.c cVarA = ax.p016b1.c.a(this);
        this.i0 = cVarA;
        this.k0 = null;
        f fVarI0 = i0();
        this.l0 = fVarI0;
        this.m0 = new l(fVarI0, new ax.p124ib.a() { // from class: ax.i.e
            @Override // ax.p124ib.a
            public final Object invoke() {
                return this.q.m0();
            }
        });
        this.o0 = new AtomicInteger();
        this.p0 = new a();
        this.q0 = new CopyOnWriteArrayList<>();
        this.r0 = new CopyOnWriteArrayList<>();
        this.s0 = new CopyOnWriteArrayList<>();
        this.t0 = new CopyOnWriteArrayList<>();
        this.u0 = new CopyOnWriteArrayList<>();
        this.v0 = false;
        this.w0 = false;
        if (f() == null) {
            throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        }
        int i = Build.VERSION.SDK_INT;
        f().a(new androidx.lifecycle.f() { // from class: androidx.activity.ComponentActivity.2
            @Override // androidx.lifecycle.f
            public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                if (aVar == androidx.lifecycle.d.a.ON_STOP) {
                    Window window = ComponentActivity.this.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        c.a(viewPeekDecorView);
                    }
                }
            }
        });
        f().a(new androidx.lifecycle.f() { // from class: androidx.activity.ComponentActivity.3
            @Override // androidx.lifecycle.f
            public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                if (aVar == androidx.lifecycle.d.a.ON_DESTROY) {
                    ComponentActivity.this.Y.b();
                    if (!ComponentActivity.this.isChangingConfigurations()) {
                        ComponentActivity.this.J().a();
                    }
                    ComponentActivity.this.l0.h();
                }
            }
        });
        f().a(new androidx.lifecycle.f() { // from class: androidx.activity.ComponentActivity.4
            @Override // androidx.lifecycle.f
            public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                ComponentActivity.this.j0();
                ComponentActivity.this.f().c(this);
            }
        });
        cVarA.c();
        androidx.lifecycle.m.a(this);
        if (i <= 23) {
            f().a(new ImmLeaksCleaner(this));
        }
        R().h("android:support:activity-result", new androidx.savedstate.a.c() { // from class: ax.i.f
            @Override // androidx.savedstate.a.c
            public final Bundle a() {
                return this.a.n0();
            }
        });
        g0(new ax.p126j.b() { // from class: ax.i.g
            @Override // ax.p126j.b
            public final void a(Context context) {
                this.a.o0(context);
            }
        });
    }

    private f i0() {
        return new g();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ ax.Wa.t m0() {
        reportFullyDrawn();
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Bundle n0() {
        Bundle bundle = new Bundle();
        this.p0.h(bundle);
        return bundle;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o0(Context context) {
        Bundle bundleB = R().b("android:support:activity-result");
        if (bundleB != null) {
            this.p0.g(bundleB);
        }
    }

    @Override // ax.O.r
    public final void B(ax.p001a0.a<ax.O.t> aVar) {
        this.u0.remove(aVar);
    }

    @Override // androidx.lifecycle.c
    public ax.H0.a E() {
        ax.H0.d dVar = new ax.H0.d();
        if (getApplication() != null) {
            dVar.b(androidx.lifecycle.p.a.d, getApplication());
        }
        dVar.b(androidx.lifecycle.m.a, this);
        dVar.b(androidx.lifecycle.m.b, this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            dVar.b(androidx.lifecycle.m.c, getIntent().getExtras());
        }
        return dVar;
    }

    @Override // ax.F0.t
    public androidx.lifecycle.q J() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        j0();
        return this.j0;
    }

    @Override // ax.O.q
    public final void K(ax.p001a0.a<i> aVar) {
        this.t0.remove(aVar);
    }

    @Override // ax.O.r
    public final void L(ax.p001a0.a<ax.O.t> aVar) {
        this.u0.add(aVar);
    }

    @Override // ax.O.q
    public final void N(ax.p001a0.a<i> aVar) {
        this.t0.add(aVar);
    }

    @Override // ax.P.e
    public final void Q(ax.p001a0.a<Configuration> aVar) {
        this.q0.add(aVar);
    }

    @Override // ax.p016b1.d
    public final androidx.savedstate.a R() {
        return this.i0.b();
    }

    @Override // ax.P.f
    public final void W(ax.p001a0.a<Integer> aVar) {
        this.r0.add(aVar);
    }

    @Override // ax.P.f
    public final void X(ax.p001a0.a<Integer> aVar) {
        this.r0.remove(aVar);
    }

    @Override // android.app.Activity
    public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams layoutParams) {
        k0();
        this.l0.H(getWindow().getDecorView());
        super.addContentView(view, layoutParams);
    }

    @Override // ax.O.h, ax.F0.g
    public androidx.lifecycle.d f() {
        return this.h0;
    }

    public final void g0(ax.p126j.b bVar) {
        this.Y.a(bVar);
    }

    public final void h0(ax.p001a0.a<Intent> aVar) {
        this.s0.add(aVar);
    }

    @Override // ax.p015b0.InterfaceC5252x
    public void j(A a2) {
        this.Z.f(a2);
    }

    void j0() {
        if (this.j0 == null) {
            e eVar = (e) getLastNonConfigurationInstance();
            if (eVar != null) {
                this.j0 = eVar.b;
            }
            if (this.j0 == null) {
                this.j0 = new androidx.lifecycle.q();
            }
        }
    }

    public void k0() {
        u.a(getWindow().getDecorView(), this);
        v.a(getWindow().getDecorView(), this);
        ax.p016b1.e.a(getWindow().getDecorView(), this);
        s.a(getWindow().getDecorView(), this);
        ax.p112i.r.a(getWindow().getDecorView(), this);
    }

    @Override // ax.P.e
    public final void l(ax.p001a0.a<Configuration> aVar) {
        this.q0.remove(aVar);
    }

    public void l0() {
        invalidateOptionsMenu();
    }

    @Override // android.app.Activity
    @Deprecated
    protected void onActivityResult(int i, int i2, Intent intent) {
        if (this.p0.b(i, i2, intent)) {
            return;
        }
        super.onActivityResult(i, i2, intent);
    }

    @Override // android.app.Activity
    @Deprecated
    public void onBackPressed() {
        q().k();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator<ax.p001a0.a<Configuration>> it = this.q0.iterator();
        while (it.hasNext()) {
            it.next().a(configuration);
        }
    }

    @Override // ax.O.h, android.app.Activity
    protected void onCreate(Bundle bundle) {
        this.i0.d(bundle);
        this.Y.c(this);
        super.onCreate(bundle);
        k.e(this);
        int i = this.n0;
        if (i != 0) {
            setContentView(i);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int i, Menu menu) {
        if (i != 0) {
            return true;
        }
        super.onCreatePanelMenu(i, menu);
        this.Z.b(menu, getMenuInflater());
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.Z.d(menuItem);
        }
        return false;
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z) {
        if (this.v0) {
            return;
        }
        Iterator<ax.p001a0.a<i>> it = this.t0.iterator();
        while (it.hasNext()) {
            it.next().a(new i(z));
        }
    }

    @Override // android.app.Activity
    protected void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent intent) {
        super.onNewIntent(intent);
        Iterator<ax.p001a0.a<Intent>> it = this.s0.iterator();
        while (it.hasNext()) {
            it.next().a(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i, Menu menu) {
        this.Z.c(menu);
        super.onPanelClosed(i, menu);
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z) {
        if (this.w0) {
            return;
        }
        Iterator<ax.p001a0.a<ax.O.t>> it = this.u0.iterator();
        while (it.hasNext()) {
            it.next().a(new ax.O.t(z));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int i, View view, Menu menu) {
        if (i != 0) {
            return true;
        }
        super.onPreparePanel(i, view, menu);
        this.Z.e(menu);
        return true;
    }

    @Override // android.app.Activity
    @Deprecated
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (this.p0.b(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) || Build.VERSION.SDK_INT < 23) {
            return;
        }
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        e eVar;
        Object objP0 = p0();
        androidx.lifecycle.q qVar = this.j0;
        if (qVar == null && (eVar = (e) getLastNonConfigurationInstance()) != null) {
            qVar = eVar.b;
        }
        if (qVar == null && objP0 == null) {
            return null;
        }
        e eVar2 = new e();
        eVar2.a = objP0;
        eVar2.b = qVar;
        return eVar2;
    }

    @Override // ax.O.h, android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.d dVarF = f();
        if (dVarF instanceof androidx.lifecycle.g) {
            ((androidx.lifecycle.g) dVarF).m(androidx.lifecycle.d.b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.i0.e(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public void onTrimMemory(int i) {
        super.onTrimMemory(i);
        Iterator<ax.p001a0.a<Integer>> it = this.r0.iterator();
        while (it.hasNext()) {
            it.next().a(Integer.valueOf(i));
        }
    }

    @Deprecated
    public Object p0() {
        return null;
    }

    @Override // ax.p112i.p
    public final OnBackPressedDispatcher q() {
        if (this.k0 == null) {
            this.k0 = new OnBackPressedDispatcher(new b());
            f().a(new androidx.lifecycle.f() { // from class: androidx.activity.ComponentActivity.6
                @Override // androidx.lifecycle.f
                public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
                    if (aVar != androidx.lifecycle.d.a.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                        return;
                    }
                    ComponentActivity.this.k0.n(d.a((ComponentActivity) gVar));
                }
            });
        }
        return this.k0;
    }

    public final <I, O> ax.p140k.c<I> q0(ax.p154l.a<I, O> aVar, ActivityResultRegistry activityResultRegistry, ax.p140k.b<O> bVar) {
        return activityResultRegistry.i("activity_rq#" + this.o0.getAndIncrement(), this, aVar, bVar);
    }

    @Override // ax.p140k.d
    public final ActivityResultRegistry r() {
        return this.p0;
    }

    public final <I, O> ax.p140k.c<I> r0(ax.p154l.a<I, O> aVar, ax.p140k.b<O> bVar) {
        return q0(aVar, this.p0, bVar);
    }

    @Override // android.app.Activity
    public void reportFullyDrawn() {
        try {
            if (ax.p086g1.b.d()) {
                ax.p086g1.b.a("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            this.m0.b();
        } finally {
            ax.p086g1.b.b();
        }
    }

    @Override // ax.p015b0.InterfaceC5252x
    public void s(A a2) {
        this.Z.a(a2);
    }

    @Override // android.app.Activity
    public void setContentView(int i) {
        k0();
        this.l0.H(getWindow().getDecorView());
        super.setContentView(i);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startActivityForResult(Intent intent, int i) {
        super.startActivityForResult(intent, i);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        super.startActivityForResult(intent, i, bundle);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z, Configuration configuration) {
        this.v0 = true;
        try {
            super.onMultiWindowModeChanged(z, configuration);
            this.v0 = false;
            Iterator<ax.p001a0.a<i>> it = this.t0.iterator();
            while (it.hasNext()) {
                it.next().a(new i(z, configuration));
            }
        } catch (Throwable th) {
            this.v0 = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        this.w0 = true;
        try {
            super.onPictureInPictureModeChanged(z, configuration);
            this.w0 = false;
            Iterator<ax.p001a0.a<ax.O.t>> it = this.u0.iterator();
            while (it.hasNext()) {
                it.next().a(new ax.O.t(z, configuration));
            }
        } catch (Throwable th) {
            this.w0 = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        k0();
        this.l0.H(getWindow().getDecorView());
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams layoutParams) {
        k0();
        this.l0.H(getWindow().getDecorView());
        super.setContentView(view, layoutParams);
    }
}
