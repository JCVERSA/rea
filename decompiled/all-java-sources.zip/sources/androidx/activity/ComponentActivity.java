package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.d;
import androidx.lifecycle.k;
import androidx.lifecycle.n;
import ax.G0.h;
import ax.G0.v;
import ax.G0.w;
import ax.G0.x;
import ax.P.q;
import ax.P.r;
import ax.P.t;
import ax.p035c0.B;
import ax.p035c0.C1881z;
import ax.p035c0.InterfaceC1875w;
import ax.p130i.p;
import ax.p130i.u;
import ax.p335uc.l;
import ax.p335uc.m;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public class ComponentActivity extends ax.P.h implements ax.G0.h, v, androidx.lifecycle.c, ax.p245p2.d, u, ax.p162k.f, ax.Q.e, ax.Q.f, q, r, InterfaceC1875w, ax.p130i.q {
    private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
    private static final b Companion = new b(null);
    private androidx.lifecycle.r _viewModelStore;
    private final ax.p162k.e activityResultRegistry;
    private int contentLayoutId;
    private final ax.p146j.a contextAwareHelper;
    private final ax.p111gc.h defaultViewModelProviderFactory$delegate;
    private boolean dispatchingOnMultiWindowModeChanged;
    private boolean dispatchingOnPictureInPictureModeChanged;
    private final ax.p111gc.h fullyDrawnReporter$delegate;
    private final C1881z menuHostHelper;
    private final AtomicInteger nextLocalRequestCode;
    private final ax.p111gc.h onBackPressedDispatcher$delegate;
    private final CopyOnWriteArrayList<ax.p019b0.a<Configuration>> onConfigurationChangedListeners;
    private final CopyOnWriteArrayList<ax.p019b0.a<ax.P.i>> onMultiWindowModeChangedListeners;
    private final CopyOnWriteArrayList<ax.p019b0.a<Intent>> onNewIntentListeners;
    private final CopyOnWriteArrayList<ax.p019b0.a<t>> onPictureInPictureModeChangedListeners;
    private final CopyOnWriteArrayList<ax.p019b0.a<Integer>> onTrimMemoryListeners;
    private final CopyOnWriteArrayList<Runnable> onUserLeaveHintListeners;
    private final d reportFullyDrawnExecutor;
    private final ax.p245p2.c savedStateRegistryController;

    private static final class a {
        public static final a a = new a();

        private a() {
        }

        public final OnBackInvokedDispatcher a(Activity activity) {
            l.f(activity, "activity");
            OnBackInvokedDispatcher onBackInvokedDispatcher = activity.getOnBackInvokedDispatcher();
            l.e(onBackInvokedDispatcher, "activity.getOnBackInvokedDispatcher()");
            return onBackInvokedDispatcher;
        }
    }

    private static final class b {
        private b() {
        }

        public /* synthetic */ b(ax.p335uc.g gVar) {
            this();
        }
    }

    public static final class c {
        private Object a;
        private androidx.lifecycle.r b;

        public final Object a() {
            return this.a;
        }

        public final androidx.lifecycle.r b() {
            return this.b;
        }

        public final void c(Object obj) {
            this.a = obj;
        }

        public final void d(androidx.lifecycle.r rVar) {
            this.b = rVar;
        }
    }

    private interface d extends Executor {
        void N(View view);

        void k();
    }

    /* JADX INFO: Access modifiers changed from: private */
    final class e implements d, ViewTreeObserver.OnDrawListener, Runnable {
        private Runnable X;
        private boolean Y;
        private final long q = SystemClock.uptimeMillis() + ((long) 10000);

        public e() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(e eVar) {
            l.f(eVar, "this$0");
            Runnable runnable = eVar.X;
            if (runnable != null) {
                l.c(runnable);
                runnable.run();
                eVar.X = null;
            }
        }

        @Override // androidx.activity.ComponentActivity.d
        public void N(View view) {
            l.f(view, "view");
            if (this.Y) {
                return;
            }
            this.Y = true;
            view.getViewTreeObserver().addOnDrawListener(this);
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            l.f(runnable, "runnable");
            this.X = runnable;
            View decorView = ComponentActivity.this.getWindow().getDecorView();
            l.e(decorView, "window.decorView");
            if (!this.Y) {
                decorView.postOnAnimation(new Runnable() { // from class: androidx.activity.a
                    @Override // java.lang.Runnable
                    public final void run() {
                        ComponentActivity.e.c(this.q);
                    }
                });
            } else if (l.a(Looper.myLooper(), Looper.getMainLooper())) {
                decorView.invalidate();
            } else {
                decorView.postInvalidate();
            }
        }

        @Override // androidx.activity.ComponentActivity.d
        public void k() {
            ComponentActivity.this.getWindow().getDecorView().removeCallbacks(this);
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnDrawListener
        public void onDraw() {
            Runnable runnable = this.X;
            if (runnable == null) {
                if (SystemClock.uptimeMillis() > this.q) {
                    this.Y = false;
                    ComponentActivity.this.getWindow().getDecorView().post(this);
                    return;
                }
                return;
            }
            runnable.run();
            this.X = null;
            if (ComponentActivity.this.getFullyDrawnReporter().c()) {
                this.Y = false;
                ComponentActivity.this.getWindow().getDecorView().post(this);
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }
    }

    public static final class f extends ax.p162k.e {
        f() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void s(f fVar, int i, ax.p178l.a.C0373a c0373a) {
            l.f(fVar, "this$0");
            fVar.f(i, c0373a.a());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void t(f fVar, int i, IntentSender.SendIntentException sendIntentException) {
            l.f(fVar, "this$0");
            l.f(sendIntentException, "$e");
            fVar.e(i, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", sendIntentException));
        }

        @Override // ax.p162k.e
        public <I, O> void i(final int i, ax.p178l.a<I, O> aVar, I i2, ax.P.c cVar) {
            Bundle bundleExtra;
            final int i3;
            l.f(aVar, "contract");
            ComponentActivity componentActivity = ComponentActivity.this;
            final ax.p178l.a.C0373a<O> c0373aB = aVar.b(componentActivity, i2);
            if (c0373aB != null) {
                new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: ax.i.j
                    @Override // java.lang.Runnable
                    public final void run() {
                        ComponentActivity.f.s(this.q, i, c0373aB);
                    }
                });
                return;
            }
            Intent intentA = aVar.a(componentActivity, i2);
            if (intentA.getExtras() != null) {
                Bundle extras = intentA.getExtras();
                l.c(extras);
                if (extras.getClassLoader() == null) {
                    intentA.setExtrasClassLoader(componentActivity.getClassLoader());
                }
            }
            if (intentA.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
                bundleExtra = intentA.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                intentA.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            } else {
                bundleExtra = null;
            }
            Bundle bundle = bundleExtra;
            if (l.a("androidx.activity.result.contract.action.REQUEST_PERMISSIONS", intentA.getAction())) {
                String[] stringArrayExtra = intentA.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (stringArrayExtra == null) {
                    stringArrayExtra = new String[0];
                }
                ax.P.b.s(componentActivity, stringArrayExtra, i);
                return;
            }
            if (!l.a("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST", intentA.getAction())) {
                ax.P.b.w(componentActivity, intentA, i, bundle);
                return;
            }
            ax.p162k.g gVar = (ax.p162k.g) intentA.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
            try {
                l.c(gVar);
                i3 = i;
                try {
                    ax.P.b.x(componentActivity, gVar.d(), i3, gVar.a(), gVar.b(), gVar.c(), 0, bundle);
                } catch (IntentSender.SendIntentException e) {
                    e = e;
                    final IntentSender.SendIntentException sendIntentException = e;
                    new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: ax.i.k
                        @Override // java.lang.Runnable
                        public final void run() {
                            ComponentActivity.f.t(this.q, i3, sendIntentException);
                        }
                    });
                }
            } catch (IntentSender.SendIntentException e2) {
                e = e2;
                i3 = i;
            }
        }
    }

    static final class g extends m implements ax.p319tc.a<n> {
        g() {
            super(0);
        }

        @Override // ax.p319tc.a
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final n invoke() {
            Application application = ComponentActivity.this.getApplication();
            ComponentActivity componentActivity = ComponentActivity.this;
            return new n(application, componentActivity, componentActivity.getIntent() != null ? ComponentActivity.this.getIntent().getExtras() : null);
        }
    }

    static final class h extends m implements ax.p319tc.a<p> {

        static final class a extends m implements ax.p319tc.a<ax.p111gc.t> {
            final /* synthetic */ ComponentActivity q;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(ComponentActivity componentActivity) {
                super(0);
                this.q = componentActivity;
            }

            public final void a() {
                this.q.reportFullyDrawn();
            }

            @Override // ax.p319tc.a
            public /* bridge */ /* synthetic */ ax.p111gc.t invoke() {
                a();
                return ax.p111gc.t.a;
            }
        }

        h() {
            super(0);
        }

        @Override // ax.p319tc.a
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final p invoke() {
            return new p(ComponentActivity.this.reportFullyDrawnExecutor, new a(ComponentActivity.this));
        }
    }

    static final class i extends m implements ax.p319tc.a<OnBackPressedDispatcher> {
        i() {
            super(0);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void e(ComponentActivity componentActivity) {
            l.f(componentActivity, "this$0");
            try {
                ComponentActivity.super.onBackPressed();
            } catch (IllegalStateException e) {
                if (!l.a(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e;
                }
            } catch (NullPointerException e2) {
                if (!l.a(e2.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                    throw e2;
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void g(ComponentActivity componentActivity, OnBackPressedDispatcher onBackPressedDispatcher) {
            l.f(componentActivity, "this$0");
            l.f(onBackPressedDispatcher, "$dispatcher");
            componentActivity.addObserverForBackInvoker(onBackPressedDispatcher);
        }

        @Override // ax.p319tc.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public final OnBackPressedDispatcher invoke() {
            final ComponentActivity componentActivity = ComponentActivity.this;
            final OnBackPressedDispatcher onBackPressedDispatcher = new OnBackPressedDispatcher(new Runnable() { // from class: androidx.activity.b
                @Override // java.lang.Runnable
                public final void run() {
                    ComponentActivity.i.e(componentActivity);
                }
            });
            final ComponentActivity componentActivity2 = ComponentActivity.this;
            if (Build.VERSION.SDK_INT >= 33) {
                if (!l.a(Looper.myLooper(), Looper.getMainLooper())) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: androidx.activity.c
                        @Override // java.lang.Runnable
                        public final void run() {
                            ComponentActivity.i.g(componentActivity2, onBackPressedDispatcher);
                        }
                    });
                    return onBackPressedDispatcher;
                }
                componentActivity2.addObserverForBackInvoker(onBackPressedDispatcher);
            }
            return onBackPressedDispatcher;
        }
    }

    public ComponentActivity() {
        this.contextAwareHelper = new ax.p146j.a();
        this.menuHostHelper = new C1881z(new Runnable() { // from class: ax.i.d
            @Override // java.lang.Runnable
            public final void run() {
                ComponentActivity.menuHostHelper$lambda$0(this.q);
            }
        });
        ax.p245p2.c cVarA = ax.p245p2.c.d.a(this);
        this.savedStateRegistryController = cVarA;
        this.reportFullyDrawnExecutor = createFullyDrawnExecutor();
        this.fullyDrawnReporter$delegate = ax.p111gc.i.a(new h());
        this.nextLocalRequestCode = new AtomicInteger();
        this.activityResultRegistry = new f();
        this.onConfigurationChangedListeners = new CopyOnWriteArrayList<>();
        this.onTrimMemoryListeners = new CopyOnWriteArrayList<>();
        this.onNewIntentListeners = new CopyOnWriteArrayList<>();
        this.onMultiWindowModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<>();
        this.onUserLeaveHintListeners = new CopyOnWriteArrayList<>();
        if (getLifecycle() == null) {
            throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        }
        getLifecycle().a(new androidx.lifecycle.f() { // from class: ax.i.e
            @Override // androidx.lifecycle.f
            public final void b(h hVar, d.a aVar) {
                ComponentActivity._init_$lambda$2(this.q, hVar, aVar);
            }
        });
        getLifecycle().a(new androidx.lifecycle.f() { // from class: ax.i.f
            @Override // androidx.lifecycle.f
            public final void b(h hVar, d.a aVar) {
                ComponentActivity._init_$lambda$3(this.q, hVar, aVar);
            }
        });
        getLifecycle().a(new androidx.lifecycle.f() { // from class: androidx.activity.ComponentActivity.4
            @Override // androidx.lifecycle.f
            public void b(ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
                l.f(hVar, "source");
                l.f(aVar, "event");
                ComponentActivity.this.ensureViewModelStore();
                ComponentActivity.this.getLifecycle().c(this);
            }
        });
        cVarA.c();
        androidx.lifecycle.m.c(this);
        if (Build.VERSION.SDK_INT <= 23) {
            getLifecycle().a(new ImmLeaksCleaner(this));
        }
        getSavedStateRegistry().h(ACTIVITY_RESULT_TAG, new androidx.savedstate.a.c() { // from class: ax.i.g
            @Override // androidx.savedstate.a.c
            public final Bundle a() {
                return ComponentActivity._init_$lambda$4(this.a);
            }
        });
        addOnContextAvailableListener(new ax.p146j.b() { // from class: ax.i.h
            @Override // ax.p146j.b
            public final void a(Context context) {
                ComponentActivity._init_$lambda$5(this.a, context);
            }
        });
        this.defaultViewModelProviderFactory$delegate = ax.p111gc.i.a(new g());
        this.onBackPressedDispatcher$delegate = ax.p111gc.i.a(new i());
    }

    public ComponentActivity(int i2) {
        this();
        this.contentLayoutId = i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$2(ComponentActivity componentActivity, ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
        Window window;
        View viewPeekDecorView;
        l.f(componentActivity, "this$0");
        l.f(hVar, "<anonymous parameter 0>");
        l.f(aVar, "event");
        if (aVar != androidx.lifecycle.d.a.ON_STOP || (window = componentActivity.getWindow()) == null || (viewPeekDecorView = window.peekDecorView()) == null) {
            return;
        }
        viewPeekDecorView.cancelPendingInputEvents();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$3(ComponentActivity componentActivity, ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
        l.f(componentActivity, "this$0");
        l.f(hVar, "<anonymous parameter 0>");
        l.f(aVar, "event");
        if (aVar == androidx.lifecycle.d.a.ON_DESTROY) {
            componentActivity.contextAwareHelper.b();
            if (!componentActivity.isChangingConfigurations()) {
                componentActivity.getViewModelStore().a();
            }
            componentActivity.reportFullyDrawnExecutor.k();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Bundle _init_$lambda$4(ComponentActivity componentActivity) {
        l.f(componentActivity, "this$0");
        Bundle bundle = new Bundle();
        componentActivity.activityResultRegistry.k(bundle);
        return bundle;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$5(ComponentActivity componentActivity, Context context) {
        l.f(componentActivity, "this$0");
        l.f(context, "it");
        Bundle bundleB = componentActivity.getSavedStateRegistry().b(ACTIVITY_RESULT_TAG);
        if (bundleB != null) {
            componentActivity.activityResultRegistry.j(bundleB);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void addObserverForBackInvoker(final OnBackPressedDispatcher onBackPressedDispatcher) {
        getLifecycle().a(new androidx.lifecycle.f() { // from class: ax.i.i
            @Override // androidx.lifecycle.f
            public final void b(h hVar, d.a aVar) {
                ComponentActivity.addObserverForBackInvoker$lambda$7(onBackPressedDispatcher, this, hVar, aVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addObserverForBackInvoker$lambda$7(OnBackPressedDispatcher onBackPressedDispatcher, ComponentActivity componentActivity, ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
        l.f(onBackPressedDispatcher, "$dispatcher");
        l.f(componentActivity, "this$0");
        l.f(hVar, "<anonymous parameter 0>");
        l.f(aVar, "event");
        if (aVar == androidx.lifecycle.d.a.ON_CREATE) {
            onBackPressedDispatcher.n(a.a.a(componentActivity));
        }
    }

    private final d createFullyDrawnExecutor() {
        return new e();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void ensureViewModelStore() {
        if (this._viewModelStore == null) {
            c cVar = (c) getLastNonConfigurationInstance();
            if (cVar != null) {
                this._viewModelStore = cVar.b();
            }
            if (this._viewModelStore == null) {
                this._viewModelStore = new androidx.lifecycle.r();
            }
        }
    }

    public static /* synthetic */ void getOnBackPressedDispatcher$annotations() {
    }

    private static /* synthetic */ void getSavedStateRegistryController$annotations() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void menuHostHelper$lambda$0(ComponentActivity componentActivity) {
        l.f(componentActivity, "this$0");
        componentActivity.invalidateMenu();
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        d dVar = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        l.e(decorView, "window.decorView");
        dVar.N(decorView);
        super.addContentView(view, layoutParams);
    }

    @Override // ax.p035c0.InterfaceC1875w
    public void addMenuProvider(B b2) {
        l.f(b2, "provider");
        this.menuHostHelper.c(b2);
    }

    public void addMenuProvider(B b2, ax.G0.h hVar) {
        l.f(b2, "provider");
        l.f(hVar, "owner");
        this.menuHostHelper.d(b2, hVar);
    }

    @SuppressLint({"LambdaLast"})
    public void addMenuProvider(B b2, ax.G0.h hVar, androidx.lifecycle.d.b bVar) {
        l.f(b2, "provider");
        l.f(hVar, "owner");
        l.f(bVar, "state");
        this.menuHostHelper.e(b2, hVar, bVar);
    }

    @Override // ax.Q.e
    public final void addOnConfigurationChangedListener(ax.p019b0.a<Configuration> aVar) {
        l.f(aVar, "listener");
        this.onConfigurationChangedListeners.add(aVar);
    }

    public final void addOnContextAvailableListener(ax.p146j.b bVar) {
        l.f(bVar, "listener");
        this.contextAwareHelper.a(bVar);
    }

    @Override // ax.P.q
    public final void addOnMultiWindowModeChangedListener(ax.p019b0.a<ax.P.i> aVar) {
        l.f(aVar, "listener");
        this.onMultiWindowModeChangedListeners.add(aVar);
    }

    public final void addOnNewIntentListener(ax.p019b0.a<Intent> aVar) {
        l.f(aVar, "listener");
        this.onNewIntentListeners.add(aVar);
    }

    @Override // ax.P.r
    public final void addOnPictureInPictureModeChangedListener(ax.p019b0.a<t> aVar) {
        l.f(aVar, "listener");
        this.onPictureInPictureModeChangedListeners.add(aVar);
    }

    @Override // ax.Q.f
    public final void addOnTrimMemoryListener(ax.p019b0.a<Integer> aVar) {
        l.f(aVar, "listener");
        this.onTrimMemoryListeners.add(aVar);
    }

    public final void addOnUserLeaveHintListener(Runnable runnable) {
        l.f(runnable, "listener");
        this.onUserLeaveHintListeners.add(runnable);
    }

    @Override // ax.p162k.f
    public final ax.p162k.e getActivityResultRegistry() {
        return this.activityResultRegistry;
    }

    @Override // androidx.lifecycle.c
    public ax.I0.a getDefaultViewModelCreationExtras() {
        ax.I0.d dVar = new ax.I0.d(null, 1, null);
        if (getApplication() != null) {
            ax.I0.a.b<Application> bVar = androidx.lifecycle.q.a.g;
            Application application = getApplication();
            l.e(application, "application");
            dVar.c(bVar, application);
        }
        dVar.c(androidx.lifecycle.m.a, this);
        dVar.c(androidx.lifecycle.m.b, this);
        Intent intent = getIntent();
        Bundle extras = intent != null ? intent.getExtras() : null;
        if (extras != null) {
            dVar.c(androidx.lifecycle.m.c, extras);
        }
        return dVar;
    }

    public androidx.lifecycle.q.b getDefaultViewModelProviderFactory() {
        return (androidx.lifecycle.q.b) this.defaultViewModelProviderFactory$delegate.getValue();
    }

    public p getFullyDrawnReporter() {
        return (p) this.fullyDrawnReporter$delegate.getValue();
    }

    public Object getLastCustomNonConfigurationInstance() {
        c cVar = (c) getLastNonConfigurationInstance();
        if (cVar != null) {
            return cVar.a();
        }
        return null;
    }

    @Override // ax.P.h, ax.G0.h
    public androidx.lifecycle.d getLifecycle() {
        return super.getLifecycle();
    }

    @Override // ax.p130i.u
    public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
        return (OnBackPressedDispatcher) this.onBackPressedDispatcher$delegate.getValue();
    }

    @Override // ax.p245p2.d
    public final androidx.savedstate.a getSavedStateRegistry() {
        return this.savedStateRegistryController.b();
    }

    @Override // ax.G0.v
    public androidx.lifecycle.r getViewModelStore() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        ensureViewModelStore();
        androidx.lifecycle.r rVar = this._viewModelStore;
        l.c(rVar);
        return rVar;
    }

    public void initializeViewTreeOwners() {
        View decorView = getWindow().getDecorView();
        l.e(decorView, "window.decorView");
        w.a(decorView, this);
        View decorView2 = getWindow().getDecorView();
        l.e(decorView2, "window.decorView");
        x.a(decorView2, this);
        View decorView3 = getWindow().getDecorView();
        l.e(decorView3, "window.decorView");
        ax.p245p2.e.a(decorView3, this);
        View decorView4 = getWindow().getDecorView();
        l.e(decorView4, "window.decorView");
        ax.p130i.x.a(decorView4, this);
        View decorView5 = getWindow().getDecorView();
        l.e(decorView5, "window.decorView");
        ax.p130i.w.a(decorView5, this);
    }

    public void invalidateMenu() {
        invalidateOptionsMenu();
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        if (this.activityResultRegistry.e(i2, i3, intent)) {
            return;
        }
        super.onActivityResult(i2, i3, intent);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        getOnBackPressedDispatcher().k();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        l.f(configuration, "newConfig");
        super.onConfigurationChanged(configuration);
        Iterator<ax.p019b0.a<Configuration>> it = this.onConfigurationChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(configuration);
        }
    }

    @Override // ax.P.h, android.app.Activity
    protected void onCreate(Bundle bundle) {
        this.savedStateRegistryController.d(bundle);
        this.contextAwareHelper.c(this);
        super.onCreate(bundle);
        k.X.c(this);
        int i2 = this.contentLayoutId;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int i2, Menu menu) {
        l.f(menu, "menu");
        if (i2 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i2, menu);
        this.menuHostHelper.f(menu, getMenuInflater());
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        l.f(menuItem, "item");
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            return this.menuHostHelper.h(menuItem);
        }
        return false;
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z) {
        if (this.dispatchingOnMultiWindowModeChanged) {
            return;
        }
        Iterator<ax.p019b0.a<ax.P.i>> it = this.onMultiWindowModeChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(new ax.P.i(z));
        }
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z, Configuration configuration) {
        l.f(configuration, "newConfig");
        this.dispatchingOnMultiWindowModeChanged = true;
        try {
            super.onMultiWindowModeChanged(z, configuration);
            this.dispatchingOnMultiWindowModeChanged = false;
            Iterator<ax.p019b0.a<ax.P.i>> it = this.onMultiWindowModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new ax.P.i(z, configuration));
            }
        } catch (Throwable th) {
            this.dispatchingOnMultiWindowModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        l.f(intent, "intent");
        super.onNewIntent(intent);
        Iterator<ax.p019b0.a<Intent>> it = this.onNewIntentListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i2, Menu menu) {
        l.f(menu, "menu");
        this.menuHostHelper.g(menu);
        super.onPanelClosed(i2, menu);
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z) {
        if (this.dispatchingOnPictureInPictureModeChanged) {
            return;
        }
        Iterator<ax.p019b0.a<t>> it = this.onPictureInPictureModeChangedListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(new t(z));
        }
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        l.f(configuration, "newConfig");
        this.dispatchingOnPictureInPictureModeChanged = true;
        try {
            super.onPictureInPictureModeChanged(z, configuration);
            this.dispatchingOnPictureInPictureModeChanged = false;
            Iterator<ax.p019b0.a<t>> it = this.onPictureInPictureModeChangedListeners.iterator();
            while (it.hasNext()) {
                it.next().accept(new t(z, configuration));
            }
        } catch (Throwable th) {
            this.dispatchingOnPictureInPictureModeChanged = false;
            throw th;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int i2, View view, Menu menu) {
        l.f(menu, "menu");
        if (i2 != 0) {
            return true;
        }
        super.onPreparePanel(i2, view, menu);
        this.menuHostHelper.i(menu);
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        l.f(strArr, "permissions");
        l.f(iArr, "grantResults");
        if (this.activityResultRegistry.e(i2, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) || Build.VERSION.SDK_INT < 23) {
            return;
        }
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    public Object onRetainCustomNonConfigurationInstance() {
        return null;
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        c cVar;
        Object objOnRetainCustomNonConfigurationInstance = onRetainCustomNonConfigurationInstance();
        androidx.lifecycle.r rVarB = this._viewModelStore;
        if (rVarB == null && (cVar = (c) getLastNonConfigurationInstance()) != null) {
            rVarB = cVar.b();
        }
        if (rVarB == null && objOnRetainCustomNonConfigurationInstance == null) {
            return null;
        }
        c cVar2 = new c();
        cVar2.c(objOnRetainCustomNonConfigurationInstance);
        cVar2.d(rVarB);
        return cVar2;
    }

    @Override // ax.P.h, android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        l.f(bundle, "outState");
        if (getLifecycle() instanceof androidx.lifecycle.g) {
            androidx.lifecycle.d lifecycle = getLifecycle();
            l.d(lifecycle, "null cannot be cast to non-null type androidx.lifecycle.LifecycleRegistry");
            ((androidx.lifecycle.g) lifecycle).m(androidx.lifecycle.d.b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.savedStateRegistryController.e(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        Iterator<ax.p019b0.a<Integer>> it = this.onTrimMemoryListeners.iterator();
        while (it.hasNext()) {
            it.next().accept(Integer.valueOf(i2));
        }
    }

    @Override // android.app.Activity
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Iterator<Runnable> it = this.onUserLeaveHintListeners.iterator();
        while (it.hasNext()) {
            it.next().run();
        }
    }

    public Context peekAvailableContext() {
        return this.contextAwareHelper.d();
    }

    public final <I, O> ax.p162k.c<I> registerForActivityResult(ax.p178l.a<I, O> aVar, ax.p162k.b<O> bVar) {
        l.f(aVar, "contract");
        l.f(bVar, "callback");
        return registerForActivityResult(aVar, this.activityResultRegistry, bVar);
    }

    public final <I, O> ax.p162k.c<I> registerForActivityResult(ax.p178l.a<I, O> aVar, ax.p162k.e eVar, ax.p162k.b<O> bVar) {
        l.f(aVar, "contract");
        l.f(eVar, "registry");
        l.f(bVar, "callback");
        return eVar.l("activity_rq#" + this.nextLocalRequestCode.getAndIncrement(), this, aVar, bVar);
    }

    @Override // ax.p035c0.InterfaceC1875w
    public void removeMenuProvider(B b2) {
        l.f(b2, "provider");
        this.menuHostHelper.j(b2);
    }

    @Override // ax.Q.e
    public final void removeOnConfigurationChangedListener(ax.p019b0.a<Configuration> aVar) {
        l.f(aVar, "listener");
        this.onConfigurationChangedListeners.remove(aVar);
    }

    public final void removeOnContextAvailableListener(ax.p146j.b bVar) {
        l.f(bVar, "listener");
        this.contextAwareHelper.e(bVar);
    }

    @Override // ax.P.q
    public final void removeOnMultiWindowModeChangedListener(ax.p019b0.a<ax.P.i> aVar) {
        l.f(aVar, "listener");
        this.onMultiWindowModeChangedListeners.remove(aVar);
    }

    public final void removeOnNewIntentListener(ax.p019b0.a<Intent> aVar) {
        l.f(aVar, "listener");
        this.onNewIntentListeners.remove(aVar);
    }

    @Override // ax.P.r
    public final void removeOnPictureInPictureModeChangedListener(ax.p019b0.a<t> aVar) {
        l.f(aVar, "listener");
        this.onPictureInPictureModeChangedListeners.remove(aVar);
    }

    @Override // ax.Q.f
    public final void removeOnTrimMemoryListener(ax.p019b0.a<Integer> aVar) {
        l.f(aVar, "listener");
        this.onTrimMemoryListeners.remove(aVar);
    }

    public final void removeOnUserLeaveHintListener(Runnable runnable) {
        l.f(runnable, "listener");
        this.onUserLeaveHintListeners.remove(runnable);
    }

    @Override // android.app.Activity
    public void reportFullyDrawn() {
        try {
            if (ax.p357w2.b.d()) {
                ax.p357w2.b.a("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            getFullyDrawnReporter().b();
        } finally {
            ax.p357w2.b.b();
        }
    }

    @Override // android.app.Activity
    public void setContentView(int i2) {
        initializeViewTreeOwners();
        d dVar = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        l.e(decorView, "window.decorView");
        dVar.N(decorView);
        super.setContentView(i2);
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        initializeViewTreeOwners();
        d dVar = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        l.e(decorView, "window.decorView");
        dVar.N(decorView);
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        initializeViewTreeOwners();
        d dVar = this.reportFullyDrawnExecutor;
        View decorView = getWindow().getDecorView();
        l.e(decorView, "window.decorView");
        dVar.N(decorView);
        super.setContentView(view, layoutParams);
    }

    @Override // android.app.Activity
    public void startActivityForResult(Intent intent, int i2) {
        l.f(intent, "intent");
        super.startActivityForResult(intent, i2);
    }

    @Override // android.app.Activity
    public void startActivityForResult(Intent intent, int i2, Bundle bundle) {
        l.f(intent, "intent");
        super.startActivityForResult(intent, i2, bundle);
    }

    @Override // android.app.Activity
    public void startIntentSenderForResult(IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5) throws IntentSender.SendIntentException {
        l.f(intentSender, "intent");
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
    }

    @Override // android.app.Activity
    public void startIntentSenderForResult(IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        l.f(intentSender, "intent");
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
    }
}
