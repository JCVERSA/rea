package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.f;
import ax.F0.g;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public abstract class ActivityResultRegistry {
    private final Map<Integer, String> a = new HashMap();
    final Map<String, Integer> b = new HashMap();
    private final Map<String, d> c = new HashMap();
    ArrayList<String> d = new ArrayList<>();
    final transient Map<String, c<?>> e = new HashMap();
    final Map<String, Object> f = new HashMap();
    final Bundle g = new Bundle();

    /* JADX INFO: Add missing generic type declarations: [I] */
    class a<I> extends ax.p140k.c<I> {
        final /* synthetic */ String a;
        final /* synthetic */ ax.p154l.a b;

        a(String str, ax.p154l.a aVar) {
            this.a = str;
            this.b = aVar;
        }

        @Override // ax.p140k.c
        public void b(I i, ax.O.c cVar) throws Exception {
            Integer num = ActivityResultRegistry.this.b.get(this.a);
            if (num != null) {
                ActivityResultRegistry.this.d.add(this.a);
                try {
                    ActivityResultRegistry.this.f(num.intValue(), this.b, i, cVar);
                    return;
                } catch (Exception e) {
                    ActivityResultRegistry.this.d.remove(this.a);
                    throw e;
                }
            }
            throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + this.b + " and input " + i + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }

        @Override // ax.p140k.c
        public void c() {
            ActivityResultRegistry.this.l(this.a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [I] */
    class b<I> extends ax.p140k.c<I> {
        final /* synthetic */ String a;
        final /* synthetic */ ax.p154l.a b;

        b(String str, ax.p154l.a aVar) {
            this.a = str;
            this.b = aVar;
        }

        @Override // ax.p140k.c
        public void b(I i, ax.O.c cVar) throws Exception {
            Integer num = ActivityResultRegistry.this.b.get(this.a);
            if (num != null) {
                ActivityResultRegistry.this.d.add(this.a);
                try {
                    ActivityResultRegistry.this.f(num.intValue(), this.b, i, cVar);
                    return;
                } catch (Exception e) {
                    ActivityResultRegistry.this.d.remove(this.a);
                    throw e;
                }
            }
            throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + this.b + " and input " + i + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }

        @Override // ax.p140k.c
        public void c() {
            ActivityResultRegistry.this.l(this.a);
        }
    }

    private static class c<O> {
        final ax.p140k.b<O> a;
        final ax.p154l.a<?, O> b;

        c(ax.p140k.b<O> bVar, ax.p154l.a<?, O> aVar) {
            this.a = bVar;
            this.b = aVar;
        }
    }

    private static class d {
        final androidx.lifecycle.d a;
        private final ArrayList<f> b = new ArrayList<>();

        d(androidx.lifecycle.d dVar) {
            this.a = dVar;
        }

        void a(f fVar) {
            this.a.a(fVar);
            this.b.add(fVar);
        }

        void b() {
            Iterator<f> it = this.b.iterator();
            while (it.hasNext()) {
                this.a.c(it.next());
            }
            this.b.clear();
        }
    }

    private void a(int i, String str) {
        this.a.put(Integer.valueOf(i), str);
        this.b.put(str, Integer.valueOf(i));
    }

    private <O> void d(String str, int i, Intent intent, c<O> cVar) {
        if (cVar == null || cVar.a == null || !this.d.contains(str)) {
            this.f.remove(str);
            this.g.putParcelable(str, new ax.p140k.a(i, intent));
        } else {
            cVar.a.a(cVar.b.c(i, intent));
            this.d.remove(str);
        }
    }

    private int e() {
        int iC = ax.p180mb.c.q.c(2147418112);
        while (true) {
            int i = iC + 65536;
            if (!this.a.containsKey(Integer.valueOf(i))) {
                return i;
            }
            iC = ax.p180mb.c.q.c(2147418112);
        }
    }

    private void k(String str) {
        if (this.b.get(str) != null) {
            return;
        }
        a(e(), str);
    }

    public final boolean b(int i, int i2, Intent intent) {
        String str = this.a.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        d(str, i2, intent, this.e.get(str));
        return true;
    }

    public final <O> boolean c(int i, @SuppressLint({"UnknownNullness"}) O o) {
        ax.p140k.b<?> bVar;
        String str = this.a.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        c<?> cVar = this.e.get(str);
        if (cVar == null || (bVar = cVar.a) == null) {
            this.g.remove(str);
            this.f.put(str, o);
            return true;
        }
        if (!this.d.remove(str)) {
            return true;
        }
        bVar.a(o);
        return true;
    }

    public abstract <I, O> void f(int i, ax.p154l.a<I, O> aVar, @SuppressLint({"UnknownNullness"}) I i2, ax.O.c cVar);

    public final void g(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null || integerArrayList == null) {
            return;
        }
        this.d = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        this.g.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
        for (int i = 0; i < stringArrayList.size(); i++) {
            String str = stringArrayList.get(i);
            if (this.b.containsKey(str)) {
                Integer numRemove = this.b.remove(str);
                if (!this.g.containsKey(str)) {
                    this.a.remove(numRemove);
                }
            }
            a(integerArrayList.get(i).intValue(), stringArrayList.get(i));
        }
    }

    public final void h(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(this.b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(this.b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(this.d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.g.clone());
    }

    public final <I, O> ax.p140k.c<I> i(final String str, g gVar, final ax.p154l.a<I, O> aVar, final ax.p140k.b<O> bVar) {
        androidx.lifecycle.d dVarF = gVar.f();
        if (dVarF.b().h(androidx.lifecycle.d.b.STARTED)) {
            throw new IllegalStateException("LifecycleOwner " + gVar + " is attempting to register while current state is " + dVarF.b() + ". LifecycleOwners must call register before they are STARTED.");
        }
        k(str);
        d dVar = this.c.get(str);
        if (dVar == null) {
            dVar = new d(dVarF);
        }
        dVar.a(new f() { // from class: androidx.activity.result.ActivityResultRegistry.1
            @Override // androidx.lifecycle.f
            public void d(g gVar2, androidx.lifecycle.d.a aVar2) {
                if (!androidx.lifecycle.d.a.ON_START.equals(aVar2)) {
                    if (androidx.lifecycle.d.a.ON_STOP.equals(aVar2)) {
                        ActivityResultRegistry.this.e.remove(str);
                        return;
                    } else {
                        if (androidx.lifecycle.d.a.ON_DESTROY.equals(aVar2)) {
                            ActivityResultRegistry.this.l(str);
                            return;
                        }
                        return;
                    }
                }
                ActivityResultRegistry.this.e.put(str, new c<>(bVar, aVar));
                if (ActivityResultRegistry.this.f.containsKey(str)) {
                    Object obj = ActivityResultRegistry.this.f.get(str);
                    ActivityResultRegistry.this.f.remove(str);
                    bVar.a(obj);
                }
                ax.p140k.a aVar3 = (ax.p140k.a) ActivityResultRegistry.this.g.getParcelable(str);
                if (aVar3 != null) {
                    ActivityResultRegistry.this.g.remove(str);
                    bVar.a(aVar.c(aVar3.b(), aVar3.a()));
                }
            }
        });
        this.c.put(str, dVar);
        return new a(str, aVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final <I, O> ax.p140k.c<I> j(String str, ax.p154l.a<I, O> aVar, ax.p140k.b<O> bVar) {
        k(str);
        this.e.put(str, new c<>(bVar, aVar));
        if (this.f.containsKey(str)) {
            Object obj = this.f.get(str);
            this.f.remove(str);
            bVar.a(obj);
        }
        ax.p140k.a aVar2 = (ax.p140k.a) this.g.getParcelable(str);
        if (aVar2 != null) {
            this.g.remove(str);
            bVar.a(aVar.c(aVar2.b(), aVar2.a()));
        }
        return new b(str, aVar);
    }

    final void l(String str) {
        Integer numRemove;
        if (!this.d.contains(str) && (numRemove = this.b.remove(str)) != null) {
            this.a.remove(numRemove);
        }
        this.e.remove(str);
        if (this.f.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f.get(str));
            this.f.remove(str);
        }
        if (this.g.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.g.getParcelable(str));
            this.g.remove(str);
        }
        d dVar = this.c.get(str);
        if (dVar != null) {
            dVar.b();
            this.c.remove(str);
        }
    }
}
