package androidx.activity;

import android.os.Build;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.OnBackPressedDispatcher;
import ax.p111gc.t;
import ax.p127hc.C2086h;
import ax.p130i.r;
import ax.p130i.s;
import ax.p335uc.l;
import ax.p335uc.m;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class OnBackPressedDispatcher {
    private final Runnable a;
    private final ax.p019b0.a<Boolean> b;
    private final C2086h<r> c;
    private r d;
    private OnBackInvokedCallback e;
    private OnBackInvokedDispatcher f;
    private boolean g;
    private boolean h;

    private final class LifecycleOnBackPressedCancellable implements androidx.lifecycle.f, ax.p130i.c {
        private final r X;
        private ax.p130i.c Y;
        final /* synthetic */ OnBackPressedDispatcher Z;
        private final androidx.lifecycle.d q;

        public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher onBackPressedDispatcher, androidx.lifecycle.d dVar, r rVar) {
            l.f(dVar, "lifecycle");
            l.f(rVar, "onBackPressedCallback");
            this.Z = onBackPressedDispatcher;
            this.q = dVar;
            this.X = rVar;
            dVar.a(this);
        }

        @Override // androidx.lifecycle.f
        public void b(ax.G0.h hVar, androidx.lifecycle.d.a aVar) {
            l.f(hVar, "source");
            l.f(aVar, "event");
            if (aVar == androidx.lifecycle.d.a.ON_START) {
                this.Y = this.Z.i(this.X);
                return;
            }
            if (aVar != androidx.lifecycle.d.a.ON_STOP) {
                if (aVar == androidx.lifecycle.d.a.ON_DESTROY) {
                    cancel();
                }
            } else {
                ax.p130i.c cVar = this.Y;
                if (cVar != null) {
                    cVar.cancel();
                }
            }
        }

        @Override // ax.p130i.c
        public void cancel() {
            this.q.c(this);
            this.X.i(this);
            ax.p130i.c cVar = this.Y;
            if (cVar != null) {
                cVar.cancel();
            }
            this.Y = null;
        }
    }

    static final class a extends m implements ax.p319tc.l<ax.p130i.b, t> {
        a() {
            super(1);
        }

        public final void a(ax.p130i.b bVar) {
            l.f(bVar, "backEvent");
            OnBackPressedDispatcher.this.m(bVar);
        }

        @Override // ax.p319tc.l
        public /* bridge */ /* synthetic */ t invoke(ax.p130i.b bVar) {
            a(bVar);
            return t.a;
        }
    }

    static final class b extends m implements ax.p319tc.l<ax.p130i.b, t> {
        b() {
            super(1);
        }

        public final void a(ax.p130i.b bVar) {
            l.f(bVar, "backEvent");
            OnBackPressedDispatcher.this.l(bVar);
        }

        @Override // ax.p319tc.l
        public /* bridge */ /* synthetic */ t invoke(ax.p130i.b bVar) {
            a(bVar);
            return t.a;
        }
    }

    static final class c extends m implements ax.p319tc.a<t> {
        c() {
            super(0);
        }

        public final void a() {
            OnBackPressedDispatcher.this.k();
        }

        @Override // ax.p319tc.a
        public /* bridge */ /* synthetic */ t invoke() {
            a();
            return t.a;
        }
    }

    static final class d extends m implements ax.p319tc.a<t> {
        d() {
            super(0);
        }

        public final void a() {
            OnBackPressedDispatcher.this.j();
        }

        @Override // ax.p319tc.a
        public /* bridge */ /* synthetic */ t invoke() {
            a();
            return t.a;
        }
    }

    static final class e extends m implements ax.p319tc.a<t> {
        e() {
            super(0);
        }

        public final void a() {
            OnBackPressedDispatcher.this.k();
        }

        @Override // ax.p319tc.a
        public /* bridge */ /* synthetic */ t invoke() {
            a();
            return t.a;
        }
    }

    public static final class f {
        public static final f a = new f();

        private f() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(ax.p319tc.a aVar) {
            l.f(aVar, "$onBackInvoked");
            aVar.invoke();
        }

        public final OnBackInvokedCallback b(final ax.p319tc.a<t> aVar) {
            l.f(aVar, "onBackInvoked");
            return new OnBackInvokedCallback() { // from class: ax.i.t
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    OnBackPressedDispatcher.f.c(aVar);
                }
            };
        }

        public final void d(Object obj, int i, Object obj2) {
            l.f(obj, "dispatcher");
            l.f(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i, (OnBackInvokedCallback) obj2);
        }

        public final void e(Object obj, Object obj2) {
            l.f(obj, "dispatcher");
            l.f(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    public static final class g {
        public static final g a = new g();

        public static final class a implements OnBackAnimationCallback {
            final /* synthetic */ ax.p319tc.l<ax.p130i.b, t> a;
            final /* synthetic */ ax.p319tc.l<ax.p130i.b, t> b;
            final /* synthetic */ ax.p319tc.a<t> c;
            final /* synthetic */ ax.p319tc.a<t> d;

            /* JADX WARN: Multi-variable type inference failed */
            a(ax.p319tc.l<? super ax.p130i.b, t> lVar, ax.p319tc.l<? super ax.p130i.b, t> lVar2, ax.p319tc.a<t> aVar, ax.p319tc.a<t> aVar2) {
                this.a = lVar;
                this.b = lVar2;
                this.c = aVar;
                this.d = aVar2;
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackCancelled() {
                this.d.invoke();
            }

            @Override // android.window.OnBackInvokedCallback
            public void onBackInvoked() {
                this.c.invoke();
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackProgressed(BackEvent backEvent) {
                l.f(backEvent, "backEvent");
                this.b.invoke(new ax.p130i.b(backEvent));
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackStarted(BackEvent backEvent) {
                l.f(backEvent, "backEvent");
                this.a.invoke(new ax.p130i.b(backEvent));
            }
        }

        private g() {
        }

        public final OnBackInvokedCallback a(ax.p319tc.l<? super ax.p130i.b, t> lVar, ax.p319tc.l<? super ax.p130i.b, t> lVar2, ax.p319tc.a<t> aVar, ax.p319tc.a<t> aVar2) {
            l.f(lVar, "onBackStarted");
            l.f(lVar2, "onBackProgressed");
            l.f(aVar, "onBackInvoked");
            l.f(aVar2, "onBackCancelled");
            return new a(lVar, lVar2, aVar, aVar2);
        }
    }

    private final class h implements ax.p130i.c {
        final /* synthetic */ OnBackPressedDispatcher X;
        private final r q;

        public h(OnBackPressedDispatcher onBackPressedDispatcher, r rVar) {
            l.f(rVar, "onBackPressedCallback");
            this.X = onBackPressedDispatcher;
            this.q = rVar;
        }

        @Override // ax.p130i.c
        public void cancel() {
            this.X.c.remove(this.q);
            if (l.a(this.X.d, this.q)) {
                this.q.c();
                this.X.d = null;
            }
            this.q.i(this);
            ax.p319tc.a<t> aVarB = this.q.b();
            if (aVarB != null) {
                aVarB.invoke();
            }
            this.q.k(null);
        }
    }

    /* synthetic */ class i extends ax.p335uc.j implements ax.p319tc.a<t> {
        i(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        @Override // ax.p319tc.a
        public /* bridge */ /* synthetic */ t invoke() {
            k();
            return t.a;
        }

        public final void k() {
            ((OnBackPressedDispatcher) this.X).p();
        }
    }

    /* synthetic */ class j extends ax.p335uc.j implements ax.p319tc.a<t> {
        j(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        @Override // ax.p319tc.a
        public /* bridge */ /* synthetic */ t invoke() {
            k();
            return t.a;
        }

        public final void k() {
            ((OnBackPressedDispatcher) this.X).p();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OnBackPressedDispatcher() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this(runnable, null);
    }

    public /* synthetic */ OnBackPressedDispatcher(Runnable runnable, int i2, ax.p335uc.g gVar) {
        this((i2 & 1) != 0 ? null : runnable);
    }

    public OnBackPressedDispatcher(Runnable runnable, ax.p019b0.a<Boolean> aVar) {
        this.a = runnable;
        this.b = aVar;
        this.c = new C2086h<>();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33) {
            this.e = i2 >= 34 ? g.a.a(new a(), new b(), new c(), new d()) : f.a.b(new e());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void j() {
        r rVarPrevious;
        r rVar = this.d;
        if (rVar == null) {
            C2086h<r> c2086h = this.c;
            ListIterator<r> listIterator = c2086h.listIterator(c2086h.size());
            do {
                if (!listIterator.hasPrevious()) {
                    rVarPrevious = null;
                    break;
                }
                rVarPrevious = listIterator.previous();
            } while (!rVarPrevious.g());
            rVar = rVarPrevious;
        }
        this.d = null;
        if (rVar != null) {
            rVar.c();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void l(ax.p130i.b bVar) {
        r rVarPrevious;
        r rVar = this.d;
        if (rVar == null) {
            C2086h<r> c2086h = this.c;
            ListIterator<r> listIterator = c2086h.listIterator(c2086h.size());
            do {
                if (!listIterator.hasPrevious()) {
                    rVarPrevious = null;
                    break;
                }
                rVarPrevious = listIterator.previous();
            } while (!rVarPrevious.g());
            rVar = rVarPrevious;
        }
        if (rVar != null) {
            rVar.e(bVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void m(ax.p130i.b bVar) {
        r rVarPrevious;
        C2086h<r> c2086h = this.c;
        ListIterator<r> listIterator = c2086h.listIterator(c2086h.size());
        do {
            if (!listIterator.hasPrevious()) {
                rVarPrevious = null;
                break;
            }
            rVarPrevious = listIterator.previous();
        } while (!rVarPrevious.g());
        r rVar = rVarPrevious;
        if (this.d != null) {
            j();
        }
        this.d = rVar;
        if (rVar != null) {
            rVar.f(bVar);
        }
    }

    private final void o(boolean z) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f;
        OnBackInvokedCallback onBackInvokedCallback = this.e;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        if (z && !this.g) {
            f.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.g = true;
        } else {
            if (z || !this.g) {
                return;
            }
            f.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
            this.g = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void p() {
        boolean z = this.h;
        C2086h<r> c2086h = this.c;
        boolean z2 = false;
        if (!s.a(c2086h) || !c2086h.isEmpty()) {
            Iterator<r> it = c2086h.iterator();
            while (it.hasNext()) {
                if (it.next().g()) {
                    z2 = true;
                    break;
                }
            }
        }
        this.h = z2;
        if (z2 != z) {
            ax.p019b0.a<Boolean> aVar = this.b;
            if (aVar != null) {
                aVar.accept(Boolean.valueOf(z2));
            }
            if (Build.VERSION.SDK_INT >= 33) {
                o(z2);
            }
        }
    }

    public final void h(ax.G0.h hVar, r rVar) {
        l.f(hVar, "owner");
        l.f(rVar, "onBackPressedCallback");
        androidx.lifecycle.d lifecycle = hVar.getLifecycle();
        if (lifecycle.b() == androidx.lifecycle.d.b.DESTROYED) {
            return;
        }
        rVar.a(new LifecycleOnBackPressedCancellable(this, lifecycle, rVar));
        p();
        rVar.k(new i(this));
    }

    public final ax.p130i.c i(r rVar) {
        l.f(rVar, "onBackPressedCallback");
        this.c.add(rVar);
        h hVar = new h(this, rVar);
        rVar.a(hVar);
        p();
        rVar.k(new j(this));
        return hVar;
    }

    public final void k() {
        r rVarPrevious;
        r rVar = this.d;
        if (rVar == null) {
            C2086h<r> c2086h = this.c;
            ListIterator<r> listIterator = c2086h.listIterator(c2086h.size());
            do {
                if (!listIterator.hasPrevious()) {
                    rVarPrevious = null;
                    break;
                }
                rVarPrevious = listIterator.previous();
            } while (!rVarPrevious.g());
            rVar = rVarPrevious;
        }
        this.d = null;
        if (rVar != null) {
            rVar.d();
            return;
        }
        Runnable runnable = this.a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void n(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        l.f(onBackInvokedDispatcher, "invoker");
        this.f = onBackInvokedDispatcher;
        o(this.h);
    }
}
