package androidx.activity;

import android.os.Build;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.OnBackPressedDispatcher;
import ax.Wa.t;
import ax.Xa.C5074e;
import ax.p112i.n;
import ax.p138jb.l;
import ax.p138jb.m;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class OnBackPressedDispatcher {
    private final Runnable a;
    private final ax.p001a0.a<Boolean> b;
    private final C5074e<n> c;
    private n d;
    private OnBackInvokedCallback e;
    private OnBackInvokedDispatcher f;
    private boolean g;
    private boolean h;

    private final class LifecycleOnBackPressedCancellable implements androidx.lifecycle.f, ax.p112i.c {
        private final n X;
        private ax.p112i.c Y;
        final /* synthetic */ OnBackPressedDispatcher Z;
        private final androidx.lifecycle.d q;

        public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher onBackPressedDispatcher, androidx.lifecycle.d dVar, n nVar) {
            l.f(dVar, "lifecycle");
            l.f(nVar, "onBackPressedCallback");
            this.Z = onBackPressedDispatcher;
            this.q = dVar;
            this.X = nVar;
            dVar.a(this);
        }

        @Override // ax.p112i.c
        public void cancel() {
            this.q.c(this);
            this.X.i(this);
            ax.p112i.c cVar = this.Y;
            if (cVar != null) {
                cVar.cancel();
            }
            this.Y = null;
        }

        @Override // androidx.lifecycle.f
        public void d(ax.F0.g gVar, androidx.lifecycle.d.a aVar) {
            l.f(gVar, "source");
            l.f(aVar, "event");
            if (aVar == androidx.lifecycle.d.a.ON_START) {
                this.Y = this.Z.i(this.X);
                return;
            }
            if (aVar != androidx.lifecycle.d.a.ON_STOP) {
                if (aVar == androidx.lifecycle.d.a.ON_DESTROY) {
                    cancel();
                }
            } else {
                ax.p112i.c cVar = this.Y;
                if (cVar != null) {
                    cVar.cancel();
                }
            }
        }
    }

    static final class a extends m implements ax.p124ib.l<ax.p112i.b, t> {
        a() {
            super(1);
        }

        public final void b(ax.p112i.b bVar) {
            l.f(bVar, "backEvent");
            OnBackPressedDispatcher.this.m(bVar);
        }

        @Override // ax.p124ib.l
        public /* bridge */ /* synthetic */ t invoke(ax.p112i.b bVar) {
            b(bVar);
            return t.a;
        }
    }

    static final class b extends m implements ax.p124ib.l<ax.p112i.b, t> {
        b() {
            super(1);
        }

        public final void b(ax.p112i.b bVar) {
            l.f(bVar, "backEvent");
            OnBackPressedDispatcher.this.l(bVar);
        }

        @Override // ax.p124ib.l
        public /* bridge */ /* synthetic */ t invoke(ax.p112i.b bVar) {
            b(bVar);
            return t.a;
        }
    }

    static final class c extends m implements ax.p124ib.a<t> {
        c() {
            super(0);
        }

        public final void b() {
            OnBackPressedDispatcher.this.k();
        }

        @Override // ax.p124ib.a
        public /* bridge */ /* synthetic */ t invoke() {
            b();
            return t.a;
        }
    }

    static final class d extends m implements ax.p124ib.a<t> {
        d() {
            super(0);
        }

        public final void b() {
            OnBackPressedDispatcher.this.j();
        }

        @Override // ax.p124ib.a
        public /* bridge */ /* synthetic */ t invoke() {
            b();
            return t.a;
        }
    }

    static final class e extends m implements ax.p124ib.a<t> {
        e() {
            super(0);
        }

        public final void b() {
            OnBackPressedDispatcher.this.k();
        }

        @Override // ax.p124ib.a
        public /* bridge */ /* synthetic */ t invoke() {
            b();
            return t.a;
        }
    }

    public static final class f {
        public static final f a = new f();

        private f() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(ax.p124ib.a aVar) {
            l.f(aVar, "$onBackInvoked");
            aVar.invoke();
        }

        public final OnBackInvokedCallback b(final ax.p124ib.a<t> aVar) {
            l.f(aVar, "onBackInvoked");
            return new OnBackInvokedCallback() { // from class: ax.i.o
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    OnBackPressedDispatcher.f.c(aVar);
                }
            };
        }

        public final void d(Object obj, int i, Object obj2) {
            l.f(obj, "dispatcher");
            l.f(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i, (OnBackInvokedCallback) obj2);
        }

        public final void e(Object obj, Object obj2) {
            l.f(obj, "dispatcher");
            l.f(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    public static final class g {
        public static final g a = new g();

        public static final class a implements OnBackAnimationCallback {
            final /* synthetic */ ax.p124ib.l<ax.p112i.b, t> a;
            final /* synthetic */ ax.p124ib.l<ax.p112i.b, t> b;
            final /* synthetic */ ax.p124ib.a<t> c;
            final /* synthetic */ ax.p124ib.a<t> d;

            /* JADX WARN: Multi-variable type inference failed */
            a(ax.p124ib.l<? super ax.p112i.b, t> lVar, ax.p124ib.l<? super ax.p112i.b, t> lVar2, ax.p124ib.a<t> aVar, ax.p124ib.a<t> aVar2) {
                this.a = lVar;
                this.b = lVar2;
                this.c = aVar;
                this.d = aVar2;
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackCancelled() {
                this.d.invoke();
            }

            @Override // android.window.OnBackInvokedCallback
            public void onBackInvoked() {
                this.c.invoke();
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackProgressed(BackEvent backEvent) {
                l.f(backEvent, "backEvent");
                this.b.invoke(new ax.p112i.b(backEvent));
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackStarted(BackEvent backEvent) {
                l.f(backEvent, "backEvent");
                this.a.invoke(new ax.p112i.b(backEvent));
            }
        }

        private g() {
        }

        public final OnBackInvokedCallback a(ax.p124ib.l<? super ax.p112i.b, t> lVar, ax.p124ib.l<? super ax.p112i.b, t> lVar2, ax.p124ib.a<t> aVar, ax.p124ib.a<t> aVar2) {
            l.f(lVar, "onBackStarted");
            l.f(lVar2, "onBackProgressed");
            l.f(aVar, "onBackInvoked");
            l.f(aVar2, "onBackCancelled");
            return new a(lVar, lVar2, aVar, aVar2);
        }
    }

    private final class h implements ax.p112i.c {
        final /* synthetic */ OnBackPressedDispatcher X;
        private final n q;

        public h(OnBackPressedDispatcher onBackPressedDispatcher, n nVar) {
            l.f(nVar, "onBackPressedCallback");
            this.X = onBackPressedDispatcher;
            this.q = nVar;
        }

        @Override // ax.p112i.c
        public void cancel() {
            this.X.c.remove(this.q);
            if (l.a(this.X.d, this.q)) {
                this.q.c();
                this.X.d = null;
            }
            this.q.i(this);
            ax.p124ib.a<t> aVarB = this.q.b();
            if (aVarB != null) {
                aVarB.invoke();
            }
            this.q.k(null);
        }
    }

    /* synthetic */ class i extends ax.p138jb.j implements ax.p124ib.a<t> {
        i(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        @Override // ax.p124ib.a
        public /* bridge */ /* synthetic */ t invoke() {
            l();
            return t.a;
        }

        public final void l() {
            ((OnBackPressedDispatcher) this.X).p();
        }
    }

    /* synthetic */ class j extends ax.p138jb.j implements ax.p124ib.a<t> {
        j(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        @Override // ax.p124ib.a
        public /* bridge */ /* synthetic */ t invoke() {
            l();
            return t.a;
        }

        public final void l() {
            ((OnBackPressedDispatcher) this.X).p();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OnBackPressedDispatcher() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void j() {
        n nVarPrevious;
        C5074e<n> c5074e = this.c;
        ListIterator<n> listIterator = c5074e.listIterator(c5074e.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.d = null;
        if (nVar != null) {
            nVar.c();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void l(ax.p112i.b bVar) {
        n nVarPrevious;
        C5074e<n> c5074e = this.c;
        ListIterator<n> listIterator = c5074e.listIterator(c5074e.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        if (nVar != null) {
            nVar.e(bVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void m(ax.p112i.b bVar) {
        n nVarPrevious;
        C5074e<n> c5074e = this.c;
        ListIterator<n> listIterator = c5074e.listIterator(c5074e.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.d = nVar;
        if (nVar != null) {
            nVar.f(bVar);
        }
    }

    private final void o(boolean z) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f;
        OnBackInvokedCallback onBackInvokedCallback = this.e;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        if (z && !this.g) {
            f.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.g = true;
        } else {
            if (z || !this.g) {
                return;
            }
            f.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
            this.g = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void p() {
        boolean z = this.h;
        C5074e<n> c5074e = this.c;
        boolean z2 = false;
        if (!(c5074e instanceof Collection) || !c5074e.isEmpty()) {
            Iterator<n> it = c5074e.iterator();
            while (it.hasNext()) {
                if (it.next().g()) {
                    z2 = true;
                    break;
                }
            }
        }
        this.h = z2;
        if (z2 != z) {
            ax.p001a0.a<Boolean> aVar = this.b;
            if (aVar != null) {
                aVar.a(Boolean.valueOf(z2));
            }
            if (Build.VERSION.SDK_INT >= 33) {
                o(z2);
            }
        }
    }

    public final void h(ax.F0.g gVar, n nVar) {
        l.f(gVar, "owner");
        l.f(nVar, "onBackPressedCallback");
        androidx.lifecycle.d dVarF = gVar.f();
        if (dVarF.b() == androidx.lifecycle.d.b.DESTROYED) {
            return;
        }
        nVar.a(new LifecycleOnBackPressedCancellable(this, dVarF, nVar));
        p();
        nVar.k(new i(this));
    }

    public final ax.p112i.c i(n nVar) {
        l.f(nVar, "onBackPressedCallback");
        this.c.add(nVar);
        h hVar = new h(this, nVar);
        nVar.a(hVar);
        p();
        nVar.k(new j(this));
        return hVar;
    }

    public final void k() {
        n nVarPrevious;
        C5074e<n> c5074e = this.c;
        ListIterator<n> listIterator = c5074e.listIterator(c5074e.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.d = null;
        if (nVar != null) {
            nVar.d();
            return;
        }
        Runnable runnable = this.a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void n(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        l.f(onBackInvokedDispatcher, "invoker");
        this.f = onBackInvokedDispatcher;
        o(this.h);
    }

    public OnBackPressedDispatcher(Runnable runnable, ax.p001a0.a<Boolean> aVar) {
        this.a = runnable;
        this.b = aVar;
        this.c = new C5074e<>();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33) {
            this.e = i2 >= 34 ? g.a.a(new a(), new b(), new c(), new d()) : f.a.b(new e());
        }
    }

    public /* synthetic */ OnBackPressedDispatcher(Runnable runnable, int i2, ax.p138jb.g gVar) {
        this((i2 & 1) != 0 ? null : runnable);
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this(runnable, null);
    }
}
