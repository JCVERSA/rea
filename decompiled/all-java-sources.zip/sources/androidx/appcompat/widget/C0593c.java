package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import ax.p035c0.AbstractC1834b;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.appcompat.widget.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0593c extends androidx.appcompat.view.menu.a implements AbstractC1834b.a {
    private boolean A0;
    private boolean B0;
    private int C0;
    private final SparseBooleanArray D0;
    e E0;
    a F0;
    RunnableC0012c G0;
    private b H0;
    final f I0;
    int J0;
    d q0;
    private Drawable r0;
    private boolean s0;
    private boolean t0;
    private boolean u0;
    private int v0;
    private int w0;
    private int x0;
    private boolean y0;
    private boolean z0;

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$a */
    private class a extends androidx.appcompat.view.menu.i {
        public a(Context context, androidx.appcompat.view.menu.m mVar, View view) {
            super(context, mVar, view, false, ax.p194m.a.l);
            if (!((androidx.appcompat.view.menu.g) mVar.getItem()).l()) {
                View view2 = C0593c.this.q0;
                f(view2 == null ? (View) ((androidx.appcompat.view.menu.a) C0593c.this).o0 : view2);
            }
            j(C0593c.this.I0);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            C0593c c0593c = C0593c.this;
            c0593c.F0 = null;
            c0593c.J0 = 0;
            super.e();
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$b */
    private class b extends ActionMenuItemView.b {
        b() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.b
        public ax.p306t.e a() {
            a aVar = C0593c.this.F0;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$c, reason: collision with other inner class name */
    private class RunnableC0012c implements Runnable {
        private e q;

        public RunnableC0012c(e eVar) {
            this.q = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((androidx.appcompat.view.menu.a) C0593c.this).Y != null) {
                ((androidx.appcompat.view.menu.a) C0593c.this).Y.d();
            }
            View view = (View) ((androidx.appcompat.view.menu.a) C0593c.this).o0;
            if (view != null && view.getWindowToken() != null && this.q.n()) {
                C0593c.this.E0 = this.q;
            }
            C0593c.this.G0 = null;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$d */
    private class d extends AppCompatImageView implements ActionMenuView.a {

        /* JADX INFO: renamed from: androidx.appcompat.widget.c$d$a */
        class a extends ax.p322u.s {
            final /* synthetic */ C0593c p0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(View view, C0593c c0593c) {
                super(view);
                this.p0 = c0593c;
            }

            @Override // ax.p322u.s
            public ax.p306t.e b() {
                e eVar = C0593c.this.E0;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            @Override // ax.p322u.s
            public boolean c() {
                C0593c.this.K();
                return true;
            }

            @Override // ax.p322u.s
            public boolean d() {
                C0593c c0593c = C0593c.this;
                if (c0593c.G0 != null) {
                    return false;
                }
                c0593c.B();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, ax.p194m.a.k);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            ax.p322u.B.a(this, getContentDescription());
            setOnTouchListener(new a(this, C0593c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0593c.this.K();
            return true;
        }

        @Override // android.widget.ImageView
        protected boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int iMax = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                ax.U.a.l(background, paddingLeft - iMax, paddingTop - iMax, paddingLeft + iMax, paddingTop + iMax);
            }
            return frame;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$e */
    private class e extends androidx.appcompat.view.menu.i {
        public e(Context context, androidx.appcompat.view.menu.e eVar, View view, boolean z) {
            super(context, eVar, view, z, ax.p194m.a.l);
            h(8388613);
            j(C0593c.this.I0);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            if (((androidx.appcompat.view.menu.a) C0593c.this).Y != null) {
                ((androidx.appcompat.view.menu.a) C0593c.this).Y.close();
            }
            C0593c.this.E0 = null;
            super.e();
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$f */
    private class f implements androidx.appcompat.view.menu.j.a {
        f() {
        }

        @Override // androidx.appcompat.view.menu.j.a
        public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
            if (eVar instanceof androidx.appcompat.view.menu.m) {
                eVar.D().e(false);
            }
            androidx.appcompat.view.menu.j.a aVarM = C0593c.this.m();
            if (aVarM != null) {
                aVarM.a(eVar, z);
            }
        }

        @Override // androidx.appcompat.view.menu.j.a
        public boolean b(androidx.appcompat.view.menu.e eVar) {
            if (eVar == ((androidx.appcompat.view.menu.a) C0593c.this).Y) {
                return false;
            }
            C0593c.this.J0 = ((androidx.appcompat.view.menu.m) eVar).getItem().getItemId();
            androidx.appcompat.view.menu.j.a aVarM = C0593c.this.m();
            if (aVarM != null) {
                return aVarM.b(eVar);
            }
            return false;
        }
    }

    public C0593c(Context context) {
        super(context, ax.p194m.g.c, ax.p194m.g.b);
        this.D0 = new SparseBooleanArray();
        this.I0 = new f();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View z(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.o0;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if ((childAt instanceof androidx.appcompat.view.menu.k.a) && ((androidx.appcompat.view.menu.k.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public Drawable A() {
        d dVar = this.q0;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.s0) {
            return this.r0;
        }
        return null;
    }

    public boolean B() {
        Object obj;
        RunnableC0012c runnableC0012c = this.G0;
        if (runnableC0012c != null && (obj = this.o0) != null) {
            ((View) obj).removeCallbacks(runnableC0012c);
            this.G0 = null;
            return true;
        }
        e eVar = this.E0;
        if (eVar == null) {
            return false;
        }
        eVar.b();
        return true;
    }

    public boolean C() {
        a aVar = this.F0;
        if (aVar == null) {
            return false;
        }
        aVar.b();
        return true;
    }

    public boolean D() {
        return this.G0 != null || E();
    }

    public boolean E() {
        e eVar = this.E0;
        return eVar != null && eVar.d();
    }

    public void F(Configuration configuration) {
        if (!this.y0) {
            this.x0 = ax.p290s.a.b(this.X).d();
        }
        androidx.appcompat.view.menu.e eVar = this.Y;
        if (eVar != null) {
            eVar.L(true);
        }
    }

    public void G(boolean z) {
        this.B0 = z;
    }

    public void H(ActionMenuView actionMenuView) {
        this.o0 = actionMenuView;
        actionMenuView.b(this.Y);
    }

    public void I(Drawable drawable) {
        d dVar = this.q0;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
        } else {
            this.s0 = true;
            this.r0 = drawable;
        }
    }

    public void J(boolean z) {
        this.t0 = z;
        this.u0 = true;
    }

    public boolean K() {
        androidx.appcompat.view.menu.e eVar;
        if (!this.t0 || E() || (eVar = this.Y) == null || this.o0 == null || this.G0 != null || eVar.z().isEmpty()) {
            return false;
        }
        RunnableC0012c runnableC0012c = new RunnableC0012c(new e(this.X, this.Y, this.q0, true));
        this.G0 = runnableC0012c;
        ((View) this.o0).post(runnableC0012c);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
        y();
        super.a(eVar, z);
    }

    @Override // androidx.appcompat.view.menu.a
    public void c(androidx.appcompat.view.menu.g gVar, androidx.appcompat.view.menu.k.a aVar) {
        aVar.f(gVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.o0);
        if (this.H0 == null) {
            this.H0 = new b();
        }
        actionMenuItemView.setPopupCallback(this.H0);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void d(boolean z) {
        super.d(z);
        ((View) this.o0).requestLayout();
        androidx.appcompat.view.menu.e eVar = this.Y;
        boolean z2 = false;
        if (eVar != null) {
            ArrayList<androidx.appcompat.view.menu.g> arrayListS = eVar.s();
            int size = arrayListS.size();
            for (int i = 0; i < size; i++) {
                AbstractC1834b abstractC1834bB = arrayListS.get(i).b();
                if (abstractC1834bB != null) {
                    abstractC1834bB.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.e eVar2 = this.Y;
        ArrayList<androidx.appcompat.view.menu.g> arrayListZ = eVar2 != null ? eVar2.z() : null;
        if (this.t0 && arrayListZ != null) {
            int size2 = arrayListZ.size();
            if (size2 == 1) {
                z2 = !arrayListZ.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.q0 == null) {
                this.q0 = new d(this.q);
            }
            ViewGroup viewGroup = (ViewGroup) this.q0.getParent();
            if (viewGroup != this.o0) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.q0);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.o0;
                actionMenuView.addView(this.q0, actionMenuView.F());
            }
        } else {
            d dVar = this.q0;
            if (dVar != null) {
                Object parent = dVar.getParent();
                Object obj = this.o0;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.q0);
                }
            }
        }
        ((ActionMenuView) this.o0).setOverflowReserved(this.t0);
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        ArrayList<androidx.appcompat.view.menu.g> arrayListE;
        int size;
        int i;
        int iL;
        C0593c c0593c = this;
        androidx.appcompat.view.menu.e eVar = c0593c.Y;
        View view = null;
        int i2 = 0;
        if (eVar != null) {
            arrayListE = eVar.E();
            size = arrayListE.size();
        } else {
            arrayListE = null;
            size = 0;
        }
        int i3 = c0593c.x0;
        int i4 = c0593c.w0;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) c0593c.o0;
        boolean z = false;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < size; i7++) {
            androidx.appcompat.view.menu.g gVar = arrayListE.get(i7);
            if (gVar.o()) {
                i5++;
            } else if (gVar.n()) {
                i6++;
            } else {
                z = true;
            }
            if (c0593c.B0 && gVar.isActionViewExpanded()) {
                i3 = 0;
            }
        }
        if (c0593c.t0 && (z || i6 + i5 > i3)) {
            i3--;
        }
        int i8 = i3 - i5;
        SparseBooleanArray sparseBooleanArray = c0593c.D0;
        sparseBooleanArray.clear();
        if (c0593c.z0) {
            int i9 = c0593c.C0;
            iL = i4 / i9;
            i = i9 + ((i4 % i9) / iL);
        } else {
            i = 0;
            iL = 0;
        }
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            androidx.appcompat.view.menu.g gVar2 = arrayListE.get(i10);
            if (gVar2.o()) {
                View viewN = c0593c.n(gVar2, view, viewGroup);
                if (c0593c.z0) {
                    iL -= ActionMenuView.L(viewN, i, iL, iMakeMeasureSpec, i2);
                } else {
                    viewN.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                }
                int measuredWidth = viewN.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                int groupId = gVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                gVar2.u(true);
            } else {
                if (gVar2.n()) {
                    int groupId2 = gVar2.getGroupId();
                    boolean z2 = sparseBooleanArray.get(groupId2);
                    boolean z3 = (i8 > 0 || z2) && i4 > 0 && (!c0593c.z0 || iL > 0);
                    boolean z4 = z3;
                    if (z3) {
                        View viewN2 = c0593c.n(gVar2, null, viewGroup);
                        if (c0593c.z0) {
                            int iL2 = ActionMenuView.L(viewN2, i, iL, iMakeMeasureSpec, 0);
                            iL -= iL2;
                            if (iL2 == 0) {
                                z4 = false;
                            }
                        } else {
                            viewN2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                        }
                        boolean z5 = z4;
                        int measuredWidth2 = viewN2.getMeasuredWidth();
                        i4 -= measuredWidth2;
                        if (i11 == 0) {
                            i11 = measuredWidth2;
                        }
                        z3 = z5 & (!c0593c.z0 ? i4 + i11 <= 0 : i4 < 0);
                    }
                    if (z3 && groupId2 != 0) {
                        sparseBooleanArray.put(groupId2, true);
                    } else if (z2) {
                        sparseBooleanArray.put(groupId2, false);
                        for (int i12 = 0; i12 < i10; i12++) {
                            androidx.appcompat.view.menu.g gVar3 = arrayListE.get(i12);
                            if (gVar3.getGroupId() == groupId2) {
                                if (gVar3.l()) {
                                    i8++;
                                }
                                gVar3.u(false);
                            }
                        }
                    }
                    if (z3) {
                        i8--;
                    }
                    gVar2.u(z3);
                } else {
                    size = size;
                    gVar2.u(false);
                }
                i10++;
                view = null;
                c0593c = this;
                size = size;
                i2 = 0;
            }
            i10++;
            view = null;
            c0593c = this;
            size = size;
            i2 = 0;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void i(Context context, androidx.appcompat.view.menu.e eVar) {
        super.i(context, eVar);
        Resources resources = context.getResources();
        ax.p290s.a aVarB = ax.p290s.a.b(context);
        if (!this.u0) {
            this.t0 = aVarB.h();
        }
        if (!this.A0) {
            this.v0 = aVarB.c();
        }
        if (!this.y0) {
            this.x0 = aVarB.d();
        }
        int measuredWidth = this.v0;
        if (this.t0) {
            if (this.q0 == null) {
                d dVar = new d(this.q);
                this.q0 = dVar;
                if (this.s0) {
                    dVar.setImageDrawable(this.r0);
                    this.r0 = null;
                    this.s0 = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.q0.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.q0.getMeasuredWidth();
        } else {
            this.q0 = null;
        }
        this.w0 = measuredWidth;
        this.C0 = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public boolean k(androidx.appcompat.view.menu.m mVar) {
        boolean z = false;
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        androidx.appcompat.view.menu.m mVar2 = mVar;
        while (mVar2.g0() != this.Y) {
            mVar2 = (androidx.appcompat.view.menu.m) mVar2.g0();
        }
        View viewZ = z(mVar2.getItem());
        if (viewZ == null) {
            return false;
        }
        this.J0 = mVar.getItem().getItemId();
        int size = mVar.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = mVar.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
        }
        a aVar = new a(this.X, mVar, viewZ);
        this.F0 = aVar;
        aVar.g(z);
        this.F0.k();
        super.k(mVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean l(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.q0) {
            return false;
        }
        return super.l(viewGroup, i);
    }

    @Override // androidx.appcompat.view.menu.a
    public View n(androidx.appcompat.view.menu.g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.j()) {
            actionView = super.n(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.a
    public androidx.appcompat.view.menu.k o(ViewGroup viewGroup) {
        androidx.appcompat.view.menu.k kVar = this.o0;
        androidx.appcompat.view.menu.k kVarO = super.o(viewGroup);
        if (kVar != kVarO) {
            ((ActionMenuView) kVarO).setPresenter(this);
        }
        return kVarO;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean q(int i, androidx.appcompat.view.menu.g gVar) {
        return gVar.l();
    }

    public boolean y() {
        return B() | C();
    }
}
