package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import ax.p015b0.Y;
import java.lang.ref.WeakReference;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
class w {
    private final TextView a;
    private J b;
    private J c;
    private J d;
    private J e;
    private J f;
    private J g;
    private J h;
    private final y i;
    private int j = 0;
    private int k = -1;
    private Typeface l;
    private boolean m;

    class a extends ax.R.h.e {
        final /* synthetic */ int a;
        final /* synthetic */ int b;
        final /* synthetic */ WeakReference c;

        a(int i, int i2, WeakReference weakReference) {
            this.a = i;
            this.b = i2;
            this.c = weakReference;
        }

        @Override // ax.R.h.e
        /* JADX INFO: renamed from: h */
        public void f(int i) {
        }

        @Override // ax.R.h.e
        /* JADX INFO: renamed from: i */
        public void g(Typeface typeface) {
            int i;
            if (Build.VERSION.SDK_INT >= 28 && (i = this.a) != -1) {
                typeface = f.a(typeface, i, (this.b & 2) != 0);
            }
            w.this.n(this.c, typeface);
        }
    }

    class b implements Runnable {
        final /* synthetic */ Typeface X;
        final /* synthetic */ int Y;
        final /* synthetic */ TextView q;

        b(TextView textView, Typeface typeface, int i) {
            this.q = textView;
            this.X = typeface;
            this.Y = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.q.setTypeface(this.X, this.Y);
        }
    }

    static class c {
        static Locale a(String str) {
            return Locale.forLanguageTag(str);
        }
    }

    static class d {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }

        static void b(TextView textView, LocaleList localeList) {
            textView.setTextLocales(localeList);
        }
    }

    static class e {
        static int a(TextView textView) {
            return textView.getAutoSizeStepGranularity();
        }

        static void b(TextView textView, int i, int i2, int i3, int i4) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
        }

        static void c(TextView textView, int[] iArr, int i) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
        }

        static boolean d(TextView textView, String str) {
            return textView.setFontVariationSettings(str);
        }
    }

    static class f {
        static Typeface a(Typeface typeface, int i, boolean z) {
            return Typeface.create(typeface, i, z);
        }
    }

    w(TextView textView) {
        this.a = textView;
        this.i = new y(textView);
    }

    private void B(int i, float f2) {
        this.i.t(i, f2);
    }

    private void C(Context context, L l) {
        String strO;
        this.j = l.k(ax.p168m.j.M2, this.j);
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            int iK = l.k(ax.p168m.j.R2, -1);
            this.k = iK;
            if (iK != -1) {
                this.j &= 2;
            }
        }
        int i2 = ax.p168m.j.Q2;
        if (!l.s(i2) && !l.s(ax.p168m.j.S2)) {
            int i3 = ax.p168m.j.L2;
            if (l.s(i3)) {
                this.m = false;
                int iK2 = l.k(i3, 1);
                if (iK2 == 1) {
                    this.l = Typeface.SANS_SERIF;
                    return;
                } else if (iK2 == 2) {
                    this.l = Typeface.SERIF;
                    return;
                } else {
                    if (iK2 != 3) {
                        return;
                    }
                    this.l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.l = null;
        int i4 = ax.p168m.j.S2;
        if (l.s(i4)) {
            i2 = i4;
        }
        int i5 = this.k;
        int i6 = this.j;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceJ = l.j(i2, this.j, new a(i5, i6, new WeakReference(this.a)));
                if (typefaceJ != null) {
                    if (i < 28 || this.k == -1) {
                        this.l = typefaceJ;
                    } else {
                        this.l = f.a(Typeface.create(typefaceJ, 0), this.k, (this.j & 2) != 0);
                    }
                }
                this.m = this.l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.l != null || (strO = l.o(i2)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.k == -1) {
            this.l = Typeface.create(strO, this.j);
        } else {
            this.l = f.a(Typeface.create(strO, 0), this.k, (this.j & 2) != 0);
        }
    }

    private void a(Drawable drawable, J j) {
        if (drawable == null || j == null) {
            return;
        }
        C0558k.i(drawable, j, this.a.getDrawableState());
    }

    private static J d(Context context, C0558k c0558k, int i) {
        ColorStateList colorStateListF = c0558k.f(context, i);
        if (colorStateListF == null) {
            return null;
        }
        J j = new J();
        j.d = true;
        j.a = colorStateListF;
        return j;
    }

    private void y(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] compoundDrawablesRelative = this.a.getCompoundDrawablesRelative();
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            TextView textView = this.a;
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
            return;
        }
        if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative2 = this.a.getCompoundDrawablesRelative();
        Drawable drawable7 = compoundDrawablesRelative2[0];
        if (drawable7 != null || compoundDrawablesRelative2[2] != null) {
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative2[1];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative2[3];
            }
            this.a.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, compoundDrawablesRelative2[2], drawable4);
            return;
        }
        Drawable[] compoundDrawables = this.a.getCompoundDrawables();
        TextView textView2 = this.a;
        if (drawable == null) {
            drawable = compoundDrawables[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawables[1];
        }
        if (drawable3 == null) {
            drawable3 = compoundDrawables[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawables[3];
        }
        textView2.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    private void z() {
        J j = this.h;
        this.b = j;
        this.c = j;
        this.d = j;
        this.e = j;
        this.f = j;
        this.g = j;
    }

    void A(int i, float f2) {
        if (O.c || l()) {
            return;
        }
        B(i, f2);
    }

    void b() {
        if (this.b != null || this.c != null || this.d != null || this.e != null) {
            Drawable[] compoundDrawables = this.a.getCompoundDrawables();
            a(compoundDrawables[0], this.b);
            a(compoundDrawables[1], this.c);
            a(compoundDrawables[2], this.d);
            a(compoundDrawables[3], this.e);
        }
        if (this.f == null && this.g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = this.a.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f);
        a(compoundDrawablesRelative[2], this.g);
    }

    void c() {
        this.i.a();
    }

    int e() {
        return this.i.f();
    }

    int f() {
        return this.i.g();
    }

    int g() {
        return this.i.h();
    }

    int[] h() {
        return this.i.i();
    }

    int i() {
        return this.i.j();
    }

    ColorStateList j() {
        J j = this.h;
        if (j != null) {
            return j.a;
        }
        return null;
    }

    PorterDuff.Mode k() {
        J j = this.h;
        if (j != null) {
            return j.b;
        }
        return null;
    }

    boolean l() {
        return this.i.n();
    }

    /* JADX WARN: Code duplicated, block: B:163:0x031f  */
    /* JADX WARN: Code duplicated, block: B:165:0x0326  */
    /* JADX WARN: Code duplicated, block: B:168:0x032f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:169:0x0331  */
    /* JADX WARN: Code duplicated, block: B:170:0x0338  */
    /* JADX WARN: Code duplicated, block: B:172:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:27:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:45:0x0102  */
    /* JADX WARN: Code duplicated, block: B:46:0x0107  */
    /* JADX WARN: Code duplicated, block: B:48:0x010a  */
    /* JADX WARN: Code duplicated, block: B:50:0x0112  */
    /* JADX WARN: Code duplicated, block: B:51:0x0117  */
    /* JADX WARN: Code duplicated, block: B:59:0x013a  */
    /* JADX WARN: Code duplicated, block: B:86:0x019f  */
    @SuppressLint({"NewApi"})
    void m(AttributeSet attributeSet, int i) {
        String strO;
        ColorStateList colorStateListC;
        boolean zA;
        boolean z;
        ColorStateList colorStateListC2;
        ColorStateList colorStateListC3;
        String strO2;
        boolean z2;
        int i2;
        int i3;
        float f2;
        int i4;
        int i5;
        int i6;
        Context context = this.a.getContext();
        C0558k c0558kB = C0558k.b();
        int[] iArr = ax.p168m.j.Y;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        TextView textView = this.a;
        Y.o0(textView, textView.getContext(), iArr, attributeSet, lV.r(), i, 0);
        int iN = lV.n(ax.p168m.j.Z, -1);
        int i7 = ax.p168m.j.c0;
        if (lV.s(i7)) {
            this.b = d(context, c0558kB, lV.n(i7, 0));
        }
        int i8 = ax.p168m.j.a0;
        if (lV.s(i8)) {
            this.c = d(context, c0558kB, lV.n(i8, 0));
        }
        int i9 = ax.p168m.j.d0;
        if (lV.s(i9)) {
            this.d = d(context, c0558kB, lV.n(i9, 0));
        }
        int i10 = ax.p168m.j.b0;
        if (lV.s(i10)) {
            this.e = d(context, c0558kB, lV.n(i10, 0));
        }
        int i11 = ax.p168m.j.e0;
        if (lV.s(i11)) {
            this.f = d(context, c0558kB, lV.n(i11, 0));
        }
        int i12 = ax.p168m.j.f0;
        if (lV.s(i12)) {
            this.g = d(context, c0558kB, lV.n(i12, 0));
        }
        lV.x();
        boolean z3 = this.a.getTransformationMethod() instanceof PasswordTransformationMethod;
        if (iN != -1) {
            L lT = L.t(context, iN, ax.p168m.j.J2);
            if (z3) {
                zA = false;
                z = false;
            } else {
                int i13 = ax.p168m.j.U2;
                if (lT.s(i13)) {
                    zA = lT.a(i13, false);
                    z = true;
                } else {
                    zA = false;
                    z = false;
                }
            }
            C(context, lT);
            int i14 = Build.VERSION.SDK_INT;
            if (i14 < 23) {
                int i15 = ax.p168m.j.N2;
                colorStateListC = lT.s(i15) ? lT.c(i15) : null;
                int i16 = ax.p168m.j.O2;
                colorStateListC2 = lT.s(i16) ? lT.c(i16) : null;
                int i17 = ax.p168m.j.P2;
                colorStateListC3 = lT.s(i17) ? lT.c(i17) : null;
                i5 = ax.p168m.j.V2;
                if (lT.s(i5)) {
                    strO = lT.o(i5);
                } else {
                    strO = null;
                }
                if (i14 >= 26) {
                    i6 = ax.p168m.j.T2;
                    if (lT.s(i6)) {
                        strO2 = lT.o(i6);
                    } else {
                        strO2 = null;
                    }
                } else {
                    strO2 = null;
                }
                lT.x();
            } else {
                colorStateListC = null;
                colorStateListC2 = null;
            }
            i5 = ax.p168m.j.V2;
            if (lT.s(i5)) {
                strO = lT.o(i5);
            } else {
                strO = null;
            }
            if (i14 >= 26) {
                i6 = ax.p168m.j.T2;
                if (lT.s(i6)) {
                    strO2 = lT.o(i6);
                } else {
                    strO2 = null;
                }
            } else {
                strO2 = null;
            }
            lT.x();
        } else {
            strO = null;
            colorStateListC = null;
            zA = false;
            z = false;
            colorStateListC2 = null;
            colorStateListC3 = null;
            strO2 = null;
        }
        L lV2 = L.v(context, attributeSet, ax.p168m.j.J2, i, 0);
        if (z3) {
            z2 = z;
        } else {
            int i18 = ax.p168m.j.U2;
            if (lV2.s(i18)) {
                zA = lV2.a(i18, false);
                z2 = true;
            } else {
                z2 = z;
            }
        }
        int i19 = Build.VERSION.SDK_INT;
        if (i19 < 23) {
            int i20 = ax.p168m.j.N2;
            if (lV2.s(i20)) {
                colorStateListC = lV2.c(i20);
            }
            int i21 = ax.p168m.j.O2;
            if (lV2.s(i21)) {
                colorStateListC2 = lV2.c(i21);
            }
            int i22 = ax.p168m.j.P2;
            if (lV2.s(i22)) {
                colorStateListC3 = lV2.c(i22);
            }
        }
        int i23 = ax.p168m.j.V2;
        if (lV2.s(i23)) {
            strO = lV2.o(i23);
        }
        if (i19 >= 26) {
            int i24 = ax.p168m.j.T2;
            if (lV2.s(i24)) {
                strO2 = lV2.o(i24);
            }
        }
        if (i19 >= 28) {
            int i25 = ax.p168m.j.K2;
            if (lV2.s(i25) && lV2.f(i25, -1) == 0) {
                this.a.setTextSize(0, 0.0f);
            }
        }
        C(context, lV2);
        lV2.x();
        if (colorStateListC != null) {
            this.a.setTextColor(colorStateListC);
        }
        if (colorStateListC2 != null) {
            this.a.setHintTextColor(colorStateListC2);
        }
        if (colorStateListC3 != null) {
            this.a.setLinkTextColor(colorStateListC3);
        }
        if (!z3 && z2) {
            s(zA);
        }
        Typeface typeface = this.l;
        if (typeface != null) {
            if (this.k == -1) {
                this.a.setTypeface(typeface, this.j);
            } else {
                this.a.setTypeface(typeface);
            }
        }
        if (strO2 != null) {
            e.d(this.a, strO2);
        }
        if (strO != null) {
            if (i19 >= 24) {
                d.b(this.a, d.a(strO));
            } else {
                this.a.setTextLocale(c.a(strO.split(",")[0]));
            }
        }
        this.i.o(attributeSet, i);
        if (O.c && this.i.j() != 0) {
            int[] iArrI = this.i.i();
            if (iArrI.length > 0) {
                if (e.a(this.a) != -1.0f) {
                    e.b(this.a, this.i.g(), this.i.f(), this.i.h(), 0);
                } else {
                    e.c(this.a, iArrI, 0);
                }
            }
        }
        L lU = L.u(context, attributeSet, ax.p168m.j.g0);
        int iN2 = lU.n(ax.p168m.j.o0, -1);
        Drawable drawableC = iN2 != -1 ? c0558kB.c(context, iN2) : null;
        int iN3 = lU.n(ax.p168m.j.t0, -1);
        Drawable drawableC2 = iN3 != -1 ? c0558kB.c(context, iN3) : null;
        int iN4 = lU.n(ax.p168m.j.p0, -1);
        Drawable drawableC3 = iN4 != -1 ? c0558kB.c(context, iN4) : null;
        int iN5 = lU.n(ax.p168m.j.m0, -1);
        Drawable drawableC4 = iN5 != -1 ? c0558kB.c(context, iN5) : null;
        int iN6 = lU.n(ax.p168m.j.q0, -1);
        Drawable drawableC5 = iN6 != -1 ? c0558kB.c(context, iN6) : null;
        int iN7 = lU.n(ax.p168m.j.n0, -1);
        y(drawableC, drawableC2, drawableC3, drawableC4, drawableC5, iN7 != -1 ? c0558kB.c(context, iN7) : null);
        int i26 = ax.p168m.j.r0;
        if (lU.s(i26)) {
            ax.p099h0.j.h(this.a, lU.c(i26));
        }
        int i27 = ax.p168m.j.s0;
        if (lU.s(i27)) {
            i2 = -1;
            ax.p099h0.j.i(this.a, A.e(lU.k(i27, -1), null));
        } else {
            i2 = -1;
        }
        int iF = lU.f(ax.p168m.j.v0, i2);
        int iF2 = lU.f(ax.p168m.j.w0, i2);
        int i28 = ax.p168m.j.x0;
        if (lU.s(i28)) {
            TypedValue typedValueW = lU.w(i28);
            if (typedValueW == null || typedValueW.type != 5) {
                i3 = -1;
                f2 = lU.f(i28, -1);
            } else {
                int iA = ax.p001a0.j.a(typedValueW.data);
                f2 = TypedValue.complexToFloat(typedValueW.data);
                i4 = iA;
                i3 = -1;
            }
            lU.x();
            if (iF != i3) {
                ax.p099h0.j.k(this.a, iF);
            }
            if (iF2 != i3) {
                ax.p099h0.j.l(this.a, iF2);
            }
            if (f2 != -1.0f) {
                if (i4 == i3) {
                    ax.p099h0.j.m(this.a, (int) f2);
                } else {
                    ax.p099h0.j.n(this.a, i4, f2);
                }
            }
        }
        i3 = -1;
        f2 = -1.0f;
        i4 = -1;
        lU.x();
        if (iF != i3) {
            ax.p099h0.j.k(this.a, iF);
        }
        if (iF2 != i3) {
            ax.p099h0.j.l(this.a, iF2);
        }
        if (f2 != -1.0f) {
            if (i4 == i3) {
                ax.p099h0.j.m(this.a, (int) f2);
            } else {
                ax.p099h0.j.n(this.a, i4, f2);
            }
        }
    }

    void n(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.m) {
            this.l = typeface;
            TextView textView = weakReference.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new b(textView, typeface, this.j));
                } else {
                    textView.setTypeface(typeface, this.j);
                }
            }
        }
    }

    void o(boolean z, int i, int i2, int i3, int i4) {
        if (O.c) {
            return;
        }
        c();
    }

    void p() {
        b();
    }

    void q(Context context, int i) {
        String strO;
        ColorStateList colorStateListC;
        ColorStateList colorStateListC2;
        ColorStateList colorStateListC3;
        L lT = L.t(context, i, ax.p168m.j.J2);
        int i2 = ax.p168m.j.U2;
        if (lT.s(i2)) {
            s(lT.a(i2, false));
        }
        int i3 = Build.VERSION.SDK_INT;
        if (i3 < 23) {
            int i4 = ax.p168m.j.N2;
            if (lT.s(i4) && (colorStateListC3 = lT.c(i4)) != null) {
                this.a.setTextColor(colorStateListC3);
            }
            int i5 = ax.p168m.j.P2;
            if (lT.s(i5) && (colorStateListC2 = lT.c(i5)) != null) {
                this.a.setLinkTextColor(colorStateListC2);
            }
            int i6 = ax.p168m.j.O2;
            if (lT.s(i6) && (colorStateListC = lT.c(i6)) != null) {
                this.a.setHintTextColor(colorStateListC);
            }
        }
        int i7 = ax.p168m.j.K2;
        if (lT.s(i7) && lT.f(i7, -1) == 0) {
            this.a.setTextSize(0, 0.0f);
        }
        C(context, lT);
        if (i3 >= 26) {
            int i8 = ax.p168m.j.T2;
            if (lT.s(i8) && (strO = lT.o(i8)) != null) {
                e.d(this.a, strO);
            }
        }
        lT.x();
        Typeface typeface = this.l;
        if (typeface != null) {
            this.a.setTypeface(typeface, this.j);
        }
    }

    void r(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
        if (Build.VERSION.SDK_INT >= 30 || inputConnection == null) {
            return;
        }
        ax.p085g0.c.f(editorInfo, textView.getText());
    }

    void s(boolean z) {
        this.a.setAllCaps(z);
    }

    void t(int i, int i2, int i3, int i4) throws IllegalArgumentException {
        this.i.p(i, i2, i3, i4);
    }

    void u(int[] iArr, int i) throws IllegalArgumentException {
        this.i.q(iArr, i);
    }

    void v(int i) {
        this.i.r(i);
    }

    void w(ColorStateList colorStateList) {
        if (this.h == null) {
            this.h = new J();
        }
        J j = this.h;
        j.a = colorStateList;
        j.d = colorStateList != null;
        z();
    }

    void x(PorterDuff.Mode mode) {
        if (this.h == null) {
            this.h = new J();
        }
        J j = this.h;
        j.b = mode;
        j.c = mode != null;
        z();
    }
}
