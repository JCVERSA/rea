package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import ax.p035c0.C1839d0;

/* JADX INFO: renamed from: androidx.appcompat.widget.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0595e {
    private final View a;
    private J d;
    private J e;
    private J f;
    private int c = -1;
    private final C0601k b = C0601k.b();

    C0595e(View view) {
        this.a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f == null) {
            this.f = new J();
        }
        J j = this.f;
        j.a();
        ColorStateList colorStateListS = C1839d0.s(this.a);
        if (colorStateListS != null) {
            j.d = true;
            j.a = colorStateListS;
        }
        PorterDuff.Mode modeT = C1839d0.t(this.a);
        if (modeT != null) {
            j.c = true;
            j.b = modeT;
        }
        if (!j.d && !j.c) {
            return false;
        }
        C0601k.i(drawable, j, this.a.getDrawableState());
        return true;
    }

    private boolean k() {
        int i = Build.VERSION.SDK_INT;
        if (i > 21) {
            return this.d != null;
        }
        return i == 21;
    }

    void b() {
        Drawable background = this.a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            J j = this.e;
            if (j != null) {
                C0601k.i(background, j, this.a.getDrawableState());
                return;
            }
            J j2 = this.d;
            if (j2 != null) {
                C0601k.i(background, j2, this.a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        J j = this.e;
        if (j != null) {
            return j.a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        J j = this.e;
        if (j != null) {
            return j.b;
        }
        return null;
    }

    void e(AttributeSet attributeSet, int i) {
        Context context = this.a.getContext();
        int[] iArr = ax.p194m.j.H3;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        View view = this.a;
        C1839d0.j0(view, view.getContext(), iArr, attributeSet, lV.r(), i, 0);
        try {
            int i2 = ax.p194m.j.I3;
            if (lV.s(i2)) {
                this.c = lV.n(i2, -1);
                ColorStateList colorStateListF = this.b.f(this.a.getContext(), this.c);
                if (colorStateListF != null) {
                    h(colorStateListF);
                }
            }
            int i3 = ax.p194m.j.J3;
            if (lV.s(i3)) {
                C1839d0.p0(this.a, lV.c(i3));
            }
            int i4 = ax.p194m.j.K3;
            if (lV.s(i4)) {
                C1839d0.q0(this.a, A.e(lV.k(i4, -1), null));
            }
        } finally {
            lV.x();
        }
    }

    void f(Drawable drawable) {
        this.c = -1;
        h(null);
        b();
    }

    void g(int i) {
        this.c = i;
        C0601k c0601k = this.b;
        h(c0601k != null ? c0601k.f(this.a.getContext(), i) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.d == null) {
                this.d = new J();
            }
            J j = this.d;
            j.a = colorStateList;
            j.d = true;
        } else {
            this.d = null;
        }
        b();
    }

    void i(ColorStateList colorStateList) {
        if (this.e == null) {
            this.e = new J();
        }
        J j = this.e;
        j.a = colorStateList;
        j.d = true;
        b();
    }

    void j(PorterDuff.Mode mode) {
        if (this.e == null) {
            this.e = new J();
        }
        J j = this.e;
        j.b = mode;
        j.c = true;
        b();
    }
}
