package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckedTextView;
import ax.p035c0.C1839d0;

/* JADX INFO: renamed from: androidx.appcompat.widget.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0599i {
    private final CheckedTextView a;
    private ColorStateList b = null;
    private PorterDuff.Mode c = null;
    private boolean d = false;
    private boolean e = false;
    private boolean f;

    C0599i(CheckedTextView checkedTextView) {
        this.a = checkedTextView;
    }

    void a() {
        Drawable drawableA = ax.p115h0.b.a(this.a);
        if (drawableA != null) {
            if (this.d || this.e) {
                Drawable drawableMutate = ax.U.a.r(drawableA).mutate();
                if (this.d) {
                    ax.U.a.o(drawableMutate, this.b);
                }
                if (this.e) {
                    ax.U.a.p(drawableMutate, this.c);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(this.a.getDrawableState());
                }
                this.a.setCheckMarkDrawable(drawableMutate);
            }
        }
    }

    ColorStateList b() {
        return this.b;
    }

    PorterDuff.Mode c() {
        return this.c;
    }

    void d(AttributeSet attributeSet, int i) {
        int i2;
        int iN;
        int iN2;
        Context context = this.a.getContext();
        int[] iArr = ax.p194m.j.P0;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        CheckedTextView checkedTextView = this.a;
        C1839d0.j0(checkedTextView, checkedTextView.getContext(), iArr, attributeSet, lV.r(), i, 0);
        try {
            int i3 = ax.p194m.j.R0;
            if (!lV.s(i3) || (iN2 = lV.n(i3, 0)) == 0) {
                i2 = ax.p194m.j.Q0;
                if (lV.s(i2) && (iN = lV.n(i2, 0)) != 0) {
                    CheckedTextView checkedTextView2 = this.a;
                    checkedTextView2.setCheckMarkDrawable(ax.p226o.a.b(checkedTextView2.getContext(), iN));
                }
            } else {
                try {
                    CheckedTextView checkedTextView3 = this.a;
                    checkedTextView3.setCheckMarkDrawable(ax.p226o.a.b(checkedTextView3.getContext(), iN2));
                } catch (Resources.NotFoundException unused) {
                    i2 = ax.p194m.j.Q0;
                    if (lV.s(i2)) {
                        CheckedTextView checkedTextView4 = this.a;
                        checkedTextView4.setCheckMarkDrawable(ax.p226o.a.b(checkedTextView4.getContext(), iN));
                    }
                }
            }
            int i4 = ax.p194m.j.S0;
            if (lV.s(i4)) {
                ax.p115h0.b.b(this.a, lV.c(i4));
            }
            int i5 = ax.p194m.j.T0;
            if (lV.s(i5)) {
                ax.p115h0.b.c(this.a, A.e(lV.k(i5, -1), null));
            }
        } finally {
            lV.x();
        }
    }

    void e() {
        if (this.f) {
            this.f = false;
        } else {
            this.f = true;
            a();
        }
    }

    void f(ColorStateList colorStateList) {
        this.b = colorStateList;
        this.d = true;
        a();
    }

    void g(PorterDuff.Mode mode) {
        this.c = mode;
        this.e = true;
        a();
    }
}
