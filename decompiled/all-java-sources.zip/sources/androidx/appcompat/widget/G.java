package androidx.appcompat.widget;

import android.R;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.WeakHashMap;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
class G extends ax.p113i0.c implements View.OnClickListener {
    private int A0;
    private int B0;
    private final SearchView o0;
    private final SearchableInfo p0;
    private final Context q0;
    private final WeakHashMap<String, Drawable.ConstantState> r0;
    private final int s0;
    private boolean t0;
    private int u0;
    private ColorStateList v0;
    private int w0;
    private int x0;
    private int y0;
    private int z0;

    private static final class a {
        public final TextView a;
        public final TextView b;
        public final ImageView c;
        public final ImageView d;
        public final ImageView e;

        public a(View view) {
            this.a = (TextView) view.findViewById(R.id.text1);
            this.b = (TextView) view.findViewById(R.id.text2);
            this.c = (ImageView) view.findViewById(R.id.icon1);
            this.d = (ImageView) view.findViewById(R.id.icon2);
            this.e = (ImageView) view.findViewById(ax.p168m.f.q);
        }
    }

    public G(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap<String, Drawable.ConstantState> weakHashMap) {
        super(context, searchView.getSuggestionRowLayout(), null, true);
        this.t0 = false;
        this.u0 = 1;
        this.w0 = -1;
        this.x0 = -1;
        this.y0 = -1;
        this.z0 = -1;
        this.A0 = -1;
        this.B0 = -1;
        this.o0 = searchView;
        this.p0 = searchableInfo;
        this.s0 = searchView.getSuggestionCommitIconResId();
        this.q0 = context;
        this.r0 = weakHashMap;
    }

    private Drawable A(Uri uri) {
        try {
            if ("android.resource".equals(uri.getScheme())) {
                try {
                    return B(uri);
                } catch (Resources.NotFoundException unused) {
                    throw new FileNotFoundException("Resource does not exist: " + uri);
                }
            }
            InputStream inputStreamOpenInputStream = this.q0.getContentResolver().openInputStream(uri);
            if (inputStreamOpenInputStream == null) {
                throw new FileNotFoundException("Failed to open " + uri);
            }
            try {
                Drawable drawableCreateFromStream = Drawable.createFromStream(inputStreamOpenInputStream, null);
                try {
                    inputStreamOpenInputStream.close();
                } catch (IOException e) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, e);
                }
                return drawableCreateFromStream;
            } catch (Throwable th) {
                try {
                    inputStreamOpenInputStream.close();
                } catch (IOException e2) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, e2);
                }
                throw th;
            }
        } catch (FileNotFoundException e3) {
            Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e3.getMessage());
            return null;
        }
        Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e3.getMessage());
        return null;
    }

    private Drawable C(String str) {
        if (str == null || str.isEmpty() || "0".equals(str)) {
            return null;
        }
        try {
            int i = Integer.parseInt(str);
            String str2 = "android.resource://" + this.q0.getPackageName() + "/" + i;
            Drawable drawableU = u(str2);
            if (drawableU != null) {
                return drawableU;
            }
            Drawable drawableE = ax.P.b.e(this.q0, i);
            K(str2, drawableE);
            return drawableE;
        } catch (Resources.NotFoundException unused) {
            Log.w("SuggestionsAdapter", "Icon resource not found: " + str);
            return null;
        } catch (NumberFormatException unused2) {
            Drawable drawableU2 = u(str);
            if (drawableU2 != null) {
                return drawableU2;
            }
            Drawable drawableA = A(Uri.parse(str));
            K(str, drawableA);
            return drawableA;
        }
    }

    private Drawable D(Cursor cursor) {
        int i = this.z0;
        if (i == -1) {
            return null;
        }
        Drawable drawableC = C(cursor.getString(i));
        return drawableC != null ? drawableC : z();
    }

    private Drawable E(Cursor cursor) {
        int i = this.A0;
        if (i == -1) {
            return null;
        }
        return C(cursor.getString(i));
    }

    private static String G(Cursor cursor, int i) {
        if (i == -1) {
            return null;
        }
        try {
            return cursor.getString(i);
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e);
            return null;
        }
    }

    private void I(ImageView imageView, Drawable drawable, int i) {
        imageView.setImageDrawable(drawable);
        if (drawable == null) {
            imageView.setVisibility(i);
            return;
        }
        imageView.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    private void J(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        if (TextUtils.isEmpty(charSequence)) {
            textView.setVisibility(8);
        } else {
            textView.setVisibility(0);
        }
    }

    private void K(String str, Drawable drawable) {
        if (drawable != null) {
            this.r0.put(str, drawable.getConstantState());
        }
    }

    private void L(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null) {
            extras.getBoolean("in_progress");
        }
    }

    private Drawable u(String str) {
        Drawable.ConstantState constantState = this.r0.get(str);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    private CharSequence v(CharSequence charSequence) {
        if (this.v0 == null) {
            TypedValue typedValue = new TypedValue();
            this.q0.getTheme().resolveAttribute(ax.p168m.a.O, typedValue, true);
            this.v0 = this.q0.getResources().getColorStateList(typedValue.resourceId);
        }
        SpannableString spannableString = new SpannableString(charSequence);
        spannableString.setSpan(new TextAppearanceSpan(null, 0, 0, this.v0, null), 0, charSequence.length(), 33);
        return spannableString;
    }

    private Drawable w(ComponentName componentName) {
        PackageManager packageManager = this.q0.getPackageManager();
        try {
            ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, 128);
            int iconResource = activityInfo.getIconResource();
            if (iconResource == 0) {
                return null;
            }
            Drawable drawable = packageManager.getDrawable(componentName.getPackageName(), iconResource, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            Log.w("SuggestionsAdapter", "Invalid icon resource " + iconResource + " for " + componentName.flattenToShortString());
            return null;
        } catch (PackageManager.NameNotFoundException e) {
            Log.w("SuggestionsAdapter", e.toString());
            return null;
        }
    }

    private Drawable x(ComponentName componentName) {
        String strFlattenToShortString = componentName.flattenToShortString();
        if (!this.r0.containsKey(strFlattenToShortString)) {
            Drawable drawableW = w(componentName);
            this.r0.put(strFlattenToShortString, drawableW != null ? drawableW.getConstantState() : null);
            return drawableW;
        }
        Drawable.ConstantState constantState = this.r0.get(strFlattenToShortString);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable(this.q0.getResources());
    }

    public static String y(Cursor cursor, String str) {
        return G(cursor, cursor.getColumnIndex(str));
    }

    private Drawable z() {
        Drawable drawableX = x(this.p0.getSearchActivity());
        return drawableX != null ? drawableX : this.q0.getPackageManager().getDefaultActivityIcon();
    }

    Drawable B(Uri uri) throws FileNotFoundException {
        int identifier;
        String authority = uri.getAuthority();
        if (TextUtils.isEmpty(authority)) {
            throw new FileNotFoundException("No authority: " + uri);
        }
        try {
            Resources resourcesForApplication = this.q0.getPackageManager().getResourcesForApplication(authority);
            List<String> pathSegments = uri.getPathSegments();
            if (pathSegments == null) {
                throw new FileNotFoundException("No path: " + uri);
            }
            int size = pathSegments.size();
            if (size == 1) {
                try {
                    identifier = Integer.parseInt(pathSegments.get(0));
                } catch (NumberFormatException unused) {
                    throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                }
            } else {
                if (size != 2) {
                    throw new FileNotFoundException("More than two path segments: " + uri);
                }
                identifier = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
            }
            if (identifier != 0) {
                return resourcesForApplication.getDrawable(identifier);
            }
            throw new FileNotFoundException("No resource found for: " + uri);
        } catch (PackageManager.NameNotFoundException unused2) {
            throw new FileNotFoundException("No package found for authority: " + uri);
        }
    }

    Cursor F(SearchableInfo searchableInfo, String str, int i) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder builderFragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query(HttpUrl.FRAGMENT_ENCODE_SET).fragment(HttpUrl.FRAGMENT_ENCODE_SET);
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            builderFragment.appendEncodedPath(suggestPath);
        }
        builderFragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            builderFragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        if (i > 0) {
            builderFragment.appendQueryParameter("limit", String.valueOf(i));
        }
        return this.q0.getContentResolver().query(builderFragment.build(), null, suggestSelection, strArr2, null);
    }

    public void H(int i) {
        this.u0 = i;
    }

    @Override // ax.p113i0.a, ax.i0.b.a
    public void a(Cursor cursor) {
        if (this.t0) {
            Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
            if (cursor != null) {
                cursor.close();
                return;
            }
            return;
        }
        try {
            super.a(cursor);
            if (cursor != null) {
                this.w0 = cursor.getColumnIndex("suggest_text_1");
                this.x0 = cursor.getColumnIndex("suggest_text_2");
                this.y0 = cursor.getColumnIndex("suggest_text_2_url");
                this.z0 = cursor.getColumnIndex("suggest_icon_1");
                this.A0 = cursor.getColumnIndex("suggest_icon_2");
                this.B0 = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e);
        }
    }

    @Override // ax.i0.b.a
    public CharSequence c(Cursor cursor) {
        String strY;
        String strY2;
        if (cursor == null) {
            return null;
        }
        String strY3 = y(cursor, "suggest_intent_query");
        if (strY3 != null) {
            return strY3;
        }
        if (this.p0.shouldRewriteQueryFromData() && (strY2 = y(cursor, "suggest_intent_data")) != null) {
            return strY2;
        }
        if (!this.p0.shouldRewriteQueryFromText() || (strY = y(cursor, "suggest_text_1")) == null) {
            return null;
        }
        return strY;
    }

    @Override // ax.i0.b.a
    public Cursor d(CharSequence charSequence) {
        String string = charSequence == null ? HttpUrl.FRAGMENT_ENCODE_SET : charSequence.toString();
        if (this.o0.getVisibility() == 0 && this.o0.getWindowVisibility() == 0) {
            try {
                Cursor cursorF = F(this.p0, string, 50);
                if (cursorF != null) {
                    cursorF.getCount();
                    return cursorF;
                }
            } catch (RuntimeException e) {
                Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e);
            }
        }
        return null;
    }

    @Override // ax.p113i0.a
    public void f(View view, Context context, Cursor cursor) {
        a aVar = (a) view.getTag();
        int i = this.B0;
        int i2 = i != -1 ? cursor.getInt(i) : 0;
        if (aVar.a != null) {
            J(aVar.a, G(cursor, this.w0));
        }
        if (aVar.b != null) {
            String strG = G(cursor, this.y0);
            CharSequence charSequenceV = strG != null ? v(strG) : G(cursor, this.x0);
            if (TextUtils.isEmpty(charSequenceV)) {
                TextView textView = aVar.a;
                if (textView != null) {
                    textView.setSingleLine(false);
                    aVar.a.setMaxLines(2);
                }
            } else {
                TextView textView2 = aVar.a;
                if (textView2 != null) {
                    textView2.setSingleLine(true);
                    aVar.a.setMaxLines(1);
                }
            }
            J(aVar.b, charSequenceV);
        }
        ImageView imageView = aVar.c;
        if (imageView != null) {
            I(imageView, D(cursor), 4);
        }
        ImageView imageView2 = aVar.d;
        if (imageView2 != null) {
            I(imageView2, E(cursor), 8);
        }
        int i3 = this.u0;
        if (i3 != 2 && (i3 != 1 || (i2 & 1) == 0)) {
            aVar.e.setVisibility(8);
            return;
        }
        aVar.e.setVisibility(0);
        aVar.e.setTag(aVar.a.getText());
        aVar.e.setOnClickListener(this);
    }

    @Override // ax.p113i0.a, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i, view, viewGroup);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View viewQ = q(this.q0, b(), viewGroup);
            if (viewQ != null) {
                ((a) viewQ.getTag()).a.setText(e.toString());
            }
            return viewQ;
        }
    }

    @Override // ax.p113i0.a, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i, view, viewGroup);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View viewR = r(this.q0, b(), viewGroup);
            if (viewR != null) {
                ((a) viewR.getTag()).a.setText(e.toString());
            }
            return viewR;
        }
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return false;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        L(b());
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        L(b());
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.o0.M((CharSequence) tag);
        }
    }

    @Override // ax.p113i0.c, ax.p113i0.a
    public View r(Context context, Cursor cursor, ViewGroup viewGroup) {
        View viewR = super.r(context, cursor, viewGroup);
        viewR.setTag(new a(viewR));
        ((ImageView) viewR.findViewById(ax.p168m.f.q)).setImageResource(this.s0);
        return viewR;
    }
}
