package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.SearchableInfo;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class SearchView extends B implements ax.p290s.b {
    static final e k1;
    private final View A0;
    final ImageView B0;
    final ImageView C0;
    final ImageView D0;
    final ImageView E0;
    private g F0;
    private Rect G0;
    private Rect H0;
    private int[] I0;
    private int[] J0;
    private final ImageView K0;
    private final Drawable L0;
    private final int M0;
    private final int N0;
    private final Intent O0;
    private final Intent P0;
    private final CharSequence Q0;
    View.OnFocusChangeListener R0;
    private View.OnClickListener S0;
    private boolean T0;
    private boolean U0;
    ax.p131i0.a V0;
    private boolean W0;
    private CharSequence X0;
    private boolean Y0;
    private boolean Z0;
    private int a1;
    private boolean b1;
    private CharSequence c1;
    private boolean d1;
    private int e1;
    SearchableInfo f1;
    private Bundle g1;
    private final Runnable h1;
    private Runnable i1;
    private final WeakHashMap<String, Drawable.ConstantState> j1;
    final SearchAutoComplete y0;
    private final View z0;

    public static class SearchAutoComplete extends C0594d {
        private int n0;
        private SearchView o0;
        private boolean p0;
        final Runnable q0;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchAutoComplete.this.c();
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, ax.p194m.a.p);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.q0 = new a();
            this.n0 = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        void b() {
            if (Build.VERSION.SDK_INT < 29) {
                SearchView.k1.c(this);
                return;
            }
            a.b(this, 1);
            if (enoughToFilter()) {
                showDropDown();
            }
        }

        void c() {
            if (this.p0) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.p0 = false;
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public boolean enoughToFilter() {
            return this.n0 <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.C0594d, android.widget.TextView, android.view.View
        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.p0) {
                removeCallbacks(this.q0);
                post(this.q0);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        protected void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        protected void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.o0.P();
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.o0.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.o0.hasFocus() && getVisibility() == 0) {
                this.p0 = true;
                if (SearchView.I(getContext())) {
                    b();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        protected void replaceText(CharSequence charSequence) {
        }

        void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.p0 = false;
                removeCallbacks(this.q0);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.p0 = true;
                    return;
                }
                this.p0 = false;
                removeCallbacks(this.q0);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        void setSearchView(SearchView searchView) {
            this.o0 = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i) {
            super.setThreshold(i);
            this.n0 = i;
        }
    }

    static class a {
        static void a(AutoCompleteTextView autoCompleteTextView) {
            autoCompleteTextView.refreshAutoCompleteResults();
        }

        static void b(SearchAutoComplete searchAutoComplete, int i) {
            searchAutoComplete.setInputMethodMode(i);
        }
    }

    public interface b {
    }

    public interface c {
    }

    public interface d {
    }

    private static class e {
        private Method a;
        private Method b;
        private Method c;

        @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
        e() {
            this.a = null;
            this.b = null;
            this.c = null;
            d();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                this.a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                this.b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                this.c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        private static void d() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }

        void a(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.b;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, null);
                } catch (Exception unused) {
                }
            }
        }

        void b(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.a;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, null);
                } catch (Exception unused) {
                }
            }
        }

        void c(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.c;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }
    }

    static class f extends ax.p163k0.a {
        public static final Parcelable.Creator<f> CREATOR = new a();
        boolean Y;

        class a implements Parcelable.ClassLoaderCreator<f> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public f createFromParcel(Parcel parcel) {
                return new f(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public f createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new f(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public f[] newArray(int i) {
                return new f[i];
            }
        }

        public f(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.Y = ((Boolean) parcel.readValue(null)).booleanValue();
        }

        f(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.Y + "}";
        }

        @Override // ax.p163k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeValue(Boolean.valueOf(this.Y));
        }
    }

    private static class g extends TouchDelegate {
        private final View a;
        private final Rect b;
        private final Rect c;
        private final Rect d;
        private final int e;
        private boolean f;

        public g(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            this.b = new Rect();
            this.d = new Rect();
            this.c = new Rect();
            a(rect, rect2);
            this.a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.b.set(rect);
            this.d.set(rect);
            Rect rect3 = this.d;
            int i = this.e;
            rect3.inset(-i, -i);
            this.c.set(rect2);
        }

        /* JADX WARN: Code duplicated, block: B:20:0x003c  */
        @Override // android.view.TouchDelegate
        public boolean onTouchEvent(MotionEvent motionEvent) {
            boolean z;
            boolean z2;
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            int action = motionEvent.getAction();
            boolean z3 = true;
            if (action != 0) {
                if (action == 1 || action == 2) {
                    z2 = this.f;
                    if (z2 && !this.d.contains(x, y)) {
                        z3 = z2;
                        z = false;
                    }
                } else if (action != 3) {
                    z = true;
                    z3 = false;
                } else {
                    z2 = this.f;
                    this.f = false;
                }
                z3 = z2;
                z = true;
            } else if (this.b.contains(x, y)) {
                this.f = true;
                z = true;
            } else {
                z = true;
                z3 = false;
            }
            if (!z3) {
                return false;
            }
            if (!z || this.c.contains(x, y)) {
                Rect rect = this.c;
                motionEvent.setLocation(x - rect.left, y - rect.top);
            } else {
                motionEvent.setLocation(this.a.getWidth() / 2, this.a.getHeight() / 2);
            }
            return this.a.dispatchTouchEvent(motionEvent);
        }
    }

    static {
        k1 = Build.VERSION.SDK_INT < 29 ? new e() : null;
    }

    private Intent B(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.c1);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.g1;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f1.getSearchActivity());
        return intent;
    }

    private void C() {
        this.y0.dismissDropDown();
    }

    private void E(View view, Rect rect) {
        view.getLocationInWindow(this.I0);
        getLocationInWindow(this.J0);
        int[] iArr = this.I0;
        int i = iArr[1];
        int[] iArr2 = this.J0;
        int i2 = i - iArr2[1];
        int i3 = iArr[0] - iArr2[0];
        rect.set(i3, i2, view.getWidth() + i3, view.getHeight() + i2);
    }

    private CharSequence F(CharSequence charSequence) {
        if (!this.T0 || this.L0 == null) {
            return charSequence;
        }
        int textSize = (int) (((double) this.y0.getTextSize()) * 1.25d);
        this.L0.setBounds(0, 0, textSize, textSize);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.L0), 1, 2, 33);
        spannableStringBuilder.append(charSequence);
        return spannableStringBuilder;
    }

    private boolean G() {
        Intent intent;
        SearchableInfo searchableInfo = this.f1;
        if (searchableInfo != null && searchableInfo.getVoiceSearchEnabled()) {
            if (this.f1.getVoiceSearchLaunchWebSearch()) {
                intent = this.O0;
            } else {
                intent = this.f1.getVoiceSearchLaunchRecognizer() ? this.P0 : null;
            }
            if (intent != null && getContext().getPackageManager().resolveActivity(intent, 65536) != null) {
                return true;
            }
        }
        return false;
    }

    static boolean I(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private boolean J() {
        return (this.W0 || this.b1) && !H();
    }

    private void Q() {
        post(this.h1);
    }

    private void S() {
        boolean zIsEmpty = TextUtils.isEmpty(this.y0.getText());
        this.D0.setVisibility(!zIsEmpty || (this.T0 && !this.d1) ? 0 : 8);
        Drawable drawable = this.D0.getDrawable();
        if (drawable != null) {
            drawable.setState(!zIsEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    private void T() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.y0;
        if (queryHint == null) {
            queryHint = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        searchAutoComplete.setHint(F(queryHint));
    }

    private void U() {
        this.y0.setThreshold(this.f1.getSuggestThreshold());
        this.y0.setImeOptions(this.f1.getImeOptions());
        int inputType = this.f1.getInputType();
        if ((inputType & 15) == 1) {
            inputType &= -65537;
            if (this.f1.getSuggestAuthority() != null) {
                inputType |= 589824;
            }
        }
        this.y0.setInputType(inputType);
        ax.p131i0.a aVar = this.V0;
        if (aVar != null) {
            aVar.a(null);
        }
        if (this.f1.getSuggestAuthority() != null) {
            G g2 = new G(getContext(), this, this.f1, this.j1);
            this.V0 = g2;
            this.y0.setAdapter(g2);
            ((G) this.V0).H(this.Y0 ? 2 : 1);
        }
    }

    private void V() {
        this.A0.setVisibility((J() && (this.C0.getVisibility() == 0 || this.E0.getVisibility() == 0)) ? 0 : 8);
    }

    private void W(boolean z) {
        this.C0.setVisibility((this.W0 && J() && hasFocus() && (z || !this.b1)) ? 0 : 8);
    }

    private void X(boolean z) {
        this.U0 = z;
        int i = 8;
        int i2 = z ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.y0.getText());
        this.B0.setVisibility(i2);
        W(!zIsEmpty);
        this.z0.setVisibility(z ? 8 : 0);
        if (this.K0.getDrawable() != null && !this.T0) {
            i = 0;
        }
        this.K0.setVisibility(i);
        S();
        Y(zIsEmpty);
        V();
    }

    private void Y(boolean z) {
        int i = 8;
        if (this.b1 && !H() && z) {
            this.C0.setVisibility(8);
            i = 0;
        }
        this.E0.setVisibility(i);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(ax.p194m.d.e);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(ax.p194m.d.f);
    }

    private void setQuery(CharSequence charSequence) {
        this.y0.setText(charSequence);
        this.y0.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    void D() {
        if (Build.VERSION.SDK_INT >= 29) {
            a.a(this.y0);
            return;
        }
        e eVar = k1;
        eVar.b(this.y0);
        eVar.a(this.y0);
    }

    public boolean H() {
        return this.U0;
    }

    void K(int i, String str, String str2) {
        getContext().startActivity(B("android.intent.action.SEARCH", null, null, str2, i, str));
    }

    void L() {
        if (!TextUtils.isEmpty(this.y0.getText())) {
            this.y0.setText(HttpUrl.FRAGMENT_ENCODE_SET);
            this.y0.requestFocus();
            this.y0.setImeVisibility(true);
        } else if (this.T0) {
            clearFocus();
            X(true);
        }
    }

    protected void M(CharSequence charSequence) {
        setQuery(charSequence);
    }

    void N() {
        X(false);
        this.y0.requestFocus();
        this.y0.setImeVisibility(true);
        View.OnClickListener onClickListener = this.S0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    void O() {
        Editable text = this.y0.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f1 != null) {
            K(0, null, text.toString());
        }
        this.y0.setImeVisibility(false);
        C();
    }

    void P() {
        X(H());
        Q();
        if (this.y0.hasFocus()) {
            D();
        }
    }

    public void R(CharSequence charSequence, boolean z) {
        this.y0.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.y0;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.c1 = charSequence;
        }
        if (!z || TextUtils.isEmpty(charSequence)) {
            return;
        }
        O();
    }

    @Override // ax.p290s.b
    public void c() {
        if (this.d1) {
            return;
        }
        this.d1 = true;
        int imeOptions = this.y0.getImeOptions();
        this.e1 = imeOptions;
        this.y0.setImeOptions(imeOptions | 33554432);
        this.y0.setText(HttpUrl.FRAGMENT_ENCODE_SET);
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void clearFocus() {
        this.Z0 = true;
        super.clearFocus();
        this.y0.clearFocus();
        this.y0.setImeVisibility(false);
        this.Z0 = false;
    }

    @Override // ax.p290s.b
    public void e() {
        R(HttpUrl.FRAGMENT_ENCODE_SET, false);
        clearFocus();
        X(true);
        this.y0.setImeOptions(this.e1);
        this.d1 = false;
    }

    public int getImeOptions() {
        return this.y0.getImeOptions();
    }

    public int getInputType() {
        return this.y0.getInputType();
    }

    public int getMaxWidth() {
        return this.a1;
    }

    public CharSequence getQuery() {
        return this.y0.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.X0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f1;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.Q0 : getContext().getText(this.f1.getHintId());
    }

    int getSuggestionCommitIconResId() {
        return this.N0;
    }

    int getSuggestionRowLayout() {
        return this.M0;
    }

    public ax.p131i0.a getSuggestionsAdapter() {
        return this.V0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.h1);
        post(this.i1);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.B, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            E(this.y0, this.G0);
            Rect rect = this.H0;
            Rect rect2 = this.G0;
            rect.set(rect2.left, 0, rect2.right, i4 - i2);
            g gVar = this.F0;
            if (gVar != null) {
                gVar.a(this.H0, this.G0);
                return;
            }
            g gVar2 = new g(this.H0, this.G0, this.y0);
            this.F0 = gVar2;
            setTouchDelegate(gVar2);
        }
    }

    @Override // androidx.appcompat.widget.B, android.view.View
    protected void onMeasure(int i, int i2) {
        int i3;
        if (H()) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        if (mode == Integer.MIN_VALUE) {
            int i4 = this.a1;
            size = i4 > 0 ? Math.min(i4, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.a1;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i3 = this.a1) > 0) {
            size = Math.min(i3, size);
        }
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof f)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        f fVar = (f) parcelable;
        super.onRestoreInstanceState(fVar.a());
        X(fVar.Y);
        requestLayout();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        f fVar = new f(super.onSaveInstanceState());
        fVar.Y = H();
        return fVar;
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        Q();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean requestFocus(int i, Rect rect) {
        if (this.Z0 || !isFocusable()) {
            return false;
        }
        if (H()) {
            return super.requestFocus(i, rect);
        }
        boolean zRequestFocus = this.y0.requestFocus(i, rect);
        if (zRequestFocus) {
            X(false);
        }
        return zRequestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.g1 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            L();
        } else {
            N();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.T0 == z) {
            return;
        }
        this.T0 = z;
        X(z);
        T();
    }

    public void setImeOptions(int i) {
        this.y0.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.y0.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.a1 = i;
        requestLayout();
    }

    public void setOnCloseListener(b bVar) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.R0 = onFocusChangeListener;
    }

    public void setOnQueryTextListener(c cVar) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.S0 = onClickListener;
    }

    public void setOnSuggestionListener(d dVar) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.X0 = charSequence;
        T();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.Y0 = z;
        ax.p131i0.a aVar = this.V0;
        if (aVar instanceof G) {
            ((G) aVar).H(z ? 2 : 1);
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f1 = searchableInfo;
        if (searchableInfo != null) {
            U();
            T();
        }
        boolean zG = G();
        this.b1 = zG;
        if (zG) {
            this.y0.setPrivateImeOptions("nm");
        }
        X(H());
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.W0 = z;
        X(H());
    }

    public void setSuggestionsAdapter(ax.p131i0.a aVar) {
        this.V0 = aVar;
        this.y0.setAdapter(aVar);
    }
}
