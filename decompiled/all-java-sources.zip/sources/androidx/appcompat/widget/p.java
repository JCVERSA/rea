package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* JADX INFO: loaded from: classes.dex */
public class p extends ImageButton {
    private final q h0;
    private boolean i0;
    private final C0552e q;

    public p(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.E);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.b();
        }
        q qVar = this.h0;
        if (qVar != null) {
            qVar.c();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.d();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        q qVar = this.h0;
        if (qVar != null) {
            return qVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        q qVar = this.h0;
        if (qVar != null) {
            return qVar.e();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.h0.f() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.g(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        q qVar = this.h0;
        if (qVar != null) {
            qVar.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        q qVar = this.h0;
        if (qVar != null && drawable != null && !this.i0) {
            qVar.h(drawable);
        }
        super.setImageDrawable(drawable);
        q qVar2 = this.h0;
        if (qVar2 != null) {
            qVar2.c();
            if (this.i0) {
                return;
            }
            this.h0.b();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.i0 = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        this.h0.i(i);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        q qVar = this.h0;
        if (qVar != null) {
            qVar.c();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.j(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        q qVar = this.h0;
        if (qVar != null) {
            qVar.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        q qVar = this.h0;
        if (qVar != null) {
            qVar.k(mode);
        }
    }

    public p(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        this.i0 = false;
        H.a(this, getContext());
        C0552e c0552e = new C0552e(this);
        this.q = c0552e;
        c0552e.e(attributeSet, i);
        q qVar = new q(this);
        this.h0 = qVar;
        qVar.g(attributeSet, i);
    }
}
