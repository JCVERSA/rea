package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* JADX INFO: loaded from: classes.dex */
public class p extends ImageButton {
    private final q k0;
    private boolean l0;
    private final C0595e q;

    public p(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.G);
    }

    public p(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        this.l0 = false;
        H.a(this, getContext());
        C0595e c0595e = new C0595e(this);
        this.q = c0595e;
        c0595e.e(attributeSet, i);
        q qVar = new q(this);
        this.k0 = qVar;
        qVar.g(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.b();
        }
        q qVar = this.k0;
        if (qVar != null) {
            qVar.c();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.d();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        q qVar = this.k0;
        if (qVar != null) {
            return qVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        q qVar = this.k0;
        if (qVar != null) {
            return qVar.e();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.k0.f() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.g(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        q qVar = this.k0;
        if (qVar != null) {
            qVar.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        q qVar = this.k0;
        if (qVar != null && drawable != null && !this.l0) {
            qVar.h(drawable);
        }
        super.setImageDrawable(drawable);
        q qVar2 = this.k0;
        if (qVar2 != null) {
            qVar2.c();
            if (this.l0) {
                return;
            }
            this.k0.b();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i) {
        super.setImageLevel(i);
        this.l0 = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        this.k0.i(i);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        q qVar = this.k0;
        if (qVar != null) {
            qVar.c();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.j(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        q qVar = this.k0;
        if (qVar != null) {
            qVar.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        q qVar = this.k0;
        if (qVar != null) {
            qVar.k(mode);
        }
    }
}
