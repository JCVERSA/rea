package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import ax.p035c0.C1839d0;
import ax.p035c0.C1869t;

/* JADX INFO: loaded from: classes.dex */
public class B extends ViewGroup {
    private int k0;
    private int l0;
    private int m0;
    private int n0;
    private int o0;
    private float p0;
    private boolean q;
    private boolean q0;
    private int[] r0;
    private int[] s0;
    private Drawable t0;
    private int u0;
    private int v0;
    private int w0;
    private int x0;

    public static class a extends LinearLayout.LayoutParams {
        public a(int i, int i2) {
            super(i, i2);
        }

        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    public B(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public B(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q = true;
        this.k0 = -1;
        this.l0 = 0;
        this.n0 = 8388659;
        int[] iArr = ax.p194m.j.i1;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        C1839d0.j0(this, context, iArr, attributeSet, lV.r(), i, 0);
        int iK = lV.k(ax.p194m.j.k1, -1);
        if (iK >= 0) {
            setOrientation(iK);
        }
        int iK2 = lV.k(ax.p194m.j.j1, -1);
        if (iK2 >= 0) {
            setGravity(iK2);
        }
        boolean zA = lV.a(ax.p194m.j.l1, true);
        if (!zA) {
            setBaselineAligned(zA);
        }
        this.p0 = lV.i(ax.p194m.j.n1, -1.0f);
        this.k0 = lV.k(ax.p194m.j.m1, -1);
        this.q0 = lV.a(ax.p194m.j.q1, false);
        setDividerDrawable(lV.g(ax.p194m.j.o1));
        this.w0 = lV.k(ax.p194m.j.r1, 0);
        this.x0 = lV.f(ax.p194m.j.p1, 0);
        lV.x();
    }

    private void A(View view, int i, int i2, int i3, int i4) {
        view.layout(i, i2, i3 + i, i4 + i2);
    }

    /* JADX WARN: Code duplicated, block: B:9:0x0036  */
    private void k(int i, int i2) {
        int i3;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        int i4 = 0;
        while (i4 < i) {
            View viewS = s(i4);
            if (viewS.getVisibility() != 8) {
                a aVar = (a) viewS.getLayoutParams();
                if (((LinearLayout.LayoutParams) aVar).height == -1) {
                    int i5 = ((LinearLayout.LayoutParams) aVar).width;
                    ((LinearLayout.LayoutParams) aVar).width = viewS.getMeasuredWidth();
                    i3 = i2;
                    measureChildWithMargins(viewS, i3, 0, iMakeMeasureSpec, 0);
                    ((LinearLayout.LayoutParams) aVar).width = i5;
                } else {
                    i3 = i2;
                }
            } else {
                i3 = i2;
            }
            i4++;
            i2 = i3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:9:0x0036  */
    private void l(int i, int i2) {
        int i3;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        int i4 = 0;
        while (i4 < i) {
            View viewS = s(i4);
            if (viewS.getVisibility() != 8) {
                a aVar = (a) viewS.getLayoutParams();
                if (((LinearLayout.LayoutParams) aVar).width == -1) {
                    int i5 = ((LinearLayout.LayoutParams) aVar).height;
                    ((LinearLayout.LayoutParams) aVar).height = viewS.getMeasuredHeight();
                    i3 = i2;
                    measureChildWithMargins(viewS, iMakeMeasureSpec, 0, i3, 0);
                    ((LinearLayout.LayoutParams) aVar).height = i5;
                } else {
                    i3 = i2;
                }
            } else {
                i3 = i2;
            }
            i4++;
            i2 = i3;
        }
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof a;
    }

    void g(Canvas canvas) {
        int right;
        int left;
        int i;
        int virtualChildCount = getVirtualChildCount();
        boolean zB = O.b(this);
        for (int i2 = 0; i2 < virtualChildCount; i2++) {
            View viewS = s(i2);
            if (viewS != null && viewS.getVisibility() != 8 && t(i2)) {
                a aVar = (a) viewS.getLayoutParams();
                j(canvas, zB ? viewS.getRight() + ((LinearLayout.LayoutParams) aVar).rightMargin : (viewS.getLeft() - ((LinearLayout.LayoutParams) aVar).leftMargin) - this.u0);
            }
        }
        if (t(virtualChildCount)) {
            View viewS2 = s(virtualChildCount - 1);
            if (viewS2 != null) {
                a aVar2 = (a) viewS2.getLayoutParams();
                if (zB) {
                    left = viewS2.getLeft() - ((LinearLayout.LayoutParams) aVar2).leftMargin;
                    i = this.u0;
                    right = left - i;
                } else {
                    right = viewS2.getRight() + ((LinearLayout.LayoutParams) aVar2).rightMargin;
                }
            } else if (zB) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i = this.u0;
                right = left - i;
            }
            j(canvas, right);
        }
    }

    @Override // android.view.View
    public int getBaseline() {
        int i;
        if (this.k0 < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i2 = this.k0;
        if (childCount <= i2) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i2);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.k0 == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int bottom = this.l0;
        if (this.m0 == 1 && (i = this.n0 & 112) != 48) {
            if (i == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.o0) / 2;
            } else if (i == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.o0;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((a) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.k0;
    }

    public Drawable getDividerDrawable() {
        return this.t0;
    }

    public int getDividerPadding() {
        return this.x0;
    }

    public int getDividerWidth() {
        return this.u0;
    }

    public int getGravity() {
        return this.n0;
    }

    public int getOrientation() {
        return this.m0;
    }

    public int getShowDividers() {
        return this.w0;
    }

    int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.p0;
    }

    void h(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        for (int i = 0; i < virtualChildCount; i++) {
            View viewS = s(i);
            if (viewS != null && viewS.getVisibility() != 8 && t(i)) {
                i(canvas, (viewS.getTop() - ((LinearLayout.LayoutParams) ((a) viewS.getLayoutParams())).topMargin) - this.v0);
            }
        }
        if (t(virtualChildCount)) {
            View viewS2 = s(virtualChildCount - 1);
            i(canvas, viewS2 == null ? (getHeight() - getPaddingBottom()) - this.v0 : viewS2.getBottom() + ((LinearLayout.LayoutParams) ((a) viewS2.getLayoutParams())).bottomMargin);
        }
    }

    void i(Canvas canvas, int i) {
        this.t0.setBounds(getPaddingLeft() + this.x0, i, (getWidth() - getPaddingRight()) - this.x0, this.v0 + i);
        this.t0.draw(canvas);
    }

    void j(Canvas canvas, int i) {
        this.t0.setBounds(i, getPaddingTop() + this.x0, this.u0 + i, (getHeight() - getPaddingBottom()) - this.x0);
        this.t0.draw(canvas);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public a generateDefaultLayoutParams() {
        int i = this.m0;
        if (i == 0) {
            return new a(-2, -2);
        }
        if (i == 1) {
            return new a(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public a generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public a generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof a) {
            return new a((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new a((ViewGroup.MarginLayoutParams) layoutParams) : new a(layoutParams);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.t0 == null) {
            return;
        }
        if (this.m0 == 1) {
            h(canvas);
        } else {
            g(canvas);
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.m0 == 1) {
            v(i, i2, i3, i4);
        } else {
            u(i, i2, i3, i4);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        if (this.m0 == 1) {
            z(i, i2);
        } else {
            x(i, i2);
        }
    }

    int p(View view, int i) {
        return 0;
    }

    int q(View view) {
        return 0;
    }

    int r(View view) {
        return 0;
    }

    View s(int i) {
        return getChildAt(i);
    }

    public void setBaselineAligned(boolean z) {
        this.q = z;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i >= 0 && i < getChildCount()) {
            this.k0 = i;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.t0) {
            return;
        }
        this.t0 = drawable;
        if (drawable != null) {
            this.u0 = drawable.getIntrinsicWidth();
            this.v0 = drawable.getIntrinsicHeight();
        } else {
            this.u0 = 0;
            this.v0 = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i) {
        this.x0 = i;
    }

    public void setGravity(int i) {
        if (this.n0 != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.n0 = i;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        int i2 = i & 8388615;
        int i3 = this.n0;
        if ((8388615 & i3) != i2) {
            this.n0 = i2 | ((-8388616) & i3);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        this.q0 = z;
    }

    public void setOrientation(int i) {
        if (this.m0 != i) {
            this.m0 = i;
            requestLayout();
        }
    }

    public void setShowDividers(int i) {
        if (i != this.w0) {
            requestLayout();
        }
        this.w0 = i;
    }

    public void setVerticalGravity(int i) {
        int i2 = i & 112;
        int i3 = this.n0;
        if ((i3 & 112) != i2) {
            this.n0 = i2 | (i3 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f) {
        this.p0 = Math.max(0.0f, f);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    protected boolean t(int i) {
        if (i == 0) {
            return (this.w0 & 1) != 0;
        }
        if (i == getChildCount()) {
            return (this.w0 & 4) != 0;
        }
        if ((this.w0 & 2) != 0) {
            for (int i2 = i - 1; i2 >= 0; i2--) {
                if (getChildAt(i2).getVisibility() != 8) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:32:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:36:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:37:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:39:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:41:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:43:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:44:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:47:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:48:0x0103  */
    void u(int i, int i2, int i3, int i4) {
        int paddingLeft;
        int i5;
        int i6;
        int i7;
        int iP;
        int i8;
        int baseline;
        int i9;
        int i10;
        int i11;
        int measuredHeight;
        int i12;
        boolean zB = O.b(this);
        int paddingTop = getPaddingTop();
        int i13 = i4 - i2;
        int paddingBottom = i13 - getPaddingBottom();
        int paddingBottom2 = (i13 - paddingTop) - getPaddingBottom();
        int virtualChildCount = getVirtualChildCount();
        int i14 = this.n0;
        int i15 = i14 & 112;
        boolean z = this.q;
        int[] iArr = this.r0;
        int[] iArr2 = this.s0;
        int iB = C1869t.b(8388615 & i14, getLayoutDirection());
        if (iB != 1) {
            paddingLeft = iB != 5 ? getPaddingLeft() : ((getPaddingLeft() + i3) - i) - this.o0;
        } else {
            paddingLeft = getPaddingLeft() + (((i3 - i) - this.o0) / 2);
        }
        if (zB) {
            i5 = virtualChildCount - 1;
            i6 = -1;
        } else {
            i5 = 0;
            i6 = 1;
        }
        int i16 = 0;
        while (i16 < virtualChildCount) {
            int i17 = i5 + (i6 * i16);
            int i18 = i16;
            View viewS = s(i17);
            if (viewS == null) {
                paddingLeft += y(i17);
                iP = i18;
                i7 = paddingTop;
            } else if (viewS.getVisibility() != 8) {
                int measuredWidth = viewS.getMeasuredWidth();
                int measuredHeight2 = viewS.getMeasuredHeight();
                a aVar = (a) viewS.getLayoutParams();
                int i19 = paddingLeft;
                if (z) {
                    i8 = measuredHeight2;
                    baseline = ((LinearLayout.LayoutParams) aVar).height != -1 ? viewS.getBaseline() : -1;
                    i9 = ((LinearLayout.LayoutParams) aVar).gravity;
                    if (i9 < 0) {
                        i9 = i15;
                    }
                    i10 = i9 & 112;
                    i7 = paddingTop;
                    if (i10 != 16) {
                        if (i10 != 48) {
                            i11 = i7 + ((LinearLayout.LayoutParams) aVar).topMargin;
                            if (baseline != -1) {
                                i11 += iArr[1] - baseline;
                            }
                        } else if (i10 != 80) {
                            i11 = i7;
                        } else {
                            i11 = (paddingBottom - i8) - ((LinearLayout.LayoutParams) aVar).bottomMargin;
                            if (baseline != -1) {
                                measuredHeight = iArr2[2] - (viewS.getMeasuredHeight() - baseline);
                            }
                        }
                        if (t(i17)) {
                            i12 = i19 + this.u0;
                        } else {
                            i12 = i19;
                        }
                        int i20 = ((LinearLayout.LayoutParams) aVar).leftMargin + i12;
                        A(viewS, q(viewS) + i20, i11, measuredWidth, i8);
                        int iR = i20 + ((LinearLayout.LayoutParams) aVar).rightMargin + measuredWidth + r(viewS);
                        iP = p(viewS, i17) + i18;
                        paddingLeft = iR;
                    } else {
                        i11 = i7 + ((paddingBottom2 - i8) / 2) + ((LinearLayout.LayoutParams) aVar).topMargin;
                        measuredHeight = ((LinearLayout.LayoutParams) aVar).bottomMargin;
                    }
                    i11 -= measuredHeight;
                    if (t(i17)) {
                        i12 = i19 + this.u0;
                    } else {
                        i12 = i19;
                    }
                    int i21 = ((LinearLayout.LayoutParams) aVar).leftMargin + i12;
                    A(viewS, q(viewS) + i21, i11, measuredWidth, i8);
                    int iR2 = i21 + ((LinearLayout.LayoutParams) aVar).rightMargin + measuredWidth + r(viewS);
                    iP = p(viewS, i17) + i18;
                    paddingLeft = iR2;
                } else {
                    i8 = measuredHeight2;
                }
                i9 = ((LinearLayout.LayoutParams) aVar).gravity;
                if (i9 < 0) {
                    i9 = i15;
                }
                i10 = i9 & 112;
                i7 = paddingTop;
                if (i10 != 16) {
                    if (i10 != 48) {
                        i11 = i7 + ((LinearLayout.LayoutParams) aVar).topMargin;
                        if (baseline != -1) {
                            i11 += iArr[1] - baseline;
                        }
                    } else if (i10 != 80) {
                        i11 = i7;
                    } else {
                        i11 = (paddingBottom - i8) - ((LinearLayout.LayoutParams) aVar).bottomMargin;
                        if (baseline != -1) {
                            measuredHeight = iArr2[2] - (viewS.getMeasuredHeight() - baseline);
                        }
                    }
                    if (t(i17)) {
                        i12 = i19 + this.u0;
                    } else {
                        i12 = i19;
                    }
                    int i22 = ((LinearLayout.LayoutParams) aVar).leftMargin + i12;
                    A(viewS, q(viewS) + i22, i11, measuredWidth, i8);
                    int iR3 = i22 + ((LinearLayout.LayoutParams) aVar).rightMargin + measuredWidth + r(viewS);
                    iP = p(viewS, i17) + i18;
                    paddingLeft = iR3;
                } else {
                    i11 = i7 + ((paddingBottom2 - i8) / 2) + ((LinearLayout.LayoutParams) aVar).topMargin;
                    measuredHeight = ((LinearLayout.LayoutParams) aVar).bottomMargin;
                }
                i11 -= measuredHeight;
                if (t(i17)) {
                    i12 = i19 + this.u0;
                } else {
                    i12 = i19;
                }
                int i23 = ((LinearLayout.LayoutParams) aVar).leftMargin + i12;
                A(viewS, q(viewS) + i23, i11, measuredWidth, i8);
                int iR4 = i23 + ((LinearLayout.LayoutParams) aVar).rightMargin + measuredWidth + r(viewS);
                iP = p(viewS, i17) + i18;
                paddingLeft = iR4;
            } else {
                i7 = paddingTop;
                iP = i18;
            }
            i16 = iP + 1;
            paddingTop = i7;
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0099  */
    void v(int i, int i2, int i3, int i4) {
        int paddingTop;
        int i5;
        int i6;
        int i7;
        int paddingLeft = getPaddingLeft();
        int i8 = i3 - i;
        int paddingRight = i8 - getPaddingRight();
        int paddingRight2 = (i8 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        int i9 = this.n0;
        int i10 = i9 & 112;
        int i11 = i9 & 8388615;
        if (i10 != 16) {
            paddingTop = i10 != 80 ? getPaddingTop() : ((getPaddingTop() + i4) - i2) - this.o0;
        } else {
            paddingTop = getPaddingTop() + (((i4 - i2) - this.o0) / 2);
        }
        int iP = 0;
        while (iP < virtualChildCount) {
            View viewS = s(iP);
            if (viewS == null) {
                paddingTop += y(iP);
            } else {
                if (viewS.getVisibility() != 8) {
                    int measuredWidth = viewS.getMeasuredWidth();
                    int measuredHeight = viewS.getMeasuredHeight();
                    a aVar = (a) viewS.getLayoutParams();
                    int i12 = ((LinearLayout.LayoutParams) aVar).gravity;
                    if (i12 < 0) {
                        i12 = i11;
                    }
                    int iB = C1869t.b(i12, getLayoutDirection()) & 7;
                    if (iB != 1) {
                        if (iB != 5) {
                            i7 = ((LinearLayout.LayoutParams) aVar).leftMargin + paddingLeft;
                        } else {
                            i5 = paddingRight - measuredWidth;
                            i6 = ((LinearLayout.LayoutParams) aVar).rightMargin;
                        }
                        int i13 = i7;
                        if (t(iP)) {
                            paddingTop += this.v0;
                        }
                        int i14 = paddingTop + ((LinearLayout.LayoutParams) aVar).topMargin;
                        A(viewS, i13, i14 + q(viewS), measuredWidth, measuredHeight);
                        paddingTop = i14 + measuredHeight + ((LinearLayout.LayoutParams) aVar).bottomMargin + r(viewS);
                        iP += p(viewS, iP);
                    } else {
                        i5 = ((paddingRight2 - measuredWidth) / 2) + paddingLeft + ((LinearLayout.LayoutParams) aVar).leftMargin;
                        i6 = ((LinearLayout.LayoutParams) aVar).rightMargin;
                    }
                    i7 = i5 - i6;
                    int i15 = i7;
                    if (t(iP)) {
                        paddingTop += this.v0;
                    }
                    int i16 = paddingTop + ((LinearLayout.LayoutParams) aVar).topMargin;
                    A(viewS, i15, i16 + q(viewS), measuredWidth, measuredHeight);
                    paddingTop = i16 + measuredHeight + ((LinearLayout.LayoutParams) aVar).bottomMargin + r(viewS);
                    iP += p(viewS, iP);
                }
                iP++;
            }
            iP++;
        }
    }

    void w(View view, int i, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    /* JADX WARN: Code duplicated, block: B:200:0x045a  */
    /* JADX WARN: Code duplicated, block: B:60:0x017e  */
    /* JADX WARN: Code duplicated, block: B:69:0x01c1  */
    /* JADX WARN: Code duplicated, block: B:75:0x01d1  */
    /* JADX WARN: Code duplicated, block: B:78:0x01d9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:79:0x01db  */
    /* JADX WARN: Code duplicated, block: B:81:0x01e2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:82:0x01e4  */
    void x(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int iMax;
        int i8;
        int iMax2;
        int i9;
        int baseline;
        int i10;
        int i11;
        int i12;
        int i13;
        int[] iArr;
        int[] iArr2;
        int i14;
        boolean z;
        View view;
        int i15;
        boolean z2;
        int i16;
        int measuredHeight;
        int baseline2;
        this.o0 = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        if (this.r0 == null || this.s0 == null) {
            this.r0 = new int[4];
            this.s0 = new int[4];
        }
        int[] iArr3 = this.r0;
        int[] iArr4 = this.s0;
        iArr3[3] = -1;
        iArr3[2] = -1;
        iArr3[1] = -1;
        iArr3[0] = -1;
        iArr4[3] = -1;
        iArr4[2] = -1;
        iArr4[1] = -1;
        iArr4[0] = -1;
        boolean z3 = this.q;
        boolean z4 = this.q0;
        int i17 = 1073741824;
        boolean z5 = mode == 1073741824;
        boolean z6 = z4;
        int iP = 0;
        float f = 0.0f;
        int iMax3 = 0;
        int iMax4 = 0;
        int iMax5 = 0;
        int iMax6 = 0;
        boolean z7 = false;
        int iCombineMeasuredStates = 0;
        boolean z8 = true;
        boolean z9 = false;
        while (true) {
            i3 = iMax3;
            if (iP >= virtualChildCount) {
                break;
            }
            boolean z10 = z3;
            View viewS = s(iP);
            if (viewS == null) {
                this.o0 += y(iP);
            } else {
                if (viewS.getVisibility() == 8) {
                    iP += p(viewS, iP);
                } else {
                    if (t(iP)) {
                        this.o0 += this.u0;
                    }
                    a aVar = (a) viewS.getLayoutParams();
                    float f2 = ((LinearLayout.LayoutParams) aVar).weight;
                    float f3 = f + f2;
                    if (mode == i17 && ((LinearLayout.LayoutParams) aVar).width == 0 && f2 > 0.0f) {
                        if (z5) {
                            this.o0 += ((LinearLayout.LayoutParams) aVar).leftMargin + ((LinearLayout.LayoutParams) aVar).rightMargin;
                        } else {
                            int i18 = this.o0;
                            this.o0 = Math.max(i18, ((LinearLayout.LayoutParams) aVar).leftMargin + i18 + ((LinearLayout.LayoutParams) aVar).rightMargin);
                        }
                        if (z10) {
                            int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                            viewS.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                            i13 = mode;
                            iArr = iArr3;
                            iArr2 = iArr4;
                            i14 = i3;
                            z = z6;
                            view = viewS;
                        } else {
                            i13 = mode;
                            iArr = iArr3;
                            iArr2 = iArr4;
                            i14 = i3;
                            i15 = 1073741824;
                            z7 = true;
                            z = z6;
                            view = viewS;
                        }
                        if (mode2 == i15 && ((LinearLayout.LayoutParams) aVar).height == -1) {
                            z2 = true;
                            z9 = true;
                        } else {
                            z2 = false;
                        }
                        i16 = ((LinearLayout.LayoutParams) aVar).topMargin + ((LinearLayout.LayoutParams) aVar).bottomMargin;
                        measuredHeight = view.getMeasuredHeight() + i16;
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        if (!z10 && (baseline2 = view.getBaseline()) != -1) {
                            int i19 = ((LinearLayout.LayoutParams) aVar).gravity;
                            if (i19 < 0) {
                                i19 = this.n0;
                            }
                            int i20 = (((i19 & 112) >> 4) & (-2)) >> 1;
                            iArr[i20] = Math.max(iArr[i20], baseline2);
                            iArr2[i20] = Math.max(iArr2[i20], measuredHeight - baseline2);
                        }
                        iMax3 = Math.max(i14, measuredHeight);
                        if (z8 || ((LinearLayout.LayoutParams) aVar).height != -1) {
                            z8 = false;
                        } else {
                            z8 = true;
                        }
                        if (((LinearLayout.LayoutParams) aVar).weight > 0.0f) {
                            if (z2) {
                                measuredHeight = i16;
                            }
                            iMax5 = Math.max(iMax5, measuredHeight);
                        } else {
                            if (z2 != 0) {
                                measuredHeight = i16;
                            }
                            iMax4 = Math.max(iMax4, measuredHeight);
                        }
                        iP += p(view, iP);
                        f = f3;
                    } else {
                        if (((LinearLayout.LayoutParams) aVar).width != 0 || f2 <= 0.0f) {
                            i12 = Integer.MIN_VALUE;
                        } else {
                            ((LinearLayout.LayoutParams) aVar).width = -2;
                            i12 = 0;
                        }
                        i13 = mode;
                        iArr = iArr3;
                        iArr2 = iArr4;
                        i14 = i3;
                        int i21 = i12;
                        z = z6;
                        w(viewS, iP, i, f3 == 0.0f ? this.o0 : 0, i2, 0);
                        view = viewS;
                        if (i21 != Integer.MIN_VALUE) {
                            ((LinearLayout.LayoutParams) aVar).width = i21;
                        }
                        int measuredWidth = view.getMeasuredWidth();
                        if (z5) {
                            this.o0 += ((LinearLayout.LayoutParams) aVar).leftMargin + measuredWidth + ((LinearLayout.LayoutParams) aVar).rightMargin + r(view);
                        } else {
                            int i22 = this.o0;
                            this.o0 = Math.max(i22, i22 + measuredWidth + ((LinearLayout.LayoutParams) aVar).leftMargin + ((LinearLayout.LayoutParams) aVar).rightMargin + r(view));
                        }
                        if (z) {
                            iMax6 = Math.max(measuredWidth, iMax6);
                        }
                    }
                    i15 = 1073741824;
                    if (mode2 == i15) {
                        z2 = false;
                    } else {
                        z2 = false;
                    }
                    i16 = ((LinearLayout.LayoutParams) aVar).topMargin + ((LinearLayout.LayoutParams) aVar).bottomMargin;
                    measuredHeight = view.getMeasuredHeight() + i16;
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    if (!z10) {
                    }
                    iMax3 = Math.max(i14, measuredHeight);
                    if (z8) {
                        z8 = false;
                    } else {
                        z8 = false;
                    }
                    if (((LinearLayout.LayoutParams) aVar).weight > 0.0f) {
                        if (z2) {
                            measuredHeight = i16;
                        }
                        iMax5 = Math.max(iMax5, measuredHeight);
                    } else {
                        if (z2 != 0) {
                            measuredHeight = i16;
                        }
                        iMax4 = Math.max(iMax4, measuredHeight);
                    }
                    iP += p(view, iP);
                    f = f3;
                }
                iP++;
                z6 = z;
                iArr4 = iArr2;
                z3 = z10;
                iArr3 = iArr;
                mode = i13;
                i17 = 1073741824;
            }
            i13 = mode;
            iArr = iArr3;
            iArr2 = iArr4;
            iMax3 = i3;
            z = z6;
            iP++;
            z6 = z;
            iArr4 = iArr2;
            z3 = z10;
            iArr3 = iArr;
            mode = i13;
            i17 = 1073741824;
        }
        boolean z11 = z3;
        int i23 = mode;
        int[] iArr5 = iArr3;
        int[] iArr6 = iArr4;
        int i24 = iCombineMeasuredStates;
        boolean z12 = z6;
        if (this.o0 > 0 && t(virtualChildCount)) {
            this.o0 += this.u0;
        }
        int i25 = iArr5[1];
        int iMax7 = (i25 == -1 && iArr5[0] == -1 && iArr5[2] == -1 && iArr5[3] == -1) ? i3 : Math.max(i3, Math.max(iArr5[3], Math.max(iArr5[0], Math.max(i25, iArr5[2]))) + Math.max(iArr6[3], Math.max(iArr6[0], Math.max(iArr6[1], iArr6[2]))));
        if (z12) {
            i5 = i23;
            if (i5 == Integer.MIN_VALUE || i5 == 0) {
                this.o0 = 0;
                int iP2 = 0;
                while (iP2 < virtualChildCount) {
                    View viewS2 = s(iP2);
                    if (viewS2 == null) {
                        this.o0 += y(iP2);
                    } else {
                        if (viewS2.getVisibility() == 8) {
                            iP2 += p(viewS2, iP2);
                        } else {
                            a aVar2 = (a) viewS2.getLayoutParams();
                            if (z5) {
                                this.o0 += ((LinearLayout.LayoutParams) aVar2).leftMargin + iMax6 + ((LinearLayout.LayoutParams) aVar2).rightMargin + r(viewS2);
                            } else {
                                iMax7 = iMax7;
                                int i26 = this.o0;
                                this.o0 = Math.max(i26, i26 + iMax6 + ((LinearLayout.LayoutParams) aVar2).leftMargin + ((LinearLayout.LayoutParams) aVar2).rightMargin + r(viewS2));
                            }
                        }
                        iP2++;
                        iMax7 = iMax7;
                        f = f;
                    }
                    iP2++;
                    iMax7 = iMax7;
                    f = f;
                }
            }
            i4 = iMax7;
        } else {
            i4 = iMax7;
            i5 = i23;
        }
        float f4 = f;
        int paddingLeft = this.o0 + getPaddingLeft() + getPaddingRight();
        this.o0 = paddingLeft;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingLeft, getSuggestedMinimumWidth()), i, 0);
        int i27 = (16777215 & iResolveSizeAndState) - this.o0;
        if (z7 || (i27 != 0 && f4 > 0.0f)) {
            float f5 = this.p0;
            if (f5 > 0.0f) {
                f4 = f5;
            }
            iArr5[3] = -1;
            iArr5[2] = -1;
            iArr5[1] = -1;
            iArr5[0] = -1;
            iArr6[3] = -1;
            iArr6[2] = -1;
            iArr6[1] = -1;
            iArr6[0] = -1;
            this.o0 = 0;
            int iCombineMeasuredStates2 = i24;
            int iMax8 = -1;
            int i28 = 0;
            while (i28 < virtualChildCount) {
                View viewS3 = s(i28);
                if (viewS3 == null || viewS3.getVisibility() == 8) {
                    iResolveSizeAndState = iResolveSizeAndState;
                } else {
                    a aVar3 = (a) viewS3.getLayoutParams();
                    float f6 = ((LinearLayout.LayoutParams) aVar3).weight;
                    if (f6 > 0.0f) {
                        int i29 = (int) ((i27 * f6) / f4);
                        f4 -= f6;
                        i27 -= i29;
                        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingTop() + getPaddingBottom() + ((LinearLayout.LayoutParams) aVar3).topMargin + ((LinearLayout.LayoutParams) aVar3).bottomMargin, ((LinearLayout.LayoutParams) aVar3).height);
                        if (((LinearLayout.LayoutParams) aVar3).width == 0) {
                            i11 = 1073741824;
                            if (i5 == 1073741824) {
                                if (i29 <= 0) {
                                    i29 = 0;
                                }
                                viewS3.measure(View.MeasureSpec.makeMeasureSpec(i29, 1073741824), childMeasureSpec);
                            }
                            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, viewS3.getMeasuredState() & (-16777216));
                        } else {
                            i11 = 1073741824;
                        }
                        int measuredWidth2 = viewS3.getMeasuredWidth() + i29;
                        if (measuredWidth2 < 0) {
                            measuredWidth2 = 0;
                        }
                        viewS3.measure(View.MeasureSpec.makeMeasureSpec(measuredWidth2, i11), childMeasureSpec);
                        iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, viewS3.getMeasuredState() & (-16777216));
                    }
                    if (z5) {
                        this.o0 += viewS3.getMeasuredWidth() + ((LinearLayout.LayoutParams) aVar3).leftMargin + ((LinearLayout.LayoutParams) aVar3).rightMargin + r(viewS3);
                    } else {
                        int i30 = this.o0;
                        this.o0 = Math.max(i30, viewS3.getMeasuredWidth() + i30 + ((LinearLayout.LayoutParams) aVar3).leftMargin + ((LinearLayout.LayoutParams) aVar3).rightMargin + r(viewS3));
                    }
                    boolean z13 = mode2 != 1073741824 && ((LinearLayout.LayoutParams) aVar3).height == -1;
                    int i31 = ((LinearLayout.LayoutParams) aVar3).topMargin + ((LinearLayout.LayoutParams) aVar3).bottomMargin;
                    int measuredHeight2 = viewS3.getMeasuredHeight() + i31;
                    iMax8 = Math.max(iMax8, measuredHeight2);
                    if (!z13) {
                        i31 = measuredHeight2;
                    }
                    int iMax9 = Math.max(iMax4, i31);
                    if (z8) {
                        i9 = -1;
                        boolean z14 = ((LinearLayout.LayoutParams) aVar3).height == -1;
                        if (z11 && (baseline = viewS3.getBaseline()) != i9) {
                            i10 = ((LinearLayout.LayoutParams) aVar3).gravity;
                            if (i10 < 0) {
                                i10 = this.n0;
                            }
                            int i32 = (((i10 & 112) >> 4) & (-2)) >> 1;
                            iArr5[i32] = Math.max(iArr5[i32], baseline);
                            iArr6[i32] = Math.max(iArr6[i32], measuredHeight2 - baseline);
                        }
                        iMax4 = iMax9;
                        z8 = z14;
                    } else {
                        i9 = -1;
                    }
                    if (z11) {
                        i10 = ((LinearLayout.LayoutParams) aVar3).gravity;
                        if (i10 < 0) {
                            i10 = this.n0;
                        }
                        int i33 = (((i10 & 112) >> 4) & (-2)) >> 1;
                        iArr5[i33] = Math.max(iArr5[i33], baseline);
                        iArr6[i33] = Math.max(iArr6[i33], measuredHeight2 - baseline);
                    }
                    iMax4 = iMax9;
                    z8 = z14;
                }
                i28++;
                iResolveSizeAndState = iResolveSizeAndState;
            }
            i6 = iResolveSizeAndState;
            i7 = -16777216;
            this.o0 += getPaddingLeft() + getPaddingRight();
            int i34 = iArr5[1];
            iMax = (i34 == -1 && iArr5[0] == -1 && iArr5[2] == -1 && iArr5[3] == -1) ? iMax8 : Math.max(iMax8, Math.max(iArr5[3], Math.max(iArr5[0], Math.max(i34, iArr5[2]))) + Math.max(iArr6[3], Math.max(iArr6[0], Math.max(iArr6[1], iArr6[2]))));
            i8 = iCombineMeasuredStates2;
            iMax2 = iMax4;
        } else {
            iMax2 = Math.max(iMax4, iMax5);
            if (z12 && i5 != 1073741824) {
                for (int i35 = 0; i35 < virtualChildCount; i35++) {
                    View viewS4 = s(i35);
                    if (viewS4 != null && viewS4.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((a) viewS4.getLayoutParams())).weight > 0.0f) {
                        viewS4.measure(View.MeasureSpec.makeMeasureSpec(iMax6, 1073741824), View.MeasureSpec.makeMeasureSpec(viewS4.getMeasuredHeight(), 1073741824));
                    }
                }
            }
            i6 = iResolveSizeAndState;
            i8 = i24;
            iMax = i4;
            i7 = -16777216;
        }
        if (!z8 && mode2 != 1073741824) {
            iMax = iMax2;
        }
        setMeasuredDimension(i6 | (i8 & i7), View.resolveSizeAndState(Math.max(iMax + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i2, i8 << 16));
        if (z9) {
            k(virtualChildCount, i);
        }
    }

    int y(int i) {
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:64:0x0157 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:66:0x015a  */
    /* JADX WARN: Code duplicated, block: B:68:0x0161 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:70:0x0164  */
    void z(int i, int i2) {
        int i3;
        int iMax;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        boolean z;
        int iMax2;
        View view;
        int iMax3;
        boolean z2;
        int iMax4;
        int i13;
        this.o0 = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int i14 = this.k0;
        boolean z3 = this.q0;
        float f = 0.0f;
        int iP = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        int iMax5 = 0;
        boolean z4 = false;
        boolean z5 = true;
        boolean z6 = false;
        while (true) {
            int i19 = 8;
            if (iP >= virtualChildCount) {
                float f2 = f;
                int i20 = i15;
                int i21 = virtualChildCount;
                int i22 = mode2;
                boolean z7 = z3;
                int i23 = i16;
                int iMax6 = i17;
                int iCombineMeasuredStates = i18;
                if (this.o0 > 0) {
                    i3 = i21;
                    if (t(i3)) {
                        this.o0 += this.v0;
                    }
                } else {
                    i3 = i21;
                }
                int i24 = i22;
                if (z7 && (i24 == Integer.MIN_VALUE || i24 == 0)) {
                    this.o0 = 0;
                    int iP2 = 0;
                    while (iP2 < i3) {
                        View viewS = s(iP2);
                        if (viewS == null) {
                            this.o0 += y(iP2);
                        } else if (viewS.getVisibility() == i19) {
                            iP2 += p(viewS, iP2);
                        } else {
                            a aVar = (a) viewS.getLayoutParams();
                            int i25 = this.o0;
                            this.o0 = Math.max(i25, i25 + i23 + ((LinearLayout.LayoutParams) aVar).topMargin + ((LinearLayout.LayoutParams) aVar).bottomMargin + r(viewS));
                        }
                        iP2++;
                        i19 = 8;
                    }
                }
                int paddingTop = this.o0 + getPaddingTop() + getPaddingBottom();
                this.o0 = paddingTop;
                int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingTop, getSuggestedMinimumHeight()), i2, 0);
                int i26 = (16777215 & iResolveSizeAndState) - this.o0;
                if (z4 || (i26 != 0 && f2 > 0.0f)) {
                    float f3 = this.p0;
                    if (f3 <= 0.0f) {
                        f3 = f2;
                    }
                    this.o0 = 0;
                    float f4 = f3;
                    int i27 = i26;
                    int i28 = 0;
                    while (i28 < i3) {
                        View viewS2 = s(i28);
                        if (viewS2.getVisibility() == 8) {
                            i24 = i24;
                            i28 = i28;
                        } else {
                            a aVar2 = (a) viewS2.getLayoutParams();
                            float f5 = ((LinearLayout.LayoutParams) aVar2).weight;
                            if (f5 > 0.0f) {
                                int i29 = (int) ((i27 * f5) / f4);
                                f4 -= f5;
                                i27 -= i29;
                                int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + ((LinearLayout.LayoutParams) aVar2).leftMargin + ((LinearLayout.LayoutParams) aVar2).rightMargin, ((LinearLayout.LayoutParams) aVar2).width);
                                if (((LinearLayout.LayoutParams) aVar2).height == 0) {
                                    i5 = 1073741824;
                                    if (i24 == 1073741824) {
                                        viewS2.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(i29 > 0 ? i29 : 0, 1073741824));
                                    }
                                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, viewS2.getMeasuredState() & (-256));
                                } else {
                                    i5 = 1073741824;
                                }
                                int measuredHeight = viewS2.getMeasuredHeight() + i29;
                                if (measuredHeight < 0) {
                                    measuredHeight = 0;
                                }
                                viewS2.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(measuredHeight, i5));
                                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, viewS2.getMeasuredState() & (-256));
                            } else {
                                i24 = i24;
                            }
                            int i30 = ((LinearLayout.LayoutParams) aVar2).leftMargin + ((LinearLayout.LayoutParams) aVar2).rightMargin;
                            int measuredWidth = viewS2.getMeasuredWidth() + i30;
                            iMax6 = Math.max(iMax6, measuredWidth);
                            if (mode != 1073741824) {
                                i4 = -1;
                                if (((LinearLayout.LayoutParams) aVar2).width == -1) {
                                    measuredWidth = i30;
                                }
                            } else {
                                i4 = -1;
                            }
                            int iMax7 = Math.max(iMax5, measuredWidth);
                            boolean z8 = z5 && ((LinearLayout.LayoutParams) aVar2).width == i4;
                            int i31 = this.o0;
                            this.o0 = Math.max(i31, i31 + viewS2.getMeasuredHeight() + ((LinearLayout.LayoutParams) aVar2).topMargin + ((LinearLayout.LayoutParams) aVar2).bottomMargin + r(viewS2));
                            iMax5 = iMax7;
                            z5 = z8;
                        }
                        i28++;
                        i24 = i24;
                    }
                    this.o0 += getPaddingTop() + getPaddingBottom();
                    iMax = iMax5;
                } else {
                    iMax = Math.max(iMax5, i20);
                    if (z7 && i24 != 1073741824) {
                        for (int i32 = 0; i32 < i3; i32++) {
                            View viewS3 = s(i32);
                            if (viewS3 != null && viewS3.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((a) viewS3.getLayoutParams())).weight > 0.0f) {
                                viewS3.measure(View.MeasureSpec.makeMeasureSpec(viewS3.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i23, 1073741824));
                            }
                        }
                    }
                }
                if (!z5 && mode != 1073741824) {
                    iMax6 = iMax;
                }
                setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax6 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i, iCombineMeasuredStates), iResolveSizeAndState);
                if (z6) {
                    l(i3, i2);
                    return;
                }
                return;
            }
            float f6 = f;
            View viewS4 = s(iP);
            if (viewS4 == null) {
                this.o0 += y(iP);
            } else {
                if (viewS4.getVisibility() == 8) {
                    iP += p(viewS4, iP);
                } else {
                    if (t(iP)) {
                        this.o0 += this.v0;
                    }
                    a aVar3 = (a) viewS4.getLayoutParams();
                    float f7 = ((LinearLayout.LayoutParams) aVar3).weight;
                    float f8 = f6 + f7;
                    if (mode2 == 1073741824 && ((LinearLayout.LayoutParams) aVar3).height == 0 && f7 > 0.0f) {
                        int i33 = this.o0;
                        this.o0 = Math.max(i33, ((LinearLayout.LayoutParams) aVar3).topMargin + i33 + ((LinearLayout.LayoutParams) aVar3).bottomMargin);
                        iMax2 = i15;
                        iMax3 = i16;
                        i9 = virtualChildCount;
                        i10 = mode2;
                        view = viewS4;
                        z4 = true;
                        i12 = i17;
                        i11 = i18;
                        z = z3;
                    } else {
                        if (((LinearLayout.LayoutParams) aVar3).height != 0 || f7 <= 0.0f) {
                            i6 = Integer.MIN_VALUE;
                        } else {
                            ((LinearLayout.LayoutParams) aVar3).height = -2;
                            i6 = 0;
                        }
                        if (f8 == 0.0f) {
                            int i34 = i18;
                            i8 = this.o0;
                            i7 = i34;
                        } else {
                            i7 = i18;
                            i8 = 0;
                        }
                        int i35 = i16;
                        i9 = virtualChildCount;
                        i10 = mode2;
                        i11 = i7;
                        i12 = i17;
                        z = z3;
                        iMax2 = i15;
                        w(viewS4, iP, i, 0, i2, i8);
                        view = viewS4;
                        if (i6 != Integer.MIN_VALUE) {
                            ((LinearLayout.LayoutParams) aVar3).height = i6;
                        }
                        int measuredHeight2 = view.getMeasuredHeight();
                        int i36 = this.o0;
                        this.o0 = Math.max(i36, i36 + measuredHeight2 + ((LinearLayout.LayoutParams) aVar3).topMargin + ((LinearLayout.LayoutParams) aVar3).bottomMargin + r(view));
                        iMax3 = z ? Math.max(measuredHeight2, i35) : i35;
                    }
                    if (i14 >= 0 && i14 == iP + 1) {
                        this.l0 = this.o0;
                    }
                    if (iP < i14 && ((LinearLayout.LayoutParams) aVar3).weight > 0.0f) {
                        throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                    }
                    if (mode == 1073741824 || ((LinearLayout.LayoutParams) aVar3).width != -1) {
                        z2 = false;
                    } else {
                        z2 = true;
                        z6 = true;
                    }
                    int i37 = ((LinearLayout.LayoutParams) aVar3).leftMargin + ((LinearLayout.LayoutParams) aVar3).rightMargin;
                    int measuredWidth2 = view.getMeasuredWidth() + i37;
                    iMax4 = Math.max(i12, measuredWidth2);
                    int i38 = iMax3;
                    int iCombineMeasuredStates2 = View.combineMeasuredStates(i11, view.getMeasuredState());
                    if (z5) {
                        i13 = iCombineMeasuredStates2;
                        z5 = ((LinearLayout.LayoutParams) aVar3).width == -1;
                        if (((LinearLayout.LayoutParams) aVar3).weight > 0.0f) {
                            if (!z2) {
                                i37 = measuredWidth2;
                            }
                            iMax2 = Math.max(iMax2, i37);
                        } else {
                            if (!z2) {
                                i37 = measuredWidth2;
                            }
                            iMax5 = Math.max(iMax5, i37);
                        }
                        iP += p(view, iP);
                        f = f8;
                        i16 = i38;
                        i18 = i13;
                    } else {
                        i13 = iCombineMeasuredStates2;
                    }
                    if (((LinearLayout.LayoutParams) aVar3).weight > 0.0f) {
                        if (!z2) {
                            i37 = measuredWidth2;
                        }
                        iMax2 = Math.max(iMax2, i37);
                    } else {
                        if (!z2) {
                            i37 = measuredWidth2;
                        }
                        iMax5 = Math.max(iMax5, i37);
                    }
                    iP += p(view, iP);
                    f = f8;
                    i16 = i38;
                    i18 = i13;
                }
                iP++;
                i17 = iMax4;
                i15 = iMax2;
                z3 = z;
                mode2 = i10;
                virtualChildCount = i9;
            }
            iMax2 = i15;
            i9 = virtualChildCount;
            i10 = mode2;
            z = z3;
            f = f6;
            iMax4 = i17;
            iP++;
            i17 = iMax4;
            i15 = iMax2;
            z3 = z;
            mode2 = i10;
            virtualChildCount = i9;
        }
    }
}
