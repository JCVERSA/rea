package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import ax.p015b0.Y;

/* JADX INFO: renamed from: androidx.appcompat.widget.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0552e {
    private final View a;
    private J d;
    private J e;
    private J f;
    private int c = -1;
    private final C0558k b = C0558k.b();

    C0552e(View view) {
        this.a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f == null) {
            this.f = new J();
        }
        J j = this.f;
        j.a();
        ColorStateList colorStateListT = Y.t(this.a);
        if (colorStateListT != null) {
            j.d = true;
            j.a = colorStateListT;
        }
        PorterDuff.Mode modeU = Y.u(this.a);
        if (modeU != null) {
            j.c = true;
            j.b = modeU;
        }
        if (!j.d && !j.c) {
            return false;
        }
        C0558k.i(drawable, j, this.a.getDrawableState());
        return true;
    }

    private boolean k() {
        int i = Build.VERSION.SDK_INT;
        if (i > 21) {
            return this.d != null;
        }
        return i == 21;
    }

    void b() {
        Drawable background = this.a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            J j = this.e;
            if (j != null) {
                C0558k.i(background, j, this.a.getDrawableState());
                return;
            }
            J j2 = this.d;
            if (j2 != null) {
                C0558k.i(background, j2, this.a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        J j = this.e;
        if (j != null) {
            return j.a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        J j = this.e;
        if (j != null) {
            return j.b;
        }
        return null;
    }

    void e(AttributeSet attributeSet, int i) {
        Context context = this.a.getContext();
        int[] iArr = ax.p168m.j.D3;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        View view = this.a;
        Y.o0(view, view.getContext(), iArr, attributeSet, lV.r(), i, 0);
        try {
            int i2 = ax.p168m.j.E3;
            if (lV.s(i2)) {
                this.c = lV.n(i2, -1);
                ColorStateList colorStateListF = this.b.f(this.a.getContext(), this.c);
                if (colorStateListF != null) {
                    h(colorStateListF);
                }
            }
            int i3 = ax.p168m.j.F3;
            if (lV.s(i3)) {
                Y.v0(this.a, lV.c(i3));
            }
            int i4 = ax.p168m.j.G3;
            if (lV.s(i4)) {
                Y.w0(this.a, A.e(lV.k(i4, -1), null));
            }
        } finally {
            lV.x();
        }
    }

    void f(Drawable drawable) {
        this.c = -1;
        h(null);
        b();
    }

    void g(int i) {
        this.c = i;
        C0558k c0558k = this.b;
        h(c0558k != null ? c0558k.f(this.a.getContext(), i) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.d == null) {
                this.d = new J();
            }
            J j = this.d;
            j.a = colorStateList;
            j.d = true;
        } else {
            this.d = null;
        }
        b();
    }

    void i(ColorStateList colorStateList) {
        if (this.e == null) {
            this.e = new J();
        }
        J j = this.e;
        j.a = colorStateList;
        j.d = true;
        b();
    }

    void j(PorterDuff.Mode mode) {
        if (this.e == null) {
            this.e = new J();
        }
        J j = this.e;
        j.b = mode;
        j.c = true;
        b();
    }
}
