package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;

/* JADX INFO: loaded from: classes.dex */
public class s extends RadioButton implements ax.p115h0.m, ax.p115h0.n {
    private final C0595e k0;
    private final w l0;
    private C0604n m0;
    private final C0600j q;

    public s(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.L);
    }

    public s(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        C0600j c0600j = new C0600j(this);
        this.q = c0600j;
        c0600j.d(attributeSet, i);
        C0595e c0595e = new C0595e(this);
        this.k0 = c0595e;
        c0595e.e(attributeSet, i);
        w wVar = new w(this);
        this.l0 = wVar;
        wVar.m(attributeSet, i);
        getEmojiTextViewHelper().c(attributeSet, i);
    }

    private C0604n getEmojiTextViewHelper() {
        if (this.m0 == null) {
            this.m0 = new C0604n(this);
        }
        return this.m0;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.b();
        }
        w wVar = this.l0;
        if (wVar != null) {
            wVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            return c0595e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            return c0595e.d();
        }
        return null;
    }

    @Override // ax.p115h0.m
    public ColorStateList getSupportButtonTintList() {
        C0600j c0600j = this.q;
        if (c0600j != null) {
            return c0600j.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0600j c0600j = this.q;
        if (c0600j != null) {
            return c0600j.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.l0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.l0.k();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.g(i);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(ax.p226o.a.b(getContext(), i));
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0600j c0600j = this.q;
        if (c0600j != null) {
            c0600j.e();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.l0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.l0;
        if (wVar != null) {
            wVar.p();
        }
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.j(mode);
        }
    }

    @Override // ax.p115h0.m
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0600j c0600j = this.q;
        if (c0600j != null) {
            c0600j.f(colorStateList);
        }
    }

    @Override // ax.p115h0.m
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0600j c0600j = this.q;
        if (c0600j != null) {
            c0600j.g(mode);
        }
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.l0.w(colorStateList);
        this.l0.b();
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.l0.x(mode);
        this.l0.b();
    }
}
