package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;

/* JADX INFO: loaded from: classes.dex */
public class s extends RadioButton implements ax.p099h0.m, ax.p099h0.n {
    private final C0552e h0;
    private final w i0;
    private C0561n j0;
    private final C0557j q;

    public s(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.J);
    }

    private C0561n getEmojiTextViewHelper() {
        if (this.j0 == null) {
            this.j0 = new C0561n(this);
        }
        return this.j0;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.b();
        }
        w wVar = this.i0;
        if (wVar != null) {
            wVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            return c0552e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            return c0552e.d();
        }
        return null;
    }

    @Override // ax.p099h0.m
    public ColorStateList getSupportButtonTintList() {
        C0557j c0557j = this.q;
        if (c0557j != null) {
            return c0557j.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0557j c0557j = this.q;
        if (c0557j != null) {
            return c0557j.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.i0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.i0.k();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.g(i);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0557j c0557j = this.q;
        if (c0557j != null) {
            c0557j.e();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.i0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.i0;
        if (wVar != null) {
            wVar.p();
        }
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.j(mode);
        }
    }

    @Override // ax.p099h0.m
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0557j c0557j = this.q;
        if (c0557j != null) {
            c0557j.f(colorStateList);
        }
    }

    @Override // ax.p099h0.m
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0557j c0557j = this.q;
        if (c0557j != null) {
            c0557j.g(mode);
        }
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.i0.w(colorStateList);
        this.i0.b();
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.i0.x(mode);
        this.i0.b();
    }

    public s(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        C0557j c0557j = new C0557j(this);
        this.q = c0557j;
        c0557j.d(attributeSet, i);
        C0552e c0552e = new C0552e(this);
        this.h0 = c0552e;
        c0552e.e(attributeSet, i);
        w wVar = new w(this);
        this.i0 = wVar;
        wVar.m(attributeSet, i);
        getEmojiTextViewHelper().c(attributeSet, i);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i) {
        setButtonDrawable(ax.p196o.a.b(getContext(), i));
    }
}
