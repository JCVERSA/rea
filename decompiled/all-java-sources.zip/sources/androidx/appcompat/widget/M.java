package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import ax.p035c0.C1839d0;
import ax.p035c0.C1859n0;
import ax.p035c0.C1863p0;

/* JADX INFO: loaded from: classes.dex */
public class M implements ax.p322u.l {
    Toolbar a;
    private int b;
    private View c;
    private View d;
    private Drawable e;
    private Drawable f;
    private Drawable g;
    private boolean h;
    CharSequence i;
    private CharSequence j;
    private CharSequence k;
    Window.Callback l;
    boolean m;
    private C0593c n;
    private int o;
    private int p;
    private Drawable q;

    class a implements View.OnClickListener {
        final ax.p306t.a q;

        a() {
            this.q = new ax.p306t.a(M.this.a.getContext(), 0, R.id.home, 0, 0, M.this.i);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            M m = M.this;
            Window.Callback callback = m.l;
            if (callback == null || !m.m) {
                return;
            }
            callback.onMenuItemSelected(0, this.q);
        }
    }

    class b extends C1863p0 {
        private boolean a = false;
        final /* synthetic */ int b;

        b(int i) {
            this.b = i;
        }

        @Override // ax.p035c0.C1863p0, ax.p035c0.InterfaceC1861o0
        public void a(View view) {
            this.a = true;
        }

        @Override // ax.p035c0.InterfaceC1861o0
        public void b(View view) {
            if (this.a) {
                return;
            }
            M.this.a.setVisibility(this.b);
        }

        @Override // ax.p035c0.C1863p0, ax.p035c0.InterfaceC1861o0
        public void c(View view) {
            M.this.a.setVisibility(0);
        }
    }

    public M(Toolbar toolbar, boolean z) {
        this(toolbar, z, ax.p194m.h.a, ax.p194m.e.n);
    }

    public M(Toolbar toolbar, boolean z, int i, int i2) {
        Drawable drawable;
        this.o = 0;
        this.p = 0;
        this.a = toolbar;
        this.i = toolbar.getTitle();
        this.j = toolbar.getSubtitle();
        this.h = this.i != null;
        this.g = toolbar.getNavigationIcon();
        L lV = L.v(toolbar.getContext(), null, ax.p194m.j.a, ax.p194m.a.c, 0);
        this.q = lV.g(ax.p194m.j.l);
        if (z) {
            CharSequence charSequenceP = lV.p(ax.p194m.j.r);
            if (!TextUtils.isEmpty(charSequenceP)) {
                setTitle(charSequenceP);
            }
            CharSequence charSequenceP2 = lV.p(ax.p194m.j.p);
            if (!TextUtils.isEmpty(charSequenceP2)) {
                f(charSequenceP2);
            }
            Drawable drawableG = lV.g(ax.p194m.j.n);
            if (drawableG != null) {
                d(drawableG);
            }
            Drawable drawableG2 = lV.g(ax.p194m.j.m);
            if (drawableG2 != null) {
                setIcon(drawableG2);
            }
            if (this.g == null && (drawable = this.q) != null) {
                C(drawable);
            }
            o(lV.k(ax.p194m.j.h, 0));
            int iN = lV.n(ax.p194m.j.g, 0);
            if (iN != 0) {
                F(LayoutInflater.from(this.a.getContext()).inflate(iN, (ViewGroup) this.a, false));
                o(this.b | 16);
            }
            int iM = lV.m(ax.p194m.j.j, 0);
            if (iM > 0) {
                ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
                layoutParams.height = iM;
                this.a.setLayoutParams(layoutParams);
            }
            int iE = lV.e(ax.p194m.j.f, -1);
            int iE2 = lV.e(ax.p194m.j.e, -1);
            if (iE >= 0 || iE2 >= 0) {
                this.a.K(Math.max(iE, 0), Math.max(iE2, 0));
            }
            int iN2 = lV.n(ax.p194m.j.s, 0);
            if (iN2 != 0) {
                Toolbar toolbar2 = this.a;
                toolbar2.O(toolbar2.getContext(), iN2);
            }
            int iN3 = lV.n(ax.p194m.j.q, 0);
            if (iN3 != 0) {
                Toolbar toolbar3 = this.a;
                toolbar3.N(toolbar3.getContext(), iN3);
            }
            int iN4 = lV.n(ax.p194m.j.o, 0);
            if (iN4 != 0) {
                this.a.setPopupTheme(iN4);
            }
        } else {
            this.b = E();
        }
        lV.x();
        G(i);
        this.k = this.a.getNavigationContentDescription();
        this.a.setNavigationOnClickListener(new a());
    }

    private int E() {
        if (this.a.getNavigationIcon() == null) {
            return 11;
        }
        this.q = this.a.getNavigationIcon();
        return 15;
    }

    private void I(CharSequence charSequence) {
        this.i = charSequence;
        if ((this.b & 8) != 0) {
            this.a.setTitle(charSequence);
            if (this.h) {
                C1839d0.n0(this.a.getRootView(), charSequence);
            }
        }
    }

    private void J() {
        if ((this.b & 4) != 0) {
            if (TextUtils.isEmpty(this.k)) {
                this.a.setNavigationContentDescription(this.p);
            } else {
                this.a.setNavigationContentDescription(this.k);
            }
        }
    }

    private void K() {
        if ((this.b & 4) == 0) {
            this.a.setNavigationIcon((Drawable) null);
            return;
        }
        Toolbar toolbar = this.a;
        Drawable drawable = this.g;
        if (drawable == null) {
            drawable = this.q;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void L() {
        Drawable drawable;
        int i = this.b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f) == null) {
            drawable = this.e;
        }
        this.a.setLogo(drawable);
    }

    @Override // ax.p322u.l
    public void A() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // ax.p322u.l
    public void B() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // ax.p322u.l
    public void C(Drawable drawable) {
        this.g = drawable;
        K();
    }

    @Override // ax.p322u.l
    public void D(boolean z) {
        this.a.setCollapsible(z);
    }

    public void F(View view) {
        View view2 = this.d;
        if (view2 != null && (this.b & 16) != 0) {
            this.a.removeView(view2);
        }
        this.d = view;
        if (view == null || (this.b & 16) == 0) {
            return;
        }
        this.a.addView(view);
    }

    public void G(int i) {
        if (i == this.p) {
            return;
        }
        this.p = i;
        if (TextUtils.isEmpty(this.a.getNavigationContentDescription())) {
            z(this.p);
        }
    }

    public void H(CharSequence charSequence) {
        this.k = charSequence;
        J();
    }

    @Override // ax.p322u.l
    public void a(Drawable drawable) {
        this.a.setBackground(drawable);
    }

    @Override // ax.p322u.l
    public void b(Menu menu, androidx.appcompat.view.menu.j.a aVar) {
        if (this.n == null) {
            C0593c c0593c = new C0593c(this.a.getContext());
            this.n = c0593c;
            c0593c.p(ax.p194m.f.g);
        }
        this.n.h(aVar);
        this.a.L((androidx.appcompat.view.menu.e) menu, this.n);
    }

    @Override // ax.p322u.l
    public boolean c() {
        return this.a.B();
    }

    @Override // ax.p322u.l
    public void collapseActionView() {
        this.a.e();
    }

    @Override // ax.p322u.l
    public void d(Drawable drawable) {
        this.f = drawable;
        L();
    }

    @Override // ax.p322u.l
    public void e() {
        this.m = true;
    }

    @Override // ax.p322u.l
    public void f(CharSequence charSequence) {
        this.j = charSequence;
        if ((this.b & 8) != 0) {
            this.a.setSubtitle(charSequence);
        }
    }

    @Override // ax.p322u.l
    public boolean g() {
        return this.a.d();
    }

    @Override // ax.p322u.l
    public Context getContext() {
        return this.a.getContext();
    }

    @Override // ax.p322u.l
    public int getHeight() {
        return this.a.getHeight();
    }

    @Override // ax.p322u.l
    public CharSequence getTitle() {
        return this.a.getTitle();
    }

    @Override // ax.p322u.l
    public boolean h() {
        return this.a.A();
    }

    @Override // ax.p322u.l
    public boolean i() {
        return this.a.w();
    }

    @Override // ax.p322u.l
    public boolean j() {
        return this.a.R();
    }

    @Override // ax.p322u.l
    public void k() {
        this.a.f();
    }

    @Override // ax.p322u.l
    public void l(F f) {
        View view = this.c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.a;
            if (parent == toolbar) {
                toolbar.removeView(this.c);
            }
        }
        this.c = f;
        if (f == null || this.o != 2) {
            return;
        }
        this.a.addView(f, 0);
        Toolbar.g gVar = (Toolbar.g) this.c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) gVar).width = -2;
        ((ViewGroup.MarginLayoutParams) gVar).height = -2;
        gVar.a = 8388691;
        f.setAllowCollapse(true);
    }

    @Override // ax.p322u.l
    public int m() {
        return this.a.getVisibility();
    }

    @Override // ax.p322u.l
    public boolean n() {
        return this.a.v();
    }

    @Override // ax.p322u.l
    public void o(int i) {
        View view;
        int i2 = this.b ^ i;
        this.b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    J();
                }
                K();
            }
            if ((i2 & 3) != 0) {
                L();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.a.setTitle(this.i);
                    this.a.setSubtitle(this.j);
                } else {
                    this.a.setTitle((CharSequence) null);
                    this.a.setSubtitle((CharSequence) null);
                }
            }
            if ((i2 & 16) == 0 || (view = this.d) == null) {
                return;
            }
            if ((i & 16) != 0) {
                this.a.addView(view);
            } else {
                this.a.removeView(view);
            }
        }
    }

    @Override // ax.p322u.l
    public Menu p() {
        return this.a.getMenu();
    }

    @Override // ax.p322u.l
    public void q(int i) {
        d(i != 0 ? ax.p226o.a.b(getContext(), i) : null);
    }

    @Override // ax.p322u.l
    public int r() {
        return this.o;
    }

    @Override // ax.p322u.l
    public C1859n0 s(int i, long j) {
        return C1839d0.e(this.a).b(i == 0 ? 1.0f : 0.0f).e(j).g(new b(i));
    }

    @Override // ax.p322u.l
    public void setIcon(int i) {
        setIcon(i != 0 ? ax.p226o.a.b(getContext(), i) : null);
    }

    @Override // ax.p322u.l
    public void setIcon(Drawable drawable) {
        this.e = drawable;
        L();
    }

    @Override // ax.p322u.l
    public void setTitle(CharSequence charSequence) {
        this.h = true;
        I(charSequence);
    }

    @Override // ax.p322u.l
    public void setWindowCallback(Window.Callback callback) {
        this.l = callback;
    }

    @Override // ax.p322u.l
    public void setWindowTitle(CharSequence charSequence) {
        if (this.h) {
            return;
        }
        I(charSequence);
    }

    @Override // ax.p322u.l
    public void t(int i) {
        C(i != 0 ? ax.p226o.a.b(getContext(), i) : null);
    }

    @Override // ax.p322u.l
    public void u(androidx.appcompat.view.menu.j.a aVar, androidx.appcompat.view.menu.e.a aVar2) {
        this.a.M(aVar, aVar2);
    }

    @Override // ax.p322u.l
    public void v(int i) {
        this.a.setVisibility(i);
    }

    @Override // ax.p322u.l
    public ViewGroup w() {
        return this.a;
    }

    @Override // ax.p322u.l
    public void x(boolean z) {
    }

    @Override // ax.p322u.l
    public int y() {
        return this.b;
    }

    @Override // ax.p322u.l
    public void z(int i) {
        H(i == 0 ? null : getContext().getString(i));
    }
}
