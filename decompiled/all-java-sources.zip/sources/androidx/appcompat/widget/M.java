package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import ax.p015b0.C5224i0;
import ax.p015b0.C5228k0;
import ax.p015b0.Y;

/* JADX INFO: loaded from: classes.dex */
public class M implements ax.p280u.l {
    Toolbar a;
    private int b;
    private View c;
    private View d;
    private Drawable e;
    private Drawable f;
    private Drawable g;
    private boolean h;
    CharSequence i;
    private CharSequence j;
    private CharSequence k;
    Window.Callback l;
    boolean m;
    private C0550c n;
    private int o;
    private int p;
    private Drawable q;

    class a implements View.OnClickListener {
        final ax.p266t.a q;

        a() {
            this.q = new ax.p266t.a(M.this.a.getContext(), 0, R.id.home, 0, 0, M.this.i);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            M m = M.this;
            Window.Callback callback = m.l;
            if (callback == null || !m.m) {
                return;
            }
            callback.onMenuItemSelected(0, this.q);
        }
    }

    class b extends C5228k0 {
        private boolean a = false;
        final /* synthetic */ int b;

        b(int i) {
            this.b = i;
        }

        @Override // ax.p015b0.C5228k0, ax.p015b0.InterfaceC5226j0
        public void a(View view) {
            this.a = true;
        }

        @Override // ax.p015b0.InterfaceC5226j0
        public void b(View view) {
            if (this.a) {
                return;
            }
            M.this.a.setVisibility(this.b);
        }

        @Override // ax.p015b0.C5228k0, ax.p015b0.InterfaceC5226j0
        public void c(View view) {
            M.this.a.setVisibility(0);
        }
    }

    public M(Toolbar toolbar, boolean z) {
        this(toolbar, z, ax.p168m.h.a, ax.p168m.e.n);
    }

    private int C() {
        if (this.a.getNavigationIcon() == null) {
            return 11;
        }
        this.q = this.a.getNavigationIcon();
        return 15;
    }

    private void G(CharSequence charSequence) {
        this.i = charSequence;
        if ((this.b & 8) != 0) {
            this.a.setTitle(charSequence);
            if (this.h) {
                Y.t0(this.a.getRootView(), charSequence);
            }
        }
    }

    private void H() {
        if ((this.b & 4) != 0) {
            if (TextUtils.isEmpty(this.k)) {
                this.a.setNavigationContentDescription(this.p);
            } else {
                this.a.setNavigationContentDescription(this.k);
            }
        }
    }

    private void I() {
        if ((this.b & 4) == 0) {
            this.a.setNavigationIcon((Drawable) null);
            return;
        }
        Toolbar toolbar = this.a;
        Drawable drawable = this.g;
        if (drawable == null) {
            drawable = this.q;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void J() {
        Drawable drawable;
        int i = this.b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f) == null) {
            drawable = this.e;
        }
        this.a.setLogo(drawable);
    }

    @Override // ax.p280u.l
    public void A(Drawable drawable) {
        this.g = drawable;
        I();
    }

    @Override // ax.p280u.l
    public void B(boolean z) {
        this.a.setCollapsible(z);
    }

    public void D(View view) {
        View view2 = this.d;
        if (view2 != null && (this.b & 16) != 0) {
            this.a.removeView(view2);
        }
        this.d = view;
        if (view == null || (this.b & 16) == 0) {
            return;
        }
        this.a.addView(view);
    }

    public void E(int i) {
        if (i == this.p) {
            return;
        }
        this.p = i;
        if (TextUtils.isEmpty(this.a.getNavigationContentDescription())) {
            x(this.p);
        }
    }

    public void F(CharSequence charSequence) {
        this.k = charSequence;
        H();
    }

    @Override // ax.p280u.l
    public void a(Drawable drawable) {
        this.a.setBackground(drawable);
    }

    @Override // ax.p280u.l
    public void b(Menu menu, androidx.appcompat.view.menu.j.a aVar) {
        if (this.n == null) {
            C0550c c0550c = new C0550c(this.a.getContext());
            this.n = c0550c;
            c0550c.p(ax.p168m.f.g);
        }
        this.n.h(aVar);
        this.a.N((androidx.appcompat.view.menu.e) menu, this.n);
    }

    @Override // ax.p280u.l
    public boolean c() {
        return this.a.D();
    }

    @Override // ax.p280u.l
    public void collapseActionView() {
        this.a.e();
    }

    @Override // ax.p280u.l
    public void d(Drawable drawable) {
        this.f = drawable;
        J();
    }

    @Override // ax.p280u.l
    public void e() {
        this.m = true;
    }

    @Override // ax.p280u.l
    public void f(CharSequence charSequence) {
        this.j = charSequence;
        if ((this.b & 8) != 0) {
            this.a.setSubtitle(charSequence);
        }
    }

    @Override // ax.p280u.l
    public boolean g() {
        return this.a.d();
    }

    @Override // ax.p280u.l
    public Context getContext() {
        return this.a.getContext();
    }

    @Override // ax.p280u.l
    public CharSequence getTitle() {
        return this.a.getTitle();
    }

    @Override // ax.p280u.l
    public boolean h() {
        return this.a.C();
    }

    @Override // ax.p280u.l
    public boolean i() {
        return this.a.y();
    }

    @Override // ax.p280u.l
    public boolean j() {
        return this.a.T();
    }

    @Override // ax.p280u.l
    public void k() {
        this.a.f();
    }

    @Override // ax.p280u.l
    public void l(F f) {
        View view = this.c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.a;
            if (parent == toolbar) {
                toolbar.removeView(this.c);
            }
        }
        this.c = f;
        if (f == null || this.o != 2) {
            return;
        }
        this.a.addView(f, 0);
        Toolbar.g gVar = (Toolbar.g) this.c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) gVar).width = -2;
        ((ViewGroup.MarginLayoutParams) gVar).height = -2;
        gVar.a = 8388691;
        f.setAllowCollapse(true);
    }

    @Override // ax.p280u.l
    public boolean m() {
        return this.a.x();
    }

    @Override // ax.p280u.l
    public void n(int i) {
        View view;
        int i2 = this.b ^ i;
        this.b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    H();
                }
                I();
            }
            if ((i2 & 3) != 0) {
                J();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.a.setTitle(this.i);
                    this.a.setSubtitle(this.j);
                } else {
                    this.a.setTitle((CharSequence) null);
                    this.a.setSubtitle((CharSequence) null);
                }
            }
            if ((i2 & 16) == 0 || (view = this.d) == null) {
                return;
            }
            if ((i & 16) != 0) {
                this.a.addView(view);
            } else {
                this.a.removeView(view);
            }
        }
    }

    @Override // ax.p280u.l
    public Menu o() {
        return this.a.getMenu();
    }

    @Override // ax.p280u.l
    public void p(int i) {
        d(i != 0 ? ax.p196o.a.b(getContext(), i) : null);
    }

    @Override // ax.p280u.l
    public int q() {
        return this.o;
    }

    @Override // ax.p280u.l
    public C5224i0 r(int i, long j) {
        return Y.e(this.a).b(i == 0 ? 1.0f : 0.0f).f(j).h(new b(i));
    }

    @Override // ax.p280u.l
    public void s(androidx.appcompat.view.menu.j.a aVar, androidx.appcompat.view.menu.e.a aVar2) {
        this.a.O(aVar, aVar2);
    }

    @Override // ax.p280u.l
    public void setIcon(int i) {
        setIcon(i != 0 ? ax.p196o.a.b(getContext(), i) : null);
    }

    @Override // ax.p280u.l
    public void setTitle(CharSequence charSequence) {
        this.h = true;
        G(charSequence);
    }

    @Override // ax.p280u.l
    public void setWindowCallback(Window.Callback callback) {
        this.l = callback;
    }

    @Override // ax.p280u.l
    public void setWindowTitle(CharSequence charSequence) {
        if (this.h) {
            return;
        }
        G(charSequence);
    }

    @Override // ax.p280u.l
    public void t(int i) {
        this.a.setVisibility(i);
    }

    @Override // ax.p280u.l
    public ViewGroup u() {
        return this.a;
    }

    @Override // ax.p280u.l
    public void v(boolean z) {
    }

    @Override // ax.p280u.l
    public int w() {
        return this.b;
    }

    @Override // ax.p280u.l
    public void x(int i) {
        F(i == 0 ? null : getContext().getString(i));
    }

    @Override // ax.p280u.l
    public void y() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // ax.p280u.l
    public void z() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public M(Toolbar toolbar, boolean z, int i, int i2) {
        Drawable drawable;
        this.o = 0;
        this.p = 0;
        this.a = toolbar;
        this.i = toolbar.getTitle();
        this.j = toolbar.getSubtitle();
        this.h = this.i != null;
        this.g = toolbar.getNavigationIcon();
        L lV = L.v(toolbar.getContext(), null, ax.p168m.j.a, ax.p168m.a.c, 0);
        this.q = lV.g(ax.p168m.j.l);
        if (z) {
            CharSequence charSequenceP = lV.p(ax.p168m.j.r);
            if (!TextUtils.isEmpty(charSequenceP)) {
                setTitle(charSequenceP);
            }
            CharSequence charSequenceP2 = lV.p(ax.p168m.j.p);
            if (!TextUtils.isEmpty(charSequenceP2)) {
                f(charSequenceP2);
            }
            Drawable drawableG = lV.g(ax.p168m.j.n);
            if (drawableG != null) {
                d(drawableG);
            }
            Drawable drawableG2 = lV.g(ax.p168m.j.m);
            if (drawableG2 != null) {
                setIcon(drawableG2);
            }
            if (this.g == null && (drawable = this.q) != null) {
                A(drawable);
            }
            n(lV.k(ax.p168m.j.h, 0));
            int iN = lV.n(ax.p168m.j.g, 0);
            if (iN != 0) {
                D(LayoutInflater.from(this.a.getContext()).inflate(iN, (ViewGroup) this.a, false));
                n(this.b | 16);
            }
            int iM = lV.m(ax.p168m.j.j, 0);
            if (iM > 0) {
                ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
                layoutParams.height = iM;
                this.a.setLayoutParams(layoutParams);
            }
            int iE = lV.e(ax.p168m.j.f, -1);
            int iE2 = lV.e(ax.p168m.j.e, -1);
            if (iE >= 0 || iE2 >= 0) {
                this.a.M(Math.max(iE, 0), Math.max(iE2, 0));
            }
            int iN2 = lV.n(ax.p168m.j.s, 0);
            if (iN2 != 0) {
                Toolbar toolbar2 = this.a;
                toolbar2.Q(toolbar2.getContext(), iN2);
            }
            int iN3 = lV.n(ax.p168m.j.q, 0);
            if (iN3 != 0) {
                Toolbar toolbar3 = this.a;
                toolbar3.P(toolbar3.getContext(), iN3);
            }
            int iN4 = lV.n(ax.p168m.j.o, 0);
            if (iN4 != 0) {
                this.a.setPopupTheme(iN4);
            }
        } else {
            this.b = C();
        }
        lV.x();
        E(i);
        this.k = this.a.getNavigationContentDescription();
        this.a.setNavigationOnClickListener(new a());
    }

    @Override // ax.p280u.l
    public void setIcon(Drawable drawable) {
        this.e = drawable;
        J();
    }
}
