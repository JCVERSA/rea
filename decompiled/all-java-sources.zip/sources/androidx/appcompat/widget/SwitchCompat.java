package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import ax.p035c0.C1839d0;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    private static final Property<SwitchCompat, Float> b1 = new a(Float.class, "thumbPos");
    private static final int[] c1 = {R.attr.state_checked};
    private CharSequence A0;
    private boolean B0;
    private int C0;
    private int D0;
    private float E0;
    private float F0;
    private VelocityTracker G0;
    private int H0;
    float I0;
    private int J0;
    private int K0;
    private int L0;
    private int M0;
    private int N0;
    private int O0;
    private int P0;
    private boolean Q0;
    private final TextPaint R0;
    private ColorStateList S0;
    private Layout T0;
    private Layout U0;
    private TransformationMethod V0;
    ObjectAnimator W0;
    private final w X0;
    private C0604n Y0;
    private b Z0;
    private final Rect a1;
    private ColorStateList k0;
    private PorterDuff.Mode l0;
    private boolean m0;
    private boolean n0;
    private Drawable o0;
    private ColorStateList p0;
    private Drawable q;
    private PorterDuff.Mode q0;
    private boolean r0;
    private boolean s0;
    private int t0;
    private int u0;
    private int v0;
    private boolean w0;
    private CharSequence x0;
    private CharSequence y0;
    private CharSequence z0;

    class a extends Property<SwitchCompat, Float> {
        a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(SwitchCompat switchCompat) {
            return Float.valueOf(switchCompat.I0);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(SwitchCompat switchCompat, Float f) {
            switchCompat.setThumbPosition(f.floatValue());
        }
    }

    static class b extends androidx.emoji2.text.e.AbstractC0018e {
        private final Reference<SwitchCompat> q;

        b(SwitchCompat switchCompat) {
            this.q = new WeakReference(switchCompat);
        }

        @Override // androidx.emoji2.text.e.AbstractC0018e
        public void a(Throwable th) {
            SwitchCompat switchCompat = this.q.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }

        @Override // androidx.emoji2.text.e.AbstractC0018e
        public void b() {
            SwitchCompat switchCompat = this.q.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.P);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.k0 = null;
        this.l0 = null;
        this.m0 = false;
        this.n0 = false;
        this.p0 = null;
        this.q0 = null;
        this.r0 = false;
        this.s0 = false;
        this.G0 = VelocityTracker.obtain();
        this.Q0 = true;
        this.a1 = new Rect();
        H.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.R0 = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = ax.p194m.j.u2;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        C1839d0.j0(this, context, iArr, attributeSet, lV.r(), i, 0);
        Drawable drawableG = lV.g(ax.p194m.j.x2);
        this.q = drawableG;
        if (drawableG != null) {
            drawableG.setCallback(this);
        }
        Drawable drawableG2 = lV.g(ax.p194m.j.G2);
        this.o0 = drawableG2;
        if (drawableG2 != null) {
            drawableG2.setCallback(this);
        }
        setTextOnInternal(lV.p(ax.p194m.j.v2));
        setTextOffInternal(lV.p(ax.p194m.j.w2));
        this.B0 = lV.a(ax.p194m.j.y2, true);
        this.t0 = lV.f(ax.p194m.j.D2, 0);
        this.u0 = lV.f(ax.p194m.j.A2, 0);
        this.v0 = lV.f(ax.p194m.j.B2, 0);
        this.w0 = lV.a(ax.p194m.j.z2, false);
        ColorStateList colorStateListC = lV.c(ax.p194m.j.E2);
        if (colorStateListC != null) {
            this.k0 = colorStateListC;
            this.m0 = true;
        }
        PorterDuff.Mode modeE = A.e(lV.k(ax.p194m.j.F2, -1), null);
        if (this.l0 != modeE) {
            this.l0 = modeE;
            this.n0 = true;
        }
        if (this.m0 || this.n0) {
            b();
        }
        ColorStateList colorStateListC2 = lV.c(ax.p194m.j.H2);
        if (colorStateListC2 != null) {
            this.p0 = colorStateListC2;
            this.r0 = true;
        }
        PorterDuff.Mode modeE2 = A.e(lV.k(ax.p194m.j.I2, -1), null);
        if (this.q0 != modeE2) {
            this.q0 = modeE2;
            this.s0 = true;
        }
        if (this.r0 || this.s0) {
            c();
        }
        int iN = lV.n(ax.p194m.j.C2, 0);
        if (iN != 0) {
            m(context, iN);
        }
        w wVar = new w(this);
        this.X0 = wVar;
        wVar.m(attributeSet, i);
        lV.x();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.D0 = viewConfiguration.getScaledTouchSlop();
        this.H0 = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().c(attributeSet, i);
        refreshDrawableState();
        setChecked(isChecked());
    }

    private void a(boolean z) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, b1, z ? 1.0f : 0.0f);
        this.W0 = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.W0.setAutoCancel(true);
        this.W0.start();
    }

    private void b() {
        Drawable drawable = this.q;
        if (drawable != null) {
            if (this.m0 || this.n0) {
                Drawable drawableMutate = ax.U.a.r(drawable).mutate();
                this.q = drawableMutate;
                if (this.m0) {
                    ax.U.a.o(drawableMutate, this.k0);
                }
                if (this.n0) {
                    ax.U.a.p(this.q, this.l0);
                }
                if (this.q.isStateful()) {
                    this.q.setState(getDrawableState());
                }
            }
        }
    }

    private void c() {
        Drawable drawable = this.o0;
        if (drawable != null) {
            if (this.r0 || this.s0) {
                Drawable drawableMutate = ax.U.a.r(drawable).mutate();
                this.o0 = drawableMutate;
                if (this.r0) {
                    ax.U.a.o(drawableMutate, this.p0);
                }
                if (this.s0) {
                    ax.U.a.p(this.o0, this.q0);
                }
                if (this.o0.isStateful()) {
                    this.o0.setState(getDrawableState());
                }
            }
        }
    }

    private void d() {
        ObjectAnimator objectAnimator = this.W0;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    private void e(MotionEvent motionEvent) {
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.setAction(3);
        super.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    private static float f(float f, float f2, float f3) {
        if (f < f2) {
            return f2;
        }
        return f > f3 ? f3 : f;
    }

    private CharSequence g(CharSequence charSequence) {
        TransformationMethod transformationMethodF = getEmojiTextViewHelper().f(this.V0);
        return transformationMethodF != null ? transformationMethodF.getTransformation(charSequence, this) : charSequence;
    }

    private C0604n getEmojiTextViewHelper() {
        if (this.Y0 == null) {
            this.Y0 = new C0604n(this);
        }
        return this.Y0;
    }

    private boolean getTargetCheckedState() {
        return this.I0 > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((O.b(this) ? 1.0f - this.I0 : this.I0) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.o0;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.a1;
        drawable.getPadding(rect);
        Drawable drawable2 = this.q;
        Rect rectD = drawable2 != null ? A.d(drawable2) : A.c;
        return ((((this.J0 - this.L0) - rect.left) - rect.right) - rectD.left) - rectD.right;
    }

    private boolean h(float f, float f2) {
        if (this.q == null) {
            return false;
        }
        int thumbOffset = getThumbOffset();
        this.q.getPadding(this.a1);
        int i = this.N0;
        int i2 = this.D0;
        int i3 = i - i2;
        int i4 = (this.M0 + thumbOffset) - i2;
        int i5 = this.L0 + i4;
        Rect rect = this.a1;
        return f > ((float) i4) && f < ((float) (((i5 + rect.left) + rect.right) + i2)) && f2 > ((float) i3) && f2 < ((float) (this.P0 + i2));
    }

    private Layout i(CharSequence charSequence) {
        TextPaint textPaint = this.R0;
        return new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    private void k() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.z0;
            if (string == null) {
                string = getResources().getString(ax.p194m.h.b);
            }
            C1839d0.z0(this, string);
        }
    }

    private void l() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.x0;
            if (string == null) {
                string = getResources().getString(ax.p194m.h.c);
            }
            C1839d0.z0(this, string);
        }
    }

    private void o(int i, int i2) {
        Typeface typeface;
        if (i == 1) {
            typeface = Typeface.SANS_SERIF;
        } else if (i != 2) {
            typeface = i != 3 ? null : Typeface.MONOSPACE;
        } else {
            typeface = Typeface.SERIF;
        }
        n(typeface, i2);
    }

    private void p() {
        if (this.Z0 == null && this.Y0.b() && androidx.emoji2.text.e.i()) {
            androidx.emoji2.text.e eVarC = androidx.emoji2.text.e.c();
            int iE = eVarC.e();
            if (iE == 3 || iE == 0) {
                b bVar = new b(this);
                this.Z0 = bVar;
                eVarC.t(bVar);
            }
        }
    }

    private void q(MotionEvent motionEvent) {
        this.C0 = 0;
        boolean targetCheckedState = true;
        boolean z = motionEvent.getAction() == 1 && isEnabled();
        boolean zIsChecked = isChecked();
        if (z) {
            this.G0.computeCurrentVelocity(1000);
            float xVelocity = this.G0.getXVelocity();
            if (Math.abs(xVelocity) <= this.H0) {
                targetCheckedState = getTargetCheckedState();
            } else if (!O.b(this) ? xVelocity <= 0.0f : xVelocity >= 0.0f) {
                targetCheckedState = false;
            }
        } else {
            targetCheckedState = zIsChecked;
        }
        if (targetCheckedState != zIsChecked) {
            playSoundEffect(0);
        }
        setChecked(targetCheckedState);
        e(motionEvent);
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.z0 = charSequence;
        this.A0 = g(charSequence);
        this.U0 = null;
        if (this.B0) {
            p();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.x0 = charSequence;
        this.y0 = g(charSequence);
        this.T0 = null;
        if (this.B0) {
            p();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i;
        int i2;
        Rect rect = this.a1;
        int i3 = this.M0;
        int i4 = this.N0;
        int i5 = this.O0;
        int i6 = this.P0;
        int thumbOffset = getThumbOffset() + i3;
        Drawable drawable = this.q;
        Rect rectD = drawable != null ? A.d(drawable) : A.c;
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i7 = rect.left;
            thumbOffset += i7;
            if (rectD != null) {
                int i8 = rectD.left;
                if (i8 > i7) {
                    i3 += i8 - i7;
                }
                int i9 = rectD.top;
                int i10 = rect.top;
                i = i9 > i10 ? (i9 - i10) + i4 : i4;
                int i11 = rectD.right;
                int i12 = rect.right;
                if (i11 > i12) {
                    i5 -= i11 - i12;
                }
                int i13 = rectD.bottom;
                int i14 = rect.bottom;
                if (i13 > i14) {
                    i2 = i6 - (i13 - i14);
                }
                this.o0.setBounds(i3, i, i5, i2);
            } else {
                i = i4;
            }
            i2 = i6;
            this.o0.setBounds(i3, i, i5, i2);
        }
        Drawable drawable3 = this.q;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i15 = thumbOffset - rect.left;
            int i16 = thumbOffset + this.L0 + rect.right;
            this.q.setBounds(i15, i4, i16, i6);
            Drawable background = getBackground();
            if (background != null) {
                ax.U.a.l(background, i15, i4, i16, i6);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.q;
        if (drawable != null) {
            ax.U.a.k(drawable, f, f2);
        }
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            ax.U.a.k(drawable2, f, f2);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.q;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.o0;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        if (!O.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.J0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.v0 : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        if (O.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.J0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.v0 : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p115h0.j.o(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.B0;
    }

    public boolean getSplitTrack() {
        return this.w0;
    }

    public int getSwitchMinWidth() {
        return this.u0;
    }

    public int getSwitchPadding() {
        return this.v0;
    }

    public CharSequence getTextOff() {
        return this.z0;
    }

    public CharSequence getTextOn() {
        return this.x0;
    }

    public Drawable getThumbDrawable() {
        return this.q;
    }

    protected final float getThumbPosition() {
        return this.I0;
    }

    public int getThumbTextPadding() {
        return this.t0;
    }

    public ColorStateList getThumbTintList() {
        return this.k0;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.l0;
    }

    public Drawable getTrackDrawable() {
        return this.o0;
    }

    public ColorStateList getTrackTintList() {
        return this.p0;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.q0;
    }

    void j() {
        setTextOnInternal(this.x0);
        setTextOffInternal(this.z0);
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.q;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.W0;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.W0.end();
        this.W0 = null;
    }

    public void m(Context context, int i) {
        L lT = L.t(context, i, ax.p194m.j.J2);
        ColorStateList colorStateListC = lT.c(ax.p194m.j.N2);
        if (colorStateListC != null) {
            this.S0 = colorStateListC;
        } else {
            this.S0 = getTextColors();
        }
        int iF = lT.f(ax.p194m.j.K2, 0);
        if (iF != 0) {
            float f = iF;
            if (f != this.R0.getTextSize()) {
                this.R0.setTextSize(f);
                requestLayout();
            }
        }
        o(lT.k(ax.p194m.j.L2, -1), lT.k(ax.p194m.j.M2, -1));
        if (lT.a(ax.p194m.j.Y2, false)) {
            this.V0 = new ax.p274r.a(getContext());
        } else {
            this.V0 = null;
        }
        setTextOnInternal(this.x0);
        setTextOffInternal(this.z0);
        lT.x();
    }

    public void n(Typeface typeface, int i) {
        if (i <= 0) {
            this.R0.setFakeBoldText(false);
            this.R0.setTextSkewX(0.0f);
            setSwitchTypeface(typeface);
        } else {
            Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i) : Typeface.create(typeface, i);
            setSwitchTypeface(typefaceDefaultFromStyle);
            int i2 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i;
            this.R0.setFakeBoldText((i2 & 1) != 0);
            this.R0.setTextSkewX((i2 & 2) != 0 ? -0.25f : 0.0f);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, c1);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Rect rect = this.a1;
        Drawable drawable = this.o0;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.N0;
        int i2 = this.P0;
        int i3 = i + rect.top;
        int i4 = i2 - rect.bottom;
        Drawable drawable2 = this.q;
        if (drawable != null) {
            if (!this.w0 || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectD = A.d(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectD.left;
                rect.right -= rectD.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.T0 : this.U0;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.S0;
            if (colorStateList != null) {
                this.R0.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.R0.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i3 + i4) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.x0 : this.z0;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int iMax;
        int width;
        int paddingLeft;
        int i5;
        int paddingTop;
        int height;
        super.onLayout(z, i, i2, i3, i4);
        int iMax2 = 0;
        if (this.q != null) {
            Rect rect = this.a1;
            Drawable drawable = this.o0;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectD = A.d(this.q);
            iMax = Math.max(0, rectD.left - rect.left);
            iMax2 = Math.max(0, rectD.right - rect.right);
        } else {
            iMax = 0;
        }
        if (O.b(this)) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.J0 + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.J0) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity != 16) {
            if (gravity != 80) {
                paddingTop = getPaddingTop();
                i5 = this.K0;
            } else {
                height = getHeight() - getPaddingBottom();
                paddingTop = height - this.K0;
            }
            this.M0 = paddingLeft;
            this.N0 = paddingTop;
            this.P0 = height;
            this.O0 = width;
        }
        int paddingTop2 = ((getPaddingTop() + getHeight()) - getPaddingBottom()) / 2;
        i5 = this.K0;
        paddingTop = paddingTop2 - (i5 / 2);
        height = i5 + paddingTop;
        this.M0 = paddingLeft;
        this.N0 = paddingTop;
        this.P0 = height;
        this.O0 = width;
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i2) {
        int intrinsicWidth;
        int intrinsicHeight;
        if (this.B0) {
            if (this.T0 == null) {
                this.T0 = i(this.y0);
            }
            if (this.U0 == null) {
                this.U0 = i(this.A0);
            }
        }
        Rect rect = this.a1;
        Drawable drawable = this.q;
        int intrinsicHeight2 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.q.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.q.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.L0 = Math.max(this.B0 ? Math.max(this.T0.getWidth(), this.U0.getWidth()) + (this.t0 * 2) : 0, intrinsicWidth);
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.o0.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.q;
        if (drawable3 != null) {
            Rect rectD = A.d(drawable3);
            iMax = Math.max(iMax, rectD.left);
            iMax2 = Math.max(iMax2, rectD.right);
        }
        int iMax3 = this.Q0 ? Math.max(this.u0, (this.L0 * 2) + iMax + iMax2) : this.u0;
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.J0 = iMax3;
        this.K0 = iMax4;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.x0 : this.z0;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x008b  */
    /* JADX WARN: Code duplicated, block: B:36:0x008f  */
    /* JADX WARN: Code duplicated, block: B:38:0x0096  */
    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float f;
        this.G0.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            if (isEnabled() && h(x, y)) {
                this.C0 = 1;
                this.E0 = x;
                this.F0 = y;
            }
        } else if (actionMasked == 1) {
            if (this.C0 == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.C0 = 0;
            this.G0.clear();
        } else if (actionMasked == 2) {
            int i = this.C0;
            if (i == 1) {
                float x2 = motionEvent.getX();
                float y2 = motionEvent.getY();
                if (Math.abs(x2 - this.E0) > this.D0 || Math.abs(y2 - this.F0) > this.D0) {
                    this.C0 = 2;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    this.E0 = x2;
                    this.F0 = y2;
                    return true;
                }
            } else if (i == 2) {
                float x3 = motionEvent.getX();
                int thumbScrollRange = getThumbScrollRange();
                float f2 = x3 - this.E0;
                if (thumbScrollRange != 0) {
                    f = f2 / thumbScrollRange;
                } else {
                    f = f2 > 0.0f ? 1.0f : -1.0f;
                }
                if (O.b(this)) {
                    f = -f;
                }
                float f3 = f(this.I0 + f, 0.0f, 1.0f);
                if (f3 != this.I0) {
                    this.E0 = x3;
                    setThumbPosition(f3);
                }
                return true;
            }
        } else if (actionMasked == 3) {
            if (this.C0 == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.C0 = 0;
            this.G0.clear();
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z) {
        super.setChecked(z);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            l();
        } else {
            k();
        }
        if (getWindowToken() != null && isLaidOut()) {
            a(zIsChecked);
        } else {
            d();
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p115h0.j.p(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
        setTextOnInternal(this.x0);
        setTextOffInternal(this.z0);
        requestLayout();
    }

    protected final void setEnforceSwitchWidth(boolean z) {
        this.Q0 = z;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z) {
        if (this.B0 != z) {
            this.B0 = z;
            requestLayout();
            if (z) {
                p();
            }
        }
    }

    public void setSplitTrack(boolean z) {
        this.w0 = z;
        invalidate();
    }

    public void setSwitchMinWidth(int i) {
        this.u0 = i;
        requestLayout();
    }

    public void setSwitchPadding(int i) {
        this.v0 = i;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.R0.getTypeface() == null || this.R0.getTypeface().equals(typeface)) && (this.R0.getTypeface() != null || typeface == null)) {
            return;
        }
        this.R0.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            return;
        }
        k();
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            l();
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.q;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.q = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    void setThumbPosition(float f) {
        this.I0 = f;
        invalidate();
    }

    public void setThumbResource(int i) {
        setThumbDrawable(ax.p226o.a.b(getContext(), i));
    }

    public void setThumbTextPadding(int i) {
        this.t0 = i;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.k0 = colorStateList;
        this.m0 = true;
        b();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.l0 = mode;
        this.n0 = true;
        b();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.o0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i) {
        setTrackDrawable(ax.p226o.a.b(getContext(), i));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.p0 = colorStateList;
        this.r0 = true;
        c();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.q0 = mode;
        this.s0 = true;
        c();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.q || drawable == this.o0;
    }
}
