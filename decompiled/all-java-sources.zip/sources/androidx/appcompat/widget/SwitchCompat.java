package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import ax.p015b0.Y;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    private static final Property<SwitchCompat, Float> Y0 = new a(Float.class, "thumbPos");
    private static final int[] Z0 = {R.attr.state_checked};
    private int A0;
    private float B0;
    private float C0;
    private VelocityTracker D0;
    private int E0;
    float F0;
    private int G0;
    private int H0;
    private int I0;
    private int J0;
    private int K0;
    private int L0;
    private int M0;
    private boolean N0;
    private final TextPaint O0;
    private ColorStateList P0;
    private Layout Q0;
    private Layout R0;
    private TransformationMethod S0;
    ObjectAnimator T0;
    private final w U0;
    private C0561n V0;
    private b W0;
    private final Rect X0;
    private ColorStateList h0;
    private PorterDuff.Mode i0;
    private boolean j0;
    private boolean k0;
    private Drawable l0;
    private ColorStateList m0;
    private PorterDuff.Mode n0;
    private boolean o0;
    private boolean p0;
    private Drawable q;
    private int q0;
    private int r0;
    private int s0;
    private boolean t0;
    private CharSequence u0;
    private CharSequence v0;
    private CharSequence w0;
    private CharSequence x0;
    private boolean y0;
    private int z0;

    class a extends Property<SwitchCompat, Float> {
        a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(SwitchCompat switchCompat) {
            return Float.valueOf(switchCompat.F0);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(SwitchCompat switchCompat, Float f) {
            switchCompat.setThumbPosition(f.floatValue());
        }
    }

    static class b extends androidx.emoji2.text.e.f {
        private final Reference<SwitchCompat> a;

        b(SwitchCompat switchCompat) {
            this.a = new WeakReference(switchCompat);
        }

        @Override // androidx.emoji2.text.e.f
        public void a(Throwable th) {
            SwitchCompat switchCompat = this.a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }

        @Override // androidx.emoji2.text.e.f
        public void b() {
            SwitchCompat switchCompat = this.a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.N);
    }

    private void a(boolean z) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, Y0, z ? 1.0f : 0.0f);
        this.T0 = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.T0.setAutoCancel(true);
        this.T0.start();
    }

    private void b() {
        Drawable drawable = this.q;
        if (drawable != null) {
            if (this.j0 || this.k0) {
                Drawable drawableMutate = ax.T.a.r(drawable).mutate();
                this.q = drawableMutate;
                if (this.j0) {
                    ax.T.a.o(drawableMutate, this.h0);
                }
                if (this.k0) {
                    ax.T.a.p(this.q, this.i0);
                }
                if (this.q.isStateful()) {
                    this.q.setState(getDrawableState());
                }
            }
        }
    }

    private void c() {
        Drawable drawable = this.l0;
        if (drawable != null) {
            if (this.o0 || this.p0) {
                Drawable drawableMutate = ax.T.a.r(drawable).mutate();
                this.l0 = drawableMutate;
                if (this.o0) {
                    ax.T.a.o(drawableMutate, this.m0);
                }
                if (this.p0) {
                    ax.T.a.p(this.l0, this.n0);
                }
                if (this.l0.isStateful()) {
                    this.l0.setState(getDrawableState());
                }
            }
        }
    }

    private void d() {
        ObjectAnimator objectAnimator = this.T0;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    private void e(MotionEvent motionEvent) {
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.setAction(3);
        super.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    private static float f(float f, float f2, float f3) {
        if (f < f2) {
            return f2;
        }
        return f > f3 ? f3 : f;
    }

    private CharSequence g(CharSequence charSequence) {
        TransformationMethod transformationMethodF = getEmojiTextViewHelper().f(this.S0);
        return transformationMethodF != null ? transformationMethodF.getTransformation(charSequence, this) : charSequence;
    }

    private C0561n getEmojiTextViewHelper() {
        if (this.V0 == null) {
            this.V0 = new C0561n(this);
        }
        return this.V0;
    }

    private boolean getTargetCheckedState() {
        return this.F0 > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((O.b(this) ? 1.0f - this.F0 : this.F0) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.l0;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.X0;
        drawable.getPadding(rect);
        Drawable drawable2 = this.q;
        Rect rectD = drawable2 != null ? A.d(drawable2) : A.c;
        return ((((this.G0 - this.I0) - rect.left) - rect.right) - rectD.left) - rectD.right;
    }

    private boolean h(float f, float f2) {
        if (this.q == null) {
            return false;
        }
        int thumbOffset = getThumbOffset();
        this.q.getPadding(this.X0);
        int i = this.K0;
        int i2 = this.A0;
        int i3 = i - i2;
        int i4 = (this.J0 + thumbOffset) - i2;
        int i5 = this.I0 + i4;
        Rect rect = this.X0;
        return f > ((float) i4) && f < ((float) (((i5 + rect.left) + rect.right) + i2)) && f2 > ((float) i3) && f2 < ((float) (this.M0 + i2));
    }

    private Layout i(CharSequence charSequence) {
        TextPaint textPaint = this.O0;
        return new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    private void k() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.w0;
            if (string == null) {
                string = getResources().getString(ax.p168m.h.b);
            }
            Y.J0(this, string);
        }
    }

    private void l() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.u0;
            if (string == null) {
                string = getResources().getString(ax.p168m.h.c);
            }
            Y.J0(this, string);
        }
    }

    private void o(int i, int i2) {
        Typeface typeface;
        if (i == 1) {
            typeface = Typeface.SANS_SERIF;
        } else if (i != 2) {
            typeface = i != 3 ? null : Typeface.MONOSPACE;
        } else {
            typeface = Typeface.SERIF;
        }
        n(typeface, i2);
    }

    private void p() {
        if (this.W0 == null && this.V0.b() && androidx.emoji2.text.e.i()) {
            androidx.emoji2.text.e eVarC = androidx.emoji2.text.e.c();
            int iE = eVarC.e();
            if (iE == 3 || iE == 0) {
                b bVar = new b(this);
                this.W0 = bVar;
                eVarC.t(bVar);
            }
        }
    }

    private void q(MotionEvent motionEvent) {
        this.z0 = 0;
        boolean targetCheckedState = true;
        boolean z = motionEvent.getAction() == 1 && isEnabled();
        boolean zIsChecked = isChecked();
        if (z) {
            this.D0.computeCurrentVelocity(1000);
            float xVelocity = this.D0.getXVelocity();
            if (Math.abs(xVelocity) <= this.E0) {
                targetCheckedState = getTargetCheckedState();
            } else if (!O.b(this) ? xVelocity <= 0.0f : xVelocity >= 0.0f) {
                targetCheckedState = false;
            }
        } else {
            targetCheckedState = zIsChecked;
        }
        if (targetCheckedState != zIsChecked) {
            playSoundEffect(0);
        }
        setChecked(targetCheckedState);
        e(motionEvent);
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.w0 = charSequence;
        this.x0 = g(charSequence);
        this.R0 = null;
        if (this.y0) {
            p();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.u0 = charSequence;
        this.v0 = g(charSequence);
        this.Q0 = null;
        if (this.y0) {
            p();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i;
        int i2;
        Rect rect = this.X0;
        int i3 = this.J0;
        int i4 = this.K0;
        int i5 = this.L0;
        int i6 = this.M0;
        int thumbOffset = getThumbOffset() + i3;
        Drawable drawable = this.q;
        Rect rectD = drawable != null ? A.d(drawable) : A.c;
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i7 = rect.left;
            thumbOffset += i7;
            if (rectD != null) {
                int i8 = rectD.left;
                if (i8 > i7) {
                    i3 += i8 - i7;
                }
                int i9 = rectD.top;
                int i10 = rect.top;
                i = i9 > i10 ? (i9 - i10) + i4 : i4;
                int i11 = rectD.right;
                int i12 = rect.right;
                if (i11 > i12) {
                    i5 -= i11 - i12;
                }
                int i13 = rectD.bottom;
                int i14 = rect.bottom;
                if (i13 > i14) {
                    i2 = i6 - (i13 - i14);
                }
                this.l0.setBounds(i3, i, i5, i2);
            } else {
                i = i4;
            }
            i2 = i6;
            this.l0.setBounds(i3, i, i5, i2);
        }
        Drawable drawable3 = this.q;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i15 = thumbOffset - rect.left;
            int i16 = thumbOffset + this.I0 + rect.right;
            this.q.setBounds(i15, i4, i16, i6);
            Drawable background = getBackground();
            if (background != null) {
                ax.T.a.l(background, i15, i4, i16, i6);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.q;
        if (drawable != null) {
            ax.T.a.k(drawable, f, f2);
        }
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            ax.T.a.k(drawable2, f, f2);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.q;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.l0;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        if (!O.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.G0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.s0 : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        if (O.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.G0;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.s0 : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p099h0.j.r(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.y0;
    }

    public boolean getSplitTrack() {
        return this.t0;
    }

    public int getSwitchMinWidth() {
        return this.r0;
    }

    public int getSwitchPadding() {
        return this.s0;
    }

    public CharSequence getTextOff() {
        return this.w0;
    }

    public CharSequence getTextOn() {
        return this.u0;
    }

    public Drawable getThumbDrawable() {
        return this.q;
    }

    protected final float getThumbPosition() {
        return this.F0;
    }

    public int getThumbTextPadding() {
        return this.q0;
    }

    public ColorStateList getThumbTintList() {
        return this.h0;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.i0;
    }

    public Drawable getTrackDrawable() {
        return this.l0;
    }

    public ColorStateList getTrackTintList() {
        return this.m0;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.n0;
    }

    void j() {
        setTextOnInternal(this.u0);
        setTextOffInternal(this.w0);
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.q;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.T0;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.T0.end();
        this.T0 = null;
    }

    public void m(Context context, int i) {
        L lT = L.t(context, i, ax.p168m.j.J2);
        ColorStateList colorStateListC = lT.c(ax.p168m.j.N2);
        if (colorStateListC != null) {
            this.P0 = colorStateListC;
        } else {
            this.P0 = getTextColors();
        }
        int iF = lT.f(ax.p168m.j.K2, 0);
        if (iF != 0) {
            float f = iF;
            if (f != this.O0.getTextSize()) {
                this.O0.setTextSize(f);
                requestLayout();
            }
        }
        o(lT.k(ax.p168m.j.L2, -1), lT.k(ax.p168m.j.M2, -1));
        if (lT.a(ax.p168m.j.U2, false)) {
            this.S0 = new ax.p238r.a(getContext());
        } else {
            this.S0 = null;
        }
        setTextOnInternal(this.u0);
        setTextOffInternal(this.w0);
        lT.x();
    }

    public void n(Typeface typeface, int i) {
        if (i <= 0) {
            this.O0.setFakeBoldText(false);
            this.O0.setTextSkewX(0.0f);
            setSwitchTypeface(typeface);
        } else {
            Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i) : Typeface.create(typeface, i);
            setSwitchTypeface(typefaceDefaultFromStyle);
            int i2 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i;
            this.O0.setFakeBoldText((i2 & 1) != 0);
            this.O0.setTextSkewX((i2 & 2) != 0 ? -0.25f : 0.0f);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected int[] onCreateDrawableState(int i) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, Z0);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Rect rect = this.X0;
        Drawable drawable = this.l0;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.K0;
        int i2 = this.M0;
        int i3 = i + rect.top;
        int i4 = i2 - rect.bottom;
        Drawable drawable2 = this.q;
        if (drawable != null) {
            if (!this.t0 || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectD = A.d(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectD.left;
                rect.right -= rectD.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.Q0 : this.R0;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.P0;
            if (colorStateList != null) {
                this.O0.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.O0.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i3 + i4) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.u0 : this.w0;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int iMax;
        int width;
        int paddingLeft;
        int i5;
        int paddingTop;
        int height;
        super.onLayout(z, i, i2, i3, i4);
        int iMax2 = 0;
        if (this.q != null) {
            Rect rect = this.X0;
            Drawable drawable = this.l0;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectD = A.d(this.q);
            iMax = Math.max(0, rectD.left - rect.left);
            iMax2 = Math.max(0, rectD.right - rect.right);
        } else {
            iMax = 0;
        }
        if (O.b(this)) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.G0 + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.G0) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity != 16) {
            if (gravity != 80) {
                paddingTop = getPaddingTop();
                i5 = this.H0;
            } else {
                height = getHeight() - getPaddingBottom();
                paddingTop = height - this.H0;
            }
            this.J0 = paddingLeft;
            this.K0 = paddingTop;
            this.M0 = height;
            this.L0 = width;
        }
        int paddingTop2 = ((getPaddingTop() + getHeight()) - getPaddingBottom()) / 2;
        i5 = this.H0;
        paddingTop = paddingTop2 - (i5 / 2);
        height = i5 + paddingTop;
        this.J0 = paddingLeft;
        this.K0 = paddingTop;
        this.M0 = height;
        this.L0 = width;
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i2) {
        int intrinsicWidth;
        int intrinsicHeight;
        if (this.y0) {
            if (this.Q0 == null) {
                this.Q0 = i(this.v0);
            }
            if (this.R0 == null) {
                this.R0 = i(this.x0);
            }
        }
        Rect rect = this.X0;
        Drawable drawable = this.q;
        int intrinsicHeight2 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.q.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.q.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.I0 = Math.max(this.y0 ? Math.max(this.Q0.getWidth(), this.R0.getWidth()) + (this.q0 * 2) : 0, intrinsicWidth);
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.l0.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.q;
        if (drawable3 != null) {
            Rect rectD = A.d(drawable3);
            iMax = Math.max(iMax, rectD.left);
            iMax2 = Math.max(iMax2, rectD.right);
        }
        int iMax3 = this.N0 ? Math.max(this.r0, (this.I0 * 2) + iMax + iMax2) : this.r0;
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.G0 = iMax3;
        this.H0 = iMax4;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.u0 : this.w0;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x008b  */
    /* JADX WARN: Code duplicated, block: B:36:0x008f  */
    /* JADX WARN: Code duplicated, block: B:38:0x0096  */
    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float f;
        this.D0.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            if (isEnabled() && h(x, y)) {
                this.z0 = 1;
                this.B0 = x;
                this.C0 = y;
            }
        } else if (actionMasked == 1) {
            if (this.z0 == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.z0 = 0;
            this.D0.clear();
        } else if (actionMasked == 2) {
            int i = this.z0;
            if (i == 1) {
                float x2 = motionEvent.getX();
                float y2 = motionEvent.getY();
                if (Math.abs(x2 - this.B0) > this.A0 || Math.abs(y2 - this.C0) > this.A0) {
                    this.z0 = 2;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    this.B0 = x2;
                    this.C0 = y2;
                    return true;
                }
            } else if (i == 2) {
                float x3 = motionEvent.getX();
                int thumbScrollRange = getThumbScrollRange();
                float f2 = x3 - this.B0;
                if (thumbScrollRange != 0) {
                    f = f2 / thumbScrollRange;
                } else {
                    f = f2 > 0.0f ? 1.0f : -1.0f;
                }
                if (O.b(this)) {
                    f = -f;
                }
                float f3 = f(this.F0 + f, 0.0f, 1.0f);
                if (f3 != this.F0) {
                    this.B0 = x3;
                    setThumbPosition(f3);
                }
                return true;
            }
        } else if (actionMasked == 3) {
            if (this.z0 == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.z0 = 0;
            this.D0.clear();
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z) {
        super.setChecked(z);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            l();
        } else {
            k();
        }
        if (getWindowToken() != null && isLaidOut()) {
            a(zIsChecked);
        } else {
            d();
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p099h0.j.s(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
        setTextOnInternal(this.u0);
        setTextOffInternal(this.w0);
        requestLayout();
    }

    protected final void setEnforceSwitchWidth(boolean z) {
        this.N0 = z;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z) {
        if (this.y0 != z) {
            this.y0 = z;
            requestLayout();
            if (z) {
                p();
            }
        }
    }

    public void setSplitTrack(boolean z) {
        this.t0 = z;
        invalidate();
    }

    public void setSwitchMinWidth(int i) {
        this.r0 = i;
        requestLayout();
    }

    public void setSwitchPadding(int i) {
        this.s0 = i;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.O0.getTypeface() == null || this.O0.getTypeface().equals(typeface)) && (this.O0.getTypeface() != null || typeface == null)) {
            return;
        }
        this.O0.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            return;
        }
        k();
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            l();
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.q;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.q = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    void setThumbPosition(float f) {
        this.F0 = f;
        invalidate();
    }

    public void setThumbResource(int i) {
        setThumbDrawable(ax.p196o.a.b(getContext(), i));
    }

    public void setThumbTextPadding(int i) {
        this.q0 = i;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.h0 = colorStateList;
        this.j0 = true;
        b();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.i0 = mode;
        this.k0 = true;
        b();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.l0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i) {
        setTrackDrawable(ax.p196o.a.b(getContext(), i));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.m0 = colorStateList;
        this.o0 = true;
        c();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.n0 = mode;
        this.p0 = true;
        c();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.q || drawable == this.l0;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.h0 = null;
        this.i0 = null;
        this.j0 = false;
        this.k0 = false;
        this.m0 = null;
        this.n0 = null;
        this.o0 = false;
        this.p0 = false;
        this.D0 = VelocityTracker.obtain();
        this.N0 = true;
        this.X0 = new Rect();
        H.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.O0 = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = ax.p168m.j.u2;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        Y.o0(this, context, iArr, attributeSet, lV.r(), i, 0);
        Drawable drawableG = lV.g(ax.p168m.j.x2);
        this.q = drawableG;
        if (drawableG != null) {
            drawableG.setCallback(this);
        }
        Drawable drawableG2 = lV.g(ax.p168m.j.G2);
        this.l0 = drawableG2;
        if (drawableG2 != null) {
            drawableG2.setCallback(this);
        }
        setTextOnInternal(lV.p(ax.p168m.j.v2));
        setTextOffInternal(lV.p(ax.p168m.j.w2));
        this.y0 = lV.a(ax.p168m.j.y2, true);
        this.q0 = lV.f(ax.p168m.j.D2, 0);
        this.r0 = lV.f(ax.p168m.j.A2, 0);
        this.s0 = lV.f(ax.p168m.j.B2, 0);
        this.t0 = lV.a(ax.p168m.j.z2, false);
        ColorStateList colorStateListC = lV.c(ax.p168m.j.E2);
        if (colorStateListC != null) {
            this.h0 = colorStateListC;
            this.j0 = true;
        }
        PorterDuff.Mode modeE = A.e(lV.k(ax.p168m.j.F2, -1), null);
        if (this.i0 != modeE) {
            this.i0 = modeE;
            this.k0 = true;
        }
        if (this.j0 || this.k0) {
            b();
        }
        ColorStateList colorStateListC2 = lV.c(ax.p168m.j.H2);
        if (colorStateListC2 != null) {
            this.m0 = colorStateListC2;
            this.o0 = true;
        }
        PorterDuff.Mode modeE2 = A.e(lV.k(ax.p168m.j.I2, -1), null);
        if (this.n0 != modeE2) {
            this.n0 = modeE2;
            this.p0 = true;
        }
        if (this.o0 || this.p0) {
            c();
        }
        int iN = lV.n(ax.p168m.j.C2, 0);
        if (iN != 0) {
            m(context, iN);
        }
        w wVar = new w(this);
        this.U0 = wVar;
        wVar.m(attributeSet, i);
        lV.x();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.A0 = viewConfiguration.getScaledTouchSlop();
        this.E0 = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().c(attributeSet, i);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
