package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import ax.p015b0.C5224i0;
import ax.p015b0.Y;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends AbstractC0548a {
    private CharSequence o0;
    private CharSequence p0;
    private View q0;
    private View r0;
    private View s0;
    private LinearLayout t0;
    private TextView u0;
    private TextView v0;
    private int w0;
    private int x0;
    private boolean y0;
    private int z0;

    class a implements View.OnClickListener {
        final /* synthetic */ androidx.appcompat.view.a q;

        a(androidx.appcompat.view.a aVar) {
            this.q = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.q.c();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    private void i() {
        if (this.t0 == null) {
            LayoutInflater.from(getContext()).inflate(ax.p168m.g.a, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.t0 = linearLayout;
            this.u0 = (TextView) linearLayout.findViewById(ax.p168m.f.e);
            this.v0 = (TextView) this.t0.findViewById(ax.p168m.f.d);
            if (this.w0 != 0) {
                this.u0.setTextAppearance(getContext(), this.w0);
            }
            if (this.x0 != 0) {
                this.v0.setTextAppearance(getContext(), this.x0);
            }
        }
        this.u0.setText(this.o0);
        this.v0.setText(this.p0);
        boolean z = !TextUtils.isEmpty(this.o0);
        boolean z2 = !TextUtils.isEmpty(this.p0);
        this.v0.setVisibility(z2 ? 0 : 8);
        this.t0.setVisibility((z || z2) ? 0 : 8);
        if (this.t0.getParent() == null) {
            addView(this.t0);
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0548a
    public /* bridge */ /* synthetic */ C5224i0 f(int i, long j) {
        return super.f(i, j);
    }

    public void g() {
        if (this.q0 == null) {
            k();
        }
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.AbstractC0548a
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // androidx.appcompat.widget.AbstractC0548a
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.p0;
    }

    public CharSequence getTitle() {
        return this.o0;
    }

    public void h(androidx.appcompat.view.a aVar) {
        View view = this.q0;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.z0, (ViewGroup) this, false);
            this.q0 = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.q0);
        }
        View viewFindViewById = this.q0.findViewById(ax.p168m.f.i);
        this.r0 = viewFindViewById;
        viewFindViewById.setOnClickListener(new a(aVar));
        androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) aVar.e();
        C0550c c0550c = this.j0;
        if (c0550c != null) {
            c0550c.y();
        }
        C0550c c0550c2 = new C0550c(getContext());
        this.j0 = c0550c2;
        c0550c2.J(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        eVar.c(this.j0, this.h0);
        ActionMenuView actionMenuView = (ActionMenuView) this.j0.o(this);
        this.i0 = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.i0, layoutParams);
    }

    public boolean j() {
        return this.y0;
    }

    public void k() {
        removeAllViews();
        this.s0 = null;
        this.i0 = null;
        this.j0 = null;
        View view = this.r0;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public boolean l() {
        C0550c c0550c = this.j0;
        if (c0550c != null) {
            return c0550c.K();
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0550c c0550c = this.j0;
        if (c0550c != null) {
            c0550c.B();
            this.j0.C();
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0548a, android.view.View
    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean zB = O.b(this);
        int paddingRight = zB ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.q0;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.q0.getLayoutParams();
            int i5 = zB ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = zB ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int iD = AbstractC0548a.d(paddingRight, i5, zB);
            paddingRight = AbstractC0548a.d(iD + e(this.q0, iD, paddingTop, paddingTop2, zB), i6, zB);
        }
        int iE = paddingRight;
        LinearLayout linearLayout = this.t0;
        if (linearLayout != null && this.s0 == null && linearLayout.getVisibility() != 8) {
            iE += e(this.t0, iE, paddingTop, paddingTop2, zB);
        }
        int i7 = iE;
        View view2 = this.s0;
        if (view2 != null) {
            e(view2, i7, paddingTop, paddingTop2, zB);
        }
        int paddingLeft = zB ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.i0;
        if (actionMenuView != null) {
            e(actionMenuView, paddingLeft, paddingTop, paddingTop2, !zB);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i2) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.k0;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i2);
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingTop;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.q0;
        if (view != null) {
            int iC = c(view, paddingLeft, iMakeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.q0.getLayoutParams();
            paddingLeft = iC - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.i0;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(this.i0, paddingLeft, iMakeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.t0;
        if (linearLayout != null && this.s0 == null) {
            if (this.y0) {
                this.t0.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.t0.getMeasuredWidth();
                boolean z = measuredWidth <= paddingLeft;
                if (z) {
                    paddingLeft -= measuredWidth;
                }
                this.t0.setVisibility(z ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, iMakeMeasureSpec, 0);
            }
        }
        View view2 = this.s0;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i3 = layoutParams.width;
            int i4 = i3 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i3 >= 0) {
                paddingLeft = Math.min(i3, paddingLeft);
            }
            int i5 = layoutParams.height;
            int i6 = i5 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i5 >= 0) {
                iMin = Math.min(i5, iMin);
            }
            this.s0.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i4), View.MeasureSpec.makeMeasureSpec(iMin, i6));
        }
        if (this.k0 > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            int measuredHeight = getChildAt(i8).getMeasuredHeight() + paddingTop;
            if (measuredHeight > i7) {
                i7 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i7);
    }

    @Override // androidx.appcompat.widget.AbstractC0548a, android.view.View
    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // androidx.appcompat.widget.AbstractC0548a
    public void setContentHeight(int i) {
        this.k0 = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.s0;
        if (view2 != null) {
            removeView(view2);
        }
        this.s0 = view;
        if (view != null && (linearLayout = this.t0) != null) {
            removeView(linearLayout);
            this.t0 = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.p0 = charSequence;
        i();
    }

    public void setTitle(CharSequence charSequence) {
        this.o0 = charSequence;
        i();
        Y.t0(this, charSequence);
    }

    public void setTitleOptional(boolean z) {
        if (z != this.y0) {
            requestLayout();
        }
        this.y0 = z;
    }

    @Override // androidx.appcompat.widget.AbstractC0548a, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.j);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        L lV = L.v(context, attributeSet, ax.p168m.j.y, i, 0);
        setBackground(lV.g(ax.p168m.j.z));
        this.w0 = lV.n(ax.p168m.j.D, 0);
        this.x0 = lV.n(ax.p168m.j.C, 0);
        this.k0 = lV.m(ax.p168m.j.B, 0);
        this.z0 = lV.n(ax.p168m.j.A, ax.p168m.g.d);
        lV.x();
    }
}
