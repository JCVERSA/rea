package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import ax.p035c0.C1839d0;
import ax.p035c0.C1859n0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends AbstractC0591a {
    private int A0;
    private boolean B0;
    private int C0;
    private CharSequence r0;
    private CharSequence s0;
    private View t0;
    private View u0;
    private View v0;
    private LinearLayout w0;
    private TextView x0;
    private TextView y0;
    private int z0;

    class a implements View.OnClickListener {
        final /* synthetic */ androidx.appcompat.view.a q;

        a(androidx.appcompat.view.a aVar) {
            this.q = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.q.c();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.j);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        L lV = L.v(context, attributeSet, ax.p194m.j.y, i, 0);
        setBackground(lV.g(ax.p194m.j.z));
        this.z0 = lV.n(ax.p194m.j.D, 0);
        this.A0 = lV.n(ax.p194m.j.C, 0);
        this.n0 = lV.m(ax.p194m.j.B, 0);
        this.C0 = lV.n(ax.p194m.j.A, ax.p194m.g.d);
        lV.x();
    }

    private void i() {
        if (this.w0 == null) {
            LayoutInflater.from(getContext()).inflate(ax.p194m.g.a, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.w0 = linearLayout;
            this.x0 = (TextView) linearLayout.findViewById(ax.p194m.f.e);
            this.y0 = (TextView) this.w0.findViewById(ax.p194m.f.d);
            if (this.z0 != 0) {
                this.x0.setTextAppearance(getContext(), this.z0);
            }
            if (this.A0 != 0) {
                this.y0.setTextAppearance(getContext(), this.A0);
            }
        }
        this.x0.setText(this.r0);
        this.y0.setText(this.s0);
        boolean zIsEmpty = TextUtils.isEmpty(this.r0);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.s0);
        this.y0.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.w0.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.w0.getParent() == null) {
            addView(this.w0);
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0591a
    public /* bridge */ /* synthetic */ C1859n0 f(int i, long j) {
        return super.f(i, j);
    }

    public void g() {
        if (this.t0 == null) {
            k();
        }
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.AbstractC0591a
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // androidx.appcompat.widget.AbstractC0591a
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.s0;
    }

    public CharSequence getTitle() {
        return this.r0;
    }

    public void h(androidx.appcompat.view.a aVar) {
        View view = this.t0;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.C0, (ViewGroup) this, false);
            this.t0 = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.t0);
        }
        View viewFindViewById = this.t0.findViewById(ax.p194m.f.i);
        this.u0 = viewFindViewById;
        viewFindViewById.setOnClickListener(new a(aVar));
        androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) aVar.e();
        C0593c c0593c = this.m0;
        if (c0593c != null) {
            c0593c.y();
        }
        C0593c c0593c2 = new C0593c(getContext());
        this.m0 = c0593c2;
        c0593c2.J(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        eVar.c(this.m0, this.k0);
        ActionMenuView actionMenuView = (ActionMenuView) this.m0.o(this);
        this.l0 = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.l0, layoutParams);
    }

    public boolean j() {
        return this.B0;
    }

    public void k() {
        removeAllViews();
        this.v0 = null;
        this.l0 = null;
        this.m0 = null;
        View view = this.u0;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public boolean l() {
        C0593c c0593c = this.m0;
        if (c0593c != null) {
            return c0593c.K();
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0593c c0593c = this.m0;
        if (c0593c != null) {
            c0593c.B();
            this.m0.C();
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0591a, android.view.View
    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean zB = O.b(this);
        int paddingRight = zB ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.t0;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.t0.getLayoutParams();
            int i5 = zB ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = zB ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int iD = AbstractC0591a.d(paddingRight, i5, zB);
            paddingRight = AbstractC0591a.d(iD + e(this.t0, iD, paddingTop, paddingTop2, zB), i6, zB);
        }
        int iE = paddingRight;
        LinearLayout linearLayout = this.w0;
        if (linearLayout != null && this.v0 == null && linearLayout.getVisibility() != 8) {
            iE += e(this.w0, iE, paddingTop, paddingTop2, zB);
        }
        View view2 = this.v0;
        if (view2 != null) {
            e(view2, iE, paddingTop, paddingTop2, zB);
        }
        int paddingLeft = zB ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.l0;
        if (actionMenuView != null) {
            e(actionMenuView, paddingLeft, paddingTop, paddingTop2, !zB);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i2) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.n0;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i2);
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingTop;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.t0;
        if (view != null) {
            int iC = c(view, paddingLeft, iMakeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.t0.getLayoutParams();
            paddingLeft = iC - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.l0;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(this.l0, paddingLeft, iMakeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.w0;
        if (linearLayout != null && this.v0 == null) {
            if (this.B0) {
                this.w0.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.w0.getMeasuredWidth();
                boolean z = measuredWidth <= paddingLeft;
                if (z) {
                    paddingLeft -= measuredWidth;
                }
                this.w0.setVisibility(z ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, iMakeMeasureSpec, 0);
            }
        }
        View view2 = this.v0;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i3 = layoutParams.width;
            int i4 = i3 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i3 >= 0) {
                paddingLeft = Math.min(i3, paddingLeft);
            }
            int i5 = layoutParams.height;
            int i6 = i5 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i5 >= 0) {
                iMin = Math.min(i5, iMin);
            }
            this.v0.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i4), View.MeasureSpec.makeMeasureSpec(iMin, i6));
        }
        if (this.n0 > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            int measuredHeight = getChildAt(i8).getMeasuredHeight() + paddingTop;
            if (measuredHeight > i7) {
                i7 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i7);
    }

    @Override // androidx.appcompat.widget.AbstractC0591a, android.view.View
    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // androidx.appcompat.widget.AbstractC0591a
    public void setContentHeight(int i) {
        this.n0 = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.v0;
        if (view2 != null) {
            removeView(view2);
        }
        this.v0 = view;
        if (view != null && (linearLayout = this.w0) != null) {
            removeView(linearLayout);
            this.w0 = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.s0 = charSequence;
        i();
    }

    public void setTitle(CharSequence charSequence) {
        this.r0 = charSequence;
        i();
        C1839d0.n0(this, charSequence);
    }

    public void setTitleOptional(boolean z) {
        if (z != this.B0) {
            requestLayout();
        }
        this.B0 = z;
    }

    @Override // androidx.appcompat.widget.AbstractC0591a, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
