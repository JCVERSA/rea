package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import ax.p035c0.C1839d0;
import ax.p035c0.C1859n0;
import ax.p035c0.InterfaceC1861o0;

/* JADX INFO: renamed from: androidx.appcompat.widget.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC0591a extends ViewGroup {
    protected final Context k0;
    protected ActionMenuView l0;
    protected C0593c m0;
    protected int n0;
    protected C1859n0 o0;
    private boolean p0;
    protected final C0011a q;
    private boolean q0;

    /* JADX INFO: renamed from: androidx.appcompat.widget.a$a, reason: collision with other inner class name */
    protected class C0011a implements InterfaceC1861o0 {
        private boolean a = false;
        int b;

        protected C0011a() {
        }

        @Override // ax.p035c0.InterfaceC1861o0
        public void a(View view) {
            this.a = true;
        }

        @Override // ax.p035c0.InterfaceC1861o0
        public void b(View view) {
            if (this.a) {
                return;
            }
            AbstractC0591a abstractC0591a = AbstractC0591a.this;
            abstractC0591a.o0 = null;
            AbstractC0591a.super.setVisibility(this.b);
        }

        @Override // ax.p035c0.InterfaceC1861o0
        public void c(View view) {
            AbstractC0591a.super.setVisibility(0);
            this.a = false;
        }

        public C0011a d(C1859n0 c1859n0, int i) {
            AbstractC0591a.this.o0 = c1859n0;
            this.b = i;
            return this;
        }
    }

    AbstractC0591a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    AbstractC0591a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q = new C0011a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(ax.p194m.a.a, typedValue, true) || typedValue.resourceId == 0) {
            this.k0 = context;
        } else {
            this.k0 = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    protected static int d(int i, int i2, boolean z) {
        return z ? i - i2 : i + i2;
    }

    protected int c(View view, int i, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    protected int e(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i2 + ((i3 - measuredHeight) / 2);
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public C1859n0 f(int i, long j) {
        C1859n0 c1859n0 = this.o0;
        if (c1859n0 != null) {
            c1859n0.c();
        }
        if (i != 0) {
            C1859n0 c1859n0B = C1839d0.e(this).b(0.0f);
            c1859n0B.e(j);
            c1859n0B.g(this.q.d(c1859n0B, i));
            return c1859n0B;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        C1859n0 c1859n0B2 = C1839d0.e(this).b(1.0f);
        c1859n0B2.e(j);
        c1859n0B2.g(this.q.d(c1859n0B2, i));
        return c1859n0B2;
    }

    public int getAnimatedVisibility() {
        return this.o0 != null ? this.q.b : getVisibility();
    }

    public int getContentHeight() {
        return this.n0;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, ax.p194m.j.a, ax.p194m.a.c, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(ax.p194m.j.j, 0));
        typedArrayObtainStyledAttributes.recycle();
        C0593c c0593c = this.m0;
        if (c0593c != null) {
            c0593c.F(configuration);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.q0 = false;
        }
        if (!this.q0) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.q0 = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.q0 = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.p0 = false;
        }
        if (!this.p0) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.p0 = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.p0 = false;
        }
        return true;
    }

    public void setContentHeight(int i) {
        this.n0 = i;
        requestLayout();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        if (i != getVisibility()) {
            C1859n0 c1859n0 = this.o0;
            if (c1859n0 != null) {
                c1859n0.c();
            }
            super.setVisibility(i);
        }
    }
}
