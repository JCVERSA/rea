package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;

/* JADX INFO: loaded from: classes.dex */
public class r extends MultiAutoCompleteTextView implements ax.p115h0.n {
    private static final int[] m0 = {R.attr.popupBackground};
    private final w k0;
    private final C0603m l0;
    private final C0595e q;

    public r(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.p);
    }

    public r(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        L lV = L.v(getContext(), attributeSet, m0, i, 0);
        if (lV.s(0)) {
            setDropDownBackgroundDrawable(lV.g(0));
        }
        lV.x();
        C0595e c0595e = new C0595e(this);
        this.q = c0595e;
        c0595e.e(attributeSet, i);
        w wVar = new w(this);
        this.k0 = wVar;
        wVar.m(attributeSet, i);
        wVar.b();
        C0603m c0603m = new C0603m(this);
        this.l0 = c0603m;
        c0603m.c(attributeSet, i);
        a(c0603m);
    }

    void a(C0603m c0603m) {
        KeyListener keyListener = getKeyListener();
        if (c0603m.b(keyListener)) {
            boolean zIsFocusable = super.isFocusable();
            boolean zIsClickable = super.isClickable();
            boolean zIsLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener keyListenerA = c0603m.a(keyListener);
            if (keyListenerA == keyListener) {
                return;
            }
            super.setKeyListener(keyListenerA);
            super.setRawInputType(inputType);
            super.setFocusable(zIsFocusable);
            super.setClickable(zIsClickable);
            super.setLongClickable(zIsLongClickable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.b();
        }
        w wVar = this.k0;
        if (wVar != null) {
            wVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.k0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.k0.k();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return this.l0.d(C0605o.a(super.onCreateInputConnection(editorInfo), editorInfo, this), editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.g(i);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.k0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.k0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(ax.p226o.a.b(getContext(), i));
    }

    public void setEmojiCompatEnabled(boolean z) {
        this.l0.e(z);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.l0.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.j(mode);
        }
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.k0.w(colorStateList);
        this.k0.b();
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.k0.x(mode);
        this.k0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        w wVar = this.k0;
        if (wVar != null) {
            wVar.q(context, i);
        }
    }
}
