package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends B implements androidx.appcompat.view.menu.e.b, androidx.appcompat.view.menu.k {
    private int A0;
    private boolean B0;
    private C0593c C0;
    private androidx.appcompat.view.menu.j.a D0;
    androidx.appcompat.view.menu.e.a E0;
    private boolean F0;
    private int G0;
    private int H0;
    private int I0;
    e J0;
    private androidx.appcompat.view.menu.e y0;
    private Context z0;

    public interface a {
        boolean a();

        boolean b();
    }

    private static class b implements androidx.appcompat.view.menu.j.a {
        b() {
        }

        @Override // androidx.appcompat.view.menu.j.a
        public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
        }

        @Override // androidx.appcompat.view.menu.j.a
        public boolean b(androidx.appcompat.view.menu.e eVar) {
            return false;
        }
    }

    public static class c extends B.a {

        @ViewDebug.ExportedProperty
        public boolean a;

        @ViewDebug.ExportedProperty
        public int b;

        @ViewDebug.ExportedProperty
        public int c;

        @ViewDebug.ExportedProperty
        public boolean d;

        @ViewDebug.ExportedProperty
        public boolean e;
        boolean f;

        public c(int i, int i2) {
            super(i, i2);
            this.a = false;
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(c cVar) {
            super((ViewGroup.LayoutParams) cVar);
            this.a = cVar.a;
        }
    }

    private class d implements androidx.appcompat.view.menu.e.a {
        d() {
        }

        @Override // androidx.appcompat.view.menu.e.a
        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            e eVar2 = ActionMenuView.this.J0;
            return eVar2 != null && eVar2.onMenuItemClick(menuItem);
        }

        @Override // androidx.appcompat.view.menu.e.a
        public void b(androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.e.a aVar = ActionMenuView.this.E0;
            if (aVar != null) {
                aVar.b(eVar);
            }
        }
    }

    public interface e {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.H0 = (int) (56.0f * f);
        this.I0 = (int) (f * 4.0f);
        this.z0 = context;
        this.A0 = 0;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x004d  */
    static int L(View view, int i, int i2, int i3, int i4) {
        int i5;
        c cVar = (c) view.getLayoutParams();
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3) - i4, View.MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z = false;
        boolean z2 = actionMenuItemView != null && actionMenuItemView.C();
        if (i2 > 0) {
            i5 = 2;
            if (!z2 || i2 >= 2) {
                view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i, Integer.MIN_VALUE), iMakeMeasureSpec);
                int measuredWidth = view.getMeasuredWidth();
                int i6 = measuredWidth / i;
                if (measuredWidth % i != 0) {
                    i6++;
                }
                if (!z2 || i6 >= 2) {
                    i5 = i6;
                }
            } else {
                i5 = 0;
            }
        } else {
            i5 = 0;
        }
        if (!cVar.a && z2) {
            z = true;
        }
        cVar.d = z;
        cVar.b = i5;
        view.measure(View.MeasureSpec.makeMeasureSpec(i * i5, 1073741824), iMakeMeasureSpec);
        return i5;
    }

    /* JADX WARN: Type inference failed for: r3v32 */
    /* JADX WARN: Type inference failed for: r3v33, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r3v47 */
    private void M(int i, int i2) {
        long j;
        int i3;
        ?? r3;
        int i4;
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i);
        int size2 = View.MeasureSpec.getSize(i2);
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingTop, -2);
        int i5 = size - paddingLeft;
        int i6 = this.H0;
        int i7 = i5 / i6;
        int i8 = i5 % i6;
        if (i7 == 0) {
            setMeasuredDimension(i5, 0);
            return;
        }
        int i9 = i6 + (i8 / i7);
        int childCount = getChildCount();
        int iMax = 0;
        int i10 = 0;
        boolean z = false;
        int i11 = 0;
        int iMax2 = 0;
        int i12 = 0;
        long j2 = 0;
        while (i10 < childCount) {
            View childAt = getChildAt(i10);
            int i13 = size2;
            if (childAt.getVisibility() == 8) {
                i4 = i9;
            } else {
                boolean z2 = childAt instanceof ActionMenuItemView;
                i11++;
                if (z2) {
                    int i14 = this.I0;
                    r3 = 0;
                    childAt.setPadding(i14, 0, i14, 0);
                } else {
                    r3 = 0;
                }
                c cVar = (c) childAt.getLayoutParams();
                cVar.f = r3;
                cVar.c = r3;
                cVar.b = r3;
                cVar.d = r3;
                ((LinearLayout.LayoutParams) cVar).leftMargin = r3;
                ((LinearLayout.LayoutParams) cVar).rightMargin = r3;
                cVar.e = z2 && ((ActionMenuItemView) childAt).C();
                int iL = L(childAt, i9, cVar.a ? 1 : i7, childMeasureSpec, paddingTop);
                iMax2 = Math.max(iMax2, iL);
                i4 = i9;
                if (cVar.d) {
                    i12++;
                }
                if (cVar.a) {
                    z = true;
                }
                i7 -= iL;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (iL == 1) {
                    j2 |= (long) (1 << i10);
                }
            }
            i10++;
            size2 = i13;
            i9 = i4;
        }
        int i15 = size2;
        int i16 = i9;
        boolean z3 = z && i11 == 2;
        boolean z4 = false;
        while (true) {
            if (i12 <= 0 || i7 <= 0) {
                j = 1;
                break;
            }
            int i17 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
            long j3 = 0;
            int i18 = 0;
            int i19 = 0;
            j = 1;
            while (i19 < childCount) {
                c cVar2 = (c) getChildAt(i19).getLayoutParams();
                boolean z5 = z3;
                if (cVar2.d) {
                    int i20 = cVar2.b;
                    if (i20 < i17) {
                        j3 = 1 << i19;
                        i17 = i20;
                        i18 = 1;
                    } else if (i20 == i17) {
                        j3 |= 1 << i19;
                        i18++;
                    }
                }
                i19++;
                z3 = z5;
            }
            boolean z6 = z3;
            j2 |= j3;
            if (i18 > i7) {
                break;
            }
            int i21 = i17 + 1;
            int i22 = 0;
            while (i22 < childCount) {
                View childAt2 = getChildAt(i22);
                c cVar3 = (c) childAt2.getLayoutParams();
                long j4 = 1 << i22;
                if ((j3 & j4) == 0) {
                    if (cVar3.b == i21) {
                        j2 |= j4;
                    }
                    i22 = i22;
                } else {
                    if (z6 && cVar3.e && i7 == 1) {
                        int i23 = this.I0;
                        childAt2.setPadding(i23 + i16, 0, i23, 0);
                    }
                    cVar3.b++;
                    cVar3.f = true;
                    i7--;
                }
                i22++;
            }
            z3 = z6;
            z4 = true;
        }
        boolean z7 = !z && i11 == 1;
        if (i7 <= 0 || j2 == 0 || (i7 >= i11 - 1 && !z7 && iMax2 <= 1)) {
            i3 = 0;
        } else {
            float fBitCount = Long.bitCount(j2);
            if (z7) {
                i3 = 0;
            } else {
                if ((j2 & j) != 0) {
                    i3 = 0;
                    if (!((c) getChildAt(0).getLayoutParams()).e) {
                        fBitCount -= 0.5f;
                    }
                } else {
                    i3 = 0;
                }
                int i24 = childCount - 1;
                if ((j2 & ((long) (1 << i24))) != 0 && !((c) getChildAt(i24).getLayoutParams()).e) {
                    fBitCount -= 0.5f;
                }
            }
            int i25 = fBitCount > 0.0f ? (int) ((i7 * i16) / fBitCount) : 0;
            for (int i26 = 0; i26 < childCount; i26++) {
                if ((j2 & ((long) (1 << i26))) != 0) {
                    View childAt3 = getChildAt(i26);
                    c cVar4 = (c) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        cVar4.c = i25;
                        cVar4.f = true;
                        if (i26 == 0 && !cVar4.e) {
                            ((LinearLayout.LayoutParams) cVar4).leftMargin = (-i25) / 2;
                        }
                        z4 = true;
                    } else if (cVar4.a) {
                        cVar4.c = i25;
                        cVar4.f = true;
                        ((LinearLayout.LayoutParams) cVar4).rightMargin = (-i25) / 2;
                        z4 = true;
                    } else {
                        if (i26 != 0) {
                            ((LinearLayout.LayoutParams) cVar4).leftMargin = i25 / 2;
                        }
                        if (i26 != childCount - 1) {
                            ((LinearLayout.LayoutParams) cVar4).rightMargin = i25 / 2;
                        }
                    }
                }
            }
        }
        if (z4) {
            while (i3 < childCount) {
                View childAt4 = getChildAt(i3);
                c cVar5 = (c) childAt4.getLayoutParams();
                if (cVar5.f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((cVar5.b * i16) + cVar5.c, 1073741824), childMeasureSpec);
                }
                i3++;
            }
        }
        setMeasuredDimension(i5, mode != 1073741824 ? iMax : i15);
    }

    public void B() {
        C0593c c0593c = this.C0;
        if (c0593c != null) {
            c0593c.y();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.widget.B
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public c generateDefaultLayoutParams() {
        c cVar = new c(-2, -2);
        ((LinearLayout.LayoutParams) cVar).gravity = 16;
        return cVar;
    }

    @Override // androidx.appcompat.widget.B
    /* JADX INFO: renamed from: D, reason: merged with bridge method [inline-methods] */
    public c generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.widget.B
    /* JADX INFO: renamed from: E, reason: merged with bridge method [inline-methods] */
    public c generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return generateDefaultLayoutParams();
        }
        c cVar = layoutParams instanceof c ? new c((c) layoutParams) : new c(layoutParams);
        if (((LinearLayout.LayoutParams) cVar).gravity <= 0) {
            ((LinearLayout.LayoutParams) cVar).gravity = 16;
        }
        return cVar;
    }

    public c F() {
        c cVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
        cVarGenerateDefaultLayoutParams.a = true;
        return cVarGenerateDefaultLayoutParams;
    }

    protected boolean G(int i) {
        boolean zA = false;
        if (i == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i - 1);
        KeyEvent.Callback childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof a)) {
            zA = ((a) childAt).a();
        }
        return (i <= 0 || !(childAt2 instanceof a)) ? zA : ((a) childAt2).b() | zA;
    }

    public boolean H() {
        C0593c c0593c = this.C0;
        return c0593c != null && c0593c.B();
    }

    public boolean I() {
        C0593c c0593c = this.C0;
        return c0593c != null && c0593c.D();
    }

    public boolean J() {
        C0593c c0593c = this.C0;
        return c0593c != null && c0593c.E();
    }

    public boolean K() {
        return this.B0;
    }

    public androidx.appcompat.view.menu.e N() {
        return this.y0;
    }

    public void O(androidx.appcompat.view.menu.j.a aVar, androidx.appcompat.view.menu.e.a aVar2) {
        this.D0 = aVar;
        this.E0 = aVar2;
    }

    public boolean P() {
        C0593c c0593c = this.C0;
        return c0593c != null && c0593c.K();
    }

    @Override // androidx.appcompat.view.menu.e.b
    public boolean a(androidx.appcompat.view.menu.g gVar) {
        return this.y0.M(gVar, 0);
    }

    @Override // androidx.appcompat.view.menu.k
    public void b(androidx.appcompat.view.menu.e eVar) {
        this.y0 = eVar;
    }

    @Override // androidx.appcompat.widget.B, android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof c;
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public Menu getMenu() {
        if (this.y0 == null) {
            Context context = getContext();
            androidx.appcompat.view.menu.e eVar = new androidx.appcompat.view.menu.e(context);
            this.y0 = eVar;
            eVar.S(new d());
            C0593c c0593c = new C0593c(context);
            this.C0 = c0593c;
            c0593c.J(true);
            C0593c c0593c2 = this.C0;
            androidx.appcompat.view.menu.j.a bVar = this.D0;
            if (bVar == null) {
                bVar = new b();
            }
            c0593c2.h(bVar);
            this.y0.c(this.C0, this.z0);
            this.C0.H(this);
        }
        return this.y0;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        return this.C0.A();
    }

    public int getPopupTheme() {
        return this.A0;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0593c c0593c = this.C0;
        if (c0593c != null) {
            c0593c.d(false);
            if (this.C0.E()) {
                this.C0.B();
                this.C0.K();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        B();
    }

    @Override // androidx.appcompat.widget.B, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int width;
        int paddingLeft;
        if (!this.F0) {
            super.onLayout(z, i, i2, i3, i4);
            return;
        }
        int childCount = getChildCount();
        int i5 = (i4 - i2) / 2;
        int dividerWidth = getDividerWidth();
        int i6 = i3 - i;
        int paddingRight = (i6 - getPaddingRight()) - getPaddingLeft();
        boolean zB = O.b(this);
        int i7 = 0;
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                if (cVar.a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (G(i9)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (zB) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) cVar).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) cVar).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i10 = i5 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i10, width, measuredHeight + i10);
                    paddingRight -= measuredWidth;
                    i7 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) cVar).leftMargin) + ((LinearLayout.LayoutParams) cVar).rightMargin;
                    G(i9);
                    i8++;
                }
            }
        }
        if (childCount == 1 && i7 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i11 = (i6 / 2) - (measuredWidth2 / 2);
            int i12 = i5 - (measuredHeight2 / 2);
            childAt2.layout(i11, i12, measuredWidth2 + i11, measuredHeight2 + i12);
            return;
        }
        int i13 = i8 - (i7 ^ 1);
        int iMax = Math.max(0, i13 > 0 ? paddingRight / i13 : 0);
        if (zB) {
            int width2 = getWidth() - getPaddingRight();
            for (int i14 = 0; i14 < childCount; i14++) {
                View childAt3 = getChildAt(i14);
                c cVar2 = (c) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !cVar2.a) {
                    int i15 = width2 - ((LinearLayout.LayoutParams) cVar2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i16 = i5 - (measuredHeight3 / 2);
                    childAt3.layout(i15 - measuredWidth3, i16, i15, measuredHeight3 + i16);
                    width2 = i15 - ((measuredWidth3 + ((LinearLayout.LayoutParams) cVar2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i17 = 0; i17 < childCount; i17++) {
            View childAt4 = getChildAt(i17);
            c cVar3 = (c) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !cVar3.a) {
                int i18 = paddingLeft2 + ((LinearLayout.LayoutParams) cVar3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i19 = i5 - (measuredHeight4 / 2);
                childAt4.layout(i18, i19, i18 + measuredWidth4, measuredHeight4 + i19);
                paddingLeft2 = i18 + measuredWidth4 + ((LinearLayout.LayoutParams) cVar3).rightMargin + iMax;
            }
        }
    }

    @Override // androidx.appcompat.widget.B, android.view.View
    protected void onMeasure(int i, int i2) {
        androidx.appcompat.view.menu.e eVar;
        boolean z = this.F0;
        boolean z2 = View.MeasureSpec.getMode(i) == 1073741824;
        this.F0 = z2;
        if (z != z2) {
            this.G0 = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (this.F0 && (eVar = this.y0) != null && size != this.G0) {
            this.G0 = size;
            eVar.L(true);
        }
        int childCount = getChildCount();
        if (this.F0 && childCount > 0) {
            M(i, i2);
            return;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            c cVar = (c) getChildAt(i3).getLayoutParams();
            ((LinearLayout.LayoutParams) cVar).rightMargin = 0;
            ((LinearLayout.LayoutParams) cVar).leftMargin = 0;
        }
        super.onMeasure(i, i2);
    }

    public void setExpandedActionViewsExclusive(boolean z) {
        this.C0.G(z);
    }

    public void setOnMenuItemClickListener(e eVar) {
        this.J0 = eVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        this.C0.I(drawable);
    }

    public void setOverflowReserved(boolean z) {
        this.B0 = z;
    }

    public void setPopupTheme(int i) {
        if (this.A0 != i) {
            this.A0 = i;
            if (i == 0) {
                this.z0 = getContext();
            } else {
                this.z0 = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0593c c0593c) {
        this.C0 = c0593c;
        c0593c.H(this);
    }
}
