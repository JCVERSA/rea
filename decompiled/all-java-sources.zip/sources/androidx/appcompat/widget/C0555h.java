package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;

/* JADX INFO: renamed from: androidx.appcompat.widget.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0555h extends CheckedTextView implements ax.p099h0.n {
    private final C0552e h0;
    private final w i0;
    private C0561n j0;
    private final C0556i q;

    public C0555h(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.s);
    }

    private C0561n getEmojiTextViewHelper() {
        if (this.j0 == null) {
            this.j0 = new C0561n(this);
        }
        return this.j0;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        w wVar = this.i0;
        if (wVar != null) {
            wVar.b();
        }
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.b();
        }
        C0556i c0556i = this.q;
        if (c0556i != null) {
            c0556i.a();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p099h0.j.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            return c0552e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            return c0552e.d();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        C0556i c0556i = this.q;
        if (c0556i != null) {
            return c0556i.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        C0556i c0556i = this.q;
        if (c0556i != null) {
            return c0556i.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.i0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.i0.k();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return C0562o.a(super.onCreateInputConnection(editorInfo), editorInfo, this);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.g(i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        C0556i c0556i = this.q;
        if (c0556i != null) {
            c0556i.e();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.i0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.i0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p099h0.j.s(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0552e c0552e = this.h0;
        if (c0552e != null) {
            c0552e.j(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        C0556i c0556i = this.q;
        if (c0556i != null) {
            c0556i.f(colorStateList);
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        C0556i c0556i = this.q;
        if (c0556i != null) {
            c0556i.g(mode);
        }
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.i0.w(colorStateList);
        this.i0.b();
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.i0.x(mode);
        this.i0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        w wVar = this.i0;
        if (wVar != null) {
            wVar.q(context, i);
        }
    }

    public C0555h(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        w wVar = new w(this);
        this.i0 = wVar;
        wVar.m(attributeSet, i);
        wVar.b();
        C0552e c0552e = new C0552e(this);
        this.h0 = c0552e;
        c0552e.e(attributeSet, i);
        C0556i c0556i = new C0556i(this);
        this.q = c0556i;
        c0556i.d(attributeSet, i);
        getEmojiTextViewHelper().c(attributeSet, i);
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(ax.p196o.a.b(getContext(), i));
    }
}
