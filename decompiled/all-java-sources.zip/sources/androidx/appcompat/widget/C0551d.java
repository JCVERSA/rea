package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;

/* JADX INFO: renamed from: androidx.appcompat.widget.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0551d extends AutoCompleteTextView implements ax.p099h0.n {
    private static final int[] j0 = {R.attr.popupBackground};
    private final w h0;
    private final C0560m i0;
    private final C0552e q;

    public C0551d(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.p);
    }

    void a(C0560m c0560m) {
        KeyListener keyListener = getKeyListener();
        if (c0560m.b(keyListener)) {
            boolean zIsFocusable = super.isFocusable();
            boolean zIsClickable = super.isClickable();
            boolean zIsLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener keyListenerA = c0560m.a(keyListener);
            if (keyListenerA == keyListener) {
                return;
            }
            super.setKeyListener(keyListenerA);
            super.setRawInputType(inputType);
            super.setFocusable(zIsFocusable);
            super.setClickable(zIsClickable);
            super.setLongClickable(zIsLongClickable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.b();
        }
        w wVar = this.h0;
        if (wVar != null) {
            wVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p099h0.j.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.h0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.h0.k();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return this.i0.d(C0562o.a(super.onCreateInputConnection(editorInfo), editorInfo, this), editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.g(i);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p099h0.j.s(this, callback));
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(ax.p196o.a.b(getContext(), i));
    }

    public void setEmojiCompatEnabled(boolean z) {
        this.i0.e(z);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.i0.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.j(mode);
        }
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.h0.w(colorStateList);
        this.h0.b();
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.h0.x(mode);
        this.h0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.q(context, i);
        }
    }

    public C0551d(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        L lV = L.v(getContext(), attributeSet, j0, i, 0);
        if (lV.s(0)) {
            setDropDownBackgroundDrawable(lV.g(0));
        }
        lV.x();
        C0552e c0552e = new C0552e(this);
        this.q = c0552e;
        c0552e.e(attributeSet, i);
        w wVar = new w(this);
        this.h0 = wVar;
        wVar.m(attributeSet, i);
        wVar.b();
        C0560m c0560m = new C0560m(this);
        this.i0 = c0560m;
        c0560m.c(attributeSet, i);
        a(c0560m);
    }
}
