package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import ax.p015b0.Y;

/* JADX INFO: renamed from: androidx.appcompat.widget.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0557j {
    private final CompoundButton a;
    private ColorStateList b = null;
    private PorterDuff.Mode c = null;
    private boolean d = false;
    private boolean e = false;
    private boolean f;

    C0557j(CompoundButton compoundButton) {
        this.a = compoundButton;
    }

    void a() {
        Drawable drawableA = ax.p099h0.c.a(this.a);
        if (drawableA != null) {
            if (this.d || this.e) {
                Drawable drawableMutate = ax.T.a.r(drawableA).mutate();
                if (this.d) {
                    ax.T.a.o(drawableMutate, this.b);
                }
                if (this.e) {
                    ax.T.a.p(drawableMutate, this.c);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(this.a.getDrawableState());
                }
                this.a.setButtonDrawable(drawableMutate);
            }
        }
    }

    ColorStateList b() {
        return this.b;
    }

    PorterDuff.Mode c() {
        return this.c;
    }

    void d(AttributeSet attributeSet, int i) {
        int i2;
        int iN;
        int iN2;
        Context context = this.a.getContext();
        int[] iArr = ax.p168m.j.U0;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        CompoundButton compoundButton = this.a;
        Y.o0(compoundButton, compoundButton.getContext(), iArr, attributeSet, lV.r(), i, 0);
        try {
            int i3 = ax.p168m.j.W0;
            if (!lV.s(i3) || (iN2 = lV.n(i3, 0)) == 0) {
                i2 = ax.p168m.j.V0;
                if (lV.s(i2) && (iN = lV.n(i2, 0)) != 0) {
                    CompoundButton compoundButton2 = this.a;
                    compoundButton2.setButtonDrawable(ax.p196o.a.b(compoundButton2.getContext(), iN));
                }
            } else {
                try {
                    CompoundButton compoundButton3 = this.a;
                    compoundButton3.setButtonDrawable(ax.p196o.a.b(compoundButton3.getContext(), iN2));
                } catch (Resources.NotFoundException unused) {
                    i2 = ax.p168m.j.V0;
                    if (lV.s(i2)) {
                        CompoundButton compoundButton4 = this.a;
                        compoundButton4.setButtonDrawable(ax.p196o.a.b(compoundButton4.getContext(), iN));
                    }
                }
            }
            int i4 = ax.p168m.j.X0;
            if (lV.s(i4)) {
                ax.p099h0.c.d(this.a, lV.c(i4));
            }
            int i5 = ax.p168m.j.Y0;
            if (lV.s(i5)) {
                ax.p099h0.c.e(this.a, A.e(lV.k(i5, -1), null));
            }
        } finally {
            lV.x();
        }
    }

    void e() {
        if (this.f) {
            this.f = false;
        } else {
            this.f = true;
            a();
        }
    }

    void f(ColorStateList colorStateList) {
        this.b = colorStateList;
        this.d = true;
        a();
    }

    void g(PorterDuff.Mode mode) {
        this.c = mode;
        this.e = true;
        a();
    }
}
