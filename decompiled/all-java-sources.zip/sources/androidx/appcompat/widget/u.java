package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import ax.p322u.C2351f;
import ax.p322u.C2352g;

/* JADX INFO: loaded from: classes.dex */
public class u extends Spinner {

    @SuppressLint({"ResourceType"})
    private static final int[] r0 = {R.attr.spinnerMode};
    private final Context k0;
    private ax.p322u.s l0;
    private SpinnerAdapter m0;
    private final boolean n0;
    private h o0;
    int p0;
    private final C0595e q;
    final Rect q0;

    class a extends ax.p322u.s {
        final /* synthetic */ f p0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        a(View view, f fVar) {
            super(view);
            this.p0 = fVar;
        }

        @Override // ax.p322u.s
        public ax.p306t.e b() {
            return this.p0;
        }

        @Override // ax.p322u.s
        public boolean c() {
            if (u.this.getInternalPopup().b()) {
                return true;
            }
            u.this.b();
            return true;
        }
    }

    class b implements ViewTreeObserver.OnGlobalLayoutListener {
        b() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!u.this.getInternalPopup().b()) {
                u.this.b();
            }
            ViewTreeObserver viewTreeObserver = u.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    private static final class c {
        static void a(ThemedSpinnerAdapter themedSpinnerAdapter, Resources.Theme theme) {
            if (ax.p019b0.b.a(themedSpinnerAdapter.getDropDownViewTheme(), theme)) {
                return;
            }
            themedSpinnerAdapter.setDropDownViewTheme(theme);
        }
    }

    class d implements h, DialogInterface.OnClickListener {
        private ListAdapter X;
        private CharSequence Y;
        androidx.appcompat.app.a q;

        d() {
        }

        @Override // androidx.appcompat.widget.u.h
        public void a(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.u.h
        public boolean b() {
            androidx.appcompat.app.a aVar = this.q;
            if (aVar != null) {
                return aVar.isShowing();
            }
            return false;
        }

        @Override // androidx.appcompat.widget.u.h
        public int d() {
            return 0;
        }

        @Override // androidx.appcompat.widget.u.h
        public void dismiss() {
            androidx.appcompat.app.a aVar = this.q;
            if (aVar != null) {
                aVar.dismiss();
                this.q = null;
            }
        }

        @Override // androidx.appcompat.widget.u.h
        public void f(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.u.h
        public CharSequence g() {
            return this.Y;
        }

        @Override // androidx.appcompat.widget.u.h
        public Drawable i() {
            return null;
        }

        @Override // androidx.appcompat.widget.u.h
        public void k(CharSequence charSequence) {
            this.Y = charSequence;
        }

        @Override // androidx.appcompat.widget.u.h
        public void l(int i) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.u.h
        public void m(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.u.h
        public void n(int i, int i2) {
            if (this.X == null) {
                return;
            }
            androidx.appcompat.app.a.C0008a c0008a = new androidx.appcompat.app.a.C0008a(u.this.getPopupContext());
            CharSequence charSequence = this.Y;
            if (charSequence != null) {
                c0008a.setTitle(charSequence);
            }
            androidx.appcompat.app.a aVarCreate = c0008a.n(this.X, u.this.getSelectedItemPosition(), this).create();
            this.q = aVarCreate;
            ListView listViewJ = aVarCreate.j();
            listViewJ.setTextDirection(i);
            listViewJ.setTextAlignment(i2);
            this.q.show();
        }

        @Override // androidx.appcompat.widget.u.h
        public int o() {
            return 0;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i) {
            u.this.setSelection(i);
            if (u.this.getOnItemClickListener() != null) {
                u.this.performItemClick(null, i, this.X.getItemId(i));
            }
            dismiss();
        }

        @Override // androidx.appcompat.widget.u.h
        public void p(ListAdapter listAdapter) {
            this.X = listAdapter;
        }
    }

    private static class e implements ListAdapter, SpinnerAdapter {
        private ListAdapter X;
        private SpinnerAdapter q;

        public e(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.q = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.X = (ListAdapter) spinnerAdapter;
            }
            if (theme != null) {
                if (Build.VERSION.SDK_INT >= 23 && C2351f.a(spinnerAdapter)) {
                    c.a(C2352g.a(spinnerAdapter), theme);
                } else if (spinnerAdapter instanceof ax.p322u.x) {
                    ax.p322u.x xVar = (ax.p322u.x) spinnerAdapter;
                    if (xVar.getDropDownViewTheme() == null) {
                        xVar.setDropDownViewTheme(theme);
                    }
                }
            }
        }

        @Override // android.widget.ListAdapter
        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.X;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        @Override // android.widget.Adapter
        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        @Override // android.widget.SpinnerAdapter
        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter == null) {
                return -1L;
            }
            return spinnerAdapter.getItemId(i);
        }

        @Override // android.widget.Adapter
        public int getItemViewType(int i) {
            return 0;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            return getDropDownView(i, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public int getViewTypeCount() {
            return 1;
        }

        @Override // android.widget.Adapter
        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.q;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        @Override // android.widget.Adapter
        public boolean isEmpty() {
            return getCount() == 0;
        }

        @Override // android.widget.ListAdapter
        public boolean isEnabled(int i) {
            ListAdapter listAdapter = this.X;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i);
            }
            return true;
        }

        @Override // android.widget.Adapter
        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        @Override // android.widget.Adapter
        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.q;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    class f extends ax.p322u.t implements h {
        private CharSequence P0;
        ListAdapter Q0;
        private final Rect R0;
        private int S0;

        class a implements AdapterView.OnItemClickListener {
            final /* synthetic */ u q;

            a(u uVar) {
                this.q = uVar;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                u.this.setSelection(i);
                if (u.this.getOnItemClickListener() != null) {
                    f fVar = f.this;
                    u.this.performItemClick(view, i, fVar.Q0.getItemId(i));
                }
                f.this.dismiss();
            }
        }

        class b implements ViewTreeObserver.OnGlobalLayoutListener {
            b() {
            }

            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                f fVar = f.this;
                if (!fVar.V(u.this)) {
                    f.this.dismiss();
                } else {
                    f.this.T();
                    f.super.c();
                }
            }
        }

        class c implements PopupWindow.OnDismissListener {
            final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener q;

            c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.q = onGlobalLayoutListener;
            }

            @Override // android.widget.PopupWindow.OnDismissListener
            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = u.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.q);
                }
            }
        }

        public f(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.R0 = new Rect();
            D(u.this);
            J(true);
            P(0);
            L(new a(u.this));
        }

        void T() {
            int i;
            Drawable drawableI = i();
            if (drawableI != null) {
                drawableI.getPadding(u.this.q0);
                i = O.b(u.this) ? u.this.q0.right : -u.this.q0.left;
            } else {
                Rect rect = u.this.q0;
                rect.right = 0;
                rect.left = 0;
                i = 0;
            }
            int paddingLeft = u.this.getPaddingLeft();
            int paddingRight = u.this.getPaddingRight();
            int width = u.this.getWidth();
            u uVar = u.this;
            int i2 = uVar.p0;
            if (i2 == -2) {
                int iA = uVar.a((SpinnerAdapter) this.Q0, i());
                int i3 = u.this.getContext().getResources().getDisplayMetrics().widthPixels;
                Rect rect2 = u.this.q0;
                int i4 = (i3 - rect2.left) - rect2.right;
                if (iA > i4) {
                    iA = i4;
                }
                F(Math.max(iA, (width - paddingLeft) - paddingRight));
            } else if (i2 == -1) {
                F((width - paddingLeft) - paddingRight);
            } else {
                F(i2);
            }
            f(O.b(u.this) ? i + (((width - paddingRight) - z()) - U()) : i + paddingLeft + U());
        }

        public int U() {
            return this.S0;
        }

        boolean V(View view) {
            return view.isAttachedToWindow() && view.getGlobalVisibleRect(this.R0);
        }

        @Override // androidx.appcompat.widget.u.h
        public CharSequence g() {
            return this.P0;
        }

        @Override // androidx.appcompat.widget.u.h
        public void k(CharSequence charSequence) {
            this.P0 = charSequence;
        }

        @Override // androidx.appcompat.widget.u.h
        public void m(int i) {
            this.S0 = i;
        }

        @Override // androidx.appcompat.widget.u.h
        public void n(int i, int i2) {
            ViewTreeObserver viewTreeObserver;
            boolean zB = b();
            T();
            I(2);
            super.c();
            ListView listViewJ = j();
            listViewJ.setChoiceMode(1);
            listViewJ.setTextDirection(i);
            listViewJ.setTextAlignment(i2);
            Q(u.this.getSelectedItemPosition());
            if (zB || (viewTreeObserver = u.this.getViewTreeObserver()) == null) {
                return;
            }
            b bVar = new b();
            viewTreeObserver.addOnGlobalLayoutListener(bVar);
            K(new c(bVar));
        }

        @Override // ax.p322u.t, androidx.appcompat.widget.u.h
        public void p(ListAdapter listAdapter) {
            super.p(listAdapter);
            this.Q0 = listAdapter;
        }
    }

    static class g extends View.BaseSavedState {
        public static final Parcelable.Creator<g> CREATOR = new a();
        boolean q;

        class a implements Parcelable.Creator<g> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public g[] newArray(int i) {
                return new g[i];
            }
        }

        g(Parcel parcel) {
            super(parcel);
            this.q = parcel.readByte() != 0;
        }

        g(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.q ? (byte) 1 : (byte) 0);
        }
    }

    interface h {
        void a(Drawable drawable);

        boolean b();

        int d();

        void dismiss();

        void f(int i);

        CharSequence g();

        Drawable i();

        void k(CharSequence charSequence);

        void l(int i);

        void m(int i);

        void n(int i, int i2);

        int o();

        void p(ListAdapter listAdapter);
    }

    public u(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.O);
    }

    public u(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, -1);
    }

    public u(Context context, AttributeSet attributeSet, int i, int i2) {
        this(context, attributeSet, i, i2, null);
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0070 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x0073  */
    /* JADX WARN: Code duplicated, block: B:36:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:39:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:42:0x00db  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v7, types: [android.content.res.TypedArray] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [android.content.res.TypedArray] */
    /* JADX WARN: Type inference failed for: r6v0, types: [android.view.View, androidx.appcompat.widget.u] */
    public u(Context context, AttributeSet attributeSet, int i, int i2, Resources.Theme theme) throws Throwable {
        TypedArray typedArrayObtainStyledAttributes;
        CharSequence[] charSequenceArrQ;
        SpinnerAdapter spinnerAdapter;
        super(context, attributeSet, i);
        this.q0 = new Rect();
        H.a(this, getContext());
        L lV = L.v(context, attributeSet, ax.p194m.j.o2, i, 0);
        this.q = new C0595e(this);
        if (theme != null) {
            this.k0 = new ax.p290s.c(context, theme);
        } else {
            int iN = lV.n(ax.p194m.j.t2, 0);
            if (iN != 0) {
                this.k0 = new ax.p290s.c(context, iN);
            } else {
                this.k0 = context;
            }
        }
        ?? r11 = -1;
        ?? r2 = 0;
        try {
            if (i2 == -1) {
                try {
                    typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, r0, i, 0);
                    try {
                        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(0);
                        r11 = typedArrayObtainStyledAttributes;
                        if (zHasValue) {
                            i2 = typedArrayObtainStyledAttributes.getInt(0, 0);
                            r11 = typedArrayObtainStyledAttributes;
                        }
                    } catch (Exception e2) {
                        e = e2;
                        Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
                        r11 = typedArrayObtainStyledAttributes;
                        if (typedArrayObtainStyledAttributes != null) {
                        }
                        if (i2 != 0) {
                            d dVar = new d();
                            this.o0 = dVar;
                            dVar.k(lV.o(ax.p194m.j.r2));
                        } else if (i2 == 1) {
                            f fVar = new f(this.k0, attributeSet, i);
                            L lV2 = L.v(this.k0, attributeSet, ax.p194m.j.o2, i, 0);
                            this.p0 = lV2.m(ax.p194m.j.s2, -2);
                            fVar.a(lV2.g(ax.p194m.j.q2));
                            fVar.k(lV.o(ax.p194m.j.r2));
                            lV2.x();
                            this.o0 = fVar;
                            this.l0 = new a(this, fVar);
                        }
                        charSequenceArrQ = lV.q(ax.p194m.j.p2);
                        if (charSequenceArrQ != null) {
                            ArrayAdapter arrayAdapter = new ArrayAdapter(context, R.layout.simple_spinner_item, charSequenceArrQ);
                            arrayAdapter.setDropDownViewResource(ax.p194m.g.r);
                            setAdapter(arrayAdapter);
                        }
                        lV.x();
                        this.n0 = true;
                        spinnerAdapter = this.m0;
                        if (spinnerAdapter != null) {
                            setAdapter(spinnerAdapter);
                            this.m0 = null;
                        }
                        this.q.e(attributeSet, i);
                    }
                } catch (Exception e3) {
                    e = e3;
                    typedArrayObtainStyledAttributes = null;
                } catch (Throwable th) {
                    th = th;
                    if (r2 != 0) {
                        r2.recycle();
                    }
                    throw th;
                }
                r11.recycle();
            }
            if (i2 != 0) {
                d dVar2 = new d();
                this.o0 = dVar2;
                dVar2.k(lV.o(ax.p194m.j.r2));
            } else if (i2 == 1) {
                f fVar2 = new f(this.k0, attributeSet, i);
                L lV3 = L.v(this.k0, attributeSet, ax.p194m.j.o2, i, 0);
                this.p0 = lV3.m(ax.p194m.j.s2, -2);
                fVar2.a(lV3.g(ax.p194m.j.q2));
                fVar2.k(lV.o(ax.p194m.j.r2));
                lV3.x();
                this.o0 = fVar2;
                this.l0 = new a(this, fVar2);
            }
            charSequenceArrQ = lV.q(ax.p194m.j.p2);
            if (charSequenceArrQ != null) {
                ArrayAdapter arrayAdapter2 = new ArrayAdapter(context, R.layout.simple_spinner_item, charSequenceArrQ);
                arrayAdapter2.setDropDownViewResource(ax.p194m.g.r);
                setAdapter(arrayAdapter2);
            }
            lV.x();
            this.n0 = true;
            spinnerAdapter = this.m0;
            if (spinnerAdapter != null) {
                setAdapter(spinnerAdapter);
                this.m0 = null;
            }
            this.q.e(attributeSet, i);
        } catch (Throwable th2) {
            th = th2;
            r2 = r11;
        }
    }

    int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int iMax = Math.max(0, getSelectedItemPosition());
        int iMin = Math.min(spinnerAdapter.getCount(), iMax + 15);
        View view = null;
        int iMax2 = 0;
        for (int iMax3 = Math.max(0, iMax - (15 - (iMin - iMax))); iMax3 < iMin; iMax3++) {
            int itemViewType = spinnerAdapter.getItemViewType(iMax3);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(iMax3, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
            iMax2 = Math.max(iMax2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return iMax2;
        }
        drawable.getPadding(this.q0);
        Rect rect = this.q0;
        return iMax2 + rect.left + rect.right;
    }

    void b() {
        this.o0.n(getTextDirection(), getTextAlignment());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.b();
        }
    }

    @Override // android.widget.Spinner
    public int getDropDownHorizontalOffset() {
        h hVar = this.o0;
        return hVar != null ? hVar.d() : super.getDropDownHorizontalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownVerticalOffset() {
        h hVar = this.o0;
        return hVar != null ? hVar.o() : super.getDropDownVerticalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownWidth() {
        return this.o0 != null ? this.p0 : super.getDropDownWidth();
    }

    final h getInternalPopup() {
        return this.o0;
    }

    @Override // android.widget.Spinner
    public Drawable getPopupBackground() {
        h hVar = this.o0;
        return hVar != null ? hVar.i() : super.getPopupBackground();
    }

    @Override // android.widget.Spinner
    public Context getPopupContext() {
        return this.k0;
    }

    @Override // android.widget.Spinner
    public CharSequence getPrompt() {
        h hVar = this.o0;
        return hVar != null ? hVar.g() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            return c0595e.d();
        }
        return null;
    }

    @Override // android.widget.Spinner, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h hVar = this.o0;
        if (hVar == null || !hVar.b()) {
            return;
        }
        this.o0.dismiss();
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.o0 == null || View.MeasureSpec.getMode(i) != Integer.MIN_VALUE) {
            return;
        }
        setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i)), getMeasuredHeight());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.getSuperState());
        if (!gVar.q || (viewTreeObserver = getViewTreeObserver()) == null) {
            return;
        }
        viewTreeObserver.addOnGlobalLayoutListener(new b());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        h hVar = this.o0;
        gVar.q = hVar != null && hVar.b();
        return gVar;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        ax.p322u.s sVar = this.l0;
        if (sVar == null || !sVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean performClick() {
        h hVar = this.o0;
        if (hVar == null) {
            return super.performClick();
        }
        if (hVar.b()) {
            return true;
        }
        b();
        return true;
    }

    @Override // android.widget.AdapterView
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.n0) {
            this.m0 = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.o0 != null) {
            Context context = this.k0;
            if (context == null) {
                context = getContext();
            }
            this.o0.p(new e(spinnerAdapter, context.getTheme()));
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.g(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownHorizontalOffset(int i) {
        h hVar = this.o0;
        if (hVar == null) {
            super.setDropDownHorizontalOffset(i);
        } else {
            hVar.m(i);
            this.o0.f(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownVerticalOffset(int i) {
        h hVar = this.o0;
        if (hVar != null) {
            hVar.l(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownWidth(int i) {
        if (this.o0 != null) {
            this.p0 = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundDrawable(Drawable drawable) {
        h hVar = this.o0;
        if (hVar != null) {
            hVar.a(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(ax.p226o.a.b(getPopupContext(), i));
    }

    @Override // android.widget.Spinner
    public void setPrompt(CharSequence charSequence) {
        h hVar = this.o0;
        if (hVar != null) {
            hVar.k(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0595e c0595e = this.q;
        if (c0595e != null) {
            c0595e.j(mode);
        }
    }
}
