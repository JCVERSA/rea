package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import ax.p015b0.A0;
import ax.p015b0.Y;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements ax.p280u.k, ax.p015b0.E, ax.p015b0.F {
    static final int[] M0 = {ax.p168m.a.b, R.attr.windowContentOverlay};
    private static final A0 N0 = new A0.b().d(ax.S.b.b(0, 1, 0, 1)).a();
    private static final Rect O0 = new Rect();
    private A0 A0;
    private A0 B0;
    private A0 C0;
    private A0 D0;
    private d E0;
    private OverScroller F0;
    ViewPropertyAnimator G0;
    final AnimatorListenerAdapter H0;
    private final Runnable I0;
    private final Runnable J0;
    private final ax.p015b0.G K0;
    private final f L0;
    private int h0;
    private ContentFrameLayout i0;
    ActionBarContainer j0;
    private ax.p280u.l k0;
    private Drawable l0;
    private boolean m0;
    private boolean n0;
    private boolean o0;
    boolean p0;
    private int q;
    private int q0;
    private int r0;
    private final Rect s0;
    private final Rect t0;
    private final Rect u0;
    private final Rect v0;
    private final Rect w0;
    private final Rect x0;
    private final Rect y0;
    private final Rect z0;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G0 = null;
            actionBarOverlayLayout.p0 = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G0 = null;
            actionBarOverlayLayout.p0 = false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G0 = actionBarOverlayLayout.j0.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.H0);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.G0 = actionBarOverlayLayout.j0.animate().translationY(-ActionBarOverlayLayout.this.j0.getHeight()).setListener(ActionBarOverlayLayout.this.H0);
        }
    }

    public interface d {
        void a();

        void b();

        void c(boolean z);

        void d();

        void e();

        void onWindowVisibilityChanged(int i);
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(int i, int i2) {
            super(i, i2);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    private static final class f extends View {
        f(Context context) {
            super(context);
            setWillNotDraw(true);
        }

        @Override // android.view.View
        public int getWindowSystemUiVisibility() {
            return 0;
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h0 = 0;
        this.s0 = new Rect();
        this.t0 = new Rect();
        this.u0 = new Rect();
        this.v0 = new Rect();
        this.w0 = new Rect();
        this.x0 = new Rect();
        this.y0 = new Rect();
        this.z0 = new Rect();
        A0 a0 = A0.b;
        this.A0 = a0;
        this.B0 = a0;
        this.C0 = a0;
        this.D0 = a0;
        this.H0 = new a();
        this.I0 = new b();
        this.J0 = new c();
        w(context);
        this.K0 = new ax.p015b0.G(this);
        f fVar = new f(context);
        this.L0 = fVar;
        addView(fVar);
    }

    private void B() {
        v();
        this.I0.run();
    }

    private boolean C(float f2) {
        this.F0.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, SubsamplingScaleImageView.TILE_SIZE_AUTO);
        return this.F0.getFinalY() > this.j0.getHeight();
    }

    private void a() {
        v();
        this.J0.run();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    private boolean q(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        e eVar = (e) view.getLayoutParams();
        if (z) {
            int i = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
            int i2 = rect.left;
            if (i != i2) {
                ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i2;
                z5 = true;
            } else {
                z5 = false;
            }
        } else {
            z5 = false;
        }
        if (z2) {
            int i3 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
            int i4 = rect.top;
            if (i3 != i4) {
                ((ViewGroup.MarginLayoutParams) eVar).topMargin = i4;
                z5 = true;
            }
        }
        if (z4) {
            int i5 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
            int i6 = rect.right;
            if (i5 != i6) {
                ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i6;
                z5 = true;
            }
        }
        if (z3) {
            int i7 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            int i8 = rect.bottom;
            if (i7 != i8) {
                ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i8;
                return true;
            }
        }
        return z5;
    }

    private boolean r() {
        Y.h(this.L0, N0, this.v0);
        return !this.v0.equals(O0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private ax.p280u.l u(View view) {
        if (view instanceof ax.p280u.l) {
            return (ax.p280u.l) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void w(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(M0);
        this.q = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.l0 = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.F0 = new OverScroller(context);
    }

    private void y() {
        v();
        postDelayed(this.J0, 600L);
    }

    private void z() {
        v();
        postDelayed(this.I0, 600L);
    }

    void A() {
        if (this.i0 == null) {
            this.i0 = (ContentFrameLayout) findViewById(ax.p168m.f.b);
            this.j0 = (ActionBarContainer) findViewById(ax.p168m.f.c);
            this.k0 = u(findViewById(ax.p168m.f.a));
        }
    }

    @Override // ax.p280u.k
    public void b(Menu menu, androidx.appcompat.view.menu.j.a aVar) {
        A();
        this.k0.b(menu, aVar);
    }

    @Override // ax.p280u.k
    public boolean c() {
        A();
        return this.k0.c();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // ax.p015b0.F
    public void d(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        f(view, i, i2, i3, i4, i5);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.l0 != null) {
            int bottom = this.j0.getVisibility() == 0 ? (int) (this.j0.getBottom() + this.j0.getTranslationY() + 0.5f) : 0;
            this.l0.setBounds(0, bottom, getWidth(), this.l0.getIntrinsicHeight() + bottom);
            this.l0.draw(canvas);
        }
    }

    @Override // ax.p280u.k
    public void e() {
        A();
        this.k0.e();
    }

    @Override // ax.p015b0.E
    public void f(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    @Override // android.view.View
    protected boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // ax.p280u.k
    public boolean g() {
        A();
        return this.k0.g();
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.j0;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.K0.a();
    }

    public CharSequence getTitle() {
        A();
        return this.k0.getTitle();
    }

    @Override // ax.p280u.k
    public boolean h() {
        A();
        return this.k0.h();
    }

    @Override // ax.p280u.k
    public boolean i() {
        A();
        return this.k0.i();
    }

    @Override // ax.p280u.k
    public boolean j() {
        A();
        return this.k0.j();
    }

    @Override // ax.p280u.k
    public void k(int i) {
        A();
        if (i == 2) {
            this.k0.y();
        } else if (i == 5) {
            this.k0.z();
        } else {
            if (i != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // ax.p280u.k
    public void l() {
        A();
        this.k0.k();
    }

    @Override // ax.p015b0.E
    public boolean m(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    @Override // ax.p015b0.E
    public void n(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // ax.p015b0.E
    public void o(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        A();
        A0 a0W = A0.w(windowInsets, this);
        boolean zQ = q(this.j0, new Rect(a0W.j(), a0W.l(), a0W.k(), a0W.i()), true, true, false, true);
        Y.h(this, a0W, this.s0);
        Rect rect = this.s0;
        A0 a0M = a0W.m(rect.left, rect.top, rect.right, rect.bottom);
        this.A0 = a0M;
        boolean z = true;
        if (!this.B0.equals(a0M)) {
            this.B0 = this.A0;
            zQ = true;
        }
        if (this.t0.equals(this.s0)) {
            z = zQ;
        } else {
            this.t0.set(this.s0);
        }
        if (z) {
            requestLayout();
        }
        return a0W.a().c().b().u();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        w(getContext());
        Y.n0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        v();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        int measuredHeight;
        A();
        measureChildWithMargins(this.j0, i, 0, i2, 0);
        e eVar = (e) this.j0.getLayoutParams();
        int iMax = Math.max(0, this.j0.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int iMax2 = Math.max(0, this.j0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.j0.getMeasuredState());
        boolean z = (Y.N(this) & 256) != 0;
        if (z) {
            measuredHeight = this.q;
            if (this.n0 && this.j0.getTabContainer() != null) {
                measuredHeight += this.q;
            }
        } else {
            measuredHeight = this.j0.getVisibility() != 8 ? this.j0.getMeasuredHeight() : 0;
        }
        this.u0.set(this.s0);
        this.C0 = this.A0;
        if (this.m0 || z || !r()) {
            this.C0 = new A0.b(this.C0).d(ax.S.b.b(this.C0.j(), this.C0.l() + measuredHeight, this.C0.k(), this.C0.i())).a();
        } else {
            Rect rect = this.u0;
            rect.top += measuredHeight;
            rect.bottom = rect.bottom;
            this.C0 = this.C0.m(0, measuredHeight, 0, 0);
        }
        q(this.i0, this.u0, true, true, true, true);
        if (!this.D0.equals(this.C0)) {
            A0 a0 = this.C0;
            this.D0 = a0;
            Y.i(this.i0, a0);
        }
        measureChildWithMargins(this.i0, i, 0, i2, 0);
        e eVar2 = (e) this.i0.getLayoutParams();
        int iMax3 = Math.max(iMax, this.i0.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int iMax4 = Math.max(iMax2, this.i0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.i0.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(iMax4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i2, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        if (!this.o0 || !z) {
            return false;
        }
        if (C(f3)) {
            a();
        } else {
            B();
        }
        this.p0 = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.q0 + i2;
        this.q0 = i5;
        setActionBarHideOffset(i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.K0.b(view, view2, i);
        this.q0 = getActionBarHideOffset();
        v();
        d dVar = this.E0;
        if (dVar != null) {
            dVar.e();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.j0.getVisibility() != 0) {
            return false;
        }
        return this.o0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.o0 && !this.p0) {
            if (this.q0 <= this.j0.getHeight()) {
                z();
            } else {
                y();
            }
        }
        d dVar = this.E0;
        if (dVar != null) {
            dVar.b();
        }
    }

    @Override // android.view.View
    @Deprecated
    public void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        A();
        int i2 = this.r0 ^ i;
        this.r0 = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & 256) != 0;
        d dVar = this.E0;
        if (dVar != null) {
            dVar.c(!z2);
            if (z || !z2) {
                this.E0.a();
            } else {
                this.E0.d();
            }
        }
        if ((i2 & 256) == 0 || this.E0 == null) {
            return;
        }
        Y.n0(this);
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.h0 = i;
        d dVar = this.E0;
        if (dVar != null) {
            dVar.onWindowVisibilityChanged(i);
        }
    }

    @Override // ax.p015b0.E
    public void p(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    public void setActionBarHideOffset(int i) {
        v();
        this.j0.setTranslationY(-Math.max(0, Math.min(i, this.j0.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.E0 = dVar;
        if (getWindowToken() != null) {
            this.E0.onWindowVisibilityChanged(this.h0);
            int i = this.r0;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                Y.n0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.n0 = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.o0) {
            this.o0 = z;
            if (z) {
                return;
            }
            v();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i) {
        A();
        this.k0.setIcon(i);
    }

    public void setLogo(int i) {
        A();
        this.k0.p(i);
    }

    public void setOverlayMode(boolean z) {
        this.m0 = z;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    @Override // ax.p280u.k
    public void setWindowCallback(Window.Callback callback) {
        A();
        this.k0.setWindowCallback(callback);
    }

    @Override // ax.p280u.k
    public void setWindowTitle(CharSequence charSequence) {
        A();
        this.k0.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: t, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    void v() {
        removeCallbacks(this.I0);
        removeCallbacks(this.J0);
        ViewPropertyAnimator viewPropertyAnimator = this.G0;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean x() {
        return this.m0;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        A();
        this.k0.setIcon(drawable);
    }
}
