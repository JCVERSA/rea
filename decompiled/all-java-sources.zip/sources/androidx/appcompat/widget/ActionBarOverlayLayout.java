package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import ax.p035c0.C1839d0;
import ax.p035c0.F0;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements ax.p322u.k, ax.p035c0.F, ax.p035c0.G {
    static final int[] P0 = {ax.p194m.a.b, R.attr.windowContentOverlay};
    private static final F0 Q0 = new F0.b().d(ax.T.b.b(0, 1, 0, 1)).a();
    private static final Rect R0 = new Rect();
    private final Rect A0;
    private final Rect B0;
    private final Rect C0;
    private F0 D0;
    private F0 E0;
    private F0 F0;
    private F0 G0;
    private d H0;
    private OverScroller I0;
    ViewPropertyAnimator J0;
    final AnimatorListenerAdapter K0;
    private final Runnable L0;
    private final Runnable M0;
    private final ax.p035c0.H N0;
    private final f O0;
    private int k0;
    private ContentFrameLayout l0;
    ActionBarContainer m0;
    private ax.p322u.l n0;
    private Drawable o0;
    private boolean p0;
    private int q;
    private boolean q0;
    private boolean r0;
    boolean s0;
    private int t0;
    private int u0;
    private final Rect v0;
    private final Rect w0;
    private final Rect x0;
    private final Rect y0;
    private final Rect z0;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.J0 = null;
            actionBarOverlayLayout.s0 = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.J0 = null;
            actionBarOverlayLayout.s0 = false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.J0 = actionBarOverlayLayout.m0.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.K0);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.J0 = actionBarOverlayLayout.m0.animate().translationY(-ActionBarOverlayLayout.this.m0.getHeight()).setListener(ActionBarOverlayLayout.this.K0);
        }
    }

    public interface d {
        void a();

        void b();

        void c(boolean z);

        void d();

        void e();

        void onWindowVisibilityChanged(int i);
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(int i, int i2) {
            super(i, i2);
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    private static final class f extends View {
        f(Context context) {
            super(context);
            setWillNotDraw(true);
        }

        @Override // android.view.View
        public int getWindowSystemUiVisibility() {
            return 0;
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.k0 = 0;
        this.v0 = new Rect();
        this.w0 = new Rect();
        this.x0 = new Rect();
        this.y0 = new Rect();
        this.z0 = new Rect();
        this.A0 = new Rect();
        this.B0 = new Rect();
        this.C0 = new Rect();
        F0 f0 = F0.b;
        this.D0 = f0;
        this.E0 = f0;
        this.F0 = f0;
        this.G0 = f0;
        this.K0 = new a();
        this.L0 = new b();
        this.M0 = new c();
        w(context);
        this.N0 = new ax.p035c0.H(this);
        f fVar = new f(context);
        this.O0 = fVar;
        addView(fVar);
    }

    private void B() {
        v();
        this.L0.run();
    }

    private boolean C(float f2) {
        this.I0.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, SubsamplingScaleImageView.TILE_SIZE_AUTO);
        return this.I0.getFinalY() > this.m0.getHeight();
    }

    private void a() {
        v();
        this.M0.run();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    private boolean q(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        e eVar = (e) view.getLayoutParams();
        if (z) {
            int i = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
            int i2 = rect.left;
            if (i != i2) {
                ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i2;
                z5 = true;
            } else {
                z5 = false;
            }
        } else {
            z5 = false;
        }
        if (z2) {
            int i3 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
            int i4 = rect.top;
            if (i3 != i4) {
                ((ViewGroup.MarginLayoutParams) eVar).topMargin = i4;
                z5 = true;
            }
        }
        if (z4) {
            int i5 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
            int i6 = rect.right;
            if (i5 != i6) {
                ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i6;
                z5 = true;
            }
        }
        if (z3) {
            int i7 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            int i8 = rect.bottom;
            if (i7 != i8) {
                ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i8;
                return true;
            }
        }
        return z5;
    }

    private boolean r() {
        C1839d0.h(this.O0, Q0, this.y0);
        return !this.y0.equals(R0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private ax.p322u.l u(View view) {
        if (view instanceof ax.p322u.l) {
            return (ax.p322u.l) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void w(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(P0);
        this.q = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.o0 = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.I0 = new OverScroller(context);
    }

    private void y() {
        v();
        postDelayed(this.M0, 600L);
    }

    private void z() {
        v();
        postDelayed(this.L0, 600L);
    }

    void A() {
        if (this.l0 == null) {
            this.l0 = (ContentFrameLayout) findViewById(ax.p194m.f.b);
            this.m0 = (ActionBarContainer) findViewById(ax.p194m.f.c);
            this.n0 = u(findViewById(ax.p194m.f.a));
        }
    }

    @Override // ax.p322u.k
    public void b(Menu menu, androidx.appcompat.view.menu.j.a aVar) {
        A();
        this.n0.b(menu, aVar);
    }

    @Override // ax.p322u.k
    public boolean c() {
        A();
        return this.n0.c();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // ax.p035c0.G
    public void d(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        f(view, i, i2, i3, i4, i5);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.o0 != null) {
            int bottom = this.m0.getVisibility() == 0 ? (int) (this.m0.getBottom() + this.m0.getTranslationY() + 0.5f) : 0;
            this.o0.setBounds(0, bottom, getWidth(), this.o0.getIntrinsicHeight() + bottom);
            this.o0.draw(canvas);
        }
    }

    @Override // ax.p322u.k
    public void e() {
        A();
        this.n0.e();
    }

    @Override // ax.p035c0.F
    public void f(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    @Override // android.view.View
    protected boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // ax.p322u.k
    public boolean g() {
        A();
        return this.n0.g();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.m0;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.N0.a();
    }

    public CharSequence getTitle() {
        A();
        return this.n0.getTitle();
    }

    @Override // ax.p322u.k
    public boolean h() {
        A();
        return this.n0.h();
    }

    @Override // ax.p322u.k
    public boolean i() {
        A();
        return this.n0.i();
    }

    @Override // ax.p322u.k
    public boolean j() {
        A();
        return this.n0.j();
    }

    @Override // ax.p322u.k
    public void k(int i) {
        A();
        if (i == 2) {
            this.n0.A();
        } else if (i == 5) {
            this.n0.B();
        } else {
            if (i != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // ax.p322u.k
    public void l() {
        A();
        this.n0.k();
    }

    @Override // ax.p035c0.F
    public boolean m(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    @Override // ax.p035c0.F
    public void n(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // ax.p035c0.F
    public void o(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        A();
        F0 f0W = F0.w(windowInsets, this);
        boolean zQ = q(this.m0, new Rect(f0W.j(), f0W.l(), f0W.k(), f0W.i()), true, true, false, true);
        C1839d0.h(this, f0W, this.v0);
        Rect rect = this.v0;
        F0 f0M = f0W.m(rect.left, rect.top, rect.right, rect.bottom);
        this.D0 = f0M;
        boolean z = true;
        if (!this.E0.equals(f0M)) {
            this.E0 = this.D0;
            zQ = true;
        }
        if (this.w0.equals(this.v0)) {
            z = zQ;
        } else {
            this.w0.set(this.v0);
        }
        if (z) {
            requestLayout();
        }
        return f0W.a().c().b().u();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        w(getContext());
        C1839d0.i0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        v();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        int measuredHeight;
        A();
        measureChildWithMargins(this.m0, i, 0, i2, 0);
        e eVar = (e) this.m0.getLayoutParams();
        int iMax = Math.max(0, this.m0.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int iMax2 = Math.max(0, this.m0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.m0.getMeasuredState());
        boolean z = (C1839d0.L(this) & 256) != 0;
        if (z) {
            measuredHeight = this.q;
            if (this.q0 && this.m0.getTabContainer() != null) {
                measuredHeight += this.q;
            }
        } else {
            measuredHeight = this.m0.getVisibility() != 8 ? this.m0.getMeasuredHeight() : 0;
        }
        this.x0.set(this.v0);
        this.F0 = this.D0;
        if (this.p0 || z || !r()) {
            this.F0 = new F0.b(this.F0).d(ax.T.b.b(this.F0.j(), this.F0.l() + measuredHeight, this.F0.k(), this.F0.i())).a();
        } else {
            Rect rect = this.x0;
            rect.top += measuredHeight;
            rect.bottom = rect.bottom;
            this.F0 = this.F0.m(0, measuredHeight, 0, 0);
        }
        q(this.l0, this.x0, true, true, true, true);
        if (!this.G0.equals(this.F0)) {
            F0 f0 = this.F0;
            this.G0 = f0;
            C1839d0.i(this.l0, f0);
        }
        measureChildWithMargins(this.l0, i, 0, i2, 0);
        e eVar2 = (e) this.l0.getLayoutParams();
        int iMax3 = Math.max(iMax, this.l0.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int iMax4 = Math.max(iMax2, this.l0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.l0.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(iMax4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i2, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        if (!this.r0 || !z) {
            return false;
        }
        if (C(f3)) {
            a();
        } else {
            B();
        }
        this.s0 = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.t0 + i2;
        this.t0 = i5;
        setActionBarHideOffset(i5);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.N0.b(view, view2, i);
        this.t0 = getActionBarHideOffset();
        v();
        d dVar = this.H0;
        if (dVar != null) {
            dVar.e();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.m0.getVisibility() != 0) {
            return false;
        }
        return this.r0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.r0 && !this.s0) {
            if (this.t0 <= this.m0.getHeight()) {
                z();
            } else {
                y();
            }
        }
        d dVar = this.H0;
        if (dVar != null) {
            dVar.b();
        }
    }

    @Override // android.view.View
    @Deprecated
    public void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        A();
        int i2 = this.u0 ^ i;
        this.u0 = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & 256) != 0;
        d dVar = this.H0;
        if (dVar != null) {
            dVar.c(!z2);
            if (z || !z2) {
                this.H0.a();
            } else {
                this.H0.d();
            }
        }
        if ((i2 & 256) == 0 || this.H0 == null) {
            return;
        }
        C1839d0.i0(this);
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.k0 = i;
        d dVar = this.H0;
        if (dVar != null) {
            dVar.onWindowVisibilityChanged(i);
        }
    }

    @Override // ax.p035c0.F
    public void p(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    public void setActionBarHideOffset(int i) {
        v();
        this.m0.setTranslationY(-Math.max(0, Math.min(i, this.m0.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.H0 = dVar;
        if (getWindowToken() != null) {
            this.H0.onWindowVisibilityChanged(this.k0);
            int i = this.u0;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                C1839d0.i0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.q0 = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.r0) {
            this.r0 = z;
            if (z) {
                return;
            }
            v();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i) {
        A();
        this.n0.setIcon(i);
    }

    public void setIcon(Drawable drawable) {
        A();
        this.n0.setIcon(drawable);
    }

    public void setLogo(int i) {
        A();
        this.n0.q(i);
    }

    public void setOverlayMode(boolean z) {
        this.p0 = z;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    @Override // ax.p322u.k
    public void setWindowCallback(Window.Callback callback) {
        A();
        this.n0.setWindowCallback(callback);
    }

    @Override // ax.p322u.k
    public void setWindowTitle(CharSequence charSequence) {
        A();
        this.n0.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: t, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    void v() {
        removeCallbacks(this.L0);
        removeCallbacks(this.M0);
        ViewPropertyAnimator viewPropertyAnimator = this.J0;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean x() {
        return this.p0;
    }
}
