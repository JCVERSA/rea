package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import ax.p015b0.Y;

/* JADX INFO: loaded from: classes.dex */
public class q {
    private final ImageView a;
    private J b;
    private J c;
    private J d;
    private int e = 0;

    public q(ImageView imageView) {
        this.a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.d == null) {
            this.d = new J();
        }
        J j = this.d;
        j.a();
        ColorStateList colorStateListA = ax.p099h0.e.a(this.a);
        if (colorStateListA != null) {
            j.d = true;
            j.a = colorStateListA;
        }
        PorterDuff.Mode modeB = ax.p099h0.e.b(this.a);
        if (modeB != null) {
            j.c = true;
            j.b = modeB;
        }
        if (!j.d && !j.c) {
            return false;
        }
        C0558k.i(drawable, j, this.a.getDrawableState());
        return true;
    }

    private boolean l() {
        int i = Build.VERSION.SDK_INT;
        if (i > 21) {
            return this.b != null;
        }
        return i == 21;
    }

    void b() {
        if (this.a.getDrawable() != null) {
            this.a.getDrawable().setLevel(this.e);
        }
    }

    void c() {
        Drawable drawable = this.a.getDrawable();
        if (drawable != null) {
            A.b(drawable);
        }
        if (drawable != null) {
            if (l() && a(drawable)) {
                return;
            }
            J j = this.c;
            if (j != null) {
                C0558k.i(drawable, j, this.a.getDrawableState());
                return;
            }
            J j2 = this.b;
            if (j2 != null) {
                C0558k.i(drawable, j2, this.a.getDrawableState());
            }
        }
    }

    ColorStateList d() {
        J j = this.c;
        if (j != null) {
            return j.a;
        }
        return null;
    }

    PorterDuff.Mode e() {
        J j = this.c;
        if (j != null) {
            return j.b;
        }
        return null;
    }

    boolean f() {
        return !(this.a.getBackground() instanceof RippleDrawable);
    }

    public void g(AttributeSet attributeSet, int i) {
        int iN;
        Context context = this.a.getContext();
        int[] iArr = ax.p168m.j.P;
        L lV = L.v(context, attributeSet, iArr, i, 0);
        ImageView imageView = this.a;
        Y.o0(imageView, imageView.getContext(), iArr, attributeSet, lV.r(), i, 0);
        try {
            Drawable drawable = this.a.getDrawable();
            if (drawable == null && (iN = lV.n(ax.p168m.j.Q, -1)) != -1 && (drawable = ax.p196o.a.b(this.a.getContext(), iN)) != null) {
                this.a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                A.b(drawable);
            }
            int i2 = ax.p168m.j.R;
            if (lV.s(i2)) {
                ax.p099h0.e.c(this.a, lV.c(i2));
            }
            int i3 = ax.p168m.j.S;
            if (lV.s(i3)) {
                ax.p099h0.e.d(this.a, A.e(lV.k(i3, -1), null));
            }
        } finally {
            lV.x();
        }
    }

    void h(Drawable drawable) {
        this.e = drawable.getLevel();
    }

    public void i(int i) {
        if (i != 0) {
            Drawable drawableB = ax.p196o.a.b(this.a.getContext(), i);
            if (drawableB != null) {
                A.b(drawableB);
            }
            this.a.setImageDrawable(drawableB);
        } else {
            this.a.setImageDrawable(null);
        }
        c();
    }

    void j(ColorStateList colorStateList) {
        if (this.c == null) {
            this.c = new J();
        }
        J j = this.c;
        j.a = colorStateList;
        j.d = true;
        c();
    }

    void k(PorterDuff.Mode mode) {
        if (this.c == null) {
            this.c = new J();
        }
        J j = this.c;
        j.b = mode;
        j.c = true;
        c();
    }
}
