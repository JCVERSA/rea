package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;

/* JADX INFO: renamed from: androidx.appcompat.widget.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0598h extends CheckedTextView implements ax.p115h0.n {
    private final C0595e k0;
    private final w l0;
    private C0604n m0;
    private final C0599i q;

    public C0598h(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.s);
    }

    public C0598h(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        w wVar = new w(this);
        this.l0 = wVar;
        wVar.m(attributeSet, i);
        wVar.b();
        C0595e c0595e = new C0595e(this);
        this.k0 = c0595e;
        c0595e.e(attributeSet, i);
        C0599i c0599i = new C0599i(this);
        this.q = c0599i;
        c0599i.d(attributeSet, i);
        getEmojiTextViewHelper().c(attributeSet, i);
    }

    private C0604n getEmojiTextViewHelper() {
        if (this.m0 == null) {
            this.m0 = new C0604n(this);
        }
        return this.m0;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        w wVar = this.l0;
        if (wVar != null) {
            wVar.b();
        }
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.b();
        }
        C0599i c0599i = this.q;
        if (c0599i != null) {
            c0599i.a();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p115h0.j.o(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            return c0595e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            return c0595e.d();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        C0599i c0599i = this.q;
        if (c0599i != null) {
            return c0599i.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        C0599i c0599i = this.q;
        if (c0599i != null) {
            return c0599i.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.l0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.l0.k();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return C0605o.a(super.onCreateInputConnection(editorInfo), editorInfo, this);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z) {
        super.setAllCaps(z);
        getEmojiTextViewHelper().d(z);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.g(i);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(ax.p226o.a.b(getContext(), i));
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        C0599i c0599i = this.q;
        if (c0599i != null) {
            c0599i.e();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.l0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.l0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p115h0.j.p(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z) {
        getEmojiTextViewHelper().e(z);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0595e c0595e = this.k0;
        if (c0595e != null) {
            c0595e.j(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        C0599i c0599i = this.q;
        if (c0599i != null) {
            c0599i.f(colorStateList);
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        C0599i c0599i = this.q;
        if (c0599i != null) {
            c0599i.g(mode);
        }
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.l0.w(colorStateList);
        this.l0.b();
    }

    @Override // ax.p115h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.l0.x(mode);
        this.l0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        w wVar = this.l0;
        if (wVar != null) {
            wVar.q(context, i);
        }
    }
}
