package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import ax.p015b0.C5213d;
import ax.p015b0.Y;

/* JADX INFO: renamed from: androidx.appcompat.widget.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0559l extends EditText implements ax.p015b0.J, ax.p099h0.n {
    private final w h0;
    private final v i0;
    private final ax.p099h0.l j0;
    private final C0560m k0;
    private a l0;
    private final C0552e q;

    /* JADX INFO: renamed from: androidx.appcompat.widget.l$a */
    class a {
        a() {
        }

        public TextClassifier a() {
            return C0559l.super.getTextClassifier();
        }

        public void b(TextClassifier textClassifier) {
            C0559l.super.setTextClassifier(textClassifier);
        }
    }

    public C0559l(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.C);
    }

    private a getSuperCaller() {
        if (this.l0 == null) {
            this.l0 = new a();
        }
        return this.l0;
    }

    @Override // ax.p015b0.J
    public C5213d a(C5213d c5213d) {
        return this.j0.a(this, c5213d);
    }

    void d(C0560m c0560m) {
        KeyListener keyListener = getKeyListener();
        if (c0560m.b(keyListener)) {
            boolean zIsFocusable = super.isFocusable();
            boolean zIsClickable = super.isClickable();
            boolean zIsLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener keyListenerA = c0560m.a(keyListener);
            if (keyListenerA == keyListener) {
                return;
            }
            super.setKeyListener(keyListenerA);
            super.setRawInputType(inputType);
            super.setFocusable(zIsFocusable);
            super.setClickable(zIsClickable);
            super.setLongClickable(zIsLongClickable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.b();
        }
        w wVar = this.h0;
        if (wVar != null) {
            wVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return ax.p099h0.j.r(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            return c0552e.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.h0.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.h0.k();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        v vVar;
        return (Build.VERSION.SDK_INT >= 28 || (vVar = this.i0) == null) ? getSuperCaller().a() : vVar.a();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        String[] strArrF;
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.h0.r(this, inputConnectionOnCreateInputConnection, editorInfo);
        InputConnection inputConnectionA = C0562o.a(inputConnectionOnCreateInputConnection, editorInfo, this);
        if (inputConnectionA != null && Build.VERSION.SDK_INT <= 30 && (strArrF = Y.F(this)) != null) {
            ax.p085g0.c.d(editorInfo, strArrF);
            inputConnectionA = ax.p085g0.e.c(this, inputConnectionA, editorInfo);
        }
        return this.k0.d(inputConnectionA, editorInfo);
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i = Build.VERSION.SDK_INT;
        if (i < 30 || i >= 33) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onDragEvent(DragEvent dragEvent) {
        if (t.a(this, dragEvent)) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public boolean onTextContextMenuItem(int i) {
        if (t.b(this, i)) {
            return true;
        }
        return super.onTextContextMenuItem(i);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.g(i);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(ax.p099h0.j.s(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z) {
        this.k0.e(z);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.k0.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0552e c0552e = this.q;
        if (c0552e != null) {
            c0552e.j(mode);
        }
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.h0.w(colorStateList);
        this.h0.b();
    }

    @Override // ax.p099h0.n
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.h0.x(mode);
        this.h0.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        w wVar = this.h0;
        if (wVar != null) {
            wVar.q(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        v vVar;
        if (Build.VERSION.SDK_INT >= 28 || (vVar = this.i0) == null) {
            getSuperCaller().b(textClassifier);
        } else {
            vVar.b(textClassifier);
        }
    }

    public C0559l(Context context, AttributeSet attributeSet, int i) {
        super(I.b(context), attributeSet, i);
        H.a(this, getContext());
        C0552e c0552e = new C0552e(this);
        this.q = c0552e;
        c0552e.e(attributeSet, i);
        w wVar = new w(this);
        this.h0 = wVar;
        wVar.m(attributeSet, i);
        wVar.b();
        this.i0 = new v(this);
        this.j0 = new ax.p099h0.l();
        C0560m c0560m = new C0560m(this);
        this.k0 = c0560m;
        c0560m.c(attributeSet, i);
        d(c0560m);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }
}
