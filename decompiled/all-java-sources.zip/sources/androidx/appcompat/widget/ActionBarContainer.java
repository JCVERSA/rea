package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {
    private View h0;
    private View i0;
    private View j0;
    Drawable k0;
    Drawable l0;
    Drawable m0;
    boolean n0;
    boolean o0;
    private int p0;
    private boolean q;

    private static class a {
        public static void a(ActionBarContainer actionBarContainer) {
            actionBarContainer.invalidateOutline();
        }
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C0549b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p168m.j.a);
        this.k0 = typedArrayObtainStyledAttributes.getDrawable(ax.p168m.j.b);
        this.l0 = typedArrayObtainStyledAttributes.getDrawable(ax.p168m.j.d);
        this.p0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p168m.j.j, -1);
        boolean z = true;
        if (getId() == ax.p168m.f.z) {
            this.n0 = true;
            this.m0 = typedArrayObtainStyledAttributes.getDrawable(ax.p168m.j.c);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.n0 ? this.k0 != null || this.l0 != null : this.m0 != null) {
            z = false;
        }
        setWillNotDraw(z);
    }

    private int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    private boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.k0;
        if (drawable != null && drawable.isStateful()) {
            this.k0.setState(getDrawableState());
        }
        Drawable drawable2 = this.l0;
        if (drawable2 != null && drawable2.isStateful()) {
            this.l0.setState(getDrawableState());
        }
        Drawable drawable3 = this.m0;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.m0.setState(getDrawableState());
    }

    public View getTabContainer() {
        return this.h0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.k0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.m0;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.i0 = findViewById(ax.p168m.f.a);
        this.j0 = findViewById(ax.p168m.f.f);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.q || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Drawable drawable;
        super.onLayout(z, i, i2, i3, i4);
        View view = this.h0;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = (view == null || view.getVisibility() == 8) ? false : true;
        if (view != null && view.getVisibility() != 8) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            int measuredHeight2 = measuredHeight - view.getMeasuredHeight();
            int i5 = layoutParams.bottomMargin;
            view.layout(i, measuredHeight2 - i5, i3, measuredHeight - i5);
        }
        if (this.n0) {
            Drawable drawable2 = this.m0;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.k0 != null) {
                if (this.i0.getVisibility() == 0) {
                    this.k0.setBounds(this.i0.getLeft(), this.i0.getTop(), this.i0.getRight(), this.i0.getBottom());
                } else {
                    View view2 = this.j0;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.k0.setBounds(0, 0, 0, 0);
                    } else {
                        this.k0.setBounds(this.j0.getLeft(), this.j0.getTop(), this.j0.getRight(), this.j0.getBottom());
                    }
                }
                z3 = true;
            }
            this.o0 = z4;
            if (!z4 || (drawable = this.l0) == null) {
                z2 = z3;
            } else {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        }
        if (z2) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        int iA;
        int i3;
        if (this.i0 == null && View.MeasureSpec.getMode(i2) == Integer.MIN_VALUE && (i3 = this.p0) >= 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(Math.min(i3, View.MeasureSpec.getSize(i2)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i2);
        if (this.i0 == null) {
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        View view = this.h0;
        if (view == null || view.getVisibility() == 8 || mode == 1073741824) {
            return;
        }
        if (b(this.i0)) {
            iA = !b(this.j0) ? a(this.j0) : 0;
        } else {
            iA = a(this.i0);
        }
        setMeasuredDimension(getMeasuredWidth(), Math.min(iA + a(this.h0), mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i2) : SubsamplingScaleImageView.TILE_SIZE_AUTO));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.k0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.k0);
        }
        this.k0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.i0;
            if (view != null) {
                this.k0.setBounds(view.getLeft(), this.i0.getTop(), this.i0.getRight(), this.i0.getBottom());
            }
        }
        boolean z = false;
        if (!this.n0 ? !(this.k0 != null || this.l0 != null) : this.m0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.m0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.m0);
        }
        this.m0 = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.n0 && (drawable2 = this.m0) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.n0 ? !(this.k0 != null || this.l0 != null) : this.m0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.l0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.l0);
        }
        this.l0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.o0 && (drawable2 = this.l0) != null) {
                drawable2.setBounds(this.h0.getLeft(), this.h0.getTop(), this.h0.getRight(), this.h0.getBottom());
            }
        }
        boolean z = false;
        if (!this.n0 ? !(this.k0 != null || this.l0 != null) : this.m0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setTabContainer(F f) {
        View view = this.h0;
        if (view != null) {
            removeView(view);
        }
        this.h0 = f;
        if (f != null) {
            addView(f);
            ViewGroup.LayoutParams layoutParams = f.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            f.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.q = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.k0;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.l0;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.m0;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.k0 && !this.n0) || (drawable == this.l0 && this.o0) || ((drawable == this.m0 && this.n0) || super.verifyDrawable(drawable));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }
}
