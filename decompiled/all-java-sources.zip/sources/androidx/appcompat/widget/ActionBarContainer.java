package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {
    private View k0;
    private View l0;
    private View m0;
    Drawable n0;
    Drawable o0;
    Drawable p0;
    private boolean q;
    boolean q0;
    boolean r0;
    private int s0;

    private static class a {
        public static void a(ActionBarContainer actionBarContainer) {
            actionBarContainer.invalidateOutline();
        }
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C0592b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p194m.j.a);
        this.n0 = typedArrayObtainStyledAttributes.getDrawable(ax.p194m.j.b);
        this.o0 = typedArrayObtainStyledAttributes.getDrawable(ax.p194m.j.d);
        this.s0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p194m.j.j, -1);
        boolean z = true;
        if (getId() == ax.p194m.f.z) {
            this.q0 = true;
            this.p0 = typedArrayObtainStyledAttributes.getDrawable(ax.p194m.j.c);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.q0 ? this.n0 != null || this.o0 != null : this.p0 != null) {
            z = false;
        }
        setWillNotDraw(z);
    }

    private int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    private boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.n0;
        if (drawable != null && drawable.isStateful()) {
            this.n0.setState(getDrawableState());
        }
        Drawable drawable2 = this.o0;
        if (drawable2 != null && drawable2.isStateful()) {
            this.o0.setState(getDrawableState());
        }
        Drawable drawable3 = this.p0;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.p0.setState(getDrawableState());
    }

    public View getTabContainer() {
        return this.k0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.n0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.p0;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.l0 = findViewById(ax.p194m.f.a);
        this.m0 = findViewById(ax.p194m.f.f);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.q || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Drawable drawable;
        super.onLayout(z, i, i2, i3, i4);
        View view = this.k0;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = (view == null || view.getVisibility() == 8) ? false : true;
        if (view != null && view.getVisibility() != 8) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            int measuredHeight2 = measuredHeight - view.getMeasuredHeight();
            int i5 = layoutParams.bottomMargin;
            view.layout(i, measuredHeight2 - i5, i3, measuredHeight - i5);
        }
        if (this.q0) {
            Drawable drawable2 = this.p0;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.n0 != null) {
                if (this.l0.getVisibility() == 0) {
                    this.n0.setBounds(this.l0.getLeft(), this.l0.getTop(), this.l0.getRight(), this.l0.getBottom());
                } else {
                    View view2 = this.m0;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.n0.setBounds(0, 0, 0, 0);
                    } else {
                        this.n0.setBounds(this.m0.getLeft(), this.m0.getTop(), this.m0.getRight(), this.m0.getBottom());
                    }
                }
                z3 = true;
            }
            this.r0 = z4;
            if (!z4 || (drawable = this.o0) == null) {
                z2 = z3;
            } else {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        }
        if (z2) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        int iA;
        int i3;
        if (this.l0 == null && View.MeasureSpec.getMode(i2) == Integer.MIN_VALUE && (i3 = this.s0) >= 0) {
            i2 = View.MeasureSpec.makeMeasureSpec(Math.min(i3, View.MeasureSpec.getSize(i2)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i2);
        if (this.l0 == null) {
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        View view = this.k0;
        if (view == null || view.getVisibility() == 8 || mode == 1073741824) {
            return;
        }
        if (b(this.l0)) {
            iA = !b(this.m0) ? a(this.m0) : 0;
        } else {
            iA = a(this.l0);
        }
        setMeasuredDimension(getMeasuredWidth(), Math.min(iA + a(this.k0), mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i2) : SubsamplingScaleImageView.TILE_SIZE_AUTO));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.n0;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.n0);
        }
        this.n0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.l0;
            if (view != null) {
                this.n0.setBounds(view.getLeft(), this.l0.getTop(), this.l0.getRight(), this.l0.getBottom());
            }
        }
        boolean z = false;
        if (!this.q0 ? !(this.n0 != null || this.o0 != null) : this.p0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.p0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.p0);
        }
        this.p0 = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.q0 && (drawable2 = this.p0) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.q0 ? !(this.n0 != null || this.o0 != null) : this.p0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.o0;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.o0);
        }
        this.o0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.r0 && (drawable2 = this.o0) != null) {
                drawable2.setBounds(this.k0.getLeft(), this.k0.getTop(), this.k0.getRight(), this.k0.getBottom());
            }
        }
        boolean z = false;
        if (!this.q0 ? !(this.n0 != null || this.o0 != null) : this.p0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        a.a(this);
    }

    public void setTabContainer(F f) {
        View view = this.k0;
        if (view != null) {
            removeView(view);
        }
        this.k0 = f;
        if (f != null) {
            addView(f);
            ViewGroup.LayoutParams layoutParams = f.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            f.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.q = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.n0;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.o0;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.p0;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        if (drawable == this.n0 && !this.q0) {
            return true;
        }
        if (drawable == this.o0 && this.r0) {
            return true;
        }
        return (drawable == this.p0 && this.q0) || super.verifyDrawable(drawable);
    }
}
