package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import ax.p015b0.C5224i0;
import ax.p015b0.InterfaceC5226j0;
import ax.p015b0.Y;

/* JADX INFO: renamed from: androidx.appcompat.widget.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
abstract class AbstractC0548a extends ViewGroup {
    protected final Context h0;
    protected ActionMenuView i0;
    protected C0550c j0;
    protected int k0;
    protected C5224i0 l0;
    private boolean m0;
    private boolean n0;
    protected final C0009a q;

    /* JADX INFO: renamed from: androidx.appcompat.widget.a$a, reason: collision with other inner class name */
    protected class C0009a implements InterfaceC5226j0 {
        private boolean a = false;
        int b;

        protected C0009a() {
        }

        @Override // ax.p015b0.InterfaceC5226j0
        public void a(View view) {
            this.a = true;
        }

        @Override // ax.p015b0.InterfaceC5226j0
        public void b(View view) {
            if (this.a) {
                return;
            }
            AbstractC0548a abstractC0548a = AbstractC0548a.this;
            abstractC0548a.l0 = null;
            AbstractC0548a.super.setVisibility(this.b);
        }

        @Override // ax.p015b0.InterfaceC5226j0
        public void c(View view) {
            AbstractC0548a.super.setVisibility(0);
            this.a = false;
        }

        public C0009a d(C5224i0 c5224i0, int i) {
            AbstractC0548a.this.l0 = c5224i0;
            this.b = i;
            return this;
        }
    }

    AbstractC0548a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    protected static int d(int i, int i2, boolean z) {
        return z ? i - i2 : i + i2;
    }

    protected int c(View view, int i, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    protected int e(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i2 + ((i3 - measuredHeight) / 2);
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public C5224i0 f(int i, long j) {
        C5224i0 c5224i0 = this.l0;
        if (c5224i0 != null) {
            c5224i0.c();
        }
        if (i != 0) {
            C5224i0 c5224i0B = Y.e(this).b(0.0f);
            c5224i0B.f(j);
            c5224i0B.h(this.q.d(c5224i0B, i));
            return c5224i0B;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        C5224i0 c5224i0B2 = Y.e(this).b(1.0f);
        c5224i0B2.f(j);
        c5224i0B2.h(this.q.d(c5224i0B2, i));
        return c5224i0B2;
    }

    public int getAnimatedVisibility() {
        return this.l0 != null ? this.q.b : getVisibility();
    }

    public int getContentHeight() {
        return this.k0;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, ax.p168m.j.a, ax.p168m.a.c, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(ax.p168m.j.j, 0));
        typedArrayObtainStyledAttributes.recycle();
        C0550c c0550c = this.j0;
        if (c0550c != null) {
            c0550c.F(configuration);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.n0 = false;
        }
        if (!this.n0) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.n0 = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.n0 = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.m0 = false;
        }
        if (!this.m0) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.m0 = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.m0 = false;
        }
        return true;
    }

    public void setContentHeight(int i) {
        this.k0 = i;
        requestLayout();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        if (i != getVisibility()) {
            C5224i0 c5224i0 = this.l0;
            if (c5224i0 != null) {
                c5224i0.c();
            }
            super.setVisibility(i);
        }
    }

    AbstractC0548a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q = new C0009a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(ax.p168m.a.a, typedValue, true) || typedValue.resourceId == 0) {
            this.h0 = context;
        } else {
            this.h0 = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }
}
