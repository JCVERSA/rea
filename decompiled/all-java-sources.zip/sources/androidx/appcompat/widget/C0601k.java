package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;

/* JADX INFO: renamed from: androidx.appcompat.widget.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0601k {
    private static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
    private static C0601k c;
    private C a;

    /* JADX INFO: renamed from: androidx.appcompat.widget.k$a */
    class a implements C.f {
        private final int[] a = {ax.p194m.e.R, ax.p194m.e.P, ax.p194m.e.a};
        private final int[] b = {ax.p194m.e.o, ax.p194m.e.B, ax.p194m.e.t, ax.p194m.e.p, ax.p194m.e.q, ax.p194m.e.s, ax.p194m.e.r};
        private final int[] c = {ax.p194m.e.O, ax.p194m.e.Q, ax.p194m.e.k, ax.p194m.e.K, ax.p194m.e.L, ax.p194m.e.M, ax.p194m.e.N};
        private final int[] d = {ax.p194m.e.w, ax.p194m.e.i, ax.p194m.e.v};
        private final int[] e = {ax.p194m.e.J, ax.p194m.e.S};
        private final int[] f = {ax.p194m.e.c, ax.p194m.e.g, ax.p194m.e.d, ax.p194m.e.h};

        a() {
        }

        private boolean f(int[] iArr, int i) {
            for (int i2 : iArr) {
                if (i2 == i) {
                    return true;
                }
            }
            return false;
        }

        private ColorStateList g(Context context) {
            return h(context, 0);
        }

        private ColorStateList h(Context context, int i) {
            int iC = H.c(context, ax.p194m.a.w);
            return new ColorStateList(new int[][]{H.b, H.e, H.c, H.i}, new int[]{H.b(context, ax.p194m.a.u), ax.T.a.g(iC, i), ax.T.a.g(iC, i), i});
        }

        private ColorStateList i(Context context) {
            return h(context, H.c(context, ax.p194m.a.t));
        }

        private ColorStateList j(Context context) {
            return h(context, H.c(context, ax.p194m.a.u));
        }

        private ColorStateList k(Context context) {
            int[][] iArr = new int[3][];
            int[] iArr2 = new int[3];
            int i = ax.p194m.a.A;
            ColorStateList colorStateListE = H.e(context, i);
            if (colorStateListE == null || !colorStateListE.isStateful()) {
                iArr[0] = H.b;
                iArr2[0] = H.b(context, i);
                iArr[1] = H.f;
                iArr2[1] = H.c(context, ax.p194m.a.v);
                iArr[2] = H.i;
                iArr2[2] = H.c(context, i);
            } else {
                int[] iArr3 = H.b;
                iArr[0] = iArr3;
                iArr2[0] = colorStateListE.getColorForState(iArr3, 0);
                iArr[1] = H.f;
                iArr2[1] = H.c(context, ax.p194m.a.v);
                iArr[2] = H.i;
                iArr2[2] = colorStateListE.getDefaultColor();
            }
            return new ColorStateList(iArr, iArr2);
        }

        private LayerDrawable l(C c, Context context, int i) {
            BitmapDrawable bitmapDrawable;
            BitmapDrawable bitmapDrawable2;
            BitmapDrawable bitmapDrawable3;
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(i);
            Drawable drawableJ = c.j(context, ax.p194m.e.F);
            Drawable drawableJ2 = c.j(context, ax.p194m.e.G);
            if ((drawableJ instanceof BitmapDrawable) && drawableJ.getIntrinsicWidth() == dimensionPixelSize && drawableJ.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable = (BitmapDrawable) drawableJ;
                bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
            } else {
                Bitmap bitmapCreateBitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmapCreateBitmap);
                drawableJ.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                drawableJ.draw(canvas);
                bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
                bitmapDrawable2 = new BitmapDrawable(bitmapCreateBitmap);
            }
            bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
            if ((drawableJ2 instanceof BitmapDrawable) && drawableJ2.getIntrinsicWidth() == dimensionPixelSize && drawableJ2.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable3 = (BitmapDrawable) drawableJ2;
            } else {
                Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas2 = new Canvas(bitmapCreateBitmap2);
                drawableJ2.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                drawableJ2.draw(canvas2);
                bitmapDrawable3 = new BitmapDrawable(bitmapCreateBitmap2);
            }
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable, bitmapDrawable3, bitmapDrawable2});
            layerDrawable.setId(0, R.id.background);
            layerDrawable.setId(1, R.id.secondaryProgress);
            layerDrawable.setId(2, R.id.progress);
            return layerDrawable;
        }

        private void m(Drawable drawable, int i, PorterDuff.Mode mode) {
            Drawable drawableMutate = drawable.mutate();
            if (mode == null) {
                mode = C0601k.b;
            }
            drawableMutate.setColorFilter(C0601k.e(i, mode));
        }

        /* JADX WARN: Code duplicated, block: B:22:0x0052  */
        /* JADX WARN: Code duplicated, block: B:24:0x0063  */
        /* JADX WARN: Code duplicated, block: B:26:0x0067 A[RETURN] */
        @Override // androidx.appcompat.widget.C.f
        public boolean a(Context context, int i, Drawable drawable) {
            PorterDuff.Mode mode;
            int i2;
            int iRound;
            boolean z;
            Drawable drawableMutate;
            PorterDuff.Mode mode2 = C0601k.b;
            if (!f(this.a, i)) {
                if (f(this.c, i)) {
                    i2 = ax.p194m.a.v;
                } else {
                    if (f(this.d, i)) {
                        mode2 = PorterDuff.Mode.MULTIPLY;
                    } else if (i == ax.p194m.e.u) {
                        mode = mode2;
                        z = true;
                        iRound = Math.round(40.8f);
                        i2 = R.attr.colorForeground;
                    } else if (i != ax.p194m.e.l) {
                        mode = mode2;
                        i2 = 0;
                        iRound = -1;
                        z = false;
                    }
                    mode = mode2;
                    i2 = R.attr.colorBackground;
                    iRound = -1;
                    z = true;
                }
                if (z) {
                    return false;
                }
                drawableMutate = drawable.mutate();
                drawableMutate.setColorFilter(C0601k.e(H.c(context, i2), mode));
                if (iRound != -1) {
                    drawableMutate.setAlpha(iRound);
                }
                return true;
            }
            i2 = ax.p194m.a.x;
            mode = mode2;
            iRound = -1;
            z = true;
            if (z) {
                return false;
            }
            drawableMutate = drawable.mutate();
            drawableMutate.setColorFilter(C0601k.e(H.c(context, i2), mode));
            if (iRound != -1) {
                drawableMutate.setAlpha(iRound);
            }
            return true;
        }

        @Override // androidx.appcompat.widget.C.f
        public PorterDuff.Mode b(int i) {
            if (i == ax.p194m.e.H) {
                return PorterDuff.Mode.MULTIPLY;
            }
            return null;
        }

        @Override // androidx.appcompat.widget.C.f
        public Drawable c(C c, Context context, int i) {
            if (i == ax.p194m.e.j) {
                return new LayerDrawable(new Drawable[]{c.j(context, ax.p194m.e.i), c.j(context, ax.p194m.e.k)});
            }
            if (i == ax.p194m.e.y) {
                return l(c, context, ax.p194m.d.g);
            }
            if (i == ax.p194m.e.x) {
                return l(c, context, ax.p194m.d.h);
            }
            if (i == ax.p194m.e.z) {
                return l(c, context, ax.p194m.d.i);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.C.f
        public ColorStateList d(Context context, int i) {
            if (i == ax.p194m.e.m) {
                return ax.p226o.a.a(context, ax.p194m.c.e);
            }
            if (i == ax.p194m.e.I) {
                return ax.p226o.a.a(context, ax.p194m.c.h);
            }
            if (i == ax.p194m.e.H) {
                return k(context);
            }
            if (i == ax.p194m.e.f) {
                return j(context);
            }
            if (i == ax.p194m.e.b) {
                return g(context);
            }
            if (i == ax.p194m.e.e) {
                return i(context);
            }
            if (i == ax.p194m.e.D || i == ax.p194m.e.E) {
                return ax.p226o.a.a(context, ax.p194m.c.g);
            }
            if (f(this.b, i)) {
                return H.e(context, ax.p194m.a.x);
            }
            if (f(this.e, i)) {
                return ax.p226o.a.a(context, ax.p194m.c.d);
            }
            if (f(this.f, i)) {
                return ax.p226o.a.a(context, ax.p194m.c.c);
            }
            if (i == ax.p194m.e.A) {
                return ax.p226o.a.a(context, ax.p194m.c.f);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.C.f
        public boolean e(Context context, int i, Drawable drawable) {
            if (i == ax.p194m.e.C) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable drawableFindDrawableByLayerId = layerDrawable.findDrawableByLayerId(R.id.background);
                int i2 = ax.p194m.a.x;
                m(drawableFindDrawableByLayerId, H.c(context, i2), C0601k.b);
                m(layerDrawable.findDrawableByLayerId(R.id.secondaryProgress), H.c(context, i2), C0601k.b);
                m(layerDrawable.findDrawableByLayerId(R.id.progress), H.c(context, ax.p194m.a.v), C0601k.b);
                return true;
            }
            if (i != ax.p194m.e.y && i != ax.p194m.e.x && i != ax.p194m.e.z) {
                return false;
            }
            LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
            m(layerDrawable2.findDrawableByLayerId(R.id.background), H.b(context, ax.p194m.a.x), C0601k.b);
            Drawable drawableFindDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(R.id.secondaryProgress);
            int i3 = ax.p194m.a.v;
            m(drawableFindDrawableByLayerId2, H.c(context, i3), C0601k.b);
            m(layerDrawable2.findDrawableByLayerId(R.id.progress), H.c(context, i3), C0601k.b);
            return true;
        }
    }

    public static synchronized C0601k b() {
        try {
            if (c == null) {
                h();
            }
        } catch (Throwable th) {
            throw th;
        }
        return c;
    }

    public static synchronized PorterDuffColorFilter e(int i, PorterDuff.Mode mode) {
        return C.l(i, mode);
    }

    public static synchronized void h() {
        if (c == null) {
            C0601k c0601k = new C0601k();
            c = c0601k;
            c0601k.a = C.h();
            c.a.u(new a());
        }
    }

    static void i(Drawable drawable, J j, int[] iArr) {
        C.w(drawable, j, iArr);
    }

    public synchronized Drawable c(Context context, int i) {
        return this.a.j(context, i);
    }

    synchronized Drawable d(Context context, int i, boolean z) {
        return this.a.k(context, i, z);
    }

    synchronized ColorStateList f(Context context, int i) {
        return this.a.m(context, i);
    }

    public synchronized void g(Context context) {
        this.a.s(context);
    }
}
