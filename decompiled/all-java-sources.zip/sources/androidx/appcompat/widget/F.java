package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import ax.p182n.AbstractC5569a;

/* JADX INFO: loaded from: classes.dex */
public class F extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
    private static final Interpolator p0 = new DecelerateInterpolator();
    private c h0;
    B i0;
    private Spinner j0;
    private boolean k0;
    int l0;
    int m0;
    private int n0;
    private int o0;
    Runnable q;

    class a implements Runnable {
        final /* synthetic */ View q;

        a(View view) {
            this.q = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            F.this.smoothScrollTo(this.q.getLeft() - ((F.this.getWidth() - this.q.getWidth()) / 2), 0);
            F.this.q = null;
        }
    }

    private class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return F.this.i0.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return ((d) F.this.i0.getChildAt(i)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                return F.this.c((AbstractC5569a.c) getItem(i), true);
            }
            ((d) view).a((AbstractC5569a.c) getItem(i));
            return view;
        }
    }

    private class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = F.this.i0.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = F.this.i0.getChildAt(i);
                childAt.setSelected(childAt == view);
            }
        }
    }

    private class d extends LinearLayout {
        private AbstractC5569a.c h0;
        private TextView i0;
        private ImageView j0;
        private View k0;
        private final int[] q;

        /* JADX WARN: Illegal instructions before constructor call */
        public d(Context context, AbstractC5569a.c cVar, boolean z) {
            int i = ax.p168m.a.d;
            super(context, null, i);
            int[] iArr = {R.attr.background};
            this.q = iArr;
            this.h0 = cVar;
            L lV = L.v(context, null, iArr, i, 0);
            if (lV.s(0)) {
                setBackgroundDrawable(lV.g(0));
            }
            lV.x();
            if (z) {
                setGravity(8388627);
            }
            c();
        }

        public void a(AbstractC5569a.c cVar) {
            this.h0 = cVar;
            c();
        }

        public AbstractC5569a.c b() {
            return this.h0;
        }

        public void c() {
            AbstractC5569a.c cVar = this.h0;
            View viewB = cVar.b();
            if (viewB != null) {
                ViewParent parent = viewB.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(viewB);
                    }
                    addView(viewB);
                }
                this.k0 = viewB;
                TextView textView = this.i0;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.j0;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.j0.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.k0;
            if (view != null) {
                removeView(view);
                this.k0 = null;
            }
            Drawable drawableC = cVar.c();
            CharSequence charSequenceD = cVar.d();
            if (drawableC != null) {
                if (this.j0 == null) {
                    AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    appCompatImageView.setLayoutParams(layoutParams);
                    addView(appCompatImageView, 0);
                    this.j0 = appCompatImageView;
                }
                this.j0.setImageDrawable(drawableC);
                this.j0.setVisibility(0);
            } else {
                ImageView imageView2 = this.j0;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.j0.setImageDrawable(null);
                }
            }
            boolean z = !TextUtils.isEmpty(charSequenceD);
            if (z) {
                if (this.i0 == null) {
                    x xVar = new x(getContext(), null, ax.p168m.a.e);
                    xVar.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    xVar.setLayoutParams(layoutParams2);
                    addView(xVar);
                    this.i0 = xVar;
                }
                this.i0.setText(charSequenceD);
                this.i0.setVisibility(0);
            } else {
                TextView textView2 = this.i0;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.i0.setText((CharSequence) null);
                }
            }
            ImageView imageView3 = this.j0;
            if (imageView3 != null) {
                imageView3.setContentDescription(cVar.a());
            }
            ax.p280u.B.a(this, z ? null : cVar.a());
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (F.this.l0 > 0) {
                int measuredWidth = getMeasuredWidth();
                int i3 = F.this.l0;
                if (measuredWidth > i3) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), i2);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                sendAccessibilityEvent(4);
            }
        }
    }

    private Spinner b() {
        u uVar = new u(getContext(), null, ax.p168m.a.h);
        uVar.setLayoutParams(new B.a(-2, -1));
        uVar.setOnItemSelectedListener(this);
        return uVar;
    }

    private boolean d() {
        Spinner spinner = this.j0;
        return spinner != null && spinner.getParent() == this;
    }

    private void e() {
        if (d()) {
            return;
        }
        if (this.j0 == null) {
            this.j0 = b();
        }
        removeView(this.i0);
        addView(this.j0, new ViewGroup.LayoutParams(-2, -1));
        if (this.j0.getAdapter() == null) {
            this.j0.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.q = null;
        }
        this.j0.setSelection(this.o0);
    }

    private boolean f() {
        if (!d()) {
            return false;
        }
        removeView(this.j0);
        addView(this.i0, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.j0.getSelectedItemPosition());
        return false;
    }

    public void a(int i) {
        View childAt = this.i0.getChildAt(i);
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.q = aVar;
        post(aVar);
    }

    d c(AbstractC5569a.c cVar, boolean z) {
        d dVar = new d(getContext(), cVar, z);
        if (z) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.n0));
        } else {
            dVar.setFocusable(true);
            if (this.h0 == null) {
                this.h0 = new c();
            }
            dVar.setOnClickListener(this.h0);
        }
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.q;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        ax.p252s.a aVarB = ax.p252s.a.b(getContext());
        setContentHeight(aVarB.f());
        this.m0 = aVarB.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        boolean z = mode == 1073741824;
        setFillViewport(z);
        int childCount = this.i0.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            this.l0 = -1;
        } else {
            if (childCount > 2) {
                this.l0 = (int) (View.MeasureSpec.getSize(i) * 0.4f);
            } else {
                this.l0 = View.MeasureSpec.getSize(i) / 2;
            }
            this.l0 = Math.min(this.l0, this.m0);
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.n0, 1073741824);
        if (z || !this.k0) {
            f();
        } else {
            this.i0.measure(0, iMakeMeasureSpec);
            if (this.i0.getMeasuredWidth() > View.MeasureSpec.getSize(i)) {
                e();
            } else {
                f();
            }
        }
        int measuredWidth = getMeasuredWidth();
        super.onMeasure(i, iMakeMeasureSpec);
        int measuredWidth2 = getMeasuredWidth();
        if (!z || measuredWidth == measuredWidth2) {
            return;
        }
        setTabSelected(this.o0);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z) {
        this.k0 = z;
    }

    public void setContentHeight(int i) {
        this.n0 = i;
        requestLayout();
    }

    public void setTabSelected(int i) {
        this.o0 = i;
        int childCount = this.i0.getChildCount();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = this.i0.getChildAt(i2);
            boolean z = i2 == i;
            childAt.setSelected(z);
            if (z) {
                a(i);
            }
            i2++;
        }
        Spinner spinner = this.j0;
        if (spinner == null || i < 0) {
            return;
        }
        spinner.setSelection(i);
    }
}
