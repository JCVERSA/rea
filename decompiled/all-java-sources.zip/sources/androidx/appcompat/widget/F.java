package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import ax.p210n.AbstractC2162a;

/* JADX INFO: loaded from: classes.dex */
public class F extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
    private static final Interpolator s0 = new DecelerateInterpolator();
    private c k0;
    B l0;
    private Spinner m0;
    private boolean n0;
    int o0;
    int p0;
    Runnable q;
    private int q0;
    private int r0;

    class a implements Runnable {
        final /* synthetic */ View q;

        a(View view) {
            this.q = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            F.this.smoothScrollTo(this.q.getLeft() - ((F.this.getWidth() - this.q.getWidth()) / 2), 0);
            F.this.q = null;
        }
    }

    private class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return F.this.l0.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return ((d) F.this.l0.getChildAt(i)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                return F.this.c((AbstractC2162a.c) getItem(i), true);
            }
            ((d) view).a((AbstractC2162a.c) getItem(i));
            return view;
        }
    }

    private class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = F.this.l0.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = F.this.l0.getChildAt(i);
                childAt.setSelected(childAt == view);
            }
        }
    }

    private class d extends LinearLayout {
        private AbstractC2162a.c k0;
        private TextView l0;
        private ImageView m0;
        private View n0;
        private final int[] q;

        /* JADX WARN: Illegal instructions before constructor call */
        public d(Context context, AbstractC2162a.c cVar, boolean z) {
            int i = ax.p194m.a.d;
            super(context, null, i);
            int[] iArr = {R.attr.background};
            this.q = iArr;
            this.k0 = cVar;
            L lV = L.v(context, null, iArr, i, 0);
            if (lV.s(0)) {
                setBackgroundDrawable(lV.g(0));
            }
            lV.x();
            if (z) {
                setGravity(8388627);
            }
            c();
        }

        public void a(AbstractC2162a.c cVar) {
            this.k0 = cVar;
            c();
        }

        public AbstractC2162a.c b() {
            return this.k0;
        }

        public void c() {
            AbstractC2162a.c cVar = this.k0;
            View viewB = cVar.b();
            if (viewB != null) {
                ViewParent parent = viewB.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(viewB);
                    }
                    addView(viewB);
                }
                this.n0 = viewB;
                TextView textView = this.l0;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.m0;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.m0.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.n0;
            if (view != null) {
                removeView(view);
                this.n0 = null;
            }
            Drawable drawableC = cVar.c();
            CharSequence charSequenceD = cVar.d();
            if (drawableC != null) {
                if (this.m0 == null) {
                    AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    appCompatImageView.setLayoutParams(layoutParams);
                    addView(appCompatImageView, 0);
                    this.m0 = appCompatImageView;
                }
                this.m0.setImageDrawable(drawableC);
                this.m0.setVisibility(0);
            } else {
                ImageView imageView2 = this.m0;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.m0.setImageDrawable(null);
                }
            }
            boolean zIsEmpty = TextUtils.isEmpty(charSequenceD);
            if (zIsEmpty) {
                TextView textView2 = this.l0;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.l0.setText((CharSequence) null);
                }
            } else {
                if (this.l0 == null) {
                    x xVar = new x(getContext(), null, ax.p194m.a.e);
                    xVar.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    xVar.setLayoutParams(layoutParams2);
                    addView(xVar);
                    this.l0 = xVar;
                }
                this.l0.setText(charSequenceD);
                this.l0.setVisibility(0);
            }
            ImageView imageView3 = this.m0;
            if (imageView3 != null) {
                imageView3.setContentDescription(cVar.a());
            }
            ax.p322u.B.a(this, zIsEmpty ? cVar.a() : null);
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (F.this.o0 > 0) {
                int measuredWidth = getMeasuredWidth();
                int i3 = F.this.o0;
                if (measuredWidth > i3) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), i2);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                sendAccessibilityEvent(4);
            }
        }
    }

    private Spinner b() {
        u uVar = new u(getContext(), null, ax.p194m.a.h);
        uVar.setLayoutParams(new B.a(-2, -1));
        uVar.setOnItemSelectedListener(this);
        return uVar;
    }

    private boolean d() {
        Spinner spinner = this.m0;
        return spinner != null && spinner.getParent() == this;
    }

    private void e() {
        if (d()) {
            return;
        }
        if (this.m0 == null) {
            this.m0 = b();
        }
        removeView(this.l0);
        addView(this.m0, new ViewGroup.LayoutParams(-2, -1));
        if (this.m0.getAdapter() == null) {
            this.m0.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.q = null;
        }
        this.m0.setSelection(this.r0);
    }

    private boolean f() {
        if (!d()) {
            return false;
        }
        removeView(this.m0);
        addView(this.l0, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.m0.getSelectedItemPosition());
        return false;
    }

    public void a(int i) {
        View childAt = this.l0.getChildAt(i);
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.q = aVar;
        post(aVar);
    }

    d c(AbstractC2162a.c cVar, boolean z) {
        d dVar = new d(getContext(), cVar, z);
        if (z) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.q0));
            return dVar;
        }
        dVar.setFocusable(true);
        if (this.k0 == null) {
            this.k0 = new c();
        }
        dVar.setOnClickListener(this.k0);
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.q;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        ax.p290s.a aVarB = ax.p290s.a.b(getContext());
        setContentHeight(aVarB.f());
        this.p0 = aVarB.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.q;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        boolean z = mode == 1073741824;
        setFillViewport(z);
        int childCount = this.l0.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            this.o0 = -1;
        } else {
            if (childCount > 2) {
                this.o0 = (int) (View.MeasureSpec.getSize(i) * 0.4f);
            } else {
                this.o0 = View.MeasureSpec.getSize(i) / 2;
            }
            this.o0 = Math.min(this.o0, this.p0);
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.q0, 1073741824);
        if (z || !this.n0) {
            f();
        } else {
            this.l0.measure(0, iMakeMeasureSpec);
            if (this.l0.getMeasuredWidth() > View.MeasureSpec.getSize(i)) {
                e();
            } else {
                f();
            }
        }
        int measuredWidth = getMeasuredWidth();
        super.onMeasure(i, iMakeMeasureSpec);
        int measuredWidth2 = getMeasuredWidth();
        if (!z || measuredWidth == measuredWidth2) {
            return;
        }
        setTabSelected(this.r0);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z) {
        this.n0 = z;
    }

    public void setContentHeight(int i) {
        this.q0 = i;
        requestLayout();
    }

    public void setTabSelected(int i) {
        this.r0 = i;
        int childCount = this.l0.getChildCount();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = this.l0.getChildAt(i2);
            boolean z = i2 == i;
            childAt.setSelected(z);
            if (z) {
                a(i);
            }
            i2++;
        }
        Spinner spinner = this.m0;
        if (spinner == null || i < 0) {
            return;
        }
        spinner.setSelection(i);
    }
}
