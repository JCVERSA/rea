package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import ax.p015b0.C5244t;
import ax.p015b0.C5254y;
import ax.p015b0.InterfaceC5252x;
import ax.p015b0.Y;
import ax.p182n.AbstractC5569a;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup implements InterfaceC5252x {
    private int A0;
    private int B0;
    private int C0;
    private CharSequence D0;
    private CharSequence E0;
    private ColorStateList F0;
    private ColorStateList G0;
    private boolean H0;
    private boolean I0;
    private final ArrayList<View> J0;
    private final ArrayList<View> K0;
    private final int[] L0;
    final C5254y M0;
    private ArrayList<MenuItem> N0;
    h O0;
    private final ActionMenuView.e P0;
    private M Q0;
    private C0550c R0;
    private f S0;
    private androidx.appcompat.view.menu.j.a T0;
    androidx.appcompat.view.menu.e.a U0;
    private boolean V0;
    private OnBackInvokedCallback W0;
    private OnBackInvokedDispatcher X0;
    private boolean Y0;
    private final Runnable Z0;
    private TextView h0;
    private TextView i0;
    private ImageButton j0;
    private ImageView k0;
    private Drawable l0;
    private CharSequence m0;
    ImageButton n0;
    View o0;
    private Context p0;
    ActionMenuView q;
    private int q0;
    private int r0;
    private int s0;
    int t0;
    private int u0;
    private int v0;
    private int w0;
    private int x0;
    private int y0;
    private E z0;

    class a implements ActionMenuView.e {
        a() {
        }

        @Override // androidx.appcompat.widget.ActionMenuView.e
        public boolean onMenuItemClick(MenuItem menuItem) {
            if (Toolbar.this.M0.d(menuItem)) {
                return true;
            }
            h hVar = Toolbar.this.O0;
            if (hVar != null) {
                return hVar.onMenuItemClick(menuItem);
            }
            return false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.T();
        }
    }

    class c implements androidx.appcompat.view.menu.e.a {
        c() {
        }

        @Override // androidx.appcompat.view.menu.e.a
        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            androidx.appcompat.view.menu.e.a aVar = Toolbar.this.U0;
            return aVar != null && aVar.a(eVar, menuItem);
        }

        @Override // androidx.appcompat.view.menu.e.a
        public void b(androidx.appcompat.view.menu.e eVar) {
            if (!Toolbar.this.q.J()) {
                Toolbar.this.M0.e(eVar);
            }
            androidx.appcompat.view.menu.e.a aVar = Toolbar.this.U0;
            if (aVar != null) {
                aVar.b(eVar);
            }
        }
    }

    class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    static class e {
        static OnBackInvokedDispatcher a(View view) {
            return view.findOnBackInvokedDispatcher();
        }

        static OnBackInvokedCallback b(final Runnable runnable) {
            Objects.requireNonNull(runnable);
            return new OnBackInvokedCallback() { // from class: ax.u.A
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    runnable.run();
                }
            };
        }

        static void c(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback) obj2);
        }

        static void d(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    private class f implements androidx.appcompat.view.menu.j {
        androidx.appcompat.view.menu.g X;
        androidx.appcompat.view.menu.e q;

        f() {
        }

        @Override // androidx.appcompat.view.menu.j
        public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
        }

        @Override // androidx.appcompat.view.menu.j
        public void d(boolean z) {
            if (this.X != null) {
                androidx.appcompat.view.menu.e eVar = this.q;
                if (eVar != null) {
                    int size = eVar.size();
                    for (int i = 0; i < size; i++) {
                        if (this.q.getItem(i) == this.X) {
                            return;
                        }
                    }
                }
                f(this.q, this.X);
            }
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean e() {
            return false;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean f(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            KeyEvent.Callback callback = Toolbar.this.o0;
            if (callback instanceof ax.p252s.b) {
                ((ax.p252s.b) callback).e();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.o0);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.n0);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.o0 = null;
            toolbar3.a();
            this.X = null;
            Toolbar.this.requestLayout();
            gVar.r(false);
            Toolbar.this.U();
            return true;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean g(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            Toolbar.this.g();
            ViewParent parent = Toolbar.this.n0.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.n0);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.n0);
            }
            Toolbar.this.o0 = gVar.getActionView();
            this.X = gVar;
            ViewParent parent2 = Toolbar.this.o0.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.o0);
                }
                g gVarGenerateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                gVarGenerateDefaultLayoutParams.a = (toolbar4.t0 & 112) | 8388611;
                gVarGenerateDefaultLayoutParams.b = 2;
                toolbar4.o0.setLayoutParams(gVarGenerateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.o0);
            }
            Toolbar.this.K();
            Toolbar.this.requestLayout();
            gVar.r(true);
            KeyEvent.Callback callback = Toolbar.this.o0;
            if (callback instanceof ax.p252s.b) {
                ((ax.p252s.b) callback).c();
            }
            Toolbar.this.U();
            return true;
        }

        @Override // androidx.appcompat.view.menu.j
        public void i(Context context, androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.g gVar;
            androidx.appcompat.view.menu.e eVar2 = this.q;
            if (eVar2 != null && (gVar = this.X) != null) {
                eVar2.f(gVar);
            }
            this.q = eVar;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean k(androidx.appcompat.view.menu.m mVar) {
            return false;
        }
    }

    public interface h {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.Q);
    }

    private boolean B(View view) {
        return view.getParent() == this || this.K0.contains(view);
    }

    private int E(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - iArr[0];
        int iMax = i2 + Math.max(0, i4);
        iArr[0] = Math.max(0, -i4);
        int iR = r(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iR, iMax + measuredWidth, view.getMeasuredHeight() + iR);
        return iMax + measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).rightMargin;
    }

    private int F(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - iArr[1];
        int iMax = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int iR = r(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iR, iMax, view.getMeasuredHeight() + iR);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).leftMargin);
    }

    private int G(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i6) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + iMax + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    private void H(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private void I() {
        Menu menu = getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        this.M0.b(menu, getMenuInflater());
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.N0 = currentMenuItems2;
    }

    private void J() {
        removeCallbacks(this.Z0);
        post(this.Z0);
    }

    private boolean R() {
        if (!this.V0) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (S(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    private boolean S(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    private void b(List<View> list, int i2) {
        boolean z = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int iB = C5244t.b(i2, getLayoutDirection());
        list.clear();
        if (!z) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.b == 0 && S(childAt) && q(gVar.a) == iB) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            g gVar2 = (g) childAt2.getLayoutParams();
            if (gVar2.b == 0 && S(childAt2) && q(gVar2.a) == iB) {
                list.add(childAt2);
            }
        }
    }

    private void c(View view, boolean z) {
        g gVarGenerateLayoutParams;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            gVarGenerateLayoutParams = generateDefaultLayoutParams();
        } else {
            gVarGenerateLayoutParams = !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (g) layoutParams;
        }
        gVarGenerateLayoutParams.b = 1;
        if (!z || this.o0 == null) {
            addView(view, gVarGenerateLayoutParams);
        } else {
            view.setLayoutParams(gVarGenerateLayoutParams);
            this.K0.add(view);
        }
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new ax.p252s.d(getContext());
    }

    private void h() {
        if (this.z0 == null) {
            this.z0 = new E();
        }
    }

    private void i() {
        if (this.k0 == null) {
            this.k0 = new AppCompatImageView(getContext());
        }
    }

    private void k() {
        l();
        if (this.q.N() == null) {
            androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) this.q.getMenu();
            if (this.S0 == null) {
                this.S0 = new f();
            }
            this.q.setExpandedActionViewsExclusive(true);
            eVar.c(this.S0, this.p0);
            U();
        }
    }

    private void l() {
        if (this.q == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.q = actionMenuView;
            actionMenuView.setPopupTheme(this.q0);
            this.q.setOnMenuItemClickListener(this.P0);
            this.q.O(this.T0, new c());
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.t0 & 112) | 8388613;
            this.q.setLayoutParams(gVarGenerateDefaultLayoutParams);
            c(this.q, false);
        }
    }

    private void m() {
        if (this.j0 == null) {
            this.j0 = new p(getContext(), null, ax.p168m.a.P);
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.t0 & 112) | 8388611;
            this.j0.setLayoutParams(gVarGenerateDefaultLayoutParams);
        }
    }

    private int q(int i2) {
        int layoutDirection = getLayoutDirection();
        int iB = C5244t.b(i2, layoutDirection) & 7;
        if (iB == 1 || iB == 3 || iB == 5) {
            return iB;
        }
        return layoutDirection == 1 ? 5 : 3;
    }

    private int r(View view, int i2) {
        g gVar = (g) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int iT = t(gVar.a);
        if (iT == 48) {
            return getPaddingTop() - i3;
        }
        if (iT == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) gVar).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
        if (iMax < i4) {
            iMax = i4;
        } else {
            int i5 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i6 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
            if (i5 < i6) {
                iMax = Math.max(0, iMax - (i6 - i5));
            }
        }
        return paddingTop + iMax;
    }

    private int t(int i2) {
        int i3 = i2 & 112;
        return (i3 == 16 || i3 == 48 || i3 == 80) ? i3 : this.C0 & 112;
    }

    private int u(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    private int v(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    private int w(List<View> list, int[] iArr) {
        int i2 = iArr[0];
        int i3 = iArr[1];
        int size = list.size();
        int i4 = 0;
        int measuredWidth = 0;
        while (i4 < size) {
            View view = list.get(i4);
            g gVar = (g) view.getLayoutParams();
            int i5 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - i2;
            int i6 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - i3;
            int iMax = Math.max(0, i5);
            int iMax2 = Math.max(0, i6);
            int iMax3 = Math.max(0, -i5);
            int iMax4 = Math.max(0, -i6);
            measuredWidth += iMax + view.getMeasuredWidth() + iMax2;
            i4++;
            i3 = iMax4;
            i2 = iMax3;
        }
        return measuredWidth;
    }

    public void A() {
        Iterator<MenuItem> it = this.N0.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(it.next().getItemId());
        }
        I();
    }

    public boolean C() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.I();
    }

    public boolean D() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.J();
    }

    void K() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (((g) childAt.getLayoutParams()).b != 2 && childAt != this.q) {
                removeViewAt(childCount);
                this.K0.add(childAt);
            }
        }
    }

    public void L(int i2, int i3) {
        h();
        this.z0.e(i2, i3);
    }

    public void M(int i2, int i3) {
        h();
        this.z0.g(i2, i3);
    }

    public void N(androidx.appcompat.view.menu.e eVar, C0550c c0550c) {
        if (eVar == null && this.q == null) {
            return;
        }
        l();
        androidx.appcompat.view.menu.e eVarN = this.q.N();
        if (eVarN == eVar) {
            return;
        }
        if (eVarN != null) {
            eVarN.P(this.R0);
            eVarN.P(this.S0);
        }
        if (this.S0 == null) {
            this.S0 = new f();
        }
        c0550c.G(true);
        if (eVar != null) {
            eVar.c(c0550c, this.p0);
            eVar.c(this.S0, this.p0);
        } else {
            c0550c.i(this.p0, null);
            this.S0.i(this.p0, null);
            c0550c.d(true);
            this.S0.d(true);
        }
        this.q.setPopupTheme(this.q0);
        this.q.setPresenter(c0550c);
        this.R0 = c0550c;
        U();
    }

    public void O(androidx.appcompat.view.menu.j.a aVar, androidx.appcompat.view.menu.e.a aVar2) {
        this.T0 = aVar;
        this.U0 = aVar2;
        ActionMenuView actionMenuView = this.q;
        if (actionMenuView != null) {
            actionMenuView.O(aVar, aVar2);
        }
    }

    public void P(Context context, int i2) {
        this.s0 = i2;
        TextView textView = this.i0;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public void Q(Context context, int i2) {
        this.r0 = i2;
        TextView textView = this.h0;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public boolean T() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.P();
    }

    void U() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = e.a(this);
            boolean z = x() && onBackInvokedDispatcherA != null && isAttachedToWindow() && this.Y0;
            if (z && this.X0 == null) {
                if (this.W0 == null) {
                    this.W0 = e.b(new Runnable() { // from class: ax.u.y
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.q.e();
                        }
                    });
                }
                e.c(onBackInvokedDispatcherA, this.W0);
                this.X0 = onBackInvokedDispatcherA;
                return;
            }
            if (z || (onBackInvokedDispatcher = this.X0) == null) {
                return;
            }
            e.d(onBackInvokedDispatcher, this.W0);
            this.X0 = null;
        }
    }

    void a() {
        for (int size = this.K0.size() - 1; size >= 0; size--) {
            addView(this.K0.get(size));
        }
        this.K0.clear();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof g);
    }

    public boolean d() {
        ActionMenuView actionMenuView;
        return getVisibility() == 0 && (actionMenuView = this.q) != null && actionMenuView.K();
    }

    public void e() {
        f fVar = this.S0;
        androidx.appcompat.view.menu.g gVar = fVar == null ? null : fVar.X;
        if (gVar != null) {
            gVar.collapseActionView();
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.q;
        if (actionMenuView != null) {
            actionMenuView.B();
        }
    }

    void g() {
        if (this.n0 == null) {
            p pVar = new p(getContext(), null, ax.p168m.a.P);
            this.n0 = pVar;
            pVar.setImageDrawable(this.l0);
            this.n0.setContentDescription(this.m0);
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.t0 & 112) | 8388611;
            gVarGenerateDefaultLayoutParams.b = 2;
            this.n0.setLayoutParams(gVarGenerateDefaultLayoutParams);
            this.n0.setOnClickListener(new d());
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.n0;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.n0;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        E e2 = this.z0;
        if (e2 != null) {
            return e2.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.B0;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        E e2 = this.z0;
        if (e2 != null) {
            return e2.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        E e2 = this.z0;
        if (e2 != null) {
            return e2.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        E e2 = this.z0;
        if (e2 != null) {
            return e2.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.A0;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        androidx.appcompat.view.menu.e eVarN;
        ActionMenuView actionMenuView = this.q;
        return (actionMenuView == null || (eVarN = actionMenuView.N()) == null || !eVarN.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.B0, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.A0, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.k0;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.k0;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        k();
        return this.q.getMenu();
    }

    View getNavButtonView() {
        return this.j0;
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.j0;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.j0;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    C0550c getOuterActionMenuPresenter() {
        return this.R0;
    }

    public Drawable getOverflowIcon() {
        k();
        return this.q.getOverflowIcon();
    }

    Context getPopupContext() {
        return this.p0;
    }

    public int getPopupTheme() {
        return this.q0;
    }

    public CharSequence getSubtitle() {
        return this.E0;
    }

    final TextView getSubtitleTextView() {
        return this.i0;
    }

    public CharSequence getTitle() {
        return this.D0;
    }

    public int getTitleMarginBottom() {
        return this.y0;
    }

    public int getTitleMarginEnd() {
        return this.w0;
    }

    public int getTitleMarginStart() {
        return this.v0;
    }

    public int getTitleMarginTop() {
        return this.x0;
    }

    final TextView getTitleTextView() {
        return this.h0;
    }

    public ax.p280u.l getWrapper() {
        if (this.Q0 == null) {
            this.Q0 = new M(this, true);
        }
        return this.Q0;
    }

    @Override // ax.p015b0.InterfaceC5252x
    public void j(ax.p015b0.A a2) {
        this.M0.f(a2);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public g generateDefaultLayoutParams() {
        return new g(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        U();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Z0);
        U();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.I0 = false;
        }
        if (!this.I0) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.I0 = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.I0 = false;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0268  */
    /* JADX WARN: Code duplicated, block: B:102:0x028a  */
    /* JADX WARN: Code duplicated, block: B:104:0x028d  */
    /* JADX WARN: Code duplicated, block: B:107:0x02a1 A[LOOP:0: B:106:0x029f->B:107:0x02a1, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:110:0x02c3 A[LOOP:1: B:109:0x02c1->B:110:0x02c3, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:114:0x02ed A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:115:0x02ef  */
    /* JADX WARN: Code duplicated, block: B:116:0x02f3  */
    /* JADX WARN: Code duplicated, block: B:119:0x02fc A[LOOP:2: B:118:0x02fa->B:119:0x02fc, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x0060 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0062  */
    /* JADX WARN: Code duplicated, block: B:21:0x0069  */
    /* JADX WARN: Code duplicated, block: B:24:0x0077 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x0079  */
    /* JADX WARN: Code duplicated, block: B:26:0x0080  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b4 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cb A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:39:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:40:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:42:0x0104  */
    /* JADX WARN: Code duplicated, block: B:43:0x011c  */
    /* JADX WARN: Code duplicated, block: B:49:0x012a A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:50:0x012c  */
    /* JADX WARN: Code duplicated, block: B:51:0x012f  */
    /* JADX WARN: Code duplicated, block: B:53:0x0133  */
    /* JADX WARN: Code duplicated, block: B:54:0x0136  */
    /* JADX WARN: Code duplicated, block: B:57:0x0146  */
    /* JADX WARN: Code duplicated, block: B:59:0x014e A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:66:0x0167  */
    /* JADX WARN: Code duplicated, block: B:68:0x016b  */
    /* JADX WARN: Code duplicated, block: B:70:0x017d  */
    /* JADX WARN: Code duplicated, block: B:71:0x0180  */
    /* JADX WARN: Code duplicated, block: B:73:0x018b  */
    /* JADX WARN: Code duplicated, block: B:75:0x0197  */
    /* JADX WARN: Code duplicated, block: B:76:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:78:0x01b6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:79:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:81:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:84:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:85:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:87:0x01f7  */
    /* JADX WARN: Code duplicated, block: B:88:0x021b  */
    /* JADX WARN: Code duplicated, block: B:90:0x021e  */
    /* JADX WARN: Code duplicated, block: B:92:0x0227 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:93:0x0229  */
    /* JADX WARN: Code duplicated, block: B:95:0x022e  */
    /* JADX WARN: Code duplicated, block: B:98:0x0242  */
    /* JADX WARN: Code duplicated, block: B:99:0x0265  */
    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int iE;
        int iF;
        int iMax;
        int iMin;
        boolean zS;
        boolean zS2;
        int measuredHeight;
        TextView textView;
        TextView textView2;
        g gVar;
        g gVar2;
        boolean z2;
        int i6;
        int i7;
        int paddingTop;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int iMax2;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int size;
        int iE2;
        int i20;
        int i21;
        int size2;
        int i22;
        int i23;
        int i24;
        int size3;
        boolean z3 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i25 = width - paddingRight;
        int[] iArr = this.L0;
        iArr[1] = 0;
        iArr[0] = 0;
        int iD = Y.D(this);
        int iMin2 = iD >= 0 ? Math.min(iD, i5 - i3) : 0;
        if (S(this.j0)) {
            if (z3) {
                iF = F(this.j0, i25, iArr, iMin2);
                iE = paddingLeft;
            } else {
                iE = E(this.j0, paddingLeft, iArr, iMin2);
            }
            if (S(this.n0)) {
                if (z3) {
                    iF = F(this.n0, iF, iArr, iMin2);
                } else {
                    iE = E(this.n0, iE, iArr, iMin2);
                }
            }
            if (S(this.q)) {
                if (z3) {
                    iE = E(this.q, iE, iArr, iMin2);
                } else {
                    iF = F(this.q, iF, iArr, iMin2);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iE);
            iArr[1] = Math.max(0, currentContentInsetRight - (i25 - iF));
            iMax = Math.max(iE, currentContentInsetLeft);
            iMin = Math.min(iF, i25 - currentContentInsetRight);
            if (S(this.o0)) {
                if (z3) {
                    iMin = F(this.o0, iMin, iArr, iMin2);
                } else {
                    iMax = E(this.o0, iMax, iArr, iMin2);
                }
            }
            if (S(this.k0)) {
                if (z3) {
                    iMin = F(this.k0, iMin, iArr, iMin2);
                } else {
                    iMax = E(this.k0, iMax, iArr, iMin2);
                }
            }
            zS = S(this.h0);
            zS2 = S(this.i0);
            if (zS) {
                g gVar3 = (g) this.h0.getLayoutParams();
                measuredHeight = ((ViewGroup.MarginLayoutParams) gVar3).topMargin + this.h0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar3).bottomMargin;
            } else {
                measuredHeight = 0;
            }
            if (zS2) {
                g gVar4 = (g) this.i0.getLayoutParams();
                measuredHeight += ((ViewGroup.MarginLayoutParams) gVar4).topMargin + this.i0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar4).bottomMargin;
            }
            if (!zS || zS2) {
                if (zS) {
                    textView = this.h0;
                } else {
                    textView = this.i0;
                }
                if (zS2) {
                    textView2 = this.i0;
                } else {
                    textView2 = this.h0;
                }
                gVar = (g) textView.getLayoutParams();
                gVar2 = (g) textView2.getLayoutParams();
                z2 = (!zS && this.h0.getMeasuredWidth() > 0) || (zS2 && this.i0.getMeasuredWidth() > 0);
                i6 = this.C0 & 112;
                i7 = paddingLeft;
                if (i6 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.x0;
                } else if (i6 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                    i15 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                    i16 = this.x0;
                    if (iMax2 < i15 + i16) {
                        iMax2 = i15 + i16;
                    } else {
                        i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                        i18 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                        i19 = this.y0;
                        if (i17 < i18 + i19) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i19) - i17));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.y0) - measuredHeight;
                }
                if (z3) {
                    if (z2) {
                        i12 = this.v0;
                    } else {
                        i12 = 0;
                    }
                    int i26 = i12 - iArr[1];
                    iMin -= Math.max(0, i26);
                    iArr[1] = Math.max(0, -i26);
                    if (zS) {
                        g gVar5 = (g) this.h0.getLayoutParams();
                        int measuredWidth = iMin - this.h0.getMeasuredWidth();
                        int measuredHeight2 = this.h0.getMeasuredHeight() + paddingTop;
                        this.h0.layout(measuredWidth, paddingTop, iMin, measuredHeight2);
                        i13 = measuredWidth - this.w0;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) gVar5).bottomMargin;
                    } else {
                        i13 = iMin;
                    }
                    if (zS2) {
                        int i27 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                        this.i0.layout(iMin - this.i0.getMeasuredWidth(), i27, iMin, this.i0.getMeasuredHeight() + i27);
                        i14 = iMin - this.w0;
                    } else {
                        i14 = iMin;
                    }
                    if (z2) {
                        iMin = Math.min(i13, i14);
                    }
                    iMax = iMax;
                } else {
                    if (z2) {
                        i8 = this.v0;
                    } else {
                        i8 = 0;
                    }
                    i9 = 0;
                    int i28 = i8 - iArr[0];
                    iMax += Math.max(0, i28);
                    iArr[0] = Math.max(0, -i28);
                    if (zS) {
                        g gVar6 = (g) this.h0.getLayoutParams();
                        int measuredWidth2 = this.h0.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.h0.getMeasuredHeight() + paddingTop;
                        this.h0.layout(iMax, paddingTop, measuredWidth2, measuredHeight3);
                        i10 = measuredWidth2 + this.w0;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) gVar6).bottomMargin;
                    } else {
                        i10 = iMax;
                    }
                    if (zS2) {
                        int i29 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                        int measuredWidth3 = this.i0.getMeasuredWidth() + iMax;
                        this.i0.layout(iMax, i29, measuredWidth3, this.i0.getMeasuredHeight() + i29);
                        i11 = measuredWidth3 + this.w0;
                    } else {
                        i11 = iMax;
                    }
                    if (z2) {
                        iMax = Math.max(i10, i11);
                    }
                }
                b(this.J0, 3);
                size = this.J0.size();
                iE2 = iMax;
                for (i20 = 0; i20 < size; i20++) {
                    iE2 = E(this.J0.get(i20), iE2, iArr, iMin2);
                }
                i21 = iMin2;
                b(this.J0, 5);
                size2 = this.J0.size();
                for (i22 = 0; i22 < size2; i22++) {
                    iMin = F(this.J0.get(i22), iMin, iArr, i21);
                }
                b(this.J0, 1);
                int iW = w(this.J0, iArr);
                i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iW / 2);
                i24 = iW + i23;
                if (i23 >= iE2) {
                    if (i24 > iMin) {
                        iE2 = i23 - (i24 - iMin);
                    } else {
                        iE2 = i23;
                    }
                }
                size3 = this.J0.size();
                while (i9 < size3) {
                    iE2 = E(this.J0.get(i9), iE2, iArr, i21);
                    i9++;
                }
                this.J0.clear();
            }
            i7 = paddingLeft;
            iMin2 = iMin2;
            i9 = 0;
            b(this.J0, 3);
            size = this.J0.size();
            iE2 = iMax;
            while (i20 < size) {
                iE2 = E(this.J0.get(i20), iE2, iArr, iMin2);
            }
            i21 = iMin2;
            b(this.J0, 5);
            size2 = this.J0.size();
            while (i22 < size2) {
                iMin = F(this.J0.get(i22), iMin, iArr, i21);
            }
            b(this.J0, 1);
            int iW2 = w(this.J0, iArr);
            i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iW2 / 2);
            i24 = iW2 + i23;
            if (i23 >= iE2) {
                if (i24 > iMin) {
                    iE2 = i23 - (i24 - iMin);
                } else {
                    iE2 = i23;
                }
            }
            size3 = this.J0.size();
            while (i9 < size3) {
                iE2 = E(this.J0.get(i9), iE2, iArr, i21);
                i9++;
            }
            this.J0.clear();
        }
        iE = paddingLeft;
        iF = i25;
        if (S(this.n0)) {
            if (z3) {
                iF = F(this.n0, iF, iArr, iMin2);
            } else {
                iE = E(this.n0, iE, iArr, iMin2);
            }
        }
        if (S(this.q)) {
            if (z3) {
                iE = E(this.q, iE, iArr, iMin2);
            } else {
                iF = F(this.q, iF, iArr, iMin2);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iE);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i25 - iF));
        iMax = Math.max(iE, currentContentInsetLeft2);
        iMin = Math.min(iF, i25 - currentContentInsetRight2);
        if (S(this.o0)) {
            if (z3) {
                iMin = F(this.o0, iMin, iArr, iMin2);
            } else {
                iMax = E(this.o0, iMax, iArr, iMin2);
            }
        }
        if (S(this.k0)) {
            if (z3) {
                iMin = F(this.k0, iMin, iArr, iMin2);
            } else {
                iMax = E(this.k0, iMax, iArr, iMin2);
            }
        }
        zS = S(this.h0);
        zS2 = S(this.i0);
        if (zS) {
            g gVar7 = (g) this.h0.getLayoutParams();
            measuredHeight = ((ViewGroup.MarginLayoutParams) gVar7).topMargin + this.h0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar7).bottomMargin;
        } else {
            measuredHeight = 0;
        }
        if (zS2) {
            g gVar8 = (g) this.i0.getLayoutParams();
            measuredHeight += ((ViewGroup.MarginLayoutParams) gVar8).topMargin + this.i0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar8).bottomMargin;
        }
        if (zS) {
            if (zS) {
                textView = this.h0;
            } else {
                textView = this.i0;
            }
            if (zS2) {
                textView2 = this.i0;
            } else {
                textView2 = this.h0;
            }
            gVar = (g) textView.getLayoutParams();
            gVar2 = (g) textView2.getLayoutParams();
            if (zS) {
            }
            i6 = this.C0 & 112;
            i7 = paddingLeft;
            if (i6 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.x0;
            } else if (i6 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                i15 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                i16 = this.x0;
                if (iMax2 < i15 + i16) {
                    iMax2 = i15 + i16;
                } else {
                    i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                    i19 = this.y0;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.y0) - measuredHeight;
            }
            if (z3) {
                if (z2) {
                    i12 = this.v0;
                } else {
                    i12 = 0;
                }
                int i210 = i12 - iArr[1];
                iMin -= Math.max(0, i210);
                iArr[1] = Math.max(0, -i210);
                if (zS) {
                    g gVar9 = (g) this.h0.getLayoutParams();
                    int measuredWidth4 = iMin - this.h0.getMeasuredWidth();
                    int measuredHeight4 = this.h0.getMeasuredHeight() + paddingTop;
                    this.h0.layout(measuredWidth4, paddingTop, iMin, measuredHeight4);
                    i13 = measuredWidth4 - this.w0;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) gVar9).bottomMargin;
                } else {
                    i13 = iMin;
                }
                if (zS2) {
                    int i211 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                    this.i0.layout(iMin - this.i0.getMeasuredWidth(), i211, iMin, this.i0.getMeasuredHeight() + i211);
                    i14 = iMin - this.w0;
                } else {
                    i14 = iMin;
                }
                if (z2) {
                    iMin = Math.min(i13, i14);
                }
                iMax = iMax;
                i9 = 0;
            } else {
                if (z2) {
                    i8 = this.v0;
                } else {
                    i8 = 0;
                }
                i9 = 0;
                int i212 = i8 - iArr[0];
                iMax += Math.max(0, i212);
                iArr[0] = Math.max(0, -i212);
                if (zS) {
                    g gVar10 = (g) this.h0.getLayoutParams();
                    int measuredWidth5 = this.h0.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.h0.getMeasuredHeight() + paddingTop;
                    this.h0.layout(iMax, paddingTop, measuredWidth5, measuredHeight5);
                    i10 = measuredWidth5 + this.w0;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) gVar10).bottomMargin;
                } else {
                    i10 = iMax;
                }
                if (zS2) {
                    int i213 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                    int measuredWidth6 = this.i0.getMeasuredWidth() + iMax;
                    this.i0.layout(iMax, i213, measuredWidth6, this.i0.getMeasuredHeight() + i213);
                    i11 = measuredWidth6 + this.w0;
                } else {
                    i11 = iMax;
                }
                if (z2) {
                    iMax = Math.max(i10, i11);
                }
            }
        } else {
            if (zS) {
                textView = this.h0;
            } else {
                textView = this.i0;
            }
            if (zS2) {
                textView2 = this.i0;
            } else {
                textView2 = this.h0;
            }
            gVar = (g) textView.getLayoutParams();
            gVar2 = (g) textView2.getLayoutParams();
            if (zS) {
            }
            i6 = this.C0 & 112;
            i7 = paddingLeft;
            if (i6 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.x0;
            } else if (i6 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                i15 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                i16 = this.x0;
                if (iMax2 < i15 + i16) {
                    iMax2 = i15 + i16;
                } else {
                    i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                    i19 = this.y0;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.y0) - measuredHeight;
            }
            if (z3) {
                if (z2) {
                    i12 = this.v0;
                } else {
                    i12 = 0;
                }
                int i214 = i12 - iArr[1];
                iMin -= Math.max(0, i214);
                iArr[1] = Math.max(0, -i214);
                if (zS) {
                    g gVar11 = (g) this.h0.getLayoutParams();
                    int measuredWidth7 = iMin - this.h0.getMeasuredWidth();
                    int measuredHeight6 = this.h0.getMeasuredHeight() + paddingTop;
                    this.h0.layout(measuredWidth7, paddingTop, iMin, measuredHeight6);
                    i13 = measuredWidth7 - this.w0;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) gVar11).bottomMargin;
                } else {
                    i13 = iMin;
                }
                if (zS2) {
                    int i215 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                    this.i0.layout(iMin - this.i0.getMeasuredWidth(), i215, iMin, this.i0.getMeasuredHeight() + i215);
                    i14 = iMin - this.w0;
                } else {
                    i14 = iMin;
                }
                if (z2) {
                    iMin = Math.min(i13, i14);
                }
                iMax = iMax;
                i9 = 0;
            } else {
                if (z2) {
                    i8 = this.v0;
                } else {
                    i8 = 0;
                }
                i9 = 0;
                int i216 = i8 - iArr[0];
                iMax += Math.max(0, i216);
                iArr[0] = Math.max(0, -i216);
                if (zS) {
                    g gVar12 = (g) this.h0.getLayoutParams();
                    int measuredWidth8 = this.h0.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.h0.getMeasuredHeight() + paddingTop;
                    this.h0.layout(iMax, paddingTop, measuredWidth8, measuredHeight7);
                    i10 = measuredWidth8 + this.w0;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) gVar12).bottomMargin;
                } else {
                    i10 = iMax;
                }
                if (zS2) {
                    int i217 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.i0.getLayoutParams())).topMargin;
                    int measuredWidth9 = this.i0.getMeasuredWidth() + iMax;
                    this.i0.layout(iMax, i217, measuredWidth9, this.i0.getMeasuredHeight() + i217);
                    i11 = measuredWidth9 + this.w0;
                } else {
                    i11 = iMax;
                }
                if (z2) {
                    iMax = Math.max(i10, i11);
                }
            }
        }
        b(this.J0, 3);
        size = this.J0.size();
        iE2 = iMax;
        while (i20 < size) {
            iE2 = E(this.J0.get(i20), iE2, iArr, iMin2);
        }
        i21 = iMin2;
        b(this.J0, 5);
        size2 = this.J0.size();
        while (i22 < size2) {
            iMin = F(this.J0.get(i22), iMin, iArr, i21);
        }
        b(this.J0, 1);
        int iW3 = w(this.J0, iArr);
        i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iW3 / 2);
        i24 = iW3 + i23;
        if (i23 >= iE2) {
            if (i24 > iMin) {
                iE2 = i23 - (i24 - iMin);
            } else {
                iE2 = i23;
            }
        }
        size3 = this.J0.size();
        while (i9 < size3) {
            iE2 = E(this.J0.get(i9), iE2, iArr, i21);
            i9++;
        }
        this.J0.clear();
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int measuredWidth;
        int iMax;
        int iCombineMeasuredStates;
        int measuredWidth2;
        int iCombineMeasuredStates2;
        int iMax2;
        int measuredHeight;
        int[] iArr = this.L0;
        boolean zB = O.b(this);
        int i4 = !zB ? 1 : 0;
        if (S(this.j0)) {
            H(this.j0, i2, 0, i3, 0, this.u0);
            measuredWidth = this.j0.getMeasuredWidth() + u(this.j0);
            iMax = Math.max(0, this.j0.getMeasuredHeight() + v(this.j0));
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.j0.getMeasuredState());
        } else {
            measuredWidth = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (S(this.n0)) {
            H(this.n0, i2, 0, i3, 0, this.u0);
            measuredWidth = this.n0.getMeasuredWidth() + u(this.n0);
            iMax = Math.max(iMax, this.n0.getMeasuredHeight() + v(this.n0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.n0.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, measuredWidth);
        iArr[zB ? 1 : 0] = Math.max(0, currentContentInsetStart - measuredWidth);
        if (S(this.q)) {
            H(this.q, i2, iMax3, i3, 0, this.u0);
            measuredWidth2 = this.q.getMeasuredWidth() + u(this.q);
            iMax = Math.max(iMax, this.q.getMeasuredHeight() + v(this.q));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.q.getMeasuredState());
        } else {
            measuredWidth2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax4 = iMax3 + Math.max(currentContentInsetEnd, measuredWidth2);
        iArr[i4] = Math.max(0, currentContentInsetEnd - measuredWidth2);
        if (S(this.o0)) {
            iMax4 += G(this.o0, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.o0.getMeasuredHeight() + v(this.o0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.o0.getMeasuredState());
        }
        if (S(this.k0)) {
            iMax4 += G(this.k0, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.k0.getMeasuredHeight() + v(this.k0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.k0.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (((g) childAt.getLayoutParams()).b == 0 && S(childAt)) {
                iMax4 += G(childAt, i2, iMax4, i3, 0, iArr);
                iMax = Math.max(iMax, childAt.getMeasuredHeight() + v(childAt));
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
            }
        }
        int i6 = this.x0 + this.y0;
        int i7 = this.v0 + this.w0;
        if (S(this.h0)) {
            G(this.h0, i2, iMax4 + i7, i3, i6, iArr);
            int measuredWidth3 = this.h0.getMeasuredWidth() + u(this.h0);
            measuredHeight = this.h0.getMeasuredHeight() + v(this.h0);
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.h0.getMeasuredState());
            iMax2 = measuredWidth3;
        } else {
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
            measuredHeight = 0;
        }
        if (S(this.i0)) {
            iMax2 = Math.max(iMax2, G(this.i0, i2, iMax4 + i7, i3, measuredHeight + i6, iArr));
            measuredHeight += this.i0.getMeasuredHeight() + v(this.i0);
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.i0.getMeasuredState());
        }
        int iMax5 = Math.max(iMax, measuredHeight);
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax4 + iMax2 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, (-16777216) & iCombineMeasuredStates2), R() ? 0 : View.resolveSizeAndState(Math.max(iMax5 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i iVar = (i) parcelable;
        super.onRestoreInstanceState(iVar.a());
        ActionMenuView actionMenuView = this.q;
        androidx.appcompat.view.menu.e eVarN = actionMenuView != null ? actionMenuView.N() : null;
        int i2 = iVar.Y;
        if (i2 != 0 && this.S0 != null && eVarN != null && (menuItemFindItem = eVarN.findItem(i2)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (iVar.Z) {
            J();
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        h();
        this.z0.f(i2 == 1);
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.g gVar;
        i iVar = new i(super.onSaveInstanceState());
        f fVar = this.S0;
        if (fVar != null && (gVar = fVar.X) != null) {
            iVar.Y = gVar.getItemId();
        }
        iVar.Z = D();
        return iVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.H0 = false;
        }
        if (!this.H0) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.H0 = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.H0 = false;
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: p, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof g) {
            return new g((g) layoutParams);
        }
        if (layoutParams instanceof AbstractC5569a.C0406a) {
            return new g((AbstractC5569a.C0406a) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new g((ViewGroup.MarginLayoutParams) layoutParams) : new g(layoutParams);
    }

    @Override // ax.p015b0.InterfaceC5252x
    public void s(ax.p015b0.A a2) {
        this.M0.a(a2);
    }

    public void setBackInvokedCallbackEnabled(boolean z) {
        if (this.Y0 != z) {
            this.Y0 = z;
            U();
        }
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(ax.p196o.a.b(getContext(), i2));
    }

    public void setCollapsible(boolean z) {
        this.V0 = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.B0) {
            this.B0 = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.A0) {
            this.A0 = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(ax.p196o.a.b(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(ax.p196o.a.b(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        m();
        this.j0.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(h hVar) {
        this.O0 = hVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        k();
        this.q.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.q0 != i2) {
            this.q0 = i2;
            if (i2 == 0) {
                this.p0 = getContext();
            } else {
                this.p0 = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.y0 = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.w0 = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.v0 = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.x0 = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public boolean x() {
        f fVar = this.S0;
        return (fVar == null || fVar.X == null) ? false : true;
    }

    public boolean y() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.H();
    }

    public void z(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public static class g extends AbstractC5569a.C0406a {
        int b;

        public g(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.b = 0;
        }

        void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public g(int i, int i2) {
            super(i, i2);
            this.b = 0;
            this.a = 8388627;
        }

        public g(g gVar) {
            super((AbstractC5569a.C0406a) gVar);
            this.b = 0;
            this.b = gVar.b;
        }

        public g(AbstractC5569a.C0406a c0406a) {
            super(c0406a);
            this.b = 0;
        }

        public g(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.b = 0;
            a(marginLayoutParams);
        }

        public g(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.b = 0;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.C0 = 8388627;
        this.J0 = new ArrayList<>();
        this.K0 = new ArrayList<>();
        this.L0 = new int[2];
        this.M0 = new C5254y(new Runnable() { // from class: ax.u.z
            @Override // java.lang.Runnable
            public final void run() {
                this.q.A();
            }
        });
        this.N0 = new ArrayList<>();
        this.P0 = new a();
        this.Z0 = new b();
        Context context2 = getContext();
        int[] iArr = ax.p168m.j.W2;
        L lV = L.v(context2, attributeSet, iArr, i2, 0);
        Y.o0(this, context, iArr, attributeSet, lV.r(), i2, 0);
        this.r0 = lV.n(ax.p168m.j.y3, 0);
        this.s0 = lV.n(ax.p168m.j.p3, 0);
        this.C0 = lV.l(ax.p168m.j.X2, this.C0);
        this.t0 = lV.l(ax.p168m.j.Y2, 48);
        int iE = lV.e(ax.p168m.j.s3, 0);
        int i3 = ax.p168m.j.x3;
        iE = lV.s(i3) ? lV.e(i3, iE) : iE;
        this.y0 = iE;
        this.x0 = iE;
        this.w0 = iE;
        this.v0 = iE;
        int iE2 = lV.e(ax.p168m.j.v3, -1);
        if (iE2 >= 0) {
            this.v0 = iE2;
        }
        int iE3 = lV.e(ax.p168m.j.u3, -1);
        if (iE3 >= 0) {
            this.w0 = iE3;
        }
        int iE4 = lV.e(ax.p168m.j.w3, -1);
        if (iE4 >= 0) {
            this.x0 = iE4;
        }
        int iE5 = lV.e(ax.p168m.j.t3, -1);
        if (iE5 >= 0) {
            this.y0 = iE5;
        }
        this.u0 = lV.f(ax.p168m.j.j3, -1);
        int iE6 = lV.e(ax.p168m.j.f3, Integer.MIN_VALUE);
        int iE7 = lV.e(ax.p168m.j.b3, Integer.MIN_VALUE);
        int iF = lV.f(ax.p168m.j.d3, 0);
        int iF2 = lV.f(ax.p168m.j.e3, 0);
        h();
        this.z0.e(iF, iF2);
        if (iE6 != Integer.MIN_VALUE || iE7 != Integer.MIN_VALUE) {
            this.z0.g(iE6, iE7);
        }
        this.A0 = lV.e(ax.p168m.j.g3, Integer.MIN_VALUE);
        this.B0 = lV.e(ax.p168m.j.c3, Integer.MIN_VALUE);
        this.l0 = lV.g(ax.p168m.j.a3);
        this.m0 = lV.p(ax.p168m.j.Z2);
        CharSequence charSequenceP = lV.p(ax.p168m.j.r3);
        if (!TextUtils.isEmpty(charSequenceP)) {
            setTitle(charSequenceP);
        }
        CharSequence charSequenceP2 = lV.p(ax.p168m.j.o3);
        if (!TextUtils.isEmpty(charSequenceP2)) {
            setSubtitle(charSequenceP2);
        }
        this.p0 = getContext();
        setPopupTheme(lV.n(ax.p168m.j.n3, 0));
        Drawable drawableG = lV.g(ax.p168m.j.m3);
        if (drawableG != null) {
            setNavigationIcon(drawableG);
        }
        CharSequence charSequenceP3 = lV.p(ax.p168m.j.l3);
        if (!TextUtils.isEmpty(charSequenceP3)) {
            setNavigationContentDescription(charSequenceP3);
        }
        Drawable drawableG2 = lV.g(ax.p168m.j.h3);
        if (drawableG2 != null) {
            setLogo(drawableG2);
        }
        CharSequence charSequenceP4 = lV.p(ax.p168m.j.i3);
        if (!TextUtils.isEmpty(charSequenceP4)) {
            setLogoDescription(charSequenceP4);
        }
        int i4 = ax.p168m.j.z3;
        if (lV.s(i4)) {
            setTitleTextColor(lV.c(i4));
        }
        int i5 = ax.p168m.j.q3;
        if (lV.s(i5)) {
            setSubtitleTextColor(lV.c(i5));
        }
        int i6 = ax.p168m.j.k3;
        if (lV.s(i6)) {
            z(lV.n(i6, 0));
        }
        lV.x();
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.n0;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            this.n0.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.n0;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.l0);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!B(this.k0)) {
                c(this.k0, true);
            }
        } else {
            ImageView imageView = this.k0;
            if (imageView != null && B(imageView)) {
                removeView(this.k0);
                this.K0.remove(this.k0);
            }
        }
        ImageView imageView2 = this.k0;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageView imageView = this.k0;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m();
        }
        ImageButton imageButton = this.j0;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            ax.p280u.B.a(this.j0, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            m();
            if (!B(this.j0)) {
                c(this.j0, true);
            }
        } else {
            ImageButton imageButton = this.j0;
            if (imageButton != null && B(imageButton)) {
                removeView(this.j0);
                this.K0.remove(this.j0);
            }
        }
        ImageButton imageButton2 = this.j0;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.i0;
            if (textView != null && B(textView)) {
                removeView(this.i0);
                this.K0.remove(this.i0);
            }
        } else {
            if (this.i0 == null) {
                Context context = getContext();
                x xVar = new x(context);
                this.i0 = xVar;
                xVar.setSingleLine();
                this.i0.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.s0;
                if (i2 != 0) {
                    this.i0.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.G0;
                if (colorStateList != null) {
                    this.i0.setTextColor(colorStateList);
                }
            }
            if (!B(this.i0)) {
                c(this.i0, true);
            }
        }
        TextView textView2 = this.i0;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.E0 = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.G0 = colorStateList;
        TextView textView = this.i0;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.h0;
            if (textView != null && B(textView)) {
                removeView(this.h0);
                this.K0.remove(this.h0);
            }
        } else {
            if (this.h0 == null) {
                Context context = getContext();
                x xVar = new x(context);
                this.h0 = xVar;
                xVar.setSingleLine();
                this.h0.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.r0;
                if (i2 != 0) {
                    this.h0.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.F0;
                if (colorStateList != null) {
                    this.h0.setTextColor(colorStateList);
                }
            }
            if (!B(this.h0)) {
                c(this.h0, true);
            }
        }
        TextView textView2 = this.h0;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.D0 = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.F0 = colorStateList;
        TextView textView = this.h0;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public static class i extends ax.p141k0.a {
        public static final Parcelable.Creator<i> CREATOR = new a();
        int Y;
        boolean Z;

        class a implements Parcelable.ClassLoaderCreator<i> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel) {
                return new i(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new i(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public i[] newArray(int i) {
                return new i[i];
            }
        }

        public i(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.Y = parcel.readInt();
            this.Z = parcel.readInt() != 0;
        }

        @Override // ax.p141k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeInt(this.Z ? 1 : 0);
        }

        public i(Parcelable parcelable) {
            super(parcelable);
        }
    }
}
