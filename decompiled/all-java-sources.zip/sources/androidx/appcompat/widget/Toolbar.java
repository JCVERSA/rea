package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import ax.p035c0.C1839d0;
import ax.p035c0.C1869t;
import ax.p035c0.C1881z;
import ax.p035c0.InterfaceC1875w;
import ax.p210n.AbstractC2162a;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup implements InterfaceC1875w {
    private int A0;
    private int B0;
    private E C0;
    private int D0;
    private int E0;
    private int F0;
    private CharSequence G0;
    private CharSequence H0;
    private ColorStateList I0;
    private ColorStateList J0;
    private boolean K0;
    private boolean L0;
    private final ArrayList<View> M0;
    private final ArrayList<View> N0;
    private final int[] O0;
    final C1881z P0;
    private ArrayList<MenuItem> Q0;
    h R0;
    private final ActionMenuView.e S0;
    private M T0;
    private C0593c U0;
    private f V0;
    private androidx.appcompat.view.menu.j.a W0;
    androidx.appcompat.view.menu.e.a X0;
    private boolean Y0;
    private OnBackInvokedCallback Z0;
    private OnBackInvokedDispatcher a1;
    private boolean b1;
    private final Runnable c1;
    private TextView k0;
    private TextView l0;
    private ImageButton m0;
    private ImageView n0;
    private Drawable o0;
    private CharSequence p0;
    ActionMenuView q;
    ImageButton q0;
    View r0;
    private Context s0;
    private int t0;
    private int u0;
    private int v0;
    int w0;
    private int x0;
    private int y0;
    private int z0;

    class a implements ActionMenuView.e {
        a() {
        }

        @Override // androidx.appcompat.widget.ActionMenuView.e
        public boolean onMenuItemClick(MenuItem menuItem) {
            if (Toolbar.this.P0.h(menuItem)) {
                return true;
            }
            h hVar = Toolbar.this.R0;
            if (hVar != null) {
                return hVar.onMenuItemClick(menuItem);
            }
            return false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.R();
        }
    }

    class c implements androidx.appcompat.view.menu.e.a {
        c() {
        }

        @Override // androidx.appcompat.view.menu.e.a
        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            androidx.appcompat.view.menu.e.a aVar = Toolbar.this.X0;
            return aVar != null && aVar.a(eVar, menuItem);
        }

        @Override // androidx.appcompat.view.menu.e.a
        public void b(androidx.appcompat.view.menu.e eVar) {
            if (!Toolbar.this.q.J()) {
                Toolbar.this.P0.i(eVar);
            }
            androidx.appcompat.view.menu.e.a aVar = Toolbar.this.X0;
            if (aVar != null) {
                aVar.b(eVar);
            }
        }
    }

    class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    static class e {
        static OnBackInvokedDispatcher a(View view) {
            return view.findOnBackInvokedDispatcher();
        }

        static OnBackInvokedCallback b(final Runnable runnable) {
            Objects.requireNonNull(runnable);
            return new OnBackInvokedCallback() { // from class: ax.u.A
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    runnable.run();
                }
            };
        }

        static void c(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback) obj2);
        }

        static void d(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    private class f implements androidx.appcompat.view.menu.j {
        androidx.appcompat.view.menu.g X;
        androidx.appcompat.view.menu.e q;

        f() {
        }

        @Override // androidx.appcompat.view.menu.j
        public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
        }

        @Override // androidx.appcompat.view.menu.j
        public void d(boolean z) {
            if (this.X != null) {
                androidx.appcompat.view.menu.e eVar = this.q;
                if (eVar != null) {
                    int size = eVar.size();
                    for (int i = 0; i < size; i++) {
                        if (this.q.getItem(i) == this.X) {
                            return;
                        }
                    }
                }
                f(this.q, this.X);
            }
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean e() {
            return false;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean f(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            KeyEvent.Callback callback = Toolbar.this.r0;
            if (callback instanceof ax.p290s.b) {
                ((ax.p290s.b) callback).e();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.r0);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.q0);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.r0 = null;
            toolbar3.a();
            this.X = null;
            Toolbar.this.requestLayout();
            gVar.r(false);
            Toolbar.this.S();
            return true;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean g(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            Toolbar.this.g();
            ViewParent parent = Toolbar.this.q0.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.q0);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.q0);
            }
            Toolbar.this.r0 = gVar.getActionView();
            this.X = gVar;
            ViewParent parent2 = Toolbar.this.r0.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.r0);
                }
                g gVarGenerateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                gVarGenerateDefaultLayoutParams.a = (toolbar4.w0 & 112) | 8388611;
                gVarGenerateDefaultLayoutParams.b = 2;
                toolbar4.r0.setLayoutParams(gVarGenerateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.r0);
            }
            Toolbar.this.I();
            Toolbar.this.requestLayout();
            gVar.r(true);
            KeyEvent.Callback callback = Toolbar.this.r0;
            if (callback instanceof ax.p290s.b) {
                ((ax.p290s.b) callback).c();
            }
            Toolbar.this.S();
            return true;
        }

        @Override // androidx.appcompat.view.menu.j
        public void i(Context context, androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.g gVar;
            androidx.appcompat.view.menu.e eVar2 = this.q;
            if (eVar2 != null && (gVar = this.X) != null) {
                eVar2.f(gVar);
            }
            this.q = eVar;
        }

        @Override // androidx.appcompat.view.menu.j
        public boolean k(androidx.appcompat.view.menu.m mVar) {
            return false;
        }
    }

    public static class g extends AbstractC2162a.C0395a {
        int b;

        public g(int i, int i2) {
            super(i, i2);
            this.b = 0;
            this.a = 8388627;
        }

        public g(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.b = 0;
        }

        public g(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.b = 0;
        }

        public g(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.b = 0;
            a(marginLayoutParams);
        }

        public g(g gVar) {
            super((AbstractC2162a.C0395a) gVar);
            this.b = 0;
            this.b = gVar.b;
        }

        public g(AbstractC2162a.C0395a c0395a) {
            super(c0395a);
            this.b = 0;
        }

        void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }
    }

    public interface h {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public static class i extends ax.p163k0.a {
        public static final Parcelable.Creator<i> CREATOR = new a();
        int Y;
        boolean Z;

        class a implements Parcelable.ClassLoaderCreator<i> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel) {
                return new i(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public i createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new i(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public i[] newArray(int i) {
                return new i[i];
            }
        }

        public i(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.Y = parcel.readInt();
            this.Z = parcel.readInt() != 0;
        }

        public i(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // ax.p163k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeInt(this.Z ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.T);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.F0 = 8388627;
        this.M0 = new ArrayList<>();
        this.N0 = new ArrayList<>();
        this.O0 = new int[2];
        this.P0 = new C1881z(new Runnable() { // from class: ax.u.z
            @Override // java.lang.Runnable
            public final void run() {
                this.q.y();
            }
        });
        this.Q0 = new ArrayList<>();
        this.S0 = new a();
        this.c1 = new b();
        Context context2 = getContext();
        int[] iArr = ax.p194m.j.a3;
        L lV = L.v(context2, attributeSet, iArr, i2, 0);
        C1839d0.j0(this, context, iArr, attributeSet, lV.r(), i2, 0);
        this.u0 = lV.n(ax.p194m.j.C3, 0);
        this.v0 = lV.n(ax.p194m.j.t3, 0);
        this.F0 = lV.l(ax.p194m.j.b3, this.F0);
        this.w0 = lV.l(ax.p194m.j.c3, 48);
        int iE = lV.e(ax.p194m.j.w3, 0);
        int i3 = ax.p194m.j.B3;
        iE = lV.s(i3) ? lV.e(i3, iE) : iE;
        this.B0 = iE;
        this.A0 = iE;
        this.z0 = iE;
        this.y0 = iE;
        int iE2 = lV.e(ax.p194m.j.z3, -1);
        if (iE2 >= 0) {
            this.y0 = iE2;
        }
        int iE3 = lV.e(ax.p194m.j.y3, -1);
        if (iE3 >= 0) {
            this.z0 = iE3;
        }
        int iE4 = lV.e(ax.p194m.j.A3, -1);
        if (iE4 >= 0) {
            this.A0 = iE4;
        }
        int iE5 = lV.e(ax.p194m.j.x3, -1);
        if (iE5 >= 0) {
            this.B0 = iE5;
        }
        this.x0 = lV.f(ax.p194m.j.n3, -1);
        int iE6 = lV.e(ax.p194m.j.j3, Integer.MIN_VALUE);
        int iE7 = lV.e(ax.p194m.j.f3, Integer.MIN_VALUE);
        int iF = lV.f(ax.p194m.j.h3, 0);
        int iF2 = lV.f(ax.p194m.j.i3, 0);
        h();
        this.C0.e(iF, iF2);
        if (iE6 != Integer.MIN_VALUE || iE7 != Integer.MIN_VALUE) {
            this.C0.g(iE6, iE7);
        }
        this.D0 = lV.e(ax.p194m.j.k3, Integer.MIN_VALUE);
        this.E0 = lV.e(ax.p194m.j.g3, Integer.MIN_VALUE);
        this.o0 = lV.g(ax.p194m.j.e3);
        this.p0 = lV.p(ax.p194m.j.d3);
        CharSequence charSequenceP = lV.p(ax.p194m.j.v3);
        if (!TextUtils.isEmpty(charSequenceP)) {
            setTitle(charSequenceP);
        }
        CharSequence charSequenceP2 = lV.p(ax.p194m.j.s3);
        if (!TextUtils.isEmpty(charSequenceP2)) {
            setSubtitle(charSequenceP2);
        }
        this.s0 = getContext();
        setPopupTheme(lV.n(ax.p194m.j.r3, 0));
        Drawable drawableG = lV.g(ax.p194m.j.q3);
        if (drawableG != null) {
            setNavigationIcon(drawableG);
        }
        CharSequence charSequenceP3 = lV.p(ax.p194m.j.p3);
        if (!TextUtils.isEmpty(charSequenceP3)) {
            setNavigationContentDescription(charSequenceP3);
        }
        Drawable drawableG2 = lV.g(ax.p194m.j.l3);
        if (drawableG2 != null) {
            setLogo(drawableG2);
        }
        CharSequence charSequenceP4 = lV.p(ax.p194m.j.m3);
        if (!TextUtils.isEmpty(charSequenceP4)) {
            setLogoDescription(charSequenceP4);
        }
        int i4 = ax.p194m.j.D3;
        if (lV.s(i4)) {
            setTitleTextColor(lV.c(i4));
        }
        int i5 = ax.p194m.j.u3;
        if (lV.s(i5)) {
            setSubtitleTextColor(lV.c(i5));
        }
        int i6 = ax.p194m.j.o3;
        if (lV.s(i6)) {
            x(lV.n(i6, 0));
        }
        lV.x();
    }

    private int C(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - iArr[0];
        int iMax = i2 + Math.max(0, i4);
        iArr[0] = Math.max(0, -i4);
        int iQ = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iQ, iMax + measuredWidth, view.getMeasuredHeight() + iQ);
        return iMax + measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).rightMargin;
    }

    private int D(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - iArr[1];
        int iMax = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int iQ = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iQ, iMax, view.getMeasuredHeight() + iQ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) gVar).leftMargin);
    }

    private int E(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i6) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + iMax + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    private void F(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private void G() {
        Menu menu = getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        this.P0.f(menu, getMenuInflater());
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.Q0 = currentMenuItems2;
    }

    private void H() {
        removeCallbacks(this.c1);
        post(this.c1);
    }

    private boolean P() {
        if (!this.Y0) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (Q(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    private boolean Q(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    private void b(List<View> list, int i2) {
        boolean z = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int iB = C1869t.b(i2, getLayoutDirection());
        list.clear();
        if (!z) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.b == 0 && Q(childAt) && p(gVar.a) == iB) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            g gVar2 = (g) childAt2.getLayoutParams();
            if (gVar2.b == 0 && Q(childAt2) && p(gVar2.a) == iB) {
                list.add(childAt2);
            }
        }
    }

    private void c(View view, boolean z) {
        g gVarGenerateLayoutParams;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            gVarGenerateLayoutParams = generateDefaultLayoutParams();
        } else {
            gVarGenerateLayoutParams = !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (g) layoutParams;
        }
        gVarGenerateLayoutParams.b = 1;
        if (!z || this.r0 == null) {
            addView(view, gVarGenerateLayoutParams);
        } else {
            view.setLayoutParams(gVarGenerateLayoutParams);
            this.N0.add(view);
        }
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new ax.p290s.d(getContext());
    }

    private void h() {
        if (this.C0 == null) {
            this.C0 = new E();
        }
    }

    private void i() {
        if (this.n0 == null) {
            this.n0 = new AppCompatImageView(getContext());
        }
    }

    private void j() {
        k();
        if (this.q.N() == null) {
            androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) this.q.getMenu();
            if (this.V0 == null) {
                this.V0 = new f();
            }
            this.q.setExpandedActionViewsExclusive(true);
            eVar.c(this.V0, this.s0);
            S();
        }
    }

    private void k() {
        if (this.q == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.q = actionMenuView;
            actionMenuView.setPopupTheme(this.t0);
            this.q.setOnMenuItemClickListener(this.S0);
            this.q.O(this.W0, new c());
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.w0 & 112) | 8388613;
            this.q.setLayoutParams(gVarGenerateDefaultLayoutParams);
            c(this.q, false);
        }
    }

    private void l() {
        if (this.m0 == null) {
            this.m0 = new p(getContext(), null, ax.p194m.a.S);
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.w0 & 112) | 8388611;
            this.m0.setLayoutParams(gVarGenerateDefaultLayoutParams);
        }
    }

    private int p(int i2) {
        int layoutDirection = getLayoutDirection();
        int iB = C1869t.b(i2, layoutDirection) & 7;
        if (iB == 1 || iB == 3 || iB == 5) {
            return iB;
        }
        return layoutDirection == 1 ? 5 : 3;
    }

    private int q(View view, int i2) {
        g gVar = (g) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int iR = r(gVar.a);
        if (iR == 48) {
            return getPaddingTop() - i3;
        }
        if (iR == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) gVar).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i4 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
        if (iMax < i4) {
            iMax = i4;
        } else {
            int i5 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i6 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
            if (i5 < i6) {
                iMax = Math.max(0, iMax - (i6 - i5));
            }
        }
        return paddingTop + iMax;
    }

    private int r(int i2) {
        int i3 = i2 & 112;
        return (i3 == 16 || i3 == 48 || i3 == 80) ? i3 : this.F0 & 112;
    }

    private int s(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    private int t(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    private int u(List<View> list, int[] iArr) {
        int i2 = iArr[0];
        int i3 = iArr[1];
        int size = list.size();
        int i4 = 0;
        int measuredWidth = 0;
        while (i4 < size) {
            View view = list.get(i4);
            g gVar = (g) view.getLayoutParams();
            int i5 = ((ViewGroup.MarginLayoutParams) gVar).leftMargin - i2;
            int i6 = ((ViewGroup.MarginLayoutParams) gVar).rightMargin - i3;
            int iMax = Math.max(0, i5);
            int iMax2 = Math.max(0, i6);
            int iMax3 = Math.max(0, -i5);
            int iMax4 = Math.max(0, -i6);
            measuredWidth += iMax + view.getMeasuredWidth() + iMax2;
            i4++;
            i3 = iMax4;
            i2 = iMax3;
        }
        return measuredWidth;
    }

    private boolean z(View view) {
        return view.getParent() == this || this.N0.contains(view);
    }

    public boolean A() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.I();
    }

    public boolean B() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.J();
    }

    void I() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (((g) childAt.getLayoutParams()).b != 2 && childAt != this.q) {
                removeViewAt(childCount);
                this.N0.add(childAt);
            }
        }
    }

    public void J(int i2, int i3) {
        h();
        this.C0.e(i2, i3);
    }

    public void K(int i2, int i3) {
        h();
        this.C0.g(i2, i3);
    }

    public void L(androidx.appcompat.view.menu.e eVar, C0593c c0593c) {
        if (eVar == null && this.q == null) {
            return;
        }
        k();
        androidx.appcompat.view.menu.e eVarN = this.q.N();
        if (eVarN == eVar) {
            return;
        }
        if (eVarN != null) {
            eVarN.P(this.U0);
            eVarN.P(this.V0);
        }
        if (this.V0 == null) {
            this.V0 = new f();
        }
        c0593c.G(true);
        if (eVar != null) {
            eVar.c(c0593c, this.s0);
            eVar.c(this.V0, this.s0);
        } else {
            c0593c.i(this.s0, null);
            this.V0.i(this.s0, null);
            c0593c.d(true);
            this.V0.d(true);
        }
        this.q.setPopupTheme(this.t0);
        this.q.setPresenter(c0593c);
        this.U0 = c0593c;
        S();
    }

    public void M(androidx.appcompat.view.menu.j.a aVar, androidx.appcompat.view.menu.e.a aVar2) {
        this.W0 = aVar;
        this.X0 = aVar2;
        ActionMenuView actionMenuView = this.q;
        if (actionMenuView != null) {
            actionMenuView.O(aVar, aVar2);
        }
    }

    public void N(Context context, int i2) {
        this.v0 = i2;
        TextView textView = this.l0;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public void O(Context context, int i2) {
        this.u0 = i2;
        TextView textView = this.k0;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public boolean R() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.P();
    }

    void S() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = e.a(this);
            boolean z = v() && onBackInvokedDispatcherA != null && isAttachedToWindow() && this.b1;
            if (z && this.a1 == null) {
                if (this.Z0 == null) {
                    this.Z0 = e.b(new Runnable() { // from class: ax.u.y
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.q.e();
                        }
                    });
                }
                e.c(onBackInvokedDispatcherA, this.Z0);
                this.a1 = onBackInvokedDispatcherA;
                return;
            }
            if (z || (onBackInvokedDispatcher = this.a1) == null) {
                return;
            }
            e.d(onBackInvokedDispatcher, this.Z0);
            this.a1 = null;
        }
    }

    void a() {
        for (int size = this.N0.size() - 1; size >= 0; size--) {
            addView(this.N0.get(size));
        }
        this.N0.clear();
    }

    @Override // ax.p035c0.InterfaceC1875w
    public void addMenuProvider(ax.p035c0.B b2) {
        this.P0.c(b2);
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof g);
    }

    public boolean d() {
        ActionMenuView actionMenuView;
        return getVisibility() == 0 && (actionMenuView = this.q) != null && actionMenuView.K();
    }

    public void e() {
        f fVar = this.V0;
        androidx.appcompat.view.menu.g gVar = fVar == null ? null : fVar.X;
        if (gVar != null) {
            gVar.collapseActionView();
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.q;
        if (actionMenuView != null) {
            actionMenuView.B();
        }
    }

    void g() {
        if (this.q0 == null) {
            p pVar = new p(getContext(), null, ax.p194m.a.S);
            this.q0 = pVar;
            pVar.setImageDrawable(this.o0);
            this.q0.setContentDescription(this.p0);
            g gVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            gVarGenerateDefaultLayoutParams.a = (this.w0 & 112) | 8388611;
            gVarGenerateDefaultLayoutParams.b = 2;
            this.q0.setLayoutParams(gVarGenerateDefaultLayoutParams);
            this.q0.setOnClickListener(new d());
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.q0;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.q0;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        E e2 = this.C0;
        if (e2 != null) {
            return e2.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.E0;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        E e2 = this.C0;
        if (e2 != null) {
            return e2.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        E e2 = this.C0;
        if (e2 != null) {
            return e2.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        E e2 = this.C0;
        if (e2 != null) {
            return e2.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.D0;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        androidx.appcompat.view.menu.e eVarN;
        ActionMenuView actionMenuView = this.q;
        return (actionMenuView == null || (eVarN = actionMenuView.N()) == null || !eVarN.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.E0, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.D0, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.n0;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.n0;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        j();
        return this.q.getMenu();
    }

    View getNavButtonView() {
        return this.m0;
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.m0;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.m0;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    C0593c getOuterActionMenuPresenter() {
        return this.U0;
    }

    public Drawable getOverflowIcon() {
        j();
        return this.q.getOverflowIcon();
    }

    Context getPopupContext() {
        return this.s0;
    }

    public int getPopupTheme() {
        return this.t0;
    }

    public CharSequence getSubtitle() {
        return this.H0;
    }

    final TextView getSubtitleTextView() {
        return this.l0;
    }

    public CharSequence getTitle() {
        return this.G0;
    }

    public int getTitleMarginBottom() {
        return this.B0;
    }

    public int getTitleMarginEnd() {
        return this.z0;
    }

    public int getTitleMarginStart() {
        return this.y0;
    }

    public int getTitleMarginTop() {
        return this.A0;
    }

    final TextView getTitleTextView() {
        return this.k0;
    }

    public ax.p322u.l getWrapper() {
        if (this.T0 == null) {
            this.T0 = new M(this, true);
        }
        return this.T0;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public g generateDefaultLayoutParams() {
        return new g(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public g generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof g) {
            return new g((g) layoutParams);
        }
        if (layoutParams instanceof AbstractC2162a.C0395a) {
            return new g((AbstractC2162a.C0395a) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new g((ViewGroup.MarginLayoutParams) layoutParams) : new g(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        S();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.c1);
        S();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.L0 = false;
        }
        if (!this.L0) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.L0 = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.L0 = false;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0281  */
    /* JADX WARN: Code duplicated, block: B:102:0x0284  */
    /* JADX WARN: Code duplicated, block: B:105:0x0298 A[LOOP:0: B:104:0x0296->B:105:0x0298, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:108:0x02b6 A[LOOP:1: B:107:0x02b4->B:108:0x02b6, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:112:0x02dd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:113:0x02df  */
    /* JADX WARN: Code duplicated, block: B:114:0x02e3  */
    /* JADX WARN: Code duplicated, block: B:117:0x02ec A[LOOP:2: B:116:0x02ea->B:117:0x02ec, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x0060 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0062  */
    /* JADX WARN: Code duplicated, block: B:21:0x0069  */
    /* JADX WARN: Code duplicated, block: B:24:0x0077 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x0079  */
    /* JADX WARN: Code duplicated, block: B:26:0x0080  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b4 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cb A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:39:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:40:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:42:0x0104  */
    /* JADX WARN: Code duplicated, block: B:43:0x011d  */
    /* JADX WARN: Code duplicated, block: B:48:0x0127 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:49:0x0129  */
    /* JADX WARN: Code duplicated, block: B:50:0x012c  */
    /* JADX WARN: Code duplicated, block: B:52:0x0130  */
    /* JADX WARN: Code duplicated, block: B:53:0x0133  */
    /* JADX WARN: Code duplicated, block: B:56:0x0145  */
    /* JADX WARN: Code duplicated, block: B:58:0x014d A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:65:0x0166  */
    /* JADX WARN: Code duplicated, block: B:67:0x016a  */
    /* JADX WARN: Code duplicated, block: B:69:0x017d  */
    /* JADX WARN: Code duplicated, block: B:70:0x0180  */
    /* JADX WARN: Code duplicated, block: B:72:0x018c  */
    /* JADX WARN: Code duplicated, block: B:74:0x0198  */
    /* JADX WARN: Code duplicated, block: B:75:0x01a2  */
    /* JADX WARN: Code duplicated, block: B:77:0x01af A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:78:0x01b1  */
    /* JADX WARN: Code duplicated, block: B:79:0x01b4  */
    /* JADX WARN: Code duplicated, block: B:82:0x01c7  */
    /* JADX WARN: Code duplicated, block: B:83:0x01eb  */
    /* JADX WARN: Code duplicated, block: B:85:0x01ee  */
    /* JADX WARN: Code duplicated, block: B:86:0x0212  */
    /* JADX WARN: Code duplicated, block: B:88:0x0215  */
    /* JADX WARN: Code duplicated, block: B:90:0x021e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:91:0x0220  */
    /* JADX WARN: Code duplicated, block: B:93:0x0225  */
    /* JADX WARN: Code duplicated, block: B:96:0x0239  */
    /* JADX WARN: Code duplicated, block: B:97:0x025c  */
    /* JADX WARN: Code duplicated, block: B:99:0x025f  */
    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int iC;
        int iD;
        int iMax;
        int iMin;
        boolean zQ;
        boolean zQ2;
        int measuredHeight;
        TextView textView;
        TextView textView2;
        g gVar;
        g gVar2;
        int i6;
        boolean z2;
        int i7;
        int i8;
        int paddingTop;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int iMax2;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int size;
        int iC2;
        int i21;
        int size2;
        int i22;
        int i23;
        int i24;
        int size3;
        boolean z3 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i25 = width - paddingRight;
        int[] iArr = this.O0;
        iArr[1] = 0;
        iArr[0] = 0;
        int iC3 = C1839d0.C(this);
        int iMin2 = iC3 >= 0 ? Math.min(iC3, i5 - i3) : 0;
        if (Q(this.m0)) {
            if (z3) {
                iD = D(this.m0, i25, iArr, iMin2);
                iC = paddingLeft;
            } else {
                iC = C(this.m0, paddingLeft, iArr, iMin2);
            }
            if (Q(this.q0)) {
                if (z3) {
                    iD = D(this.q0, iD, iArr, iMin2);
                } else {
                    iC = C(this.q0, iC, iArr, iMin2);
                }
            }
            if (Q(this.q)) {
                if (z3) {
                    iC = C(this.q, iC, iArr, iMin2);
                } else {
                    iD = D(this.q, iD, iArr, iMin2);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iC);
            iArr[1] = Math.max(0, currentContentInsetRight - (i25 - iD));
            iMax = Math.max(iC, currentContentInsetLeft);
            iMin = Math.min(iD, i25 - currentContentInsetRight);
            if (Q(this.r0)) {
                if (z3) {
                    iMin = D(this.r0, iMin, iArr, iMin2);
                } else {
                    iMax = C(this.r0, iMax, iArr, iMin2);
                }
            }
            if (Q(this.n0)) {
                if (z3) {
                    iMin = D(this.n0, iMin, iArr, iMin2);
                } else {
                    iMax = C(this.n0, iMax, iArr, iMin2);
                }
            }
            zQ = Q(this.k0);
            zQ2 = Q(this.l0);
            if (zQ) {
                g gVar3 = (g) this.k0.getLayoutParams();
                measuredHeight = ((ViewGroup.MarginLayoutParams) gVar3).bottomMargin + ((ViewGroup.MarginLayoutParams) gVar3).topMargin + this.k0.getMeasuredHeight();
            } else {
                measuredHeight = 0;
            }
            if (zQ2) {
                g gVar4 = (g) this.l0.getLayoutParams();
                measuredHeight += ((ViewGroup.MarginLayoutParams) gVar4).topMargin + this.l0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar4).bottomMargin;
            }
            if (!zQ || zQ2) {
                if (zQ) {
                    textView = this.k0;
                } else {
                    textView = this.l0;
                }
                if (zQ2) {
                    textView2 = this.l0;
                } else {
                    textView2 = this.k0;
                }
                gVar = (g) textView.getLayoutParams();
                gVar2 = (g) textView2.getLayoutParams();
                i6 = measuredHeight;
                z2 = (!zQ && this.k0.getMeasuredWidth() > 0) || (zQ2 && this.l0.getMeasuredWidth() > 0);
                i7 = this.F0 & 112;
                i8 = iMax;
                if (i7 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.A0;
                } else if (i7 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - i6) / 2;
                    i16 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                    i17 = this.A0;
                    if (iMax2 < i16 + i17) {
                        iMax2 = i16 + i17;
                    } else {
                        i18 = (((height - paddingBottom) - i6) - iMax2) - paddingTop2;
                        i19 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                        i20 = this.B0;
                        if (i18 < i19 + i20) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i20) - i18));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.B0) - i6;
                }
                if (z3) {
                    if (z2) {
                        i13 = this.y0;
                    } else {
                        i13 = 0;
                    }
                    int i26 = i13 - iArr[1];
                    iMin -= Math.max(0, i26);
                    iArr[1] = Math.max(0, -i26);
                    if (zQ) {
                        g gVar5 = (g) this.k0.getLayoutParams();
                        int measuredWidth = iMin - this.k0.getMeasuredWidth();
                        int measuredHeight2 = this.k0.getMeasuredHeight() + paddingTop;
                        this.k0.layout(measuredWidth, paddingTop, iMin, measuredHeight2);
                        i14 = measuredWidth - this.z0;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) gVar5).bottomMargin;
                    } else {
                        i14 = iMin;
                    }
                    if (zQ2) {
                        int i27 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                        this.l0.layout(iMin - this.l0.getMeasuredWidth(), i27, iMin, this.l0.getMeasuredHeight() + i27);
                        i15 = iMin - this.z0;
                    } else {
                        i15 = iMin;
                    }
                    if (z2) {
                        iMin = Math.min(i14, i15);
                    }
                    iMax = i8;
                    i10 = 0;
                } else {
                    if (z2) {
                        i9 = this.y0;
                    } else {
                        i9 = 0;
                    }
                    i10 = 0;
                    int i28 = i9 - iArr[0];
                    iMax = i8 + Math.max(0, i28);
                    iArr[0] = Math.max(0, -i28);
                    if (zQ) {
                        g gVar6 = (g) this.k0.getLayoutParams();
                        int measuredWidth2 = this.k0.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.k0.getMeasuredHeight() + paddingTop;
                        this.k0.layout(iMax, paddingTop, measuredWidth2, measuredHeight3);
                        i11 = measuredWidth2 + this.z0;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) gVar6).bottomMargin;
                    } else {
                        i11 = iMax;
                    }
                    if (zQ2) {
                        int i29 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                        int measuredWidth3 = this.l0.getMeasuredWidth() + iMax;
                        this.l0.layout(iMax, i29, measuredWidth3, this.l0.getMeasuredHeight() + i29);
                        i12 = measuredWidth3 + this.z0;
                    } else {
                        i12 = iMax;
                    }
                    if (z2) {
                        iMax = Math.max(i11, i12);
                    }
                }
            } else {
                i10 = 0;
            }
            b(this.M0, 3);
            size = this.M0.size();
            iC2 = iMax;
            for (i21 = 0; i21 < size; i21++) {
                iC2 = C(this.M0.get(i21), iC2, iArr, iMin2);
            }
            b(this.M0, 5);
            size2 = this.M0.size();
            for (i22 = 0; i22 < size2; i22++) {
                iMin = D(this.M0.get(i22), iMin, iArr, iMin2);
            }
            b(this.M0, 1);
            int iU = u(this.M0, iArr);
            i23 = (paddingLeft + (((width - paddingLeft) - paddingRight) / 2)) - (iU / 2);
            i24 = iU + i23;
            if (i23 >= iC2) {
                if (i24 > iMin) {
                    iC2 = i23 - (i24 - iMin);
                } else {
                    iC2 = i23;
                }
            }
            size3 = this.M0.size();
            while (i10 < size3) {
                iC2 = C(this.M0.get(i10), iC2, iArr, iMin2);
                i10++;
            }
            this.M0.clear();
        }
        iC = paddingLeft;
        iD = i25;
        if (Q(this.q0)) {
            if (z3) {
                iD = D(this.q0, iD, iArr, iMin2);
            } else {
                iC = C(this.q0, iC, iArr, iMin2);
            }
        }
        if (Q(this.q)) {
            if (z3) {
                iC = C(this.q, iC, iArr, iMin2);
            } else {
                iD = D(this.q, iD, iArr, iMin2);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iC);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i25 - iD));
        iMax = Math.max(iC, currentContentInsetLeft2);
        iMin = Math.min(iD, i25 - currentContentInsetRight2);
        if (Q(this.r0)) {
            if (z3) {
                iMin = D(this.r0, iMin, iArr, iMin2);
            } else {
                iMax = C(this.r0, iMax, iArr, iMin2);
            }
        }
        if (Q(this.n0)) {
            if (z3) {
                iMin = D(this.n0, iMin, iArr, iMin2);
            } else {
                iMax = C(this.n0, iMax, iArr, iMin2);
            }
        }
        zQ = Q(this.k0);
        zQ2 = Q(this.l0);
        if (zQ) {
            g gVar7 = (g) this.k0.getLayoutParams();
            measuredHeight = ((ViewGroup.MarginLayoutParams) gVar7).bottomMargin + ((ViewGroup.MarginLayoutParams) gVar7).topMargin + this.k0.getMeasuredHeight();
        } else {
            measuredHeight = 0;
        }
        if (zQ2) {
            g gVar8 = (g) this.l0.getLayoutParams();
            measuredHeight += ((ViewGroup.MarginLayoutParams) gVar8).topMargin + this.l0.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) gVar8).bottomMargin;
        }
        if (zQ) {
            if (zQ) {
                textView = this.k0;
            } else {
                textView = this.l0;
            }
            if (zQ2) {
                textView2 = this.l0;
            } else {
                textView2 = this.k0;
            }
            gVar = (g) textView.getLayoutParams();
            gVar2 = (g) textView2.getLayoutParams();
            i6 = measuredHeight;
            if (zQ) {
            }
            i7 = this.F0 & 112;
            i8 = iMax;
            if (i7 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.A0;
            } else if (i7 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i6) / 2;
                i16 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                i17 = this.A0;
                if (iMax2 < i16 + i17) {
                    iMax2 = i16 + i17;
                } else {
                    i18 = (((height - paddingBottom) - i6) - iMax2) - paddingTop2;
                    i19 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                    i20 = this.B0;
                    if (i18 < i19 + i20) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i20) - i18));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.B0) - i6;
            }
            if (z3) {
                if (z2) {
                    i13 = this.y0;
                } else {
                    i13 = 0;
                }
                int i210 = i13 - iArr[1];
                iMin -= Math.max(0, i210);
                iArr[1] = Math.max(0, -i210);
                if (zQ) {
                    g gVar9 = (g) this.k0.getLayoutParams();
                    int measuredWidth4 = iMin - this.k0.getMeasuredWidth();
                    int measuredHeight4 = this.k0.getMeasuredHeight() + paddingTop;
                    this.k0.layout(measuredWidth4, paddingTop, iMin, measuredHeight4);
                    i14 = measuredWidth4 - this.z0;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) gVar9).bottomMargin;
                } else {
                    i14 = iMin;
                }
                if (zQ2) {
                    int i211 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                    this.l0.layout(iMin - this.l0.getMeasuredWidth(), i211, iMin, this.l0.getMeasuredHeight() + i211);
                    i15 = iMin - this.z0;
                } else {
                    i15 = iMin;
                }
                if (z2) {
                    iMin = Math.min(i14, i15);
                }
                iMax = i8;
                i10 = 0;
            } else {
                if (z2) {
                    i9 = this.y0;
                } else {
                    i9 = 0;
                }
                i10 = 0;
                int i212 = i9 - iArr[0];
                iMax = i8 + Math.max(0, i212);
                iArr[0] = Math.max(0, -i212);
                if (zQ) {
                    g gVar10 = (g) this.k0.getLayoutParams();
                    int measuredWidth5 = this.k0.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.k0.getMeasuredHeight() + paddingTop;
                    this.k0.layout(iMax, paddingTop, measuredWidth5, measuredHeight5);
                    i11 = measuredWidth5 + this.z0;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) gVar10).bottomMargin;
                } else {
                    i11 = iMax;
                }
                if (zQ2) {
                    int i213 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                    int measuredWidth6 = this.l0.getMeasuredWidth() + iMax;
                    this.l0.layout(iMax, i213, measuredWidth6, this.l0.getMeasuredHeight() + i213);
                    i12 = measuredWidth6 + this.z0;
                } else {
                    i12 = iMax;
                }
                if (z2) {
                    iMax = Math.max(i11, i12);
                }
            }
        } else {
            if (zQ) {
                textView = this.k0;
            } else {
                textView = this.l0;
            }
            if (zQ2) {
                textView2 = this.l0;
            } else {
                textView2 = this.k0;
            }
            gVar = (g) textView.getLayoutParams();
            gVar2 = (g) textView2.getLayoutParams();
            i6 = measuredHeight;
            if (zQ) {
            }
            i7 = this.F0 & 112;
            i8 = iMax;
            if (i7 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin + this.A0;
            } else if (i7 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i6) / 2;
                i16 = ((ViewGroup.MarginLayoutParams) gVar).topMargin;
                i17 = this.A0;
                if (iMax2 < i16 + i17) {
                    iMax2 = i16 + i17;
                } else {
                    i18 = (((height - paddingBottom) - i6) - iMax2) - paddingTop2;
                    i19 = ((ViewGroup.MarginLayoutParams) gVar).bottomMargin;
                    i20 = this.B0;
                    if (i18 < i19 + i20) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) gVar2).bottomMargin + i20) - i18));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) gVar2).bottomMargin) - this.B0) - i6;
            }
            if (z3) {
                if (z2) {
                    i13 = this.y0;
                } else {
                    i13 = 0;
                }
                int i214 = i13 - iArr[1];
                iMin -= Math.max(0, i214);
                iArr[1] = Math.max(0, -i214);
                if (zQ) {
                    g gVar11 = (g) this.k0.getLayoutParams();
                    int measuredWidth7 = iMin - this.k0.getMeasuredWidth();
                    int measuredHeight6 = this.k0.getMeasuredHeight() + paddingTop;
                    this.k0.layout(measuredWidth7, paddingTop, iMin, measuredHeight6);
                    i14 = measuredWidth7 - this.z0;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) gVar11).bottomMargin;
                } else {
                    i14 = iMin;
                }
                if (zQ2) {
                    int i215 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                    this.l0.layout(iMin - this.l0.getMeasuredWidth(), i215, iMin, this.l0.getMeasuredHeight() + i215);
                    i15 = iMin - this.z0;
                } else {
                    i15 = iMin;
                }
                if (z2) {
                    iMin = Math.min(i14, i15);
                }
                iMax = i8;
                i10 = 0;
            } else {
                if (z2) {
                    i9 = this.y0;
                } else {
                    i9 = 0;
                }
                i10 = 0;
                int i216 = i9 - iArr[0];
                iMax = i8 + Math.max(0, i216);
                iArr[0] = Math.max(0, -i216);
                if (zQ) {
                    g gVar12 = (g) this.k0.getLayoutParams();
                    int measuredWidth8 = this.k0.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.k0.getMeasuredHeight() + paddingTop;
                    this.k0.layout(iMax, paddingTop, measuredWidth8, measuredHeight7);
                    i11 = measuredWidth8 + this.z0;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) gVar12).bottomMargin;
                } else {
                    i11 = iMax;
                }
                if (zQ2) {
                    int i217 = paddingTop + ((ViewGroup.MarginLayoutParams) ((g) this.l0.getLayoutParams())).topMargin;
                    int measuredWidth9 = this.l0.getMeasuredWidth() + iMax;
                    this.l0.layout(iMax, i217, measuredWidth9, this.l0.getMeasuredHeight() + i217);
                    i12 = measuredWidth9 + this.z0;
                } else {
                    i12 = iMax;
                }
                if (z2) {
                    iMax = Math.max(i11, i12);
                }
            }
        }
        b(this.M0, 3);
        size = this.M0.size();
        iC2 = iMax;
        while (i21 < size) {
            iC2 = C(this.M0.get(i21), iC2, iArr, iMin2);
        }
        b(this.M0, 5);
        size2 = this.M0.size();
        while (i22 < size2) {
            iMin = D(this.M0.get(i22), iMin, iArr, iMin2);
        }
        b(this.M0, 1);
        int iU2 = u(this.M0, iArr);
        i23 = (paddingLeft + (((width - paddingLeft) - paddingRight) / 2)) - (iU2 / 2);
        i24 = iU2 + i23;
        if (i23 >= iC2) {
            if (i24 > iMin) {
                iC2 = i23 - (i24 - iMin);
            } else {
                iC2 = i23;
            }
        }
        size3 = this.M0.size();
        while (i10 < size3) {
            iC2 = C(this.M0.get(i10), iC2, iArr, iMin2);
            i10++;
        }
        this.M0.clear();
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int measuredWidth;
        int iMax;
        int iCombineMeasuredStates;
        int measuredWidth2;
        int[] iArr;
        int iCombineMeasuredStates2;
        int iMax2;
        int measuredHeight;
        int[] iArr2 = this.O0;
        boolean zB = O.b(this);
        int i4 = !zB ? 1 : 0;
        if (Q(this.m0)) {
            F(this.m0, i2, 0, i3, 0, this.x0);
            measuredWidth = this.m0.getMeasuredWidth() + s(this.m0);
            iMax = Math.max(0, this.m0.getMeasuredHeight() + t(this.m0));
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.m0.getMeasuredState());
        } else {
            measuredWidth = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (Q(this.q0)) {
            F(this.q0, i2, 0, i3, 0, this.x0);
            measuredWidth = this.q0.getMeasuredWidth() + s(this.q0);
            iMax = Math.max(iMax, this.q0.getMeasuredHeight() + t(this.q0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.q0.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, measuredWidth);
        iArr2[zB ? 1 : 0] = Math.max(0, currentContentInsetStart - measuredWidth);
        if (Q(this.q)) {
            F(this.q, i2, iMax3, i3, 0, this.x0);
            measuredWidth2 = this.q.getMeasuredWidth() + s(this.q);
            iMax = Math.max(iMax, this.q.getMeasuredHeight() + t(this.q));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.q.getMeasuredState());
        } else {
            measuredWidth2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax4 = iMax3 + Math.max(currentContentInsetEnd, measuredWidth2);
        iArr2[i4] = Math.max(0, currentContentInsetEnd - measuredWidth2);
        if (Q(this.r0)) {
            iArr = iArr2;
            iMax4 += E(this.r0, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.r0.getMeasuredHeight() + t(this.r0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.r0.getMeasuredState());
        } else {
            iArr = iArr2;
        }
        if (Q(this.n0)) {
            iMax4 += E(this.n0, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.n0.getMeasuredHeight() + t(this.n0));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.n0.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (((g) childAt.getLayoutParams()).b == 0 && Q(childAt)) {
                iMax4 += E(childAt, i2, iMax4, i3, 0, iArr);
                int iMax5 = Math.max(iMax, childAt.getMeasuredHeight() + t(childAt));
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax5;
            } else {
                iMax4 = iMax4;
            }
        }
        int i6 = iMax4;
        int i7 = this.A0 + this.B0;
        int i8 = this.y0 + this.z0;
        if (Q(this.k0)) {
            E(this.k0, i2, i6 + i8, i3, i7, iArr);
            int measuredWidth3 = this.k0.getMeasuredWidth() + s(this.k0);
            int measuredHeight2 = this.k0.getMeasuredHeight() + t(this.k0);
            iMax2 = measuredWidth3;
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.k0.getMeasuredState());
            measuredHeight = measuredHeight2;
        } else {
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
            measuredHeight = 0;
        }
        if (Q(this.l0)) {
            iMax2 = Math.max(iMax2, E(this.l0, i2, i6 + i8, i3, i7 + measuredHeight, iArr));
            measuredHeight += this.l0.getMeasuredHeight() + t(this.l0);
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.l0.getMeasuredState());
        }
        int iMax6 = Math.max(iMax, measuredHeight);
        setMeasuredDimension(View.resolveSizeAndState(Math.max(i6 + iMax2 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, (-16777216) & iCombineMeasuredStates2), P() ? 0 : View.resolveSizeAndState(Math.max(iMax6 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i iVar = (i) parcelable;
        super.onRestoreInstanceState(iVar.a());
        ActionMenuView actionMenuView = this.q;
        androidx.appcompat.view.menu.e eVarN = actionMenuView != null ? actionMenuView.N() : null;
        int i2 = iVar.Y;
        if (i2 != 0 && this.V0 != null && eVarN != null && (menuItemFindItem = eVarN.findItem(i2)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (iVar.Z) {
            H();
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        h();
        this.C0.f(i2 == 1);
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.g gVar;
        i iVar = new i(super.onSaveInstanceState());
        f fVar = this.V0;
        if (fVar != null && (gVar = fVar.X) != null) {
            iVar.Y = gVar.getItemId();
        }
        iVar.Z = B();
        return iVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.K0 = false;
        }
        if (!this.K0) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.K0 = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.K0 = false;
        }
        return true;
    }

    @Override // ax.p035c0.InterfaceC1875w
    public void removeMenuProvider(ax.p035c0.B b2) {
        this.P0.j(b2);
    }

    public void setBackInvokedCallbackEnabled(boolean z) {
        if (this.b1 != z) {
            this.b1 = z;
            S();
        }
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.q0;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(ax.p226o.a.b(getContext(), i2));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            this.q0.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.q0;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.o0);
            }
        }
    }

    public void setCollapsible(boolean z) {
        this.Y0 = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.E0) {
            this.E0 = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.D0) {
            this.D0 = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(ax.p226o.a.b(getContext(), i2));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!z(this.n0)) {
                c(this.n0, true);
            }
        } else {
            ImageView imageView = this.n0;
            if (imageView != null && z(imageView)) {
                removeView(this.n0);
                this.N0.remove(this.n0);
            }
        }
        ImageView imageView2 = this.n0;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageView imageView = this.n0;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            l();
        }
        ImageButton imageButton = this.m0;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            ax.p322u.B.a(this.m0, charSequence);
        }
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(ax.p226o.a.b(getContext(), i2));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            l();
            if (!z(this.m0)) {
                c(this.m0, true);
            }
        } else {
            ImageButton imageButton = this.m0;
            if (imageButton != null && z(imageButton)) {
                removeView(this.m0);
                this.N0.remove(this.m0);
            }
        }
        ImageButton imageButton2 = this.m0;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        l();
        this.m0.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(h hVar) {
        this.R0 = hVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        j();
        this.q.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.t0 != i2) {
            this.t0 = i2;
            if (i2 == 0) {
                this.s0 = getContext();
            } else {
                this.s0 = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.l0;
            if (textView != null && z(textView)) {
                removeView(this.l0);
                this.N0.remove(this.l0);
            }
        } else {
            if (this.l0 == null) {
                Context context = getContext();
                x xVar = new x(context);
                this.l0 = xVar;
                xVar.setSingleLine();
                this.l0.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.v0;
                if (i2 != 0) {
                    this.l0.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.J0;
                if (colorStateList != null) {
                    this.l0.setTextColor(colorStateList);
                }
            }
            if (!z(this.l0)) {
                c(this.l0, true);
            }
        }
        TextView textView2 = this.l0;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.H0 = charSequence;
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.J0 = colorStateList;
        TextView textView = this.l0;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.k0;
            if (textView != null && z(textView)) {
                removeView(this.k0);
                this.N0.remove(this.k0);
            }
        } else {
            if (this.k0 == null) {
                Context context = getContext();
                x xVar = new x(context);
                this.k0 = xVar;
                xVar.setSingleLine();
                this.k0.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.u0;
                if (i2 != 0) {
                    this.k0.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.I0;
                if (colorStateList != null) {
                    this.k0.setTextColor(colorStateList);
                }
            }
            if (!z(this.k0)) {
                c(this.k0, true);
            }
        }
        TextView textView2 = this.k0;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.G0 = charSequence;
    }

    public void setTitleMarginBottom(int i2) {
        this.B0 = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.z0 = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.y0 = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.A0 = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.I0 = colorStateList;
        TextView textView = this.k0;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public boolean v() {
        f fVar = this.V0;
        return (fVar == null || fVar.X == null) ? false : true;
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.q;
        return actionMenuView != null && actionMenuView.H();
    }

    public void x(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public void y() {
        ArrayList<MenuItem> arrayList = this.Q0;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            MenuItem menuItem = arrayList.get(i2);
            i2++;
            getMenu().removeItem(menuItem.getItemId());
        }
        G();
    }
}
