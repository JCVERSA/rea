package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import ax.p015b0.AbstractC5209b;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.appcompat.widget.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
class C0550c extends androidx.appcompat.view.menu.a implements AbstractC5209b.a {
    private final SparseBooleanArray A0;
    e B0;
    a C0;
    RunnableC0010c D0;
    private b E0;
    final f F0;
    int G0;
    d n0;
    private Drawable o0;
    private boolean p0;
    private boolean q0;
    private boolean r0;
    private int s0;
    private int t0;
    private int u0;
    private boolean v0;
    private boolean w0;
    private boolean x0;
    private boolean y0;
    private int z0;

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$a */
    private class a extends androidx.appcompat.view.menu.i {
        public a(Context context, androidx.appcompat.view.menu.m mVar, View view) {
            super(context, mVar, view, false, ax.p168m.a.l);
            if (!((androidx.appcompat.view.menu.g) mVar.getItem()).l()) {
                View view2 = C0550c.this.n0;
                f(view2 == null ? (View) ((androidx.appcompat.view.menu.a) C0550c.this).l0 : view2);
            }
            j(C0550c.this.F0);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            C0550c c0550c = C0550c.this;
            c0550c.C0 = null;
            c0550c.G0 = 0;
            super.e();
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$b */
    private class b extends ActionMenuItemView.b {
        b() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.b
        public ax.p266t.e a() {
            a aVar = C0550c.this.C0;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$c, reason: collision with other inner class name */
    private class RunnableC0010c implements Runnable {
        private e q;

        public RunnableC0010c(e eVar) {
            this.q = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((androidx.appcompat.view.menu.a) C0550c.this).Y != null) {
                ((androidx.appcompat.view.menu.a) C0550c.this).Y.d();
            }
            View view = (View) ((androidx.appcompat.view.menu.a) C0550c.this).l0;
            if (view != null && view.getWindowToken() != null && this.q.n()) {
                C0550c.this.B0 = this.q;
            }
            C0550c.this.D0 = null;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$d */
    private class d extends AppCompatImageView implements ActionMenuView.a {

        /* JADX INFO: renamed from: androidx.appcompat.widget.c$d$a */
        class a extends ax.p280u.s {
            final /* synthetic */ C0550c m0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(View view, C0550c c0550c) {
                super(view);
                this.m0 = c0550c;
            }

            @Override // ax.p280u.s
            public ax.p266t.e b() {
                e eVar = C0550c.this.B0;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            @Override // ax.p280u.s
            public boolean c() {
                C0550c.this.K();
                return true;
            }

            @Override // ax.p280u.s
            public boolean d() {
                C0550c c0550c = C0550c.this;
                if (c0550c.D0 != null) {
                    return false;
                }
                c0550c.B();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, ax.p168m.a.k);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            ax.p280u.B.a(this, getContentDescription());
            setOnTouchListener(new a(this, C0550c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0550c.this.K();
            return true;
        }

        @Override // android.widget.ImageView
        protected boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int iMax = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                ax.T.a.l(background, paddingLeft - iMax, paddingTop - iMax, paddingLeft + iMax, paddingTop + iMax);
            }
            return frame;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$e */
    private class e extends androidx.appcompat.view.menu.i {
        public e(Context context, androidx.appcompat.view.menu.e eVar, View view, boolean z) {
            super(context, eVar, view, z, ax.p168m.a.l);
            h(8388613);
            j(C0550c.this.F0);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            if (((androidx.appcompat.view.menu.a) C0550c.this).Y != null) {
                ((androidx.appcompat.view.menu.a) C0550c.this).Y.close();
            }
            C0550c.this.B0 = null;
            super.e();
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.c$f */
    private class f implements androidx.appcompat.view.menu.j.a {
        f() {
        }

        @Override // androidx.appcompat.view.menu.j.a
        public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
            if (eVar instanceof androidx.appcompat.view.menu.m) {
                eVar.D().e(false);
            }
            androidx.appcompat.view.menu.j.a aVarM = C0550c.this.m();
            if (aVarM != null) {
                aVarM.a(eVar, z);
            }
        }

        @Override // androidx.appcompat.view.menu.j.a
        public boolean b(androidx.appcompat.view.menu.e eVar) {
            if (eVar == ((androidx.appcompat.view.menu.a) C0550c.this).Y) {
                return false;
            }
            C0550c.this.G0 = ((androidx.appcompat.view.menu.m) eVar).getItem().getItemId();
            androidx.appcompat.view.menu.j.a aVarM = C0550c.this.m();
            if (aVarM != null) {
                return aVarM.b(eVar);
            }
            return false;
        }
    }

    public C0550c(Context context) {
        super(context, ax.p168m.g.c, ax.p168m.g.b);
        this.A0 = new SparseBooleanArray();
        this.F0 = new f();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View z(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.l0;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if ((childAt instanceof androidx.appcompat.view.menu.k.a) && ((androidx.appcompat.view.menu.k.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public Drawable A() {
        d dVar = this.n0;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.p0) {
            return this.o0;
        }
        return null;
    }

    public boolean B() {
        Object obj;
        RunnableC0010c runnableC0010c = this.D0;
        if (runnableC0010c != null && (obj = this.l0) != null) {
            ((View) obj).removeCallbacks(runnableC0010c);
            this.D0 = null;
            return true;
        }
        e eVar = this.B0;
        if (eVar == null) {
            return false;
        }
        eVar.b();
        return true;
    }

    public boolean C() {
        a aVar = this.C0;
        if (aVar == null) {
            return false;
        }
        aVar.b();
        return true;
    }

    public boolean D() {
        return this.D0 != null || E();
    }

    public boolean E() {
        e eVar = this.B0;
        return eVar != null && eVar.d();
    }

    public void F(Configuration configuration) {
        if (!this.v0) {
            this.u0 = ax.p252s.a.b(this.X).d();
        }
        androidx.appcompat.view.menu.e eVar = this.Y;
        if (eVar != null) {
            eVar.L(true);
        }
    }

    public void G(boolean z) {
        this.y0 = z;
    }

    public void H(ActionMenuView actionMenuView) {
        this.l0 = actionMenuView;
        actionMenuView.b(this.Y);
    }

    public void I(Drawable drawable) {
        d dVar = this.n0;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
        } else {
            this.p0 = true;
            this.o0 = drawable;
        }
    }

    public void J(boolean z) {
        this.q0 = z;
        this.r0 = true;
    }

    public boolean K() {
        androidx.appcompat.view.menu.e eVar;
        if (!this.q0 || E() || (eVar = this.Y) == null || this.l0 == null || this.D0 != null || eVar.z().isEmpty()) {
            return false;
        }
        RunnableC0010c runnableC0010c = new RunnableC0010c(new e(this.X, this.Y, this.n0, true));
        this.D0 = runnableC0010c;
        ((View) this.l0).post(runnableC0010c);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void a(androidx.appcompat.view.menu.e eVar, boolean z) {
        y();
        super.a(eVar, z);
    }

    @Override // androidx.appcompat.view.menu.a
    public void c(androidx.appcompat.view.menu.g gVar, androidx.appcompat.view.menu.k.a aVar) {
        aVar.f(gVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.l0);
        if (this.E0 == null) {
            this.E0 = new b();
        }
        actionMenuItemView.setPopupCallback(this.E0);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void d(boolean z) {
        super.d(z);
        ((View) this.l0).requestLayout();
        androidx.appcompat.view.menu.e eVar = this.Y;
        boolean z2 = false;
        if (eVar != null) {
            ArrayList<androidx.appcompat.view.menu.g> arrayListS = eVar.s();
            int size = arrayListS.size();
            for (int i = 0; i < size; i++) {
                AbstractC5209b abstractC5209bB = arrayListS.get(i).b();
                if (abstractC5209bB != null) {
                    abstractC5209bB.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.e eVar2 = this.Y;
        ArrayList<androidx.appcompat.view.menu.g> arrayListZ = eVar2 != null ? eVar2.z() : null;
        if (this.q0 && arrayListZ != null) {
            int size2 = arrayListZ.size();
            if (size2 == 1) {
                z2 = !arrayListZ.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.n0 == null) {
                this.n0 = new d(this.q);
            }
            ViewGroup viewGroup = (ViewGroup) this.n0.getParent();
            if (viewGroup != this.l0) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.n0);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.l0;
                actionMenuView.addView(this.n0, actionMenuView.F());
            }
        } else {
            d dVar = this.n0;
            if (dVar != null) {
                Object parent = dVar.getParent();
                Object obj = this.l0;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.n0);
                }
            }
        }
        ((ActionMenuView) this.l0).setOverflowReserved(this.q0);
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        ArrayList<androidx.appcompat.view.menu.g> arrayListE;
        int size;
        int i;
        int iL;
        C0550c c0550c = this;
        androidx.appcompat.view.menu.e eVar = c0550c.Y;
        View view = null;
        int i2 = 0;
        if (eVar != null) {
            arrayListE = eVar.E();
            size = arrayListE.size();
        } else {
            arrayListE = null;
            size = 0;
        }
        int i3 = c0550c.u0;
        int i4 = c0550c.t0;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) c0550c.l0;
        boolean z = false;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < size; i7++) {
            androidx.appcompat.view.menu.g gVar = arrayListE.get(i7);
            if (gVar.o()) {
                i5++;
            } else if (gVar.n()) {
                i6++;
            } else {
                z = true;
            }
            if (c0550c.y0 && gVar.isActionViewExpanded()) {
                i3 = 0;
            }
        }
        if (c0550c.q0 && (z || i6 + i5 > i3)) {
            i3--;
        }
        int i8 = i3 - i5;
        SparseBooleanArray sparseBooleanArray = c0550c.A0;
        sparseBooleanArray.clear();
        if (c0550c.w0) {
            int i9 = c0550c.z0;
            iL = i4 / i9;
            i = i9 + ((i4 % i9) / iL);
        } else {
            i = 0;
            iL = 0;
        }
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            androidx.appcompat.view.menu.g gVar2 = arrayListE.get(i10);
            if (gVar2.o()) {
                View viewN = c0550c.n(gVar2, view, viewGroup);
                if (c0550c.w0) {
                    iL -= ActionMenuView.L(viewN, i, iL, iMakeMeasureSpec, i2);
                } else {
                    viewN.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                }
                int measuredWidth = viewN.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                int groupId = gVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                gVar2.u(true);
            } else {
                if (gVar2.n()) {
                    int groupId2 = gVar2.getGroupId();
                    boolean z2 = sparseBooleanArray.get(groupId2);
                    boolean z3 = (i8 > 0 || z2) && i4 > 0 && (!c0550c.w0 || iL > 0);
                    boolean z4 = z3;
                    if (z3) {
                        View viewN2 = c0550c.n(gVar2, null, viewGroup);
                        if (c0550c.w0) {
                            int iL2 = ActionMenuView.L(viewN2, i, iL, iMakeMeasureSpec, 0);
                            iL -= iL2;
                            if (iL2 == 0) {
                                z4 = false;
                            }
                        } else {
                            viewN2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                        }
                        boolean z5 = z4;
                        int measuredWidth2 = viewN2.getMeasuredWidth();
                        i4 -= measuredWidth2;
                        if (i11 == 0) {
                            i11 = measuredWidth2;
                        }
                        z3 = z5 & (!c0550c.w0 ? i4 + i11 <= 0 : i4 < 0);
                    }
                    if (z3 && groupId2 != 0) {
                        sparseBooleanArray.put(groupId2, true);
                    } else if (z2) {
                        sparseBooleanArray.put(groupId2, false);
                        for (int i12 = 0; i12 < i10; i12++) {
                            androidx.appcompat.view.menu.g gVar3 = arrayListE.get(i12);
                            if (gVar3.getGroupId() == groupId2) {
                                if (gVar3.l()) {
                                    i8++;
                                }
                                gVar3.u(false);
                            }
                        }
                    }
                    if (z3) {
                        i8--;
                    }
                    gVar2.u(z3);
                } else {
                    size = size;
                    gVar2.u(false);
                }
                i10++;
                view = null;
                c0550c = this;
                size = size;
                i2 = 0;
            }
            i10++;
            view = null;
            c0550c = this;
            size = size;
            i2 = 0;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void i(Context context, androidx.appcompat.view.menu.e eVar) {
        super.i(context, eVar);
        Resources resources = context.getResources();
        ax.p252s.a aVarB = ax.p252s.a.b(context);
        if (!this.r0) {
            this.q0 = aVarB.h();
        }
        if (!this.x0) {
            this.s0 = aVarB.c();
        }
        if (!this.v0) {
            this.u0 = aVarB.d();
        }
        int measuredWidth = this.s0;
        if (this.q0) {
            if (this.n0 == null) {
                d dVar = new d(this.q);
                this.n0 = dVar;
                if (this.p0) {
                    dVar.setImageDrawable(this.o0);
                    this.o0 = null;
                    this.p0 = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.n0.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.n0.getMeasuredWidth();
        } else {
            this.n0 = null;
        }
        this.t0 = measuredWidth;
        this.z0 = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public boolean k(androidx.appcompat.view.menu.m mVar) {
        boolean z = false;
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        androidx.appcompat.view.menu.m mVar2 = mVar;
        while (mVar2.g0() != this.Y) {
            mVar2 = (androidx.appcompat.view.menu.m) mVar2.g0();
        }
        View viewZ = z(mVar2.getItem());
        if (viewZ == null) {
            return false;
        }
        this.G0 = mVar.getItem().getItemId();
        int size = mVar.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = mVar.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
        }
        a aVar = new a(this.X, mVar, viewZ);
        this.C0 = aVar;
        aVar.g(z);
        this.C0.k();
        super.k(mVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean l(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.n0) {
            return false;
        }
        return super.l(viewGroup, i);
    }

    @Override // androidx.appcompat.view.menu.a
    public View n(androidx.appcompat.view.menu.g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.j()) {
            actionView = super.n(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.a
    public androidx.appcompat.view.menu.k o(ViewGroup viewGroup) {
        androidx.appcompat.view.menu.k kVar = this.l0;
        androidx.appcompat.view.menu.k kVarO = super.o(viewGroup);
        if (kVar != kVarO) {
            ((ActionMenuView) kVarO).setPresenter(this);
        }
        return kVarO;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean q(int i, androidx.appcompat.view.menu.g gVar) {
        return gVar.l();
    }

    public boolean y() {
        return B() | C();
    }
}
