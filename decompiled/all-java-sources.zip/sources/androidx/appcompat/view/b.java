package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import ax.p290s.d;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class b extends a implements e.a {
    private Context Y;
    private ActionBarContextView Z;
    private a.InterfaceC0009a k0;
    private WeakReference<View> l0;
    private boolean m0;
    private boolean n0;
    private e o0;

    public b(Context context, ActionBarContextView actionBarContextView, a.InterfaceC0009a interfaceC0009a, boolean z) {
        this.Y = context;
        this.Z = actionBarContextView;
        this.k0 = interfaceC0009a;
        e eVarT = new e(actionBarContextView.getContext()).T(1);
        this.o0 = eVarT;
        eVarT.S(this);
        this.n0 = z;
    }

    @Override // androidx.appcompat.view.menu.e.a
    public boolean a(e eVar, MenuItem menuItem) {
        return this.k0.d(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.e.a
    public void b(e eVar) {
        k();
        this.Z.l();
    }

    @Override // androidx.appcompat.view.a
    public void c() {
        if (this.m0) {
            return;
        }
        this.m0 = true;
        this.k0.a(this);
    }

    @Override // androidx.appcompat.view.a
    public View d() {
        WeakReference<View> weakReference = this.l0;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // androidx.appcompat.view.a
    public Menu e() {
        return this.o0;
    }

    @Override // androidx.appcompat.view.a
    public MenuInflater f() {
        return new d(this.Z.getContext());
    }

    @Override // androidx.appcompat.view.a
    public CharSequence g() {
        return this.Z.getSubtitle();
    }

    @Override // androidx.appcompat.view.a
    public CharSequence i() {
        return this.Z.getTitle();
    }

    @Override // androidx.appcompat.view.a
    public void k() {
        this.k0.c(this, this.o0);
    }

    @Override // androidx.appcompat.view.a
    public boolean l() {
        return this.Z.j();
    }

    @Override // androidx.appcompat.view.a
    public void m(View view) {
        this.Z.setCustomView(view);
        this.l0 = view != null ? new WeakReference<>(view) : null;
    }

    @Override // androidx.appcompat.view.a
    public void n(int i) {
        o(this.Y.getString(i));
    }

    @Override // androidx.appcompat.view.a
    public void o(CharSequence charSequence) {
        this.Z.setSubtitle(charSequence);
    }

    @Override // androidx.appcompat.view.a
    public void q(int i) {
        r(this.Y.getString(i));
    }

    @Override // androidx.appcompat.view.a
    public void r(CharSequence charSequence) {
        this.Z.setTitle(charSequence);
    }

    @Override // androidx.appcompat.view.a
    public void s(boolean z) {
        super.s(z);
        this.Z.setTitleOptional(z);
    }
}
