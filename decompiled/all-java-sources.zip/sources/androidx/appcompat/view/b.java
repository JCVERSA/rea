package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import ax.p252s.d;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class b extends a implements e.a {
    private Context Y;
    private ActionBarContextView Z;
    private a.InterfaceC0007a h0;
    private WeakReference<View> i0;
    private boolean j0;
    private boolean k0;
    private e l0;

    public b(Context context, ActionBarContextView actionBarContextView, a.InterfaceC0007a interfaceC0007a, boolean z) {
        this.Y = context;
        this.Z = actionBarContextView;
        this.h0 = interfaceC0007a;
        e eVarT = new e(actionBarContextView.getContext()).T(1);
        this.l0 = eVarT;
        eVarT.S(this);
        this.k0 = z;
    }

    @Override // androidx.appcompat.view.menu.e.a
    public boolean a(e eVar, MenuItem menuItem) {
        return this.h0.d(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.e.a
    public void b(e eVar) {
        k();
        this.Z.l();
    }

    @Override // androidx.appcompat.view.a
    public void c() {
        if (this.j0) {
            return;
        }
        this.j0 = true;
        this.h0.a(this);
    }

    @Override // androidx.appcompat.view.a
    public View d() {
        WeakReference<View> weakReference = this.i0;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // androidx.appcompat.view.a
    public Menu e() {
        return this.l0;
    }

    @Override // androidx.appcompat.view.a
    public MenuInflater f() {
        return new d(this.Z.getContext());
    }

    @Override // androidx.appcompat.view.a
    public CharSequence g() {
        return this.Z.getSubtitle();
    }

    @Override // androidx.appcompat.view.a
    public CharSequence i() {
        return this.Z.getTitle();
    }

    @Override // androidx.appcompat.view.a
    public void k() {
        this.h0.c(this, this.l0);
    }

    @Override // androidx.appcompat.view.a
    public boolean l() {
        return this.Z.j();
    }

    @Override // androidx.appcompat.view.a
    public void m(View view) {
        this.Z.setCustomView(view);
        this.i0 = view != null ? new WeakReference<>(view) : null;
    }

    @Override // androidx.appcompat.view.a
    public void n(int i) {
        o(this.Y.getString(i));
    }

    @Override // androidx.appcompat.view.a
    public void o(CharSequence charSequence) {
        this.Z.setSubtitle(charSequence);
    }

    @Override // androidx.appcompat.view.a
    public void q(int i) {
        r(this.Y.getString(i));
    }

    @Override // androidx.appcompat.view.a
    public void r(CharSequence charSequence) {
        this.Z.setTitle(charSequence);
    }

    @Override // androidx.appcompat.view.a
    public void s(boolean z) {
        super.s(z);
        this.Z.setTitleOptional(z);
    }
}
