package androidx.appcompat.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    private boolean X;
    private Object q;

    /* JADX INFO: renamed from: androidx.appcompat.view.a$a, reason: collision with other inner class name */
    public interface InterfaceC0009a {
        void a(a aVar);

        boolean b(a aVar, Menu menu);

        boolean c(a aVar, Menu menu);

        boolean d(a aVar, MenuItem menuItem);
    }

    public abstract void c();

    public abstract View d();

    public abstract Menu e();

    public abstract MenuInflater f();

    public abstract CharSequence g();

    public Object h() {
        return this.q;
    }

    public abstract CharSequence i();

    public boolean j() {
        return this.X;
    }

    public abstract void k();

    public abstract boolean l();

    public abstract void m(View view);

    public abstract void n(int i);

    public abstract void o(CharSequence charSequence);

    public void p(Object obj) {
        this.q = obj;
    }

    public abstract void q(int i);

    public abstract void r(CharSequence charSequence);

    public void s(boolean z) {
        this.X = z;
    }
}
