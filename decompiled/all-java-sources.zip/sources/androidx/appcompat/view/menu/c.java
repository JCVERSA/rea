package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class c implements j, AdapterView.OnItemClickListener {
    LayoutInflater X;
    e Y;
    ExpandedMenuView Z;
    int h0;
    int i0;
    int j0;
    private j.a k0;
    a l0;
    Context q;

    private class a extends BaseAdapter {
        private int q = -1;

        public a() {
            a();
        }

        void a() {
            g gVarV = c.this.Y.v();
            if (gVarV != null) {
                ArrayList<g> arrayListZ = c.this.Y.z();
                int size = arrayListZ.size();
                for (int i = 0; i < size; i++) {
                    if (arrayListZ.get(i) == gVarV) {
                        this.q = i;
                        return;
                    }
                }
            }
            this.q = -1;
        }

        @Override // android.widget.Adapter
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public g getItem(int i) {
            ArrayList<g> arrayListZ = c.this.Y.z();
            int i2 = i + c.this.h0;
            int i3 = this.q;
            if (i3 >= 0 && i2 >= i3) {
                i2++;
            }
            return arrayListZ.get(i2);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            int size = c.this.Y.z().size() - c.this.h0;
            return this.q < 0 ? size : size - 1;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                c cVar = c.this;
                view = cVar.X.inflate(cVar.j0, viewGroup, false);
            }
            ((k.a) view).f(getItem(i), 0);
            return view;
        }

        @Override // android.widget.BaseAdapter
        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public c(Context context, int i) {
        this(i, 0);
        this.q = context;
        this.X = LayoutInflater.from(context);
    }

    @Override // androidx.appcompat.view.menu.j
    public void a(e eVar, boolean z) {
        j.a aVar = this.k0;
        if (aVar != null) {
            aVar.a(eVar, z);
        }
    }

    public ListAdapter b() {
        if (this.l0 == null) {
            this.l0 = new a();
        }
        return this.l0;
    }

    public k c(ViewGroup viewGroup) {
        if (this.Z == null) {
            this.Z = (ExpandedMenuView) this.X.inflate(ax.p168m.g.g, viewGroup, false);
            if (this.l0 == null) {
                this.l0 = new a();
            }
            this.Z.setAdapter((ListAdapter) this.l0);
            this.Z.setOnItemClickListener(this);
        }
        return this.Z;
    }

    @Override // androidx.appcompat.view.menu.j
    public void d(boolean z) {
        a aVar = this.l0;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean f(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean g(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.k0 = aVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public void i(Context context, e eVar) {
        if (this.i0 != 0) {
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, this.i0);
            this.q = contextThemeWrapper;
            this.X = LayoutInflater.from(contextThemeWrapper);
        } else if (this.q != null) {
            this.q = context;
            if (this.X == null) {
                this.X = LayoutInflater.from(context);
            }
        }
        this.Y = eVar;
        a aVar = this.l0;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean k(m mVar) {
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        new f(mVar).d(null);
        j.a aVar = this.k0;
        if (aVar == null) {
            return true;
        }
        aVar.b(mVar);
        return true;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.Y.N(this.l0.getItem(i), this, 0);
    }

    public c(int i, int i2) {
        this.j0 = i;
        this.i0 = i2;
    }
}
