package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.L;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {
    private ImageView h0;
    private RadioButton i0;
    private TextView j0;
    private CheckBox k0;
    private TextView l0;
    private ImageView m0;
    private ImageView n0;
    private LinearLayout o0;
    private Drawable p0;
    private g q;
    private int q0;
    private Context r0;
    private boolean s0;
    private Drawable t0;
    private boolean u0;
    private LayoutInflater v0;
    private boolean w0;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p168m.a.F);
    }

    private void a(View view) {
        b(view, -1);
    }

    private void b(View view, int i) {
        LinearLayout linearLayout = this.o0;
        if (linearLayout != null) {
            linearLayout.addView(view, i);
        } else {
            addView(view, i);
        }
    }

    private void c() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(ax.p168m.g.h, (ViewGroup) this, false);
        this.k0 = checkBox;
        a(checkBox);
    }

    private void e() {
        ImageView imageView = (ImageView) getInflater().inflate(ax.p168m.g.i, (ViewGroup) this, false);
        this.h0 = imageView;
        b(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(ax.p168m.g.k, (ViewGroup) this, false);
        this.i0 = radioButton;
        a(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.v0 == null) {
            this.v0 = LayoutInflater.from(getContext());
        }
        return this.v0;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.m0;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.n0;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.n0.getLayoutParams();
        rect.top += this.n0.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public void f(g gVar, int i) {
        this.q = gVar;
        setVisibility(gVar.isVisible() ? 0 : 8);
        setTitle(gVar.i(this));
        setCheckable(gVar.isCheckable());
        h(gVar.A(), gVar.g());
        setIcon(gVar.getIcon());
        setEnabled(gVar.isEnabled());
        setSubMenuArrowVisible(gVar.hasSubMenu());
        setContentDescription(gVar.getContentDescription());
    }

    @Override // androidx.appcompat.view.menu.k.a
    public g getItemData() {
        return this.q;
    }

    public void h(boolean z, char c) {
        int i = (z && this.q.A()) ? 0 : 8;
        if (i == 0) {
            this.l0.setText(this.q.h());
        }
        if (this.l0.getVisibility() != i) {
            this.l0.setVisibility(i);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.p0);
        TextView textView = (TextView) findViewById(ax.p168m.f.D);
        this.j0 = textView;
        int i = this.q0;
        if (i != -1) {
            textView.setTextAppearance(this.r0, i);
        }
        this.l0 = (TextView) findViewById(ax.p168m.f.x);
        ImageView imageView = (ImageView) findViewById(ax.p168m.f.A);
        this.m0 = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.t0);
        }
        this.n0 = (ImageView) findViewById(ax.p168m.f.r);
        this.o0 = (LinearLayout) findViewById(ax.p168m.f.l);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        if (this.h0 != null && this.s0) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.h0.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        View view;
        if (!z && this.i0 == null && this.k0 == null) {
            return;
        }
        if (this.q.m()) {
            if (this.i0 == null) {
                g();
            }
            compoundButton = this.i0;
            view = this.k0;
        } else {
            if (this.k0 == null) {
                c();
            }
            compoundButton = this.k0;
            view = this.i0;
        }
        if (z) {
            compoundButton.setChecked(this.q.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.k0;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.i0;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.q.m()) {
            if (this.i0 == null) {
                g();
            }
            compoundButton = this.i0;
        } else {
            if (this.k0 == null) {
                c();
            }
            compoundButton = this.k0;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.w0 = z;
        this.s0 = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.n0;
        if (imageView != null) {
            imageView.setVisibility((this.u0 || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.q.z() || this.w0;
        if (z || this.s0) {
            ImageView imageView = this.h0;
            if (imageView == null && drawable == null && !this.s0) {
                return;
            }
            if (imageView == null) {
                e();
            }
            if (drawable == null && !this.s0) {
                this.h0.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.h0;
            if (!z) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.h0.getVisibility() != 0) {
                this.h0.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.j0.getVisibility() != 8) {
                this.j0.setVisibility(8);
            }
        } else {
            this.j0.setText(charSequence);
            if (this.j0.getVisibility() != 0) {
                this.j0.setVisibility(0);
            }
        }
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        L lV = L.v(getContext(), attributeSet, ax.p168m.j.b2, i, 0);
        this.p0 = lV.g(ax.p168m.j.d2);
        this.q0 = lV.n(ax.p168m.j.c2, -1);
        this.s0 = lV.a(ax.p168m.j.e2, false);
        this.r0 = context;
        this.t0 = lV.g(ax.p168m.j.f2);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, ax.p168m.a.B, 0);
        this.u0 = typedArrayObtainStyledAttributes.hasValue(0);
        lV.x();
        typedArrayObtainStyledAttributes.recycle();
    }
}
