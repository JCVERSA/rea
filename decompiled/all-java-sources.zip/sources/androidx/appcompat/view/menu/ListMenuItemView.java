package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.L;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {
    private ImageView k0;
    private RadioButton l0;
    private TextView m0;
    private CheckBox n0;
    private TextView o0;
    private ImageView p0;
    private g q;
    private ImageView q0;
    private LinearLayout r0;
    private Drawable s0;
    private int t0;
    private Context u0;
    private boolean v0;
    private Drawable w0;
    private boolean x0;
    private LayoutInflater y0;
    private boolean z0;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p194m.a.H);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        L lV = L.v(getContext(), attributeSet, ax.p194m.j.b2, i, 0);
        this.s0 = lV.g(ax.p194m.j.d2);
        this.t0 = lV.n(ax.p194m.j.c2, -1);
        this.v0 = lV.a(ax.p194m.j.e2, false);
        this.u0 = context;
        this.w0 = lV.g(ax.p194m.j.f2);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, ax.p194m.a.D, 0);
        this.x0 = typedArrayObtainStyledAttributes.hasValue(0);
        lV.x();
        typedArrayObtainStyledAttributes.recycle();
    }

    private void a(View view) {
        b(view, -1);
    }

    private void b(View view, int i) {
        LinearLayout linearLayout = this.r0;
        if (linearLayout != null) {
            linearLayout.addView(view, i);
        } else {
            addView(view, i);
        }
    }

    private void c() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(ax.p194m.g.h, (ViewGroup) this, false);
        this.n0 = checkBox;
        a(checkBox);
    }

    private void e() {
        ImageView imageView = (ImageView) getInflater().inflate(ax.p194m.g.i, (ViewGroup) this, false);
        this.k0 = imageView;
        b(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(ax.p194m.g.k, (ViewGroup) this, false);
        this.l0 = radioButton;
        a(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.y0 == null) {
            this.y0 = LayoutInflater.from(getContext());
        }
        return this.y0;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.p0;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.q0;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.q0.getLayoutParams();
        rect.top += this.q0.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public void f(g gVar, int i) {
        this.q = gVar;
        setVisibility(gVar.isVisible() ? 0 : 8);
        setTitle(gVar.i(this));
        setCheckable(gVar.isCheckable());
        h(gVar.A(), gVar.g());
        setIcon(gVar.getIcon());
        setEnabled(gVar.isEnabled());
        setSubMenuArrowVisible(gVar.hasSubMenu());
        setContentDescription(gVar.getContentDescription());
    }

    @Override // androidx.appcompat.view.menu.k.a
    public g getItemData() {
        return this.q;
    }

    public void h(boolean z, char c) {
        int i = (z && this.q.A()) ? 0 : 8;
        if (i == 0) {
            this.o0.setText(this.q.h());
        }
        if (this.o0.getVisibility() != i) {
            this.o0.setVisibility(i);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.s0);
        TextView textView = (TextView) findViewById(ax.p194m.f.D);
        this.m0 = textView;
        int i = this.t0;
        if (i != -1) {
            textView.setTextAppearance(this.u0, i);
        }
        this.o0 = (TextView) findViewById(ax.p194m.f.x);
        ImageView imageView = (ImageView) findViewById(ax.p194m.f.A);
        this.p0 = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.w0);
        }
        this.q0 = (ImageView) findViewById(ax.p194m.f.r);
        this.r0 = (LinearLayout) findViewById(ax.p194m.f.l);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        if (this.k0 != null && this.v0) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.k0.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        View view;
        if (!z && this.l0 == null && this.n0 == null) {
            return;
        }
        if (this.q.m()) {
            if (this.l0 == null) {
                g();
            }
            compoundButton = this.l0;
            view = this.n0;
        } else {
            if (this.n0 == null) {
                c();
            }
            compoundButton = this.n0;
            view = this.l0;
        }
        if (z) {
            compoundButton.setChecked(this.q.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.n0;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.l0;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.q.m()) {
            if (this.l0 == null) {
                g();
            }
            compoundButton = this.l0;
        } else {
            if (this.n0 == null) {
                c();
            }
            compoundButton = this.n0;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.z0 = z;
        this.v0 = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.q0;
        if (imageView != null) {
            imageView.setVisibility((this.x0 || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.q.z() || this.z0;
        if (z || this.v0) {
            ImageView imageView = this.k0;
            if (imageView == null && drawable == null && !this.v0) {
                return;
            }
            if (imageView == null) {
                e();
            }
            if (drawable == null && !this.v0) {
                this.k0.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.k0;
            if (!z) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.k0.getVisibility() != 0) {
                this.k0.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.m0.getVisibility() != 8) {
                this.m0.setVisibility(8);
            }
        } else {
            this.m0.setText(charSequence);
            if (this.m0.getVisibility() != 0) {
                this.m0.setVisibility(0);
            }
        }
    }
}
