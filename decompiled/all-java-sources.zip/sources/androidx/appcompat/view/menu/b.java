package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import ax.p035c0.C1869t;
import ax.p322u.u;
import ax.p322u.v;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
final class b extends h implements j, View.OnKeyListener, PopupWindow.OnDismissListener {
    private static final int H0 = ax.p194m.g.e;
    private int A0;
    private boolean C0;
    private j.a D0;
    ViewTreeObserver E0;
    private PopupWindow.OnDismissListener F0;
    boolean G0;
    private final Context X;
    private final int Y;
    private final int Z;
    private final int k0;
    private final boolean l0;
    final Handler m0;
    private View u0;
    View v0;
    private boolean x0;
    private boolean y0;
    private int z0;
    private final List<e> n0 = new ArrayList();
    final List<d> o0 = new ArrayList();
    final ViewTreeObserver.OnGlobalLayoutListener p0 = new a();
    private final View.OnAttachStateChangeListener q0 = new ViewOnAttachStateChangeListenerC0010b();
    private final u r0 = new c();
    private int s0 = 0;
    private int t0 = 0;
    private boolean B0 = false;
    private int w0 = D();

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!b.this.b() || b.this.o0.size() <= 0 || b.this.o0.get(0).a.B()) {
                return;
            }
            View view = b.this.v0;
            if (view == null || !view.isShown()) {
                b.this.dismiss();
                return;
            }
            Iterator<d> it = b.this.o0.iterator();
            while (it.hasNext()) {
                it.next().a.c();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.view.menu.b$b, reason: collision with other inner class name */
    class ViewOnAttachStateChangeListenerC0010b implements View.OnAttachStateChangeListener {
        ViewOnAttachStateChangeListenerC0010b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = b.this.E0;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    b.this.E0 = view.getViewTreeObserver();
                }
                b bVar = b.this;
                bVar.E0.removeGlobalOnLayoutListener(bVar.p0);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    class c implements u {

        class a implements Runnable {
            final /* synthetic */ MenuItem X;
            final /* synthetic */ e Y;
            final /* synthetic */ d q;

            a(d dVar, MenuItem menuItem, e eVar) {
                this.q = dVar;
                this.X = menuItem;
                this.Y = eVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                d dVar = this.q;
                if (dVar != null) {
                    b.this.G0 = true;
                    dVar.b.e(false);
                    b.this.G0 = false;
                }
                if (this.X.isEnabled() && this.X.hasSubMenu()) {
                    this.Y.M(this.X, 4);
                }
            }
        }

        c() {
        }

        @Override // ax.p322u.u
        public void e(e eVar, MenuItem menuItem) {
            b.this.m0.removeCallbacksAndMessages(null);
            int size = b.this.o0.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                } else if (eVar == b.this.o0.get(i).b) {
                    break;
                } else {
                    i++;
                }
            }
            if (i == -1) {
                return;
            }
            int i2 = i + 1;
            b.this.m0.postAtTime(new a(i2 < b.this.o0.size() ? b.this.o0.get(i2) : null, menuItem, eVar), eVar, SystemClock.uptimeMillis() + 200);
        }

        @Override // ax.p322u.u
        public void h(e eVar, MenuItem menuItem) {
            b.this.m0.removeCallbacksAndMessages(eVar);
        }
    }

    private static class d {
        public final v a;
        public final e b;
        public final int c;

        public d(v vVar, e eVar, int i) {
            this.a = vVar;
            this.b = eVar;
            this.c = i;
        }

        public ListView a() {
            return this.a.j();
        }
    }

    public b(Context context, View view, int i, int i2, boolean z) {
        this.X = context;
        this.u0 = view;
        this.Z = i;
        this.k0 = i2;
        this.l0 = z;
        Resources resources = context.getResources();
        this.Y = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(ax.p194m.d.d));
        this.m0 = new Handler();
    }

    private int A(e eVar) {
        int size = this.o0.size();
        for (int i = 0; i < size; i++) {
            if (eVar == this.o0.get(i).b) {
                return i;
            }
        }
        return -1;
    }

    private MenuItem B(e eVar, e eVar2) {
        int size = eVar.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = eVar.getItem(i);
            if (item.hasSubMenu() && eVar2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    private View C(d dVar, e eVar) {
        androidx.appcompat.view.menu.d dVar2;
        int headersCount;
        int firstVisiblePosition;
        MenuItem menuItemB = B(dVar.b, eVar);
        if (menuItemB == null) {
            return null;
        }
        ListView listViewA = dVar.a();
        ListAdapter adapter = listViewA.getAdapter();
        int i = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            headersCount = headerViewListAdapter.getHeadersCount();
            dVar2 = (androidx.appcompat.view.menu.d) headerViewListAdapter.getWrappedAdapter();
        } else {
            dVar2 = (androidx.appcompat.view.menu.d) adapter;
            headersCount = 0;
        }
        int count = dVar2.getCount();
        while (true) {
            if (i >= count) {
                i = -1;
                break;
            }
            if (menuItemB == dVar2.getItem(i)) {
                break;
            }
            i++;
        }
        if (i != -1 && (firstVisiblePosition = (i + headersCount) - listViewA.getFirstVisiblePosition()) >= 0 && firstVisiblePosition < listViewA.getChildCount()) {
            return listViewA.getChildAt(firstVisiblePosition);
        }
        return null;
    }

    private int D() {
        return this.u0.getLayoutDirection() == 1 ? 0 : 1;
    }

    private int E(int i) {
        List<d> list = this.o0;
        ListView listViewA = list.get(list.size() - 1).a();
        int[] iArr = new int[2];
        listViewA.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.v0.getWindowVisibleDisplayFrame(rect);
        if (this.w0 == 1) {
            return (iArr[0] + listViewA.getWidth()) + i > rect.right ? 0 : 1;
        }
        return iArr[0] - i < 0 ? 1 : 0;
    }

    private void F(e eVar) {
        d dVar;
        View viewC;
        int i;
        int i2;
        int i3;
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.X);
        androidx.appcompat.view.menu.d dVar2 = new androidx.appcompat.view.menu.d(eVar, layoutInflaterFrom, this.l0, H0);
        if (!b() && this.B0) {
            dVar2.d(true);
        } else if (b()) {
            dVar2.d(h.x(eVar));
        }
        int iO = h.o(dVar2, null, this.X, this.Y);
        v vVarZ = z();
        vVarZ.p(dVar2);
        vVarZ.F(iO);
        vVarZ.G(this.t0);
        if (this.o0.size() > 0) {
            List<d> list = this.o0;
            dVar = list.get(list.size() - 1);
            viewC = C(dVar, eVar);
        } else {
            dVar = null;
            viewC = null;
        }
        if (viewC != null) {
            vVarZ.V(false);
            vVarZ.S(null);
            int iE = E(iO);
            boolean z = iE == 1;
            this.w0 = iE;
            if (Build.VERSION.SDK_INT >= 26) {
                vVarZ.D(viewC);
                i2 = 0;
                i = 0;
            } else {
                int[] iArr = new int[2];
                this.u0.getLocationOnScreen(iArr);
                int[] iArr2 = new int[2];
                viewC.getLocationOnScreen(iArr2);
                if ((this.t0 & 7) == 5) {
                    iArr[0] = iArr[0] + this.u0.getWidth();
                    iArr2[0] = iArr2[0] + viewC.getWidth();
                }
                i = iArr2[0] - iArr[0];
                i2 = iArr2[1] - iArr[1];
            }
            if ((this.t0 & 5) == 5) {
                if (z) {
                    i3 = i + iO;
                } else {
                    iO = viewC.getWidth();
                    i3 = i - iO;
                }
            } else if (z) {
                iO = viewC.getWidth();
                i3 = i + iO;
            } else {
                i3 = i - iO;
            }
            vVarZ.f(i3);
            vVarZ.N(true);
            vVarZ.l(i2);
        } else {
            if (this.x0) {
                vVarZ.f(this.z0);
            }
            if (this.y0) {
                vVarZ.l(this.A0);
            }
            vVarZ.H(n());
        }
        this.o0.add(new d(vVarZ, eVar, this.w0));
        vVarZ.c();
        ListView listViewJ = vVarZ.j();
        listViewJ.setOnKeyListener(this);
        if (dVar == null && this.C0 && eVar.x() != null) {
            FrameLayout frameLayout = (FrameLayout) layoutInflaterFrom.inflate(ax.p194m.g.l, (ViewGroup) listViewJ, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            frameLayout.setEnabled(false);
            textView.setText(eVar.x());
            listViewJ.addHeaderView(frameLayout, null, false);
            vVarZ.c();
        }
    }

    private v z() {
        v vVar = new v(this.X, null, this.Z, this.k0);
        vVar.U(this.r0);
        vVar.L(this);
        vVar.K(this);
        vVar.D(this.u0);
        vVar.G(this.t0);
        vVar.J(true);
        vVar.I(2);
        return vVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public void a(e eVar, boolean z) {
        int iA = A(eVar);
        if (iA < 0) {
            return;
        }
        int i = iA + 1;
        if (i < this.o0.size()) {
            this.o0.get(i).b.e(false);
        }
        d dVarRemove = this.o0.remove(iA);
        dVarRemove.b.P(this);
        if (this.G0) {
            dVarRemove.a.T(null);
            dVarRemove.a.E(0);
        }
        dVarRemove.a.dismiss();
        int size = this.o0.size();
        if (size > 0) {
            this.w0 = this.o0.get(size - 1).c;
        } else {
            this.w0 = D();
        }
        if (size != 0) {
            if (z) {
                this.o0.get(0).b.e(false);
                return;
            }
            return;
        }
        dismiss();
        j.a aVar = this.D0;
        if (aVar != null) {
            aVar.a(eVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.E0;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.E0.removeGlobalOnLayoutListener(this.p0);
            }
            this.E0 = null;
        }
        this.v0.removeOnAttachStateChangeListener(this.q0);
        this.F0.onDismiss();
    }

    @Override // ax.p306t.e
    public boolean b() {
        return this.o0.size() > 0 && this.o0.get(0).a.b();
    }

    @Override // ax.p306t.e
    public void c() {
        if (b()) {
            return;
        }
        Iterator<e> it = this.n0.iterator();
        while (it.hasNext()) {
            F(it.next());
        }
        this.n0.clear();
        View view = this.u0;
        this.v0 = view;
        if (view != null) {
            boolean z = this.E0 == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.E0 = viewTreeObserver;
            if (z) {
                viewTreeObserver.addOnGlobalLayoutListener(this.p0);
            }
            this.v0.addOnAttachStateChangeListener(this.q0);
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void d(boolean z) {
        Iterator<d> it = this.o0.iterator();
        while (it.hasNext()) {
            h.y(it.next().a().getAdapter()).notifyDataSetChanged();
        }
    }

    @Override // ax.p306t.e
    public void dismiss() {
        int size = this.o0.size();
        if (size > 0) {
            d[] dVarArr = (d[]) this.o0.toArray(new d[size]);
            for (int i = size - 1; i >= 0; i--) {
                d dVar = dVarArr[i];
                if (dVar.a.b()) {
                    dVar.a.dismiss();
                }
            }
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.D0 = aVar;
    }

    @Override // ax.p306t.e
    public ListView j() {
        if (this.o0.isEmpty()) {
            return null;
        }
        List<d> list = this.o0;
        return list.get(list.size() - 1).a();
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean k(m mVar) {
        for (d dVar : this.o0) {
            if (mVar == dVar.b) {
                dVar.a().requestFocus();
                return true;
            }
        }
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        l(mVar);
        j.a aVar = this.D0;
        if (aVar != null) {
            aVar.b(mVar);
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.h
    public void l(e eVar) {
        eVar.c(this, this.X);
        if (b()) {
            F(eVar);
        } else {
            this.n0.add(eVar);
        }
    }

    @Override // androidx.appcompat.view.menu.h
    protected boolean m() {
        return false;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        d dVar;
        int size = this.o0.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                dVar = null;
                break;
            }
            dVar = this.o0.get(i);
            if (!dVar.a.b()) {
                break;
            } else {
                i++;
            }
        }
        if (dVar != null) {
            dVar.b.e(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // androidx.appcompat.view.menu.h
    public void p(View view) {
        if (this.u0 != view) {
            this.u0 = view;
            this.t0 = C1869t.b(this.s0, view.getLayoutDirection());
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void r(boolean z) {
        this.B0 = z;
    }

    @Override // androidx.appcompat.view.menu.h
    public void s(int i) {
        if (this.s0 != i) {
            this.s0 = i;
            this.t0 = C1869t.b(i, this.u0.getLayoutDirection());
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void t(int i) {
        this.x0 = true;
        this.z0 = i;
    }

    @Override // androidx.appcompat.view.menu.h
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.F0 = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.h
    public void v(boolean z) {
        this.C0 = z;
    }

    @Override // androidx.appcompat.view.menu.h
    public void w(int i) {
        this.y0 = true;
        this.A0 = i;
    }
}
