package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/* JADX INFO: loaded from: classes.dex */
class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {
    private androidx.appcompat.app.a X;
    c Y;
    private j.a Z;
    private e q;

    public f(e eVar) {
        this.q = eVar;
    }

    @Override // androidx.appcompat.view.menu.j.a
    public void a(e eVar, boolean z) {
        if (z || eVar == this.q) {
            c();
        }
        j.a aVar = this.Z;
        if (aVar != null) {
            aVar.a(eVar, z);
        }
    }

    @Override // androidx.appcompat.view.menu.j.a
    public boolean b(e eVar) {
        j.a aVar = this.Z;
        if (aVar != null) {
            return aVar.b(eVar);
        }
        return false;
    }

    public void c() {
        androidx.appcompat.app.a aVar = this.X;
        if (aVar != null) {
            aVar.dismiss();
        }
    }

    public void d(IBinder iBinder) {
        e eVar = this.q;
        androidx.appcompat.app.a.C0006a c0006a = new androidx.appcompat.app.a.C0006a(eVar.u());
        c cVar = new c(c0006a.b(), ax.p168m.g.j);
        this.Y = cVar;
        cVar.h(this);
        this.q.b(this.Y);
        c0006a.c(this.Y.b(), this);
        View viewY = eVar.y();
        if (viewY != null) {
            c0006a.e(viewY);
        } else {
            c0006a.f(eVar.w()).t(eVar.x());
        }
        c0006a.n(this);
        androidx.appcompat.app.a aVarA = c0006a.a();
        this.X = aVarA;
        aVarA.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.X.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.X.show();
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        this.q.M((g) this.Y.b().getItem(i), 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        this.Y.a(this.q, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.X.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.X.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.q.e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.q.performShortcut(i, keyEvent, 0);
    }
}
