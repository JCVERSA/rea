package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.x;
import ax.p322u.B;
import ax.p322u.s;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends x implements k.a, View.OnClickListener, ActionMenuView.a {
    private int A0;
    g q0;
    private CharSequence r0;
    private Drawable s0;
    e.b t0;
    private s u0;
    b v0;
    private boolean w0;
    private boolean x0;
    private int y0;
    private int z0;

    private class a extends s {
        public a() {
            super(ActionMenuItemView.this);
        }

        @Override // ax.p322u.s
        public ax.p306t.e b() {
            b bVar = ActionMenuItemView.this.v0;
            if (bVar != null) {
                return bVar.a();
            }
            return null;
        }

        @Override // ax.p322u.s
        protected boolean c() {
            ax.p306t.e eVarB;
            ActionMenuItemView actionMenuItemView = ActionMenuItemView.this;
            e.b bVar = actionMenuItemView.t0;
            return bVar != null && bVar.a(actionMenuItemView.q0) && (eVarB = b()) != null && eVarB.b();
        }
    }

    public static abstract class b {
        public abstract ax.p306t.e a();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.w0 = D();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p194m.j.v, i, 0);
        this.y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(ax.p194m.j.w, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.A0 = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.z0 = -1;
        setSaveEnabled(false);
    }

    private boolean D() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        if (i < 480) {
            return (i >= 640 && i2 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    private void E() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.r0);
        if (this.s0 != null && (!this.q0.B() || (!this.w0 && !this.x0))) {
            z = false;
        }
        boolean z3 = z2 & z;
        setText(z3 ? this.r0 : null);
        CharSequence contentDescription = this.q0.getContentDescription();
        if (TextUtils.isEmpty(contentDescription)) {
            setContentDescription(z3 ? null : this.q0.getTitle());
        } else {
            setContentDescription(contentDescription);
        }
        CharSequence tooltipText = this.q0.getTooltipText();
        if (TextUtils.isEmpty(tooltipText)) {
            B.a(this, z3 ? null : this.q0.getTitle());
        } else {
            B.a(this, tooltipText);
        }
    }

    public boolean C() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // androidx.appcompat.widget.ActionMenuView.a
    public boolean a() {
        return C();
    }

    @Override // androidx.appcompat.widget.ActionMenuView.a
    public boolean b() {
        return C() && this.q0.getIcon() == null;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public boolean d() {
        return true;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public void f(g gVar, int i) {
        this.q0 = gVar;
        setIcon(gVar.getIcon());
        setTitle(gVar.i(this));
        setId(gVar.getItemId());
        setVisibility(gVar.isVisible() ? 0 : 8);
        setEnabled(gVar.isEnabled());
        if (gVar.hasSubMenu() && this.u0 == null) {
            this.u0 = new a();
        }
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // androidx.appcompat.view.menu.k.a
    public g getItemData() {
        return this.q0;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        e.b bVar = this.t0;
        if (bVar != null) {
            bVar.a(this.q0);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.w0 = D();
        E();
    }

    @Override // androidx.appcompat.widget.x, android.widget.TextView, android.view.View
    protected void onMeasure(int i, int i2) {
        int i3;
        boolean zC = C();
        if (zC && (i3 = this.z0) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, this.y0) : this.y0;
        if (mode != 1073741824 && this.y0 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i2);
        }
        if (zC || this.s0 == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.s0.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        s sVar;
        if (this.q0.hasSubMenu() && (sVar = this.u0) != null && sVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.x0 != z) {
            this.x0 = z;
            g gVar = this.q0;
            if (gVar != null) {
                gVar.c();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.s0 = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.A0;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (intrinsicHeight * (i / intrinsicWidth));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (intrinsicWidth * (i / intrinsicHeight));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, null, null, null);
        E();
    }

    public void setItemInvoker(e.b bVar) {
        this.t0 = bVar;
    }

    @Override // android.widget.TextView, android.view.View
    public void setPadding(int i, int i2, int i3, int i4) {
        this.z0 = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(b bVar) {
        this.v0 = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.r0 = charSequence;
        E();
    }
}
