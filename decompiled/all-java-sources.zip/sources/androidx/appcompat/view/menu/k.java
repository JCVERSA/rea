package androidx.appcompat.view.menu;

/* JADX INFO: loaded from: classes.dex */
public interface k {

    public interface a {
        boolean d();

        void f(g gVar, int i);

        g getItemData();
    }

    void b(e eVar);
}
