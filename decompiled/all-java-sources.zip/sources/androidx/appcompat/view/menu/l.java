package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import ax.p322u.v;

/* JADX INFO: loaded from: classes.dex */
final class l extends h implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, j, View.OnKeyListener {
    private static final int B0 = ax.p194m.g.m;
    private boolean A0;
    private final Context X;
    private final e Y;
    private final d Z;
    private final boolean k0;
    private final int l0;
    private final int m0;
    private final int n0;
    final v o0;
    private PopupWindow.OnDismissListener r0;
    private View s0;
    View t0;
    private j.a u0;
    ViewTreeObserver v0;
    private boolean w0;
    private boolean x0;
    private int y0;
    final ViewTreeObserver.OnGlobalLayoutListener p0 = new a();
    private final View.OnAttachStateChangeListener q0 = new b();
    private int z0 = 0;

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!l.this.b() || l.this.o0.B()) {
                return;
            }
            View view = l.this.t0;
            if (view == null || !view.isShown()) {
                l.this.dismiss();
            } else {
                l.this.o0.c();
            }
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = l.this.v0;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    l.this.v0 = view.getViewTreeObserver();
                }
                l lVar = l.this;
                lVar.v0.removeGlobalOnLayoutListener(lVar.p0);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public l(Context context, e eVar, View view, int i, int i2, boolean z) {
        this.X = context;
        this.Y = eVar;
        this.k0 = z;
        this.Z = new d(eVar, LayoutInflater.from(context), z, B0);
        this.m0 = i;
        this.n0 = i2;
        Resources resources = context.getResources();
        this.l0 = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(ax.p194m.d.d));
        this.s0 = view;
        this.o0 = new v(context, null, i, i2);
        eVar.c(this, context);
    }

    private boolean z() {
        View view;
        if (b()) {
            return true;
        }
        if (this.w0 || (view = this.s0) == null) {
            return false;
        }
        this.t0 = view;
        this.o0.K(this);
        this.o0.L(this);
        this.o0.J(true);
        View view2 = this.t0;
        boolean z = this.v0 == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.v0 = viewTreeObserver;
        if (z) {
            viewTreeObserver.addOnGlobalLayoutListener(this.p0);
        }
        view2.addOnAttachStateChangeListener(this.q0);
        this.o0.D(view2);
        this.o0.G(this.z0);
        if (!this.x0) {
            this.y0 = h.o(this.Z, null, this.X, this.l0);
            this.x0 = true;
        }
        this.o0.F(this.y0);
        this.o0.I(2);
        this.o0.H(n());
        this.o0.c();
        ListView listViewJ = this.o0.j();
        listViewJ.setOnKeyListener(this);
        if (this.A0 && this.Y.x() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.X).inflate(ax.p194m.g.l, (ViewGroup) listViewJ, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            if (textView != null) {
                textView.setText(this.Y.x());
            }
            frameLayout.setEnabled(false);
            listViewJ.addHeaderView(frameLayout, null, false);
        }
        this.o0.p(this.Z);
        this.o0.c();
        return true;
    }

    @Override // androidx.appcompat.view.menu.j
    public void a(e eVar, boolean z) {
        if (eVar != this.Y) {
            return;
        }
        dismiss();
        j.a aVar = this.u0;
        if (aVar != null) {
            aVar.a(eVar, z);
        }
    }

    @Override // ax.p306t.e
    public boolean b() {
        return !this.w0 && this.o0.b();
    }

    @Override // ax.p306t.e
    public void c() {
        if (!z()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void d(boolean z) {
        this.x0 = false;
        d dVar = this.Z;
        if (dVar != null) {
            dVar.notifyDataSetChanged();
        }
    }

    @Override // ax.p306t.e
    public void dismiss() {
        if (b()) {
            this.o0.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.u0 = aVar;
    }

    @Override // ax.p306t.e
    public ListView j() {
        return this.o0.j();
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean k(m mVar) {
        if (mVar.hasVisibleItems()) {
            i iVar = new i(this.X, mVar, this.t0, this.k0, this.m0, this.n0);
            iVar.j(this.u0);
            iVar.g(h.x(mVar));
            iVar.i(this.r0);
            this.r0 = null;
            this.Y.e(false);
            int iD = this.o0.d();
            int iO = this.o0.o();
            if ((Gravity.getAbsoluteGravity(this.z0, this.s0.getLayoutDirection()) & 7) == 5) {
                iD += this.s0.getWidth();
            }
            if (iVar.o(iD, iO)) {
                j.a aVar = this.u0;
                if (aVar == null) {
                    return true;
                }
                aVar.b(mVar);
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.h
    public void l(e eVar) {
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        this.w0 = true;
        this.Y.close();
        ViewTreeObserver viewTreeObserver = this.v0;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.v0 = this.t0.getViewTreeObserver();
            }
            this.v0.removeGlobalOnLayoutListener(this.p0);
            this.v0 = null;
        }
        this.t0.removeOnAttachStateChangeListener(this.q0);
        PopupWindow.OnDismissListener onDismissListener = this.r0;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // androidx.appcompat.view.menu.h
    public void p(View view) {
        this.s0 = view;
    }

    @Override // androidx.appcompat.view.menu.h
    public void r(boolean z) {
        this.Z.d(z);
    }

    @Override // androidx.appcompat.view.menu.h
    public void s(int i) {
        this.z0 = i;
    }

    @Override // androidx.appcompat.view.menu.h
    public void t(int i) {
        this.o0.f(i);
    }

    @Override // androidx.appcompat.view.menu.h
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.r0 = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.h
    public void v(boolean z) {
        this.A0 = z;
    }

    @Override // androidx.appcompat.view.menu.h
    public void w(int i) {
        this.o0.l(i);
    }
}
