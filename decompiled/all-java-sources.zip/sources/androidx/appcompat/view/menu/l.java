package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import ax.p280u.v;

/* JADX INFO: loaded from: classes.dex */
final class l extends h implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, j, View.OnKeyListener {
    private static final int y0 = ax.p168m.g.m;
    private final Context X;
    private final e Y;
    private final d Z;
    private final boolean h0;
    private final int i0;
    private final int j0;
    private final int k0;
    final v l0;
    private PopupWindow.OnDismissListener o0;
    private View p0;
    View q0;
    private j.a r0;
    ViewTreeObserver s0;
    private boolean t0;
    private boolean u0;
    private int v0;
    private boolean x0;
    final ViewTreeObserver.OnGlobalLayoutListener m0 = new a();
    private final View.OnAttachStateChangeListener n0 = new b();
    private int w0 = 0;

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!l.this.b() || l.this.l0.B()) {
                return;
            }
            View view = l.this.q0;
            if (view == null || !view.isShown()) {
                l.this.dismiss();
            } else {
                l.this.l0.c();
            }
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = l.this.s0;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    l.this.s0 = view.getViewTreeObserver();
                }
                l lVar = l.this;
                lVar.s0.removeGlobalOnLayoutListener(lVar.m0);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public l(Context context, e eVar, View view, int i, int i2, boolean z) {
        this.X = context;
        this.Y = eVar;
        this.h0 = z;
        this.Z = new d(eVar, LayoutInflater.from(context), z, y0);
        this.j0 = i;
        this.k0 = i2;
        Resources resources = context.getResources();
        this.i0 = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(ax.p168m.d.d));
        this.p0 = view;
        this.l0 = new v(context, null, i, i2);
        eVar.c(this, context);
    }

    private boolean z() {
        View view;
        if (b()) {
            return true;
        }
        if (this.t0 || (view = this.p0) == null) {
            return false;
        }
        this.q0 = view;
        this.l0.K(this);
        this.l0.L(this);
        this.l0.J(true);
        View view2 = this.q0;
        boolean z = this.s0 == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.s0 = viewTreeObserver;
        if (z) {
            viewTreeObserver.addOnGlobalLayoutListener(this.m0);
        }
        view2.addOnAttachStateChangeListener(this.n0);
        this.l0.D(view2);
        this.l0.G(this.w0);
        if (!this.u0) {
            this.v0 = h.o(this.Z, null, this.X, this.i0);
            this.u0 = true;
        }
        this.l0.F(this.v0);
        this.l0.I(2);
        this.l0.H(n());
        this.l0.c();
        ListView listViewJ = this.l0.j();
        listViewJ.setOnKeyListener(this);
        if (this.x0 && this.Y.x() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.X).inflate(ax.p168m.g.l, (ViewGroup) listViewJ, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            if (textView != null) {
                textView.setText(this.Y.x());
            }
            frameLayout.setEnabled(false);
            listViewJ.addHeaderView(frameLayout, null, false);
        }
        this.l0.p(this.Z);
        this.l0.c();
        return true;
    }

    @Override // androidx.appcompat.view.menu.j
    public void a(e eVar, boolean z) {
        if (eVar != this.Y) {
            return;
        }
        dismiss();
        j.a aVar = this.r0;
        if (aVar != null) {
            aVar.a(eVar, z);
        }
    }

    @Override // ax.p266t.e
    public boolean b() {
        return !this.t0 && this.l0.b();
    }

    @Override // ax.p266t.e
    public void c() {
        if (!z()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void d(boolean z) {
        this.u0 = false;
        d dVar = this.Z;
        if (dVar != null) {
            dVar.notifyDataSetChanged();
        }
    }

    @Override // ax.p266t.e
    public void dismiss() {
        if (b()) {
            this.l0.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean e() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.r0 = aVar;
    }

    @Override // ax.p266t.e
    public ListView j() {
        return this.l0.j();
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean k(m mVar) {
        if (mVar.hasVisibleItems()) {
            i iVar = new i(this.X, mVar, this.q0, this.h0, this.j0, this.k0);
            iVar.j(this.r0);
            iVar.g(h.x(mVar));
            iVar.i(this.o0);
            this.o0 = null;
            this.Y.e(false);
            int iD = this.l0.d();
            int iO = this.l0.o();
            if ((Gravity.getAbsoluteGravity(this.w0, this.p0.getLayoutDirection()) & 7) == 5) {
                iD += this.p0.getWidth();
            }
            if (iVar.o(iD, iO)) {
                j.a aVar = this.r0;
                if (aVar == null) {
                    return true;
                }
                aVar.b(mVar);
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.h
    public void l(e eVar) {
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        this.t0 = true;
        this.Y.close();
        ViewTreeObserver viewTreeObserver = this.s0;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.s0 = this.q0.getViewTreeObserver();
            }
            this.s0.removeGlobalOnLayoutListener(this.m0);
            this.s0 = null;
        }
        this.q0.removeOnAttachStateChangeListener(this.n0);
        PopupWindow.OnDismissListener onDismissListener = this.o0;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // androidx.appcompat.view.menu.h
    public void p(View view) {
        this.p0 = view;
    }

    @Override // androidx.appcompat.view.menu.h
    public void r(boolean z) {
        this.Z.d(z);
    }

    @Override // androidx.appcompat.view.menu.h
    public void s(int i) {
        this.w0 = i;
    }

    @Override // androidx.appcompat.view.menu.h
    public void t(int i) {
        this.l0.f(i);
    }

    @Override // androidx.appcompat.view.menu.h
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.o0 = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.h
    public void v(boolean z) {
        this.x0 = z;
    }

    @Override // androidx.appcompat.view.menu.h
    public void w(int i) {
        this.l0.l(i);
    }
}
