package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class d extends BaseAdapter {
    private int X = -1;
    private boolean Y;
    private final boolean Z;
    private final LayoutInflater k0;
    private final int l0;
    e q;

    public d(e eVar, LayoutInflater layoutInflater, boolean z, int i) {
        this.Z = z;
        this.k0 = layoutInflater;
        this.q = eVar;
        this.l0 = i;
        a();
    }

    void a() {
        g gVarV = this.q.v();
        if (gVarV != null) {
            ArrayList<g> arrayListZ = this.q.z();
            int size = arrayListZ.size();
            for (int i = 0; i < size; i++) {
                if (arrayListZ.get(i) == gVarV) {
                    this.X = i;
                    return;
                }
            }
        }
        this.X = -1;
    }

    public e b() {
        return this.q;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public g getItem(int i) {
        ArrayList<g> arrayListZ = this.Z ? this.q.z() : this.q.E();
        int i2 = this.X;
        if (i2 >= 0 && i >= i2) {
            i++;
        }
        return arrayListZ.get(i);
    }

    public void d(boolean z) {
        this.Y = z;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<g> arrayListZ = this.Z ? this.q.z() : this.q.E();
        return this.X < 0 ? arrayListZ.size() : arrayListZ.size() - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.k0.inflate(this.l0, viewGroup, false);
        }
        int groupId = getItem(i).getGroupId();
        int i2 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.q.G() && groupId != (i2 >= 0 ? getItem(i2).getGroupId() : groupId));
        k.a aVar = (k.a) view;
        if (this.Y) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.f(getItem(i), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
