package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class a implements j {
    protected Context X;
    protected e Y;
    protected LayoutInflater Z;
    protected LayoutInflater k0;
    private j.a l0;
    private int m0;
    private int n0;
    protected k o0;
    private int p0;
    protected Context q;

    public a(Context context, int i, int i2) {
        this.q = context;
        this.Z = LayoutInflater.from(context);
        this.m0 = i;
        this.n0 = i2;
    }

    @Override // androidx.appcompat.view.menu.j
    public void a(e eVar, boolean z) {
        j.a aVar = this.l0;
        if (aVar != null) {
            aVar.a(eVar, z);
        }
    }

    protected void b(View view, int i) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.o0).addView(view, i);
    }

    public abstract void c(g gVar, k.a aVar);

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.appcompat.view.menu.j
    public void d(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.o0;
        if (viewGroup == null) {
            return;
        }
        e eVar = this.Y;
        int i = 0;
        if (eVar != null) {
            eVar.r();
            ArrayList<g> arrayListE = this.Y.E();
            int size = arrayListE.size();
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                g gVar = arrayListE.get(i3);
                if (q(i2, gVar)) {
                    View childAt = viewGroup.getChildAt(i2);
                    g itemData = childAt instanceof k.a ? ((k.a) childAt).getItemData() : null;
                    View viewN = n(gVar, childAt, viewGroup);
                    if (gVar != itemData) {
                        viewN.setPressed(false);
                        viewN.jumpDrawablesToCurrentState();
                    }
                    if (viewN != childAt) {
                        b(viewN, i2);
                    }
                    i2++;
                }
            }
            i = i2;
        }
        while (i < viewGroup.getChildCount()) {
            if (!l(viewGroup, i)) {
                i++;
            }
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean f(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean g(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.l0 = aVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public void i(Context context, e eVar) {
        this.X = context;
        this.k0 = LayoutInflater.from(context);
        this.Y = eVar;
    }

    public k.a j(ViewGroup viewGroup) {
        return (k.a) this.Z.inflate(this.n0, viewGroup, false);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // androidx.appcompat.view.menu.j
    public boolean k(m mVar) {
        j.a aVar = this.l0;
        e eVar = mVar;
        if (aVar == null) {
            return false;
        }
        if (mVar == null) {
            eVar = this.Y;
        }
        return aVar.b(eVar);
    }

    protected boolean l(ViewGroup viewGroup, int i) {
        viewGroup.removeViewAt(i);
        return true;
    }

    public j.a m() {
        return this.l0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View n(g gVar, View view, ViewGroup viewGroup) {
        k.a aVarJ = view instanceof k.a ? (k.a) view : j(viewGroup);
        c(gVar, aVarJ);
        return (View) aVarJ;
    }

    public k o(ViewGroup viewGroup) {
        if (this.o0 == null) {
            k kVar = (k) this.Z.inflate(this.m0, viewGroup, false);
            this.o0 = kVar;
            kVar.b(this.Y);
            d(true);
        }
        return this.o0;
    }

    public void p(int i) {
        this.p0 = i;
    }

    public abstract boolean q(int i, g gVar);
}
