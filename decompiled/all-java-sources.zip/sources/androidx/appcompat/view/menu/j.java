package androidx.appcompat.view.menu;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public interface j {

    public interface a {
        void a(e eVar, boolean z);

        boolean b(e eVar);
    }

    void a(e eVar, boolean z);

    void d(boolean z);

    boolean e();

    boolean f(e eVar, g gVar);

    boolean g(e eVar, g gVar);

    void h(a aVar);

    void i(Context context, e eVar);

    boolean k(m mVar);
}
