package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import ax.p029c0.I;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    boolean I;
    int J;
    int[] K;
    View[] L;
    final SparseIntArray M;
    final SparseIntArray N;
    c O;
    final Rect P;
    private boolean Q;

    public static final class a extends c {
        @Override // androidx.recyclerview.widget.GridLayoutManager.c
        public int e(int i, int i2) {
            return i % i2;
        }

        @Override // androidx.recyclerview.widget.GridLayoutManager.c
        public int f(int i) {
            return 1;
        }
    }

    public static abstract class c {
        final SparseIntArray a = new SparseIntArray();
        final SparseIntArray b = new SparseIntArray();
        private boolean c = false;
        private boolean d = false;

        static int a(SparseIntArray sparseIntArray, int i) {
            int size = sparseIntArray.size() - 1;
            int i2 = 0;
            while (i2 <= size) {
                int i3 = (i2 + size) >>> 1;
                if (sparseIntArray.keyAt(i3) < i) {
                    i2 = i3 + 1;
                } else {
                    size = i3 - 1;
                }
            }
            int i4 = i2 - 1;
            if (i4 < 0 || i4 >= sparseIntArray.size()) {
                return -1;
            }
            return sparseIntArray.keyAt(i4);
        }

        int b(int i, int i2) {
            if (!this.d) {
                return d(i, i2);
            }
            int i3 = this.b.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int iD = d(i, i2);
            this.b.put(i, iD);
            return iD;
        }

        int c(int i, int i2) {
            if (!this.c) {
                return e(i, i2);
            }
            int i3 = this.a.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int iE = e(i, i2);
            this.a.put(i, iE);
            return iE;
        }

        /* JADX WARN: Code duplicated, block: B:13:0x002e  */
        /* JADX WARN: Code duplicated, block: B:15:0x0035  */
        /* JADX WARN: Code duplicated, block: B:16:0x0039 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:17:0x003b  */
        /* JADX WARN: Code duplicated, block: B:21:0x0044  */
        /* JADX WARN: Code duplicated, block: B:26:0x003e A[SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:27:? A[RETURN, SYNTHETIC] */
        public int d(int i, int i2) {
            int i3;
            int iC;
            int i4;
            int iF;
            int iF2;
            int iA;
            if (this.d && (iA = a(this.b, i)) != -1) {
                i4 = this.b.get(iA);
                i3 = iA + 1;
                iC = c(iA, i2) + f(iA);
                i4 = iC == i2 ? i4 + 1 : 0;
                iF = f(i);
                while (i3 < i) {
                    iF2 = f(i3);
                    iC += iF2;
                    if (iC == i2) {
                        i4++;
                        iC = 0;
                    } else if (iC > i2) {
                        i4++;
                        iC = iF2;
                    }
                    i3++;
                }
                if (iC + iF > i2) {
                    return i4 + 1;
                }
                return i4;
            }
            i3 = 0;
            iC = 0;
            iF = f(i);
            while (i3 < i) {
                iF2 = f(i3);
                iC += iF2;
                if (iC == i2) {
                    i4++;
                    iC = 0;
                } else if (iC > i2) {
                    i4++;
                    iC = iF2;
                }
                i3++;
            }
            if (iC + iF > i2) {
                return i4 + 1;
            }
            return i4;
        }

        public abstract int e(int i, int i2);

        public abstract int f(int i);

        public void g() {
            this.b.clear();
        }

        public void h() {
            this.a.clear();
        }
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.I = false;
        this.J = -1;
        this.M = new SparseIntArray();
        this.N = new SparseIntArray();
        this.O = new a();
        this.P = new Rect();
        g3(RecyclerView.p.n0(context, attributeSet, i, i2).b);
    }

    private void P2(RecyclerView.w wVar, RecyclerView.B b2, int i, boolean z) {
        int i2;
        int i3;
        int i4;
        int i5 = 0;
        if (z) {
            i3 = i;
            i2 = 0;
            i4 = 1;
        } else {
            i2 = i - 1;
            i3 = -1;
            i4 = -1;
        }
        while (i2 != i3) {
            View view = this.L[i2];
            b bVar = (b) view.getLayoutParams();
            int iC3 = c3(wVar, b2, m0(view));
            bVar.f = iC3;
            bVar.e = i5;
            i5 += iC3;
            i2 += i4;
        }
    }

    private void Q2() {
        int iP = P();
        for (int i = 0; i < iP; i++) {
            b bVar = (b) O(i).getLayoutParams();
            int iA = bVar.a();
            this.M.put(iA, bVar.f());
            this.N.put(iA, bVar.e());
        }
    }

    private void R2(int i) {
        this.K = S2(this.K, this.J, i);
    }

    static int[] S2(int[] iArr, int i, int i2) {
        int i3;
        if (iArr == null || iArr.length != i + 1 || iArr[iArr.length - 1] != i2) {
            iArr = new int[i + 1];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i2 / i;
        int i6 = i2 % i;
        int i7 = 0;
        for (int i8 = 1; i8 <= i; i8++) {
            i4 += i6;
            if (i4 <= 0 || i - i4 >= i6) {
                i3 = i5;
            } else {
                i3 = i5 + 1;
                i4 -= i;
            }
            i7 += i3;
            iArr[i8] = i7;
        }
        return iArr;
    }

    private void T2() {
        this.M.clear();
        this.N.clear();
    }

    private int U2(RecyclerView.B b2) {
        if (P() != 0 && b2.b() != 0) {
            Y1();
            boolean zS2 = s2();
            View viewC2 = c2(!zS2, true);
            View viewB2 = b2(!zS2, true);
            if (viewC2 != null && viewB2 != null) {
                int iB = this.O.b(m0(viewC2), this.J);
                int iB2 = this.O.b(m0(viewB2), this.J);
                int iMax = this.x ? Math.max(0, ((this.O.b(b2.b() - 1, this.J) + 1) - Math.max(iB, iB2)) - 1) : Math.max(0, Math.min(iB, iB2));
                if (zS2) {
                    return Math.round((iMax * (Math.abs(this.u.d(viewB2) - this.u.g(viewC2)) / ((this.O.b(m0(viewB2), this.J) - this.O.b(m0(viewC2), this.J)) + 1))) + (this.u.m() - this.u.g(viewC2)));
                }
                return iMax;
            }
        }
        return 0;
    }

    private int V2(RecyclerView.B b2) {
        if (P() != 0 && b2.b() != 0) {
            Y1();
            View viewC2 = c2(!s2(), true);
            View viewB2 = b2(!s2(), true);
            if (viewC2 != null && viewB2 != null) {
                if (!s2()) {
                    return this.O.b(b2.b() - 1, this.J) + 1;
                }
                return (int) (((this.u.d(viewB2) - this.u.g(viewC2)) / ((this.O.b(m0(viewB2), this.J) - this.O.b(m0(viewC2), this.J)) + 1)) * (this.O.b(b2.b() - 1, this.J) + 1));
            }
        }
        return 0;
    }

    private void W2(RecyclerView.w wVar, RecyclerView.B b2, LinearLayoutManager.a aVar, int i) {
        boolean z = i == 1;
        int iB3 = b3(wVar, b2, aVar.b);
        if (z) {
            while (iB3 > 0) {
                int i2 = aVar.b;
                if (i2 <= 0) {
                    return;
                }
                int i3 = i2 - 1;
                aVar.b = i3;
                iB3 = b3(wVar, b2, i3);
            }
            return;
        }
        int iB = b2.b() - 1;
        int i4 = aVar.b;
        while (i4 < iB) {
            int i5 = i4 + 1;
            int iB4 = b3(wVar, b2, i5);
            if (iB4 <= iB3) {
                break;
            }
            i4 = i5;
            iB3 = iB4;
        }
        aVar.b = i4;
    }

    private void X2() {
        View[] viewArr = this.L;
        if (viewArr == null || viewArr.length != this.J) {
            this.L = new View[this.J];
        }
    }

    private int a3(RecyclerView.w wVar, RecyclerView.B b2, int i) {
        if (!b2.e()) {
            return this.O.b(i, this.J);
        }
        int iF = wVar.f(i);
        if (iF != -1) {
            return this.O.b(iF, this.J);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    private int b3(RecyclerView.w wVar, RecyclerView.B b2, int i) {
        if (!b2.e()) {
            return this.O.c(i, this.J);
        }
        int i2 = this.N.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int iF = wVar.f(i);
        if (iF != -1) {
            return this.O.c(iF, this.J);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 0;
    }

    private int c3(RecyclerView.w wVar, RecyclerView.B b2, int i) {
        if (!b2.e()) {
            return this.O.f(i);
        }
        int i2 = this.M.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int iF = wVar.f(i);
        if (iF != -1) {
            return this.O.f(iF);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 1;
    }

    private void d3(float f, int i) {
        R2(Math.max(Math.round(f * this.J), i));
    }

    private void e3(View view, int i, boolean z) {
        int iQ;
        int iQ2;
        b bVar = (b) view.getLayoutParams();
        Rect rect = bVar.b;
        int i2 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) bVar).topMargin + ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
        int i3 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) bVar).leftMargin + ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
        int iY2 = Y2(bVar.e, bVar.f);
        if (this.s == 1) {
            iQ2 = RecyclerView.p.Q(iY2, i, i3, ((ViewGroup.MarginLayoutParams) bVar).width, false);
            iQ = RecyclerView.p.Q(this.u.n(), d0(), i2, ((ViewGroup.MarginLayoutParams) bVar).height, true);
        } else {
            int iQ3 = RecyclerView.p.Q(iY2, i, i2, ((ViewGroup.MarginLayoutParams) bVar).height, false);
            int iQ4 = RecyclerView.p.Q(this.u.n(), u0(), i3, ((ViewGroup.MarginLayoutParams) bVar).width, true);
            iQ = iQ3;
            iQ2 = iQ4;
        }
        f3(view, iQ2, iQ, z);
    }

    private void f3(View view, int i, int i2, boolean z) {
        RecyclerView.q qVar = (RecyclerView.q) view.getLayoutParams();
        if (z ? M1(view, i, i2, qVar) : K1(view, i, i2, qVar)) {
            view.measure(i, i2);
        }
    }

    private void h3() {
        int iC0;
        int iL0;
        if (q2() == 1) {
            iC0 = t0() - k0();
            iL0 = j0();
        } else {
            iC0 = c0() - i0();
            iL0 = l0();
        }
        R2(iC0 - iL0);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int A(RecyclerView.B b2) {
        return this.Q ? U2(b2) : super.A(b2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int B(RecyclerView.B b2) {
        return this.Q ? V2(b2) : super.B(b2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int B1(int i, RecyclerView.w wVar, RecyclerView.B b2) {
        h3();
        X2();
        return super.B1(i, wVar, b2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int D1(int i, RecyclerView.w wVar, RecyclerView.B b2) {
        h3();
        X2();
        return super.D1(i, wVar, b2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void G2(boolean z) {
        if (z) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.G2(false);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void H1(Rect rect, int i, int i2) {
        int iT;
        int iT2;
        if (this.K == null) {
            super.H1(rect, i, i2);
        }
        int iJ0 = j0() + k0();
        int iL0 = l0() + i0();
        if (this.s == 1) {
            iT2 = RecyclerView.p.t(i2, rect.height() + iL0, g0());
            int[] iArr = this.K;
            iT = RecyclerView.p.t(i, iArr[iArr.length - 1] + iJ0, h0());
        } else {
            iT = RecyclerView.p.t(i, rect.width() + iJ0, h0());
            int[] iArr2 = this.K;
            iT2 = RecyclerView.p.t(i2, iArr2[iArr2.length - 1] + iL0, g0());
        }
        G1(iT, iT2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q J() {
        return this.s == 0 ? new b(-2, -1) : new b(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q K(Context context, AttributeSet attributeSet) {
        return new b(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q L(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new b((ViewGroup.MarginLayoutParams) layoutParams) : new b(layoutParams);
    }

    /* JADX WARN: Code duplicated, block: B:72:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:73:0x010f  */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00d1, code lost:
    
        if (r13 == (r2 > r15)) goto L47;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public View O0(View view, int i, RecyclerView.w wVar, RecyclerView.B b2) {
        int iP;
        int iP2;
        int i2;
        View view2;
        View view3;
        int i3;
        int i4;
        int i5;
        int i6;
        RecyclerView.w wVar2 = wVar;
        RecyclerView.B b3 = b2;
        View viewH = H(view);
        View view4 = null;
        if (viewH == null) {
            return null;
        }
        b bVar = (b) viewH.getLayoutParams();
        int i7 = bVar.e;
        int i8 = bVar.f + i7;
        if (super.O0(view, i, wVar, b2) == null) {
            return null;
        }
        if ((W1(i) == 1) != this.x) {
            iP2 = P() - 1;
            iP = -1;
            i2 = -1;
        } else {
            iP = P();
            iP2 = 0;
            i2 = 1;
        }
        boolean z = this.s == 1 && r2();
        int iA3 = a3(wVar2, b3, iP2);
        int i9 = iP2;
        int iMin = 0;
        int i10 = -1;
        int i11 = -1;
        int iMin2 = 0;
        View view5 = null;
        while (i9 != iP) {
            int iA4 = a3(wVar2, b3, i9);
            View viewO = O(i9);
            if (viewO == viewH) {
                break;
            }
            if (!viewO.hasFocusable() || iA4 == iA3) {
                b bVar2 = (b) viewO.getLayoutParams();
                int i12 = bVar2.e;
                view2 = viewH;
                int i13 = bVar2.f + i12;
                if (viewO.hasFocusable() && i12 == i7 && i13 == i8) {
                    return viewO;
                }
                if (!(viewO.hasFocusable() && view4 == null) && (viewO.hasFocusable() || view5 != null)) {
                    view3 = view5;
                    int iMin3 = Math.min(i13, i8) - Math.max(i12, i7);
                    if (!viewO.hasFocusable()) {
                        if (view4 == null) {
                            i3 = iMin;
                            i4 = iP;
                            if (D0(viewO, false, true)) {
                                i5 = iMin2;
                                if (iMin3 > i5) {
                                    i6 = i11;
                                } else if (iMin3 == i5) {
                                    i6 = i11;
                                    if (z == (i12 > i6)) {
                                    }
                                    i9 += i2;
                                    wVar2 = wVar;
                                    b3 = b2;
                                    viewH = view2;
                                    iP = i4;
                                } else {
                                    i6 = i11;
                                }
                                if (viewO.hasFocusable()) {
                                    i10 = bVar2.e;
                                    i11 = i6;
                                    iMin2 = i5;
                                    view5 = view3;
                                    view4 = viewO;
                                    iMin = Math.min(i13, i8) - Math.max(i12, i7);
                                } else {
                                    int i14 = bVar2.e;
                                    iMin2 = Math.min(i13, i8) - Math.max(i12, i7);
                                    i11 = i14;
                                    iMin = i3;
                                    view5 = viewO;
                                }
                                i9 += i2;
                                wVar2 = wVar;
                                b3 = b2;
                                viewH = view2;
                                iP = i4;
                            }
                            i11 = i6;
                            iMin2 = i5;
                            iMin = i3;
                            view5 = view3;
                            i9 += i2;
                            wVar2 = wVar;
                            b3 = b2;
                            viewH = view2;
                            iP = i4;
                        }
                        i6 = i11;
                        i5 = iMin2;
                        i11 = i6;
                        iMin2 = i5;
                        iMin = i3;
                        view5 = view3;
                        i9 += i2;
                        wVar2 = wVar;
                        b3 = b2;
                        viewH = view2;
                        iP = i4;
                    } else if (iMin3 <= iMin) {
                        if (iMin3 == iMin) {
                        }
                    }
                } else {
                    view3 = view5;
                }
                i3 = iMin;
                i4 = iP;
                i6 = i11;
                i5 = iMin2;
                if (viewO.hasFocusable()) {
                    i10 = bVar2.e;
                    i11 = i6;
                    iMin2 = i5;
                    view5 = view3;
                    view4 = viewO;
                    iMin = Math.min(i13, i8) - Math.max(i12, i7);
                } else {
                    int i15 = bVar2.e;
                    iMin2 = Math.min(i13, i8) - Math.max(i12, i7);
                    i11 = i15;
                    iMin = i3;
                    view5 = viewO;
                }
                i9 += i2;
                wVar2 = wVar;
                b3 = b2;
                viewH = view2;
                iP = i4;
            } else {
                if (view4 != null) {
                    break;
                }
                view2 = viewH;
                view3 = view5;
            }
            i3 = iMin;
            i4 = iP;
            i6 = i11;
            i5 = iMin2;
            i11 = i6;
            iMin2 = i5;
            iMin = i3;
            view5 = view3;
            i9 += i2;
            wVar2 = wVar;
            b3 = b2;
            viewH = view2;
            iP = i4;
        }
        return view4 != null ? view4 : view5;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public boolean Q1() {
        return this.D == null && !this.I;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void R0(RecyclerView.w wVar, RecyclerView.B b2, I i) {
        super.R0(wVar, b2, i);
        i.m0(GridView.class.getName());
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    void S1(RecyclerView.B b2, LinearLayoutManager.c cVar, RecyclerView.p.c cVar2) {
        int iF = this.J;
        for (int i = 0; i < this.J && cVar.c(b2) && iF > 0; i++) {
            int i2 = cVar.d;
            cVar2.a(i2, Math.max(0, cVar.g));
            iF -= this.O.f(i2);
            cVar.d += cVar.e;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int T(RecyclerView.w wVar, RecyclerView.B b2) {
        if (this.s == 1) {
            return this.J;
        }
        if (b2.b() < 1) {
            return 0;
        }
        return a3(wVar, b2, b2.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void U0(RecyclerView.w wVar, RecyclerView.B b2, View view, I i) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof b)) {
            super.T0(view, i);
            return;
        }
        b bVar = (b) layoutParams;
        int iA3 = a3(wVar, b2, bVar.a());
        if (this.s == 0) {
            i.p0(I.f.a(bVar.e(), bVar.f(), iA3, 1, false, false));
        } else {
            i.p0(I.f.a(iA3, 1, bVar.e(), bVar.f(), false, false));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void W0(RecyclerView recyclerView, int i, int i2) {
        this.O.h();
        this.O.g();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void X0(RecyclerView recyclerView) {
        this.O.h();
        this.O.g();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void Y0(RecyclerView recyclerView, int i, int i2, int i3) {
        this.O.h();
        this.O.g();
    }

    int Y2(int i, int i2) {
        if (this.s != 1 || !r2()) {
            int[] iArr = this.K;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.K;
        int i3 = this.J;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void Z0(RecyclerView recyclerView, int i, int i2) {
        this.O.h();
        this.O.g();
    }

    public int Z2() {
        return this.J;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void b1(RecyclerView recyclerView, int i, int i2, Object obj) {
        this.O.h();
        this.O.g();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public void c1(RecyclerView.w wVar, RecyclerView.B b2) {
        if (b2.e()) {
            Q2();
        }
        super.c1(wVar, b2);
        T2();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public void d1(RecyclerView.B b2) {
        super.d1(b2);
        this.I = false;
    }

    public void g3(int i) {
        if (i == this.J) {
            return;
        }
        this.I = true;
        if (i >= 1) {
            this.J = i;
            this.O.h();
            y1();
        } else {
            throw new IllegalArgumentException("Span count should be at least 1. Provided " + i);
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    View k2(RecyclerView.w wVar, RecyclerView.B b2, boolean z, boolean z2) {
        int i;
        int iP;
        int iP2 = P();
        int i2 = 1;
        if (z2) {
            iP = P() - 1;
            i = -1;
            i2 = -1;
        } else {
            i = iP2;
            iP = 0;
        }
        int iB = b2.b();
        Y1();
        int iM = this.u.m();
        int i3 = this.u.i();
        View view = null;
        View view2 = null;
        while (iP != i) {
            View viewO = O(iP);
            int iM0 = m0(viewO);
            if (iM0 >= 0 && iM0 < iB && b3(wVar, b2, iM0) == 0) {
                if (((RecyclerView.q) viewO.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = viewO;
                    }
                } else {
                    if (this.u.g(viewO) < i3 && this.u.d(viewO) >= iM) {
                        return viewO;
                    }
                    if (view == null) {
                        view = viewO;
                    }
                }
            }
            iP += i2;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int p0(RecyclerView.w wVar, RecyclerView.B b2) {
        if (this.s == 0) {
            return this.J;
        }
        if (b2.b() < 1) {
            return 0;
        }
        return a3(wVar, b2, b2.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean s(RecyclerView.q qVar) {
        return qVar instanceof b;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    void t2(RecyclerView.w wVar, RecyclerView.B b2, LinearLayoutManager.c cVar, LinearLayoutManager.b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int iF;
        int i6;
        int iF2;
        int iF3;
        int i7;
        int iQ;
        int iQ2;
        View viewD;
        int iL = this.u.l();
        boolean z = iL != 1073741824;
        int i8 = P() > 0 ? this.K[this.J] : 0;
        if (z) {
            h3();
        }
        boolean z2 = cVar.e == 1;
        int iB3 = this.J;
        if (!z2) {
            iB3 = b3(wVar, b2, cVar.d) + c3(wVar, b2, cVar.d);
        }
        int i9 = 0;
        while (i9 < this.J && cVar.c(b2) && iB3 > 0) {
            int i10 = cVar.d;
            int iC3 = c3(wVar, b2, i10);
            if (iC3 > this.J) {
                throw new IllegalArgumentException("Item at position " + i10 + " requires " + iC3 + " spans but GridLayoutManager has only " + this.J + " spans.");
            }
            iB3 -= iC3;
            if (iB3 < 0 || (viewD = cVar.d(wVar)) == null) {
                break;
            }
            this.L[i9] = viewD;
            i9++;
        }
        if (i9 == 0) {
            bVar.b = true;
            return;
        }
        P2(wVar, b2, i9, z2);
        float f = 0.0f;
        int i11 = 0;
        for (int i12 = 0; i12 < i9; i12++) {
            View view = this.L[i12];
            if (cVar.l == null) {
                if (z2) {
                    j(view);
                } else {
                    k(view, 0);
                }
            } else if (z2) {
                h(view);
            } else {
                i(view, 0);
            }
            p(view, this.P);
            e3(view, iL, false);
            int iE = this.u.e(view);
            if (iE > i11) {
                i11 = iE;
            }
            float f2 = (this.u.f(view) * 1.0f) / ((b) view.getLayoutParams()).f;
            if (f2 > f) {
                f = f2;
            }
        }
        if (z) {
            d3(f, i8);
            i11 = 0;
            for (int i13 = 0; i13 < i9; i13++) {
                View view2 = this.L[i13];
                e3(view2, 1073741824, true);
                int iE2 = this.u.e(view2);
                if (iE2 > i11) {
                    i11 = iE2;
                }
            }
        }
        for (int i14 = 0; i14 < i9; i14++) {
            View view3 = this.L[i14];
            if (this.u.e(view3) != i11) {
                b bVar2 = (b) view3.getLayoutParams();
                Rect rect = bVar2.b;
                int i15 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) bVar2).topMargin + ((ViewGroup.MarginLayoutParams) bVar2).bottomMargin;
                int i16 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) bVar2).leftMargin + ((ViewGroup.MarginLayoutParams) bVar2).rightMargin;
                int iY2 = Y2(bVar2.e, bVar2.f);
                if (this.s == 1) {
                    iQ2 = RecyclerView.p.Q(iY2, 1073741824, i16, ((ViewGroup.MarginLayoutParams) bVar2).width, false);
                    iQ = View.MeasureSpec.makeMeasureSpec(i11 - i15, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i11 - i16, 1073741824);
                    iQ = RecyclerView.p.Q(iY2, 1073741824, i15, ((ViewGroup.MarginLayoutParams) bVar2).height, false);
                    iQ2 = iMakeMeasureSpec;
                }
                f3(view3, iQ2, iQ, true);
            }
        }
        bVar.a = i11;
        if (this.s == 1) {
            if (cVar.f == -1) {
                iF = cVar.b;
                i7 = iF - i11;
            } else {
                i7 = cVar.b;
                iF = i7 + i11;
            }
            i4 = i7;
            i5 = 0;
            i3 = 0;
        } else {
            if (cVar.f == -1) {
                i2 = cVar.b;
                i = i2 - i11;
            } else {
                i = cVar.b;
                i2 = i + i11;
            }
            i3 = i;
            i4 = 0;
            i5 = i2;
            iF = 0;
        }
        int i17 = 0;
        while (i17 < i9) {
            View view4 = this.L[i17];
            b bVar3 = (b) view4.getLayoutParams();
            if (this.s == 1) {
                if (r2()) {
                    int iJ0 = j0() + this.K[this.J - bVar3.e];
                    iF2 = iJ0;
                    iF3 = iJ0 - this.u.f(view4);
                } else {
                    int iJ1 = j0() + this.K[bVar3.e];
                    iF3 = iJ1;
                    iF2 = this.u.f(view4) + iJ1;
                }
                i6 = i4;
            } else {
                int iL0 = l0() + this.K[bVar3.e];
                i6 = iL0;
                iF2 = i5;
                iF3 = i3;
                iF = this.u.f(view4) + iL0;
            }
            E0(view4, iF3, i6, iF2, iF);
            if (bVar3.c() || bVar3.b()) {
                bVar.c = true;
            }
            bVar.d |= view4.hasFocusable();
            i17++;
            iF = iF;
            i5 = iF2;
            i3 = iF3;
            i4 = i6;
        }
        Arrays.fill(this.L, (Object) null);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    void v2(RecyclerView.w wVar, RecyclerView.B b2, LinearLayoutManager.a aVar, int i) {
        super.v2(wVar, b2, aVar, i);
        h3();
        if (b2.b() > 0 && !b2.e()) {
            W2(wVar, b2, aVar, i);
        }
        X2();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int x(RecyclerView.B b2) {
        return this.Q ? U2(b2) : super.x(b2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.p
    public int y(RecyclerView.B b2) {
        return this.Q ? V2(b2) : super.y(b2);
    }

    public static class b extends RecyclerView.q {
        int e;
        int f;

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.e = -1;
            this.f = 0;
        }

        public int e() {
            return this.e;
        }

        public int f() {
            return this.f;
        }

        public b(int i, int i2) {
            super(i, i2);
            this.e = -1;
            this.f = 0;
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.e = -1;
            this.f = 0;
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.e = -1;
            this.f = 0;
        }
    }

    public GridLayoutManager(Context context, int i, int i2, boolean z) {
        super(context, i2, z);
        this.I = false;
        this.J = -1;
        this.M = new SparseIntArray();
        this.N = new SparseIntArray();
        this.O = new a();
        this.P = new Rect();
        g3(i);
    }
}
