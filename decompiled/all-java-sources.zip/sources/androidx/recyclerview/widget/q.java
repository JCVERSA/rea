package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import ax.p015b0.C5207a;
import ax.p015b0.Y;
import ax.p029c0.I;
import ax.p029c0.L;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class q extends C5207a {
    final RecyclerView d;
    private final a e;

    public static class a extends C5207a {
        final q d;
        private Map<View, C5207a> e = new WeakHashMap();

        public a(q qVar) {
            this.d = qVar;
        }

        @Override // ax.p015b0.C5207a
        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            C5207a c5207a = this.e.get(view);
            return c5207a != null ? c5207a.a(view, accessibilityEvent) : super.a(view, accessibilityEvent);
        }

        @Override // ax.p015b0.C5207a
        public L b(View view) {
            C5207a c5207a = this.e.get(view);
            return c5207a != null ? c5207a.b(view) : super.b(view);
        }

        @Override // ax.p015b0.C5207a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                c5207a.f(view, accessibilityEvent);
            } else {
                super.f(view, accessibilityEvent);
            }
        }

        @Override // ax.p015b0.C5207a
        public void g(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) I i) {
            if (this.d.o() || this.d.d.getLayoutManager() == null) {
                super.g(view, i);
                return;
            }
            this.d.d.getLayoutManager().T0(view, i);
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                c5207a.g(view, i);
            } else {
                super.g(view, i);
            }
        }

        @Override // ax.p015b0.C5207a
        public void h(View view, AccessibilityEvent accessibilityEvent) {
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                c5207a.h(view, accessibilityEvent);
            } else {
                super.h(view, accessibilityEvent);
            }
        }

        @Override // ax.p015b0.C5207a
        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            C5207a c5207a = this.e.get(viewGroup);
            return c5207a != null ? c5207a.i(viewGroup, view, accessibilityEvent) : super.i(viewGroup, view, accessibilityEvent);
        }

        @Override // ax.p015b0.C5207a
        public boolean j(@SuppressLint({"InvalidNullabilityOverride"}) View view, int i, @SuppressLint({"InvalidNullabilityOverride"}) Bundle bundle) {
            if (this.d.o() || this.d.d.getLayoutManager() == null) {
                return super.j(view, i, bundle);
            }
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                if (c5207a.j(view, i, bundle)) {
                    return true;
                }
            } else if (super.j(view, i, bundle)) {
                return true;
            }
            return this.d.d.getLayoutManager().n1(view, i, bundle);
        }

        @Override // ax.p015b0.C5207a
        public void l(View view, int i) {
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                c5207a.l(view, i);
            } else {
                super.l(view, i);
            }
        }

        @Override // ax.p015b0.C5207a
        public void m(View view, AccessibilityEvent accessibilityEvent) {
            C5207a c5207a = this.e.get(view);
            if (c5207a != null) {
                c5207a.m(view, accessibilityEvent);
            } else {
                super.m(view, accessibilityEvent);
            }
        }

        C5207a n(View view) {
            return this.e.remove(view);
        }

        void o(View view) {
            C5207a c5207aN = Y.n(view);
            if (c5207aN == null || c5207aN == this) {
                return;
            }
            this.e.put(view, c5207aN);
        }
    }

    public q(RecyclerView recyclerView) {
        this.d = recyclerView;
        C5207a c5207aN = n();
        if (c5207aN == null || !(c5207aN instanceof a)) {
            this.e = new a(this);
        } else {
            this.e = (a) c5207aN;
        }
    }

    @Override // ax.p015b0.C5207a
    public void f(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        if (!(view instanceof RecyclerView) || o()) {
            return;
        }
        RecyclerView recyclerView = (RecyclerView) view;
        if (recyclerView.getLayoutManager() != null) {
            recyclerView.getLayoutManager().P0(accessibilityEvent);
        }
    }

    @Override // ax.p015b0.C5207a
    public void g(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) I i) {
        super.g(view, i);
        if (o() || this.d.getLayoutManager() == null) {
            return;
        }
        this.d.getLayoutManager().S0(i);
    }

    @Override // ax.p015b0.C5207a
    public boolean j(@SuppressLint({"InvalidNullabilityOverride"}) View view, int i, @SuppressLint({"InvalidNullabilityOverride"}) Bundle bundle) {
        if (super.j(view, i, bundle)) {
            return true;
        }
        if (o() || this.d.getLayoutManager() == null) {
            return false;
        }
        return this.d.getLayoutManager().l1(i, bundle);
    }

    public C5207a n() {
        return this.e;
    }

    boolean o() {
        return this.d.v0();
    }
}
