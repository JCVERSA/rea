package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import ax.p035c0.C1832a;
import ax.p035c0.C1839d0;
import ax.p051d0.H;
import ax.p051d0.K;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class q extends C1832a {
    final RecyclerView d;
    private final a e;

    public static class a extends C1832a {
        final q d;
        private Map<View, C1832a> e = new WeakHashMap();

        public a(q qVar) {
            this.d = qVar;
        }

        @Override // ax.p035c0.C1832a
        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            C1832a c1832a = this.e.get(view);
            return c1832a != null ? c1832a.a(view, accessibilityEvent) : super.a(view, accessibilityEvent);
        }

        @Override // ax.p035c0.C1832a
        public K b(View view) {
            C1832a c1832a = this.e.get(view);
            return c1832a != null ? c1832a.b(view) : super.b(view);
        }

        @Override // ax.p035c0.C1832a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                c1832a.f(view, accessibilityEvent);
            } else {
                super.f(view, accessibilityEvent);
            }
        }

        @Override // ax.p035c0.C1832a
        public void g(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) H h) {
            if (this.d.o() || this.d.d.getLayoutManager() == null) {
                super.g(view, h);
                return;
            }
            this.d.d.getLayoutManager().T0(view, h);
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                c1832a.g(view, h);
            } else {
                super.g(view, h);
            }
        }

        @Override // ax.p035c0.C1832a
        public void h(View view, AccessibilityEvent accessibilityEvent) {
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                c1832a.h(view, accessibilityEvent);
            } else {
                super.h(view, accessibilityEvent);
            }
        }

        @Override // ax.p035c0.C1832a
        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            C1832a c1832a = this.e.get(viewGroup);
            return c1832a != null ? c1832a.i(viewGroup, view, accessibilityEvent) : super.i(viewGroup, view, accessibilityEvent);
        }

        @Override // ax.p035c0.C1832a
        public boolean j(@SuppressLint({"InvalidNullabilityOverride"}) View view, int i, @SuppressLint({"InvalidNullabilityOverride"}) Bundle bundle) {
            if (this.d.o() || this.d.d.getLayoutManager() == null) {
                return super.j(view, i, bundle);
            }
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                if (c1832a.j(view, i, bundle)) {
                    return true;
                }
            } else if (super.j(view, i, bundle)) {
                return true;
            }
            return this.d.d.getLayoutManager().n1(view, i, bundle);
        }

        @Override // ax.p035c0.C1832a
        public void l(View view, int i) {
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                c1832a.l(view, i);
            } else {
                super.l(view, i);
            }
        }

        @Override // ax.p035c0.C1832a
        public void m(View view, AccessibilityEvent accessibilityEvent) {
            C1832a c1832a = this.e.get(view);
            if (c1832a != null) {
                c1832a.m(view, accessibilityEvent);
            } else {
                super.m(view, accessibilityEvent);
            }
        }

        C1832a n(View view) {
            return this.e.remove(view);
        }

        void o(View view) {
            C1832a c1832aM = C1839d0.m(view);
            if (c1832aM == null || c1832aM == this) {
                return;
            }
            this.e.put(view, c1832aM);
        }
    }

    public q(RecyclerView recyclerView) {
        this.d = recyclerView;
        C1832a c1832aN = n();
        if (c1832aN == null || !(c1832aN instanceof a)) {
            this.e = new a(this);
        } else {
            this.e = (a) c1832aN;
        }
    }

    @Override // ax.p035c0.C1832a
    public void f(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        if (!(view instanceof RecyclerView) || o()) {
            return;
        }
        RecyclerView recyclerView = (RecyclerView) view;
        if (recyclerView.getLayoutManager() != null) {
            recyclerView.getLayoutManager().P0(accessibilityEvent);
        }
    }

    @Override // ax.p035c0.C1832a
    public void g(@SuppressLint({"InvalidNullabilityOverride"}) View view, @SuppressLint({"InvalidNullabilityOverride"}) H h) {
        super.g(view, h);
        if (o() || this.d.getLayoutManager() == null) {
            return;
        }
        this.d.getLayoutManager().S0(h);
    }

    @Override // ax.p035c0.C1832a
    public boolean j(@SuppressLint({"InvalidNullabilityOverride"}) View view, int i, @SuppressLint({"InvalidNullabilityOverride"}) Bundle bundle) {
        if (super.j(view, i, bundle)) {
            return true;
        }
        if (o() || this.d.getLayoutManager() == null) {
            return false;
        }
        return this.d.getLayoutManager().l1(i, bundle);
    }

    public C1832a n() {
        return this.e;
    }

    boolean o() {
        return this.d.v0();
    }
}
