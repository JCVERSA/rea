package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
class w {
    final ax.B.k<RecyclerView.F, a> a = new ax.B.k<>();
    final ax.B.h<RecyclerView.F> b = new ax.B.h<>();

    static class a {
        static ax.p019b0.d<a> d = new ax.p019b0.e(20);
        int a;
        RecyclerView.m.c b;
        RecyclerView.m.c c;

        private a() {
        }

        static void a() {
            while (d.b() != null) {
            }
        }

        static a b() {
            a aVarB = d.b();
            return aVarB == null ? new a() : aVarB;
        }

        static void c(a aVar) {
            aVar.a = 0;
            aVar.b = null;
            aVar.c = null;
            d.a(aVar);
        }
    }

    interface b {
        void a(RecyclerView.F f);

        void b(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);

        void c(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);

        void d(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);
    }

    w() {
    }

    private RecyclerView.m.c l(RecyclerView.F f, int i) {
        a aVarK;
        RecyclerView.m.c cVar;
        int iD = this.a.d(f);
        if (iD >= 0 && (aVarK = this.a.k(iD)) != null) {
            int i2 = aVarK.a;
            if ((i2 & i) != 0) {
                int i3 = (~i) & i2;
                aVarK.a = i3;
                if (i == 4) {
                    cVar = aVarK.b;
                } else {
                    if (i != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    cVar = aVarK.c;
                }
                if ((i3 & 12) == 0) {
                    this.a.i(iD);
                    a.c(aVarK);
                }
                return cVar;
            }
        }
        return null;
    }

    void a(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.a |= 2;
        aVarB.b = cVar;
    }

    void b(RecyclerView.F f) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.a |= 1;
    }

    void c(long j, RecyclerView.F f) {
        this.b.l(j, f);
    }

    void d(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.c = cVar;
        aVarB.a |= 8;
    }

    void e(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.b = cVar;
        aVarB.a |= 4;
    }

    void f() {
        this.a.clear();
        this.b.c();
    }

    RecyclerView.F g(long j) {
        return this.b.e(j);
    }

    boolean h(RecyclerView.F f) {
        a aVar = this.a.get(f);
        return (aVar == null || (aVar.a & 1) == 0) ? false : true;
    }

    boolean i(RecyclerView.F f) {
        a aVar = this.a.get(f);
        return (aVar == null || (aVar.a & 4) == 0) ? false : true;
    }

    void j() {
        a.a();
    }

    public void k(RecyclerView.F f) {
        p(f);
    }

    RecyclerView.m.c m(RecyclerView.F f) {
        return l(f, 8);
    }

    RecyclerView.m.c n(RecyclerView.F f) {
        return l(f, 4);
    }

    void o(b bVar) {
        for (int size = this.a.size() - 1; size >= 0; size--) {
            RecyclerView.F f = this.a.f(size);
            a aVarI = this.a.i(size);
            int i = aVarI.a;
            if ((i & 3) == 3) {
                bVar.a(f);
            } else if ((i & 1) != 0) {
                RecyclerView.m.c cVar = aVarI.b;
                if (cVar == null) {
                    bVar.a(f);
                } else {
                    bVar.c(f, cVar, aVarI.c);
                }
            } else if ((i & 14) == 14) {
                bVar.b(f, aVarI.b, aVarI.c);
            } else if ((i & 12) == 12) {
                bVar.d(f, aVarI.b, aVarI.c);
            } else if ((i & 4) != 0) {
                bVar.c(f, aVarI.b, null);
            } else if ((i & 8) != 0) {
                bVar.b(f, aVarI.b, aVarI.c);
            }
            a.c(aVarI);
        }
    }

    void p(RecyclerView.F f) {
        a aVar = this.a.get(f);
        if (aVar == null) {
            return;
        }
        aVar.a &= -2;
    }

    void q(RecyclerView.F f) {
        for (int iO = this.b.o() - 1; iO >= 0; iO--) {
            if (f == this.b.q(iO)) {
                this.b.n(iO);
                break;
            }
        }
        a aVarRemove = this.a.remove(f);
        if (aVarRemove != null) {
            a.c(aVarRemove);
        }
    }
}
