package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
class w {
    final ax.B.h<RecyclerView.F, a> a = new ax.B.h<>();
    final ax.B.e<RecyclerView.F> b = new ax.B.e<>();

    static class a {
        static ax.p001a0.d<a> d = new ax.p001a0.e(20);
        int a;
        RecyclerView.m.c b;
        RecyclerView.m.c c;

        private a() {
        }

        static void a() {
            while (d.b() != null) {
            }
        }

        static a b() {
            a aVarB = d.b();
            return aVarB == null ? new a() : aVarB;
        }

        static void c(a aVar) {
            aVar.a = 0;
            aVar.b = null;
            aVar.c = null;
            d.c(aVar);
        }
    }

    interface b {
        void a(RecyclerView.F f);

        void b(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);

        void c(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);

        void d(RecyclerView.F f, RecyclerView.m.c cVar, RecyclerView.m.c cVar2);
    }

    w() {
    }

    private RecyclerView.m.c l(RecyclerView.F f, int i) {
        a aVarM;
        RecyclerView.m.c cVar;
        int iF = this.a.f(f);
        if (iF >= 0 && (aVarM = this.a.m(iF)) != null) {
            int i2 = aVarM.a;
            if ((i2 & i) != 0) {
                int i3 = (~i) & i2;
                aVarM.a = i3;
                if (i == 4) {
                    cVar = aVarM.b;
                } else {
                    if (i != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    cVar = aVarM.c;
                }
                if ((i3 & 12) == 0) {
                    this.a.k(iF);
                    a.c(aVarM);
                }
                return cVar;
            }
        }
        return null;
    }

    void a(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.a |= 2;
        aVarB.b = cVar;
    }

    void b(RecyclerView.F f) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.a |= 1;
    }

    void c(long j, RecyclerView.F f) {
        this.b.m(j, f);
    }

    void d(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.c = cVar;
        aVarB.a |= 8;
    }

    void e(RecyclerView.F f, RecyclerView.m.c cVar) {
        a aVarB = this.a.get(f);
        if (aVarB == null) {
            aVarB = a.b();
            this.a.put(f, aVarB);
        }
        aVarB.b = cVar;
        aVarB.a |= 4;
    }

    void f() {
        this.a.clear();
        this.b.c();
    }

    RecyclerView.F g(long j) {
        return this.b.h(j);
    }

    boolean h(RecyclerView.F f) {
        a aVar = this.a.get(f);
        return (aVar == null || (aVar.a & 1) == 0) ? false : true;
    }

    boolean i(RecyclerView.F f) {
        a aVar = this.a.get(f);
        return (aVar == null || (aVar.a & 4) == 0) ? false : true;
    }

    void j() {
        a.a();
    }

    public void k(RecyclerView.F f) {
        p(f);
    }

    RecyclerView.m.c m(RecyclerView.F f) {
        return l(f, 8);
    }

    RecyclerView.m.c n(RecyclerView.F f) {
        return l(f, 4);
    }

    void o(b bVar) {
        for (int size = this.a.size() - 1; size >= 0; size--) {
            RecyclerView.F fI = this.a.i(size);
            a aVarK = this.a.k(size);
            int i = aVarK.a;
            if ((i & 3) == 3) {
                bVar.a(fI);
            } else if ((i & 1) != 0) {
                RecyclerView.m.c cVar = aVarK.b;
                if (cVar == null) {
                    bVar.a(fI);
                } else {
                    bVar.c(fI, cVar, aVarK.c);
                }
            } else if ((i & 14) == 14) {
                bVar.b(fI, aVarK.b, aVarK.c);
            } else if ((i & 12) == 12) {
                bVar.d(fI, aVarK.b, aVarK.c);
            } else if ((i & 4) != 0) {
                bVar.c(fI, aVarK.b, null);
            } else if ((i & 8) != 0) {
                bVar.b(fI, aVarK.b, aVarK.c);
            }
            a.c(aVarK);
        }
    }

    void p(RecyclerView.F f) {
        a aVar = this.a.get(f);
        if (aVar == null) {
            return;
        }
        aVar.a &= -2;
    }

    void q(RecyclerView.F f) {
        for (int iP = this.b.p() - 1; iP >= 0; iP--) {
            if (f == this.b.q(iP)) {
                this.b.o(iP);
                break;
            }
        }
        a aVarRemove = this.a.remove(f);
        if (aVarRemove != null) {
            a.c(aVarRemove);
        }
    }
}
