package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
final class h implements Runnable {
    static final ThreadLocal<h> k0 = new ThreadLocal<>();
    static Comparator<c> l0 = new a();
    long X;
    long Y;
    ArrayList<RecyclerView> q = new ArrayList<>();
    private ArrayList<c> Z = new ArrayList<>();

    class a implements Comparator<c> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(c cVar, c cVar2) {
            RecyclerView recyclerView = cVar.d;
            if ((recyclerView == null) != (cVar2.d == null)) {
                return recyclerView == null ? 1 : -1;
            }
            boolean z = cVar.a;
            if (z != cVar2.a) {
                return z ? -1 : 1;
            }
            int i = cVar2.b - cVar.b;
            if (i != 0) {
                return i;
            }
            int i2 = cVar.c - cVar2.c;
            if (i2 != 0) {
                return i2;
            }
            return 0;
        }
    }

    @SuppressLint({"VisibleForTests"})
    static class b implements RecyclerView.p.c {
        int a;
        int b;
        int[] c;
        int d;

        b() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.p.c
        public void a(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            }
            if (i2 < 0) {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
            int i3 = this.d;
            int i4 = i3 * 2;
            int[] iArr = this.c;
            if (iArr == null) {
                int[] iArr2 = new int[4];
                this.c = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i4 >= iArr.length) {
                int[] iArr3 = new int[i3 * 4];
                this.c = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            }
            int[] iArr4 = this.c;
            iArr4[i4] = i;
            iArr4[i4 + 1] = i2;
            this.d++;
        }

        void b() {
            int[] iArr = this.c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.d = 0;
        }

        void c(RecyclerView recyclerView, boolean z) {
            this.d = 0;
            int[] iArr = this.c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            RecyclerView.p pVar = recyclerView.w0;
            if (recyclerView.v0 == null || pVar == null || !pVar.z0()) {
                return;
            }
            if (z) {
                if (!recyclerView.n0.p()) {
                    pVar.v(recyclerView.v0.l(), this);
                }
            } else if (!recyclerView.v0()) {
                pVar.u(this.a, this.b, recyclerView.p1, this);
            }
            int i = this.d;
            if (i > pVar.m) {
                pVar.m = i;
                pVar.n = z;
                recyclerView.l0.P();
            }
        }

        boolean d(int i) {
            if (this.c != null) {
                int i2 = this.d * 2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.c[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }

        void e(int i, int i2) {
            this.a = i;
            this.b = i2;
        }
    }

    static class c {
        public boolean a;
        public int b;
        public int c;
        public RecyclerView d;
        public int e;

        c() {
        }

        public void a() {
            this.a = false;
            this.b = 0;
            this.c = 0;
            this.d = null;
            this.e = 0;
        }
    }

    h() {
    }

    private void b() {
        c cVar;
        int size = this.q.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            RecyclerView recyclerView = this.q.get(i2);
            if (recyclerView.getWindowVisibility() == 0) {
                recyclerView.o1.c(recyclerView, false);
                i += recyclerView.o1.d;
            }
        }
        this.Z.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView recyclerView2 = this.q.get(i4);
            if (recyclerView2.getWindowVisibility() == 0) {
                b bVar = recyclerView2.o1;
                int iAbs = Math.abs(bVar.a) + Math.abs(bVar.b);
                for (int i5 = 0; i5 < bVar.d * 2; i5 += 2) {
                    if (i3 >= this.Z.size()) {
                        cVar = new c();
                        this.Z.add(cVar);
                    } else {
                        cVar = this.Z.get(i3);
                    }
                    int[] iArr = bVar.c;
                    int i6 = iArr[i5 + 1];
                    cVar.a = i6 <= iAbs;
                    cVar.b = iAbs;
                    cVar.c = i6;
                    cVar.d = recyclerView2;
                    cVar.e = iArr[i5];
                    i3++;
                }
            }
        }
        Collections.sort(this.Z, l0);
    }

    private void c(c cVar, long j) {
        RecyclerView.F fI = i(cVar.d, cVar.e, cVar.a ? Long.MAX_VALUE : j);
        if (fI == null || fI.b == null || !fI.t() || fI.u()) {
            return;
        }
        h(fI.b.get(), j);
    }

    private void d(long j) {
        for (int i = 0; i < this.Z.size(); i++) {
            c cVar = this.Z.get(i);
            if (cVar.d == null) {
                return;
            }
            c(cVar, j);
            cVar.a();
        }
    }

    static boolean e(RecyclerView recyclerView, int i) {
        int iJ = recyclerView.o0.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            RecyclerView.F fN0 = RecyclerView.n0(recyclerView.o0.i(i2));
            if (fN0.c == i && !fN0.u()) {
                return true;
            }
        }
        return false;
    }

    private void h(RecyclerView recyclerView, long j) {
        if (recyclerView == null) {
            return;
        }
        if (recyclerView.O0 && recyclerView.o0.j() != 0) {
            recyclerView.i1();
        }
        b bVar = recyclerView.o1;
        bVar.c(recyclerView, true);
        if (bVar.d != 0) {
            try {
                ax.Y.u.a("RV Nested Prefetch");
                recyclerView.p1.f(recyclerView.v0);
                for (int i = 0; i < bVar.d * 2; i += 2) {
                    i(recyclerView, bVar.c[i], j);
                }
                ax.Y.u.b();
            } catch (Throwable th) {
                ax.Y.u.b();
                throw th;
            }
        }
    }

    private RecyclerView.F i(RecyclerView recyclerView, int i, long j) {
        if (e(recyclerView, i)) {
            return null;
        }
        RecyclerView.w wVar = recyclerView.l0;
        try {
            recyclerView.S0();
            RecyclerView.F fN = wVar.N(i, false, j);
            if (fN != null) {
                if (!fN.t() || fN.u()) {
                    wVar.a(fN, false);
                } else {
                    wVar.G(fN.a);
                }
            }
            return fN;
        } finally {
            recyclerView.U0(false);
        }
    }

    public void a(RecyclerView recyclerView) {
        if (RecyclerView.J1 && this.q.contains(recyclerView)) {
            throw new IllegalStateException("RecyclerView already present in worker list!");
        }
        this.q.add(recyclerView);
    }

    void f(RecyclerView recyclerView, int i, int i2) {
        if (recyclerView.isAttachedToWindow()) {
            if (RecyclerView.J1 && !this.q.contains(recyclerView)) {
                throw new IllegalStateException("attempting to post unregistered view!");
            }
            if (this.X == 0) {
                this.X = recyclerView.getNanoTime();
                recyclerView.post(this);
            }
        }
        recyclerView.o1.e(i, i2);
    }

    void g(long j) {
        b();
        d(j);
    }

    public void j(RecyclerView recyclerView) {
        boolean zRemove = this.q.remove(recyclerView);
        if (RecyclerView.J1 && !zRemove) {
            throw new IllegalStateException("RecyclerView removal failed!");
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            ax.Y.u.a("RV Prefetch");
            if (!this.q.isEmpty()) {
                int size = this.q.size();
                long jMax = 0;
                for (int i = 0; i < size; i++) {
                    RecyclerView recyclerView = this.q.get(i);
                    if (recyclerView.getWindowVisibility() == 0) {
                        jMax = Math.max(recyclerView.getDrawingTime(), jMax);
                    }
                }
                if (jMax != 0) {
                    g(TimeUnit.MILLISECONDS.toNanos(jMax) + this.Y);
                }
            }
        } finally {
            this.X = 0L;
            ax.Y.u.b();
        }
    }
}
