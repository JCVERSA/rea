package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import ax.p035c0.C1832a;
import ax.p035c0.C1839d0;
import ax.p035c0.C1847h0;
import ax.p051d0.C1884b;
import ax.p051d0.H;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import j$.util.DesugarCollections;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements ax.p035c0.D {
    static boolean J1;
    static boolean K1;
    private static final int[] L1 = {R.attr.nestedScrollingEnabled};
    private static final float M1 = (float) (Math.log(0.78d) / Math.log(0.9d));
    static final boolean N1;
    static final boolean O1;
    static final boolean P1;
    static final boolean Q1;
    private static final boolean R1;
    private static final boolean S1;
    private static final Class<?>[] T1;
    static final Interpolator U1;
    static final C V1;
    private final ArrayList<t> A0;
    private final int[] A1;
    private t B0;
    private final int[] B1;
    boolean C0;
    final int[] C1;
    boolean D0;
    final List<F> D1;
    boolean E0;
    private Runnable E1;
    boolean F0;
    private boolean F1;
    private int G0;
    private int G1;
    boolean H0;
    private int H1;
    boolean I0;
    private final androidx.recyclerview.widget.w.b I1;
    private boolean J0;
    private int K0;
    boolean L0;
    private final AccessibilityManager M0;
    private List<r> N0;
    boolean O0;
    boolean P0;
    private int Q0;
    private int R0;
    private l S0;
    private EdgeEffect T0;
    private EdgeEffect U0;
    private EdgeEffect V0;
    private EdgeEffect W0;
    m X0;
    private int Y0;
    private int Z0;
    private VelocityTracker a1;
    private int b1;
    private int c1;
    private int d1;
    private int e1;
    private int f1;
    private s g1;
    private final int h1;
    private final int i1;
    private float j1;
    private final y k0;
    private float k1;
    final w l0;
    private boolean l1;
    z m0;
    final E m1;
    a n0;
    androidx.recyclerview.widget.h n1;
    b o0;
    androidx.recyclerview.widget.h.b o1;
    final androidx.recyclerview.widget.w p0;
    final B p1;
    private final float q;
    boolean q0;
    private u q1;
    final Runnable r0;
    private List<u> r1;
    final Rect s0;
    boolean s1;
    private final Rect t0;
    boolean t1;
    final RectF u0;
    private m.b u1;
    h v0;
    boolean v1;
    p w0;
    androidx.recyclerview.widget.q w1;
    x x0;
    private k x1;
    final List<x> y0;
    private final int[] y1;
    final ArrayList<o> z0;
    private ax.p035c0.E z1;

    public static abstract class A {
        private RecyclerView b;
        private p c;
        private boolean d;
        private boolean e;
        private View f;
        private boolean h;
        private int a = -1;
        private final a g = new a(0, 0);

        public static class a {
            private int a;
            private int b;
            private int c;
            private int d;
            private Interpolator e;
            private boolean f;
            private int g;

            public a(int i, int i2) {
                this(i, i2, Integer.MIN_VALUE, null);
            }

            public a(int i, int i2, int i3, Interpolator interpolator) {
                this.d = -1;
                this.f = false;
                this.g = 0;
                this.a = i;
                this.b = i2;
                this.c = i3;
                this.e = interpolator;
            }

            private void e() {
                if (this.e != null && this.c < 1) {
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                }
                if (this.c < 1) {
                    throw new IllegalStateException("Scroll duration must be a positive number");
                }
            }

            boolean a() {
                return this.d >= 0;
            }

            public void b(int i) {
                this.d = i;
            }

            void c(RecyclerView recyclerView) {
                int i = this.d;
                if (i >= 0) {
                    this.d = -1;
                    recyclerView.G0(i);
                    this.f = false;
                } else {
                    if (!this.f) {
                        this.g = 0;
                        return;
                    }
                    e();
                    recyclerView.m1.e(this.a, this.b, this.c, this.e);
                    int i2 = this.g + 1;
                    this.g = i2;
                    if (i2 > 10) {
                        Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                    }
                    this.f = false;
                }
            }

            public void d(int i, int i2, int i3, Interpolator interpolator) {
                this.a = i;
                this.b = i2;
                this.c = i3;
                this.e = interpolator;
                this.f = true;
            }
        }

        public interface b {
            PointF c(int i);
        }

        public PointF a(int i) {
            Object objE = e();
            if (objE instanceof b) {
                return ((b) objE).c(i);
            }
            Log.w("RecyclerView", "You should override computeScrollVectorForPosition when the LayoutManager does not implement " + b.class.getCanonicalName());
            return null;
        }

        public View b(int i) {
            return this.b.w0.I(i);
        }

        public int c() {
            return this.b.w0.P();
        }

        public int d(View view) {
            return this.b.l0(view);
        }

        public p e() {
            return this.c;
        }

        public int f() {
            return this.a;
        }

        public boolean g() {
            return this.d;
        }

        public boolean h() {
            return this.e;
        }

        protected void i(PointF pointF) {
            float f = pointF.x;
            float f2 = pointF.y;
            float fSqrt = (float) Math.sqrt((f * f) + (f2 * f2));
            pointF.x /= fSqrt;
            pointF.y /= fSqrt;
        }

        void j(int i, int i2) {
            PointF pointFA;
            RecyclerView recyclerView = this.b;
            if (this.a == -1 || recyclerView == null) {
                r();
            }
            if (this.d && this.f == null && this.c != null && (pointFA = a(this.a)) != null) {
                float f = pointFA.x;
                if (f != 0.0f || pointFA.y != 0.0f) {
                    recyclerView.v1((int) Math.signum(f), (int) Math.signum(pointFA.y), null);
                }
            }
            this.d = false;
            View view = this.f;
            if (view != null) {
                if (d(view) == this.a) {
                    o(this.f, recyclerView.p1, this.g);
                    this.g.c(recyclerView);
                    r();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f = null;
                }
            }
            if (this.e) {
                l(i, i2, recyclerView.p1, this.g);
                boolean zA = this.g.a();
                this.g.c(recyclerView);
                if (zA && this.e) {
                    this.d = true;
                    recyclerView.m1.d();
                }
            }
        }

        protected void k(View view) {
            if (d(view) == f()) {
                this.f = view;
                if (RecyclerView.K1) {
                    Log.d("RecyclerView", "smooth scroll target view has been attached");
                }
            }
        }

        protected abstract void l(int i, int i2, B b2, a aVar);

        protected abstract void m();

        protected abstract void n();

        protected abstract void o(View view, B b2, a aVar);

        public void p(int i) {
            this.a = i;
        }

        void q(RecyclerView recyclerView, p pVar) {
            recyclerView.m1.f();
            if (this.h) {
                Log.w("RecyclerView", "An instance of " + getClass().getSimpleName() + " was started more than once. Each instance of" + getClass().getSimpleName() + " is intended to only be used once. You should create a new instance for each use.");
            }
            this.b = recyclerView;
            this.c = pVar;
            int i = this.a;
            if (i == -1) {
                throw new IllegalArgumentException("Invalid target position");
            }
            recyclerView.p1.a = i;
            this.e = true;
            this.d = true;
            this.f = b(f());
            m();
            this.b.m1.d();
            this.h = true;
        }

        protected final void r() {
            if (this.e) {
                this.e = false;
                n();
                this.b.p1.a = -1;
                this.f = null;
                this.a = -1;
                this.d = false;
                this.c.k1(this);
                this.c = null;
                this.b = null;
            }
        }
    }

    public static class B {
        private SparseArray<Object> b;
        int m;
        long n;
        int o;
        int p;
        int q;
        int a = -1;
        int c = 0;
        int d = 0;
        int e = 1;
        int f = 0;
        boolean g = false;
        boolean h = false;
        boolean i = false;
        boolean j = false;
        boolean k = false;
        boolean l = false;

        void a(int i) {
            if ((this.e & i) != 0) {
                return;
            }
            throw new IllegalStateException("Layout state should be one of " + Integer.toBinaryString(i) + " but it is " + Integer.toBinaryString(this.e));
        }

        public int b() {
            return this.h ? this.c - this.d : this.f;
        }

        public int c() {
            return this.a;
        }

        public boolean d() {
            return this.a != -1;
        }

        public boolean e() {
            return this.h;
        }

        void f(h hVar) {
            this.e = 1;
            this.f = hVar.l();
            this.h = false;
            this.i = false;
            this.j = false;
        }

        public boolean g() {
            return this.l;
        }

        public String toString() {
            return "State{mTargetPosition=" + this.a + ", mData=" + this.b + ", mItemCount=" + this.f + ", mIsMeasuring=" + this.j + ", mPreviousLayoutItemCount=" + this.c + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.d + ", mStructureChanged=" + this.g + ", mInPreLayout=" + this.h + ", mRunSimpleAnimations=" + this.k + ", mRunPredictiveAnimations=" + this.l + '}';
        }
    }

    static class C extends l {
        C() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.l
        protected EdgeEffect a(RecyclerView recyclerView, int i) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    public static abstract class D {
    }

    class E implements Runnable {
        private int X;
        OverScroller Y;
        Interpolator Z;
        private boolean k0;
        private boolean l0;
        private int q;

        E() {
            Interpolator interpolator = RecyclerView.U1;
            this.Z = interpolator;
            this.k0 = false;
            this.l0 = false;
            this.Y = new OverScroller(RecyclerView.this.getContext(), interpolator);
        }

        private int a(int i, int i2) {
            int iAbs = Math.abs(i);
            int iAbs2 = Math.abs(i2);
            boolean z = iAbs > iAbs2;
            RecyclerView recyclerView = RecyclerView.this;
            int width = z ? recyclerView.getWidth() : recyclerView.getHeight();
            if (!z) {
                iAbs = iAbs2;
            }
            return Math.min((int) (((iAbs / width) + 1.0f) * 300.0f), 2000);
        }

        private void c() {
            RecyclerView.this.removeCallbacks(this);
            C1839d0.d0(RecyclerView.this, this);
        }

        public void b(int i, int i2) {
            RecyclerView.this.setScrollState(2);
            this.X = 0;
            this.q = 0;
            Interpolator interpolator = this.Z;
            Interpolator interpolator2 = RecyclerView.U1;
            if (interpolator != interpolator2) {
                this.Z = interpolator2;
                this.Y = new OverScroller(RecyclerView.this.getContext(), interpolator2);
            }
            this.Y.fling(0, 0, i, i2, Integer.MIN_VALUE, SubsamplingScaleImageView.TILE_SIZE_AUTO, Integer.MIN_VALUE, SubsamplingScaleImageView.TILE_SIZE_AUTO);
            d();
        }

        void d() {
            if (this.k0) {
                this.l0 = true;
            } else {
                c();
            }
        }

        public void e(int i, int i2, int i3, Interpolator interpolator) {
            if (i3 == Integer.MIN_VALUE) {
                i3 = a(i, i2);
            }
            int i4 = i3;
            if (interpolator == null) {
                interpolator = RecyclerView.U1;
            }
            if (this.Z != interpolator) {
                this.Z = interpolator;
                this.Y = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.X = 0;
            this.q = 0;
            RecyclerView.this.setScrollState(2);
            this.Y.startScroll(0, 0, i, i2, i4);
            if (Build.VERSION.SDK_INT < 23) {
                this.Y.computeScrollOffset();
            }
            d();
        }

        public void f() {
            RecyclerView.this.removeCallbacks(this);
            this.Y.abortAnimation();
        }

        @Override // java.lang.Runnable
        public void run() {
            int i;
            int i2;
            int i3;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.w0 == null) {
                f();
                return;
            }
            this.l0 = false;
            this.k0 = true;
            recyclerView.A();
            OverScroller overScroller = this.Y;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i4 = currX - this.q;
                int i5 = currY - this.X;
                this.q = currX;
                this.X = currY;
                int iX = RecyclerView.this.x(i4);
                int iZ = RecyclerView.this.z(i5);
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.C1;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.L(iX, iZ, iArr, null, 1)) {
                    int[] iArr2 = RecyclerView.this.C1;
                    iX -= iArr2[0];
                    iZ -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.w(iX, iZ);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.v0 != null) {
                    int[] iArr3 = recyclerView3.C1;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.v1(iX, iZ, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.C1;
                    int i6 = iArr4[0];
                    int i7 = iArr4[1];
                    iX -= i6;
                    iZ -= i7;
                    A a = recyclerView4.w0.g;
                    if (a != null && !a.g() && a.h()) {
                        int iB = RecyclerView.this.p1.b();
                        if (iB == 0) {
                            a.r();
                        } else if (a.f() >= iB) {
                            a.p(iB - 1);
                            a.j(i6, i7);
                        } else {
                            a.j(i6, i7);
                        }
                    }
                    i2 = i7;
                    i = i6;
                } else {
                    i = 0;
                    i2 = 0;
                }
                int i8 = iX;
                int i9 = iZ;
                if (!RecyclerView.this.z0.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.C1;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.M(i, i2, i8, i9, null, 1, iArr5);
                RecyclerView recyclerView6 = RecyclerView.this;
                int[] iArr6 = recyclerView6.C1;
                int i10 = i8 - iArr6[0];
                int i11 = i9 - iArr6[1];
                if (i != 0 || i2 != 0) {
                    recyclerView6.O(i, i2);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i10 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i11 != 0));
                A a2 = RecyclerView.this.w0.g;
                if ((a2 == null || !a2.g()) && z) {
                    if (RecyclerView.this.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        if (i10 < 0) {
                            i3 = -currVelocity;
                        } else {
                            i3 = i10 > 0 ? currVelocity : 0;
                        }
                        if (i11 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i11 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView.this.a(i3, currVelocity);
                    }
                    if (RecyclerView.Q1) {
                        RecyclerView.this.o1.b();
                    }
                } else {
                    d();
                    RecyclerView recyclerView7 = RecyclerView.this;
                    androidx.recyclerview.widget.h hVar = recyclerView7.n1;
                    if (hVar != null) {
                        hVar.f(recyclerView7, i, i2);
                    }
                }
            }
            A a3 = RecyclerView.this.w0.g;
            if (a3 != null && a3.g()) {
                a3.j(0, 0);
            }
            this.k0 = false;
            if (this.l0) {
                c();
            } else {
                RecyclerView.this.setScrollState(0);
                RecyclerView.this.K1(1);
            }
        }
    }

    public static abstract class F {
        private static final List<Object> t = Collections.EMPTY_LIST;
        public final View a;
        WeakReference<RecyclerView> b;
        int j;
        RecyclerView r;
        h<? extends F> s;
        int c = -1;
        int d = -1;
        long e = -1;
        int f = -1;
        int g = -1;
        F h = null;
        F i = null;
        List<Object> k = null;
        List<Object> l = null;
        private int m = 0;
        w n = null;
        boolean o = false;
        private int p = 0;
        int q = -1;

        public F(View view) {
            if (view == null) {
                throw new IllegalArgumentException("itemView may not be null");
            }
            this.a = view;
        }

        private void g() {
            if (this.k == null) {
                ArrayList arrayList = new ArrayList();
                this.k = arrayList;
                this.l = DesugarCollections.unmodifiableList(arrayList);
            }
        }

        boolean A() {
            return (this.j & 2) != 0;
        }

        void B(int i, boolean z) {
            if (this.d == -1) {
                this.d = this.c;
            }
            if (this.g == -1) {
                this.g = this.c;
            }
            if (z) {
                this.g += i;
            }
            this.c += i;
            if (this.a.getLayoutParams() != null) {
                ((q) this.a.getLayoutParams()).c = true;
            }
        }

        void C(RecyclerView recyclerView) {
            int i = this.q;
            if (i != -1) {
                this.p = i;
            } else {
                this.p = C1839d0.z(this.a);
            }
            recyclerView.y1(this, 4);
        }

        void D(RecyclerView recyclerView) {
            recyclerView.y1(this, this.p);
            this.p = 0;
        }

        void E() {
            if (RecyclerView.J1 && y()) {
                throw new IllegalStateException("Attempting to reset temp-detached ViewHolder: " + this + ". ViewHolders should be fully detached before resetting.");
            }
            this.j = 0;
            this.c = -1;
            this.d = -1;
            this.e = -1L;
            this.g = -1;
            this.m = 0;
            this.h = null;
            this.i = null;
            d();
            this.p = 0;
            this.q = -1;
            RecyclerView.u(this);
        }

        void F() {
            if (this.d == -1) {
                this.d = this.c;
            }
        }

        void G(int i, int i2) {
            this.j = (i & i2) | (this.j & (~i2));
        }

        public final void H(boolean z) {
            int i = this.m;
            int i2 = z ? i - 1 : i + 1;
            this.m = i2;
            if (i2 < 0) {
                this.m = 0;
                if (RecyclerView.J1) {
                    throw new RuntimeException("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                }
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
            } else if (!z && i2 == 1) {
                this.j |= 16;
            } else if (z && i2 == 0) {
                this.j &= -17;
            }
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "setIsRecyclable val:" + z + ":" + this);
            }
        }

        void I(w wVar, boolean z) {
            this.n = wVar;
            this.o = z;
        }

        boolean J() {
            return (this.j & 16) != 0;
        }

        boolean K() {
            return (this.j & 128) != 0;
        }

        void L() {
            this.n.O(this);
        }

        boolean M() {
            return (this.j & 32) != 0;
        }

        void a(Object obj) {
            if (obj == null) {
                b(1024);
            } else if ((1024 & this.j) == 0) {
                g();
                this.k.add(obj);
            }
        }

        void b(int i) {
            this.j = i | this.j;
        }

        void c() {
            this.d = -1;
            this.g = -1;
        }

        void d() {
            List<Object> list = this.k;
            if (list != null) {
                list.clear();
            }
            this.j &= -1025;
        }

        void e() {
            this.j &= -33;
        }

        void f() {
            this.j &= -257;
        }

        boolean h() {
            return (this.j & 16) == 0 && C1839d0.O(this.a);
        }

        void i(int i, int i2, boolean z) {
            b(8);
            B(i2, z);
            this.c = i;
        }

        public final int j() {
            RecyclerView recyclerView = this.r;
            if (recyclerView == null) {
                return -1;
            }
            return recyclerView.i0(this);
        }

        public final int k() {
            RecyclerView recyclerView;
            h adapter;
            int iI0;
            if (this.s == null || (recyclerView = this.r) == null || (adapter = recyclerView.getAdapter()) == null || (iI0 = this.r.i0(this)) == -1) {
                return -1;
            }
            return adapter.k(this.s, this, iI0);
        }

        public final long l() {
            return this.e;
        }

        public final int m() {
            return this.f;
        }

        public final int n() {
            int i = this.g;
            return i == -1 ? this.c : i;
        }

        public final int o() {
            return this.d;
        }

        List<Object> p() {
            if ((this.j & 1024) != 0) {
                return t;
            }
            List<Object> list = this.k;
            return (list == null || list.size() == 0) ? t : this.l;
        }

        boolean q(int i) {
            return (i & this.j) != 0;
        }

        boolean r() {
            return (this.j & 512) != 0 || u();
        }

        boolean s() {
            return (this.a.getParent() == null || this.a.getParent() == this.r) ? false : true;
        }

        boolean t() {
            return (this.j & 1) != 0;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder((getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName()) + "{" + Integer.toHexString(hashCode()) + " position=" + this.c + " id=" + this.e + ", oldPos=" + this.d + ", pLpos:" + this.g);
            if (x()) {
                sb.append(" scrap ");
                sb.append(this.o ? "[changeScrap]" : "[attachedScrap]");
            }
            if (u()) {
                sb.append(" invalid");
            }
            if (!t()) {
                sb.append(" unbound");
            }
            if (A()) {
                sb.append(" update");
            }
            if (w()) {
                sb.append(" removed");
            }
            if (K()) {
                sb.append(" ignored");
            }
            if (y()) {
                sb.append(" tmpDetached");
            }
            if (!v()) {
                sb.append(" not recyclable(" + this.m + ")");
            }
            if (r()) {
                sb.append(" undefined adapter position");
            }
            if (this.a.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        boolean u() {
            return (this.j & 4) != 0;
        }

        public final boolean v() {
            return (this.j & 16) == 0 && !C1839d0.O(this.a);
        }

        boolean w() {
            return (this.j & 8) != 0;
        }

        boolean x() {
            return this.n != null;
        }

        boolean y() {
            return (this.j & 256) != 0;
        }

        boolean z() {
            return (this.j & 2) != 0;
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$a, reason: case insensitive filesystem */
    class RunnableC0667a implements Runnable {
        RunnableC0667a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.F0 || recyclerView.isLayoutRequested()) {
                return;
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            if (!recyclerView2.C0) {
                recyclerView2.requestLayout();
            } else if (recyclerView2.I0) {
                recyclerView2.H0 = true;
            } else {
                recyclerView2.A();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$b, reason: case insensitive filesystem */
    class RunnableC0668b implements Runnable {
        RunnableC0668b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            m mVar = RecyclerView.this.X0;
            if (mVar != null) {
                mVar.v();
            }
            RecyclerView.this.v1 = false;
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$c, reason: case insensitive filesystem */
    class InterpolatorC0669c implements Interpolator {
        InterpolatorC0669c() {
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$d, reason: case insensitive filesystem */
    class C0670d implements androidx.recyclerview.widget.w.b {
        C0670d() {
        }

        @Override // androidx.recyclerview.widget.w.b
        public void a(F f) {
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.w0.r1(f.a, recyclerView.l0);
        }

        @Override // androidx.recyclerview.widget.w.b
        public void b(F f, m.c cVar, m.c cVar2) {
            RecyclerView.this.o(f, cVar, cVar2);
        }

        @Override // androidx.recyclerview.widget.w.b
        public void c(F f, m.c cVar, m.c cVar2) {
            RecyclerView.this.l0.O(f);
            RecyclerView.this.q(f, cVar, cVar2);
        }

        @Override // androidx.recyclerview.widget.w.b
        public void d(F f, m.c cVar, m.c cVar2) {
            f.H(false);
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.O0) {
                if (recyclerView.X0.b(f, f, cVar, cVar2)) {
                    RecyclerView.this.Y0();
                }
            } else if (recyclerView.X0.d(f, cVar, cVar2)) {
                RecyclerView.this.Y0();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$e, reason: case insensitive filesystem */
    class C0671e implements b.InterfaceC0040b {
        C0671e() {
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public View a(int i) {
            return RecyclerView.this.getChildAt(i);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void b(View view) {
            F fN0 = RecyclerView.n0(view);
            if (fN0 != null) {
                fN0.C(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public int c() {
            return RecyclerView.this.getChildCount();
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void d() {
            int iC = c();
            for (int i = 0; i < iC; i++) {
                View viewA = a(i);
                RecyclerView.this.F(viewA);
                viewA.clearAnimation();
            }
            RecyclerView.this.removeAllViews();
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public int e(View view) {
            return RecyclerView.this.indexOfChild(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public F f(View view) {
            return RecyclerView.n0(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void g(int i) {
            View viewA = a(i);
            if (viewA != null) {
                F fN0 = RecyclerView.n0(viewA);
                if (fN0 != null) {
                    if (fN0.y() && !fN0.K()) {
                        throw new IllegalArgumentException("called detach on an already detached child " + fN0 + RecyclerView.this.V());
                    }
                    if (RecyclerView.K1) {
                        Log.d("RecyclerView", "tmpDetach " + fN0);
                    }
                    fN0.b(256);
                }
            } else if (RecyclerView.J1) {
                throw new IllegalArgumentException("No view at offset " + i + RecyclerView.this.V());
            }
            RecyclerView.this.detachViewFromParent(i);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void h(View view) {
            F fN0 = RecyclerView.n0(view);
            if (fN0 != null) {
                fN0.D(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void i(View view, int i) {
            RecyclerView.this.addView(view, i);
            RecyclerView.this.E(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void j(int i) {
            View childAt = RecyclerView.this.getChildAt(i);
            if (childAt != null) {
                RecyclerView.this.F(childAt);
                childAt.clearAnimation();
            }
            RecyclerView.this.removeViewAt(i);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0040b
        public void k(View view, int i, ViewGroup.LayoutParams layoutParams) {
            F fN0 = RecyclerView.n0(view);
            if (fN0 != null) {
                if (!fN0.y() && !fN0.K()) {
                    throw new IllegalArgumentException("Called attach on a child which is not detached: " + fN0 + RecyclerView.this.V());
                }
                if (RecyclerView.K1) {
                    Log.d("RecyclerView", "reAttach " + fN0);
                }
                fN0.f();
            } else if (RecyclerView.J1) {
                throw new IllegalArgumentException("No ViewHolder found for child: " + view + ", index: " + i + RecyclerView.this.V());
            }
            RecyclerView.this.attachViewToParent(view, i, layoutParams);
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.RecyclerView$f, reason: case insensitive filesystem */
    class C0672f implements a.InterfaceC0039a {
        C0672f() {
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void a(int i, int i2) {
            RecyclerView.this.O0(i, i2);
            RecyclerView.this.s1 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void b(a.b bVar) {
            i(bVar);
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void c(int i, int i2, Object obj) {
            RecyclerView.this.N1(i, i2, obj);
            RecyclerView.this.t1 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void d(a.b bVar) {
            i(bVar);
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public F e(int i) {
            F fG0 = RecyclerView.this.g0(i, true);
            if (fG0 == null) {
                return null;
            }
            if (!RecyclerView.this.o0.n(fG0.a)) {
                return fG0;
            }
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "assuming view holder cannot be find because it is hidden");
            }
            return null;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void f(int i, int i2) {
            RecyclerView.this.P0(i, i2, false);
            RecyclerView.this.s1 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void g(int i, int i2) {
            RecyclerView.this.N0(i, i2);
            RecyclerView.this.s1 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0039a
        public void h(int i, int i2) {
            RecyclerView.this.P0(i, i2, true);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.s1 = true;
            recyclerView.p1.d += i2;
        }

        void i(a.b bVar) {
            int i = bVar.a;
            if (i == 1) {
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.w0.W0(recyclerView, bVar.b, bVar.d);
                return;
            }
            if (i == 2) {
                RecyclerView recyclerView2 = RecyclerView.this;
                recyclerView2.w0.Z0(recyclerView2, bVar.b, bVar.d);
            } else if (i == 4) {
                RecyclerView recyclerView3 = RecyclerView.this;
                recyclerView3.w0.b1(recyclerView3, bVar.b, bVar.d, bVar.c);
            } else {
                if (i != 8) {
                    return;
                }
                RecyclerView recyclerView4 = RecyclerView.this;
                recyclerView4.w0.Y0(recyclerView4, bVar.b, bVar.d, 1);
            }
        }
    }

    static /* synthetic */ class g {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[h.a.values().length];
            a = iArr;
            try {
                iArr[h.a.PREVENT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[h.a.PREVENT_WHEN_EMPTY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public static abstract class h<VH extends F> {
        private final i a = new i();
        private boolean b = false;
        private a c = a.ALLOW;

        public enum a {
            ALLOW,
            PREVENT_WHEN_EMPTY,
            PREVENT
        }

        public void A(RecyclerView recyclerView) {
        }

        public abstract void B(VH vh, int i);

        public void C(VH vh, int i, List<Object> list) {
            B(vh, i);
        }

        public abstract VH D(ViewGroup viewGroup, int i);

        public void E(RecyclerView recyclerView) {
        }

        public boolean F(VH vh) {
            return false;
        }

        public void G(VH vh) {
        }

        public void H(VH vh) {
        }

        public void I(VH vh) {
        }

        public void J(j jVar) {
            this.a.registerObserver(jVar);
        }

        public void K(boolean z) {
            if (p()) {
                throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
            }
            this.b = z;
        }

        public void L(a aVar) {
            this.c = aVar;
            this.a.h();
        }

        public void M(j jVar) {
            this.a.unregisterObserver(jVar);
        }

        /* JADX WARN: Multi-variable type inference failed */
        public final void h(VH vh, int i) {
            boolean z = vh.s == null;
            if (z) {
                vh.c = i;
                if (q()) {
                    vh.e = m(i);
                }
                vh.G(1, 519);
                ax.Y.u.a("RV OnBindView");
            }
            vh.s = this;
            if (RecyclerView.J1) {
                if (vh.a.getParent() == null && C1839d0.Q(vh.a) != vh.y()) {
                    throw new IllegalStateException("Temp-detached state out of sync with reality. holder.isTmpDetached(): " + vh.y() + ", attached to window: " + C1839d0.Q(vh.a) + ", holder: " + vh);
                }
                if (vh.a.getParent() == null && C1839d0.Q(vh.a)) {
                    throw new IllegalStateException("Attempting to bind attached holder with no parent (AKA temp detached): " + vh);
                }
            }
            C(vh, i, vh.p());
            if (z) {
                vh.d();
                ViewGroup.LayoutParams layoutParams = vh.a.getLayoutParams();
                if (layoutParams instanceof q) {
                    ((q) layoutParams).c = true;
                }
                ax.Y.u.b();
            }
        }

        boolean i() {
            int i = g.a[this.c.ordinal()];
            return i != 1 && (i != 2 || l() > 0);
        }

        public final VH j(ViewGroup viewGroup, int i) {
            try {
                ax.Y.u.a("RV CreateView");
                VH vh = (VH) D(viewGroup, i);
                if (vh.a.getParent() != null) {
                    throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
                }
                vh.f = i;
                ax.Y.u.b();
                return vh;
            } catch (Throwable th) {
                ax.Y.u.b();
                throw th;
            }
        }

        public int k(h<? extends F> hVar, F f, int i) {
            if (hVar == this) {
                return i;
            }
            return -1;
        }

        public abstract int l();

        public long m(int i) {
            return -1L;
        }

        public int n(int i) {
            return 0;
        }

        public final a o() {
            return this.c;
        }

        public final boolean p() {
            return this.a.a();
        }

        public final boolean q() {
            return this.b;
        }

        public final void r() {
            this.a.b();
        }

        public final void s(int i) {
            this.a.d(i, 1);
        }

        public final void t(int i, Object obj) {
            this.a.e(i, 1, obj);
        }

        public final void u(int i) {
            this.a.f(i, 1);
        }

        public final void v(int i, int i2) {
            this.a.c(i, i2);
        }

        public final void w(int i, int i2, Object obj) {
            this.a.e(i, i2, obj);
        }

        public final void x(int i, int i2) {
            this.a.f(i, i2);
        }

        public final void y(int i, int i2) {
            this.a.g(i, i2);
        }

        public final void z(int i) {
            this.a.g(i, 1);
        }
    }

    static class i extends Observable<j> {
        i() {
        }

        public boolean a() {
            return !((Observable) this).mObservers.isEmpty();
        }

        public void b() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).a();
            }
        }

        public void c(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).e(i, i2, 1);
            }
        }

        public void d(int i, int i2) {
            e(i, i2, null);
        }

        public void e(int i, int i2, Object obj) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).c(i, i2, obj);
            }
        }

        public void f(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).d(i, i2);
            }
        }

        public void g(int i, int i2) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).f(i, i2);
            }
        }

        public void h() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((j) ((Observable) this).mObservers.get(size)).g();
            }
        }
    }

    public static abstract class j {
        public void a() {
        }

        public void b(int i, int i2) {
        }

        public void c(int i, int i2, Object obj) {
            b(i, i2);
        }

        public void d(int i, int i2) {
        }

        public void e(int i, int i2, int i3) {
        }

        public void f(int i, int i2) {
        }

        public void g() {
        }
    }

    public interface k {
        int a(int i, int i2);
    }

    public static class l {
        protected EdgeEffect a(RecyclerView recyclerView, int i) {
            throw null;
        }
    }

    public static abstract class m {
        private b a = null;
        private ArrayList<a> b = new ArrayList<>();
        private long c = 120;
        private long d = 120;
        private long e = 250;
        private long f = 250;

        public interface a {
            void a();
        }

        interface b {
            void a(F f);
        }

        public static class c {
            public int a;
            public int b;
            public int c;
            public int d;

            public c a(F f) {
                return b(f, 0);
            }

            public c b(F f, int i) {
                View view = f.a;
                this.a = view.getLeft();
                this.b = view.getTop();
                this.c = view.getRight();
                this.d = view.getBottom();
                return this;
            }
        }

        static int e(F f) {
            int i = f.j;
            int i2 = i & 14;
            if (f.u()) {
                return 4;
            }
            if ((i & 4) == 0) {
                int iO = f.o();
                int iJ = f.j();
                if (iO != -1 && iJ != -1 && iO != iJ) {
                    return i2 | 2048;
                }
            }
            return i2;
        }

        public abstract boolean a(F f, c cVar, c cVar2);

        public abstract boolean b(F f, F f2, c cVar, c cVar2);

        public abstract boolean c(F f, c cVar, c cVar2);

        public abstract boolean d(F f, c cVar, c cVar2);

        public abstract boolean f(F f);

        public boolean g(F f, List<Object> list) {
            return f(f);
        }

        public final void h(F f) {
            s(f);
            b bVar = this.a;
            if (bVar != null) {
                bVar.a(f);
            }
        }

        public final void i() {
            int size = this.b.size();
            for (int i = 0; i < size; i++) {
                this.b.get(i).a();
            }
            this.b.clear();
        }

        public abstract void j(F f);

        public abstract void k();

        public long l() {
            return this.c;
        }

        public long m() {
            return this.f;
        }

        public long n() {
            return this.e;
        }

        public long o() {
            return this.d;
        }

        public abstract boolean p();

        public final boolean q(a aVar) {
            boolean zP = p();
            if (aVar != null) {
                if (!zP) {
                    aVar.a();
                    return zP;
                }
                this.b.add(aVar);
            }
            return zP;
        }

        public c r() {
            return new c();
        }

        public void s(F f) {
        }

        public c t(B b2, F f) {
            return r().a(f);
        }

        public c u(B b2, F f, int i, List<Object> list) {
            return r().a(f);
        }

        public abstract void v();

        void w(b bVar) {
            this.a = bVar;
        }
    }

    private class n implements m.b {
        n() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.m.b
        public void a(F f) {
            f.H(true);
            if (f.h != null && f.i == null) {
                f.h = null;
            }
            f.i = null;
            if (f.J() || RecyclerView.this.j1(f.a) || !f.y()) {
                return;
            }
            RecyclerView.this.removeDetachedView(f.a, false);
        }
    }

    public static abstract class o {
        @Deprecated
        public void f(Rect rect, int i, RecyclerView recyclerView) {
            rect.set(0, 0, 0, 0);
        }

        public void g(Rect rect, View view, RecyclerView recyclerView, B b) {
            f(rect, ((q) view.getLayoutParams()).a(), recyclerView);
        }

        @Deprecated
        public void h(Canvas canvas, RecyclerView recyclerView) {
        }

        public void i(Canvas canvas, RecyclerView recyclerView, B b) {
            h(canvas, recyclerView);
        }

        @Deprecated
        public void j(Canvas canvas, RecyclerView recyclerView) {
        }

        public void k(Canvas canvas, RecyclerView recyclerView, B b) {
            j(canvas, recyclerView);
        }
    }

    public static abstract class p {
        androidx.recyclerview.widget.b a;
        RecyclerView b;
        private final androidx.recyclerview.widget.v.b c;
        private final androidx.recyclerview.widget.v.b d;
        androidx.recyclerview.widget.v e;
        androidx.recyclerview.widget.v f;
        A g;
        boolean h;
        boolean i;
        boolean j;
        private boolean k;
        private boolean l;
        int m;
        boolean n;
        private int o;
        private int p;
        private int q;
        private int r;

        class a implements androidx.recyclerview.widget.v.b {
            a() {
            }

            @Override // androidx.recyclerview.widget.v.b
            public View a(int i) {
                return p.this.O(i);
            }

            @Override // androidx.recyclerview.widget.v.b
            public int b(View view) {
                return p.this.W(view) - ((ViewGroup.MarginLayoutParams) ((q) view.getLayoutParams())).leftMargin;
            }

            @Override // androidx.recyclerview.widget.v.b
            public int c() {
                return p.this.j0();
            }

            @Override // androidx.recyclerview.widget.v.b
            public int d() {
                return p.this.t0() - p.this.k0();
            }

            @Override // androidx.recyclerview.widget.v.b
            public int e(View view) {
                return p.this.Z(view) + ((ViewGroup.MarginLayoutParams) ((q) view.getLayoutParams())).rightMargin;
            }
        }

        class b implements androidx.recyclerview.widget.v.b {
            b() {
            }

            @Override // androidx.recyclerview.widget.v.b
            public View a(int i) {
                return p.this.O(i);
            }

            @Override // androidx.recyclerview.widget.v.b
            public int b(View view) {
                return p.this.a0(view) - ((ViewGroup.MarginLayoutParams) ((q) view.getLayoutParams())).topMargin;
            }

            @Override // androidx.recyclerview.widget.v.b
            public int c() {
                return p.this.l0();
            }

            @Override // androidx.recyclerview.widget.v.b
            public int d() {
                return p.this.c0() - p.this.i0();
            }

            @Override // androidx.recyclerview.widget.v.b
            public int e(View view) {
                return p.this.U(view) + ((ViewGroup.MarginLayoutParams) ((q) view.getLayoutParams())).bottomMargin;
            }
        }

        public interface c {
            void a(int i, int i2);
        }

        public static class d {
            public int a;
            public int b;
            public boolean c;
            public boolean d;
        }

        public p() {
            a aVar = new a();
            this.c = aVar;
            b bVar = new b();
            this.d = bVar;
            this.e = new androidx.recyclerview.widget.v(aVar);
            this.f = new androidx.recyclerview.widget.v(bVar);
            this.h = false;
            this.i = false;
            this.j = false;
            this.k = true;
            this.l = true;
        }

        private void A1(w wVar, int i, View view) {
            F fN0 = RecyclerView.n0(view);
            if (fN0.K()) {
                if (RecyclerView.K1) {
                    Log.d("RecyclerView", "ignoring view " + fN0);
                    return;
                }
                return;
            }
            if (fN0.u() && !fN0.w() && !this.b.v0.q()) {
                v1(i);
                wVar.H(fN0);
            } else {
                D(i);
                wVar.I(view);
                this.b.p0.k(fN0);
            }
        }

        private static boolean B0(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (i3 > 0 && i != i3) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i;
            }
            return true;
        }

        private void E(int i, View view) {
            this.a.d(i);
        }

        /* JADX WARN: Code duplicated, block: B:10:0x001b  */
        /* JADX WARN: Code duplicated, block: B:5:0x0010  */
        public static int Q(int i, int i2, int i3, int i4, boolean z) {
            int iMax = Math.max(0, i - i3);
            if (z) {
                if (i4 >= 0) {
                    i2 = 1073741824;
                } else if (i4 != -1 || (i2 != Integer.MIN_VALUE && (i2 == 0 || i2 != 1073741824))) {
                    i2 = 0;
                    i4 = 0;
                } else {
                    i4 = iMax;
                }
            } else if (i4 >= 0) {
                i2 = 1073741824;
            } else {
                if (i4 != -1) {
                    if (i4 == -2) {
                        i2 = (i2 == Integer.MIN_VALUE || i2 == 1073741824) ? Integer.MIN_VALUE : 0;
                    } else {
                        i2 = 0;
                        i4 = 0;
                    }
                }
                i4 = iMax;
            }
            return View.MeasureSpec.makeMeasureSpec(i4, i2);
        }

        private int[] R(View view, Rect rect) {
            int iJ0 = j0();
            int iL0 = l0();
            int iT0 = t0() - k0();
            int iC0 = c0() - i0();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int iWidth = rect.width() + left;
            int iHeight = rect.height() + top;
            int i = left - iJ0;
            int iMin = Math.min(0, i);
            int i2 = top - iL0;
            int iMin2 = Math.min(0, i2);
            int i3 = iWidth - iT0;
            int iMax = Math.max(0, i3);
            int iMax2 = Math.max(0, iHeight - iC0);
            if (e0() != 1) {
                if (iMin == 0) {
                    iMin = Math.min(i, iMax);
                }
                iMax = iMin;
            } else if (iMax == 0) {
                iMax = Math.max(iMin, i3);
            }
            if (iMin2 == 0) {
                iMin2 = Math.min(i2, iMax2);
            }
            return new int[]{iMax, iMin2};
        }

        private void l(View view, int i, boolean z) {
            F fN0 = RecyclerView.n0(view);
            if (z || fN0.w()) {
                this.b.p0.b(fN0);
            } else {
                this.b.p0.p(fN0);
            }
            q qVar = (q) view.getLayoutParams();
            if (fN0.M() || fN0.x()) {
                if (fN0.x()) {
                    fN0.L();
                } else {
                    fN0.e();
                }
                this.a.c(view, i, view.getLayoutParams(), false);
            } else if (view.getParent() == this.b) {
                int iM = this.a.m(view);
                if (i == -1) {
                    i = this.a.g();
                }
                if (iM == -1) {
                    throw new IllegalStateException("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:" + this.b.indexOfChild(view) + this.b.V());
                }
                if (iM != i) {
                    this.b.w0.G0(iM, i);
                }
            } else {
                this.a.a(view, i, false);
                qVar.c = true;
                A a2 = this.g;
                if (a2 != null && a2.h()) {
                    this.g.k(view);
                }
            }
            if (qVar.d) {
                if (RecyclerView.K1) {
                    Log.d("RecyclerView", "consuming pending invalidate on child " + qVar.a);
                }
                fN0.a.invalidate();
                qVar.d = false;
            }
        }

        public static d n0(Context context, AttributeSet attributeSet, int i, int i2) {
            d dVar = new d();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.p149j2.d.a, i, i2);
            dVar.a = typedArrayObtainStyledAttributes.getInt(ax.p149j2.d.b, 1);
            dVar.b = typedArrayObtainStyledAttributes.getInt(ax.p149j2.d.l, 1);
            dVar.c = typedArrayObtainStyledAttributes.getBoolean(ax.p149j2.d.k, false);
            dVar.d = typedArrayObtainStyledAttributes.getBoolean(ax.p149j2.d.m, false);
            typedArrayObtainStyledAttributes.recycle();
            return dVar;
        }

        public static int t(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            if (mode != Integer.MIN_VALUE) {
                return mode != 1073741824 ? Math.max(i2, i3) : size;
            }
            return Math.min(size, Math.max(i2, i3));
        }

        private boolean y0(RecyclerView recyclerView, int i, int i2) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild == null) {
                return false;
            }
            int iJ0 = j0();
            int iL0 = l0();
            int iT0 = t0() - k0();
            int iC0 = c0() - i0();
            Rect rect = this.b.s0;
            V(focusedChild, rect);
            return rect.left - i < iT0 && rect.right - i > iJ0 && rect.top - i2 < iC0 && rect.bottom - i2 > iL0;
        }

        public int A(B b2) {
            return 0;
        }

        public boolean A0(w wVar, B b2) {
            return false;
        }

        public int B(B b2) {
            return 0;
        }

        @SuppressLint({"UnknownNullness"})
        public int B1(int i, w wVar, B b2) {
            return 0;
        }

        public void C(w wVar) {
            for (int iP = P() - 1; iP >= 0; iP--) {
                A1(wVar, iP, O(iP));
            }
        }

        public boolean C0() {
            A a2 = this.g;
            return a2 != null && a2.h();
        }

        public void C1(int i) {
            if (RecyclerView.K1) {
                Log.e("RecyclerView", "You MUST implement scrollToPosition. It will soon become abstract");
            }
        }

        public void D(int i) {
            E(i, O(i));
        }

        public boolean D0(View view, boolean z, boolean z2) {
            boolean z3 = this.e.b(view, 24579) && this.f.b(view, 24579);
            return z ? z3 : !z3;
        }

        @SuppressLint({"UnknownNullness"})
        public int D1(int i, w wVar, B b2) {
            return 0;
        }

        public void E0(View view, int i, int i2, int i3, int i4) {
            q qVar = (q) view.getLayoutParams();
            Rect rect = qVar.b;
            view.layout(i + rect.left + ((ViewGroup.MarginLayoutParams) qVar).leftMargin, i2 + rect.top + ((ViewGroup.MarginLayoutParams) qVar).topMargin, (i3 - rect.right) - ((ViewGroup.MarginLayoutParams) qVar).rightMargin, (i4 - rect.bottom) - ((ViewGroup.MarginLayoutParams) qVar).bottomMargin);
        }

        void E1(RecyclerView recyclerView) {
            F1(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }

        void F(RecyclerView recyclerView) {
            this.i = true;
            L0(recyclerView);
        }

        public void F0(View view, int i, int i2) {
            q qVar = (q) view.getLayoutParams();
            Rect rectS0 = this.b.s0(view);
            int i3 = i + rectS0.left + rectS0.right;
            int i4 = i2 + rectS0.top + rectS0.bottom;
            int iQ = Q(t0(), u0(), j0() + k0() + ((ViewGroup.MarginLayoutParams) qVar).leftMargin + ((ViewGroup.MarginLayoutParams) qVar).rightMargin + i3, ((ViewGroup.MarginLayoutParams) qVar).width, q());
            int iQ2 = Q(c0(), d0(), l0() + i0() + ((ViewGroup.MarginLayoutParams) qVar).topMargin + ((ViewGroup.MarginLayoutParams) qVar).bottomMargin + i4, ((ViewGroup.MarginLayoutParams) qVar).height, r());
            if (K1(view, iQ, iQ2, qVar)) {
                view.measure(iQ, iQ2);
            }
        }

        void F1(int i, int i2) {
            this.q = View.MeasureSpec.getSize(i);
            int mode = View.MeasureSpec.getMode(i);
            this.o = mode;
            if (mode == 0 && !RecyclerView.O1) {
                this.q = 0;
            }
            this.r = View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.p = mode2;
            if (mode2 != 0 || RecyclerView.O1) {
                return;
            }
            this.r = 0;
        }

        void G(RecyclerView recyclerView, w wVar) {
            this.i = false;
            N0(recyclerView, wVar);
        }

        public void G0(int i, int i2) {
            View viewO = O(i);
            if (viewO != null) {
                D(i);
                n(viewO, i2);
            } else {
                throw new IllegalArgumentException("Cannot move a child from non-existing index:" + i + this.b.toString());
            }
        }

        public void G1(int i, int i2) {
            this.b.setMeasuredDimension(i, i2);
        }

        public View H(View view) {
            View viewY;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null || (viewY = recyclerView.Y(view)) == null || this.a.n(viewY)) {
                return null;
            }
            return viewY;
        }

        public void H0(int i) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.L0(i);
            }
        }

        public void H1(Rect rect, int i, int i2) {
            G1(t(i, rect.width() + j0() + k0(), h0()), t(i2, rect.height() + l0() + i0(), g0()));
        }

        public View I(int i) {
            int iP = P();
            for (int i2 = 0; i2 < iP; i2++) {
                View viewO = O(i2);
                F fN0 = RecyclerView.n0(viewO);
                if (fN0 != null && fN0.n() == i && !fN0.K() && (this.b.p1.e() || !fN0.w())) {
                    return viewO;
                }
            }
            return null;
        }

        public void I0(int i) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.M0(i);
            }
        }

        void I1(int i, int i2) {
            int iP = P();
            if (iP == 0) {
                this.b.C(i, i2);
                return;
            }
            int i3 = Integer.MIN_VALUE;
            int i4 = Integer.MIN_VALUE;
            int i5 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
            int i6 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
            for (int i7 = 0; i7 < iP; i7++) {
                View viewO = O(i7);
                Rect rect = this.b.s0;
                V(viewO, rect);
                int i8 = rect.left;
                if (i8 < i5) {
                    i5 = i8;
                }
                int i9 = rect.right;
                if (i9 > i3) {
                    i3 = i9;
                }
                int i10 = rect.top;
                if (i10 < i6) {
                    i6 = i10;
                }
                int i11 = rect.bottom;
                if (i11 > i4) {
                    i4 = i11;
                }
            }
            this.b.s0.set(i5, i6, i3, i4);
            H1(this.b.s0, i, i2);
        }

        @SuppressLint({"UnknownNullness"})
        public abstract q J();

        public void J0(h hVar, h hVar2) {
        }

        void J1(RecyclerView recyclerView) {
            if (recyclerView == null) {
                this.b = null;
                this.a = null;
                this.q = 0;
                this.r = 0;
            } else {
                this.b = recyclerView;
                this.a = recyclerView.o0;
                this.q = recyclerView.getWidth();
                this.r = recyclerView.getHeight();
            }
            this.o = 1073741824;
            this.p = 1073741824;
        }

        @SuppressLint({"UnknownNullness"})
        public q K(Context context, AttributeSet attributeSet) {
            return new q(context, attributeSet);
        }

        public boolean K0(RecyclerView recyclerView, ArrayList<View> arrayList, int i, int i2) {
            return false;
        }

        boolean K1(View view, int i, int i2, q qVar) {
            return (!view.isLayoutRequested() && this.k && B0(view.getWidth(), i, ((ViewGroup.MarginLayoutParams) qVar).width) && B0(view.getHeight(), i2, ((ViewGroup.MarginLayoutParams) qVar).height)) ? false : true;
        }

        @SuppressLint({"UnknownNullness"})
        public q L(ViewGroup.LayoutParams layoutParams) {
            if (layoutParams instanceof q) {
                return new q((q) layoutParams);
            }
            return layoutParams instanceof ViewGroup.MarginLayoutParams ? new q((ViewGroup.MarginLayoutParams) layoutParams) : new q(layoutParams);
        }

        public void L0(RecyclerView recyclerView) {
        }

        boolean L1() {
            return false;
        }

        public int M() {
            return -1;
        }

        @Deprecated
        public void M0(RecyclerView recyclerView) {
        }

        boolean M1(View view, int i, int i2, q qVar) {
            return (this.k && B0(view.getMeasuredWidth(), i, ((ViewGroup.MarginLayoutParams) qVar).width) && B0(view.getMeasuredHeight(), i2, ((ViewGroup.MarginLayoutParams) qVar).height)) ? false : true;
        }

        public int N(View view) {
            return ((q) view.getLayoutParams()).b.bottom;
        }

        @SuppressLint({"UnknownNullness"})
        public void N0(RecyclerView recyclerView, w wVar) {
            M0(recyclerView);
        }

        @SuppressLint({"UnknownNullness"})
        public void N1(RecyclerView recyclerView, B b2, int i) {
            Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
        }

        public View O(int i) {
            androidx.recyclerview.widget.b bVar = this.a;
            if (bVar != null) {
                return bVar.f(i);
            }
            return null;
        }

        public View O0(View view, int i, w wVar, B b2) {
            return null;
        }

        @SuppressLint({"UnknownNullness"})
        public void O1(A a2) {
            A a3 = this.g;
            if (a3 != null && a2 != a3 && a3.h()) {
                this.g.r();
            }
            this.g = a2;
            a2.q(this.b, this);
        }

        public int P() {
            androidx.recyclerview.widget.b bVar = this.a;
            if (bVar != null) {
                return bVar.g();
            }
            return 0;
        }

        public void P0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.b;
            Q0(recyclerView.l0, recyclerView.p1, accessibilityEvent);
        }

        void P1() {
            A a2 = this.g;
            if (a2 != null) {
                a2.r();
            }
        }

        public void Q0(w wVar, B b2, AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.b;
            if (recyclerView == null || accessibilityEvent == null) {
                return;
            }
            boolean z = true;
            if (!recyclerView.canScrollVertically(1) && !this.b.canScrollVertically(-1) && !this.b.canScrollHorizontally(-1) && !this.b.canScrollHorizontally(1)) {
                z = false;
            }
            accessibilityEvent.setScrollable(z);
            h hVar = this.b.v0;
            if (hVar != null) {
                accessibilityEvent.setItemCount(hVar.l());
            }
        }

        public boolean Q1() {
            return false;
        }

        public void R0(w wVar, B b2, H h) {
            if (this.b.canScrollVertically(-1) || this.b.canScrollHorizontally(-1)) {
                h.a(8192);
                h.G0(true);
            }
            if (this.b.canScrollVertically(1) || this.b.canScrollHorizontally(1)) {
                h.a(4096);
                h.G0(true);
            }
            h.o0(H.e.a(p0(wVar, b2), T(wVar, b2), A0(wVar, b2), q0(wVar, b2)));
        }

        public boolean S() {
            RecyclerView recyclerView = this.b;
            return recyclerView != null && recyclerView.q0;
        }

        void S0(H h) {
            RecyclerView recyclerView = this.b;
            R0(recyclerView.l0, recyclerView.p1, h);
        }

        public int T(w wVar, B b2) {
            return -1;
        }

        void T0(View view, H h) {
            F fN0 = RecyclerView.n0(view);
            if (fN0 == null || fN0.w() || this.a.n(fN0.a)) {
                return;
            }
            RecyclerView recyclerView = this.b;
            U0(recyclerView.l0, recyclerView.p1, view, h);
        }

        public int U(View view) {
            return view.getBottom() + N(view);
        }

        public void U0(w wVar, B b2, View view, H h) {
        }

        public void V(View view, Rect rect) {
            RecyclerView.p0(view, rect);
        }

        public View V0(View view, int i) {
            return null;
        }

        public int W(View view) {
            return view.getLeft() - f0(view);
        }

        public void W0(RecyclerView recyclerView, int i, int i2) {
        }

        public int X(View view) {
            Rect rect = ((q) view.getLayoutParams()).b;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        public void X0(RecyclerView recyclerView) {
        }

        public int Y(View view) {
            Rect rect = ((q) view.getLayoutParams()).b;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        public void Y0(RecyclerView recyclerView, int i, int i2, int i3) {
        }

        public int Z(View view) {
            return view.getRight() + o0(view);
        }

        public void Z0(RecyclerView recyclerView, int i, int i2) {
        }

        public int a0(View view) {
            return view.getTop() - r0(view);
        }

        public void a1(RecyclerView recyclerView, int i, int i2) {
        }

        public View b0() {
            View focusedChild;
            RecyclerView recyclerView = this.b;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.a.n(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        public void b1(RecyclerView recyclerView, int i, int i2, Object obj) {
            a1(recyclerView, i, i2);
        }

        public int c0() {
            return this.r;
        }

        @SuppressLint({"UnknownNullness"})
        public void c1(w wVar, B b2) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public int d0() {
            return this.p;
        }

        @SuppressLint({"UnknownNullness"})
        public void d1(B b2) {
        }

        public int e0() {
            return C1839d0.B(this.b);
        }

        public void e1(w wVar, B b2, int i, int i2) {
            this.b.C(i, i2);
        }

        public int f() {
            RecyclerView recyclerView = this.b;
            h adapter = recyclerView != null ? recyclerView.getAdapter() : null;
            if (adapter != null) {
                return adapter.l();
            }
            return 0;
        }

        public int f0(View view) {
            return ((q) view.getLayoutParams()).b.left;
        }

        @Deprecated
        public boolean f1(RecyclerView recyclerView, View view, View view2) {
            return C0() || recyclerView.E0();
        }

        public int g0() {
            return C1839d0.C(this.b);
        }

        public boolean g1(RecyclerView recyclerView, B b2, View view, View view2) {
            return f1(recyclerView, view, view2);
        }

        @SuppressLint({"UnknownNullness"})
        public void h(View view) {
            i(view, -1);
        }

        public int h0() {
            return C1839d0.D(this.b);
        }

        @SuppressLint({"UnknownNullness"})
        public void h1(Parcelable parcelable) {
        }

        @SuppressLint({"UnknownNullness"})
        public void i(View view, int i) {
            l(view, i, true);
        }

        public int i0() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        public Parcelable i1() {
            return null;
        }

        @SuppressLint({"UnknownNullness"})
        public void j(View view) {
            k(view, -1);
        }

        public int j0() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        public void j1(int i) {
        }

        @SuppressLint({"UnknownNullness"})
        public void k(View view, int i) {
            l(view, i, false);
        }

        public int k0() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        void k1(A a2) {
            if (this.g == a2) {
                this.g = null;
            }
        }

        public int l0() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        boolean l1(int i, Bundle bundle) {
            RecyclerView recyclerView = this.b;
            return m1(recyclerView.l0, recyclerView.p1, i, bundle);
        }

        @SuppressLint({"UnknownNullness"})
        public void m(String str) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.r(str);
            }
        }

        public int m0(View view) {
            return ((q) view.getLayoutParams()).a();
        }

        /* JADX WARN: Code duplicated, block: B:23:0x0067 A[PHI: r9
          0x0067: PHI (r9v8 int) = (r9v5 int), (r9v11 int) binds: [B:29:0x0084, B:20:0x0057] A[DONT_GENERATE, DONT_INLINE]] */
        public boolean m1(w wVar, B b2, int i, Bundle bundle) {
            int iL0;
            int iJ0;
            int i2;
            int i3;
            if (this.b == null) {
                return false;
            }
            int iC0 = c0();
            int iT0 = t0();
            Rect rect = new Rect();
            if (this.b.getMatrix().isIdentity() && this.b.getGlobalVisibleRect(rect)) {
                iC0 = rect.height();
                iT0 = rect.width();
            }
            if (i == 4096) {
                iL0 = this.b.canScrollVertically(1) ? (iC0 - l0()) - i0() : 0;
                if (this.b.canScrollHorizontally(1)) {
                    iJ0 = (iT0 - j0()) - k0();
                    i2 = iL0;
                    i3 = iJ0;
                } else {
                    i2 = iL0;
                    i3 = 0;
                }
            } else if (i != 8192) {
                i3 = 0;
                i2 = 0;
            } else {
                iL0 = this.b.canScrollVertically(-1) ? -((iC0 - l0()) - i0()) : 0;
                if (this.b.canScrollHorizontally(-1)) {
                    iJ0 = -((iT0 - j0()) - k0());
                    i2 = iL0;
                    i3 = iJ0;
                } else {
                    i2 = iL0;
                    i3 = 0;
                }
            }
            if (i2 == 0 && i3 == 0) {
                return false;
            }
            this.b.E1(i3, i2, null, Integer.MIN_VALUE, true);
            return true;
        }

        public void n(View view, int i) {
            o(view, i, (q) view.getLayoutParams());
        }

        boolean n1(View view, int i, Bundle bundle) {
            RecyclerView recyclerView = this.b;
            return o1(recyclerView.l0, recyclerView.p1, view, i, bundle);
        }

        public void o(View view, int i, q qVar) {
            F fN0 = RecyclerView.n0(view);
            if (fN0.w()) {
                this.b.p0.b(fN0);
            } else {
                this.b.p0.p(fN0);
            }
            this.a.c(view, i, qVar, fN0.w());
        }

        public int o0(View view) {
            return ((q) view.getLayoutParams()).b.right;
        }

        public boolean o1(w wVar, B b2, View view, int i, Bundle bundle) {
            return false;
        }

        public void p(View view, Rect rect) {
            RecyclerView recyclerView = this.b;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.s0(view));
            }
        }

        public int p0(w wVar, B b2) {
            return -1;
        }

        public void p1(w wVar) {
            for (int iP = P() - 1; iP >= 0; iP--) {
                if (!RecyclerView.n0(O(iP)).K()) {
                    s1(iP, wVar);
                }
            }
        }

        public boolean q() {
            return false;
        }

        public int q0(w wVar, B b2) {
            return 0;
        }

        void q1(w wVar) {
            int iJ = wVar.j();
            for (int i = iJ - 1; i >= 0; i--) {
                View viewN = wVar.n(i);
                F fN0 = RecyclerView.n0(viewN);
                if (!fN0.K()) {
                    fN0.H(false);
                    if (fN0.y()) {
                        this.b.removeDetachedView(viewN, false);
                    }
                    m mVar = this.b.X0;
                    if (mVar != null) {
                        mVar.j(fN0);
                    }
                    fN0.H(true);
                    wVar.D(viewN);
                }
            }
            wVar.e();
            if (iJ > 0) {
                this.b.invalidate();
            }
        }

        public boolean r() {
            return false;
        }

        public int r0(View view) {
            return ((q) view.getLayoutParams()).b.top;
        }

        public void r1(View view, w wVar) {
            u1(view);
            wVar.G(view);
        }

        public boolean s(q qVar) {
            return qVar != null;
        }

        public void s0(View view, boolean z, Rect rect) {
            Matrix matrix;
            if (z) {
                Rect rect2 = ((q) view.getLayoutParams()).b;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
                RectF rectF = this.b.u0;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public void s1(int i, w wVar) {
            View viewO = O(i);
            v1(i);
            wVar.G(viewO);
        }

        public int t0() {
            return this.q;
        }

        public boolean t1(Runnable runnable) {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                return recyclerView.removeCallbacks(runnable);
            }
            return false;
        }

        @SuppressLint({"UnknownNullness"})
        public void u(int i, int i2, B b2, c cVar) {
        }

        public int u0() {
            return this.o;
        }

        @SuppressLint({"UnknownNullness"})
        public void u1(View view) {
            this.a.p(view);
        }

        @SuppressLint({"UnknownNullness"})
        public void v(int i, c cVar) {
        }

        boolean v0() {
            int iP = P();
            for (int i = 0; i < iP; i++) {
                ViewGroup.LayoutParams layoutParams = O(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
            return false;
        }

        public void v1(int i) {
            if (O(i) != null) {
                this.a.q(i);
            }
        }

        public int w(B b2) {
            return 0;
        }

        public boolean w0() {
            return this.i;
        }

        public boolean w1(RecyclerView recyclerView, View view, Rect rect, boolean z) {
            return x1(recyclerView, view, rect, z, false);
        }

        public int x(B b2) {
            return 0;
        }

        public boolean x0() {
            return this.j;
        }

        public boolean x1(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
            int[] iArrR = R(view, rect);
            int i = iArrR[0];
            int i2 = iArrR[1];
            if ((z2 && !y0(recyclerView, i, i2)) || (i == 0 && i2 == 0)) {
                return false;
            }
            if (z) {
                recyclerView.scrollBy(i, i2);
            } else {
                recyclerView.B1(i, i2);
            }
            return true;
        }

        public int y(B b2) {
            return 0;
        }

        public void y1() {
            RecyclerView recyclerView = this.b;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        public int z(B b2) {
            return 0;
        }

        public final boolean z0() {
            return this.l;
        }

        public void z1() {
            this.h = true;
        }
    }

    public static class q extends ViewGroup.MarginLayoutParams {
        F a;
        final Rect b;
        boolean c;
        boolean d;

        public q(int i, int i2) {
            super(i, i2);
            this.b = new Rect();
            this.c = true;
            this.d = false;
        }

        public q(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.b = new Rect();
            this.c = true;
            this.d = false;
        }

        public q(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.b = new Rect();
            this.c = true;
            this.d = false;
        }

        public q(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.b = new Rect();
            this.c = true;
            this.d = false;
        }

        public q(q qVar) {
            super((ViewGroup.LayoutParams) qVar);
            this.b = new Rect();
            this.c = true;
            this.d = false;
        }

        public int a() {
            return this.a.n();
        }

        public boolean b() {
            return this.a.z();
        }

        public boolean c() {
            return this.a.w();
        }

        public boolean d() {
            return this.a.u();
        }
    }

    public interface r {
        void a(View view);

        void d(View view);
    }

    public static abstract class s {
        public abstract boolean a(int i, int i2);
    }

    public interface t {
        void b(RecyclerView recyclerView, MotionEvent motionEvent);

        boolean c(RecyclerView recyclerView, MotionEvent motionEvent);

        void e(boolean z);
    }

    public static abstract class u {
        public void a(RecyclerView recyclerView, int i) {
        }

        public void b(RecyclerView recyclerView, int i, int i2) {
        }
    }

    public static class v {
        SparseArray<a> a = new SparseArray<>();
        int b = 0;
        Set<h<?>> c = Collections.newSetFromMap(new IdentityHashMap());

        static class a {
            final ArrayList<F> a = new ArrayList<>();
            int b = 5;
            long c = 0;
            long d = 0;

            a() {
            }
        }

        private a i(int i) {
            a aVar = this.a.get(i);
            if (aVar != null) {
                return aVar;
            }
            a aVar2 = new a();
            this.a.put(i, aVar2);
            return aVar2;
        }

        void a() {
            this.b++;
        }

        void b(h<?> hVar) {
            this.c.add(hVar);
        }

        public void c() {
            for (int i = 0; i < this.a.size(); i++) {
                a aVarValueAt = this.a.valueAt(i);
                ArrayList<F> arrayList = aVarValueAt.a;
                int size = arrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    F f = arrayList.get(i2);
                    i2++;
                    ax.p147j0.a.a(f.a);
                }
                aVarValueAt.a.clear();
            }
        }

        void d() {
            this.b--;
        }

        void e(h<?> hVar, boolean z) {
            this.c.remove(hVar);
            if (this.c.size() != 0 || z) {
                return;
            }
            for (int i = 0; i < this.a.size(); i++) {
                SparseArray<a> sparseArray = this.a;
                ArrayList<F> arrayList = sparseArray.get(sparseArray.keyAt(i)).a;
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    ax.p147j0.a.a(arrayList.get(i2).a);
                }
            }
        }

        void f(int i, long j) {
            a aVarI = i(i);
            aVarI.d = l(aVarI.d, j);
        }

        void g(int i, long j) {
            a aVarI = i(i);
            aVarI.c = l(aVarI.c, j);
        }

        public F h(int i) {
            a aVar = this.a.get(i);
            if (aVar == null || aVar.a.isEmpty()) {
                return null;
            }
            ArrayList<F> arrayList = aVar.a;
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (!arrayList.get(size).s()) {
                    return arrayList.remove(size);
                }
            }
            return null;
        }

        void j(h<?> hVar, h<?> hVar2, boolean z) {
            if (hVar != null) {
                d();
            }
            if (!z && this.b == 0) {
                c();
            }
            if (hVar2 != null) {
                a();
            }
        }

        public void k(F f) {
            int iM = f.m();
            ArrayList<F> arrayList = i(iM).a;
            if (this.a.get(iM).b <= arrayList.size()) {
                ax.p147j0.a.a(f.a);
            } else {
                if (RecyclerView.J1 && arrayList.contains(f)) {
                    throw new IllegalArgumentException("this scrap item already exists");
                }
                f.E();
                arrayList.add(f);
            }
        }

        long l(long j, long j2) {
            return j == 0 ? j2 : ((j / 4) * 3) + (j2 / 4);
        }

        boolean m(int i, long j, long j2) {
            long j3 = i(i).d;
            return j3 == 0 || j + j3 < j2;
        }

        boolean n(int i, long j, long j2) {
            long j3 = i(i).c;
            return j3 == 0 || j + j3 < j2;
        }
    }

    public final class w {
        final ArrayList<F> a;
        ArrayList<F> b;
        final ArrayList<F> c;
        private final List<F> d;
        private int e;
        int f;
        v g;

        public w() {
            ArrayList<F> arrayList = new ArrayList<>();
            this.a = arrayList;
            this.b = null;
            this.c = new ArrayList<>();
            this.d = DesugarCollections.unmodifiableList(arrayList);
            this.e = 2;
            this.f = 2;
        }

        private void B(h<?> hVar) {
            C(hVar, false);
        }

        private void C(h<?> hVar, boolean z) {
            v vVar = this.g;
            if (vVar != null) {
                vVar.e(hVar, z);
            }
        }

        private boolean M(F f, int i, int i2, long j) {
            f.s = null;
            f.r = RecyclerView.this;
            int iM = f.m();
            long nanoTime = RecyclerView.this.getNanoTime();
            boolean z = false;
            if (j != Long.MAX_VALUE && !this.g.m(iM, nanoTime, j)) {
                return false;
            }
            if (f.y()) {
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.attachViewToParent(f.a, recyclerView.getChildCount(), f.a.getLayoutParams());
                z = true;
            }
            RecyclerView.this.v0.h(f, i);
            if (z) {
                RecyclerView.this.detachViewFromParent(f.a);
            }
            this.g.f(f.m(), RecyclerView.this.getNanoTime() - nanoTime);
            b(f);
            if (RecyclerView.this.p1.e()) {
                f.g = i2;
            }
            return true;
        }

        private void b(F f) {
            if (RecyclerView.this.D0()) {
                View view = f.a;
                if (C1839d0.z(view) == 0) {
                    C1839d0.s0(view, 1);
                }
                androidx.recyclerview.widget.q qVar = RecyclerView.this.w1;
                if (qVar == null) {
                    return;
                }
                C1832a c1832aN = qVar.n();
                if (c1832aN instanceof androidx.recyclerview.widget.q.a) {
                    ((androidx.recyclerview.widget.q.a) c1832aN).o(view);
                }
                C1839d0.l0(view, c1832aN);
            }
        }

        private void q(ViewGroup viewGroup, boolean z) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    q((ViewGroup) childAt, true);
                }
            }
            if (z) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                } else {
                    int visibility = viewGroup.getVisibility();
                    viewGroup.setVisibility(4);
                    viewGroup.setVisibility(visibility);
                }
            }
        }

        private void r(F f) {
            View view = f.a;
            if (view instanceof ViewGroup) {
                q((ViewGroup) view, false);
            }
        }

        private void u() {
            if (this.g != null) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.v0 == null || !recyclerView.isAttachedToWindow()) {
                    return;
                }
                this.g.b(RecyclerView.this.v0);
            }
        }

        void A() {
            for (int i = 0; i < this.c.size(); i++) {
                ax.p147j0.a.a(this.c.get(i).a);
            }
            B(RecyclerView.this.v0);
        }

        void D(View view) {
            F fN0 = RecyclerView.n0(view);
            fN0.n = null;
            fN0.o = false;
            fN0.e();
            H(fN0);
        }

        void E() {
            for (int size = this.c.size() - 1; size >= 0; size--) {
                F(size);
            }
            this.c.clear();
            if (RecyclerView.Q1) {
                RecyclerView.this.o1.b();
            }
        }

        void F(int i) {
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "Recycling cached view at index " + i);
            }
            F f = this.c.get(i);
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "CachedViewHolder to be recycled: " + f);
            }
            a(f, true);
            this.c.remove(i);
        }

        public void G(View view) {
            F fN0 = RecyclerView.n0(view);
            if (fN0.y()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (fN0.x()) {
                fN0.L();
            } else if (fN0.M()) {
                fN0.e();
            }
            H(fN0);
            if (RecyclerView.this.X0 == null || fN0.v()) {
                return;
            }
            RecyclerView.this.X0.j(fN0);
        }

        void H(F f) {
            boolean z;
            boolean z2 = false;
            boolean z3 = true;
            if (f.x() || f.a.getParent() != null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Scrapped or attached views may not be recycled. isScrap:");
                sb.append(f.x());
                sb.append(" isAttached:");
                sb.append(f.a.getParent() != null);
                sb.append(RecyclerView.this.V());
                throw new IllegalArgumentException(sb.toString());
            }
            if (f.y()) {
                throw new IllegalArgumentException("Tmp detached view should be removed from RecyclerView before it can be recycled: " + f + RecyclerView.this.V());
            }
            if (f.K()) {
                throw new IllegalArgumentException("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle." + RecyclerView.this.V());
            }
            boolean zH = f.h();
            h hVar = RecyclerView.this.v0;
            boolean z4 = hVar != null && zH && hVar.F(f);
            if (RecyclerView.J1 && this.c.contains(f)) {
                throw new IllegalArgumentException("cached view received recycle internal? " + f + RecyclerView.this.V());
            }
            if (z4 || f.v()) {
                if (this.f <= 0 || f.q(526)) {
                    z = false;
                } else {
                    int size = this.c.size();
                    if (size >= this.f && size > 0) {
                        F(0);
                        size--;
                    }
                    if (RecyclerView.Q1 && size > 0 && !RecyclerView.this.o1.d(f.c)) {
                        int i = size - 1;
                        while (i >= 0) {
                            if (!RecyclerView.this.o1.d(this.c.get(i).c)) {
                                break;
                            } else {
                                i--;
                            }
                        }
                        size = i + 1;
                    }
                    this.c.add(size, f);
                    z = true;
                }
                if (z) {
                    z2 = z;
                } else {
                    a(f, true);
                    z2 = z;
                }
                RecyclerView.this.p0.q(f);
                if (z2 && !z3 && zH) {
                    ax.p147j0.a.a(f.a);
                    f.s = null;
                    f.r = null;
                    return;
                }
                return;
            }
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "trying to recycle a non-recycleable holder. Hopefully, it will re-visit here. We are still removing it from animation lists" + RecyclerView.this.V());
            }
            z3 = false;
            RecyclerView.this.p0.q(f);
            if (z2) {
            }
        }

        void I(View view) {
            F fN0 = RecyclerView.n0(view);
            if (!fN0.q(12) && fN0.z() && !RecyclerView.this.s(fN0)) {
                if (this.b == null) {
                    this.b = new ArrayList<>();
                }
                fN0.I(this, true);
                this.b.add(fN0);
                return;
            }
            if (!fN0.u() || fN0.w() || RecyclerView.this.v0.q()) {
                fN0.I(this, false);
                this.a.add(fN0);
            } else {
                throw new IllegalArgumentException("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool." + RecyclerView.this.V());
            }
        }

        void J(v vVar) {
            B(RecyclerView.this.v0);
            v vVar2 = this.g;
            if (vVar2 != null) {
                vVar2.d();
            }
            this.g = vVar;
            if (vVar != null && RecyclerView.this.getAdapter() != null) {
                this.g.a();
            }
            u();
        }

        void K(D d) {
        }

        public void L(int i) {
            this.e = i;
            P();
        }

        /* JADX WARN: Code duplicated, block: B:100:0x0217  */
        /* JADX WARN: Code duplicated, block: B:103:0x021d A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:105:0x0220  */
        /* JADX WARN: Code duplicated, block: B:18:0x0037 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:19:0x0039  */
        /* JADX WARN: Code duplicated, block: B:21:0x0043  */
        /* JADX WARN: Code duplicated, block: B:22:0x004e  */
        /* JADX WARN: Code duplicated, block: B:24:0x0054  */
        /* JADX WARN: Code duplicated, block: B:27:0x005c  */
        /* JADX WARN: Code duplicated, block: B:29:0x005f  */
        /* JADX WARN: Code duplicated, block: B:72:0x0171  */
        /* JADX WARN: Code duplicated, block: B:78:0x019d  */
        /* JADX WARN: Code duplicated, block: B:80:0x01a3  */
        /* JADX WARN: Code duplicated, block: B:88:0x01b6  */
        /* JADX WARN: Code duplicated, block: B:96:0x01f3  */
        /* JADX WARN: Code duplicated, block: B:97:0x0201  */
        /* JADX WARN: Code duplicated, block: B:99:0x0209  */
        F N(int i, boolean z, long j) {
            F fJ;
            boolean z2;
            F f;
            boolean z3;
            boolean zM;
            ViewGroup.LayoutParams layoutParams;
            q qVar;
            int iM;
            RecyclerView recyclerViewC0;
            if (i < 0 || i >= RecyclerView.this.p1.b()) {
                throw new IndexOutOfBoundsException("Invalid item position " + i + "(" + i + "). Item count:" + RecyclerView.this.p1.b() + RecyclerView.this.V());
            }
            if (RecyclerView.this.p1.e()) {
                fJ = h(i);
                z2 = fJ != null;
                if (fJ == null && (fJ = m(i, z)) != null) {
                    if (Q(fJ)) {
                        z2 = true;
                    } else {
                        if (!z) {
                            fJ.b(4);
                            if (fJ.x()) {
                                RecyclerView.this.removeDetachedView(fJ.a, false);
                                fJ.L();
                            } else if (fJ.M()) {
                                fJ.e();
                            }
                            H(fJ);
                        }
                        fJ = null;
                    }
                }
                if (fJ == null) {
                    iM = RecyclerView.this.n0.m(i);
                    if (iM >= 0 || iM >= RecyclerView.this.v0.l()) {
                        throw new IndexOutOfBoundsException("Inconsistency detected. Invalid item position " + i + "(offset:" + iM + ").state:" + RecyclerView.this.p1.b() + RecyclerView.this.V());
                    }
                    int iN = RecyclerView.this.v0.n(iM);
                    if (RecyclerView.this.v0.q() && (fJ = l(RecyclerView.this.v0.m(iM), iN, z)) != null) {
                        fJ.c = iM;
                        z2 = true;
                    }
                    if (fJ == null) {
                        if (RecyclerView.K1) {
                            Log.d("RecyclerView", "tryGetViewHolderForPositionByDeadline(" + i + ") fetching from shared pool");
                        }
                        fJ = i().h(iN);
                        if (fJ != null) {
                            fJ.E();
                            if (RecyclerView.N1) {
                                r(fJ);
                            }
                        }
                    }
                    if (fJ == null) {
                        long nanoTime = RecyclerView.this.getNanoTime();
                        if (j != Long.MAX_VALUE && !this.g.n(iN, nanoTime, j)) {
                            return null;
                        }
                        RecyclerView recyclerView = RecyclerView.this;
                        fJ = recyclerView.v0.j(recyclerView, iN);
                        if (RecyclerView.Q1 && (recyclerViewC0 = RecyclerView.c0(fJ.a)) != null) {
                            fJ.b = new WeakReference<>(recyclerViewC0);
                        }
                        this.g.g(iN, RecyclerView.this.getNanoTime() - nanoTime);
                        if (RecyclerView.K1) {
                            Log.d("RecyclerView", "tryGetViewHolderForPositionByDeadline created new ViewHolder");
                        }
                    }
                }
                f = fJ;
                z3 = z2;
                if (z3 && !RecyclerView.this.p1.e() && f.q(8192)) {
                    f.G(0, 8192);
                    if (RecyclerView.this.p1.k) {
                        int iE = m.e(f) | 4096;
                        RecyclerView recyclerView2 = RecyclerView.this;
                        RecyclerView.this.d1(f, recyclerView2.X0.u(recyclerView2.p1, f, iE, f.p()));
                    }
                }
                if (RecyclerView.this.p1.e() || !f.t()) {
                    if (f.t() || f.A() || f.u()) {
                        if (!RecyclerView.J1 && f.w()) {
                            throw new IllegalStateException("Removed holder should be bound and it should come here only in pre-layout. Holder: " + f + RecyclerView.this.V());
                        }
                        zM = M(f, RecyclerView.this.n0.m(i), i, j);
                    }
                    layoutParams = f.a.getLayoutParams();
                    if (layoutParams == null) {
                        qVar = (q) RecyclerView.this.generateDefaultLayoutParams();
                        f.a.setLayoutParams(qVar);
                    } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                        qVar = (q) layoutParams;
                    } else {
                        qVar = (q) RecyclerView.this.generateLayoutParams(layoutParams);
                        f.a.setLayoutParams(qVar);
                    }
                    qVar.a = f;
                    qVar.d = !z3 && zM;
                    return f;
                }
                f.g = i;
                zM = false;
                layoutParams = f.a.getLayoutParams();
                if (layoutParams == null) {
                    qVar = (q) RecyclerView.this.generateDefaultLayoutParams();
                    f.a.setLayoutParams(qVar);
                } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                    qVar = (q) RecyclerView.this.generateLayoutParams(layoutParams);
                    f.a.setLayoutParams(qVar);
                } else {
                    qVar = (q) layoutParams;
                }
                qVar.a = f;
                qVar.d = !z3 && zM;
                return f;
            }
            fJ = null;
            if (fJ == null) {
                if (Q(fJ)) {
                    if (!z) {
                        fJ.b(4);
                        if (fJ.x()) {
                            RecyclerView.this.removeDetachedView(fJ.a, false);
                            fJ.L();
                        } else if (fJ.M()) {
                            fJ.e();
                        }
                        H(fJ);
                    }
                    fJ = null;
                } else {
                    z2 = true;
                }
            }
            if (fJ == null) {
                iM = RecyclerView.this.n0.m(i);
                if (iM >= 0) {
                }
                throw new IndexOutOfBoundsException("Inconsistency detected. Invalid item position " + i + "(offset:" + iM + ").state:" + RecyclerView.this.p1.b() + RecyclerView.this.V());
            }
            f = fJ;
            z3 = z2;
            if (z3) {
                f.G(0, 8192);
                if (RecyclerView.this.p1.k) {
                    int iE2 = m.e(f) | 4096;
                    RecyclerView recyclerView3 = RecyclerView.this;
                    RecyclerView.this.d1(f, recyclerView3.X0.u(recyclerView3.p1, f, iE2, f.p()));
                }
            }
            if (RecyclerView.this.p1.e()) {
                if (f.t()) {
                }
                if (!RecyclerView.J1) {
                }
                zM = M(f, RecyclerView.this.n0.m(i), i, j);
            } else {
                if (f.t()) {
                }
                if (!RecyclerView.J1) {
                }
                zM = M(f, RecyclerView.this.n0.m(i), i, j);
            }
            layoutParams = f.a.getLayoutParams();
            if (layoutParams == null) {
                qVar = (q) RecyclerView.this.generateDefaultLayoutParams();
                f.a.setLayoutParams(qVar);
            } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                qVar = (q) RecyclerView.this.generateLayoutParams(layoutParams);
                f.a.setLayoutParams(qVar);
            } else {
                qVar = (q) layoutParams;
            }
            qVar.a = f;
            qVar.d = !z3 && zM;
            return f;
        }

        void O(F f) {
            if (f.o) {
                this.b.remove(f);
            } else {
                this.a.remove(f);
            }
            f.n = null;
            f.o = false;
            f.e();
        }

        void P() {
            p pVar = RecyclerView.this.w0;
            this.f = this.e + (pVar != null ? pVar.m : 0);
            for (int size = this.c.size() - 1; size >= 0 && this.c.size() > this.f; size--) {
                F(size);
            }
        }

        boolean Q(F f) {
            if (f.w()) {
                if (!RecyclerView.J1 || RecyclerView.this.p1.e()) {
                    return RecyclerView.this.p1.e();
                }
                throw new IllegalStateException("should not receive a removed view unless it is pre layout" + RecyclerView.this.V());
            }
            int i = f.c;
            if (i >= 0 && i < RecyclerView.this.v0.l()) {
                if (RecyclerView.this.p1.e() || RecyclerView.this.v0.n(f.c) == f.m()) {
                    return !RecyclerView.this.v0.q() || f.l() == RecyclerView.this.v0.m(f.c);
                }
                return false;
            }
            throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + f + RecyclerView.this.V());
        }

        void R(int i, int i2) {
            int i3;
            int i4 = i2 + i;
            for (int size = this.c.size() - 1; size >= 0; size--) {
                F f = this.c.get(size);
                if (f != null && (i3 = f.c) >= i && i3 < i4) {
                    f.b(2);
                    F(size);
                }
            }
        }

        void a(F f, boolean z) {
            RecyclerView.u(f);
            View view = f.a;
            androidx.recyclerview.widget.q qVar = RecyclerView.this.w1;
            if (qVar != null) {
                C1832a c1832aN = qVar.n();
                C1839d0.l0(view, c1832aN instanceof androidx.recyclerview.widget.q.a ? ((androidx.recyclerview.widget.q.a) c1832aN).n(view) : null);
            }
            if (z) {
                g(f);
            }
            f.s = null;
            f.r = null;
            i().k(f);
        }

        public void c() {
            this.a.clear();
            E();
        }

        void d() {
            int size = this.c.size();
            for (int i = 0; i < size; i++) {
                this.c.get(i).c();
            }
            int size2 = this.a.size();
            for (int i2 = 0; i2 < size2; i2++) {
                this.a.get(i2).c();
            }
            ArrayList<F> arrayList = this.b;
            if (arrayList != null) {
                int size3 = arrayList.size();
                for (int i3 = 0; i3 < size3; i3++) {
                    this.b.get(i3).c();
                }
            }
        }

        void e() {
            this.a.clear();
            ArrayList<F> arrayList = this.b;
            if (arrayList != null) {
                arrayList.clear();
            }
        }

        public int f(int i) {
            if (i >= 0 && i < RecyclerView.this.p1.b()) {
                return !RecyclerView.this.p1.e() ? i : RecyclerView.this.n0.m(i);
            }
            throw new IndexOutOfBoundsException("invalid position " + i + ". State item count is " + RecyclerView.this.p1.b() + RecyclerView.this.V());
        }

        void g(F f) {
            x xVar = RecyclerView.this.x0;
            if (xVar != null) {
                xVar.a(f);
            }
            int size = RecyclerView.this.y0.size();
            for (int i = 0; i < size; i++) {
                RecyclerView.this.y0.get(i).a(f);
            }
            h hVar = RecyclerView.this.v0;
            if (hVar != null) {
                hVar.I(f);
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.p1 != null) {
                recyclerView.p0.q(f);
            }
            if (RecyclerView.K1) {
                Log.d("RecyclerView", "dispatchViewRecycled: " + f);
            }
        }

        F h(int i) {
            int size;
            int iM;
            ArrayList<F> arrayList = this.b;
            if (arrayList != null && (size = arrayList.size()) != 0) {
                for (int i2 = 0; i2 < size; i2++) {
                    F f = this.b.get(i2);
                    if (!f.M() && f.n() == i) {
                        f.b(32);
                        return f;
                    }
                }
                if (RecyclerView.this.v0.q() && (iM = RecyclerView.this.n0.m(i)) > 0 && iM < RecyclerView.this.v0.l()) {
                    long jM = RecyclerView.this.v0.m(iM);
                    for (int i3 = 0; i3 < size; i3++) {
                        F f2 = this.b.get(i3);
                        if (!f2.M() && f2.l() == jM) {
                            f2.b(32);
                            return f2;
                        }
                    }
                }
            }
            return null;
        }

        v i() {
            if (this.g == null) {
                this.g = new v();
                u();
            }
            return this.g;
        }

        int j() {
            return this.a.size();
        }

        public List<F> k() {
            return this.d;
        }

        F l(long j, int i, boolean z) {
            for (int size = this.a.size() - 1; size >= 0; size--) {
                F f = this.a.get(size);
                if (f.l() == j && !f.M()) {
                    if (i == f.m()) {
                        f.b(32);
                        if (f.w() && !RecyclerView.this.p1.e()) {
                            f.G(2, 14);
                        }
                        return f;
                    }
                    if (!z) {
                        this.a.remove(size);
                        RecyclerView.this.removeDetachedView(f.a, false);
                        D(f.a);
                    }
                }
            }
            int size2 = this.c.size();
            while (true) {
                size2--;
                if (size2 < 0) {
                    return null;
                }
                F f2 = this.c.get(size2);
                if (f2.l() == j && !f2.s()) {
                    if (i == f2.m()) {
                        if (!z) {
                            this.c.remove(size2);
                        }
                        return f2;
                    }
                    if (!z) {
                        F(size2);
                        return null;
                    }
                }
            }
        }

        F m(int i, boolean z) {
            View viewE;
            int size = this.a.size();
            for (int i2 = 0; i2 < size; i2++) {
                F f = this.a.get(i2);
                if (!f.M() && f.n() == i && !f.u() && (RecyclerView.this.p1.h || !f.w())) {
                    f.b(32);
                    return f;
                }
            }
            if (!z && (viewE = RecyclerView.this.o0.e(i)) != null) {
                F fN0 = RecyclerView.n0(viewE);
                RecyclerView.this.o0.s(viewE);
                int iM = RecyclerView.this.o0.m(viewE);
                if (iM != -1) {
                    RecyclerView.this.o0.d(iM);
                    I(viewE);
                    fN0.b(8224);
                    return fN0;
                }
                throw new IllegalStateException("layout index should not be -1 after unhiding a view:" + fN0 + RecyclerView.this.V());
            }
            int size2 = this.c.size();
            for (int i3 = 0; i3 < size2; i3++) {
                F f2 = this.c.get(i3);
                if (!f2.u() && f2.n() == i && !f2.s()) {
                    if (!z) {
                        this.c.remove(i3);
                    }
                    if (RecyclerView.K1) {
                        Log.d("RecyclerView", "getScrapOrHiddenOrCachedHolderForPosition(" + i + ") found match in cache: " + f2);
                    }
                    return f2;
                }
            }
            return null;
        }

        View n(int i) {
            return this.a.get(i).a;
        }

        public View o(int i) {
            return p(i, false);
        }

        View p(int i, boolean z) {
            return N(i, z, Long.MAX_VALUE).a;
        }

        void s() {
            int size = this.c.size();
            for (int i = 0; i < size; i++) {
                q qVar = (q) this.c.get(i).a.getLayoutParams();
                if (qVar != null) {
                    qVar.c = true;
                }
            }
        }

        void t() {
            int size = this.c.size();
            for (int i = 0; i < size; i++) {
                F f = this.c.get(i);
                if (f != null) {
                    f.b(6);
                    f.a(null);
                }
            }
            h hVar = RecyclerView.this.v0;
            if (hVar == null || !hVar.q()) {
                E();
            }
        }

        void v(int i, int i2) {
            int size = this.c.size();
            for (int i3 = 0; i3 < size; i3++) {
                F f = this.c.get(i3);
                if (f != null && f.c >= i) {
                    if (RecyclerView.K1) {
                        Log.d("RecyclerView", "offsetPositionRecordsForInsert cached " + i3 + " holder " + f + " now at position " + (f.c + i2));
                    }
                    f.B(i2, false);
                }
            }
        }

        void w(int i, int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            if (i < i2) {
                i3 = -1;
                i5 = i;
                i4 = i2;
            } else {
                i3 = 1;
                i4 = i;
                i5 = i2;
            }
            int size = this.c.size();
            for (int i7 = 0; i7 < size; i7++) {
                F f = this.c.get(i7);
                if (f != null && (i6 = f.c) >= i5 && i6 <= i4) {
                    if (i6 == i) {
                        f.B(i2 - i, false);
                    } else {
                        f.B(i3, false);
                    }
                    if (RecyclerView.K1) {
                        Log.d("RecyclerView", "offsetPositionRecordsForMove cached child " + i7 + " holder " + f);
                    }
                }
            }
        }

        void x(int i, int i2, boolean z) {
            int i3 = i + i2;
            for (int size = this.c.size() - 1; size >= 0; size--) {
                F f = this.c.get(size);
                if (f != null) {
                    int i4 = f.c;
                    if (i4 >= i3) {
                        if (RecyclerView.K1) {
                            Log.d("RecyclerView", "offsetPositionRecordsForRemove cached " + size + " holder " + f + " now at position " + (f.c - i2));
                        }
                        f.B(-i2, z);
                    } else if (i4 >= i) {
                        f.b(8);
                        F(size);
                    }
                }
            }
        }

        void y(h<?> hVar, h<?> hVar2, boolean z) {
            c();
            C(hVar, true);
            i().j(hVar, hVar2, z);
            u();
        }

        void z() {
            u();
        }
    }

    public interface x {
        void a(F f);
    }

    private class y extends j {
        y() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void a() {
            RecyclerView.this.r(null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.p1.g = true;
            recyclerView.b1(true);
            if (RecyclerView.this.n0.p()) {
                return;
            }
            RecyclerView.this.requestLayout();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void c(int i, int i2, Object obj) {
            RecyclerView.this.r(null);
            if (RecyclerView.this.n0.r(i, i2, obj)) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void d(int i, int i2) {
            RecyclerView.this.r(null);
            if (RecyclerView.this.n0.s(i, i2)) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void e(int i, int i2, int i3) {
            RecyclerView.this.r(null);
            if (RecyclerView.this.n0.t(i, i2, i3)) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void f(int i, int i2) {
            RecyclerView.this.r(null);
            if (RecyclerView.this.n0.u(i, i2)) {
                h();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.j
        public void g() {
            h hVar;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.m0 == null || (hVar = recyclerView.v0) == null || !hVar.i()) {
                return;
            }
            RecyclerView.this.requestLayout();
        }

        void h() {
            if (RecyclerView.P1) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.D0 && recyclerView.C0) {
                    C1839d0.d0(recyclerView, recyclerView.r0);
                    return;
                }
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            recyclerView2.L0 = true;
            recyclerView2.requestLayout();
        }
    }

    public static class z extends ax.p163k0.a {
        public static final Parcelable.Creator<z> CREATOR = new a();
        Parcelable Y;

        class a implements Parcelable.ClassLoaderCreator<z> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public z createFromParcel(Parcel parcel) {
                return new z(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public z createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new z(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public z[] newArray(int i) {
                return new z[i];
            }
        }

        z(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.Y = parcel.readParcelable(classLoader == null ? p.class.getClassLoader() : classLoader);
        }

        z(Parcelable parcelable) {
            super(parcelable);
        }

        void b(z zVar) {
            this.Y = zVar.Y;
        }

        @Override // ax.p163k0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeParcelable(this.Y, 0);
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        N1 = false;
        O1 = i2 >= 23;
        P1 = true;
        Q1 = true;
        R1 = false;
        S1 = false;
        Class<?> cls = Integer.TYPE;
        T1 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        U1 = new InterpolatorC0669c();
        V1 = new C();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.p149j2.a.a);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.k0 = new y();
        this.l0 = new w();
        this.p0 = new androidx.recyclerview.widget.w();
        this.r0 = new RunnableC0667a();
        this.s0 = new Rect();
        this.t0 = new Rect();
        this.u0 = new RectF();
        this.y0 = new ArrayList();
        this.z0 = new ArrayList<>();
        this.A0 = new ArrayList<>();
        this.G0 = 0;
        this.O0 = false;
        this.P0 = false;
        this.Q0 = 0;
        this.R0 = 0;
        this.S0 = V1;
        this.X0 = new e();
        this.Y0 = 0;
        this.Z0 = -1;
        this.j1 = Float.MIN_VALUE;
        this.k1 = Float.MIN_VALUE;
        this.l1 = true;
        this.m1 = new E();
        this.o1 = Q1 ? new androidx.recyclerview.widget.h.b() : null;
        this.p1 = new B();
        this.s1 = false;
        this.t1 = false;
        this.u1 = new n();
        this.v1 = false;
        this.y1 = new int[2];
        this.A1 = new int[2];
        this.B1 = new int[2];
        this.C1 = new int[2];
        this.D1 = new ArrayList();
        this.E1 = new RunnableC0668b();
        this.G1 = 0;
        this.H1 = 0;
        this.I1 = new C0670d();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f1 = viewConfiguration.getScaledTouchSlop();
        this.j1 = C1847h0.f(viewConfiguration, context);
        this.k1 = C1847h0.j(viewConfiguration, context);
        this.h1 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.i1 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.q = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        setWillNotDraw(getOverScrollMode() == 2);
        this.X0.w(this.u1);
        x0();
        z0();
        y0();
        if (C1839d0.z(this) == 0) {
            C1839d0.s0(this, 1);
        }
        this.M0 = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new androidx.recyclerview.widget.q(this));
        int[] iArr = ax.p149j2.d.a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        C1839d0.j0(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i2, 0);
        String string = typedArrayObtainStyledAttributes.getString(ax.p149j2.d.j);
        if (typedArrayObtainStyledAttributes.getInt(ax.p149j2.d.d, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.q0 = typedArrayObtainStyledAttributes.getBoolean(ax.p149j2.d.c, true);
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(ax.p149j2.d.e, false);
        this.E0 = z2;
        if (z2) {
            A0((StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(ax.p149j2.d.h), typedArrayObtainStyledAttributes.getDrawable(ax.p149j2.d.i), (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(ax.p149j2.d.f), typedArrayObtainStyledAttributes.getDrawable(ax.p149j2.d.g));
        }
        typedArrayObtainStyledAttributes.recycle();
        B(context, string, attributeSet, i2, 0);
        int[] iArr2 = L1;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i2, 0);
        C1839d0.j0(this, context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i2, 0);
        boolean z3 = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z3);
        ax.p147j0.a.d(this, true);
    }

    private void B(Context context, String str, AttributeSet attributeSet, int i2, int i3) {
        Object[] objArr;
        Constructor constructor;
        if (str != null) {
            String strTrim = str.trim();
            if (strTrim.isEmpty()) {
                return;
            }
            String strR0 = r0(context, strTrim);
            try {
                Class<? extends U> clsAsSubclass = Class.forName(strR0, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(p.class);
                try {
                    constructor = clsAsSubclass.getConstructor(T1);
                    objArr = new Object[]{context, attributeSet, Integer.valueOf(i2), Integer.valueOf(i3)};
                } catch (NoSuchMethodException e) {
                    objArr = null;
                    try {
                        constructor = clsAsSubclass.getConstructor(null);
                    } catch (NoSuchMethodException e2) {
                        e2.initCause(e);
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + strR0, e2);
                    }
                }
                constructor.setAccessible(true);
                setLayoutManager((p) constructor.newInstance(objArr));
            } catch (ClassCastException e3) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + strR0, e3);
            } catch (ClassNotFoundException e4) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + strR0, e4);
            } catch (IllegalAccessException e5) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + strR0, e5);
            } catch (InstantiationException e6) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strR0, e6);
            } catch (InvocationTargetException e7) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strR0, e7);
            }
        }
    }

    private boolean D(int i2, int i3) {
        b0(this.y1);
        int[] iArr = this.y1;
        return (iArr[0] == i2 && iArr[1] == i3) ? false : true;
    }

    private boolean F0(View view, View view2, int i2) {
        int i3;
        if (view2 == null || view2 == this || view2 == view || Y(view2) == null) {
            return false;
        }
        if (view == null || Y(view) == null) {
            return true;
        }
        this.s0.set(0, 0, view.getWidth(), view.getHeight());
        this.t0.set(0, 0, view2.getWidth(), view2.getHeight());
        offsetDescendantRectToMyCoords(view, this.s0);
        offsetDescendantRectToMyCoords(view2, this.t0);
        byte b = -1;
        int i4 = this.w0.e0() == 1 ? -1 : 1;
        Rect rect = this.s0;
        int i5 = rect.left;
        Rect rect2 = this.t0;
        int i6 = rect2.left;
        if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
            i3 = 1;
        } else {
            int i7 = rect.right;
            int i8 = rect2.right;
            i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
        }
        int i9 = rect.top;
        int i10 = rect2.top;
        if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
            b = 1;
        } else {
            int i11 = rect.bottom;
            int i12 = rect2.bottom;
            if ((i11 <= i12 && i9 < i12) || i9 <= i10) {
                b = 0;
            }
        }
        if (i2 == 1) {
            return b < 0 || (b == 0 && i3 * i4 < 0);
        }
        if (i2 == 2) {
            return b > 0 || (b == 0 && i3 * i4 > 0);
        }
        if (i2 == 17) {
            return i3 < 0;
        }
        if (i2 == 33) {
            return b < 0;
        }
        if (i2 == 66) {
            return i3 > 0;
        }
        if (i2 == 130) {
            return b > 0;
        }
        throw new IllegalArgumentException("Invalid direction: " + i2 + V());
    }

    private void G() {
        int i2 = this.K0;
        this.K0 = 0;
        if (i2 == 0 || !D0()) {
            return;
        }
        AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
        accessibilityEventObtain.setEventType(2048);
        C1884b.b(accessibilityEventObtain, i2);
        sendAccessibilityEventUnchecked(accessibilityEventObtain);
    }

    private void I() {
        this.p1.a(1);
        W(this.p1);
        this.p1.j = false;
        G1();
        this.p0.f();
        S0();
        a1();
        s1();
        B b = this.p1;
        b.i = b.k && this.t1;
        this.t1 = false;
        this.s1 = false;
        b.h = b.l;
        b.f = this.v0.l();
        b0(this.y1);
        if (this.p1.k) {
            int iG = this.o0.g();
            for (int i2 = 0; i2 < iG; i2++) {
                F fN0 = n0(this.o0.f(i2));
                if (!fN0.K() && (!fN0.u() || this.v0.q())) {
                    this.p0.e(fN0, this.X0.u(this.p1, fN0, m.e(fN0), fN0.p()));
                    if (this.p1.i && fN0.z() && !fN0.w() && !fN0.K() && !fN0.u()) {
                        this.p0.c(j0(fN0), fN0);
                    }
                }
            }
        }
        if (this.p1.l) {
            t1();
            B b2 = this.p1;
            boolean z2 = b2.g;
            b2.g = false;
            this.w0.c1(this.l0, b2);
            this.p1.g = z2;
            for (int i3 = 0; i3 < this.o0.g(); i3++) {
                F fN1 = n0(this.o0.f(i3));
                if (!fN1.K() && !this.p0.i(fN1)) {
                    int iE = m.e(fN1);
                    boolean zQ = fN1.q(8192);
                    if (!zQ) {
                        iE |= 4096;
                    }
                    m.c cVarU = this.X0.u(this.p1, fN1, iE, fN1.p());
                    if (zQ) {
                        d1(fN1, cVarU);
                    } else {
                        this.p0.a(fN1, cVarU);
                    }
                }
            }
            v();
        } else {
            v();
        }
        T0();
        J1(false);
        this.p1.e = 2;
    }

    private boolean I1(MotionEvent motionEvent) {
        boolean z2;
        EdgeEffect edgeEffect = this.T0;
        if (edgeEffect == null || ax.p115h0.d.b(edgeEffect) == 0.0f || canScrollHorizontally(-1)) {
            z2 = false;
        } else {
            ax.p115h0.d.d(this.T0, 0.0f, 1.0f - (motionEvent.getY() / getHeight()));
            z2 = true;
        }
        EdgeEffect edgeEffect2 = this.V0;
        if (edgeEffect2 != null && ax.p115h0.d.b(edgeEffect2) != 0.0f && !canScrollHorizontally(1)) {
            ax.p115h0.d.d(this.V0, 0.0f, motionEvent.getY() / getHeight());
            z2 = true;
        }
        EdgeEffect edgeEffect3 = this.U0;
        if (edgeEffect3 != null && ax.p115h0.d.b(edgeEffect3) != 0.0f && !canScrollVertically(-1)) {
            ax.p115h0.d.d(this.U0, 0.0f, motionEvent.getX() / getWidth());
            z2 = true;
        }
        EdgeEffect edgeEffect4 = this.W0;
        if (edgeEffect4 == null || ax.p115h0.d.b(edgeEffect4) == 0.0f || canScrollVertically(1)) {
            return z2;
        }
        ax.p115h0.d.d(this.W0, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    private void J() {
        G1();
        S0();
        this.p1.a(6);
        this.n0.j();
        this.p1.f = this.v0.l();
        this.p1.d = 0;
        if (this.m0 != null && this.v0.i()) {
            Parcelable parcelable = this.m0.Y;
            if (parcelable != null) {
                this.w0.h1(parcelable);
            }
            this.m0 = null;
        }
        B b = this.p1;
        b.h = false;
        this.w0.c1(this.l0, b);
        B b2 = this.p1;
        b2.g = false;
        b2.k = b2.k && this.X0 != null;
        b2.e = 4;
        T0();
        J1(false);
    }

    private void K() {
        RecyclerView recyclerView;
        this.p1.a(4);
        G1();
        S0();
        B b = this.p1;
        b.e = 1;
        if (b.k) {
            for (int iG = this.o0.g() - 1; iG >= 0; iG--) {
                F fN0 = n0(this.o0.f(iG));
                if (!fN0.K()) {
                    long jJ0 = j0(fN0);
                    m.c cVarT = this.X0.t(this.p1, fN0);
                    F fG = this.p0.g(jJ0);
                    if (fG == null || fG.K()) {
                        this.p0.d(fN0, cVarT);
                    } else {
                        boolean zH = this.p0.h(fG);
                        boolean zH2 = this.p0.h(fN0);
                        if (zH && fG == fN0) {
                            this.p0.d(fN0, cVarT);
                        } else {
                            m.c cVarN = this.p0.n(fG);
                            this.p0.d(fN0, cVarT);
                            m.c cVarM = this.p0.m(fN0);
                            if (cVarN == null) {
                                u0(jJ0, fN0, fG);
                            } else {
                                p(fG, fN0, cVarN, cVarM, zH, zH2);
                            }
                        }
                    }
                }
            }
            recyclerView = this;
            recyclerView.p0.o(recyclerView.I1);
        } else {
            recyclerView = this;
        }
        recyclerView.w0.q1(recyclerView.l0);
        B b2 = recyclerView.p1;
        b2.c = b2.f;
        recyclerView.O0 = false;
        recyclerView.P0 = false;
        b2.k = false;
        b2.l = false;
        recyclerView.w0.h = false;
        ArrayList<F> arrayList = recyclerView.l0.b;
        if (arrayList != null) {
            arrayList.clear();
        }
        p pVar = recyclerView.w0;
        if (pVar.n) {
            pVar.m = 0;
            pVar.n = false;
            recyclerView.l0.P();
        }
        recyclerView.w0.d1(recyclerView.p1);
        T0();
        J1(false);
        recyclerView.p0.f();
        int[] iArr = recyclerView.y1;
        if (D(iArr[0], iArr[1])) {
            O(0, 0);
        }
        e1();
        q1();
    }

    private void K0(int i2, int i3, MotionEvent motionEvent, int i4) {
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.I0) {
            return;
        }
        int[] iArr = this.C1;
        iArr[0] = 0;
        iArr[1] = 0;
        boolean zQ = pVar.q();
        boolean zR = this.w0.r();
        int i5 = zR ? (zQ ? 1 : 0) | 2 : zQ ? 1 : 0;
        float height = motionEvent == null ? getHeight() / 2.0f : motionEvent.getY();
        float width = motionEvent == null ? getWidth() / 2.0f : motionEvent.getX();
        int iG1 = i2 - g1(i2, height);
        int iH1 = i3 - h1(i3, width);
        H1(i5, i4);
        if (L(zQ ? iG1 : 0, zR ? iH1 : 0, this.C1, this.A1, i4)) {
            int[] iArr2 = this.C1;
            iG1 -= iArr2[0];
            iH1 -= iArr2[1];
        }
        u1(zQ ? iG1 : 0, zR ? iH1 : 0, motionEvent, i4);
        androidx.recyclerview.widget.h hVar = this.n1;
        if (hVar != null && (iG1 != 0 || iH1 != 0)) {
            hVar.f(this, iG1, iH1);
        }
        K1(i4);
    }

    private void M1() {
        this.m1.f();
        p pVar = this.w0;
        if (pVar != null) {
            pVar.P1();
        }
    }

    private boolean Q(MotionEvent motionEvent) {
        t tVar = this.B0;
        if (tVar == null) {
            if (motionEvent.getAction() == 0) {
                return false;
            }
            return a0(motionEvent);
        }
        tVar.b(this, motionEvent);
        int action = motionEvent.getAction();
        if (action == 3 || action == 1) {
            this.B0 = null;
        }
        return true;
    }

    private void V0(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.Z0) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.Z0 = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.d1 = x2;
            this.b1 = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.e1 = y2;
            this.c1 = y2;
        }
    }

    private boolean Z0() {
        return this.X0 != null && this.w0.Q1();
    }

    private boolean a0(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.A0.size();
        for (int i2 = 0; i2 < size; i2++) {
            t tVar = this.A0.get(i2);
            if (tVar.c(this, motionEvent) && action != 3) {
                this.B0 = tVar;
                return true;
            }
        }
        return false;
    }

    private void a1() {
        boolean z2;
        if (this.O0) {
            this.n0.y();
            if (this.P0) {
                this.w0.X0(this);
            }
        }
        if (Z0()) {
            this.n0.w();
        } else {
            this.n0.j();
        }
        boolean z3 = this.s1 || this.t1;
        this.p1.k = this.F0 && this.X0 != null && ((z2 = this.O0) || z3 || this.w0.h) && (!z2 || this.v0.q());
        B b = this.p1;
        b.l = b.k && z3 && !this.O0 && Z0();
    }

    private void b0(int[] iArr) {
        int iG = this.o0.g();
        if (iG == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < iG; i4++) {
            F fN0 = n0(this.o0.f(i4));
            if (!fN0.K()) {
                int iN = fN0.n();
                if (iN < i2) {
                    i2 = iN;
                }
                if (iN > i3) {
                    i3 = iN;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    static RecyclerView c0(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            RecyclerView recyclerViewC0 = c0(viewGroup.getChildAt(i2));
            if (recyclerViewC0 != null) {
                return recyclerViewC0;
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0040  */
    /* JADX WARN: Code duplicated, block: B:13:0x0056  */
    /* JADX WARN: Code duplicated, block: B:15:0x005a  */
    /* JADX WARN: Code duplicated, block: B:16:0x0071  */
    private void c1(float f, float f2, float f3, float f4) {
        boolean z2;
        boolean z3 = true;
        if (f2 >= 0.0f) {
            if (f2 > 0.0f) {
                T();
                ax.p115h0.d.d(this.V0, f2 / getWidth(), f3 / getHeight());
            } else {
                z2 = false;
            }
            if (f4 < 0.0f) {
                U();
                ax.p115h0.d.d(this.U0, (-f4) / getHeight(), f / getWidth());
            } else if (f4 > 0.0f) {
                R();
                ax.p115h0.d.d(this.W0, f4 / getHeight(), 1.0f - (f / getWidth()));
            } else {
                z3 = z2;
            }
            if (z3 && f2 == 0.0f && f4 == 0.0f) {
                return;
            }
            C1839d0.c0(this);
        }
        S();
        ax.p115h0.d.d(this.T0, (-f2) / getWidth(), 1.0f - (f3 / getHeight()));
        z2 = true;
        if (f4 < 0.0f) {
            U();
            ax.p115h0.d.d(this.U0, (-f4) / getHeight(), f / getWidth());
        } else if (f4 > 0.0f) {
            R();
            ax.p115h0.d.d(this.W0, f4 / getHeight(), 1.0f - (f / getWidth()));
        } else {
            z3 = z2;
        }
        if (z3) {
        }
        C1839d0.c0(this);
    }

    private View d0() {
        F fE0;
        B b = this.p1;
        int i2 = b.m;
        if (i2 == -1) {
            i2 = 0;
        }
        int iB = b.b();
        for (int i3 = i2; i3 < iB; i3++) {
            F fE1 = e0(i3);
            if (fE1 == null) {
                break;
            }
            if (fE1.a.hasFocusable()) {
                return fE1.a;
            }
        }
        int iMin = Math.min(iB, i2);
        do {
            iMin--;
            if (iMin < 0 || (fE0 = e0(iMin)) == null) {
                return null;
            }
        } while (!fE0.a.hasFocusable());
        return fE0.a;
    }

    private void e1() {
        View viewFindViewById;
        if (!this.l1 || this.v0 == null || !hasFocus() || getDescendantFocusability() == 393216) {
            return;
        }
        if (getDescendantFocusability() == 131072 && isFocused()) {
            return;
        }
        if (!isFocused()) {
            View focusedChild = getFocusedChild();
            if (!S1 || (focusedChild.getParent() != null && focusedChild.hasFocus())) {
                if (!this.o0.n(focusedChild)) {
                    return;
                }
            } else if (this.o0.g() == 0) {
                requestFocus();
                return;
            }
        }
        View viewD0 = null;
        F fF0 = (this.p1.n == -1 || !this.v0.q()) ? null : f0(this.p1.n);
        if (fF0 != null && !this.o0.n(fF0.a) && fF0.a.hasFocusable()) {
            viewD0 = fF0.a;
        } else if (this.o0.g() > 0) {
            viewD0 = d0();
        }
        if (viewD0 != null) {
            int i2 = this.p1.o;
            if (i2 != -1 && (viewFindViewById = viewD0.findViewById(i2)) != null && viewFindViewById.isFocusable()) {
                viewD0 = viewFindViewById;
            }
            viewD0.requestFocus();
        }
    }

    private void f1() {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.T0;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.T0.isFinished();
        } else {
            zIsFinished = false;
        }
        EdgeEffect edgeEffect2 = this.U0;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.U0.isFinished();
        }
        EdgeEffect edgeEffect3 = this.V0;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.V0.isFinished();
        }
        EdgeEffect edgeEffect4 = this.W0;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.W0.isFinished();
        }
        if (zIsFinished) {
            C1839d0.c0(this);
        }
    }

    private int g1(int i2, float f) {
        float height = f / getHeight();
        float width = i2 / getWidth();
        EdgeEffect edgeEffect = this.T0;
        float f2 = 0.0f;
        if (edgeEffect == null || ax.p115h0.d.b(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.V0;
            if (edgeEffect2 != null && ax.p115h0.d.b(edgeEffect2) != 0.0f) {
                if (canScrollHorizontally(1)) {
                    this.V0.onRelease();
                } else {
                    float fD = ax.p115h0.d.d(this.V0, width, height);
                    if (ax.p115h0.d.b(this.V0) == 0.0f) {
                        this.V0.onRelease();
                    }
                    f2 = fD;
                }
                invalidate();
            }
        } else {
            if (canScrollHorizontally(-1)) {
                this.T0.onRelease();
            } else {
                float f3 = -ax.p115h0.d.d(this.T0, -width, 1.0f - height);
                if (ax.p115h0.d.b(this.T0) == 0.0f) {
                    this.T0.onRelease();
                }
                f2 = f3;
            }
            invalidate();
        }
        return Math.round(f2 * getWidth());
    }

    private ax.p035c0.E getScrollingChildHelper() {
        if (this.z1 == null) {
            this.z1 = new ax.p035c0.E(this);
        }
        return this.z1;
    }

    private int h1(int i2, float f) {
        float width = f / getWidth();
        float height = i2 / getHeight();
        EdgeEffect edgeEffect = this.U0;
        float f2 = 0.0f;
        if (edgeEffect == null || ax.p115h0.d.b(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.W0;
            if (edgeEffect2 != null && ax.p115h0.d.b(edgeEffect2) != 0.0f) {
                if (canScrollVertically(1)) {
                    this.W0.onRelease();
                } else {
                    float fD = ax.p115h0.d.d(this.W0, height, 1.0f - width);
                    if (ax.p115h0.d.b(this.W0) == 0.0f) {
                        this.W0.onRelease();
                    }
                    f2 = fD;
                }
                invalidate();
            }
        } else {
            if (canScrollVertically(-1)) {
                this.U0.onRelease();
            } else {
                float f3 = -ax.p115h0.d.d(this.U0, -height, width);
                if (ax.p115h0.d.b(this.U0) == 0.0f) {
                    this.U0.onRelease();
                }
                f2 = f3;
            }
            invalidate();
        }
        return Math.round(f2 * getHeight());
    }

    private void i(F f) {
        View view = f.a;
        boolean z2 = view.getParent() == this;
        this.l0.O(m0(view));
        if (f.y()) {
            this.o0.c(view, -1, view.getLayoutParams(), true);
        } else if (z2) {
            this.o0.k(view);
        } else {
            this.o0.b(view, true);
        }
    }

    static F n0(View view) {
        if (view == null) {
            return null;
        }
        return ((q) view.getLayoutParams()).a;
    }

    private void p(F f, F f2, m.c cVar, m.c cVar2, boolean z2, boolean z3) {
        f.H(false);
        if (z2) {
            i(f);
        }
        if (f != f2) {
            if (z3) {
                i(f2);
            }
            f.h = f2;
            i(f);
            this.l0.O(f);
            f2.H(false);
            f2.i = f;
        }
        if (this.X0.b(f, f2, cVar, cVar2)) {
            Y0();
        }
    }

    static void p0(View view, Rect rect) {
        q qVar = (q) view.getLayoutParams();
        Rect rect2 = qVar.b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) qVar).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) qVar).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) qVar).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) qVar).bottomMargin);
    }

    private void p1(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.s0.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof q) {
            q qVar = (q) layoutParams;
            if (!qVar.c) {
                Rect rect = qVar.b;
                Rect rect2 = this.s0;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.s0);
            offsetRectIntoDescendantCoords(view, this.s0);
        }
        this.w0.x1(this, view, this.s0, !this.F0, view2 == null);
    }

    private int q0(View view) {
        int id = view.getId();
        while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
            view = ((ViewGroup) view).getFocusedChild();
            if (view.getId() != -1) {
                id = view.getId();
            }
        }
        return id;
    }

    private void q1() {
        B b = this.p1;
        b.n = -1L;
        b.m = -1;
        b.o = -1;
    }

    private String r0(Context context, String str) {
        if (str.charAt(0) == '.') {
            return context.getPackageName() + str;
        }
        if (str.contains(".")) {
            return str;
        }
        return RecyclerView.class.getPackage().getName() + '.' + str;
    }

    private void r1() {
        VelocityTracker velocityTracker = this.a1;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        K1(0);
        f1();
    }

    private void s1() {
        int iJ;
        View focusedChild = (this.l1 && hasFocus() && this.v0 != null) ? getFocusedChild() : null;
        F fZ = focusedChild != null ? Z(focusedChild) : null;
        if (fZ == null) {
            q1();
            return;
        }
        this.p1.n = this.v0.q() ? fZ.l() : -1L;
        B b = this.p1;
        if (this.O0) {
            iJ = -1;
        } else {
            iJ = fZ.w() ? fZ.d : fZ.j();
        }
        b.m = iJ;
        this.p1.o = q0(fZ.a);
    }

    public static void setDebugAssertionsEnabled(boolean z2) {
        J1 = z2;
    }

    public static void setVerboseLoggingEnabled(boolean z2) {
        K1 = z2;
    }

    private void t() {
        r1();
        setScrollState(0);
    }

    private float t0(int i2) {
        double dLog = Math.log((Math.abs(i2) * 0.35f) / (this.q * 0.015f));
        float f = M1;
        return (float) (((double) (this.q * 0.015f)) * Math.exp((((double) f) / (((double) f) - 1.0d)) * dLog));
    }

    static void u(F f) {
        WeakReference<RecyclerView> weakReference = f.b;
        if (weakReference != null) {
            RecyclerView recyclerView = weakReference.get();
            while (recyclerView != null) {
                if (recyclerView == f.a) {
                    return;
                }
                Object parent = recyclerView.getParent();
                recyclerView = parent instanceof View ? (View) parent : null;
            }
            f.b = null;
        }
    }

    private void u0(long j2, F f, F f2) {
        int iG = this.o0.g();
        for (int i2 = 0; i2 < iG; i2++) {
            F fN0 = n0(this.o0.f(i2));
            if (fN0 != f && j0(fN0) == j2) {
                h hVar = this.v0;
                if (hVar == null || !hVar.q()) {
                    throw new IllegalStateException("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:" + fN0 + " \n View Holder 2:" + f + V());
                }
                throw new IllegalStateException("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:" + fN0 + " \n View Holder 2:" + f + V());
            }
        }
        Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + f2 + " cannot be found but it is necessary for " + f + V());
    }

    private boolean w0() {
        int iG = this.o0.g();
        for (int i2 = 0; i2 < iG; i2++) {
            F fN0 = n0(this.o0.f(i2));
            if (fN0 != null && !fN0.K() && fN0.z()) {
                return true;
            }
        }
        return false;
    }

    private void x1(h<?> hVar, boolean z2, boolean z3) {
        h hVar2 = this.v0;
        if (hVar2 != null) {
            hVar2.M(this.k0);
            this.v0.E(this);
        }
        if (!z2 || z3) {
            i1();
        }
        this.n0.y();
        h<?> hVar3 = this.v0;
        this.v0 = hVar;
        if (hVar != null) {
            hVar.J(this.k0);
            hVar.A(this);
        }
        p pVar = this.w0;
        if (pVar != null) {
            pVar.J0(hVar3, this.v0);
        }
        this.l0.y(hVar3, this.v0, z2);
        this.p1.g = true;
    }

    private int y(int i2, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i3) {
        if (i2 > 0 && edgeEffect != null && ax.p115h0.d.b(edgeEffect) != 0.0f) {
            int iRound = Math.round(((-i3) / 4.0f) * ax.p115h0.d.d(edgeEffect, ((-i2) * 4.0f) / i3, 0.5f));
            if (iRound != i2) {
                edgeEffect.finish();
            }
            return i2 - iRound;
        }
        if (i2 >= 0 || edgeEffect2 == null || ax.p115h0.d.b(edgeEffect2) == 0.0f) {
            return i2;
        }
        float f = i3;
        int iRound2 = Math.round((f / 4.0f) * ax.p115h0.d.d(edgeEffect2, (i2 * 4.0f) / f, 0.5f));
        if (iRound2 != i2) {
            edgeEffect2.finish();
        }
        return i2 - iRound2;
    }

    @SuppressLint({"InlinedApi"})
    private void y0() {
        if (C1839d0.A(this) == 0) {
            C1839d0.u0(this, 8);
        }
    }

    private void z0() {
        this.o0 = new b(new C0671e());
    }

    private boolean z1(EdgeEffect edgeEffect, int i2, int i3) {
        if (i2 > 0) {
            return true;
        }
        return t0(-i2) < ax.p115h0.d.b(edgeEffect) * ((float) i3);
    }

    void A() {
        if (!this.F0 || this.O0) {
            ax.Y.u.a("RV FullInvalidate");
            H();
            ax.Y.u.b();
            return;
        }
        if (this.n0.p()) {
            if (!this.n0.o(4) || this.n0.o(11)) {
                if (this.n0.p()) {
                    ax.Y.u.a("RV FullInvalidate");
                    H();
                    ax.Y.u.b();
                    return;
                }
                return;
            }
            ax.Y.u.a("RV PartialInvalidate");
            G1();
            S0();
            this.n0.w();
            if (!this.H0) {
                if (w0()) {
                    H();
                } else {
                    this.n0.i();
                }
            }
            J1(true);
            T0();
            ax.Y.u.b();
        }
    }

    void A0(StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2) {
        if (stateListDrawable != null && drawable != null && stateListDrawable2 != null && drawable2 != null) {
            Resources resources = getContext().getResources();
            new androidx.recyclerview.widget.g(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(ax.p149j2.b.a), resources.getDimensionPixelSize(ax.p149j2.b.c), resources.getDimensionPixelOffset(ax.p149j2.b.b));
        } else {
            throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + V());
        }
    }

    boolean A1(AccessibilityEvent accessibilityEvent) {
        if (!E0()) {
            return false;
        }
        int iA = accessibilityEvent != null ? C1884b.a(accessibilityEvent) : 0;
        this.K0 |= iA != 0 ? iA : 0;
        return true;
    }

    void B0() {
        this.W0 = null;
        this.U0 = null;
        this.V0 = null;
        this.T0 = null;
    }

    public void B1(int i2, int i3) {
        C1(i2, i3, null);
    }

    void C(int i2, int i3) {
        setMeasuredDimension(p.t(i2, getPaddingLeft() + getPaddingRight(), C1839d0.D(this)), p.t(i3, getPaddingTop() + getPaddingBottom(), C1839d0.C(this)));
    }

    public void C0() {
        if (this.z0.size() == 0) {
            return;
        }
        p pVar = this.w0;
        if (pVar != null) {
            pVar.m("Cannot invalidate item decorations during a scroll or layout");
        }
        H0();
        requestLayout();
    }

    public void C1(int i2, int i3, Interpolator interpolator) {
        D1(i2, i3, interpolator, Integer.MIN_VALUE);
    }

    boolean D0() {
        AccessibilityManager accessibilityManager = this.M0;
        return accessibilityManager != null && accessibilityManager.isEnabled();
    }

    public void D1(int i2, int i3, Interpolator interpolator, int i4) {
        E1(i2, i3, interpolator, i4, false);
    }

    void E(View view) {
        F fN0 = n0(view);
        Q0(view);
        h hVar = this.v0;
        if (hVar != null && fN0 != null) {
            hVar.G(fN0);
        }
        List<r> list = this.N0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.N0.get(size).d(view);
            }
        }
    }

    public boolean E0() {
        return this.Q0 > 0;
    }

    void E1(int i2, int i3, Interpolator interpolator, int i4, boolean z2) {
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.I0) {
            return;
        }
        if (!pVar.q()) {
            i2 = 0;
        }
        if (!this.w0.r()) {
            i3 = 0;
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        if (i4 != Integer.MIN_VALUE && i4 <= 0) {
            scrollBy(i2, i3);
            return;
        }
        if (z2) {
            int i5 = i2 != 0 ? 1 : 0;
            if (i3 != 0) {
                i5 |= 2;
            }
            H1(i5, 1);
        }
        this.m1.e(i2, i3, i4, interpolator);
    }

    void F(View view) {
        F fN0 = n0(view);
        R0(view);
        h hVar = this.v0;
        if (hVar != null && fN0 != null) {
            hVar.H(fN0);
        }
        List<r> list = this.N0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.N0.get(size).a(view);
            }
        }
    }

    public void F1(int i2) {
        if (this.I0) {
            return;
        }
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            pVar.N1(this, this.p1, i2);
        }
    }

    void G0(int i2) {
        if (this.w0 == null) {
            return;
        }
        setScrollState(2);
        this.w0.C1(i2);
        awakenScrollBars();
    }

    void G1() {
        int i2 = this.G0 + 1;
        this.G0 = i2;
        if (i2 != 1 || this.I0) {
            return;
        }
        this.H0 = false;
    }

    void H() {
        if (this.v0 == null) {
            Log.w("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.w0 == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        this.p1.j = false;
        boolean z2 = this.F1 && !(this.G1 == getWidth() && this.H1 == getHeight());
        this.G1 = 0;
        this.H1 = 0;
        this.F1 = false;
        if (this.p1.e == 1) {
            I();
            this.w0.E1(this);
            J();
        } else if (this.n0.q() || z2 || this.w0.t0() != getWidth() || this.w0.c0() != getHeight()) {
            this.w0.E1(this);
            J();
        } else {
            this.w0.E1(this);
        }
        K();
    }

    void H0() {
        int iJ = this.o0.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            ((q) this.o0.i(i2).getLayoutParams()).c = true;
        }
        this.l0.s();
    }

    public boolean H1(int i2, int i3) {
        return getScrollingChildHelper().p(i2, i3);
    }

    void I0() {
        int iJ = this.o0.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            F fN0 = n0(this.o0.i(i2));
            if (fN0 != null && !fN0.K()) {
                fN0.b(6);
            }
        }
        H0();
        this.l0.t();
    }

    public void J0(int i2, int i3) {
        K0(i2, i3, null, 1);
    }

    void J1(boolean z2) {
        if (this.G0 < 1) {
            if (J1) {
                throw new IllegalStateException("stopInterceptRequestLayout was called more times than startInterceptRequestLayout." + V());
            }
            this.G0 = 1;
        }
        if (!z2 && !this.I0) {
            this.H0 = false;
        }
        if (this.G0 == 1) {
            if (z2 && this.H0 && !this.I0 && this.w0 != null && this.v0 != null) {
                H();
            }
            if (!this.I0) {
                this.H0 = false;
            }
        }
        this.G0--;
    }

    public void K1(int i2) {
        getScrollingChildHelper().r(i2);
    }

    public boolean L(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().d(i2, i3, iArr, iArr2, i4);
    }

    public void L0(int i2) {
        int iG = this.o0.g();
        for (int i3 = 0; i3 < iG; i3++) {
            this.o0.f(i3).offsetLeftAndRight(i2);
        }
    }

    public void L1() {
        setScrollState(0);
        M1();
    }

    public final void M(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().e(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    public void M0(int i2) {
        int iG = this.o0.g();
        for (int i3 = 0; i3 < iG; i3++) {
            this.o0.f(i3).offsetTopAndBottom(i2);
        }
    }

    void N(int i2) {
        p pVar = this.w0;
        if (pVar != null) {
            pVar.j1(i2);
        }
        W0(i2);
        u uVar = this.q1;
        if (uVar != null) {
            uVar.a(this, i2);
        }
        List<u> list = this.r1;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.r1.get(size).a(this, i2);
            }
        }
    }

    void N0(int i2, int i3) {
        int iJ = this.o0.j();
        for (int i4 = 0; i4 < iJ; i4++) {
            F fN0 = n0(this.o0.i(i4));
            if (fN0 != null && !fN0.K() && fN0.c >= i2) {
                if (K1) {
                    Log.d("RecyclerView", "offsetPositionRecordsForInsert attached child " + i4 + " holder " + fN0 + " now at position " + (fN0.c + i3));
                }
                fN0.B(i3, false);
                this.p1.g = true;
            }
        }
        this.l0.v(i2, i3);
        requestLayout();
    }

    void N1(int i2, int i3, Object obj) {
        int i4;
        int iJ = this.o0.j();
        int i5 = i2 + i3;
        for (int i6 = 0; i6 < iJ; i6++) {
            View viewI = this.o0.i(i6);
            F fN0 = n0(viewI);
            if (fN0 != null && !fN0.K() && (i4 = fN0.c) >= i2 && i4 < i5) {
                fN0.b(2);
                fN0.a(obj);
                ((q) viewI.getLayoutParams()).c = true;
            }
        }
        this.l0.R(i2, i3);
    }

    void O(int i2, int i3) {
        this.R0++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i2, scrollY - i3);
        X0(i2, i3);
        u uVar = this.q1;
        if (uVar != null) {
            uVar.b(this, i2, i3);
        }
        List<u> list = this.r1;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.r1.get(size).b(this, i2, i3);
            }
        }
        this.R0--;
    }

    void O0(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int iJ = this.o0.j();
        if (i2 < i3) {
            i6 = -1;
            i5 = i2;
            i4 = i3;
        } else {
            i4 = i2;
            i5 = i3;
            i6 = 1;
        }
        for (int i8 = 0; i8 < iJ; i8++) {
            F fN0 = n0(this.o0.i(i8));
            if (fN0 != null && (i7 = fN0.c) >= i5 && i7 <= i4) {
                if (K1) {
                    Log.d("RecyclerView", "offsetPositionRecordsForMove attached child " + i8 + " holder " + fN0);
                }
                if (fN0.c == i2) {
                    fN0.B(i3 - i2, false);
                } else {
                    fN0.B(i6, false);
                }
                this.p1.g = true;
            }
        }
        this.l0.w(i2, i3);
        requestLayout();
    }

    void P() {
        int i2;
        for (int size = this.D1.size() - 1; size >= 0; size--) {
            F f = this.D1.get(size);
            if (f.a.getParent() == this && !f.K() && (i2 = f.q) != -1) {
                C1839d0.s0(f.a, i2);
                f.q = -1;
            }
        }
        this.D1.clear();
    }

    void P0(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int iJ = this.o0.j();
        for (int i5 = 0; i5 < iJ; i5++) {
            F fN0 = n0(this.o0.i(i5));
            if (fN0 != null && !fN0.K()) {
                int i6 = fN0.c;
                if (i6 >= i4) {
                    if (K1) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + fN0 + " now at position " + (fN0.c - i3));
                    }
                    fN0.B(-i3, z2);
                    this.p1.g = true;
                } else if (i6 >= i2) {
                    if (K1) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + fN0 + " now REMOVED");
                    }
                    fN0.i(i2 - 1, -i3, z2);
                    this.p1.g = true;
                }
            }
        }
        this.l0.x(i2, i3, z2);
        requestLayout();
    }

    public void Q0(View view) {
    }

    void R() {
        if (this.W0 != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.S0.a(this, 3);
        this.W0 = edgeEffectA;
        if (this.q0) {
            edgeEffectA.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectA.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void R0(View view) {
    }

    void S() {
        if (this.T0 != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.S0.a(this, 0);
        this.T0 = edgeEffectA;
        if (this.q0) {
            edgeEffectA.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectA.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    void S0() {
        this.Q0++;
    }

    void T() {
        if (this.V0 != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.S0.a(this, 2);
        this.V0 = edgeEffectA;
        if (this.q0) {
            edgeEffectA.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectA.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    void T0() {
        U0(true);
    }

    void U() {
        if (this.U0 != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.S0.a(this, 1);
        this.U0 = edgeEffectA;
        if (this.q0) {
            edgeEffectA.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectA.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    void U0(boolean z2) {
        int i2 = this.Q0 - 1;
        this.Q0 = i2;
        if (i2 < 1) {
            if (J1 && i2 < 0) {
                throw new IllegalStateException("layout or scroll counter cannot go below zero.Some calls are not matching" + V());
            }
            this.Q0 = 0;
            if (z2) {
                G();
                P();
            }
        }
    }

    String V() {
        return " " + super.toString() + ", adapter:" + this.v0 + ", layout:" + this.w0 + ", context:" + getContext();
    }

    final void W(B b) {
        if (getScrollState() != 2) {
            b.p = 0;
            b.q = 0;
        } else {
            OverScroller overScroller = this.m1.Y;
            b.p = overScroller.getFinalX() - overScroller.getCurrX();
            b.q = overScroller.getFinalY() - overScroller.getCurrY();
        }
    }

    public void W0(int i2) {
    }

    public View X(float f, float f2) {
        for (int iG = this.o0.g() - 1; iG >= 0; iG--) {
            View viewF = this.o0.f(iG);
            float translationX = viewF.getTranslationX();
            float translationY = viewF.getTranslationY();
            if (f >= viewF.getLeft() + translationX && f <= viewF.getRight() + translationX && f2 >= viewF.getTop() + translationY && f2 <= viewF.getBottom() + translationY) {
                return viewF;
            }
        }
        return null;
    }

    public void X0(int i2, int i3) {
    }

    public View Y(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    void Y0() {
        if (this.v1 || !this.C0) {
            return;
        }
        C1839d0.d0(this, this.E1);
        this.v1 = true;
    }

    public F Z(View view) {
        View viewY = Y(view);
        if (viewY == null) {
            return null;
        }
        return m0(viewY);
    }

    void a(int i2, int i3) {
        if (i2 < 0) {
            S();
            if (this.T0.isFinished()) {
                this.T0.onAbsorb(-i2);
            }
        } else if (i2 > 0) {
            T();
            if (this.V0.isFinished()) {
                this.V0.onAbsorb(i2);
            }
        }
        if (i3 < 0) {
            U();
            if (this.U0.isFinished()) {
                this.U0.onAbsorb(-i3);
            }
        } else if (i3 > 0) {
            R();
            if (this.W0.isFinished()) {
                this.W0.onAbsorb(i3);
            }
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        C1839d0.c0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        p pVar = this.w0;
        if (pVar == null || !pVar.K0(this, arrayList, i2, i3)) {
            super.addFocusables(arrayList, i2, i3);
        }
    }

    void b1(boolean z2) {
        this.P0 = z2 | this.P0;
        this.O0 = true;
        I0();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof q) && this.w0.s((q) layoutParams);
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        p pVar = this.w0;
        if (pVar != null && pVar.q()) {
            return this.w0.w(this.p1);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        p pVar = this.w0;
        if (pVar != null && pVar.q()) {
            return this.w0.x(this.p1);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        p pVar = this.w0;
        if (pVar != null && pVar.q()) {
            return this.w0.y(this.p1);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        p pVar = this.w0;
        if (pVar != null && pVar.r()) {
            return this.w0.z(this.p1);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        p pVar = this.w0;
        if (pVar != null && pVar.r()) {
            return this.w0.A(this.p1);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        p pVar = this.w0;
        if (pVar != null && pVar.r()) {
            return this.w0.B(this.p1);
        }
        return 0;
    }

    void d1(F f, m.c cVar) {
        f.G(0, 8192);
        if (this.p1.i && f.z() && !f.w() && !f.K()) {
            this.p0.c(j0(f), f);
        }
        this.p0.e(f, cVar);
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f, float f2, boolean z2) {
        return getScrollingChildHelper().a(f, f2, z2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().b(f, f2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().f(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        int size = this.z0.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            this.z0.get(i2).k(canvas, this, this.p1);
        }
        EdgeEffect edgeEffect = this.T0;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.q0 ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.T0;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.U0;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.q0) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.U0;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.V0;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.q0 ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.V0;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.W0;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.q0) {
                canvas.translate((-getWidth()) + getPaddingRight(), (-getHeight()) + getPaddingBottom());
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.W0;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(iSave4);
        }
        if ((z2 || this.X0 == null || this.z0.size() <= 0 || !this.X0.p()) ? z2 : true) {
            C1839d0.c0(this);
        }
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public F e0(int i2) {
        F f = null;
        if (this.O0) {
            return null;
        }
        int iJ = this.o0.j();
        for (int i3 = 0; i3 < iJ; i3++) {
            F fN0 = n0(this.o0.i(i3));
            if (fN0 != null && !fN0.w() && i0(fN0) == i2) {
                if (!this.o0.n(fN0.a)) {
                    return fN0;
                }
                f = fN0;
            }
        }
        return f;
    }

    public F f0(long j2) {
        h hVar = this.v0;
        F f = null;
        if (hVar != null && hVar.q()) {
            int iJ = this.o0.j();
            for (int i2 = 0; i2 < iJ; i2++) {
                F fN0 = n0(this.o0.i(i2));
                if (fN0 != null && !fN0.w() && fN0.l() == j2) {
                    if (!this.o0.n(fN0.a)) {
                        return fN0;
                    }
                    f = fN0;
                }
            }
        }
        return f;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i2) {
        View viewO0;
        boolean z2;
        View viewV0 = this.w0.V0(view, i2);
        if (viewV0 != null) {
            return viewV0;
        }
        boolean z3 = (this.v0 == null || this.w0 == null || E0() || this.I0) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        if (z3 && (i2 == 2 || i2 == 1)) {
            if (this.w0.r()) {
                int i3 = i2 == 2 ? 130 : 33;
                z2 = focusFinder.findNextFocus(this, view, i3) == null;
                if (R1) {
                    i2 = i3;
                }
            } else {
                z2 = false;
            }
            if (!z2 && this.w0.q()) {
                int i4 = (this.w0.e0() == 1) ^ (i2 == 2) ? 66 : 17;
                boolean z4 = focusFinder.findNextFocus(this, view, i4) == null;
                if (R1) {
                    i2 = i4;
                }
                z2 = z4;
            }
            if (z2) {
                A();
                if (Y(view) == null) {
                    return null;
                }
                G1();
                this.w0.O0(view, i2, this.l0, this.p1);
                J1(false);
            }
            viewO0 = focusFinder.findNextFocus(this, view, i2);
        } else {
            View viewFindNextFocus = focusFinder.findNextFocus(this, view, i2);
            if (viewFindNextFocus == null && z3) {
                A();
                if (Y(view) == null) {
                    return null;
                }
                G1();
                viewO0 = this.w0.O0(view, i2, this.l0, this.p1);
                J1(false);
            } else {
                viewO0 = viewFindNextFocus;
            }
        }
        if (viewO0 == null || viewO0.hasFocusable()) {
            return F0(view, viewO0, i2) ? viewO0 : super.focusSearch(view, i2);
        }
        if (getFocusedChild() == null) {
            return super.focusSearch(view, i2);
        }
        p1(viewO0, null);
        return view;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002a  */
    /* JADX WARN: Code duplicated, block: B:17:0x0034  */
    /* JADX WARN: Code duplicated, block: B:22:0x0036 A[SYNTHETIC] */
    F g0(int i2, boolean z2) {
        int iJ = this.o0.j();
        F f = null;
        for (int i3 = 0; i3 < iJ; i3++) {
            F fN0 = n0(this.o0.i(i3));
            if (fN0 != null && !fN0.w()) {
                if (z2) {
                    if (fN0.c != i2) {
                        continue;
                    } else {
                        if (this.o0.n(fN0.a)) {
                            return fN0;
                        }
                        f = fN0;
                    }
                } else if (fN0.n() != i2) {
                    continue;
                } else {
                    if (this.o0.n(fN0.a)) {
                        return fN0;
                    }
                    f = fN0;
                }
            }
        }
        return f;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        p pVar = this.w0;
        if (pVar != null) {
            return pVar.J();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + V());
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        p pVar = this.w0;
        if (pVar != null) {
            return pVar.K(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + V());
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        p pVar = this.w0;
        if (pVar != null) {
            return pVar.L(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + V());
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public h getAdapter() {
        return this.v0;
    }

    @Override // android.view.View
    public int getBaseline() {
        p pVar = this.w0;
        return pVar != null ? pVar.M() : super.getBaseline();
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        k kVar = this.x1;
        return kVar == null ? super.getChildDrawingOrder(i2, i3) : kVar.a(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.q0;
    }

    public androidx.recyclerview.widget.q getCompatAccessibilityDelegate() {
        return this.w1;
    }

    public l getEdgeEffectFactory() {
        return this.S0;
    }

    public m getItemAnimator() {
        return this.X0;
    }

    public int getItemDecorationCount() {
        return this.z0.size();
    }

    public p getLayoutManager() {
        return this.w0;
    }

    public int getMaxFlingVelocity() {
        return this.i1;
    }

    public int getMinFlingVelocity() {
        return this.h1;
    }

    long getNanoTime() {
        if (Q1) {
            return System.nanoTime();
        }
        return 0L;
    }

    public s getOnFlingListener() {
        return this.g1;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.l1;
    }

    public v getRecycledViewPool() {
        return this.l0.i();
    }

    public int getScrollState() {
        return this.Y0;
    }

    /* JADX WARN: Code duplicated, block: B:39:0x007a  */
    /* JADX WARN: Code duplicated, block: B:57:0x00bc  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v6 */
    public boolean h0(int i2, int i3) {
        int iMax;
        int i4;
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        }
        if (this.I0) {
            return false;
        }
        int iQ = pVar.q();
        boolean zR = this.w0.r();
        if (iQ == 0 || Math.abs(i2) < this.h1) {
            i2 = 0;
        }
        if (!zR || Math.abs(i3) < this.h1) {
            i3 = 0;
        }
        if (i2 == 0 && i3 == 0) {
            return false;
        }
        if (i2 == 0) {
            iMax = 0;
        } else {
            EdgeEffect edgeEffect = this.T0;
            if (edgeEffect == null || ax.p115h0.d.b(edgeEffect) == 0.0f) {
                EdgeEffect edgeEffect2 = this.V0;
                if (edgeEffect2 == null || ax.p115h0.d.b(edgeEffect2) == 0.0f) {
                    iMax = 0;
                } else if (z1(this.V0, i2, getWidth())) {
                    this.V0.onAbsorb(i2);
                    i2 = 0;
                }
            } else {
                int i5 = -i2;
                if (z1(this.T0, i5, getWidth())) {
                    this.T0.onAbsorb(i5);
                    i2 = 0;
                }
            }
            iMax = i2;
            i2 = 0;
        }
        if (i3 == 0) {
            i4 = i3;
            i3 = 0;
        } else {
            EdgeEffect edgeEffect3 = this.U0;
            if (edgeEffect3 == null || ax.p115h0.d.b(edgeEffect3) == 0.0f) {
                EdgeEffect edgeEffect4 = this.W0;
                if (edgeEffect4 == null || ax.p115h0.d.b(edgeEffect4) == 0.0f) {
                    i4 = i3;
                    i3 = 0;
                } else if (z1(this.W0, i3, getHeight())) {
                    this.W0.onAbsorb(i3);
                    i3 = 0;
                }
            } else {
                int i6 = -i3;
                if (z1(this.U0, i6, getHeight())) {
                    this.U0.onAbsorb(i6);
                    i3 = 0;
                }
            }
            i4 = 0;
        }
        if (iMax != 0 || i3 != 0) {
            int i7 = this.i1;
            iMax = Math.max(-i7, Math.min(iMax, i7));
            int i8 = this.i1;
            i3 = Math.max(-i8, Math.min(i3, i8));
            this.m1.b(iMax, i3);
        }
        if (i2 == 0 && i4 == 0) {
            return (iMax == 0 && i3 == 0) ? false : true;
        }
        float f = i2;
        float f2 = i4;
        if (!dispatchNestedPreFling(f, f2)) {
            boolean z2 = iQ != 0 || zR;
            dispatchNestedFling(f, f2, z2);
            s sVar = this.g1;
            if (sVar != null && sVar.a(i2, i4)) {
                return true;
            }
            if (z2) {
                if (zR) {
                    iQ = (iQ == true ? 1 : 0) | 2;
                }
                H1(iQ, 1);
                int i9 = this.i1;
                int iMax2 = Math.max(-i9, Math.min(i2, i9));
                int i10 = this.i1;
                this.m1.b(iMax2, Math.max(-i10, Math.min(i4, i10)));
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().j();
    }

    int i0(F f) {
        if (f.q(524) || !f.t()) {
            return -1;
        }
        return this.n0.e(f.c);
    }

    void i1() {
        m mVar = this.X0;
        if (mVar != null) {
            mVar.k();
        }
        p pVar = this.w0;
        if (pVar != null) {
            pVar.p1(this.l0);
            this.w0.q1(this.l0);
        }
        this.l0.c();
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return this.C0;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.I0;
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().l();
    }

    public void j(o oVar) {
        k(oVar, -1);
    }

    long j0(F f) {
        return this.v0.q() ? f.l() : f.c;
    }

    boolean j1(View view) {
        G1();
        boolean zR = this.o0.r(view);
        if (zR) {
            F fN0 = n0(view);
            this.l0.O(fN0);
            this.l0.H(fN0);
            if (K1) {
                Log.d("RecyclerView", "after removing animated view: " + view + ", " + this);
            }
        }
        J1(!zR);
        return zR;
    }

    public void k(o oVar, int i2) {
        p pVar = this.w0;
        if (pVar != null) {
            pVar.m("Cannot add item decoration during a scroll  or layout");
        }
        if (this.z0.isEmpty()) {
            setWillNotDraw(false);
        }
        if (i2 < 0) {
            this.z0.add(oVar);
        } else {
            this.z0.add(i2, oVar);
        }
        H0();
        requestLayout();
    }

    public int k0(View view) {
        F fN0 = n0(view);
        if (fN0 != null) {
            return fN0.j();
        }
        return -1;
    }

    public void k1(o oVar) {
        p pVar = this.w0;
        if (pVar != null) {
            pVar.m("Cannot remove item decoration during a scroll  or layout");
        }
        this.z0.remove(oVar);
        if (this.z0.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        H0();
        requestLayout();
    }

    public void l(r rVar) {
        if (this.N0 == null) {
            this.N0 = new ArrayList();
        }
        this.N0.add(rVar);
    }

    public int l0(View view) {
        F fN0 = n0(view);
        if (fN0 != null) {
            return fN0.n();
        }
        return -1;
    }

    public void l1(r rVar) {
        List<r> list = this.N0;
        if (list == null) {
            return;
        }
        list.remove(rVar);
    }

    public void m(t tVar) {
        this.A0.add(tVar);
    }

    public F m0(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return n0(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public void m1(t tVar) {
        this.A0.remove(tVar);
        if (this.B0 == tVar) {
            this.B0 = null;
        }
    }

    public void n(u uVar) {
        if (this.r1 == null) {
            this.r1 = new ArrayList();
        }
        this.r1.add(uVar);
    }

    public void n1(u uVar) {
        List<u> list = this.r1;
        if (list != null) {
            list.remove(uVar);
        }
    }

    void o(F f, m.c cVar, m.c cVar2) {
        f.H(false);
        if (this.X0.a(f, cVar, cVar2)) {
            Y0();
        }
    }

    public void o0(View view, Rect rect) {
        p0(view, rect);
    }

    void o1() {
        F f;
        int iG = this.o0.g();
        for (int i2 = 0; i2 < iG; i2++) {
            View viewF = this.o0.f(i2);
            F fM0 = m0(viewF);
            if (fM0 != null && (f = fM0.i) != null) {
                View view = f.a;
                int left = viewF.getLeft();
                int top = viewF.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0053  */
    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.Q0 = 0;
        this.C0 = true;
        this.F0 = this.F0 && !isLayoutRequested();
        this.l0.z();
        p pVar = this.w0;
        if (pVar != null) {
            pVar.F(this);
        }
        this.v1 = false;
        if (Q1) {
            ThreadLocal<androidx.recyclerview.widget.h> threadLocal = androidx.recyclerview.widget.h.k0;
            androidx.recyclerview.widget.h hVar = threadLocal.get();
            this.n1 = hVar;
            if (hVar == null) {
                this.n1 = new androidx.recyclerview.widget.h();
                Display displayU = C1839d0.u(this);
                if (isInEditMode() || displayU == null) {
                    refreshRate = 60.0f;
                } else {
                    refreshRate = displayU.getRefreshRate();
                    if (refreshRate < 30.0f) {
                        refreshRate = 60.0f;
                    }
                }
                androidx.recyclerview.widget.h hVar2 = this.n1;
                hVar2.Y = (long) (1.0E9f / refreshRate);
                threadLocal.set(hVar2);
            }
            this.n1.a(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        androidx.recyclerview.widget.h hVar;
        super.onDetachedFromWindow();
        m mVar = this.X0;
        if (mVar != null) {
            mVar.k();
        }
        L1();
        this.C0 = false;
        p pVar = this.w0;
        if (pVar != null) {
            pVar.G(this, this.l0);
        }
        this.D1.clear();
        removeCallbacks(this.E1);
        this.p0.j();
        this.l0.A();
        ax.p147j0.a.b(this);
        if (!Q1 || (hVar = this.n1) == null) {
            return;
        }
        hVar.j(this);
        this.n1 = null;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.z0.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.z0.get(i2).i(canvas, this, this.p1);
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0062  */
    @Override // android.view.View
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float axisValue;
        if (this.w0 != null && !this.I0 && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f = this.w0.r() ? -motionEvent.getAxisValue(9) : 0.0f;
                axisValue = this.w0.q() ? motionEvent.getAxisValue(10) : 0.0f;
            } else if ((motionEvent.getSource() & 4194304) != 0) {
                float axisValue2 = motionEvent.getAxisValue(26);
                if (this.w0.r()) {
                    f = -axisValue2;
                } else if (this.w0.q()) {
                    axisValue = axisValue2;
                    f = 0.0f;
                } else {
                    f = 0.0f;
                }
            } else {
                f = 0.0f;
            }
            if (f != 0.0f || axisValue != 0.0f) {
                K0((int) (axisValue * this.j1), (int) (f * this.k1), motionEvent, 1);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.I0) {
            return false;
        }
        this.B0 = null;
        if (a0(motionEvent)) {
            t();
            return true;
        }
        p pVar = this.w0;
        if (pVar == null) {
            return false;
        }
        boolean zQ = pVar.q();
        boolean zR = this.w0.r();
        if (this.a1 == null) {
            this.a1 = VelocityTracker.obtain();
        }
        this.a1.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.J0) {
                this.J0 = false;
            }
            this.Z0 = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.d1 = x2;
            this.b1 = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.e1 = y2;
            this.c1 = y2;
            if (I1(motionEvent) || this.Y0 == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                K1(1);
            }
            int[] iArr = this.B1;
            iArr[1] = 0;
            iArr[0] = 0;
            int i2 = zQ;
            if (zR) {
                i2 = (zQ ? 1 : 0) | 2;
            }
            H1(i2, 0);
        } else if (actionMasked == 1) {
            this.a1.clear();
            K1(0);
        } else if (actionMasked == 2) {
            int iFindPointerIndex = motionEvent.findPointerIndex(this.Z0);
            if (iFindPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.Z0 + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
            if (this.Y0 != 1) {
                int i3 = x3 - this.b1;
                int i4 = y3 - this.c1;
                if (!zQ || Math.abs(i3) <= this.f1) {
                    z2 = false;
                } else {
                    this.d1 = x3;
                    z2 = true;
                }
                if (zR && Math.abs(i4) > this.f1) {
                    this.e1 = y3;
                    z2 = true;
                }
                if (z2) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            t();
        } else if (actionMasked == 5) {
            this.Z0 = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.d1 = x4;
            this.b1 = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.e1 = y4;
            this.c1 = y4;
        } else if (actionMasked == 6) {
            V0(motionEvent);
        }
        return this.Y0 == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        ax.Y.u.a("RV OnLayout");
        H();
        ax.Y.u.b();
        this.F0 = true;
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        p pVar = this.w0;
        if (pVar == null) {
            C(i2, i3);
            return;
        }
        boolean z2 = false;
        if (pVar.x0()) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.w0.e1(this.l0, this.p1, i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            this.F1 = z2;
            if (z2 || this.v0 == null) {
                return;
            }
            if (this.p1.e == 1) {
                I();
            }
            this.w0.F1(i2, i3);
            this.p1.j = true;
            J();
            this.w0.I1(i2, i3);
            if (this.w0.L1()) {
                this.w0.F1(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                this.p1.j = true;
                J();
                this.w0.I1(i2, i3);
            }
            this.G1 = getMeasuredWidth();
            this.H1 = getMeasuredHeight();
            return;
        }
        if (this.D0) {
            this.w0.e1(this.l0, this.p1, i2, i3);
            return;
        }
        if (this.L0) {
            G1();
            S0();
            a1();
            T0();
            B b = this.p1;
            if (b.l) {
                b.h = true;
            } else {
                this.n0.j();
                this.p1.h = false;
            }
            this.L0 = false;
            J1(false);
        } else if (this.p1.l) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        h hVar = this.v0;
        if (hVar != null) {
            this.p1.f = hVar.l();
        } else {
            this.p1.f = 0;
        }
        G1();
        this.w0.e1(this.l0, this.p1, i2, i3);
        J1(false);
        this.p1.h = false;
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (E0()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof z)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        z zVar = (z) parcelable;
        this.m0 = zVar;
        super.onRestoreInstanceState(zVar.a());
        requestLayout();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        z zVar = new z(super.onSaveInstanceState());
        z zVar2 = this.m0;
        if (zVar2 != null) {
            zVar.b(zVar2);
            return zVar;
        }
        p pVar = this.w0;
        if (pVar != null) {
            zVar.Y = pVar.i1();
            return zVar;
        }
        zVar.Y = null;
        return zVar;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        B0();
    }

    /* JADX WARN: Code duplicated, block: B:47:0x00df A[PHI: r1
      0x00df: PHI (r1v46 int) = (r1v26 int), (r1v50 int) binds: [B:41:0x00c8, B:45:0x00db] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i2;
        boolean z2;
        if (this.I0 || this.J0) {
            return false;
        }
        if (Q(motionEvent)) {
            t();
            return true;
        }
        p pVar = this.w0;
        if (pVar == null) {
            return false;
        }
        boolean zQ = pVar.q();
        boolean zR = this.w0.r();
        if (this.a1 == null) {
            this.a1 = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            int[] iArr = this.B1;
            iArr[1] = 0;
            iArr[0] = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        int[] iArr2 = this.B1;
        motionEventObtain.offsetLocation(iArr2[0], iArr2[1]);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                this.a1.addMovement(motionEventObtain);
                this.a1.computeCurrentVelocity(1000, this.i1);
                float f = zQ ? -this.a1.getXVelocity(this.Z0) : 0.0f;
                float f2 = zR ? -this.a1.getYVelocity(this.Z0) : 0.0f;
                if ((f == 0.0f && f2 == 0.0f) || !h0((int) f, (int) f2)) {
                    setScrollState(0);
                }
                r1();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.Z0);
                if (iFindPointerIndex < 0) {
                    Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.Z0 + " not found. Did any MotionEvents get skipped?");
                    return false;
                }
                int x2 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                int y2 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                int iMax = this.d1 - x2;
                int iMax2 = this.e1 - y2;
                if (this.Y0 != 1) {
                    if (zQ) {
                        iMax = iMax > 0 ? Math.max(0, iMax - this.f1) : Math.min(0, iMax + this.f1);
                        if (iMax != 0) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                    } else {
                        z2 = false;
                    }
                    if (zR) {
                        iMax2 = iMax2 > 0 ? Math.max(0, iMax2 - this.f1) : Math.min(0, iMax2 + this.f1);
                        if (iMax2 != 0) {
                            z2 = true;
                        }
                    }
                    if (z2) {
                        setScrollState(1);
                    }
                }
                if (this.Y0 == 1) {
                    int[] iArr3 = this.C1;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    int iG1 = iMax - g1(iMax, motionEvent.getY());
                    int iH1 = iMax2 - h1(iMax2, motionEvent.getX());
                    if (L(zQ ? iG1 : 0, zR ? iH1 : 0, this.C1, this.A1, 0)) {
                        int[] iArr4 = this.C1;
                        iG1 -= iArr4[0];
                        iH1 -= iArr4[1];
                        int[] iArr5 = this.B1;
                        int i3 = iArr5[0];
                        int[] iArr6 = this.A1;
                        iArr5[0] = i3 + iArr6[0];
                        iArr5[1] = iArr5[1] + iArr6[1];
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    int[] iArr7 = this.A1;
                    this.d1 = x2 - iArr7[0];
                    this.e1 = y2 - iArr7[1];
                    if (u1(zQ ? iG1 : 0, zR ? iH1 : 0, motionEvent, 0)) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    androidx.recyclerview.widget.h hVar = this.n1;
                    if (hVar != null && (iG1 != 0 || iH1 != 0)) {
                        hVar.f(this, iG1, iH1);
                    }
                }
            } else if (actionMasked == 3) {
                t();
            } else if (actionMasked == 5) {
                this.Z0 = motionEvent.getPointerId(actionIndex);
                int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                this.d1 = x3;
                this.b1 = x3;
                int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                this.e1 = y3;
                this.c1 = y3;
            } else if (actionMasked == 6) {
                V0(motionEvent);
            }
            motionEventObtain.recycle();
            return true;
        }
        this.Z0 = motionEvent.getPointerId(0);
        int x4 = (int) (motionEvent.getX() + 0.5f);
        this.d1 = x4;
        this.b1 = x4;
        int y4 = (int) (motionEvent.getY() + 0.5f);
        this.e1 = y4;
        this.c1 = y4;
        if (zR) {
            i2 = zQ;
            i2 = (zQ ? 1 : 0) | 2;
        }
        i2 = zQ;
        H1(i2, 0);
        this.a1.addMovement(motionEventObtain);
        motionEventObtain.recycle();
        return true;
    }

    void q(F f, m.c cVar, m.c cVar2) {
        i(f);
        f.H(false);
        if (this.X0.c(f, cVar, cVar2)) {
            Y0();
        }
    }

    void r(String str) {
        if (E0()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + V());
        }
        if (this.R0 > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(HttpUrl.FRAGMENT_ENCODE_SET + V()));
        }
    }

    @Override // android.view.ViewGroup
    protected void removeDetachedView(View view, boolean z2) {
        F fN0 = n0(view);
        if (fN0 != null) {
            if (fN0.y()) {
                fN0.f();
            } else if (!fN0.K()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + fN0 + V());
            }
        } else if (J1) {
            throw new IllegalArgumentException("No ViewHolder found for child: " + view + V());
        }
        view.clearAnimation();
        F(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (!this.w0.g1(this, this.p1, view, view2) && view2 != null) {
            p1(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.w0.w1(this, view, rect, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        int size = this.A0.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.A0.get(i2).e(z2);
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.G0 != 0 || this.I0) {
            this.H0 = true;
        } else {
            super.requestLayout();
        }
    }

    boolean s(F f) {
        m mVar = this.X0;
        return mVar == null || mVar.g(f, f.p());
    }

    Rect s0(View view) {
        q qVar = (q) view.getLayoutParams();
        if (!qVar.c) {
            return qVar.b;
        }
        if (this.p1.e() && (qVar.b() || qVar.d())) {
            return qVar.b;
        }
        Rect rect = qVar.b;
        rect.set(0, 0, 0, 0);
        int size = this.z0.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.s0.set(0, 0, 0, 0);
            this.z0.get(i2).g(this.s0, view, this, this.p1);
            int i3 = rect.left;
            Rect rect2 = this.s0;
            rect.left = i3 + rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        qVar.c = false;
        return rect;
    }

    @Override // android.view.View
    public void scrollBy(int i2, int i3) {
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.I0) {
            return;
        }
        boolean zQ = pVar.q();
        boolean zR = this.w0.r();
        if (zQ || zR) {
            if (!zQ) {
                i2 = 0;
            }
            if (!zR) {
                i3 = 0;
            }
            u1(i2, i3, null, 0);
        }
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (A1(accessibilityEvent)) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(androidx.recyclerview.widget.q qVar) {
        this.w1 = qVar;
        C1839d0.l0(this, qVar);
    }

    public void setAdapter(h hVar) {
        setLayoutFrozen(false);
        x1(hVar, false, true);
        b1(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(k kVar) {
        if (kVar == this.x1) {
            return;
        }
        this.x1 = kVar;
        setChildrenDrawingOrderEnabled(kVar != null);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.q0) {
            B0();
        }
        this.q0 = z2;
        super.setClipToPadding(z2);
        if (this.F0) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(l lVar) {
        ax.p019b0.g.g(lVar);
        this.S0 = lVar;
        B0();
    }

    public void setHasFixedSize(boolean z2) {
        this.D0 = z2;
    }

    public void setItemAnimator(m mVar) {
        m mVar2 = this.X0;
        if (mVar2 != null) {
            mVar2.k();
            this.X0.w(null);
        }
        this.X0 = mVar;
        if (mVar != null) {
            mVar.w(this.u1);
        }
    }

    public void setItemViewCacheSize(int i2) {
        this.l0.L(i2);
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(p pVar) {
        if (pVar == this.w0) {
            return;
        }
        L1();
        if (this.w0 != null) {
            m mVar = this.X0;
            if (mVar != null) {
                mVar.k();
            }
            this.w0.p1(this.l0);
            this.w0.q1(this.l0);
            this.l0.c();
            if (this.C0) {
                this.w0.G(this, this.l0);
            }
            this.w0.J1(null);
            this.w0 = null;
        } else {
            this.l0.c();
        }
        this.o0.o();
        this.w0 = pVar;
        if (pVar != null) {
            if (pVar.b != null) {
                throw new IllegalArgumentException("LayoutManager " + pVar + " is already attached to a RecyclerView:" + pVar.b.V());
            }
            pVar.J1(this);
            if (this.C0) {
                this.w0.F(this);
            }
        }
        this.l0.P();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        getScrollingChildHelper().m(z2);
    }

    public void setOnFlingListener(s sVar) {
        this.g1 = sVar;
    }

    @Deprecated
    public void setOnScrollListener(u uVar) {
        this.q1 = uVar;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.l1 = z2;
    }

    public void setRecycledViewPool(v vVar) {
        this.l0.J(vVar);
    }

    @Deprecated
    public void setRecyclerListener(x xVar) {
        this.x0 = xVar;
    }

    void setScrollState(int i2) {
        if (i2 == this.Y0) {
            return;
        }
        if (K1) {
            Log.d("RecyclerView", "setting scroll state to " + i2 + " from " + this.Y0, new Exception());
        }
        this.Y0 = i2;
        if (i2 != 2) {
            M1();
        }
        N(i2);
    }

    public void setScrollingTouchSlop(int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                this.f1 = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
        }
        this.f1 = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(D d) {
        this.l0.K(d);
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().o(i2);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        getScrollingChildHelper().q();
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z2) {
        if (z2 != this.I0) {
            r("Do not suppressLayout in layout or scroll");
            if (z2) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
                this.I0 = true;
                this.J0 = true;
                L1();
                return;
            }
            this.I0 = false;
            if (this.H0 && this.w0 != null && this.v0 != null) {
                requestLayout();
            }
            this.H0 = false;
        }
    }

    void t1() {
        int iJ = this.o0.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            F fN0 = n0(this.o0.i(i2));
            if (J1 && fN0.c == -1 && !fN0.w()) {
                throw new IllegalStateException("view holder cannot have position -1 unless it is removed" + V());
            }
            if (!fN0.K()) {
                fN0.F();
            }
        }
    }

    boolean u1(int i2, int i3, MotionEvent motionEvent, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        A();
        if (this.v0 != null) {
            int[] iArr = this.C1;
            iArr[0] = 0;
            iArr[1] = 0;
            v1(i2, i3, iArr);
            int[] iArr2 = this.C1;
            int i9 = iArr2[0];
            int i10 = iArr2[1];
            i7 = i2 - i9;
            i8 = i3 - i10;
            i6 = i10;
            i5 = i9;
        } else {
            i5 = 0;
            i6 = 0;
            i7 = 0;
            i8 = 0;
        }
        if (!this.z0.isEmpty()) {
            invalidate();
        }
        int[] iArr3 = this.C1;
        iArr3[0] = 0;
        iArr3[1] = 0;
        M(i5, i6, i7, i8, this.A1, i4, iArr3);
        int[] iArr4 = this.C1;
        int i11 = iArr4[0];
        int i12 = i7 - i11;
        int i13 = iArr4[1];
        int i14 = i8 - i13;
        boolean z2 = (i11 == 0 && i13 == 0) ? false : true;
        int i15 = this.d1;
        int[] iArr5 = this.A1;
        int i16 = iArr5[0];
        this.d1 = i15 - i16;
        int i17 = this.e1;
        int i18 = iArr5[1];
        this.e1 = i17 - i18;
        int[] iArr6 = this.B1;
        iArr6[0] = iArr6[0] + i16;
        iArr6[1] = iArr6[1] + i18;
        if (getOverScrollMode() != 2) {
            if (motionEvent != null && !ax.p035c0.C.e(motionEvent, 8194)) {
                c1(motionEvent.getX(), i12, motionEvent.getY(), i14);
            }
            w(i2, i3);
        }
        if (i5 != 0 || i6 != 0) {
            O(i5, i6);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        return (!z2 && i5 == 0 && i6 == 0) ? false : true;
    }

    void v() {
        int iJ = this.o0.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            F fN0 = n0(this.o0.i(i2));
            if (!fN0.K()) {
                fN0.c();
            }
        }
        this.l0.d();
    }

    public boolean v0() {
        return !this.F0 || this.O0 || this.n0.p();
    }

    void v1(int i2, int i3, int[] iArr) {
        G1();
        S0();
        ax.Y.u.a("RV Scroll");
        W(this.p1);
        int iB1 = i2 != 0 ? this.w0.B1(i2, this.l0, this.p1) : 0;
        int iD1 = i3 != 0 ? this.w0.D1(i3, this.l0, this.p1) : 0;
        ax.Y.u.b();
        o1();
        T0();
        J1(false);
        if (iArr != null) {
            iArr[0] = iB1;
            iArr[1] = iD1;
        }
    }

    void w(int i2, int i3) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.T0;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            zIsFinished = false;
        } else {
            this.T0.onRelease();
            zIsFinished = this.T0.isFinished();
        }
        EdgeEffect edgeEffect2 = this.V0;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.V0.onRelease();
            zIsFinished |= this.V0.isFinished();
        }
        EdgeEffect edgeEffect3 = this.U0;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.U0.onRelease();
            zIsFinished |= this.U0.isFinished();
        }
        EdgeEffect edgeEffect4 = this.W0;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.W0.onRelease();
            zIsFinished |= this.W0.isFinished();
        }
        if (zIsFinished) {
            C1839d0.c0(this);
        }
    }

    public void w1(int i2) {
        if (this.I0) {
            return;
        }
        L1();
        p pVar = this.w0;
        if (pVar == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            pVar.C1(i2);
            awakenScrollBars();
        }
    }

    int x(int i2) {
        return y(i2, this.T0, this.V0, getWidth());
    }

    void x0() {
        this.n0 = new a(new C0672f());
    }

    boolean y1(F f, int i2) {
        if (!E0()) {
            C1839d0.s0(f.a, i2);
            return true;
        }
        f.q = i2;
        this.D1.add(f);
        return false;
    }

    int z(int i2) {
        return y(i2, this.U0, this.W0, getHeight());
    }
}
