package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;

/* JADX INFO: loaded from: classes.dex */
public class p extends t {
    private o d;
    private o e;

    class a extends l {
        a(Context context) {
            super(context);
        }

        @Override // androidx.recyclerview.widget.l, androidx.recyclerview.widget.RecyclerView.A
        protected void o(View view, RecyclerView.B b, RecyclerView.A.a aVar) {
            p pVar = p.this;
            int[] iArrC = pVar.c(pVar.a.getLayoutManager(), view);
            int i = iArrC[0];
            int i2 = iArrC[1];
            int iW = w(Math.max(Math.abs(i), Math.abs(i2)));
            if (iW > 0) {
                aVar.d(i, i2, iW, this.j);
            }
        }

        @Override // androidx.recyclerview.widget.l
        protected float v(DisplayMetrics displayMetrics) {
            return 100.0f / displayMetrics.densityDpi;
        }

        @Override // androidx.recyclerview.widget.l
        protected int x(int i) {
            return Math.min(100, super.x(i));
        }
    }

    private int k(View view, o oVar) {
        return (oVar.g(view) + (oVar.e(view) / 2)) - (oVar.m() + (oVar.n() / 2));
    }

    private View l(RecyclerView.p pVar, o oVar) {
        int iP = pVar.P();
        View view = null;
        if (iP == 0) {
            return null;
        }
        int iM = oVar.m() + (oVar.n() / 2);
        int i = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        for (int i2 = 0; i2 < iP; i2++) {
            View viewO = pVar.O(i2);
            int iAbs = Math.abs((oVar.g(viewO) + (oVar.e(viewO) / 2)) - iM);
            if (iAbs < i) {
                view = viewO;
                i = iAbs;
            }
        }
        return view;
    }

    private o m(RecyclerView.p pVar) {
        o oVar = this.e;
        if (oVar == null || oVar.a != pVar) {
            this.e = o.a(pVar);
        }
        return this.e;
    }

    private o n(RecyclerView.p pVar) {
        if (pVar.r()) {
            return o(pVar);
        }
        if (pVar.q()) {
            return m(pVar);
        }
        return null;
    }

    private o o(RecyclerView.p pVar) {
        o oVar = this.d;
        if (oVar == null || oVar.a != pVar) {
            this.d = o.c(pVar);
        }
        return this.d;
    }

    private boolean p(RecyclerView.p pVar, int i, int i2) {
        if (pVar.q()) {
            return i > 0;
        }
        return i2 > 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean q(RecyclerView.p pVar) {
        PointF pointFC;
        int iF = pVar.f();
        if (!(pVar instanceof RecyclerView.A.b) || (pointFC = ((RecyclerView.A.b) pVar).c(iF - 1)) == null) {
            return false;
        }
        return pointFC.x < 0.0f || pointFC.y < 0.0f;
    }

    @Override // androidx.recyclerview.widget.t
    public int[] c(RecyclerView.p pVar, View view) {
        int[] iArr = new int[2];
        if (pVar.q()) {
            iArr[0] = k(view, m(pVar));
        } else {
            iArr[0] = 0;
        }
        if (pVar.r()) {
            iArr[1] = k(view, o(pVar));
            return iArr;
        }
        iArr[1] = 0;
        return iArr;
    }

    @Override // androidx.recyclerview.widget.t
    protected RecyclerView.A d(RecyclerView.p pVar) {
        if (pVar instanceof RecyclerView.A.b) {
            return new a(this.a.getContext());
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.t
    @SuppressLint({"UnknownNullness"})
    public View f(RecyclerView.p pVar) {
        if (pVar.r()) {
            return l(pVar, o(pVar));
        }
        if (pVar.q()) {
            return l(pVar, m(pVar));
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.t
    @SuppressLint({"UnknownNullness"})
    public int g(RecyclerView.p pVar, int i, int i2) {
        o oVarN;
        int iF = pVar.f();
        if (iF == 0 || (oVarN = n(pVar)) == null) {
            return -1;
        }
        int iP = pVar.P();
        View view = null;
        View view2 = null;
        int i3 = Integer.MIN_VALUE;
        int i4 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        for (int i5 = 0; i5 < iP; i5++) {
            View viewO = pVar.O(i5);
            if (viewO != null) {
                int iK = k(viewO, oVarN);
                if (iK <= 0 && iK > i3) {
                    view2 = viewO;
                    i3 = iK;
                }
                if (iK >= 0 && iK < i4) {
                    view = viewO;
                    i4 = iK;
                }
            }
        }
        boolean zP = p(pVar, i, i2);
        if (zP && view != null) {
            return pVar.m0(view);
        }
        if (!zP && view2 != null) {
            return pVar.m0(view2);
        }
        if (zP) {
            view = view2;
        }
        if (view == null) {
            return -1;
        }
        int iM0 = pVar.m0(view) + (q(pVar) == zP ? -1 : 1);
        if (iM0 < 0 || iM0 >= iF) {
            return -1;
        }
        return iM0;
    }
}
