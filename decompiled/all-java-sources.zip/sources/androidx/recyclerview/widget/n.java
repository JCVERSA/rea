package androidx.recyclerview.widget;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
class n {
    final a a;

    interface a {
        void a(androidx.recyclerview.widget.a.b bVar);

        androidx.recyclerview.widget.a.b b(int i, int i2, int i3, Object obj);
    }

    n(a aVar) {
        this.a = aVar;
    }

    private int a(List<androidx.recyclerview.widget.a.b> list) {
        boolean z = false;
        for (int size = list.size() - 1; size >= 0; size--) {
            if (list.get(size).a != 8) {
                z = true;
            } else if (z) {
                return size;
            }
        }
        return -1;
    }

    private void c(List<androidx.recyclerview.widget.a.b> list, int i, androidx.recyclerview.widget.a.b bVar, int i2, androidx.recyclerview.widget.a.b bVar2) {
        int i3 = bVar.d;
        int i4 = bVar2.b;
        int i5 = i3 < i4 ? -1 : 0;
        int i6 = bVar.b;
        if (i6 < i4) {
            i5++;
        }
        if (i4 <= i6) {
            bVar.b = i6 + bVar2.d;
        }
        int i7 = bVar2.b;
        if (i7 <= i3) {
            bVar.d = i3 + bVar2.d;
        }
        bVar2.b = i7 + i5;
        list.set(i, bVar2);
        list.set(i2, bVar);
    }

    private void d(List<androidx.recyclerview.widget.a.b> list, int i, int i2) {
        androidx.recyclerview.widget.a.b bVar = list.get(i);
        androidx.recyclerview.widget.a.b bVar2 = list.get(i2);
        int i3 = bVar2.a;
        if (i3 == 1) {
            c(list, i, bVar, i2, bVar2);
        } else if (i3 == 2) {
            e(list, i, bVar, i2, bVar2);
        } else {
            if (i3 != 4) {
                return;
            }
            f(list, i, bVar, i2, bVar2);
        }
    }

    void b(List<androidx.recyclerview.widget.a.b> list) {
        while (true) {
            int iA = a(list);
            if (iA == -1) {
                return;
            } else {
                d(list, iA, iA + 1);
            }
        }
    }

    void e(List<androidx.recyclerview.widget.a.b> list, int i, androidx.recyclerview.widget.a.b bVar, int i2, androidx.recyclerview.widget.a.b bVar2) {
        boolean z;
        int i3 = bVar.b;
        int i4 = bVar.d;
        boolean z2 = false;
        if (i3 < i4) {
            if (bVar2.b == i3 && bVar2.d == i4 - i3) {
                z = false;
                z2 = true;
            } else {
                z = false;
            }
        } else if (bVar2.b == i4 + 1 && bVar2.d == i3 - i4) {
            z = true;
            z2 = true;
        } else {
            z = true;
        }
        int i5 = bVar2.b;
        if (i4 < i5) {
            bVar2.b = i5 - 1;
        } else {
            int i6 = bVar2.d;
            if (i4 < i5 + i6) {
                bVar2.d = i6 - 1;
                bVar.a = 2;
                bVar.d = 1;
                if (bVar2.d == 0) {
                    list.remove(i2);
                    this.a.a(bVar2);
                    return;
                }
                return;
            }
        }
        int i7 = bVar.b;
        int i8 = bVar2.b;
        androidx.recyclerview.widget.a.b bVarB = null;
        if (i7 <= i8) {
            bVar2.b = i8 + 1;
        } else {
            int i9 = bVar2.d;
            if (i7 < i8 + i9) {
                bVarB = this.a.b(2, i7 + 1, (i8 + i9) - i7, null);
                bVar2.d = bVar.b - bVar2.b;
            }
        }
        if (z2) {
            list.set(i, bVar2);
            list.remove(i2);
            this.a.a(bVar);
            return;
        }
        if (z) {
            if (bVarB != null) {
                int i10 = bVar.b;
                if (i10 > bVarB.b) {
                    bVar.b = i10 - bVarB.d;
                }
                int i11 = bVar.d;
                if (i11 > bVarB.b) {
                    bVar.d = i11 - bVarB.d;
                }
            }
            int i12 = bVar.b;
            if (i12 > bVar2.b) {
                bVar.b = i12 - bVar2.d;
            }
            int i13 = bVar.d;
            if (i13 > bVar2.b) {
                bVar.d = i13 - bVar2.d;
            }
        } else {
            if (bVarB != null) {
                int i14 = bVar.b;
                if (i14 >= bVarB.b) {
                    bVar.b = i14 - bVarB.d;
                }
                int i15 = bVar.d;
                if (i15 >= bVarB.b) {
                    bVar.d = i15 - bVarB.d;
                }
            }
            int i16 = bVar.b;
            if (i16 >= bVar2.b) {
                bVar.b = i16 - bVar2.d;
            }
            int i17 = bVar.d;
            if (i17 >= bVar2.b) {
                bVar.d = i17 - bVar2.d;
            }
        }
        list.set(i, bVar2);
        if (bVar.b != bVar.d) {
            list.set(i2, bVar);
        } else {
            list.remove(i2);
        }
        if (bVarB != null) {
            list.add(i, bVarB);
        }
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0027  */
    /* JADX WARN: Code duplicated, block: B:12:0x002b  */
    /* JADX WARN: Code duplicated, block: B:14:0x0031  */
    /* JADX WARN: Code duplicated, block: B:17:0x0048  */
    /* JADX WARN: Code duplicated, block: B:18:0x004c  */
    /* JADX WARN: Code duplicated, block: B:20:0x0056  */
    /* JADX WARN: Code duplicated, block: B:22:0x005b  */
    /* JADX WARN: Code duplicated, block: B:24:? A[RETURN, SYNTHETIC] */
    void f(List<androidx.recyclerview.widget.a.b> list, int i, androidx.recyclerview.widget.a.b bVar, int i2, androidx.recyclerview.widget.a.b bVar2) {
        androidx.recyclerview.widget.a.b bVarB;
        int i3;
        int i4;
        int i5;
        int i6 = bVar.d;
        int i7 = bVar2.b;
        androidx.recyclerview.widget.a.b bVarB2 = null;
        if (i6 >= i7) {
            int i8 = bVar2.d;
            if (i6 < i7 + i8) {
                bVar2.d = i8 - 1;
                bVarB = this.a.b(4, bVar.b, 1, bVar2.c);
            }
            i3 = bVar.b;
            i4 = bVar2.b;
            if (i3 <= i4) {
                bVar2.b = i4 + 1;
            } else {
                i5 = bVar2.d;
                if (i3 < i4 + i5) {
                    int i9 = (i4 + i5) - i3;
                    bVarB2 = this.a.b(4, i3 + 1, i9, bVar2.c);
                    bVar2.d -= i9;
                }
            }
            list.set(i2, bVar);
            if (bVar2.d > 0) {
                list.set(i, bVar2);
            } else {
                list.remove(i);
                this.a.a(bVar2);
            }
            if (bVarB != null) {
                list.add(i, bVarB);
            }
            if (bVarB2 != null) {
                list.add(i, bVarB2);
            }
        }
        bVar2.b = i7 - 1;
        bVarB = null;
        i3 = bVar.b;
        i4 = bVar2.b;
        if (i3 <= i4) {
            bVar2.b = i4 + 1;
        } else {
            i5 = bVar2.d;
            if (i3 < i4 + i5) {
                int i10 = (i4 + i5) - i3;
                bVarB2 = this.a.b(4, i3 + 1, i10, bVar2.c);
                bVar2.d -= i10;
            }
        }
        list.set(i2, bVar);
        if (bVar2.d > 0) {
            list.set(i, bVar2);
        } else {
            list.remove(i);
            this.a.a(bVar2);
        }
        if (bVarB != null) {
            list.add(i, bVarB);
        }
        if (bVarB2 != null) {
            list.add(i, bVarB2);
        }
    }
}
