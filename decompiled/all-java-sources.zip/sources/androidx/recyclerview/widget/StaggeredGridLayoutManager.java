package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class StaggeredGridLayoutManager extends RecyclerView.p implements RecyclerView.A.b {
    private BitSet B;
    private boolean G;
    private boolean H;
    private e I;
    private int J;
    private int[] O;
    f[] t;
    o u;
    o v;
    private int w;
    private int x;
    private final k y;
    private int s = -1;
    boolean z = false;
    boolean A = false;
    int C = -1;
    int D = Integer.MIN_VALUE;
    d E = new d();
    private int F = 2;
    private final Rect K = new Rect();
    private final b L = new b();
    private boolean M = false;
    private boolean N = true;
    private final Runnable P = new a();

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            StaggeredGridLayoutManager.this.X1();
        }
    }

    class b {
        int a;
        int b;
        boolean c;
        boolean d;
        boolean e;
        int[] f;

        b() {
            c();
        }

        void a() {
            this.b = this.c ? StaggeredGridLayoutManager.this.u.i() : StaggeredGridLayoutManager.this.u.m();
        }

        void b(int i) {
            if (this.c) {
                this.b = StaggeredGridLayoutManager.this.u.i() - i;
            } else {
                this.b = StaggeredGridLayoutManager.this.u.m() + i;
            }
        }

        void c() {
            this.a = -1;
            this.b = Integer.MIN_VALUE;
            this.c = false;
            this.d = false;
            this.e = false;
            int[] iArr = this.f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }

        void d(f[] fVarArr) {
            int length = fVarArr.length;
            int[] iArr = this.f;
            if (iArr == null || iArr.length < length) {
                this.f = new int[StaggeredGridLayoutManager.this.t.length];
            }
            for (int i = 0; i < length; i++) {
                this.f[i] = fVarArr[i].p(Integer.MIN_VALUE);
            }
        }
    }

    public static class c extends RecyclerView.q {
        f e;
        boolean f;

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public boolean e() {
            return this.f;
        }

        public c(int i, int i2) {
            super(i, i2);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class e implements Parcelable {
        public static final Parcelable.Creator<e> CREATOR = new a();
        int X;
        int Y;
        int[] Z;
        int h0;
        int[] i0;
        List<d.a> j0;
        boolean k0;
        boolean l0;
        boolean m0;
        int q;

        class a implements Parcelable.Creator<e> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public e[] newArray(int i) {
                return new e[i];
            }
        }

        public e() {
        }

        void a() {
            this.Z = null;
            this.Y = 0;
            this.q = -1;
            this.X = -1;
        }

        void b() {
            this.Z = null;
            this.Y = 0;
            this.h0 = 0;
            this.i0 = null;
            this.j0 = null;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.q);
            parcel.writeInt(this.X);
            parcel.writeInt(this.Y);
            if (this.Y > 0) {
                parcel.writeIntArray(this.Z);
            }
            parcel.writeInt(this.h0);
            if (this.h0 > 0) {
                parcel.writeIntArray(this.i0);
            }
            parcel.writeInt(this.k0 ? 1 : 0);
            parcel.writeInt(this.l0 ? 1 : 0);
            parcel.writeInt(this.m0 ? 1 : 0);
            parcel.writeList(this.j0);
        }

        e(Parcel parcel) {
            this.q = parcel.readInt();
            this.X = parcel.readInt();
            int i = parcel.readInt();
            this.Y = i;
            if (i > 0) {
                int[] iArr = new int[i];
                this.Z = iArr;
                parcel.readIntArray(iArr);
            }
            int i2 = parcel.readInt();
            this.h0 = i2;
            if (i2 > 0) {
                int[] iArr2 = new int[i2];
                this.i0 = iArr2;
                parcel.readIntArray(iArr2);
            }
            this.k0 = parcel.readInt() == 1;
            this.l0 = parcel.readInt() == 1;
            this.m0 = parcel.readInt() == 1;
            this.j0 = parcel.readArrayList(d.a.class.getClassLoader());
        }

        public e(e eVar) {
            this.Y = eVar.Y;
            this.q = eVar.q;
            this.X = eVar.X;
            this.Z = eVar.Z;
            this.h0 = eVar.h0;
            this.i0 = eVar.i0;
            this.k0 = eVar.k0;
            this.l0 = eVar.l0;
            this.m0 = eVar.m0;
            this.j0 = eVar.j0;
        }
    }

    class f {
        ArrayList<View> a = new ArrayList<>();
        int b = Integer.MIN_VALUE;
        int c = Integer.MIN_VALUE;
        int d = 0;
        final int e;

        f(int i) {
            this.e = i;
        }

        void a(View view) {
            c cVarN = n(view);
            cVarN.e = this;
            this.a.add(view);
            this.c = Integer.MIN_VALUE;
            if (this.a.size() == 1) {
                this.b = Integer.MIN_VALUE;
            }
            if (cVarN.c() || cVarN.b()) {
                this.d += StaggeredGridLayoutManager.this.u.e(view);
            }
        }

        void b(boolean z, int i) {
            int iL = z ? l(Integer.MIN_VALUE) : p(Integer.MIN_VALUE);
            e();
            if (iL == Integer.MIN_VALUE) {
                return;
            }
            if (!z || iL >= StaggeredGridLayoutManager.this.u.i()) {
                if (z || iL <= StaggeredGridLayoutManager.this.u.m()) {
                    if (i != Integer.MIN_VALUE) {
                        iL += i;
                    }
                    this.c = iL;
                    this.b = iL;
                }
            }
        }

        void c() {
            d.a aVarF;
            ArrayList<View> arrayList = this.a;
            View view = arrayList.get(arrayList.size() - 1);
            c cVarN = n(view);
            this.c = StaggeredGridLayoutManager.this.u.d(view);
            if (cVarN.f && (aVarF = StaggeredGridLayoutManager.this.E.f(cVarN.a())) != null && aVarF.X == 1) {
                this.c += aVarF.a(this.e);
            }
        }

        void d() {
            d.a aVarF;
            View view = this.a.get(0);
            c cVarN = n(view);
            this.b = StaggeredGridLayoutManager.this.u.g(view);
            if (cVarN.f && (aVarF = StaggeredGridLayoutManager.this.E.f(cVarN.a())) != null && aVarF.X == -1) {
                this.b -= aVarF.a(this.e);
            }
        }

        void e() {
            this.a.clear();
            q();
            this.d = 0;
        }

        public int f() {
            return StaggeredGridLayoutManager.this.z ? i(this.a.size() - 1, -1, true) : i(0, this.a.size(), true);
        }

        public int g() {
            return StaggeredGridLayoutManager.this.z ? i(0, this.a.size(), true) : i(this.a.size() - 1, -1, true);
        }

        int h(int i, int i2, boolean z, boolean z2, boolean z3) {
            int iM = StaggeredGridLayoutManager.this.u.m();
            int i3 = StaggeredGridLayoutManager.this.u.i();
            int i4 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = this.a.get(i);
                int iG = StaggeredGridLayoutManager.this.u.g(view);
                int iD = StaggeredGridLayoutManager.this.u.d(view);
                boolean z4 = false;
                boolean z5 = !z3 ? iG >= i3 : iG > i3;
                if (!z3 ? iD > iM : iD >= iM) {
                    z4 = true;
                }
                if (z5 && z4) {
                    if (z && z2) {
                        if (iG >= iM && iD <= i3) {
                            return StaggeredGridLayoutManager.this.m0(view);
                        }
                    } else {
                        if (z2) {
                            return StaggeredGridLayoutManager.this.m0(view);
                        }
                        if (iG < iM || iD > i3) {
                            return StaggeredGridLayoutManager.this.m0(view);
                        }
                    }
                }
                i += i4;
            }
            return -1;
        }

        int i(int i, int i2, boolean z) {
            return h(i, i2, false, false, z);
        }

        public int j() {
            return this.d;
        }

        int k() {
            int i = this.c;
            if (i != Integer.MIN_VALUE) {
                return i;
            }
            c();
            return this.c;
        }

        int l(int i) {
            int i2 = this.c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.a.size() == 0) {
                return i;
            }
            c();
            return this.c;
        }

        public View m(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.a.size() - 1;
                while (size >= 0) {
                    View view2 = this.a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.z && staggeredGridLayoutManager.m0(view2) >= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.z && staggeredGridLayoutManager2.m0(view2) <= i) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = this.a.get(i3);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.z && staggeredGridLayoutManager3.m0(view3) <= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.z && staggeredGridLayoutManager4.m0(view3) >= i) || !view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                }
            }
            return view;
        }

        c n(View view) {
            return (c) view.getLayoutParams();
        }

        int o() {
            int i = this.b;
            if (i != Integer.MIN_VALUE) {
                return i;
            }
            d();
            return this.b;
        }

        int p(int i) {
            int i2 = this.b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.a.size() == 0) {
                return i;
            }
            d();
            return this.b;
        }

        void q() {
            this.b = Integer.MIN_VALUE;
            this.c = Integer.MIN_VALUE;
        }

        void r(int i) {
            int i2 = this.b;
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2 + i;
            }
            int i3 = this.c;
            if (i3 != Integer.MIN_VALUE) {
                this.c = i3 + i;
            }
        }

        void s() {
            int size = this.a.size();
            View viewRemove = this.a.remove(size - 1);
            c cVarN = n(viewRemove);
            cVarN.e = null;
            if (cVarN.c() || cVarN.b()) {
                this.d -= StaggeredGridLayoutManager.this.u.e(viewRemove);
            }
            if (size == 1) {
                this.b = Integer.MIN_VALUE;
            }
            this.c = Integer.MIN_VALUE;
        }

        void t() {
            View viewRemove = this.a.remove(0);
            c cVarN = n(viewRemove);
            cVarN.e = null;
            if (this.a.size() == 0) {
                this.c = Integer.MIN_VALUE;
            }
            if (cVarN.c() || cVarN.b()) {
                this.d -= StaggeredGridLayoutManager.this.u.e(viewRemove);
            }
            this.b = Integer.MIN_VALUE;
        }

        void u(View view) {
            c cVarN = n(view);
            cVarN.e = this;
            this.a.add(0, view);
            this.b = Integer.MIN_VALUE;
            if (this.a.size() == 1) {
                this.c = Integer.MIN_VALUE;
            }
            if (cVarN.c() || cVarN.b()) {
                this.d += StaggeredGridLayoutManager.this.u.e(view);
            }
        }

        void v(int i) {
            this.b = i;
            this.c = i;
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        RecyclerView.p.d dVarN0 = RecyclerView.p.n0(context, attributeSet, i, i2);
        M2(dVarN0.a);
        O2(dVarN0.b);
        N2(dVarN0.c);
        this.y = new k();
        f2();
    }

    private void A2(View view, c cVar, boolean z) {
        if (cVar.f) {
            if (this.w == 1) {
                z2(view, this.J, RecyclerView.p.Q(c0(), d0(), l0() + i0(), ((ViewGroup.MarginLayoutParams) cVar).height, true), z);
                return;
            } else {
                z2(view, RecyclerView.p.Q(t0(), u0(), j0() + k0(), ((ViewGroup.MarginLayoutParams) cVar).width, true), this.J, z);
                return;
            }
        }
        if (this.w == 1) {
            z2(view, RecyclerView.p.Q(this.x, u0(), 0, ((ViewGroup.MarginLayoutParams) cVar).width, false), RecyclerView.p.Q(c0(), d0(), l0() + i0(), ((ViewGroup.MarginLayoutParams) cVar).height, true), z);
        } else {
            z2(view, RecyclerView.p.Q(t0(), u0(), j0() + k0(), ((ViewGroup.MarginLayoutParams) cVar).width, true), RecyclerView.p.Q(this.x, d0(), 0, ((ViewGroup.MarginLayoutParams) cVar).height, false), z);
        }
    }

    /* JADX WARN: Code duplicated, block: B:86:0x0155  */
    private void B2(RecyclerView.w wVar, RecyclerView.B b2, boolean z) {
        boolean z2;
        e eVar;
        b bVar = this.L;
        if (!(this.I == null && this.C == -1) && b2.b() == 0) {
            p1(wVar);
            bVar.c();
            return;
        }
        boolean z3 = (bVar.e && this.C == -1 && this.I == null) ? false : true;
        if (z3) {
            bVar.c();
            if (this.I != null) {
                S1(bVar);
            } else {
                J2();
                bVar.c = this.A;
            }
            S2(b2, bVar);
            bVar.e = true;
        }
        if (this.I == null && this.C == -1 && (bVar.c != this.G || y2() != this.H)) {
            this.E.b();
            bVar.d = true;
        }
        if (P() > 0 && ((eVar = this.I) == null || eVar.Y < 1)) {
            if (bVar.d) {
                for (int i = 0; i < this.s; i++) {
                    this.t[i].e();
                    int i2 = bVar.b;
                    if (i2 != Integer.MIN_VALUE) {
                        this.t[i].v(i2);
                    }
                }
            } else if (z3 || this.L.f == null) {
                for (int i3 = 0; i3 < this.s; i3++) {
                    this.t[i3].b(this.A, bVar.b);
                }
                this.L.d(this.t);
            } else {
                for (int i4 = 0; i4 < this.s; i4++) {
                    f fVar = this.t[i4];
                    fVar.e();
                    fVar.v(this.L.f[i4]);
                }
            }
        }
        C(wVar);
        this.y.a = false;
        this.M = false;
        U2(this.v.n());
        T2(bVar.a, b2);
        if (bVar.c) {
            L2(-1);
            g2(wVar, this.y, b2);
            L2(1);
            k kVar = this.y;
            kVar.c = bVar.a + kVar.d;
            g2(wVar, kVar, b2);
        } else {
            L2(1);
            g2(wVar, this.y, b2);
            L2(-1);
            k kVar2 = this.y;
            kVar2.c = bVar.a + kVar2.d;
            g2(wVar, kVar2, b2);
        }
        I2();
        if (P() > 0) {
            if (this.A) {
                m2(wVar, b2, true);
                n2(wVar, b2, false);
            } else {
                n2(wVar, b2, true);
                m2(wVar, b2, false);
            }
        }
        if (z && !b2.e() && this.F != 0 && P() > 0 && (this.M || w2() != null)) {
            t1(this.P);
            z2 = X1();
        }
        if (b2.e()) {
            this.L.c();
        }
        this.G = bVar.c;
        this.H = y2();
        if (z2) {
            this.L.c();
            B2(wVar, b2, false);
        }
    }

    private boolean C2(int i) {
        if (this.w == 0) {
            return (i == -1) != this.A;
        }
        return ((i == -1) == this.A) == y2();
    }

    private void E2(View view) {
        for (int i = this.s - 1; i >= 0; i--) {
            this.t[i].u(view);
        }
    }

    private void F2(RecyclerView.w wVar, k kVar) {
        int iMin;
        if (!kVar.a || kVar.i) {
            return;
        }
        if (kVar.b == 0) {
            if (kVar.e == -1) {
                G2(wVar, kVar.g);
                return;
            } else {
                H2(wVar, kVar.f);
                return;
            }
        }
        if (kVar.e == -1) {
            int i = kVar.f;
            int iR2 = i - r2(i);
            G2(wVar, iR2 < 0 ? kVar.g : kVar.g - Math.min(iR2, kVar.b));
        } else {
            int iS2 = s2(kVar.g) - kVar.g;
            if (iS2 < 0) {
                iMin = kVar.f;
            } else {
                iMin = Math.min(iS2, kVar.b) + kVar.f;
            }
            H2(wVar, iMin);
        }
    }

    private void G2(RecyclerView.w wVar, int i) {
        for (int iP = P() - 1; iP >= 0; iP--) {
            View viewO = O(iP);
            if (this.u.g(viewO) < i || this.u.q(viewO) < i) {
                return;
            }
            c cVar = (c) viewO.getLayoutParams();
            if (cVar.f) {
                for (int i2 = 0; i2 < this.s; i2++) {
                    if (this.t[i2].a.size() == 1) {
                        return;
                    }
                }
                for (int i3 = 0; i3 < this.s; i3++) {
                    this.t[i3].s();
                }
            } else if (cVar.e.a.size() == 1) {
                return;
            } else {
                cVar.e.s();
            }
            r1(viewO, wVar);
        }
    }

    private void H2(RecyclerView.w wVar, int i) {
        while (P() > 0) {
            View viewO = O(0);
            if (this.u.d(viewO) > i || this.u.p(viewO) > i) {
                return;
            }
            c cVar = (c) viewO.getLayoutParams();
            if (cVar.f) {
                for (int i2 = 0; i2 < this.s; i2++) {
                    if (this.t[i2].a.size() == 1) {
                        return;
                    }
                }
                for (int i3 = 0; i3 < this.s; i3++) {
                    this.t[i3].t();
                }
            } else if (cVar.e.a.size() == 1) {
                return;
            } else {
                cVar.e.t();
            }
            r1(viewO, wVar);
        }
    }

    private void I2() {
        if (this.v.k() == 1073741824) {
            return;
        }
        int iP = P();
        float fMax = 0.0f;
        for (int i = 0; i < iP; i++) {
            View viewO = O(i);
            float fE = this.v.e(viewO);
            if (fE >= fMax) {
                if (((c) viewO.getLayoutParams()).e()) {
                    fE = (fE * 1.0f) / this.s;
                }
                fMax = Math.max(fMax, fE);
            }
        }
        int i2 = this.x;
        int iRound = Math.round(fMax * this.s);
        if (this.v.k() == Integer.MIN_VALUE) {
            iRound = Math.min(iRound, this.v.n());
        }
        U2(iRound);
        if (this.x == i2) {
            return;
        }
        for (int i3 = 0; i3 < iP; i3++) {
            View viewO2 = O(i3);
            c cVar = (c) viewO2.getLayoutParams();
            if (!cVar.f) {
                if (y2() && this.w == 1) {
                    int i4 = this.s;
                    int i5 = cVar.e.e;
                    viewO2.offsetLeftAndRight(((-((i4 - 1) - i5)) * this.x) - ((-((i4 - 1) - i5)) * i2));
                } else {
                    int i6 = cVar.e.e;
                    int i7 = this.x * i6;
                    int i8 = i6 * i2;
                    if (this.w == 1) {
                        viewO2.offsetLeftAndRight(i7 - i8);
                    } else {
                        viewO2.offsetTopAndBottom(i7 - i8);
                    }
                }
            }
        }
    }

    private void J2() {
        if (this.w == 1 || !y2()) {
            this.A = this.z;
        } else {
            this.A = !this.z;
        }
    }

    private void L2(int i) {
        k kVar = this.y;
        kVar.e = i;
        kVar.d = this.A != (i == -1) ? -1 : 1;
    }

    private void P2(int i, int i2) {
        for (int i3 = 0; i3 < this.s; i3++) {
            if (!this.t[i3].a.isEmpty()) {
                V2(this.t[i3], i, i2);
            }
        }
    }

    private boolean Q2(RecyclerView.B b2, b bVar) {
        bVar.a = this.G ? l2(b2.b()) : h2(b2.b());
        bVar.b = Integer.MIN_VALUE;
        return true;
    }

    private void R1(View view) {
        for (int i = this.s - 1; i >= 0; i--) {
            this.t[i].a(view);
        }
    }

    private void S1(b bVar) {
        e eVar = this.I;
        int i = eVar.Y;
        if (i > 0) {
            if (i == this.s) {
                for (int i2 = 0; i2 < this.s; i2++) {
                    this.t[i2].e();
                    e eVar2 = this.I;
                    int i3 = eVar2.Z[i2];
                    if (i3 != Integer.MIN_VALUE) {
                        i3 += eVar2.l0 ? this.u.i() : this.u.m();
                    }
                    this.t[i2].v(i3);
                }
            } else {
                eVar.b();
                e eVar3 = this.I;
                eVar3.q = eVar3.X;
            }
        }
        e eVar4 = this.I;
        this.H = eVar4.m0;
        N2(eVar4.k0);
        J2();
        e eVar5 = this.I;
        int i4 = eVar5.q;
        if (i4 != -1) {
            this.C = i4;
            bVar.c = eVar5.l0;
        } else {
            bVar.c = this.A;
        }
        if (eVar5.h0 > 1) {
            d dVar = this.E;
            dVar.a = eVar5.i0;
            dVar.b = eVar5.j0;
        }
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0037  */
    /* JADX WARN: Code duplicated, block: B:18:0x004e  */
    private void T2(int i, RecyclerView.B b2) {
        int iN;
        int iN2;
        int iC;
        k kVar = this.y;
        boolean z = false;
        kVar.b = 0;
        kVar.c = i;
        if (C0() && (iC = b2.c()) != -1) {
            if (this.A == (iC < i)) {
                iN = this.u.n();
            } else {
                iN2 = this.u.n();
                iN = 0;
            }
            if (S()) {
                this.y.f = this.u.m() - iN2;
                this.y.g = this.u.i() + iN;
            } else {
                this.y.g = this.u.h() + iN;
                this.y.f = -iN2;
            }
            k kVar2 = this.y;
            kVar2.h = false;
            kVar2.a = true;
            if (this.u.k() == 0 && this.u.h() == 0) {
                z = true;
            }
            kVar2.i = z;
        }
        iN = 0;
        iN2 = 0;
        if (S()) {
            this.y.f = this.u.m() - iN2;
            this.y.g = this.u.i() + iN;
        } else {
            this.y.g = this.u.h() + iN;
            this.y.f = -iN2;
        }
        k kVar3 = this.y;
        kVar3.h = false;
        kVar3.a = true;
        if (this.u.k() == 0) {
            z = true;
        }
        kVar3.i = z;
    }

    private void V1(View view, c cVar, k kVar) {
        if (kVar.e == 1) {
            if (cVar.f) {
                R1(view);
                return;
            } else {
                cVar.e.a(view);
                return;
            }
        }
        if (cVar.f) {
            E2(view);
        } else {
            cVar.e.u(view);
        }
    }

    private void V2(f fVar, int i, int i2) {
        int iJ = fVar.j();
        if (i == -1) {
            if (fVar.o() + iJ <= i2) {
                this.B.set(fVar.e, false);
            }
        } else if (fVar.k() - iJ >= i2) {
            this.B.set(fVar.e, false);
        }
    }

    private int W1(int i) {
        if (P() == 0) {
            return this.A ? 1 : -1;
        }
        return (i < o2()) != this.A ? -1 : 1;
    }

    private int W2(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    private boolean Y1(f fVar) {
        if (this.A) {
            if (fVar.k() < this.u.i()) {
                ArrayList<View> arrayList = fVar.a;
                return !fVar.n(arrayList.get(arrayList.size() - 1)).f;
            }
        } else if (fVar.o() > this.u.m()) {
            return !fVar.n(fVar.a.get(0)).f;
        }
        return false;
    }

    private int Z1(RecyclerView.B b2) {
        if (P() == 0) {
            return 0;
        }
        return r.a(b2, this.u, j2(!this.N), i2(!this.N), this, this.N);
    }

    private int a2(RecyclerView.B b2) {
        if (P() == 0) {
            return 0;
        }
        return r.b(b2, this.u, j2(!this.N), i2(!this.N), this, this.N, this.A);
    }

    private int b2(RecyclerView.B b2) {
        if (P() == 0) {
            return 0;
        }
        return r.c(b2, this.u, j2(!this.N), i2(!this.N), this, this.N);
    }

    private int c2(int i) {
        if (i == 1) {
            return (this.w != 1 && y2()) ? 1 : -1;
        }
        if (i == 2) {
            return (this.w != 1 && y2()) ? -1 : 1;
        }
        if (i == 17) {
            return this.w == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i == 33) {
            return this.w == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i != 66) {
            return (i == 130 && this.w == 1) ? 1 : Integer.MIN_VALUE;
        }
        return this.w == 0 ? 1 : Integer.MIN_VALUE;
    }

    private d.a d2(int i) {
        d.a aVar = new d.a();
        aVar.Y = new int[this.s];
        for (int i2 = 0; i2 < this.s; i2++) {
            aVar.Y[i2] = i - this.t[i2].l(i);
        }
        return aVar;
    }

    private d.a e2(int i) {
        d.a aVar = new d.a();
        aVar.Y = new int[this.s];
        for (int i2 = 0; i2 < this.s; i2++) {
            aVar.Y[i2] = this.t[i2].p(i) - i;
        }
        return aVar;
    }

    private void f2() {
        this.u = o.b(this, this.w);
        this.v = o.b(this, 1 - this.w);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r9v7 */
    private int g2(RecyclerView.w wVar, k kVar, RecyclerView.B b2) {
        int i;
        int iQ2;
        f fVarU2;
        int iE;
        int i2;
        int iE2;
        int iE3;
        ?? r9 = 0;
        this.B.set(0, this.s, true);
        if (this.y.i) {
            i = kVar.e == 1 ? SubsamplingScaleImageView.TILE_SIZE_AUTO : Integer.MIN_VALUE;
        } else {
            i = kVar.e == 1 ? kVar.g + kVar.b : kVar.f - kVar.b;
        }
        P2(kVar.e, i);
        int i3 = this.A ? this.u.i() : this.u.m();
        boolean z = false;
        while (kVar.a(b2) && (this.y.i || !this.B.isEmpty())) {
            View viewB = kVar.b(wVar);
            c cVar = (c) viewB.getLayoutParams();
            int iA = cVar.a();
            int iG = this.E.g(iA);
            boolean z2 = iG == -1;
            if (z2) {
                fVarU2 = cVar.f ? this.t[r9] : u2(kVar);
                this.E.n(iA, fVarU2);
            } else {
                fVarU2 = this.t[iG];
            }
            f fVar = fVarU2;
            cVar.e = fVar;
            if (kVar.e == 1) {
                j(viewB);
            } else {
                k(viewB, r9);
            }
            A2(viewB, cVar, r9);
            if (kVar.e == 1) {
                int iQ3 = cVar.f ? q2(i3) : fVar.l(i3);
                int iE4 = this.u.e(viewB) + iQ3;
                if (z2 && cVar.f) {
                    d.a aVarD2 = d2(iQ3);
                    aVarD2.X = -1;
                    aVarD2.q = iA;
                    this.E.a(aVarD2);
                }
                i2 = iE4;
                iE = iQ3;
            } else {
                int iT2 = cVar.f ? t2(i3) : fVar.p(i3);
                iE = iT2 - this.u.e(viewB);
                if (z2 && cVar.f) {
                    d.a aVarE2 = e2(iT2);
                    aVarE2.X = 1;
                    aVarE2.q = iA;
                    this.E.a(aVarE2);
                }
                i2 = iT2;
            }
            if (cVar.f && kVar.d == -1) {
                if (z2) {
                    this.M = true;
                } else {
                    if (!(kVar.e == 1 ? T1() : U1())) {
                        d.a aVarF = this.E.f(iA);
                        if (aVarF != null) {
                            aVarF.Z = true;
                        }
                        this.M = true;
                    }
                }
            }
            V1(viewB, cVar, kVar);
            if (y2() && this.w == 1) {
                int i4 = cVar.f ? this.v.i() : this.v.i() - (((this.s - 1) - fVar.e) * this.x);
                iE3 = i4;
                iE2 = i4 - this.v.e(viewB);
            } else {
                int iM = cVar.f ? this.v.m() : (fVar.e * this.x) + this.v.m();
                iE2 = iM;
                iE3 = this.v.e(viewB) + iM;
            }
            if (this.w == 1) {
                E0(viewB, iE2, iE, iE3, i2);
            } else {
                E0(viewB, iE, iE2, i2, iE3);
            }
            if (cVar.f) {
                P2(this.y.e, i);
            } else {
                V2(fVar, this.y.e, i);
            }
            F2(wVar, this.y);
            if (this.y.h && viewB.hasFocusable()) {
                if (cVar.f) {
                    this.B.clear();
                } else {
                    this.B.set(fVar.e, false);
                }
            }
            z = true;
            r9 = 0;
        }
        if (!z) {
            F2(wVar, this.y);
        }
        if (this.y.e == -1) {
            iQ2 = this.u.m() - t2(this.u.m());
        } else {
            iQ2 = q2(this.u.i()) - this.u.i();
        }
        if (iQ2 > 0) {
            return Math.min(kVar.b, iQ2);
        }
        return 0;
    }

    private int h2(int i) {
        int iP = P();
        for (int i2 = 0; i2 < iP; i2++) {
            int iM0 = m0(O(i2));
            if (iM0 >= 0 && iM0 < i) {
                return iM0;
            }
        }
        return 0;
    }

    private int l2(int i) {
        for (int iP = P() - 1; iP >= 0; iP--) {
            int iM0 = m0(O(iP));
            if (iM0 >= 0 && iM0 < i) {
                return iM0;
            }
        }
        return 0;
    }

    private void m2(RecyclerView.w wVar, RecyclerView.B b2, boolean z) {
        int i;
        int iQ2 = q2(Integer.MIN_VALUE);
        if (iQ2 != Integer.MIN_VALUE && (i = this.u.i() - iQ2) > 0) {
            int i2 = i - (-K2(-i, wVar, b2));
            if (!z || i2 <= 0) {
                return;
            }
            this.u.r(i2);
        }
    }

    private void n2(RecyclerView.w wVar, RecyclerView.B b2, boolean z) {
        int iM;
        int iT2 = t2(SubsamplingScaleImageView.TILE_SIZE_AUTO);
        if (iT2 != Integer.MAX_VALUE && (iM = iT2 - this.u.m()) > 0) {
            int iK2 = iM - K2(iM, wVar, b2);
            if (!z || iK2 <= 0) {
                return;
            }
            this.u.r(-iK2);
        }
    }

    private int q2(int i) {
        int iL = this.t[0].l(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int iL2 = this.t[i2].l(i);
            if (iL2 > iL) {
                iL = iL2;
            }
        }
        return iL;
    }

    private int r2(int i) {
        int iP = this.t[0].p(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int iP2 = this.t[i2].p(i);
            if (iP2 > iP) {
                iP = iP2;
            }
        }
        return iP;
    }

    private int s2(int i) {
        int iL = this.t[0].l(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int iL2 = this.t[i2].l(i);
            if (iL2 < iL) {
                iL = iL2;
            }
        }
        return iL;
    }

    private int t2(int i) {
        int iP = this.t[0].p(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int iP2 = this.t[i2].p(i);
            if (iP2 < iP) {
                iP = iP2;
            }
        }
        return iP;
    }

    private f u2(k kVar) {
        int i;
        int i2;
        int i3;
        if (C2(kVar.e)) {
            i2 = this.s - 1;
            i = -1;
            i3 = -1;
        } else {
            i = this.s;
            i2 = 0;
            i3 = 1;
        }
        f fVar = null;
        if (kVar.e == 1) {
            int iM = this.u.m();
            int i4 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
            while (i2 != i) {
                f fVar2 = this.t[i2];
                int iL = fVar2.l(iM);
                if (iL < i4) {
                    fVar = fVar2;
                    i4 = iL;
                }
                i2 += i3;
            }
            return fVar;
        }
        int i5 = this.u.i();
        int i6 = Integer.MIN_VALUE;
        while (i2 != i) {
            f fVar3 = this.t[i2];
            int iP = fVar3.p(i5);
            if (iP > i6) {
                fVar = fVar3;
                i6 = iP;
            }
            i2 += i3;
        }
        return fVar;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0026  */
    /* JADX WARN: Code duplicated, block: B:17:0x0029 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:19:0x002c  */
    /* JADX WARN: Code duplicated, block: B:20:0x0037  */
    /* JADX WARN: Code duplicated, block: B:21:0x003d  */
    /* JADX WARN: Code duplicated, block: B:23:0x0044 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:24:0x0045  */
    /* JADX WARN: Code duplicated, block: B:26:0x0049  */
    /* JADX WARN: Code duplicated, block: B:27:0x004e  */
    /* JADX WARN: Code duplicated, block: B:29:0x0054  */
    /* JADX WARN: Code duplicated, block: B:31:? A[RETURN, SYNTHETIC] */
    private void v2(int i, int i2, int i3) {
        int i4;
        int i5;
        int iP2;
        int iP3 = this.A ? p2() : o2();
        if (i3 == 8) {
            if (i < i2) {
                i4 = i2 + 1;
            } else {
                i4 = i + 1;
                i5 = i2;
            }
            this.E.h(i5);
            if (i3 != 1) {
                this.E.j(i, i2);
            } else if (i3 != 2) {
                this.E.k(i, i2);
            } else if (i3 == 8) {
                this.E.k(i, 1);
                this.E.j(i2, 1);
            }
            if (i4 <= iP3) {
                return;
            }
            if (this.A) {
                iP2 = o2();
            } else {
                iP2 = p2();
            }
            if (i5 <= iP2) {
                y1();
            }
        }
        i4 = i + i2;
        i5 = i;
        this.E.h(i5);
        if (i3 != 1) {
            this.E.j(i, i2);
        } else if (i3 != 2) {
            this.E.k(i, i2);
        } else if (i3 == 8) {
            this.E.k(i, 1);
            this.E.j(i2, 1);
        }
        if (i4 <= iP3) {
            return;
        }
        if (this.A) {
            iP2 = o2();
        } else {
            iP2 = p2();
        }
        if (i5 <= iP2) {
            y1();
        }
    }

    private void z2(View view, int i, int i2, boolean z) {
        p(view, this.K);
        c cVar = (c) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) cVar).leftMargin;
        Rect rect = this.K;
        int iW2 = W2(i, i3 + rect.left, ((ViewGroup.MarginLayoutParams) cVar).rightMargin + rect.right);
        int i4 = ((ViewGroup.MarginLayoutParams) cVar).topMargin;
        Rect rect2 = this.K;
        int iW3 = W2(i2, i4 + rect2.top, ((ViewGroup.MarginLayoutParams) cVar).bottomMargin + rect2.bottom);
        if (z ? M1(view, iW2, iW3, cVar) : K1(view, iW2, iW3, cVar)) {
            view.measure(iW2, iW3);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int A(RecyclerView.B b2) {
        return a2(b2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int B(RecyclerView.B b2) {
        return b2(b2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int B1(int i, RecyclerView.w wVar, RecyclerView.B b2) {
        return K2(i, wVar, b2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void C1(int i) {
        e eVar = this.I;
        if (eVar != null && eVar.q != i) {
            eVar.a();
        }
        this.C = i;
        this.D = Integer.MIN_VALUE;
        y1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int D1(int i, RecyclerView.w wVar, RecyclerView.B b2) {
        return K2(i, wVar, b2);
    }

    void D2(int i, RecyclerView.B b2) {
        int iO2;
        int i2;
        if (i > 0) {
            iO2 = p2();
            i2 = 1;
        } else {
            iO2 = o2();
            i2 = -1;
        }
        this.y.a = true;
        T2(iO2, b2);
        L2(i2);
        k kVar = this.y;
        kVar.c = iO2 + kVar.d;
        kVar.b = Math.abs(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void H0(int i) {
        super.H0(i);
        for (int i2 = 0; i2 < this.s; i2++) {
            this.t[i2].r(i);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void H1(Rect rect, int i, int i2) {
        int iT;
        int iT2;
        int iJ0 = j0() + k0();
        int iL0 = l0() + i0();
        if (this.w == 1) {
            iT2 = RecyclerView.p.t(i2, rect.height() + iL0, g0());
            iT = RecyclerView.p.t(i, (this.x * this.s) + iJ0, h0());
        } else {
            iT = RecyclerView.p.t(i, rect.width() + iJ0, h0());
            iT2 = RecyclerView.p.t(i2, (this.x * this.s) + iL0, g0());
        }
        G1(iT, iT2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void I0(int i) {
        super.I0(i);
        for (int i2 = 0; i2 < this.s; i2++) {
            this.t[i2].r(i);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q J() {
        return this.w == 0 ? new c(-2, -1) : new c(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void J0(RecyclerView.h hVar, RecyclerView.h hVar2) {
        this.E.b();
        for (int i = 0; i < this.s; i++) {
            this.t[i].e();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q K(Context context, AttributeSet attributeSet) {
        return new c(context, attributeSet);
    }

    int K2(int i, RecyclerView.w wVar, RecyclerView.B b2) {
        if (P() == 0 || i == 0) {
            return 0;
        }
        D2(i, b2);
        int iG2 = g2(wVar, this.y, b2);
        if (this.y.b >= iG2) {
            i = i < 0 ? -iG2 : iG2;
        }
        this.u.r(-i);
        this.G = this.A;
        k kVar = this.y;
        kVar.b = 0;
        F2(wVar, kVar);
        return i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public RecyclerView.q L(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams);
    }

    public void M2(int i) {
        if (i != 0 && i != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        m(null);
        if (i == this.w) {
            return;
        }
        this.w = i;
        o oVar = this.u;
        this.u = this.v;
        this.v = oVar;
        y1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void N0(RecyclerView recyclerView, RecyclerView.w wVar) {
        super.N0(recyclerView, wVar);
        t1(this.P);
        for (int i = 0; i < this.s; i++) {
            this.t[i].e();
        }
        recyclerView.requestLayout();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void N1(RecyclerView recyclerView, RecyclerView.B b2, int i) {
        l lVar = new l(recyclerView.getContext());
        lVar.p(i);
        O1(lVar);
    }

    public void N2(boolean z) {
        m(null);
        e eVar = this.I;
        if (eVar != null && eVar.k0 != z) {
            eVar.k0 = z;
        }
        this.z = z;
        y1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public View O0(View view, int i, RecyclerView.w wVar, RecyclerView.B b2) {
        View viewH;
        View viewM;
        if (P() == 0 || (viewH = H(view)) == null) {
            return null;
        }
        J2();
        int iC2 = c2(i);
        if (iC2 == Integer.MIN_VALUE) {
            return null;
        }
        c cVar = (c) viewH.getLayoutParams();
        boolean z = cVar.f;
        f fVar = cVar.e;
        int iP2 = iC2 == 1 ? p2() : o2();
        T2(iP2, b2);
        L2(iC2);
        k kVar = this.y;
        kVar.c = kVar.d + iP2;
        kVar.b = (int) (this.u.n() * 0.33333334f);
        k kVar2 = this.y;
        kVar2.h = true;
        kVar2.a = false;
        g2(wVar, kVar2, b2);
        this.G = this.A;
        if (!z && (viewM = fVar.m(iP2, iC2)) != null && viewM != viewH) {
            return viewM;
        }
        if (C2(iC2)) {
            for (int i2 = this.s - 1; i2 >= 0; i2--) {
                View viewM2 = this.t[i2].m(iP2, iC2);
                if (viewM2 != null && viewM2 != viewH) {
                    return viewM2;
                }
            }
        } else {
            for (int i3 = 0; i3 < this.s; i3++) {
                View viewM3 = this.t[i3].m(iP2, iC2);
                if (viewM3 != null && viewM3 != viewH) {
                    return viewM3;
                }
            }
        }
        boolean z2 = (this.z ^ true) == (iC2 == -1);
        if (!z) {
            View viewI = I(z2 ? fVar.f() : fVar.g());
            if (viewI != null && viewI != viewH) {
                return viewI;
            }
        }
        if (C2(iC2)) {
            for (int i4 = this.s - 1; i4 >= 0; i4--) {
                if (i4 != fVar.e) {
                    View viewI2 = I(z2 ? this.t[i4].f() : this.t[i4].g());
                    if (viewI2 != null && viewI2 != viewH) {
                        return viewI2;
                    }
                }
            }
        } else {
            for (int i5 = 0; i5 < this.s; i5++) {
                View viewI3 = I(z2 ? this.t[i5].f() : this.t[i5].g());
                if (viewI3 != null && viewI3 != viewH) {
                    return viewI3;
                }
            }
        }
        return null;
    }

    public void O2(int i) {
        m(null);
        if (i != this.s) {
            x2();
            this.s = i;
            this.B = new BitSet(this.s);
            this.t = new f[this.s];
            for (int i2 = 0; i2 < this.s; i2++) {
                this.t[i2] = new f(i2);
            }
            y1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void P0(AccessibilityEvent accessibilityEvent) {
        super.P0(accessibilityEvent);
        if (P() > 0) {
            View viewJ2 = j2(false);
            View viewI2 = i2(false);
            if (viewJ2 == null || viewI2 == null) {
                return;
            }
            int iM0 = m0(viewJ2);
            int iM1 = m0(viewI2);
            if (iM0 < iM1) {
                accessibilityEvent.setFromIndex(iM0);
                accessibilityEvent.setToIndex(iM1);
            } else {
                accessibilityEvent.setFromIndex(iM1);
                accessibilityEvent.setToIndex(iM0);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean Q1() {
        return this.I == null;
    }

    boolean R2(RecyclerView.B b2, b bVar) {
        int i;
        if (!b2.e() && (i = this.C) != -1) {
            if (i >= 0 && i < b2.b()) {
                e eVar = this.I;
                if (eVar == null || eVar.q == -1 || eVar.Y < 1) {
                    View viewI = I(this.C);
                    if (viewI != null) {
                        bVar.a = this.A ? p2() : o2();
                        if (this.D != Integer.MIN_VALUE) {
                            if (bVar.c) {
                                bVar.b = (this.u.i() - this.D) - this.u.d(viewI);
                            } else {
                                bVar.b = (this.u.m() + this.D) - this.u.g(viewI);
                            }
                            return true;
                        }
                        if (this.u.e(viewI) > this.u.n()) {
                            bVar.b = bVar.c ? this.u.i() : this.u.m();
                            return true;
                        }
                        int iG = this.u.g(viewI) - this.u.m();
                        if (iG < 0) {
                            bVar.b = -iG;
                            return true;
                        }
                        int i2 = this.u.i() - this.u.d(viewI);
                        if (i2 < 0) {
                            bVar.b = i2;
                            return true;
                        }
                        bVar.b = Integer.MIN_VALUE;
                    } else {
                        int i3 = this.C;
                        bVar.a = i3;
                        int i4 = this.D;
                        if (i4 == Integer.MIN_VALUE) {
                            bVar.c = W1(i3) == 1;
                            bVar.a();
                        } else {
                            bVar.b(i4);
                        }
                        bVar.d = true;
                    }
                } else {
                    bVar.b = Integer.MIN_VALUE;
                    bVar.a = this.C;
                }
                return true;
            }
            this.C = -1;
            this.D = Integer.MIN_VALUE;
        }
        return false;
    }

    void S2(RecyclerView.B b2, b bVar) {
        if (R2(b2, bVar) || Q2(b2, bVar)) {
            return;
        }
        bVar.a();
        bVar.a = 0;
    }

    boolean T1() {
        int iL = this.t[0].l(Integer.MIN_VALUE);
        for (int i = 1; i < this.s; i++) {
            if (this.t[i].l(Integer.MIN_VALUE) != iL) {
                return false;
            }
        }
        return true;
    }

    boolean U1() {
        int iP = this.t[0].p(Integer.MIN_VALUE);
        for (int i = 1; i < this.s; i++) {
            if (this.t[i].p(Integer.MIN_VALUE) != iP) {
                return false;
            }
        }
        return true;
    }

    void U2(int i) {
        this.x = i / this.s;
        this.J = View.MeasureSpec.makeMeasureSpec(i, this.v.k());
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void W0(RecyclerView recyclerView, int i, int i2) {
        v2(i, i2, 1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void X0(RecyclerView recyclerView) {
        this.E.b();
        y1();
    }

    boolean X1() {
        int iO2;
        int iP2;
        if (P() == 0 || this.F == 0 || !w0()) {
            return false;
        }
        if (this.A) {
            iO2 = p2();
            iP2 = o2();
        } else {
            iO2 = o2();
            iP2 = p2();
        }
        if (iO2 == 0 && w2() != null) {
            this.E.b();
            z1();
            y1();
            return true;
        }
        if (!this.M) {
            return false;
        }
        int i = this.A ? -1 : 1;
        int i2 = iP2 + 1;
        d.a aVarE = this.E.e(iO2, i2, i, true);
        if (aVarE == null) {
            this.M = false;
            this.E.d(i2);
            return false;
        }
        d.a aVarE2 = this.E.e(iO2, aVarE.q, i * (-1), true);
        if (aVarE2 == null) {
            this.E.d(aVarE.q);
        } else {
            this.E.d(aVarE2.q + 1);
        }
        z1();
        y1();
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void Y0(RecyclerView recyclerView, int i, int i2, int i3) {
        v2(i, i2, 8);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void Z0(RecyclerView recyclerView, int i, int i2) {
        v2(i, i2, 2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void b1(RecyclerView recyclerView, int i, int i2, Object obj) {
        v2(i, i2, 4);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.A.b
    public PointF c(int i) {
        int iW1 = W1(i);
        PointF pointF = new PointF();
        if (iW1 == 0) {
            return null;
        }
        if (this.w == 0) {
            pointF.x = iW1;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = iW1;
        }
        return pointF;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void c1(RecyclerView.w wVar, RecyclerView.B b2) {
        B2(wVar, b2, true);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void d1(RecyclerView.B b2) {
        super.d1(b2);
        this.C = -1;
        this.D = Integer.MIN_VALUE;
        this.I = null;
        this.L.c();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void h1(Parcelable parcelable) {
        if (parcelable instanceof e) {
            e eVar = (e) parcelable;
            this.I = eVar;
            if (this.C != -1) {
                eVar.a();
                this.I.b();
            }
            y1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public Parcelable i1() {
        int iP;
        int iM;
        int[] iArr;
        if (this.I != null) {
            return new e(this.I);
        }
        e eVar = new e();
        eVar.k0 = this.z;
        eVar.l0 = this.G;
        eVar.m0 = this.H;
        d dVar = this.E;
        if (dVar == null || (iArr = dVar.a) == null) {
            eVar.h0 = 0;
        } else {
            eVar.i0 = iArr;
            eVar.h0 = iArr.length;
            eVar.j0 = dVar.b;
        }
        if (P() > 0) {
            eVar.q = this.G ? p2() : o2();
            eVar.X = k2();
            int i = this.s;
            eVar.Y = i;
            eVar.Z = new int[i];
            for (int i2 = 0; i2 < this.s; i2++) {
                if (this.G) {
                    iP = this.t[i2].l(Integer.MIN_VALUE);
                    if (iP != Integer.MIN_VALUE) {
                        iM = this.u.i();
                        iP -= iM;
                    }
                } else {
                    iP = this.t[i2].p(Integer.MIN_VALUE);
                    if (iP != Integer.MIN_VALUE) {
                        iM = this.u.m();
                        iP -= iM;
                    }
                }
                eVar.Z[i2] = iP;
            }
        } else {
            eVar.q = -1;
            eVar.X = -1;
            eVar.Y = 0;
        }
        return eVar;
    }

    View i2(boolean z) {
        int iM = this.u.m();
        int i = this.u.i();
        View view = null;
        for (int iP = P() - 1; iP >= 0; iP--) {
            View viewO = O(iP);
            int iG = this.u.g(viewO);
            int iD = this.u.d(viewO);
            if (iD > iM && iG < i) {
                if (iD <= i || !z) {
                    return viewO;
                }
                if (view == null) {
                    view = viewO;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void j1(int i) {
        if (i == 0) {
            X1();
        }
    }

    View j2(boolean z) {
        int iM = this.u.m();
        int i = this.u.i();
        int iP = P();
        View view = null;
        for (int i2 = 0; i2 < iP; i2++) {
            View viewO = O(i2);
            int iG = this.u.g(viewO);
            if (this.u.d(viewO) > iM && iG < i) {
                if (iG >= iM || !z) {
                    return viewO;
                }
                if (view == null) {
                    view = viewO;
                }
            }
        }
        return view;
    }

    int k2() {
        View viewI2 = this.A ? i2(true) : j2(true);
        if (viewI2 == null) {
            return -1;
        }
        return m0(viewI2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void m(String str) {
        if (this.I == null) {
            super.m(str);
        }
    }

    int o2() {
        if (P() == 0) {
            return 0;
        }
        return m0(O(0));
    }

    int p2() {
        int iP = P();
        if (iP == 0) {
            return 0;
        }
        return m0(O(iP - 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean q() {
        return this.w == 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean r() {
        return this.w == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean s(RecyclerView.q qVar) {
        return qVar instanceof c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public void u(int i, int i2, RecyclerView.B b2, RecyclerView.p.c cVar) {
        int iL;
        int iP;
        if (this.w != 0) {
            i = i2;
        }
        if (P() == 0 || i == 0) {
            return;
        }
        D2(i, b2);
        int[] iArr = this.O;
        if (iArr == null || iArr.length < this.s) {
            this.O = new int[this.s];
        }
        int i3 = 0;
        for (int i4 = 0; i4 < this.s; i4++) {
            k kVar = this.y;
            if (kVar.d == -1) {
                iL = kVar.f;
                iP = this.t[i4].p(iL);
            } else {
                iL = this.t[i4].l(kVar.g);
                iP = this.y.g;
            }
            int i5 = iL - iP;
            if (i5 >= 0) {
                this.O[i3] = i5;
                i3++;
            }
        }
        Arrays.sort(this.O, 0, i3);
        for (int i6 = 0; i6 < i3 && this.y.a(b2); i6++) {
            cVar.a(this.y.c, this.O[i6]);
            k kVar2 = this.y;
            kVar2.c += kVar2.d;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int w(RecyclerView.B b2) {
        return Z1(b2);
    }

    /* JADX WARN: Code duplicated, block: B:37:0x0086  */
    /* JADX WARN: Code duplicated, block: B:39:0x0097  */
    /* JADX WARN: Code duplicated, block: B:40:0x0099  */
    /* JADX WARN: Code duplicated, block: B:42:0x009c  */
    /* JADX WARN: Code duplicated, block: B:43:0x009e  */
    /* JADX WARN: Code duplicated, block: B:53:0x00a1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:0x00a2 A[SYNTHETIC] */
    View w2() {
        int i;
        boolean z;
        boolean z2;
        int iP = P();
        int i2 = iP - 1;
        BitSet bitSet = new BitSet(this.s);
        bitSet.set(0, this.s, true);
        byte b2 = (this.w == 1 && y2()) ? (byte) 1 : (byte) -1;
        if (this.A) {
            iP = -1;
        } else {
            i2 = 0;
        }
        int i3 = i2 < iP ? 1 : -1;
        while (i2 != iP) {
            View viewO = O(i2);
            c cVar = (c) viewO.getLayoutParams();
            if (bitSet.get(cVar.e.e)) {
                if (Y1(cVar.e)) {
                    return viewO;
                }
                bitSet.clear(cVar.e.e);
            }
            if (!cVar.f && (i = i2 + i3) != iP) {
                View viewO2 = O(i);
                if (this.A) {
                    int iD = this.u.d(viewO);
                    int iD2 = this.u.d(viewO2);
                    if (iD < iD2) {
                        return viewO;
                    }
                    if (iD == iD2) {
                        if (cVar.e.e - ((c) viewO2.getLayoutParams()).e.e < 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (b2 < 0) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        if (z != z2) {
                            return viewO;
                        }
                    } else {
                        continue;
                    }
                } else {
                    int iG = this.u.g(viewO);
                    int iG2 = this.u.g(viewO2);
                    if (iG > iG2) {
                        return viewO;
                    }
                    if (iG == iG2) {
                        if (cVar.e.e - ((c) viewO2.getLayoutParams()).e.e < 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (b2 < 0) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        if (z != z2) {
                            return viewO;
                        }
                    } else {
                        continue;
                    }
                }
            }
            i2 += i3;
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int x(RecyclerView.B b2) {
        return a2(b2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public boolean x0() {
        return this.F != 0;
    }

    public void x2() {
        this.E.b();
        y1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int y(RecyclerView.B b2) {
        return b2(b2);
    }

    boolean y2() {
        return e0() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.p
    public int z(RecyclerView.B b2) {
        return Z1(b2);
    }

    static class d {
        int[] a;
        List<a> b;

        d() {
        }

        private int i(int i) {
            if (this.b == null) {
                return -1;
            }
            a aVarF = f(i);
            if (aVarF != null) {
                this.b.remove(aVarF);
            }
            int size = this.b.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                }
                if (this.b.get(i2).q >= i) {
                    break;
                }
                i2++;
            }
            if (i2 == -1) {
                return -1;
            }
            a aVar = this.b.get(i2);
            this.b.remove(i2);
            return aVar.q;
        }

        private void l(int i, int i2) {
            List<a> list = this.b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.b.get(size);
                int i3 = aVar.q;
                if (i3 >= i) {
                    aVar.q = i3 + i2;
                }
            }
        }

        private void m(int i, int i2) {
            List<a> list = this.b;
            if (list == null) {
                return;
            }
            int i3 = i + i2;
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.b.get(size);
                int i4 = aVar.q;
                if (i4 >= i) {
                    if (i4 < i3) {
                        this.b.remove(size);
                    } else {
                        aVar.q = i4 - i2;
                    }
                }
            }
        }

        public void a(a aVar) {
            if (this.b == null) {
                this.b = new ArrayList();
            }
            int size = this.b.size();
            for (int i = 0; i < size; i++) {
                a aVar2 = this.b.get(i);
                if (aVar2.q == aVar.q) {
                    this.b.remove(i);
                }
                if (aVar2.q >= aVar.q) {
                    this.b.add(i, aVar);
                    return;
                }
            }
            this.b.add(aVar);
        }

        void b() {
            int[] iArr = this.a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.b = null;
        }

        void c(int i) {
            int[] iArr = this.a;
            if (iArr == null) {
                int[] iArr2 = new int[Math.max(i, 10) + 1];
                this.a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i >= iArr.length) {
                int[] iArr3 = new int[o(i)];
                this.a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        int d(int i) {
            List<a> list = this.b;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    if (this.b.get(size).q >= i) {
                        this.b.remove(size);
                    }
                }
            }
            return h(i);
        }

        public a e(int i, int i2, int i3, boolean z) {
            List<a> list = this.b;
            if (list == null) {
                return null;
            }
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                a aVar = this.b.get(i4);
                int i5 = aVar.q;
                if (i5 >= i2) {
                    return null;
                }
                if (i5 >= i && (i3 == 0 || aVar.X == i3 || (z && aVar.Z))) {
                    return aVar;
                }
            }
            return null;
        }

        public a f(int i) {
            List<a> list = this.b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.b.get(size);
                if (aVar.q == i) {
                    return aVar;
                }
            }
            return null;
        }

        int g(int i) {
            int[] iArr = this.a;
            if (iArr == null || i >= iArr.length) {
                return -1;
            }
            return iArr[i];
        }

        int h(int i) {
            int[] iArr = this.a;
            if (iArr == null || i >= iArr.length) {
                return -1;
            }
            int i2 = i(i);
            if (i2 == -1) {
                int[] iArr2 = this.a;
                Arrays.fill(iArr2, i, iArr2.length, -1);
                return this.a.length;
            }
            int iMin = Math.min(i2 + 1, this.a.length);
            Arrays.fill(this.a, i, iMin, -1);
            return iMin;
        }

        void j(int i, int i2) {
            int[] iArr = this.a;
            if (iArr == null || i >= iArr.length) {
                return;
            }
            int i3 = i + i2;
            c(i3);
            int[] iArr2 = this.a;
            System.arraycopy(iArr2, i, iArr2, i3, (iArr2.length - i) - i2);
            Arrays.fill(this.a, i, i3, -1);
            l(i, i2);
        }

        void k(int i, int i2) {
            int[] iArr = this.a;
            if (iArr == null || i >= iArr.length) {
                return;
            }
            int i3 = i + i2;
            c(i3);
            int[] iArr2 = this.a;
            System.arraycopy(iArr2, i3, iArr2, i, (iArr2.length - i) - i2);
            int[] iArr3 = this.a;
            Arrays.fill(iArr3, iArr3.length - i2, iArr3.length, -1);
            m(i, i2);
        }

        void n(int i, f fVar) {
            c(i);
            this.a[i] = fVar.e;
        }

        int o(int i) {
            int length = this.a.length;
            while (length <= i) {
                length *= 2;
            }
            return length;
        }

        @SuppressLint({"BanParcelableUsage"})
        static class a implements Parcelable {
            public static final Parcelable.Creator<a> CREATOR = new C0033a();
            int X;
            int[] Y;
            boolean Z;
            int q;

            /* JADX INFO: renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a, reason: collision with other inner class name */
            class C0033a implements Parcelable.Creator<a> {
                C0033a() {
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public a createFromParcel(Parcel parcel) {
                    return new a(parcel);
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
                public a[] newArray(int i) {
                    return new a[i];
                }
            }

            a(Parcel parcel) {
                this.q = parcel.readInt();
                this.X = parcel.readInt();
                this.Z = parcel.readInt() == 1;
                int i = parcel.readInt();
                if (i > 0) {
                    int[] iArr = new int[i];
                    this.Y = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            int a(int i) {
                int[] iArr = this.Y;
                if (iArr == null) {
                    return 0;
                }
                return iArr[i];
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            public String toString() {
                return "FullSpanItem{mPosition=" + this.q + ", mGapDir=" + this.X + ", mHasUnwantedGapAfter=" + this.Z + ", mGapPerSpan=" + Arrays.toString(this.Y) + '}';
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.q);
                parcel.writeInt(this.X);
                parcel.writeInt(this.Z ? 1 : 0);
                int[] iArr = this.Y;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                } else {
                    parcel.writeInt(iArr.length);
                    parcel.writeIntArray(this.Y);
                }
            }

            a() {
            }
        }
    }
}
