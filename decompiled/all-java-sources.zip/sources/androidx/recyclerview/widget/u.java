package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
interface u {

    public static class a implements u {
        long a = 0;

        /* JADX INFO: renamed from: androidx.recyclerview.widget.u$a$a, reason: collision with other inner class name */
        class C0038a implements d {
            private final ax.B.e<Long> a = new ax.B.e<>();

            C0038a() {
            }

            @Override // androidx.recyclerview.widget.u.d
            public long a(long j) {
                Long lH = this.a.h(j);
                if (lH == null) {
                    lH = Long.valueOf(a.this.b());
                    this.a.m(j, lH);
                }
                return lH.longValue();
            }
        }

        @Override // androidx.recyclerview.widget.u
        public d a() {
            return new C0038a();
        }

        long b() {
            long j = this.a;
            this.a = 1 + j;
            return j;
        }
    }

    public static class b implements u {
        private final d a = new a();

        class a implements d {
            a() {
            }

            @Override // androidx.recyclerview.widget.u.d
            public long a(long j) {
                return -1L;
            }
        }

        @Override // androidx.recyclerview.widget.u
        public d a() {
            return this.a;
        }
    }

    public static class c implements u {
        private final d a = new a();

        class a implements d {
            a() {
            }

            @Override // androidx.recyclerview.widget.u.d
            public long a(long j) {
                return j;
            }
        }

        @Override // androidx.recyclerview.widget.u
        public d a() {
            return this.a;
        }
    }

    public interface d {
        long a(long j);
    }

    d a();
}
