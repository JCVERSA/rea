package androidx.recyclerview.widget;

import android.graphics.Canvas;
import android.view.View;
import ax.p015b0.Y;

/* JADX INFO: loaded from: classes.dex */
class j implements ax.X0.a {
    static final ax.X0.a a = new j();

    j() {
    }

    private static float e(RecyclerView recyclerView, View view) {
        int childCount = recyclerView.getChildCount();
        float f = 0.0f;
        for (int i = 0; i < childCount; i++) {
            View childAt = recyclerView.getChildAt(i);
            if (childAt != view) {
                float fW = Y.w(childAt);
                if (fW > f) {
                    f = fW;
                }
            }
        }
        return f;
    }

    @Override // ax.X0.a
    public void a(View view) {
        int i = ax.V0.c.a;
        Object tag = view.getTag(i);
        if (tag instanceof Float) {
            Y.y0(view, ((Float) tag).floatValue());
        }
        view.setTag(i, null);
        view.setTranslationX(0.0f);
        view.setTranslationY(0.0f);
    }

    @Override // ax.X0.a
    public void b(View view) {
    }

    @Override // ax.X0.a
    public void c(Canvas canvas, RecyclerView recyclerView, View view, float f, float f2, int i, boolean z) {
    }

    @Override // ax.X0.a
    public void d(Canvas canvas, RecyclerView recyclerView, View view, float f, float f2, int i, boolean z) {
        if (z) {
            int i2 = ax.V0.c.a;
            if (view.getTag(i2) == null) {
                Float fValueOf = Float.valueOf(Y.w(view));
                Y.y0(view, e(recyclerView, view) + 1.0f);
                view.setTag(i2, fValueOf);
            }
        }
        view.setTranslationX(f);
        view.setTranslationY(f2);
    }
}
