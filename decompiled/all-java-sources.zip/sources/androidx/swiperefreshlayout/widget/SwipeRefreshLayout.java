package androidx.swiperefreshlayout.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import ax.p035c0.C1839d0;
import ax.p035c0.D;
import ax.p035c0.E;
import ax.p035c0.F;
import ax.p035c0.G;
import ax.p035c0.H;

/* JADX INFO: loaded from: classes.dex */
public class SwipeRefreshLayout extends ViewGroup implements G, F, D {
    private static final String Z0 = "SwipeRefreshLayout";
    private static final int[] a1 = {R.attr.enabled};
    private int A0;
    boolean B0;
    private boolean C0;
    private final DecelerateInterpolator D0;
    androidx.swiperefreshlayout.widget.a E0;
    private int F0;
    protected int G0;
    float H0;
    protected int I0;
    int J0;
    int K0;
    ax.p341v2.a L0;
    private Animation M0;
    private Animation N0;
    private Animation O0;
    private Animation P0;
    private Animation Q0;
    boolean R0;
    private int S0;
    boolean T0;
    private i U0;
    private boolean V0;
    private Animation.AnimationListener W0;
    private final Animation X0;
    private final Animation Y0;
    j k0;
    boolean l0;
    private int m0;
    private float n0;
    private float o0;
    private final H p0;
    private View q;
    private final E q0;
    private final int[] r0;
    private final int[] s0;
    private final int[] t0;
    private boolean u0;
    private int v0;
    int w0;
    private float x0;
    private float y0;
    private boolean z0;

    class a implements Animation.AnimationListener {
        a() {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            j jVar;
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (!swipeRefreshLayout.l0) {
                swipeRefreshLayout.s();
                return;
            }
            swipeRefreshLayout.L0.setAlpha(255);
            SwipeRefreshLayout.this.L0.start();
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            if (swipeRefreshLayout2.R0 && (jVar = swipeRefreshLayout2.k0) != null) {
                jVar.a();
            }
            SwipeRefreshLayout swipeRefreshLayout3 = SwipeRefreshLayout.this;
            swipeRefreshLayout3.w0 = swipeRefreshLayout3.E0.getTop();
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    class b extends Animation {
        b() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(f);
        }
    }

    class c extends Animation {
        c() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(1.0f - f);
        }
    }

    class d extends Animation {
        final /* synthetic */ int X;
        final /* synthetic */ int q;

        d(int i, int i2) {
            this.q = i;
            this.X = i2;
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            ax.p341v2.a aVar = SwipeRefreshLayout.this.L0;
            int i = this.q;
            aVar.setAlpha((int) (i + ((this.X - i) * f)));
        }
    }

    class e implements Animation.AnimationListener {
        e() {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (swipeRefreshLayout.B0) {
                return;
            }
            swipeRefreshLayout.y(null);
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    class f extends Animation {
        f() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            int iAbs = !swipeRefreshLayout.T0 ? swipeRefreshLayout.J0 - Math.abs(swipeRefreshLayout.I0) : swipeRefreshLayout.J0;
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            int i = swipeRefreshLayout2.G0;
            SwipeRefreshLayout.this.setTargetOffsetTopAndBottom((i + ((int) ((iAbs - i) * f))) - swipeRefreshLayout2.E0.getTop());
            SwipeRefreshLayout.this.L0.e(1.0f - f);
        }
    }

    class g extends Animation {
        g() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.q(f);
        }
    }

    class h extends Animation {
        h() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            float f2 = swipeRefreshLayout.H0;
            swipeRefreshLayout.setAnimationProgress(f2 + ((-f2) * f));
            SwipeRefreshLayout.this.q(f);
        }
    }

    public interface i {
        boolean a(SwipeRefreshLayout swipeRefreshLayout, View view);
    }

    public interface j {
        void a();
    }

    static class k extends View.BaseSavedState {
        public static final Parcelable.Creator<k> CREATOR = new a();
        final boolean q;

        class a implements Parcelable.Creator<k> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public k createFromParcel(Parcel parcel) {
                return new k(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public k[] newArray(int i) {
                return new k[i];
            }
        }

        k(Parcel parcel) {
            super(parcel);
            this.q = parcel.readByte() != 0;
        }

        k(Parcelable parcelable, boolean z) {
            super(parcelable);
            this.q = z;
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.q ? (byte) 1 : (byte) 0);
        }
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.l0 = false;
        this.n0 = -1.0f;
        this.r0 = new int[2];
        this.s0 = new int[2];
        this.t0 = new int[2];
        this.A0 = -1;
        this.F0 = -1;
        this.W0 = new a();
        this.X0 = new f();
        this.Y0 = new g();
        this.m0 = ViewConfiguration.get(context).getScaledTouchSlop();
        this.v0 = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.D0 = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.S0 = (int) (displayMetrics.density * 40.0f);
        e();
        setChildrenDrawingOrderEnabled(true);
        int i2 = (int) (displayMetrics.density * 64.0f);
        this.J0 = i2;
        this.n0 = i2;
        this.p0 = new H(this);
        this.q0 = new E(this);
        setNestedScrollingEnabled(true);
        int i3 = -this.S0;
        this.w0 = i3;
        this.I0 = i3;
        q(1.0f);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a1);
        setEnabled(typedArrayObtainStyledAttributes.getBoolean(0, true));
        typedArrayObtainStyledAttributes.recycle();
    }

    private void A(Animation.AnimationListener animationListener) {
        this.E0.setVisibility(0);
        this.L0.setAlpha(255);
        b bVar = new b();
        this.M0 = bVar;
        bVar.setDuration(this.v0);
        if (animationListener != null) {
            this.E0.b(animationListener);
        }
        this.E0.clearAnimation();
        this.E0.startAnimation(this.M0);
    }

    private void a(int i2, Animation.AnimationListener animationListener) {
        this.G0 = i2;
        this.X0.reset();
        this.X0.setDuration(200L);
        this.X0.setInterpolator(this.D0);
        if (animationListener != null) {
            this.E0.b(animationListener);
        }
        this.E0.clearAnimation();
        this.E0.startAnimation(this.X0);
    }

    private void b(int i2, Animation.AnimationListener animationListener) {
        if (this.B0) {
            z(i2, animationListener);
            return;
        }
        this.G0 = i2;
        this.Y0.reset();
        this.Y0.setDuration(200L);
        this.Y0.setInterpolator(this.D0);
        if (animationListener != null) {
            this.E0.b(animationListener);
        }
        this.E0.clearAnimation();
        this.E0.startAnimation(this.Y0);
    }

    private void e() {
        this.E0 = new androidx.swiperefreshlayout.widget.a(getContext());
        ax.p341v2.a aVar = new ax.p341v2.a(getContext());
        this.L0 = aVar;
        aVar.l(1);
        this.E0.setImageDrawable(this.L0);
        this.E0.setVisibility(8);
        addView(this.E0);
    }

    private void h() {
        if (this.q == null) {
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                View childAt = getChildAt(i2);
                if (!childAt.equals(this.E0)) {
                    this.q = childAt;
                    return;
                }
            }
        }
    }

    private void i(float f2) {
        if (f2 > this.n0) {
            t(true, true);
            return;
        }
        this.l0 = false;
        this.L0.j(0.0f, 0.0f);
        b(this.w0, !this.B0 ? new e() : null);
        this.L0.d(false);
    }

    private boolean j(Animation animation) {
        return (animation == null || !animation.hasStarted() || animation.hasEnded()) ? false : true;
    }

    private void l(float f2) {
        this.L0.d(true);
        float fMin = Math.min(1.0f, Math.abs(f2 / this.n0));
        float fMax = (((float) Math.max(((double) fMin) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float fAbs = Math.abs(f2) - this.n0;
        int i2 = this.K0;
        if (i2 <= 0) {
            i2 = this.T0 ? this.J0 - this.I0 : this.J0;
        }
        float f3 = i2;
        double dMax = Math.max(0.0f, Math.min(fAbs, f3 * 2.0f) / f3) / 4.0f;
        float fPow = ((float) (dMax - Math.pow(dMax, 2.0d))) * 2.0f;
        int i3 = this.I0 + ((int) ((f3 * fMin) + (f3 * fPow * 2.0f)));
        if (this.E0.getVisibility() != 0) {
            this.E0.setVisibility(0);
        }
        if (!this.B0) {
            this.E0.setScaleX(1.0f);
            this.E0.setScaleY(1.0f);
        }
        if (this.B0) {
            setAnimationProgress(Math.min(1.0f, f2 / this.n0));
        }
        if (f2 < this.n0) {
            if (this.L0.getAlpha() > 76 && !j(this.O0)) {
                x();
            }
        } else if (this.L0.getAlpha() < 255 && !j(this.P0)) {
            w();
        }
        this.L0.j(0.0f, Math.min(0.8f, fMax * 0.8f));
        this.L0.e(Math.min(1.0f, fMax));
        this.L0.g((((fMax * 0.4f) - 0.25f) + (fPow * 2.0f)) * 0.5f);
        setTargetOffsetTopAndBottom(i3 - this.w0);
    }

    private void r(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.A0) {
            this.A0 = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
        }
    }

    private void setColorViewAlpha(int i2) {
        this.E0.getBackground().setAlpha(i2);
        this.L0.setAlpha(i2);
    }

    private void t(boolean z, boolean z2) {
        if (this.l0 != z) {
            this.R0 = z2;
            h();
            this.l0 = z;
            if (z) {
                a(this.w0, this.W0);
            } else {
                y(this.W0);
            }
        }
    }

    private Animation u(int i2, int i3) {
        d dVar = new d(i2, i3);
        dVar.setDuration(300L);
        this.E0.b(null);
        this.E0.clearAnimation();
        this.E0.startAnimation(dVar);
        return dVar;
    }

    private void v(float f2) {
        float f3 = this.y0;
        float f4 = f2 - f3;
        int i2 = this.m0;
        if (f4 <= i2 || this.z0) {
            return;
        }
        this.x0 = f3 + i2;
        this.z0 = true;
        this.L0.setAlpha(76);
    }

    private void w() {
        this.P0 = u(this.L0.getAlpha(), 255);
    }

    private void x() {
        this.O0 = u(this.L0.getAlpha(), 76);
    }

    private void z(int i2, Animation.AnimationListener animationListener) {
        this.G0 = i2;
        this.H0 = this.E0.getScaleX();
        h hVar = new h();
        this.Q0 = hVar;
        hVar.setDuration(150L);
        if (animationListener != null) {
            this.E0.b(animationListener);
        }
        this.E0.clearAnimation();
        this.E0.startAnimation(this.Q0);
    }

    public boolean c() {
        i iVar = this.U0;
        if (iVar != null) {
            return iVar.a(this, this.q);
        }
        View view = this.q;
        return view instanceof ListView ? ax.p115h0.g.a((ListView) view, -1) : view.canScrollVertically(-1);
    }

    @Override // ax.p035c0.G
    public void d(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i6 != 0) {
            return;
        }
        int i7 = iArr[1];
        g(i2, i3, i4, i5, this.s0, i6, iArr);
        int i8 = i5 - (iArr[1] - i7);
        int i9 = i8 == 0 ? i5 + this.s0[1] : i8;
        if (i9 >= 0 || c()) {
            return;
        }
        float fAbs = this.o0 + Math.abs(i9);
        this.o0 = fAbs;
        l(fAbs);
        iArr[1] = iArr[1] + i8;
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z) {
        return this.q0.a(f2, f3, z);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.q0.b(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.q0.c(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.q0.f(i2, i3, i4, i5, iArr);
    }

    @Override // ax.p035c0.F
    public void f(View view, int i2, int i3, int i4, int i5, int i6) {
        d(view, i2, i3, i4, i5, i6, this.t0);
    }

    public void g(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        if (i6 == 0) {
            this.q0.e(i2, i3, i4, i5, iArr, i6, iArr2);
        }
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        int i4 = this.F0;
        if (i4 < 0) {
            return i3;
        }
        if (i3 == i2 - 1) {
            return i4;
        }
        return i3 >= i4 ? i3 + 1 : i3;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.p0.a();
    }

    public int getProgressCircleDiameter() {
        return this.S0;
    }

    public int getProgressViewEndOffset() {
        return this.J0;
    }

    public int getProgressViewStartOffset() {
        return this.I0;
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return this.q0.j();
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return this.q0.l();
    }

    public boolean k() {
        return this.l0;
    }

    @Override // ax.p035c0.F
    public boolean m(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            return onStartNestedScroll(view, view2, i2);
        }
        return false;
    }

    @Override // ax.p035c0.F
    public void n(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // ax.p035c0.F
    public void o(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        s();
    }

    /* JADX WARN: Code duplicated, block: B:36:0x0058  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        h();
        int actionMasked = motionEvent.getActionMasked();
        if (this.C0 && actionMasked == 0) {
            this.C0 = false;
        }
        if (!isEnabled() || this.C0 || c() || this.l0 || this.u0) {
            return false;
        }
        if (actionMasked == 0) {
            setTargetOffsetTopAndBottom(this.I0 - this.E0.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.A0 = pointerId;
            this.z0 = false;
            int iFindPointerIndex = motionEvent.findPointerIndex(pointerId);
            if (iFindPointerIndex < 0) {
                return false;
            }
            this.y0 = motionEvent.getY(iFindPointerIndex);
        } else if (actionMasked == 1) {
            this.z0 = false;
            this.A0 = -1;
        } else if (actionMasked == 2) {
            int i2 = this.A0;
            if (i2 == -1) {
                Log.e(Z0, "Got ACTION_MOVE event but don't have an active pointer id.");
                return false;
            }
            int iFindPointerIndex2 = motionEvent.findPointerIndex(i2);
            if (iFindPointerIndex2 < 0) {
                return false;
            }
            v(motionEvent.getY(iFindPointerIndex2));
        } else if (actionMasked == 3) {
            this.z0 = false;
            this.A0 = -1;
        } else if (actionMasked == 6) {
            r(motionEvent);
        }
        return this.z0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() == 0) {
            return;
        }
        if (this.q == null) {
            h();
        }
        View view = this.q;
        if (view == null) {
            return;
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
        int measuredWidth2 = this.E0.getMeasuredWidth();
        int measuredHeight2 = this.E0.getMeasuredHeight();
        int i6 = measuredWidth / 2;
        int i7 = measuredWidth2 / 2;
        int i8 = this.w0;
        this.E0.layout(i6 - i7, i8, i6 + i7, measuredHeight2 + i8);
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.q == null) {
            h();
        }
        View view = this.q;
        if (view == null) {
            return;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
        this.E0.measure(View.MeasureSpec.makeMeasureSpec(this.S0, 1073741824), View.MeasureSpec.makeMeasureSpec(this.S0, 1073741824));
        this.F0 = -1;
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            if (getChildAt(i4) == this.E0) {
                this.F0 = i4;
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        return dispatchNestedFling(f2, f3, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        if (i3 > 0) {
            float f2 = this.o0;
            if (f2 > 0.0f) {
                float f3 = i3;
                if (f3 > f2) {
                    iArr[1] = (int) f2;
                    this.o0 = 0.0f;
                } else {
                    this.o0 = f2 - f3;
                    iArr[1] = i3;
                }
                l(this.o0);
            }
        }
        if (this.T0 && i3 > 0 && this.o0 == 0.0f && Math.abs(i3 - iArr[1]) > 0) {
            this.E0.setVisibility(8);
        }
        int[] iArr2 = this.r0;
        if (dispatchNestedPreScroll(i2 - iArr[0], i3 - iArr[1], iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        d(view, i2, i3, i4, i5, 0, this.t0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.p0.b(view, view2, i2);
        startNestedScroll(i2 & 2);
        this.o0 = 0.0f;
        this.u0 = true;
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        k kVar = (k) parcelable;
        super.onRestoreInstanceState(kVar.getSuperState());
        setRefreshing(kVar.q);
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        return new k(super.onSaveInstanceState(), this.l0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return (!isEnabled() || this.C0 || this.l0 || (i2 & 2) == 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        this.p0.d(view);
        this.u0 = false;
        float f2 = this.o0;
        if (f2 > 0.0f) {
            i(f2);
            this.o0 = 0.0f;
        }
        stopNestedScroll();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (this.C0 && actionMasked == 0) {
            this.C0 = false;
        }
        if (!isEnabled() || this.C0 || c() || this.l0 || this.u0) {
            return false;
        }
        if (actionMasked == 0) {
            this.A0 = motionEvent.getPointerId(0);
            this.z0 = false;
        } else {
            if (actionMasked == 1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.A0);
                if (iFindPointerIndex < 0) {
                    Log.e(Z0, "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
                if (this.z0) {
                    float y = (motionEvent.getY(iFindPointerIndex) - this.x0) * 0.5f;
                    this.z0 = false;
                    i(y);
                }
                this.A0 = -1;
                return false;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex2 = motionEvent.findPointerIndex(this.A0);
                if (iFindPointerIndex2 < 0) {
                    Log.e(Z0, "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                float y2 = motionEvent.getY(iFindPointerIndex2);
                v(y2);
                if (this.z0) {
                    float f2 = (y2 - this.x0) * 0.5f;
                    if (f2 <= 0.0f) {
                        return false;
                    }
                    getParent().requestDisallowInterceptTouchEvent(true);
                    l(f2);
                }
            } else {
                if (actionMasked == 3) {
                    return false;
                }
                if (actionMasked == 5) {
                    int actionIndex = motionEvent.getActionIndex();
                    if (actionIndex < 0) {
                        Log.e(Z0, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                        return false;
                    }
                    this.A0 = motionEvent.getPointerId(actionIndex);
                } else if (actionMasked == 6) {
                    r(motionEvent);
                }
            }
        }
        return true;
    }

    @Override // ax.p035c0.F
    public void p(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    void q(float f2) {
        int i2 = this.G0;
        setTargetOffsetTopAndBottom((i2 + ((int) ((this.I0 - i2) * f2))) - this.E0.getTop());
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z) {
        ViewParent parent;
        View view = this.q;
        if (view == null || C1839d0.S(view)) {
            super.requestDisallowInterceptTouchEvent(z);
        } else {
            if (this.V0 || (parent = getParent()) == null) {
                return;
            }
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    void s() {
        this.E0.clearAnimation();
        this.L0.stop();
        this.E0.setVisibility(8);
        setColorViewAlpha(255);
        if (this.B0) {
            setAnimationProgress(0.0f);
        } else {
            setTargetOffsetTopAndBottom(this.I0 - this.w0);
        }
        this.w0 = this.E0.getTop();
    }

    void setAnimationProgress(float f2) {
        this.E0.setScaleX(f2);
        this.E0.setScaleY(f2);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        h();
        this.L0.f(iArr);
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr2[i2] = ax.Q.b.c(context, iArr[i2]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i2) {
        this.n0 = i2;
    }

    @Override // android.view.View
    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (z) {
            return;
        }
        s();
    }

    @Deprecated
    public void setLegacyRequestDisallowInterceptTouchEventEnabled(boolean z) {
        this.V0 = z;
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z) {
        this.q0.m(z);
    }

    public void setOnChildScrollUpCallback(i iVar) {
        this.U0 = iVar;
    }

    public void setOnRefreshListener(j jVar) {
        this.k0 = jVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i2) {
        setProgressBackgroundColorSchemeResource(i2);
    }

    public void setProgressBackgroundColorSchemeColor(int i2) {
        this.E0.setBackgroundColor(i2);
    }

    public void setProgressBackgroundColorSchemeResource(int i2) {
        setProgressBackgroundColorSchemeColor(ax.Q.b.c(getContext(), i2));
    }

    public void setRefreshing(boolean z) {
        if (!z || this.l0 == z) {
            t(z, false);
            return;
        }
        this.l0 = z;
        setTargetOffsetTopAndBottom((!this.T0 ? this.J0 + this.I0 : this.J0) - this.w0);
        this.R0 = false;
        A(this.W0);
    }

    public void setSize(int i2) {
        if (i2 == 0 || i2 == 1) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            if (i2 == 0) {
                this.S0 = (int) (displayMetrics.density * 56.0f);
            } else {
                this.S0 = (int) (displayMetrics.density * 40.0f);
            }
            this.E0.setImageDrawable(null);
            this.L0.l(i2);
            this.E0.setImageDrawable(this.L0);
        }
    }

    public void setSlingshotDistance(int i2) {
        this.K0 = i2;
    }

    void setTargetOffsetTopAndBottom(int i2) {
        this.E0.bringToFront();
        C1839d0.W(this.E0, i2);
        this.w0 = this.E0.getTop();
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return this.q0.o(i2);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        this.q0.q();
    }

    void y(Animation.AnimationListener animationListener) {
        c cVar = new c();
        this.N0 = cVar;
        cVar.setDuration(150L);
        this.E0.b(animationListener);
        this.E0.clearAnimation();
        this.E0.startAnimation(this.N0);
    }
}
