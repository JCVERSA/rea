package androidx.swiperefreshlayout.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.ListView;
import ax.p015b0.C;
import ax.p015b0.D;
import ax.p015b0.G;
import ax.p015b0.Y;

/* JADX INFO: loaded from: classes.dex */
public class SwipeRefreshLayout extends ViewGroup implements C {
    private static final String U0 = "SwipeRefreshLayout";
    private static final int[] V0 = {R.attr.enabled};
    androidx.swiperefreshlayout.widget.a A0;
    private int B0;
    protected int C0;
    float D0;
    protected int E0;
    int F0;
    int G0;
    ax.p072f1.a H0;
    private Animation I0;
    private Animation J0;
    private Animation K0;
    private Animation L0;
    private Animation M0;
    boolean N0;
    private int O0;
    boolean P0;
    private i Q0;
    private Animation.AnimationListener R0;
    private final Animation S0;
    private final Animation T0;
    j h0;
    boolean i0;
    private int j0;
    private float k0;
    private float l0;
    private final G m0;
    private final D n0;
    private final int[] o0;
    private final int[] p0;
    private View q;
    private boolean q0;
    private int r0;
    int s0;
    private float t0;
    private float u0;
    private boolean v0;
    private int w0;
    boolean x0;
    private boolean y0;
    private final DecelerateInterpolator z0;

    class a implements Animation.AnimationListener {
        a() {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            j jVar;
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (!swipeRefreshLayout.i0) {
                swipeRefreshLayout.l();
                return;
            }
            swipeRefreshLayout.H0.setAlpha(255);
            SwipeRefreshLayout.this.H0.start();
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            if (swipeRefreshLayout2.N0 && (jVar = swipeRefreshLayout2.h0) != null) {
                jVar.a();
            }
            SwipeRefreshLayout swipeRefreshLayout3 = SwipeRefreshLayout.this;
            swipeRefreshLayout3.s0 = swipeRefreshLayout3.A0.getTop();
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    class b extends Animation {
        b() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(f);
        }
    }

    class c extends Animation {
        c() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.setAnimationProgress(1.0f - f);
        }
    }

    class d extends Animation {
        final /* synthetic */ int X;
        final /* synthetic */ int q;

        d(int i, int i2) {
            this.q = i;
            this.X = i2;
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            ax.p072f1.a aVar = SwipeRefreshLayout.this.H0;
            int i = this.q;
            aVar.setAlpha((int) (i + ((this.X - i) * f)));
        }
    }

    class e implements Animation.AnimationListener {
        e() {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            if (swipeRefreshLayout.x0) {
                return;
            }
            swipeRefreshLayout.r(null);
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    class f extends Animation {
        f() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            int iAbs = !swipeRefreshLayout.P0 ? swipeRefreshLayout.F0 - Math.abs(swipeRefreshLayout.E0) : swipeRefreshLayout.F0;
            SwipeRefreshLayout swipeRefreshLayout2 = SwipeRefreshLayout.this;
            int i = swipeRefreshLayout2.C0;
            SwipeRefreshLayout.this.setTargetOffsetTopAndBottom((i + ((int) ((iAbs - i) * f))) - swipeRefreshLayout2.A0.getTop());
            SwipeRefreshLayout.this.H0.e(1.0f - f);
        }
    }

    class g extends Animation {
        g() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout.this.j(f);
        }
    }

    class h extends Animation {
        h() {
        }

        @Override // android.view.animation.Animation
        public void applyTransformation(float f, Transformation transformation) {
            SwipeRefreshLayout swipeRefreshLayout = SwipeRefreshLayout.this;
            float f2 = swipeRefreshLayout.D0;
            swipeRefreshLayout.setAnimationProgress(f2 + ((-f2) * f));
            SwipeRefreshLayout.this.j(f);
        }
    }

    public interface i {
        boolean a(SwipeRefreshLayout swipeRefreshLayout, View view);
    }

    public interface j {
        void a();
    }

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.i0 = false;
        this.k0 = -1.0f;
        this.o0 = new int[2];
        this.p0 = new int[2];
        this.w0 = -1;
        this.B0 = -1;
        this.R0 = new a();
        this.S0 = new f();
        this.T0 = new g();
        this.j0 = ViewConfiguration.get(context).getScaledTouchSlop();
        this.r0 = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.z0 = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.O0 = (int) (displayMetrics.density * 40.0f);
        d();
        setChildrenDrawingOrderEnabled(true);
        int i2 = (int) (displayMetrics.density * 64.0f);
        this.F0 = i2;
        this.k0 = i2;
        this.m0 = new G(this);
        this.n0 = new D(this);
        setNestedScrollingEnabled(true);
        int i3 = -this.O0;
        this.s0 = i3;
        this.E0 = i3;
        j(1.0f);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, V0);
        setEnabled(typedArrayObtainStyledAttributes.getBoolean(0, true));
        typedArrayObtainStyledAttributes.recycle();
    }

    private void a(int i2, Animation.AnimationListener animationListener) {
        this.C0 = i2;
        this.S0.reset();
        this.S0.setDuration(200L);
        this.S0.setInterpolator(this.z0);
        if (animationListener != null) {
            this.A0.b(animationListener);
        }
        this.A0.clearAnimation();
        this.A0.startAnimation(this.S0);
    }

    private void b(int i2, Animation.AnimationListener animationListener) {
        if (this.x0) {
            s(i2, animationListener);
            return;
        }
        this.C0 = i2;
        this.T0.reset();
        this.T0.setDuration(200L);
        this.T0.setInterpolator(this.z0);
        if (animationListener != null) {
            this.A0.b(animationListener);
        }
        this.A0.clearAnimation();
        this.A0.startAnimation(this.T0);
    }

    private void d() {
        this.A0 = new androidx.swiperefreshlayout.widget.a(getContext(), -328966);
        ax.p072f1.a aVar = new ax.p072f1.a(getContext());
        this.H0 = aVar;
        aVar.l(1);
        this.A0.setImageDrawable(this.H0);
        this.A0.setVisibility(8);
        addView(this.A0);
    }

    private void e() {
        if (this.q == null) {
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                View childAt = getChildAt(i2);
                if (!childAt.equals(this.A0)) {
                    this.q = childAt;
                    return;
                }
            }
        }
    }

    private void f(float f2) {
        if (f2 > this.k0) {
            m(true, true);
            return;
        }
        this.i0 = false;
        this.H0.j(0.0f, 0.0f);
        b(this.s0, !this.x0 ? new e() : null);
        this.H0.d(false);
    }

    private boolean g(Animation animation) {
        return (animation == null || !animation.hasStarted() || animation.hasEnded()) ? false : true;
    }

    private void i(float f2) {
        this.H0.d(true);
        float fMin = Math.min(1.0f, Math.abs(f2 / this.k0));
        float fMax = (((float) Math.max(((double) fMin) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float fAbs = Math.abs(f2) - this.k0;
        int i2 = this.G0;
        if (i2 <= 0) {
            i2 = this.P0 ? this.F0 - this.E0 : this.F0;
        }
        float f3 = i2;
        double dMax = Math.max(0.0f, Math.min(fAbs, f3 * 2.0f) / f3) / 4.0f;
        float fPow = ((float) (dMax - Math.pow(dMax, 2.0d))) * 2.0f;
        int i3 = this.E0 + ((int) ((f3 * fMin) + (f3 * fPow * 2.0f)));
        if (this.A0.getVisibility() != 0) {
            this.A0.setVisibility(0);
        }
        if (!this.x0) {
            this.A0.setScaleX(1.0f);
            this.A0.setScaleY(1.0f);
        }
        if (this.x0) {
            setAnimationProgress(Math.min(1.0f, f2 / this.k0));
        }
        if (f2 < this.k0) {
            if (this.H0.getAlpha() > 76 && !g(this.K0)) {
                q();
            }
        } else if (this.H0.getAlpha() < 255 && !g(this.L0)) {
            p();
        }
        this.H0.j(0.0f, Math.min(0.8f, fMax * 0.8f));
        this.H0.e(Math.min(1.0f, fMax));
        this.H0.g((((fMax * 0.4f) - 0.25f) + (fPow * 2.0f)) * 0.5f);
        setTargetOffsetTopAndBottom(i3 - this.s0);
    }

    private void k(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.w0) {
            this.w0 = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
        }
    }

    private void m(boolean z, boolean z2) {
        if (this.i0 != z) {
            this.N0 = z2;
            e();
            this.i0 = z;
            if (z) {
                a(this.s0, this.R0);
            } else {
                r(this.R0);
            }
        }
    }

    private Animation n(int i2, int i3) {
        d dVar = new d(i2, i3);
        dVar.setDuration(300L);
        this.A0.b(null);
        this.A0.clearAnimation();
        this.A0.startAnimation(dVar);
        return dVar;
    }

    private void o(float f2) {
        float f3 = this.u0;
        float f4 = f2 - f3;
        int i2 = this.j0;
        if (f4 <= i2 || this.v0) {
            return;
        }
        this.t0 = f3 + i2;
        this.v0 = true;
        this.H0.setAlpha(76);
    }

    private void p() {
        this.L0 = n(this.H0.getAlpha(), 255);
    }

    private void q() {
        this.K0 = n(this.H0.getAlpha(), 76);
    }

    private void s(int i2, Animation.AnimationListener animationListener) {
        this.C0 = i2;
        this.D0 = this.A0.getScaleX();
        h hVar = new h();
        this.M0 = hVar;
        hVar.setDuration(150L);
        if (animationListener != null) {
            this.A0.b(animationListener);
        }
        this.A0.clearAnimation();
        this.A0.startAnimation(this.M0);
    }

    private void setColorViewAlpha(int i2) {
        this.A0.getBackground().setAlpha(i2);
        this.H0.setAlpha(i2);
    }

    private void t(Animation.AnimationListener animationListener) {
        this.A0.setVisibility(0);
        this.H0.setAlpha(255);
        b bVar = new b();
        this.I0 = bVar;
        bVar.setDuration(this.r0);
        if (animationListener != null) {
            this.A0.b(animationListener);
        }
        this.A0.clearAnimation();
        this.A0.startAnimation(this.I0);
    }

    public boolean c() {
        i iVar = this.Q0;
        if (iVar != null) {
            return iVar.a(this, this.q);
        }
        View view = this.q;
        return view instanceof ListView ? ax.p099h0.g.a((ListView) view, -1) : view.canScrollVertically(-1);
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z) {
        return this.n0.a(f2, f3, z);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.n0.b(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.n0.c(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.n0.f(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        int i4 = this.B0;
        if (i4 < 0) {
            return i3;
        }
        if (i3 == i2 - 1) {
            return i4;
        }
        return i3 >= i4 ? i3 + 1 : i3;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.m0.a();
    }

    public int getProgressCircleDiameter() {
        return this.O0;
    }

    public int getProgressViewEndOffset() {
        return this.F0;
    }

    public int getProgressViewStartOffset() {
        return this.E0;
    }

    public boolean h() {
        return this.i0;
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return this.n0.j();
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return this.n0.l();
    }

    void j(float f2) {
        int i2 = this.C0;
        setTargetOffsetTopAndBottom((i2 + ((int) ((this.E0 - i2) * f2))) - this.A0.getTop());
    }

    void l() {
        this.A0.clearAnimation();
        this.H0.stop();
        this.A0.setVisibility(8);
        setColorViewAlpha(255);
        if (this.x0) {
            setAnimationProgress(0.0f);
        } else {
            setTargetOffsetTopAndBottom(this.E0 - this.s0);
        }
        this.s0 = this.A0.getTop();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l();
    }

    /* JADX WARN: Code duplicated, block: B:36:0x0058  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        e();
        int actionMasked = motionEvent.getActionMasked();
        if (this.y0 && actionMasked == 0) {
            this.y0 = false;
        }
        if (!isEnabled() || this.y0 || c() || this.i0 || this.q0) {
            return false;
        }
        if (actionMasked == 0) {
            setTargetOffsetTopAndBottom(this.E0 - this.A0.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.w0 = pointerId;
            this.v0 = false;
            int iFindPointerIndex = motionEvent.findPointerIndex(pointerId);
            if (iFindPointerIndex < 0) {
                return false;
            }
            this.u0 = motionEvent.getY(iFindPointerIndex);
        } else if (actionMasked == 1) {
            this.v0 = false;
            this.w0 = -1;
        } else if (actionMasked == 2) {
            int i2 = this.w0;
            if (i2 == -1) {
                Log.e(U0, "Got ACTION_MOVE event but don't have an active pointer id.");
                return false;
            }
            int iFindPointerIndex2 = motionEvent.findPointerIndex(i2);
            if (iFindPointerIndex2 < 0) {
                return false;
            }
            o(motionEvent.getY(iFindPointerIndex2));
        } else if (actionMasked == 3) {
            this.v0 = false;
            this.w0 = -1;
        } else if (actionMasked == 6) {
            k(motionEvent);
        }
        return this.v0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() == 0) {
            return;
        }
        if (this.q == null) {
            e();
        }
        View view = this.q;
        if (view == null) {
            return;
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
        int measuredWidth2 = this.A0.getMeasuredWidth();
        int measuredHeight2 = this.A0.getMeasuredHeight();
        int i6 = measuredWidth / 2;
        int i7 = measuredWidth2 / 2;
        int i8 = this.s0;
        this.A0.layout(i6 - i7, i8, i6 + i7, measuredHeight2 + i8);
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.q == null) {
            e();
        }
        View view = this.q;
        if (view == null) {
            return;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
        this.A0.measure(View.MeasureSpec.makeMeasureSpec(this.O0, 1073741824), View.MeasureSpec.makeMeasureSpec(this.O0, 1073741824));
        this.B0 = -1;
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            if (getChildAt(i4) == this.A0) {
                this.B0 = i4;
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        return dispatchNestedFling(f2, f3, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        if (i3 > 0) {
            float f2 = this.l0;
            if (f2 > 0.0f) {
                float f3 = i3;
                if (f3 > f2) {
                    iArr[1] = i3 - ((int) f2);
                    this.l0 = 0.0f;
                } else {
                    this.l0 = f2 - f3;
                    iArr[1] = i3;
                }
                i(this.l0);
            }
        }
        if (this.P0 && i3 > 0 && this.l0 == 0.0f && Math.abs(i3 - iArr[1]) > 0) {
            this.A0.setVisibility(8);
        }
        int[] iArr2 = this.o0;
        if (dispatchNestedPreScroll(i2 - iArr[0], i3 - iArr[1], iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        dispatchNestedScroll(i2, i3, i4, i5, this.p0);
        int i6 = i5 + this.p0[1];
        if (i6 >= 0 || c()) {
            return;
        }
        float fAbs = this.l0 + Math.abs(i6);
        this.l0 = fAbs;
        i(fAbs);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.m0.b(view, view2, i2);
        startNestedScroll(i2 & 2);
        this.l0 = 0.0f;
        this.q0 = true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return (!isEnabled() || this.y0 || this.i0 || (i2 & 2) == 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        this.m0.d(view);
        this.q0 = false;
        float f2 = this.l0;
        if (f2 > 0.0f) {
            f(f2);
            this.l0 = 0.0f;
        }
        stopNestedScroll();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (this.y0 && actionMasked == 0) {
            this.y0 = false;
        }
        if (!isEnabled() || this.y0 || c() || this.i0 || this.q0) {
            return false;
        }
        if (actionMasked == 0) {
            this.w0 = motionEvent.getPointerId(0);
            this.v0 = false;
        } else {
            if (actionMasked == 1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.w0);
                if (iFindPointerIndex < 0) {
                    Log.e(U0, "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
                if (this.v0) {
                    float y = (motionEvent.getY(iFindPointerIndex) - this.t0) * 0.5f;
                    this.v0 = false;
                    f(y);
                }
                this.w0 = -1;
                return false;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex2 = motionEvent.findPointerIndex(this.w0);
                if (iFindPointerIndex2 < 0) {
                    Log.e(U0, "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                float y2 = motionEvent.getY(iFindPointerIndex2);
                o(y2);
                if (this.v0) {
                    float f2 = (y2 - this.t0) * 0.5f;
                    if (f2 <= 0.0f) {
                        return false;
                    }
                    i(f2);
                }
            } else {
                if (actionMasked == 3) {
                    return false;
                }
                if (actionMasked == 5) {
                    int actionIndex = motionEvent.getActionIndex();
                    if (actionIndex < 0) {
                        Log.e(U0, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                        return false;
                    }
                    this.w0 = motionEvent.getPointerId(actionIndex);
                } else if (actionMasked == 6) {
                    k(motionEvent);
                }
            }
        }
        return true;
    }

    void r(Animation.AnimationListener animationListener) {
        c cVar = new c();
        this.J0 = cVar;
        cVar.setDuration(150L);
        this.A0.b(animationListener);
        this.A0.clearAnimation();
        this.A0.startAnimation(this.J0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z) {
        View view = this.q;
        if (view == null || Y.V(view)) {
            super.requestDisallowInterceptTouchEvent(z);
        }
    }

    void setAnimationProgress(float f2) {
        this.A0.setScaleX(f2);
        this.A0.setScaleY(f2);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        e();
        this.H0.f(iArr);
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr2[i2] = ax.P.b.c(context, iArr[i2]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i2) {
        this.k0 = i2;
    }

    @Override // android.view.View
    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (z) {
            return;
        }
        l();
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z) {
        this.n0.m(z);
    }

    public void setOnChildScrollUpCallback(i iVar) {
        this.Q0 = iVar;
    }

    public void setOnRefreshListener(j jVar) {
        this.h0 = jVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i2) {
        setProgressBackgroundColorSchemeResource(i2);
    }

    public void setProgressBackgroundColorSchemeColor(int i2) {
        this.A0.setBackgroundColor(i2);
    }

    public void setProgressBackgroundColorSchemeResource(int i2) {
        setProgressBackgroundColorSchemeColor(ax.P.b.c(getContext(), i2));
    }

    public void setRefreshing(boolean z) {
        if (!z || this.i0 == z) {
            m(z, false);
            return;
        }
        this.i0 = z;
        setTargetOffsetTopAndBottom((!this.P0 ? this.F0 + this.E0 : this.F0) - this.s0);
        this.N0 = false;
        t(this.R0);
    }

    public void setSize(int i2) {
        if (i2 == 0 || i2 == 1) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            if (i2 == 0) {
                this.O0 = (int) (displayMetrics.density * 56.0f);
            } else {
                this.O0 = (int) (displayMetrics.density * 40.0f);
            }
            this.A0.setImageDrawable(null);
            this.H0.l(i2);
            this.A0.setImageDrawable(this.H0);
        }
    }

    public void setSlingshotDistance(int i2) {
        this.G0 = i2;
    }

    void setTargetOffsetTopAndBottom(int i2) {
        this.A0.bringToFront();
        Y.b0(this.A0, i2);
        this.s0 = this.A0.getTop();
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return this.n0.o(i2);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        this.n0.q();
    }
}
