package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

/* JADX INFO: loaded from: classes.dex */
public class a extends c {
    private int s0;
    private int t0;
    private ax.H.a u0;

    public a(Context context) {
        super(context);
        super.setVisibility(8);
    }

    private void t(ax.H.e eVar, int i, boolean z) {
        this.t0 = i;
        if (z) {
            int i2 = this.s0;
            if (i2 == 5) {
                this.t0 = 1;
            } else if (i2 == 6) {
                this.t0 = 0;
            }
        } else {
            int i3 = this.s0;
            if (i3 == 5) {
                this.t0 = 0;
            } else if (i3 == 6) {
                this.t0 = 1;
            }
        }
        if (eVar instanceof ax.H.a) {
            ((ax.H.a) eVar).A1(this.t0);
        }
    }

    public boolean getAllowsGoneWidget() {
        return this.u0.u1();
    }

    public int getMargin() {
        return this.u0.w1();
    }

    public int getType() {
        return this.s0;
    }

    @Override // androidx.constraintlayout.widget.c
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.u0 = new ax.H.a();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, ax.L.c.n1);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == ax.L.c.D1) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == ax.L.c.C1) {
                    this.u0.z1(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == ax.L.c.E1) {
                    this.u0.B1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.m0 = this.u0;
        s();
    }

    @Override // androidx.constraintlayout.widget.c
    public void n(ax.H.e eVar, boolean z) {
        t(eVar, this.s0, z);
    }

    public void setAllowsGoneWidget(boolean z) {
        this.u0.z1(z);
    }

    public void setDpMargin(int i) {
        this.u0.B1((int) ((i * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i) {
        this.u0.B1(i);
    }

    public void setType(int i) {
        this.s0 = i;
    }
}
