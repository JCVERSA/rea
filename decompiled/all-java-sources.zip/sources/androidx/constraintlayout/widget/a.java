package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

/* JADX INFO: loaded from: classes.dex */
public class a extends c {
    private int p0;
    private int q0;
    private ax.G.a r0;

    public a(Context context) {
        super(context);
        super.setVisibility(8);
    }

    private void t(ax.G.e eVar, int i, boolean z) {
        this.q0 = i;
        if (z) {
            int i2 = this.p0;
            if (i2 == 5) {
                this.q0 = 1;
            } else if (i2 == 6) {
                this.q0 = 0;
            }
        } else {
            int i3 = this.p0;
            if (i3 == 5) {
                this.q0 = 0;
            } else if (i3 == 6) {
                this.q0 = 1;
            }
        }
        if (eVar instanceof ax.G.a) {
            ((ax.G.a) eVar).A1(this.q0);
        }
    }

    public boolean getAllowsGoneWidget() {
        return this.r0.u1();
    }

    public int getMargin() {
        return this.r0.w1();
    }

    public int getType() {
        return this.p0;
    }

    @Override // androidx.constraintlayout.widget.c
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.r0 = new ax.G.a();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, ax.K.c.n1);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == ax.K.c.D1) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == ax.K.c.C1) {
                    this.r0.z1(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == ax.K.c.E1) {
                    this.r0.B1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.j0 = this.r0;
        s();
    }

    @Override // androidx.constraintlayout.widget.c
    public void n(ax.G.e eVar, boolean z) {
        t(eVar, this.p0, z);
    }

    public void setAllowsGoneWidget(boolean z) {
        this.r0.z1(z);
    }

    public void setDpMargin(int i) {
        this.r0.B1((int) ((i * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i) {
        this.r0.B1(i);
    }

    public void setType(int i) {
        this.p0 = i;
    }
}
