package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import ax.G.k;
import ax.G.l;
import ax.P5.C1452Re;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;
import java.util.HashMap;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.ws.WebSocketProtocol;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {
    private static ax.K.d D0;
    c A0;
    private int B0;
    private int C0;
    private ArrayList<androidx.constraintlayout.widget.c> h0;
    protected ax.G.f i0;
    private int j0;
    private int k0;
    private int l0;
    private int m0;
    protected boolean n0;
    private int o0;
    private e p0;
    SparseArray<View> q;
    protected d q0;
    private int r0;
    private HashMap<String, Integer> s0;
    private int t0;
    private int u0;
    int v0;
    int w0;
    int x0;
    int y0;
    private SparseArray<ax.G.e> z0;

    static /* synthetic */ class a {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[ax.G.e.b.values().length];
            a = iArr;
            try {
                iArr[ax.G.e.b.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[ax.G.e.b.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[ax.G.e.b.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[ax.G.e.b.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class c implements ax.H.b.InterfaceC0139b {
        ConstraintLayout a;
        int b;
        int c;
        int d;
        int e;
        int f;
        int g;

        public c(ConstraintLayout constraintLayout) {
            this.a = constraintLayout;
        }

        private boolean d(int i, int i2, int i3) {
            if (i == i2) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i);
            View.MeasureSpec.getSize(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (mode2 == 1073741824) {
                return (mode == Integer.MIN_VALUE || mode == 0) && i3 == size;
            }
            return false;
        }

        @Override // ax.H.b.InterfaceC0139b
        public final void a() {
            int childCount = this.a.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.a.getChildAt(i);
                if (childAt instanceof h) {
                    ((h) childAt).a(this.a);
                }
            }
            int size = this.a.h0.size();
            if (size > 0) {
                for (int i2 = 0; i2 < size; i2++) {
                    ((androidx.constraintlayout.widget.c) this.a.h0.get(i2)).p(this.a);
                }
            }
        }

        @Override // ax.H.b.InterfaceC0139b
        @SuppressLint({"WrongCall"})
        public final void b(ax.G.e eVar, ax.H.b.a aVar) {
            int iMakeMeasureSpec;
            int iMakeMeasureSpec2;
            int baseline;
            int iMax;
            int iMax2;
            int iMakeMeasureSpec3;
            int i;
            if (eVar == null) {
                return;
            }
            if (eVar.V() == 8 && !eVar.j0()) {
                aVar.e = 0;
                aVar.f = 0;
                aVar.g = 0;
                return;
            }
            if (eVar.K() == null) {
                return;
            }
            ax.G.e.b bVar = aVar.a;
            ax.G.e.b bVar2 = aVar.b;
            int i2 = aVar.c;
            int i3 = aVar.d;
            int i4 = this.b + this.c;
            int i5 = this.d;
            View view = (View) eVar.s();
            int[] iArr = a.a;
            int i6 = iArr[bVar.ordinal()];
            if (i6 == 1) {
                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
            } else if (i6 == 2) {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i5, -2);
            } else if (i6 == 3) {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i5 + eVar.B(), -1);
            } else if (i6 != 4) {
                iMakeMeasureSpec = 0;
            } else {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f, i5, -2);
                boolean z = eVar.w == 1;
                int i7 = aVar.j;
                if (i7 == ax.H.b.a.l || i7 == ax.H.b.a.m) {
                    boolean z2 = view.getMeasuredHeight() == eVar.x();
                    if (aVar.j == ax.H.b.a.m || !z || ((z && z2) || (view instanceof h) || eVar.n0())) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(eVar.W(), 1073741824);
                    }
                }
            }
            int i8 = iArr[bVar2.ordinal()];
            if (i8 == 1) {
                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
            } else if (i8 == 2) {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i4, -2);
            } else if (i8 == 3) {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i4 + eVar.U(), -1);
            } else if (i8 != 4) {
                iMakeMeasureSpec2 = 0;
            } else {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.g, i4, -2);
                boolean z3 = eVar.x == 1;
                int i9 = aVar.j;
                if (i9 == ax.H.b.a.l || i9 == ax.H.b.a.m) {
                    boolean z4 = view.getMeasuredWidth() == eVar.W();
                    if (aVar.j == ax.H.b.a.m || !z3 || ((z3 && z4) || (view instanceof h) || eVar.o0())) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(eVar.x(), 1073741824);
                    }
                }
            }
            ax.G.f fVar = (ax.G.f) eVar.K();
            if (fVar != null && k.b(ConstraintLayout.this.o0, 256) && view.getMeasuredWidth() == eVar.W() && view.getMeasuredWidth() < fVar.W() && view.getMeasuredHeight() == eVar.x() && view.getMeasuredHeight() < fVar.x() && view.getBaseline() == eVar.p() && !eVar.m0() && d(eVar.C(), iMakeMeasureSpec, eVar.W()) && d(eVar.D(), iMakeMeasureSpec2, eVar.x())) {
                aVar.e = eVar.W();
                aVar.f = eVar.x();
                aVar.g = eVar.p();
                return;
            }
            ax.G.e.b bVar3 = ax.G.e.b.MATCH_CONSTRAINT;
            boolean z5 = bVar == bVar3;
            boolean z6 = bVar2 == bVar3;
            ax.G.e.b bVar4 = ax.G.e.b.MATCH_PARENT;
            boolean z7 = bVar2 == bVar4 || bVar2 == ax.G.e.b.FIXED;
            boolean z8 = bVar == bVar4 || bVar == ax.G.e.b.FIXED;
            boolean z9 = z5 && eVar.d0 > 0.0f;
            boolean z10 = z6 && eVar.d0 > 0.0f;
            if (view == null) {
                return;
            }
            b bVar5 = (b) view.getLayoutParams();
            int i10 = aVar.j;
            if (i10 != ax.H.b.a.l && i10 != ax.H.b.a.m && z5 && eVar.w == 0 && z6 && eVar.x == 0) {
                i = -1;
                iMax2 = 0;
                baseline = 0;
                iMax = 0;
            } else {
                if ((view instanceof ax.K.e) && (eVar instanceof l)) {
                    ((ax.K.e) view).t((l) eVar, iMakeMeasureSpec, iMakeMeasureSpec2);
                } else {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                }
                eVar.V0(iMakeMeasureSpec, iMakeMeasureSpec2);
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                baseline = view.getBaseline();
                int i11 = eVar.z;
                iMax = i11 > 0 ? Math.max(i11, measuredWidth) : measuredWidth;
                int i12 = eVar.A;
                if (i12 > 0) {
                    iMax = Math.min(i12, iMax);
                }
                int i13 = eVar.C;
                iMax2 = i13 > 0 ? Math.max(i13, measuredHeight) : measuredHeight;
                int i14 = eVar.D;
                if (i14 > 0) {
                    iMax2 = Math.min(i14, iMax2);
                }
                if (!k.b(ConstraintLayout.this.o0, 1)) {
                    if (z9 && z7) {
                        iMax = (int) ((iMax2 * eVar.d0) + 0.5f);
                    } else if (z10 && z8) {
                        iMax2 = (int) ((iMax / eVar.d0) + 0.5f);
                    }
                }
                if (measuredWidth != iMax || measuredHeight != iMax2) {
                    if (measuredWidth != iMax) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(iMax, 1073741824);
                    }
                    if (measuredHeight != iMax2) {
                        iMakeMeasureSpec3 = iMakeMeasureSpec;
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, 1073741824);
                    }
                    iMakeMeasureSpec3 = iMakeMeasureSpec;
                    view.measure(iMakeMeasureSpec3, iMakeMeasureSpec2);
                    eVar.V0(iMakeMeasureSpec3, iMakeMeasureSpec2);
                    iMax = view.getMeasuredWidth();
                    iMax2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                }
                i = -1;
            }
            boolean z11 = baseline != i;
            aVar.i = (iMax == aVar.c && iMax2 == aVar.d) ? false : true;
            if (bVar5.g0) {
                z11 = true;
            }
            if (z11 && baseline != -1 && eVar.p() != baseline) {
                aVar.i = true;
            }
            aVar.e = iMax;
            aVar.f = iMax2;
            aVar.h = z11;
            aVar.g = baseline;
        }

        public void c(int i, int i2, int i3, int i4, int i5, int i6) {
            this.b = i3;
            this.c = i4;
            this.d = i5;
            this.e = i6;
            this.f = i;
            this.g = i2;
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.q = new SparseArray<>();
        this.h0 = new ArrayList<>(4);
        this.i0 = new ax.G.f();
        this.j0 = 0;
        this.k0 = 0;
        this.l0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.m0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.n0 = true;
        this.o0 = 257;
        this.p0 = null;
        this.q0 = null;
        this.r0 = -1;
        this.s0 = new HashMap<>();
        this.t0 = -1;
        this.u0 = -1;
        this.v0 = -1;
        this.w0 = -1;
        this.x0 = 0;
        this.y0 = 0;
        this.z0 = new SparseArray<>();
        this.A0 = new c(this);
        this.B0 = 0;
        this.C0 = 0;
        q(attributeSet, 0, 0);
    }

    private boolean A() {
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            if (getChildAt(i).isLayoutRequested()) {
                z = true;
                break;
            }
        }
        if (z) {
            w();
        }
        return z;
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int iMax2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static ax.K.d getSharedValues() {
        if (D0 == null) {
            D0 = new ax.K.d();
        }
        return D0;
    }

    private final ax.G.e j(int i) {
        if (i == 0) {
            return this.i0;
        }
        View viewFindViewById = this.q.get(i);
        if (viewFindViewById == null && (viewFindViewById = findViewById(i)) != null && viewFindViewById != this && viewFindViewById.getParent() == this) {
            onViewAdded(viewFindViewById);
        }
        if (viewFindViewById == this) {
            return this.i0;
        }
        if (viewFindViewById == null) {
            return null;
        }
        return ((b) viewFindViewById.getLayoutParams()).v0;
    }

    private void q(AttributeSet attributeSet, int i, int i2) {
        this.i0.B0(this);
        this.i0.V1(this.A0);
        this.q.put(getId(), this);
        this.p0 = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, ax.K.c.n1, i, i2);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == ax.K.c.x1) {
                    this.j0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.j0);
                } else if (index == ax.K.c.y1) {
                    this.k0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.k0);
                } else if (index == ax.K.c.v1) {
                    this.l0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.l0);
                } else if (index == ax.K.c.w1) {
                    this.m0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.m0);
                } else if (index == ax.K.c.g3) {
                    this.o0 = typedArrayObtainStyledAttributes.getInt(index, this.o0);
                } else if (index == ax.K.c.b2) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            t(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.q0 = null;
                        }
                    }
                } else if (index == ax.K.c.F1) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        e eVar = new e();
                        this.p0 = eVar;
                        eVar.l(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.p0 = null;
                    }
                    this.r0 = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.i0.W1(this.o0);
    }

    private void s() {
        this.n0 = true;
        this.t0 = -1;
        this.u0 = -1;
        this.v0 = -1;
        this.w0 = -1;
        this.x0 = 0;
        this.y0 = 0;
    }

    private void w() {
        boolean zIsInEditMode = isInEditMode();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            ax.G.e eVarL = l(getChildAt(i));
            if (eVarL != null) {
                eVarL.t0();
            }
        }
        if (zIsInEditMode) {
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    x(0, resourceName, Integer.valueOf(childAt.getId()));
                    int iIndexOf = resourceName.indexOf(47);
                    if (iIndexOf != -1) {
                        resourceName = resourceName.substring(iIndexOf + 1);
                    }
                    j(childAt.getId()).C0(resourceName);
                } catch (Resources.NotFoundException unused) {
                }
            }
        }
        if (this.r0 != -1) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt2 = getChildAt(i3);
                if (childAt2.getId() == this.r0 && (childAt2 instanceof f)) {
                    this.p0 = ((f) childAt2).getConstraintSet();
                }
            }
        }
        e eVar = this.p0;
        if (eVar != null) {
            eVar.d(this, true);
        }
        this.i0.u1();
        int size = this.h0.size();
        if (size > 0) {
            for (int i4 = 0; i4 < size; i4++) {
                this.h0.get(i4).r(this);
            }
        }
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt3 = getChildAt(i5);
            if (childAt3 instanceof h) {
                ((h) childAt3).b(this);
            }
        }
        this.z0.clear();
        this.z0.put(0, this.i0);
        this.z0.put(getId(), this.i0);
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt4 = getChildAt(i6);
            this.z0.put(childAt4.getId(), l(childAt4));
        }
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt5 = getChildAt(i7);
            ax.G.e eVarL2 = l(childAt5);
            if (eVarL2 != null) {
                b bVar = (b) childAt5.getLayoutParams();
                this.i0.c(eVarL2);
                e(zIsInEditMode, childAt5, eVarL2, bVar, this.z0);
            }
        }
    }

    private void z(ax.G.e eVar, b bVar, SparseArray<ax.G.e> sparseArray, int i, ax.G.d.b bVar2) {
        View view = this.q.get(i);
        ax.G.e eVar2 = sparseArray.get(i);
        if (eVar2 == null || view == null || !(view.getLayoutParams() instanceof b)) {
            return;
        }
        bVar.g0 = true;
        ax.G.d.b bVar3 = ax.G.d.b.BASELINE;
        if (bVar2 == bVar3) {
            b bVar4 = (b) view.getLayoutParams();
            bVar4.g0 = true;
            bVar4.v0.K0(true);
        }
        eVar.o(bVar3).b(eVar2.o(bVar2), bVar.D, bVar.C, true);
        eVar.K0(true);
        eVar.o(ax.G.d.b.TOP).q();
        eVar.o(ax.G.d.b.BOTTOM).q();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof b;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<androidx.constraintlayout.widget.c> arrayList = this.h0;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i = 0; i < size; i++) {
                this.h0.get(i).q(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i3 = Integer.parseInt(strArrSplit[0]);
                        int i4 = Integer.parseInt(strArrSplit[1]);
                        int i5 = Integer.parseInt(strArrSplit[2]);
                        int i6 = (int) ((i3 / 1080.0f) * width);
                        int i7 = (int) ((i4 / 1920.0f) * height);
                        int i8 = (int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = i6;
                        float f2 = i7;
                        float f3 = i6 + ((int) ((i5 / 1080.0f) * width));
                        canvas.drawLine(f, f2, f3, f2, paint);
                        float f4 = i7 + i8;
                        canvas.drawLine(f3, f2, f3, f4, paint);
                        canvas.drawLine(f3, f4, f, f4, paint);
                        canvas.drawLine(f, f4, f, f2, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f, f2, f3, f4, paint);
                        canvas.drawLine(f, f4, f3, f2, paint);
                    }
                }
            }
        }
    }

    protected void e(boolean z, View view, ax.G.e eVar, b bVar, SparseArray<ax.G.e> sparseArray) {
        ax.G.e eVar2;
        ax.G.e eVar3;
        ax.G.e eVar4;
        ax.G.e eVar5;
        int i;
        bVar.a();
        bVar.w0 = false;
        eVar.j1(view.getVisibility());
        if (bVar.j0) {
            eVar.T0(true);
            eVar.j1(8);
        }
        eVar.B0(view);
        if (view instanceof androidx.constraintlayout.widget.c) {
            ((androidx.constraintlayout.widget.c) view).n(eVar, this.i0.P1());
        }
        if (bVar.h0) {
            ax.G.h hVar = (ax.G.h) eVar;
            int i2 = bVar.s0;
            int i3 = bVar.t0;
            float f = bVar.u0;
            if (f != -1.0f) {
                hVar.z1(f);
                return;
            } else if (i2 != -1) {
                hVar.x1(i2);
                return;
            } else {
                if (i3 != -1) {
                    hVar.y1(i3);
                    return;
                }
                return;
            }
        }
        int i4 = bVar.l0;
        int i5 = bVar.m0;
        int i6 = bVar.n0;
        int i7 = bVar.o0;
        int i8 = bVar.p0;
        int i9 = bVar.q0;
        float f2 = bVar.r0;
        int i10 = bVar.p;
        if (i10 != -1) {
            ax.G.e eVar6 = sparseArray.get(i10);
            if (eVar6 != null) {
                eVar.l(eVar6, bVar.r, bVar.q);
            }
        } else {
            if (i4 != -1) {
                ax.G.e eVar7 = sparseArray.get(i4);
                if (eVar7 != null) {
                    ax.G.d.b bVar2 = ax.G.d.b.LEFT;
                    eVar.e0(bVar2, eVar7, bVar2, ((ViewGroup.MarginLayoutParams) bVar).leftMargin, i8);
                }
            } else if (i5 != -1 && (eVar2 = sparseArray.get(i5)) != null) {
                eVar.e0(ax.G.d.b.LEFT, eVar2, ax.G.d.b.RIGHT, ((ViewGroup.MarginLayoutParams) bVar).leftMargin, i8);
            }
            if (i6 != -1) {
                ax.G.e eVar8 = sparseArray.get(i6);
                if (eVar8 != null) {
                    eVar.e0(ax.G.d.b.RIGHT, eVar8, ax.G.d.b.LEFT, ((ViewGroup.MarginLayoutParams) bVar).rightMargin, i9);
                }
            } else if (i7 != -1 && (eVar3 = sparseArray.get(i7)) != null) {
                ax.G.d.b bVar3 = ax.G.d.b.RIGHT;
                eVar.e0(bVar3, eVar3, bVar3, ((ViewGroup.MarginLayoutParams) bVar).rightMargin, i9);
            }
            int i11 = bVar.i;
            if (i11 != -1) {
                ax.G.e eVar9 = sparseArray.get(i11);
                if (eVar9 != null) {
                    ax.G.d.b bVar4 = ax.G.d.b.TOP;
                    eVar.e0(bVar4, eVar9, bVar4, ((ViewGroup.MarginLayoutParams) bVar).topMargin, bVar.x);
                }
            } else {
                int i12 = bVar.j;
                if (i12 != -1 && (eVar4 = sparseArray.get(i12)) != null) {
                    eVar.e0(ax.G.d.b.TOP, eVar4, ax.G.d.b.BOTTOM, ((ViewGroup.MarginLayoutParams) bVar).topMargin, bVar.x);
                }
            }
            int i13 = bVar.k;
            if (i13 != -1) {
                ax.G.e eVar10 = sparseArray.get(i13);
                if (eVar10 != null) {
                    eVar.e0(ax.G.d.b.BOTTOM, eVar10, ax.G.d.b.TOP, ((ViewGroup.MarginLayoutParams) bVar).bottomMargin, bVar.z);
                }
            } else {
                int i14 = bVar.l;
                if (i14 != -1 && (eVar5 = sparseArray.get(i14)) != null) {
                    ax.G.d.b bVar5 = ax.G.d.b.BOTTOM;
                    eVar.e0(bVar5, eVar5, bVar5, ((ViewGroup.MarginLayoutParams) bVar).bottomMargin, bVar.z);
                }
            }
            int i15 = bVar.m;
            if (i15 != -1) {
                z(eVar, bVar, sparseArray, i15, ax.G.d.b.BASELINE);
            } else {
                int i16 = bVar.n;
                if (i16 != -1) {
                    z(eVar, bVar, sparseArray, i16, ax.G.d.b.TOP);
                } else {
                    int i17 = bVar.o;
                    if (i17 != -1) {
                        z(eVar, bVar, sparseArray, i17, ax.G.d.b.BOTTOM);
                    }
                }
            }
            if (f2 >= 0.0f) {
                eVar.M0(f2);
            }
            float f3 = bVar.H;
            if (f3 >= 0.0f) {
                eVar.d1(f3);
            }
        }
        if (z && ((i = bVar.X) != -1 || bVar.Y != -1)) {
            eVar.b1(i, bVar.Y);
        }
        if (bVar.e0) {
            eVar.P0(ax.G.e.b.FIXED);
            eVar.k1(((ViewGroup.MarginLayoutParams) bVar).width);
            if (((ViewGroup.MarginLayoutParams) bVar).width == -2) {
                eVar.P0(ax.G.e.b.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) bVar).width == -1) {
            if (bVar.a0) {
                eVar.P0(ax.G.e.b.MATCH_CONSTRAINT);
            } else {
                eVar.P0(ax.G.e.b.MATCH_PARENT);
            }
            eVar.o(ax.G.d.b.LEFT).g = ((ViewGroup.MarginLayoutParams) bVar).leftMargin;
            eVar.o(ax.G.d.b.RIGHT).g = ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
        } else {
            eVar.P0(ax.G.e.b.MATCH_CONSTRAINT);
            eVar.k1(0);
        }
        if (bVar.f0) {
            eVar.g1(ax.G.e.b.FIXED);
            eVar.L0(((ViewGroup.MarginLayoutParams) bVar).height);
            if (((ViewGroup.MarginLayoutParams) bVar).height == -2) {
                eVar.g1(ax.G.e.b.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) bVar).height == -1) {
            if (bVar.b0) {
                eVar.g1(ax.G.e.b.MATCH_CONSTRAINT);
            } else {
                eVar.g1(ax.G.e.b.MATCH_PARENT);
            }
            eVar.o(ax.G.d.b.TOP).g = ((ViewGroup.MarginLayoutParams) bVar).topMargin;
            eVar.o(ax.G.d.b.BOTTOM).g = ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
        } else {
            eVar.g1(ax.G.e.b.MATCH_CONSTRAINT);
            eVar.L0(0);
        }
        eVar.D0(bVar.I);
        eVar.R0(bVar.L);
        eVar.i1(bVar.M);
        eVar.N0(bVar.N);
        eVar.e1(bVar.O);
        eVar.l1(bVar.d0);
        eVar.Q0(bVar.P, bVar.R, bVar.T, bVar.V);
        eVar.h1(bVar.Q, bVar.S, bVar.U, bVar.W);
    }

    @Override // android.view.View
    public void forceLayout() {
        s();
        super.forceLayout();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public b generateDefaultLayoutParams() {
        return new b(-2, -2);
    }

    public int getMaxHeight() {
        return this.m0;
    }

    public int getMaxWidth() {
        return this.l0;
    }

    public int getMinHeight() {
        return this.k0;
    }

    public int getMinWidth() {
        return this.j0;
    }

    public int getOptimizationLevel() {
        return this.i0.J1();
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        if (this.i0.o == null) {
            int id2 = getId();
            if (id2 != -1) {
                this.i0.o = getContext().getResources().getResourceEntryName(id2);
            } else {
                this.i0.o = "parent";
            }
        }
        if (this.i0.t() == null) {
            ax.G.f fVar = this.i0;
            fVar.C0(fVar.o);
            Log.v("ConstraintLayout", " setDebugName " + this.i0.t());
        }
        for (ax.G.e eVar : this.i0.r1()) {
            View view = (View) eVar.s();
            if (view != null) {
                if (eVar.o == null && (id = view.getId()) != -1) {
                    eVar.o = getContext().getResources().getResourceEntryName(id);
                }
                if (eVar.t() == null) {
                    eVar.C0(eVar.o);
                    Log.v("ConstraintLayout", " setDebugName " + eVar.t());
                }
            }
        }
        this.i0.O(sb);
        return sb.toString();
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public b generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    public Object i(int i, Object obj) {
        if (i != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> map = this.s0;
        if (map == null || !map.containsKey(str)) {
            return null;
        }
        return this.s0.get(str);
    }

    public View k(int i) {
        return this.q.get(i);
    }

    public final ax.G.e l(View view) {
        if (view == this) {
            return this.i0;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof b) {
            return ((b) view.getLayoutParams()).v0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof b) {
            return ((b) view.getLayoutParams()).v0;
        }
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View content;
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            b bVar = (b) childAt.getLayoutParams();
            ax.G.e eVar = bVar.v0;
            if ((childAt.getVisibility() != 8 || bVar.h0 || bVar.i0 || bVar.k0 || zIsInEditMode) && !bVar.j0) {
                int iX = eVar.X();
                int iY = eVar.Y();
                int iW = eVar.W() + iX;
                int iX2 = eVar.x() + iY;
                childAt.layout(iX, iY, iW, iX2);
                if ((childAt instanceof h) && (content = ((h) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(iX, iY, iW, iX2);
                }
            }
        }
        int size = this.h0.size();
        if (size > 0) {
            for (int i6 = 0; i6 < size; i6++) {
                this.h0.get(i6).o(this);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        if (this.B0 == i) {
            int i3 = this.C0;
        }
        if (!this.n0) {
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                if (getChildAt(i4).isLayoutRequested()) {
                    this.n0 = true;
                    break;
                }
            }
        }
        this.B0 = i;
        this.C0 = i2;
        this.i0.Y1(r());
        if (this.n0) {
            this.n0 = false;
            if (A()) {
                this.i0.a2();
            }
        }
        v(this.i0, this.o0, i, i2);
        u(i, i2, this.i0.W(), this.i0.x(), this.i0.Q1(), this.i0.O1());
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        ax.G.e eVarL = l(view);
        if ((view instanceof g) && !(eVarL instanceof ax.G.h)) {
            b bVar = (b) view.getLayoutParams();
            ax.G.h hVar = new ax.G.h();
            bVar.v0 = hVar;
            bVar.h0 = true;
            hVar.A1(bVar.Z);
        }
        if (view instanceof androidx.constraintlayout.widget.c) {
            androidx.constraintlayout.widget.c cVar = (androidx.constraintlayout.widget.c) view;
            cVar.s();
            ((b) view.getLayoutParams()).i0 = true;
            if (!this.h0.contains(cVar)) {
                this.h0.add(cVar);
            }
        }
        this.q.put(view.getId(), view);
        this.n0 = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.q.remove(view.getId());
        this.i0.t1(l(view));
        this.h0.remove(view);
        this.n0 = true;
    }

    protected boolean r() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        s();
        super.requestLayout();
    }

    public void setConstraintSet(e eVar) {
        this.p0 = eVar;
    }

    @Override // android.view.View
    public void setId(int i) {
        this.q.remove(getId());
        super.setId(i);
        this.q.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i == this.m0) {
            return;
        }
        this.m0 = i;
        requestLayout();
    }

    public void setMaxWidth(int i) {
        if (i == this.l0) {
            return;
        }
        this.l0 = i;
        requestLayout();
    }

    public void setMinHeight(int i) {
        if (i == this.k0) {
            return;
        }
        this.k0 = i;
        requestLayout();
    }

    public void setMinWidth(int i) {
        if (i == this.j0) {
            return;
        }
        this.j0 = i;
        requestLayout();
    }

    public void setOnConstraintsChanged(ax.K.a aVar) {
        d dVar = this.q0;
        if (dVar != null) {
            dVar.c(aVar);
        }
    }

    public void setOptimizationLevel(int i) {
        this.o0 = i;
        this.i0.W1(i);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    protected void t(int i) {
        this.q0 = new d(getContext(), this, i);
    }

    protected void u(int i, int i2, int i3, int i4, boolean z, boolean z2) {
        c cVar = this.A0;
        int i5 = cVar.e;
        int iResolveSizeAndState = View.resolveSizeAndState(i3 + cVar.d, i, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(i4 + i5, i2, 0) & 16777215;
        int iMin = Math.min(this.l0, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.m0, iResolveSizeAndState2);
        if (z) {
            iMin |= Http2Connection.OKHTTP_CLIENT_WINDOW_SIZE;
        }
        if (z2) {
            iMin2 |= Http2Connection.OKHTTP_CLIENT_WINDOW_SIZE;
        }
        setMeasuredDimension(iMin, iMin2);
        this.t0 = iMin;
        this.u0 = iMin2;
    }

    protected void v(ax.G.f fVar, int i, int i2, int i3) {
        int iMax;
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        int iMax2 = Math.max(0, getPaddingTop());
        int iMax3 = Math.max(0, getPaddingBottom());
        int i4 = iMax2 + iMax3;
        int paddingWidth = getPaddingWidth();
        this.A0.c(i2, i3, iMax2, iMax3, paddingWidth, i4);
        int iMax4 = Math.max(0, getPaddingStart());
        int iMax5 = Math.max(0, getPaddingEnd());
        if (iMax4 > 0 || iMax5 > 0) {
            iMax = r() ? iMax5 : iMax4;
        } else {
            iMax = Math.max(0, getPaddingLeft());
        }
        int i5 = size - paddingWidth;
        int i6 = size2 - i4;
        y(fVar, mode, i5, mode2, i6);
        fVar.R1(i, mode, i5, mode2, i6, this.t0, this.u0, iMax, iMax2);
    }

    public void x(int i, Object obj, Object obj2) {
        if (i == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.s0 == null) {
                this.s0 = new HashMap<>();
            }
            String strSubstring = (String) obj;
            int iIndexOf = strSubstring.indexOf("/");
            if (iIndexOf != -1) {
                strSubstring = strSubstring.substring(iIndexOf + 1);
            }
            Integer num = (Integer) obj2;
            num.intValue();
            this.s0.put(strSubstring, num);
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x003e A[PHI: r2
      0x003e: PHI (r2v4 ax.G.e$b) = (r2v3 ax.G.e$b), (r2v0 ax.G.e$b) binds: [B:21:0x004a, B:17:0x003c] A[DONT_GENERATE, DONT_INLINE]] */
    protected void y(ax.G.f fVar, int i, int i2, int i3, int i4) {
        ax.G.e.b bVar;
        c cVar = this.A0;
        int i5 = cVar.e;
        int i6 = cVar.d;
        ax.G.e.b bVar2 = ax.G.e.b.FIXED;
        int childCount = getChildCount();
        if (i == Integer.MIN_VALUE) {
            bVar = ax.G.e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i2 = Math.max(0, this.j0);
            }
        } else if (i == 0) {
            bVar = ax.G.e.b.WRAP_CONTENT;
            i2 = childCount == 0 ? Math.max(0, this.j0) : 0;
        } else if (i != 1073741824) {
            bVar = bVar2;
        } else {
            i2 = Math.min(this.l0 - i6, i2);
            bVar = bVar2;
        }
        if (i3 == Integer.MIN_VALUE) {
            bVar2 = ax.G.e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i4 = Math.max(0, this.k0);
            }
        } else if (i3 == 0) {
            bVar2 = ax.G.e.b.WRAP_CONTENT;
            if (childCount == 0) {
                i4 = Math.max(0, this.k0);
            } else {
                i4 = 0;
            }
        } else if (i3 != 1073741824) {
            i4 = 0;
        } else {
            i4 = Math.min(this.m0 - i5, i4);
        }
        if (i2 != fVar.W() || i4 != fVar.x()) {
            fVar.N1();
        }
        fVar.m1(0);
        fVar.n1(0);
        fVar.X0(this.l0 - i6);
        fVar.W0(this.m0 - i5);
        fVar.a1(0);
        fVar.Z0(0);
        fVar.P0(bVar);
        fVar.k1(i2);
        fVar.g1(bVar2);
        fVar.L0(i4);
        fVar.a1(this.j0 - i6);
        fVar.Z0(this.k0 - i5);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new b(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.q = new SparseArray<>();
        this.h0 = new ArrayList<>(4);
        this.i0 = new ax.G.f();
        this.j0 = 0;
        this.k0 = 0;
        this.l0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.m0 = SubsamplingScaleImageView.TILE_SIZE_AUTO;
        this.n0 = true;
        this.o0 = 257;
        this.p0 = null;
        this.q0 = null;
        this.r0 = -1;
        this.s0 = new HashMap<>();
        this.t0 = -1;
        this.u0 = -1;
        this.v0 = -1;
        this.w0 = -1;
        this.x0 = 0;
        this.y0 = 0;
        this.z0 = new SparseArray<>();
        this.A0 = new c(this);
        this.B0 = 0;
        this.C0 = 0;
        q(attributeSet, i, 0);
    }

    public static class b extends ViewGroup.MarginLayoutParams {
        public int A;
        public int B;
        public int C;
        public int D;
        boolean E;
        boolean F;
        public float G;
        public float H;
        public String I;
        float J;
        int K;
        public float L;
        public float M;
        public int N;
        public int O;
        public int P;
        public int Q;
        public int R;
        public int S;
        public int T;
        public int U;
        public float V;
        public float W;
        public int X;
        public int Y;
        public int Z;
        public int a;
        public boolean a0;
        public int b;
        public boolean b0;
        public float c;
        public String c0;
        public boolean d;
        public int d0;
        public int e;
        boolean e0;
        public int f;
        boolean f0;
        public int g;
        boolean g0;
        public int h;
        boolean h0;
        public int i;
        boolean i0;
        public int j;
        boolean j0;
        public int k;
        boolean k0;
        public int l;
        int l0;
        public int m;
        int m0;
        public int n;
        int n0;
        public int o;
        int o0;
        public int p;
        int p0;
        public int q;
        int q0;
        public float r;
        float r0;
        public int s;
        int s0;
        public int t;
        int t0;
        public int u;
        float u0;
        public int v;
        ax.G.e v0;
        public int w;
        public boolean w0;
        public int x;
        public int y;
        public int z;

        private static class a {
            public static final SparseIntArray a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                a = sparseIntArray;
                sparseIntArray.append(ax.K.c.R2, 64);
                sparseIntArray.append(ax.K.c.u2, 65);
                sparseIntArray.append(ax.K.c.D2, 8);
                sparseIntArray.append(ax.K.c.E2, 9);
                sparseIntArray.append(ax.K.c.G2, 10);
                sparseIntArray.append(ax.K.c.H2, 11);
                sparseIntArray.append(ax.K.c.N2, 12);
                sparseIntArray.append(ax.K.c.M2, 13);
                sparseIntArray.append(ax.K.c.k2, 14);
                sparseIntArray.append(ax.K.c.j2, 15);
                sparseIntArray.append(ax.K.c.f2, 16);
                sparseIntArray.append(ax.K.c.h2, 52);
                sparseIntArray.append(ax.K.c.g2, 53);
                sparseIntArray.append(ax.K.c.l2, 2);
                sparseIntArray.append(ax.K.c.n2, 3);
                sparseIntArray.append(ax.K.c.m2, 4);
                sparseIntArray.append(ax.K.c.W2, 49);
                sparseIntArray.append(ax.K.c.X2, 50);
                sparseIntArray.append(ax.K.c.r2, 5);
                sparseIntArray.append(ax.K.c.s2, 6);
                sparseIntArray.append(ax.K.c.t2, 7);
                sparseIntArray.append(ax.K.c.a2, 67);
                sparseIntArray.append(ax.K.c.o1, 1);
                sparseIntArray.append(ax.K.c.I2, 17);
                sparseIntArray.append(ax.K.c.J2, 18);
                sparseIntArray.append(ax.K.c.q2, 19);
                sparseIntArray.append(ax.K.c.p2, 20);
                sparseIntArray.append(ax.K.c.b3, 21);
                sparseIntArray.append(ax.K.c.e3, 22);
                sparseIntArray.append(ax.K.c.c3, 23);
                sparseIntArray.append(ax.K.c.Z2, 24);
                sparseIntArray.append(ax.K.c.d3, 25);
                sparseIntArray.append(ax.K.c.a3, 26);
                sparseIntArray.append(ax.K.c.Y2, 55);
                sparseIntArray.append(ax.K.c.f3, 54);
                sparseIntArray.append(ax.K.c.z2, 29);
                sparseIntArray.append(ax.K.c.O2, 30);
                sparseIntArray.append(ax.K.c.o2, 44);
                sparseIntArray.append(ax.K.c.B2, 45);
                sparseIntArray.append(ax.K.c.Q2, 46);
                sparseIntArray.append(ax.K.c.A2, 47);
                sparseIntArray.append(ax.K.c.P2, 48);
                sparseIntArray.append(ax.K.c.d2, 27);
                sparseIntArray.append(ax.K.c.c2, 28);
                sparseIntArray.append(ax.K.c.S2, 31);
                sparseIntArray.append(ax.K.c.v2, 32);
                sparseIntArray.append(ax.K.c.U2, 33);
                sparseIntArray.append(ax.K.c.T2, 34);
                sparseIntArray.append(ax.K.c.V2, 35);
                sparseIntArray.append(ax.K.c.x2, 36);
                sparseIntArray.append(ax.K.c.w2, 37);
                sparseIntArray.append(ax.K.c.y2, 38);
                sparseIntArray.append(ax.K.c.C2, 39);
                sparseIntArray.append(ax.K.c.L2, 40);
                sparseIntArray.append(ax.K.c.F2, 41);
                sparseIntArray.append(ax.K.c.i2, 42);
                sparseIntArray.append(ax.K.c.e2, 43);
                sparseIntArray.append(ax.K.c.K2, 51);
                sparseIntArray.append(ax.K.c.h3, 66);
            }
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.a = -1;
            this.b = -1;
            this.c = -1.0f;
            this.d = true;
            this.e = -1;
            this.f = -1;
            this.g = -1;
            this.h = -1;
            this.i = -1;
            this.j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.a0 = false;
            this.b0 = false;
            this.c0 = null;
            this.d0 = 0;
            this.e0 = true;
            this.f0 = true;
            this.g0 = false;
            this.h0 = false;
            this.i0 = false;
            this.j0 = false;
            this.k0 = false;
            this.l0 = -1;
            this.m0 = -1;
            this.n0 = -1;
            this.o0 = -1;
            this.p0 = Integer.MIN_VALUE;
            this.q0 = Integer.MIN_VALUE;
            this.r0 = 0.5f;
            this.v0 = new ax.G.e();
            this.w0 = false;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ax.K.c.n1);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                int i2 = a.a.get(index);
                switch (i2) {
                    case 1:
                        this.Z = typedArrayObtainStyledAttributes.getInt(index, this.Z);
                        break;
                    case 2:
                        int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, this.p);
                        this.p = resourceId;
                        if (resourceId == -1) {
                            this.p = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 3:
                        this.q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.q);
                        break;
                    case 4:
                        float f = typedArrayObtainStyledAttributes.getFloat(index, this.r) % 360.0f;
                        this.r = f;
                        if (f < 0.0f) {
                            this.r = (360.0f - f) % 360.0f;
                        }
                        break;
                    case 5:
                        this.a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.a);
                        break;
                    case 6:
                        this.b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.b);
                        break;
                    case 7:
                        this.c = typedArrayObtainStyledAttributes.getFloat(index, this.c);
                        break;
                    case 8:
                        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, this.e);
                        this.e = resourceId2;
                        if (resourceId2 == -1) {
                            this.e = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 9:
                        int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, this.f);
                        this.f = resourceId3;
                        if (resourceId3 == -1) {
                            this.f = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 10:
                        int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, this.g);
                        this.g = resourceId4;
                        if (resourceId4 == -1) {
                            this.g = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 11:
                        int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, this.h);
                        this.h = resourceId5;
                        if (resourceId5 == -1) {
                            this.h = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 12:
                        int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, this.i);
                        this.i = resourceId6;
                        if (resourceId6 == -1) {
                            this.i = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 13:
                        int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, this.j);
                        this.j = resourceId7;
                        if (resourceId7 == -1) {
                            this.j = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 14:
                        int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, this.k);
                        this.k = resourceId8;
                        if (resourceId8 == -1) {
                            this.k = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 15:
                        int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, this.l);
                        this.l = resourceId9;
                        if (resourceId9 == -1) {
                            this.l = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 16:
                        int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, this.m);
                        this.m = resourceId10;
                        if (resourceId10 == -1) {
                            this.m = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 17:
                        int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, this.s);
                        this.s = resourceId11;
                        if (resourceId11 == -1) {
                            this.s = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 18:
                        int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, this.t);
                        this.t = resourceId12;
                        if (resourceId12 == -1) {
                            this.t = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 19:
                        int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, this.u);
                        this.u = resourceId13;
                        if (resourceId13 == -1) {
                            this.u = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 20:
                        int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, this.v);
                        this.v = resourceId14;
                        if (resourceId14 == -1) {
                            this.v = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case C1452Re.zzm /* 21 */:
                        this.w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.w);
                        break;
                    case 22:
                        this.x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.x);
                        break;
                    case 23:
                        this.y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.y);
                        break;
                    case 24:
                        this.z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.z);
                        break;
                    case 25:
                        this.A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.A);
                        break;
                    case 26:
                        this.B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.B);
                        break;
                    case 27:
                        this.a0 = typedArrayObtainStyledAttributes.getBoolean(index, this.a0);
                        break;
                    case 28:
                        this.b0 = typedArrayObtainStyledAttributes.getBoolean(index, this.b0);
                        break;
                    case 29:
                        this.G = typedArrayObtainStyledAttributes.getFloat(index, this.G);
                        break;
                    case 30:
                        this.H = typedArrayObtainStyledAttributes.getFloat(index, this.H);
                        break;
                    case 31:
                        int i3 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.P = i3;
                        if (i3 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        }
                        break;
                    case 32:
                        int i4 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.Q = i4;
                        if (i4 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        }
                        break;
                    case 33:
                        try {
                            this.R = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.R);
                        } catch (Exception unused) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.R) == -2) {
                                this.R = -2;
                            }
                        }
                        break;
                    case 34:
                        try {
                            this.T = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.T);
                        } catch (Exception unused2) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.T) == -2) {
                                this.T = -2;
                            }
                        }
                        break;
                    case 35:
                        this.V = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.V));
                        this.P = 2;
                        break;
                    case 36:
                        try {
                            this.S = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.S);
                        } catch (Exception unused3) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.S) == -2) {
                                this.S = -2;
                            }
                        }
                        break;
                    case 37:
                        try {
                            this.U = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.U);
                        } catch (Exception unused4) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.U) == -2) {
                                this.U = -2;
                            }
                        }
                        break;
                    case 38:
                        this.W = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.W));
                        this.Q = 2;
                        break;
                    default:
                        switch (i2) {
                            case 44:
                                e.q(this, typedArrayObtainStyledAttributes.getString(index));
                                break;
                            case 45:
                                this.L = typedArrayObtainStyledAttributes.getFloat(index, this.L);
                                break;
                            case 46:
                                this.M = typedArrayObtainStyledAttributes.getFloat(index, this.M);
                                break;
                            case 47:
                                this.N = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.O = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 49:
                                this.X = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.X);
                                break;
                            case 50:
                                this.Y = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.Y);
                                break;
                            case 51:
                                this.c0 = typedArrayObtainStyledAttributes.getString(index);
                                break;
                            case 52:
                                int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, this.n);
                                this.n = resourceId15;
                                if (resourceId15 == -1) {
                                    this.n = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case 53:
                                int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, this.o);
                                this.o = resourceId16;
                                if (resourceId16 == -1) {
                                    this.o = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case 54:
                                this.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.D);
                                break;
                            case 55:
                                this.C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.C);
                                break;
                            default:
                                switch (i2) {
                                    case WebSocketProtocol.B0_FLAG_RSV1 /* 64 */:
                                        e.o(this, typedArrayObtainStyledAttributes, index, 0);
                                        this.E = true;
                                        break;
                                    case 65:
                                        e.o(this, typedArrayObtainStyledAttributes, index, 1);
                                        this.F = true;
                                        break;
                                    case 66:
                                        this.d0 = typedArrayObtainStyledAttributes.getInt(index, this.d0);
                                        break;
                                    case 67:
                                        this.d = typedArrayObtainStyledAttributes.getBoolean(index, this.d);
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            a();
        }

        public void a() {
            this.h0 = false;
            this.e0 = true;
            this.f0 = true;
            int i = ((ViewGroup.MarginLayoutParams) this).width;
            if (i == -2 && this.a0) {
                this.e0 = false;
                if (this.P == 0) {
                    this.P = 1;
                }
            }
            int i2 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i2 == -2 && this.b0) {
                this.f0 = false;
                if (this.Q == 0) {
                    this.Q = 1;
                }
            }
            if (i == 0 || i == -1) {
                this.e0 = false;
                if (i == 0 && this.P == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.a0 = true;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.f0 = false;
                if (i2 == 0 && this.Q == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.b0 = true;
                }
            }
            if (this.c == -1.0f && this.a == -1 && this.b == -1) {
                return;
            }
            this.h0 = true;
            this.e0 = true;
            this.f0 = true;
            if (!(this.v0 instanceof ax.G.h)) {
                this.v0 = new ax.G.h();
            }
            ((ax.G.h) this.v0).A1(this.Z);
        }

        /* JADX WARN: Code duplicated, block: B:17:0x004a  */
        /* JADX WARN: Code duplicated, block: B:20:0x0051  */
        /* JADX WARN: Code duplicated, block: B:23:0x0058  */
        /* JADX WARN: Code duplicated, block: B:26:0x005e  */
        /* JADX WARN: Code duplicated, block: B:29:0x0064  */
        /* JADX WARN: Code duplicated, block: B:38:0x007a  */
        /* JADX WARN: Code duplicated, block: B:39:0x0082 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:40:0x0084  */
        /* JADX WARN: Code duplicated, block: B:41:0x008b A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:42:0x008d  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        @TargetApi(17)
        public void resolveLayoutDirection(int i) {
            int i2;
            int i3;
            int i4;
            int i5;
            int i6 = ((ViewGroup.MarginLayoutParams) this).leftMargin;
            int i7 = ((ViewGroup.MarginLayoutParams) this).rightMargin;
            super.resolveLayoutDirection(i);
            boolean z = false;
            boolean z2 = 1 == getLayoutDirection();
            this.n0 = -1;
            this.o0 = -1;
            this.l0 = -1;
            this.m0 = -1;
            this.p0 = this.w;
            this.q0 = this.y;
            float f = this.G;
            this.r0 = f;
            int i8 = this.a;
            this.s0 = i8;
            int i9 = this.b;
            this.t0 = i9;
            float f2 = this.c;
            this.u0 = f2;
            if (z2) {
                int i10 = this.s;
                if (i10 != -1) {
                    this.n0 = i10;
                } else {
                    int i11 = this.t;
                    if (i11 != -1) {
                        this.o0 = i11;
                    } else {
                        i2 = this.u;
                        if (i2 != -1) {
                            this.m0 = i2;
                            z = true;
                        }
                        i3 = this.v;
                        if (i3 != -1) {
                            this.l0 = i3;
                            z = true;
                        }
                        i4 = this.A;
                        if (i4 != Integer.MIN_VALUE) {
                            this.q0 = i4;
                        }
                        i5 = this.B;
                        if (i5 != Integer.MIN_VALUE) {
                            this.p0 = i5;
                        }
                        if (z) {
                            this.r0 = 1.0f - f;
                        }
                        if (this.h0 && this.Z == 1 && this.d) {
                            if (f2 != -1.0f) {
                                this.u0 = 1.0f - f2;
                                this.s0 = -1;
                                this.t0 = -1;
                            } else if (i8 != -1) {
                                this.t0 = i8;
                                this.s0 = -1;
                                this.u0 = -1.0f;
                            } else if (i9 != -1) {
                                this.s0 = i9;
                                this.t0 = -1;
                                this.u0 = -1.0f;
                            }
                        }
                    }
                }
                z = true;
                i2 = this.u;
                if (i2 != -1) {
                    this.m0 = i2;
                    z = true;
                }
                i3 = this.v;
                if (i3 != -1) {
                    this.l0 = i3;
                    z = true;
                }
                i4 = this.A;
                if (i4 != Integer.MIN_VALUE) {
                    this.q0 = i4;
                }
                i5 = this.B;
                if (i5 != Integer.MIN_VALUE) {
                    this.p0 = i5;
                }
                if (z) {
                    this.r0 = 1.0f - f;
                }
                if (this.h0) {
                    if (f2 != -1.0f) {
                        this.u0 = 1.0f - f2;
                        this.s0 = -1;
                        this.t0 = -1;
                    } else if (i8 != -1) {
                        this.t0 = i8;
                        this.s0 = -1;
                        this.u0 = -1.0f;
                    } else if (i9 != -1) {
                        this.s0 = i9;
                        this.t0 = -1;
                        this.u0 = -1.0f;
                    }
                }
            } else {
                int i12 = this.s;
                if (i12 != -1) {
                    this.m0 = i12;
                }
                int i13 = this.t;
                if (i13 != -1) {
                    this.l0 = i13;
                }
                int i14 = this.u;
                if (i14 != -1) {
                    this.n0 = i14;
                }
                int i15 = this.v;
                if (i15 != -1) {
                    this.o0 = i15;
                }
                int i16 = this.A;
                if (i16 != Integer.MIN_VALUE) {
                    this.p0 = i16;
                }
                int i17 = this.B;
                if (i17 != Integer.MIN_VALUE) {
                    this.q0 = i17;
                }
            }
            if (this.u == -1 && this.v == -1 && this.t == -1 && this.s == -1) {
                int i18 = this.g;
                if (i18 != -1) {
                    this.n0 = i18;
                    if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i7 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).rightMargin = i7;
                    }
                } else {
                    int i19 = this.h;
                    if (i19 != -1) {
                        this.o0 = i19;
                        if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i7 > 0) {
                            ((ViewGroup.MarginLayoutParams) this).rightMargin = i7;
                        }
                    }
                }
                int i20 = this.e;
                if (i20 != -1) {
                    this.l0 = i20;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i6 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i6;
                    return;
                }
                int i21 = this.f;
                if (i21 != -1) {
                    this.m0 = i21;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i6 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i6;
                }
            }
        }

        public b(int i, int i2) {
            super(i, i2);
            this.a = -1;
            this.b = -1;
            this.c = -1.0f;
            this.d = true;
            this.e = -1;
            this.f = -1;
            this.g = -1;
            this.h = -1;
            this.i = -1;
            this.j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.a0 = false;
            this.b0 = false;
            this.c0 = null;
            this.d0 = 0;
            this.e0 = true;
            this.f0 = true;
            this.g0 = false;
            this.h0 = false;
            this.i0 = false;
            this.j0 = false;
            this.k0 = false;
            this.l0 = -1;
            this.m0 = -1;
            this.n0 = -1;
            this.o0 = -1;
            this.p0 = Integer.MIN_VALUE;
            this.q0 = Integer.MIN_VALUE;
            this.r0 = 0.5f;
            this.v0 = new ax.G.e();
            this.w0 = false;
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.a = -1;
            this.b = -1;
            this.c = -1.0f;
            this.d = true;
            this.e = -1;
            this.f = -1;
            this.g = -1;
            this.h = -1;
            this.i = -1;
            this.j = -1;
            this.k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = 0;
            this.r = 0.0f;
            this.s = -1;
            this.t = -1;
            this.u = -1;
            this.v = -1;
            this.w = Integer.MIN_VALUE;
            this.x = Integer.MIN_VALUE;
            this.y = Integer.MIN_VALUE;
            this.z = Integer.MIN_VALUE;
            this.A = Integer.MIN_VALUE;
            this.B = Integer.MIN_VALUE;
            this.C = Integer.MIN_VALUE;
            this.D = 0;
            this.E = true;
            this.F = true;
            this.G = 0.5f;
            this.H = 0.5f;
            this.I = null;
            this.J = 0.0f;
            this.K = 1;
            this.L = -1.0f;
            this.M = -1.0f;
            this.N = 0;
            this.O = 0;
            this.P = 0;
            this.Q = 0;
            this.R = 0;
            this.S = 0;
            this.T = 0;
            this.U = 0;
            this.V = 1.0f;
            this.W = 1.0f;
            this.X = -1;
            this.Y = -1;
            this.Z = -1;
            this.a0 = false;
            this.b0 = false;
            this.c0 = null;
            this.d0 = 0;
            this.e0 = true;
            this.f0 = true;
            this.g0 = false;
            this.h0 = false;
            this.i0 = false;
            this.j0 = false;
            this.k0 = false;
            this.l0 = -1;
            this.m0 = -1;
            this.n0 = -1;
            this.o0 = -1;
            this.p0 = Integer.MIN_VALUE;
            this.q0 = Integer.MIN_VALUE;
            this.r0 = 0.5f;
            this.v0 = new ax.G.e();
            this.w0 = false;
        }
    }
}
