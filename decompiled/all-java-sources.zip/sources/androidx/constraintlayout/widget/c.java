package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import ax.G.i;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends View {
    protected int h0;
    protected Context i0;
    protected i j0;
    protected boolean k0;
    protected String l0;
    protected String m0;
    private View[] n0;
    protected HashMap<Integer, String> o0;
    protected int[] q;

    public c(Context context) {
        super(context);
        this.q = new int[32];
        this.k0 = false;
        this.n0 = null;
        this.o0 = new HashMap<>();
        this.i0 = context;
        m(null);
    }

    private void d(String str) {
        if (str == null || str.length() == 0 || this.i0 == null) {
            return;
        }
        String strTrim = str.trim();
        if (getParent() instanceof ConstraintLayout) {
        }
        int iK = k(strTrim);
        if (iK != 0) {
            this.o0.put(Integer.valueOf(iK), strTrim);
            e(iK);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + strTrim + "\"");
    }

    private void e(int i) {
        if (i == getId()) {
            return;
        }
        int i2 = this.h0 + 1;
        int[] iArr = this.q;
        if (i2 > iArr.length) {
            this.q = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.q;
        int i3 = this.h0;
        iArr2[i3] = i;
        this.h0 = i3 + 1;
    }

    private void f(String str) {
        if (str == null || str.length() == 0 || this.i0 == null) {
            return;
        }
        String strTrim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.b) && strTrim.equals(((ConstraintLayout.b) layoutParams).c0)) {
                if (childAt.getId() == -1) {
                    Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    e(childAt.getId());
                }
            }
        }
    }

    private int j(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String resourceEntryName;
        if (str == null || constraintLayout == null || (resources = this.i0.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = constraintLayout.getChildAt(i);
            if (childAt.getId() != -1) {
                try {
                    resourceEntryName = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    resourceEntryName = null;
                }
                if (str.equals(resourceEntryName)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    private int k(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int iJ = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object objI = constraintLayout.i(0, str);
            if (objI instanceof Integer) {
                iJ = ((Integer) objI).intValue();
            }
        }
        if (iJ == 0 && constraintLayout != null) {
            iJ = j(constraintLayout, str);
        }
        if (iJ == 0) {
            try {
                iJ = ax.K.b.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        return iJ == 0 ? this.i0.getResources().getIdentifier(str, "id", this.i0.getPackageName()) : iJ;
    }

    protected void g() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        h((ConstraintLayout) parent);
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.q, this.h0);
    }

    protected void h(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i = 0; i < this.h0; i++) {
            View viewK = constraintLayout.k(this.q[i]);
            if (viewK != null) {
                viewK.setVisibility(visibility);
                if (elevation > 0.0f) {
                    viewK.setTranslationZ(viewK.getTranslationZ() + elevation);
                }
            }
        }
    }

    protected void i(ConstraintLayout constraintLayout) {
    }

    protected View[] l(ConstraintLayout constraintLayout) {
        View[] viewArr = this.n0;
        if (viewArr == null || viewArr.length != this.h0) {
            this.n0 = new View[this.h0];
        }
        for (int i = 0; i < this.h0; i++) {
            this.n0[i] = constraintLayout.k(this.q[i]);
        }
        return this.n0;
    }

    protected void m(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, ax.K.c.n1);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == ax.K.c.G1) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.l0 = string;
                    setIds(string);
                } else if (index == ax.K.c.H1) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.m0 = string2;
                    setReferenceTags(string2);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void o(ConstraintLayout constraintLayout) {
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.l0;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.m0;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        if (this.k0) {
            super.onMeasure(i, i2);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void p(ConstraintLayout constraintLayout) {
    }

    public void q(ConstraintLayout constraintLayout) {
    }

    public void r(ConstraintLayout constraintLayout) {
        String str;
        int iJ;
        if (isInEditMode()) {
            setIds(this.l0);
        }
        i iVar = this.j0;
        if (iVar == null) {
            return;
        }
        iVar.a();
        for (int i = 0; i < this.h0; i++) {
            int i2 = this.q[i];
            View viewK = constraintLayout.k(i2);
            if (viewK == null && (iJ = j(constraintLayout, (str = this.o0.get(Integer.valueOf(i2))))) != 0) {
                this.q[i] = iJ;
                this.o0.put(Integer.valueOf(iJ), str);
                viewK = constraintLayout.k(iJ);
            }
            if (viewK != null) {
                this.j0.c(constraintLayout.l(viewK));
            }
        }
        this.j0.b(constraintLayout.i0);
    }

    public void s() {
        if (this.j0 == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b) {
            ((ConstraintLayout.b) layoutParams).v0 = (ax.G.e) this.j0;
        }
    }

    protected void setIds(String str) {
        this.l0 = str;
        if (str == null) {
            return;
        }
        int i = 0;
        this.h0 = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                d(str.substring(i));
                return;
            } else {
                d(str.substring(i, iIndexOf));
                i = iIndexOf + 1;
            }
        }
    }

    protected void setReferenceTags(String str) {
        this.m0 = str;
        if (str == null) {
            return;
        }
        int i = 0;
        this.h0 = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i);
            if (iIndexOf == -1) {
                f(str.substring(i));
                return;
            } else {
                f(str.substring(i, iIndexOf));
                i = iIndexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.l0 = null;
        this.h0 = 0;
        for (int i : iArr) {
            e(i);
        }
    }

    @Override // android.view.View
    public void setTag(int i, Object obj) {
        super.setTag(i, obj);
        if (obj == null && this.l0 == null) {
            e(i);
        }
    }

    public c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.q = new int[32];
        this.k0 = false;
        this.n0 = null;
        this.o0 = new HashMap<>();
        this.i0 = context;
        m(attributeSet);
    }

    public void n(ax.G.e eVar, boolean z) {
    }
}
