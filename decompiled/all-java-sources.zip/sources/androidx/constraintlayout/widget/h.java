package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class h extends View {
    private View k0;
    private int l0;
    private int q;

    public void a(ConstraintLayout constraintLayout) {
        if (this.k0 == null) {
            return;
        }
        ConstraintLayout.b bVar = (ConstraintLayout.b) getLayoutParams();
        ConstraintLayout.b bVar2 = (ConstraintLayout.b) this.k0.getLayoutParams();
        bVar2.v0.j1(0);
        ax.H.e.b bVarA = bVar.v0.A();
        ax.H.e.b bVar3 = ax.H.e.b.FIXED;
        if (bVarA != bVar3) {
            bVar.v0.k1(bVar2.v0.W());
        }
        if (bVar.v0.T() != bVar3) {
            bVar.v0.L0(bVar2.v0.x());
        }
        bVar2.v0.j1(8);
    }

    public void b(ConstraintLayout constraintLayout) {
        if (this.q == -1 && !isInEditMode()) {
            setVisibility(this.l0);
        }
        View viewFindViewById = constraintLayout.findViewById(this.q);
        this.k0 = viewFindViewById;
        if (viewFindViewById != null) {
            ((ConstraintLayout.b) viewFindViewById.getLayoutParams()).j0 = true;
            this.k0.setVisibility(0);
            setVisibility(0);
        }
    }

    public View getContent() {
        return this.k0;
    }

    public int getEmptyVisibility() {
        return this.l0;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            canvas.drawRGB(223, 223, 223);
            Paint paint = new Paint();
            paint.setARGB(255, 210, 210, 210);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
            Rect rect = new Rect();
            canvas.getClipBounds(rect);
            paint.setTextSize(rect.height());
            int iHeight = rect.height();
            int iWidth = rect.width();
            paint.setTextAlign(Paint.Align.LEFT);
            paint.getTextBounds("?", 0, 1, rect);
            canvas.drawText("?", ((iWidth / 2.0f) - (rect.width() / 2.0f)) - rect.left, ((iHeight / 2.0f) + (rect.height() / 2.0f)) - rect.bottom, paint);
        }
    }

    public void setContentId(int i) {
        View viewFindViewById;
        if (this.q == i) {
            return;
        }
        View view = this.k0;
        if (view != null) {
            view.setVisibility(0);
            ((ConstraintLayout.b) this.k0.getLayoutParams()).j0 = false;
            this.k0 = null;
        }
        this.q = i;
        if (i == -1 || (viewFindViewById = ((View) getParent()).findViewById(i)) == null) {
            return;
        }
        viewFindViewById.setVisibility(8);
    }

    public void setEmptyVisibility(int i) {
        this.l0 = i;
    }
}
