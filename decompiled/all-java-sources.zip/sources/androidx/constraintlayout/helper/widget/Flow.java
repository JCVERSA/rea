package androidx.constraintlayout.helper.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import ax.H.g;
import ax.H.l;
import ax.L.c;
import ax.L.e;

/* JADX INFO: loaded from: classes.dex */
public class Flow extends e {
    private g u0;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // ax.L.e, androidx.constraintlayout.widget.c
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.u0 = new g();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, c.n1);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == c.o1) {
                    this.u0.D2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.p1) {
                    this.u0.I1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.z1) {
                    this.u0.N1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.A1) {
                    this.u0.K1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.q1) {
                    this.u0.L1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.r1) {
                    this.u0.O1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.s1) {
                    this.u0.M1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.t1) {
                    this.u0.J1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.Z1) {
                    this.u0.I2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.P1) {
                    this.u0.x2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.Y1) {
                    this.u0.H2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.J1) {
                    this.u0.r2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.R1) {
                    this.u0.z2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.L1) {
                    this.u0.t2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.T1) {
                    this.u0.B2(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == c.N1) {
                    this.u0.v2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.I1) {
                    this.u0.q2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.Q1) {
                    this.u0.y2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.K1) {
                    this.u0.s2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.S1) {
                    this.u0.A2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.W1) {
                    this.u0.F2(typedArrayObtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == c.M1) {
                    this.u0.u2(typedArrayObtainStyledAttributes.getInt(index, 2));
                } else if (index == c.V1) {
                    this.u0.E2(typedArrayObtainStyledAttributes.getInt(index, 2));
                } else if (index == c.O1) {
                    this.u0.w2(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.X1) {
                    this.u0.G2(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == c.U1) {
                    this.u0.C2(typedArrayObtainStyledAttributes.getInt(index, -1));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.m0 = this.u0;
        s();
    }

    @Override // androidx.constraintlayout.widget.c
    public void n(ax.H.e eVar, boolean z) {
        this.u0.t1(z);
    }

    @Override // androidx.constraintlayout.widget.c, android.view.View
    @SuppressLint({"WrongCall"})
    protected void onMeasure(int i, int i2) {
        t(this.u0, i, i2);
    }

    public void setFirstHorizontalBias(float f) {
        this.u0.q2(f);
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i) {
        this.u0.r2(i);
        requestLayout();
    }

    public void setFirstVerticalBias(float f) {
        this.u0.s2(f);
        requestLayout();
    }

    public void setFirstVerticalStyle(int i) {
        this.u0.t2(i);
        requestLayout();
    }

    public void setHorizontalAlign(int i) {
        this.u0.u2(i);
        requestLayout();
    }

    public void setHorizontalBias(float f) {
        this.u0.v2(f);
        requestLayout();
    }

    public void setHorizontalGap(int i) {
        this.u0.w2(i);
        requestLayout();
    }

    public void setHorizontalStyle(int i) {
        this.u0.x2(i);
        requestLayout();
    }

    public void setLastHorizontalBias(float f) {
        this.u0.y2(f);
        requestLayout();
    }

    public void setLastHorizontalStyle(int i) {
        this.u0.z2(i);
        requestLayout();
    }

    public void setLastVerticalBias(float f) {
        this.u0.A2(f);
        requestLayout();
    }

    public void setLastVerticalStyle(int i) {
        this.u0.B2(i);
        requestLayout();
    }

    public void setMaxElementsWrap(int i) {
        this.u0.C2(i);
        requestLayout();
    }

    public void setOrientation(int i) {
        this.u0.D2(i);
        requestLayout();
    }

    public void setPadding(int i) {
        this.u0.I1(i);
        requestLayout();
    }

    public void setPaddingBottom(int i) {
        this.u0.J1(i);
        requestLayout();
    }

    public void setPaddingLeft(int i) {
        this.u0.L1(i);
        requestLayout();
    }

    public void setPaddingRight(int i) {
        this.u0.M1(i);
        requestLayout();
    }

    public void setPaddingTop(int i) {
        this.u0.O1(i);
        requestLayout();
    }

    public void setVerticalAlign(int i) {
        this.u0.E2(i);
        requestLayout();
    }

    public void setVerticalBias(float f) {
        this.u0.F2(f);
        requestLayout();
    }

    public void setVerticalGap(int i) {
        this.u0.G2(i);
        requestLayout();
    }

    public void setVerticalStyle(int i) {
        this.u0.H2(i);
        requestLayout();
    }

    public void setWrapMode(int i) {
        this.u0.I2(i);
        requestLayout();
    }

    @Override // ax.L.e
    public void t(l lVar, int i, int i2) {
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        int size2 = View.MeasureSpec.getSize(i2);
        if (lVar == null) {
            setMeasuredDimension(0, 0);
        } else {
            lVar.C1(mode, size, mode2, size2);
            setMeasuredDimension(lVar.x1(), lVar.w1());
        }
    }
}
