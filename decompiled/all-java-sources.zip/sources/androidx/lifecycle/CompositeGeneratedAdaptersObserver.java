package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements f {
    private final b[] q;

    public CompositeGeneratedAdaptersObserver(b[] bVarArr) {
        ax.p335uc.l.f(bVarArr, "generatedAdapters");
        this.q = bVarArr;
    }

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        ax.p335uc.l.f(hVar, "source");
        ax.p335uc.l.f(aVar, "event");
        ax.G0.k kVar = new ax.G0.k();
        for (b bVar : this.q) {
            bVar.a(hVar, aVar, false, kVar);
        }
        for (b bVar2 : this.q) {
            bVar2.a(hVar, aVar, true, kVar);
        }
    }
}
