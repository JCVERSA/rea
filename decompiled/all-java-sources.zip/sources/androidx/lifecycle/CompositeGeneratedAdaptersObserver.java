package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements f {
    private final b[] q;

    public CompositeGeneratedAdaptersObserver(b[] bVarArr) {
        ax.p138jb.l.f(bVarArr, "generatedAdapters");
        this.q = bVarArr;
    }

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        ax.F0.j jVar = new ax.F0.j();
        for (b bVar : this.q) {
            bVar.a(gVar, aVar, false, jVar);
        }
        for (b bVar2 : this.q) {
            bVar2.a(gVar, aVar, true, jVar);
        }
    }
}
