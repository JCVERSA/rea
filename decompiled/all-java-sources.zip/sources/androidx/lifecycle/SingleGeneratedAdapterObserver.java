package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements f {
    private final b q;

    public SingleGeneratedAdapterObserver(b bVar) {
        ax.p335uc.l.f(bVar, "generatedAdapter");
        this.q = bVar;
    }

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        ax.p335uc.l.f(hVar, "source");
        ax.p335uc.l.f(aVar, "event");
        this.q.a(hVar, aVar, false, null);
        this.q.a(hVar, aVar, true, null);
    }
}
