package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements f {
    private final b q;

    public SingleGeneratedAdapterObserver(b bVar) {
        ax.p138jb.l.f(bVar, "generatedAdapter");
        this.q = bVar;
    }

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        this.q.a(gVar, aVar, false, null);
        this.q.a(gVar, aVar, true, null);
    }
}
