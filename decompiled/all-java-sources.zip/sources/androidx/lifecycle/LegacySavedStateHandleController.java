package androidx.lifecycle;

import ax.F0.t;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class LegacySavedStateHandleController {
    public static final LegacySavedStateHandleController a = new LegacySavedStateHandleController();

    public static final class a implements androidx.savedstate.a.InterfaceC0044a {
        @Override // androidx.savedstate.a.InterfaceC0044a
        public void a(ax.p016b1.d dVar) {
            ax.p138jb.l.f(dVar, "owner");
            if (!(dVar instanceof t)) {
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner".toString());
            }
            q qVarJ = ((t) dVar).J();
            androidx.savedstate.a aVarR = dVar.R();
            Iterator<String> it = qVarJ.c().iterator();
            while (it.hasNext()) {
                o oVarB = qVarJ.b(it.next());
                ax.p138jb.l.c(oVarB);
                LegacySavedStateHandleController.a(oVarB, aVarR, dVar.f());
            }
            if (!qVarJ.c().isEmpty()) {
                aVarR.i(a.class);
            }
        }
    }

    private LegacySavedStateHandleController() {
    }

    public static final void a(o oVar, androidx.savedstate.a aVar, d dVar) {
        ax.p138jb.l.f(oVar, "viewModel");
        ax.p138jb.l.f(aVar, "registry");
        ax.p138jb.l.f(dVar, "lifecycle");
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) oVar.c("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController == null || savedStateHandleController.i()) {
            return;
        }
        savedStateHandleController.g(aVar, dVar);
        a.b(aVar, dVar);
    }

    private final void b(final androidx.savedstate.a aVar, final d dVar) {
        d.b bVarB = dVar.b();
        if (bVarB == d.b.INITIALIZED || bVarB.h(d.b.STARTED)) {
            aVar.i(a.class);
        } else {
            dVar.a(new f() { // from class: androidx.lifecycle.LegacySavedStateHandleController$tryToAddRecreator$1
                @Override // androidx.lifecycle.f
                public void d(ax.F0.g gVar, d.a aVar2) {
                    ax.p138jb.l.f(gVar, "source");
                    ax.p138jb.l.f(aVar2, "event");
                    if (aVar2 == d.a.ON_START) {
                        dVar.c(this);
                        aVar.i(LegacySavedStateHandleController.a.class);
                    }
                }
            });
        }
    }
}
