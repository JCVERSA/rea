package androidx.lifecycle;

import android.os.Bundle;
import ax.G0.v;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class LegacySavedStateHandleController {
    public static final LegacySavedStateHandleController a = new LegacySavedStateHandleController();

    public static final class a implements androidx.savedstate.a.InterfaceC0045a {
        @Override // androidx.savedstate.a.InterfaceC0045a
        public void a(ax.p245p2.d dVar) {
            ax.p335uc.l.f(dVar, "owner");
            if (!(dVar instanceof v)) {
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
            }
            r viewModelStore = ((v) dVar).getViewModelStore();
            androidx.savedstate.a savedStateRegistry = dVar.getSavedStateRegistry();
            Iterator<String> it = viewModelStore.c().iterator();
            while (it.hasNext()) {
                p pVarB = viewModelStore.b(it.next());
                ax.p335uc.l.c(pVarB);
                LegacySavedStateHandleController.a(pVarB, savedStateRegistry, dVar.getLifecycle());
            }
            if (viewModelStore.c().isEmpty()) {
                return;
            }
            savedStateRegistry.i(a.class);
        }
    }

    private LegacySavedStateHandleController() {
    }

    public static final void a(p pVar, androidx.savedstate.a aVar, d dVar) {
        ax.p335uc.l.f(pVar, "viewModel");
        ax.p335uc.l.f(aVar, "registry");
        ax.p335uc.l.f(dVar, "lifecycle");
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) pVar.c("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController == null || savedStateHandleController.j()) {
            return;
        }
        savedStateHandleController.h(aVar, dVar);
        a.c(aVar, dVar);
    }

    public static final SavedStateHandleController b(androidx.savedstate.a aVar, d dVar, String str, Bundle bundle) {
        ax.p335uc.l.f(aVar, "registry");
        ax.p335uc.l.f(dVar, "lifecycle");
        ax.p335uc.l.c(str);
        SavedStateHandleController savedStateHandleController = new SavedStateHandleController(str, l.f.a(aVar.b(str), bundle));
        savedStateHandleController.h(aVar, dVar);
        a.c(aVar, dVar);
        return savedStateHandleController;
    }

    private final void c(final androidx.savedstate.a aVar, final d dVar) {
        d.b bVarB = dVar.b();
        if (bVarB == d.b.INITIALIZED || bVarB.h(d.b.STARTED)) {
            aVar.i(a.class);
        } else {
            dVar.a(new f() { // from class: androidx.lifecycle.LegacySavedStateHandleController$tryToAddRecreator$1
                @Override // androidx.lifecycle.f
                public void b(ax.G0.h hVar, d.a aVar2) {
                    ax.p335uc.l.f(hVar, "source");
                    ax.p335uc.l.f(aVar2, "event");
                    if (aVar2 == d.a.ON_START) {
                        dVar.c(this);
                        aVar.i(LegacySavedStateHandleController.a.class);
                    }
                }
            });
        }
    }
}
