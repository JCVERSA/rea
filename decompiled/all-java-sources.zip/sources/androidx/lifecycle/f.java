package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface f extends ax.G0.g {
    void b(ax.G0.h hVar, d.a aVar);
}
