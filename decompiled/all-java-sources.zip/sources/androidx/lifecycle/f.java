package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface f extends ax.F0.f {
    void d(ax.F0.g gVar, d.a aVar);
}
