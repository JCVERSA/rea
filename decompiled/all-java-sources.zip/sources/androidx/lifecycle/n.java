package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import ax.G0.s;
import java.lang.reflect.Constructor;

/* JADX INFO: loaded from: classes.dex */
public final class n extends q.d implements q.b {
    private Application a;
    private final q.b b;
    private Bundle c;
    private d d;
    private androidx.savedstate.a e;

    @SuppressLint({"LambdaLast"})
    public n(Application application, ax.p245p2.d dVar, Bundle bundle) {
        ax.p335uc.l.f(dVar, "owner");
        this.e = dVar.getSavedStateRegistry();
        this.d = dVar.getLifecycle();
        this.c = bundle;
        this.a = application;
        this.b = application != null ? q.a.e.a(application) : new q.a();
    }

    @Override // androidx.lifecycle.q.b
    public <T extends p> T a(Class<T> cls) {
        ax.p335uc.l.f(cls, "modelClass");
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return (T) d(canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Override // androidx.lifecycle.q.b
    public <T extends p> T b(Class<T> cls, ax.I0.a aVar) {
        ax.p335uc.l.f(cls, "modelClass");
        ax.p335uc.l.f(aVar, "extras");
        String str = (String) aVar.a(q.c.c);
        if (str == null) {
            throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
        }
        if (aVar.a(m.a) == null || aVar.a(m.b) == null) {
            if (this.d != null) {
                return (T) d(str, cls);
            }
            throw new IllegalStateException("SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel.");
        }
        Application application = (Application) aVar.a(q.a.g);
        boolean zIsAssignableFrom = ax.G0.a.class.isAssignableFrom(cls);
        Constructor constructorC = (!zIsAssignableFrom || application == null) ? s.c(cls, s.b) : s.c(cls, s.a);
        if (constructorC == null) {
            return (T) this.b.b(cls, aVar);
        }
        return (!zIsAssignableFrom || application == null) ? (T) s.d(cls, constructorC, m.a(aVar)) : (T) s.d(cls, constructorC, application, m.a(aVar));
    }

    @Override // androidx.lifecycle.q.d
    public void c(p pVar) {
        ax.p335uc.l.f(pVar, "viewModel");
        if (this.d != null) {
            androidx.savedstate.a aVar = this.e;
            ax.p335uc.l.c(aVar);
            d dVar = this.d;
            ax.p335uc.l.c(dVar);
            LegacySavedStateHandleController.a(pVar, aVar, dVar);
        }
    }

    public final <T extends p> T d(String str, Class<T> cls) {
        T t;
        Application application;
        ax.p335uc.l.f(str, "key");
        ax.p335uc.l.f(cls, "modelClass");
        d dVar = this.d;
        if (dVar == null) {
            throw new UnsupportedOperationException("SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
        }
        boolean zIsAssignableFrom = ax.G0.a.class.isAssignableFrom(cls);
        Constructor constructorC = (!zIsAssignableFrom || this.a == null) ? s.c(cls, s.b) : s.c(cls, s.a);
        if (constructorC == null) {
            return this.a != null ? (T) this.b.a(cls) : (T) q.c.a.a().a(cls);
        }
        androidx.savedstate.a aVar = this.e;
        ax.p335uc.l.c(aVar);
        SavedStateHandleController savedStateHandleControllerB = LegacySavedStateHandleController.b(aVar, dVar, str, this.c);
        if (!zIsAssignableFrom || (application = this.a) == null) {
            t = (T) s.d(cls, constructorC, savedStateHandleControllerB.i());
        } else {
            ax.p335uc.l.c(application);
            t = (T) s.d(cls, constructorC, application, savedStateHandleControllerB.i());
        }
        t.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleControllerB);
        return t;
    }
}
