package androidx.lifecycle;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public class n {
    private final g a;
    private final Handler b;
    private a c;

    public static final class a implements Runnable {
        private final d.a X;
        private boolean Y;
        private final g q;

        public a(g gVar, d.a aVar) {
            ax.p138jb.l.f(gVar, "registry");
            ax.p138jb.l.f(aVar, "event");
            this.q = gVar;
            this.X = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.Y) {
                return;
            }
            this.q.h(this.X);
            this.Y = true;
        }
    }

    public n(ax.F0.g gVar) {
        ax.p138jb.l.f(gVar, "provider");
        this.a = new g(gVar);
        this.b = new Handler();
    }

    private final void f(d.a aVar) {
        a aVar2 = this.c;
        if (aVar2 != null) {
            aVar2.run();
        }
        a aVar3 = new a(this.a, aVar);
        this.c = aVar3;
        Handler handler = this.b;
        ax.p138jb.l.c(aVar3);
        handler.postAtFrontOfQueue(aVar3);
    }

    public d a() {
        return this.a;
    }

    public void b() {
        f(d.a.ON_START);
    }

    public void c() {
        f(d.a.ON_CREATE);
    }

    public void d() {
        f(d.a.ON_STOP);
        f(d.a.ON_DESTROY);
    }

    public void e() {
        f(d.a.ON_START);
    }
}
