package androidx.lifecycle;

import ax.Ec.x0;

/* JADX INFO: loaded from: classes.dex */
public final class LifecycleCoroutineScopeImpl extends ax.G0.e implements f {
    private final ax.p175kc.i X;
    private final d q;

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        ax.p335uc.l.f(hVar, "source");
        ax.p335uc.l.f(aVar, "event");
        if (i().b().compareTo(d.b.DESTROYED) <= 0) {
            i().c(this);
            x0.d(h(), null, 1, null);
        }
    }

    @Override // ax.Ec.J
    public ax.p175kc.i h() {
        return this.X;
    }

    public d i() {
        return this.q;
    }
}
