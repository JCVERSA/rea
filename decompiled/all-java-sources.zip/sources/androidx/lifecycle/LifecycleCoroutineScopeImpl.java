package androidx.lifecycle;

import ax.p278tb.x0;

/* JADX INFO: loaded from: classes.dex */
public final class LifecycleCoroutineScopeImpl extends ax.F0.d implements f {
    private final ax.Za.g X;
    private final d q;

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        if (i().b().compareTo(d.b.DESTROYED) <= 0) {
            i().c(this);
            x0.d(g(), null, 1, null);
        }
    }

    @Override // ax.p278tb.J
    public ax.Za.g g() {
        return this.X;
    }

    public d i() {
        return this.q;
    }
}
