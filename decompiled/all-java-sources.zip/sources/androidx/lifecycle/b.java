package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    void a(ax.G0.h hVar, d.a aVar, boolean z, ax.G0.k kVar);
}
