package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    void a(ax.F0.g gVar, d.a aVar, boolean z, ax.F0.j jVar);
}
