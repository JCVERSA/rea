package androidx.lifecycle;

import ax.p278tb.InterfaceC5694l;

/* JADX INFO: loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements f {
    final /* synthetic */ d X;
    final /* synthetic */ InterfaceC5694l<Object> Y;
    final /* synthetic */ ax.p124ib.a<Object> Z;
    final /* synthetic */ d.b q;

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        Object objA;
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        if (aVar != d.a.Companion.c(this.q)) {
            if (aVar == d.a.ON_DESTROY) {
                this.X.c(this);
                InterfaceC5694l<Object> interfaceC5694l = this.Y;
                ax.Wa.n.a aVar2 = ax.Wa.n.q;
                interfaceC5694l.e(ax.Wa.n.a(ax.Wa.o.a(new ax.F0.e())));
                return;
            }
            return;
        }
        this.X.c(this);
        InterfaceC5694l<Object> interfaceC5694l2 = this.Y;
        ax.p124ib.a<Object> aVar3 = this.Z;
        try {
            ax.Wa.n.a aVar4 = ax.Wa.n.q;
            objA = ax.Wa.n.a(aVar3.invoke());
        } catch (Throwable th) {
            ax.Wa.n.a aVar5 = ax.Wa.n.q;
            objA = ax.Wa.n.a(ax.Wa.o.a(th));
        }
        interfaceC5694l2.e(objA);
    }
}
