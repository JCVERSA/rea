package androidx.lifecycle;

import ax.Ec.InterfaceC0801l;

/* JADX INFO: loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements f {
    final /* synthetic */ d X;
    final /* synthetic */ InterfaceC0801l<Object> Y;
    final /* synthetic */ ax.p319tc.a<Object> Z;
    final /* synthetic */ d.b q;

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        Object objA;
        ax.p335uc.l.f(hVar, "source");
        ax.p335uc.l.f(aVar, "event");
        if (aVar != d.a.Companion.c(this.q)) {
            if (aVar == d.a.ON_DESTROY) {
                this.X.c(this);
                InterfaceC0801l<Object> interfaceC0801l = this.Y;
                ax.gc.n.a aVar2 = ax.p111gc.n.q;
                interfaceC0801l.c(ax.p111gc.n.a(ax.p111gc.o.a(new ax.G0.f())));
                return;
            }
            return;
        }
        this.X.c(this);
        InterfaceC0801l<Object> interfaceC0801l2 = this.Y;
        ax.p319tc.a<Object> aVar3 = this.Z;
        try {
            ax.gc.n.a aVar4 = ax.p111gc.n.q;
            objA = ax.p111gc.n.a(aVar3.invoke());
        } catch (Throwable th) {
            ax.gc.n.a aVar5 = ax.p111gc.n.q;
            objA = ax.p111gc.n.a(ax.p111gc.o.a(th));
        }
        interfaceC0801l2.c(objA);
    }
}
