package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
class ReflectiveGenericLifecycleObserver implements f {
    private final a.C0021a X;
    private final Object q;

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.q = obj;
        this.X = a.c.c(obj.getClass());
    }

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        this.X.a(gVar, aVar, this.q);
    }
}
