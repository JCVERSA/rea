package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
class ReflectiveGenericLifecycleObserver implements f {
    private final a.C0022a X;
    private final Object q;

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.q = obj;
        this.X = a.c.c(obj.getClass());
    }

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        this.X.a(hVar, aVar, this.q);
    }
}
