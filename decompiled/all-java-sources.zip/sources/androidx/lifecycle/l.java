package androidx.lifecycle;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import ax.Xa.C;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class l {
    public static final a f = new a(null);
    private static final Class<? extends Object>[] g = {Boolean.TYPE, boolean[].class, Double.TYPE, double[].class, Integer.TYPE, int[].class, Long.TYPE, long[].class, String.class, String[].class, Binder.class, Bundle.class, Byte.TYPE, byte[].class, Character.TYPE, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, Float.TYPE, float[].class, Parcelable.class, Parcelable[].class, Serializable.class, Short.TYPE, short[].class, SparseArray.class, Size.class, SizeF.class};
    private final Map<String, Object> a = new LinkedHashMap();
    private final Map<String, androidx.savedstate.a.c> b = new LinkedHashMap();
    private final Map<String, Object> c = new LinkedHashMap();
    private final Map<String, ax.p320wb.k<Object>> d = new LinkedHashMap();
    private final androidx.savedstate.a.c e = new androidx.savedstate.a.c() { // from class: ax.F0.o
        @Override // androidx.savedstate.a.c
        public final Bundle a() {
            return androidx.lifecycle.l.d(this.a);
        }
    };

    public static final class a {
        private a() {
        }

        public final boolean a(Object obj) {
            if (obj == null) {
                return true;
            }
            for (Class cls : l.g) {
                ax.p138jb.l.c(cls);
                if (cls.isInstance(obj)) {
                    return true;
                }
            }
            return false;
        }

        public /* synthetic */ a(ax.p138jb.g gVar) {
            this();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Bundle d(l lVar) {
        ax.p138jb.l.f(lVar, "this$0");
        for (Map.Entry entry : C.k(lVar.b).entrySet()) {
            lVar.e((String) entry.getKey(), ((androidx.savedstate.a.c) entry.getValue()).a());
        }
        Set<String> setKeySet = lVar.a.keySet();
        ArrayList arrayList = new ArrayList(setKeySet.size());
        ArrayList arrayList2 = new ArrayList(arrayList.size());
        for (String str : setKeySet) {
            arrayList.add(str);
            arrayList2.add(lVar.a.get(str));
        }
        return ax.X.c.a(ax.Wa.q.a("keys", arrayList), ax.Wa.q.a("values", arrayList2));
    }

    public final androidx.savedstate.a.c c() {
        return this.e;
    }

    public final <T> void e(String str, T t) {
        ax.p138jb.l.f(str, "key");
        if (!f.a(t)) {
            StringBuilder sb = new StringBuilder();
            sb.append("Can't put value with type ");
            ax.p138jb.l.c(t);
            sb.append(t.getClass());
            sb.append(" into saved state");
            throw new IllegalArgumentException(sb.toString());
        }
        Object obj = this.c.get(str);
        ax.F0.k kVar = obj instanceof ax.F0.k ? (ax.F0.k) obj : null;
        if (kVar != null) {
            kVar.n(t);
        } else {
            this.a.put(str, t);
        }
        ax.p320wb.k<Object> kVar2 = this.d.get(str);
        if (kVar2 == null) {
            return;
        }
        kVar2.setValue(t);
    }
}
