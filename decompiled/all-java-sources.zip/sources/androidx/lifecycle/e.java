package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final e a = new e();
    private static final AtomicBoolean b = new AtomicBoolean(false);

    public static final class a extends ax.F0.c {
        @Override // ax.F0.c, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            ax.p138jb.l.f(activity, "activity");
            k.X.c(activity);
        }
    }

    private e() {
    }

    public static final void a(Context context) {
        ax.p138jb.l.f(context, "context");
        if (b.getAndSet(true)) {
            return;
        }
        Context applicationContext = context.getApplicationContext();
        ax.p138jb.l.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext).registerActivityLifecycleCallbacks(new a());
    }
}
