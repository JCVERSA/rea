package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface c {
    ax.I0.a getDefaultViewModelCreationExtras();
}
