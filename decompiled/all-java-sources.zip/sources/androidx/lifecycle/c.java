package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface c {
    ax.H0.a E();
}
