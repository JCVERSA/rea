package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleAttacher implements f {
    private final ax.F0.p q;

    public SavedStateHandleAttacher(ax.F0.p pVar) {
        ax.p138jb.l.f(pVar, "provider");
        this.q = pVar;
    }

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        if (aVar == d.a.ON_CREATE) {
            gVar.f().c(this);
            this.q.c();
        } else {
            throw new IllegalStateException(("Next event must be ON_CREATE, it was " + aVar).toString());
        }
    }
}
