package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class LiveData<T> {
    static final Object k = new Object();
    final Object a = new Object();
    private ax.p308w.b<ax.F0.l<? super T>, LiveData<T>.c> b = new ax.p308w.b<>();
    int c = 0;
    private boolean d;
    private volatile Object e;
    volatile Object f;
    private int g;
    private boolean h;
    private boolean i;
    private final Runnable j;

    class LifecycleBoundObserver extends LiveData<T>.c implements f {
        final ax.F0.g h0;

        LifecycleBoundObserver(ax.F0.g gVar, ax.F0.l<? super T> lVar) {
            super(lVar);
            this.h0 = gVar;
        }

        @Override // androidx.lifecycle.f
        public void d(ax.F0.g gVar, d.a aVar) {
            d.b bVarB = this.h0.f().b();
            if (bVarB == d.b.DESTROYED) {
                LiveData.this.m(this.q);
                return;
            }
            d.b bVar = null;
            while (bVar != bVarB) {
                g(k());
                bVar = bVarB;
                bVarB = this.h0.f().b();
            }
        }

        @Override // androidx.lifecycle.LiveData.c
        void i() {
            this.h0.f().c(this);
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean j(ax.F0.g gVar) {
            return this.h0 == gVar;
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean k() {
            return this.h0.f().b().h(d.b.STARTED);
        }
    }

    class a implements Runnable {
        a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.a) {
                obj = LiveData.this.f;
                LiveData.this.f = LiveData.k;
            }
            LiveData.this.n(obj);
        }
    }

    private class b extends LiveData<T>.c {
        b(ax.F0.l<? super T> lVar) {
            super(lVar);
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean k() {
            return true;
        }
    }

    private abstract class c {
        boolean X;
        int Y = -1;
        final ax.F0.l<? super T> q;

        c(ax.F0.l<? super T> lVar) {
            this.q = lVar;
        }

        void g(boolean z) {
            if (z == this.X) {
                return;
            }
            this.X = z;
            LiveData.this.c(z ? 1 : -1);
            if (this.X) {
                LiveData.this.e(this);
            }
        }

        void i() {
        }

        boolean j(ax.F0.g gVar) {
            return false;
        }

        abstract boolean k();
    }

    public LiveData() {
        Object obj = k;
        this.f = obj;
        this.j = new a();
        this.e = obj;
        this.g = -1;
    }

    static void b(String str) {
        if (ax.p294v.c.g().b()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    private void d(LiveData<T>.c cVar) {
        if (cVar.X) {
            if (!cVar.k()) {
                cVar.g(false);
                return;
            }
            int i = cVar.Y;
            int i2 = this.g;
            if (i >= i2) {
                return;
            }
            cVar.Y = i2;
            cVar.q.a((Object) this.e);
        }
    }

    void c(int i) {
        int i2 = this.c;
        this.c = i + i2;
        if (this.d) {
            return;
        }
        this.d = true;
        while (true) {
            try {
                int i3 = this.c;
                if (i2 == i3) {
                    this.d = false;
                    return;
                }
                boolean z = i2 == 0 && i3 > 0;
                boolean z2 = i2 > 0 && i3 == 0;
                if (z) {
                    j();
                } else if (z2) {
                    k();
                }
                i2 = i3;
            } catch (Throwable th) {
                this.d = false;
                throw th;
            }
        }
    }

    void e(LiveData<T>.c cVar) {
        if (this.h) {
            this.i = true;
            return;
        }
        this.h = true;
        do {
            this.i = false;
            if (cVar != null) {
                d(cVar);
                cVar = null;
            } else {
                ax.p308w.b<ax.F0.l<? super T>, LiveData<T>.c>.d dVarJ = this.b.j();
                while (dVarJ.hasNext()) {
                    d((c) dVarJ.next().getValue());
                    if (this.i) {
                        break;
                    }
                }
            }
        } while (this.i);
        this.h = false;
    }

    public T f() {
        T t = (T) this.e;
        if (t != k) {
            return t;
        }
        return null;
    }

    public boolean g() {
        return this.c > 0;
    }

    public void h(ax.F0.g gVar, ax.F0.l<? super T> lVar) {
        b("observe");
        if (gVar.f().b() == d.b.DESTROYED) {
            return;
        }
        LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(gVar, lVar);
        LiveData<T>.c cVarO = this.b.o(lVar, lifecycleBoundObserver);
        if (cVarO != null && !cVarO.j(gVar)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (cVarO != null) {
            return;
        }
        gVar.f().a(lifecycleBoundObserver);
    }

    public void i(ax.F0.l<? super T> lVar) {
        b("observeForever");
        b bVar = new b(lVar);
        LiveData<T>.c cVarO = this.b.o(lVar, bVar);
        if (cVarO instanceof LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (cVarO != null) {
            return;
        }
        bVar.g(true);
    }

    protected void j() {
    }

    protected void k() {
    }

    protected void l(T t) {
        boolean z;
        synchronized (this.a) {
            z = this.f == k;
            this.f = t;
        }
        if (z) {
            ax.p294v.c.g().c(this.j);
        }
    }

    public void m(ax.F0.l<? super T> lVar) {
        b("removeObserver");
        LiveData<T>.c cVarP = this.b.p(lVar);
        if (cVarP == null) {
            return;
        }
        cVarP.i();
        cVarP.g(false);
    }

    protected void n(T t) {
        b("setValue");
        this.g++;
        this.e = t;
        e(null);
    }
}
