package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleController implements f {
    private final l X;
    private boolean Y;
    private final String q;

    public SavedStateHandleController(String str, l lVar) {
        ax.p335uc.l.f(str, "key");
        ax.p335uc.l.f(lVar, "handle");
        this.q = str;
        this.X = lVar;
    }

    @Override // androidx.lifecycle.f
    public void b(ax.G0.h hVar, d.a aVar) {
        ax.p335uc.l.f(hVar, "source");
        ax.p335uc.l.f(aVar, "event");
        if (aVar == d.a.ON_DESTROY) {
            this.Y = false;
            hVar.getLifecycle().c(this);
        }
    }

    public final void h(androidx.savedstate.a aVar, d dVar) {
        ax.p335uc.l.f(aVar, "registry");
        ax.p335uc.l.f(dVar, "lifecycle");
        if (this.Y) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.Y = true;
        dVar.a(this);
        aVar.h(this.q, this.X.c());
    }

    public final l i() {
        return this.X;
    }

    public final boolean j() {
        return this.Y;
    }
}
