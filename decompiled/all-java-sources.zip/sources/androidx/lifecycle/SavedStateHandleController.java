package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleController implements f {
    private final l X;
    private boolean Y;
    private final String q;

    @Override // androidx.lifecycle.f
    public void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "source");
        ax.p138jb.l.f(aVar, "event");
        if (aVar == d.a.ON_DESTROY) {
            this.Y = false;
            gVar.f().c(this);
        }
    }

    public final void g(androidx.savedstate.a aVar, d dVar) {
        ax.p138jb.l.f(aVar, "registry");
        ax.p138jb.l.f(dVar, "lifecycle");
        if (!(!this.Y)) {
            throw new IllegalStateException("Already attached to lifecycleOwner".toString());
        }
        this.Y = true;
        dVar.a(this);
        aVar.h(this.q, this.X.c());
    }

    public final boolean i() {
        return this.Y;
    }
}
