package androidx.lifecycle;

import android.app.Application;
import ax.G0.t;
import ax.G0.u;
import ax.G0.v;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public class q {
    private final r a;
    private final b b;
    private final ax.I0.a c;

    public static class a extends c {
        private static a f;
        private final Application d;
        public static final C0025a e = new C0025a(null);
        public static final ax.I0.a.b<Application> g = C0025a.C0026a.a;

        /* JADX INFO: renamed from: androidx.lifecycle.q$a$a, reason: collision with other inner class name */
        public static final class C0025a {

            /* JADX INFO: renamed from: androidx.lifecycle.q$a$a$a, reason: collision with other inner class name */
            private static final class C0026a implements ax.I0.a.b<Application> {
                public static final C0026a a = new C0026a();

                private C0026a() {
                }
            }

            private C0025a() {
            }

            public /* synthetic */ C0025a(ax.p335uc.g gVar) {
                this();
            }

            public final a a(Application application) {
                ax.p335uc.l.f(application, "application");
                if (a.f == null) {
                    a.f = new a(application);
                }
                a aVar = a.f;
                ax.p335uc.l.c(aVar);
                return aVar;
            }
        }

        public a() {
            this(null, 0);
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        public a(Application application) {
            this(application, 0);
            ax.p335uc.l.f(application, "application");
        }

        private a(Application application, int i) {
            this.d = application;
        }

        private final <T extends p> T g(Class<T> cls, Application application) {
            if (!ax.G0.a.class.isAssignableFrom(cls)) {
                return (T) super.a(cls);
            }
            try {
                T tNewInstance = cls.getConstructor(Application.class).newInstance(application);
                ax.p335uc.l.e(tNewInstance, "{\n                try {\n…          }\n            }");
                return tNewInstance;
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            } catch (NoSuchMethodException e4) {
                throw new RuntimeException("Cannot create an instance of " + cls, e4);
            } catch (InvocationTargetException e5) {
                throw new RuntimeException("Cannot create an instance of " + cls, e5);
            }
        }

        @Override // androidx.lifecycle.q.c, androidx.lifecycle.q.b
        public <T extends p> T a(Class<T> cls) {
            ax.p335uc.l.f(cls, "modelClass");
            Application application = this.d;
            if (application != null) {
                return (T) g(cls, application);
            }
            throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
        }

        @Override // androidx.lifecycle.q.c, androidx.lifecycle.q.b
        public <T extends p> T b(Class<T> cls, ax.I0.a aVar) {
            ax.p335uc.l.f(cls, "modelClass");
            ax.p335uc.l.f(aVar, "extras");
            if (this.d != null) {
                return (T) a(cls);
            }
            Application application = (Application) aVar.a(g);
            if (application != null) {
                return (T) g(cls, application);
            }
            if (ax.G0.a.class.isAssignableFrom(cls)) {
                throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
            }
            return (T) super.a(cls);
        }
    }

    public interface b {
        <T extends p> T a(Class<T> cls);

        <T extends p> T b(Class<T> cls, ax.I0.a aVar);
    }

    public static class c implements b {
        private static c b;
        public static final a a = new a(null);
        public static final ax.I0.a.b<String> c = a.C0027a.a;

        public static final class a {

            /* JADX INFO: renamed from: androidx.lifecycle.q$c$a$a, reason: collision with other inner class name */
            private static final class C0027a implements ax.I0.a.b<String> {
                public static final C0027a a = new C0027a();

                private C0027a() {
                }
            }

            private a() {
            }

            public /* synthetic */ a(ax.p335uc.g gVar) {
                this();
            }

            public final c a() {
                if (c.b == null) {
                    c.b = new c();
                }
                c cVar = c.b;
                ax.p335uc.l.c(cVar);
                return cVar;
            }
        }

        @Override // androidx.lifecycle.q.b
        public <T extends p> T a(Class<T> cls) throws InvocationTargetException {
            ax.p335uc.l.f(cls, "modelClass");
            try {
                T tNewInstance = cls.getDeclaredConstructor(null).newInstance(null);
                ax.p335uc.l.e(tNewInstance, "{\n                modelC…wInstance()\n            }");
                return tNewInstance;
            } catch (IllegalAccessException e) {
                throw new RuntimeException("Cannot create an instance of " + cls, e);
            } catch (InstantiationException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (NoSuchMethodException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            }
        }

        @Override // androidx.lifecycle.q.b
        public /* synthetic */ p b(Class cls, ax.I0.a aVar) {
            return t.b(this, cls, aVar);
        }
    }

    public static class d {
        public void c(p pVar) {
            ax.p335uc.l.f(pVar, "viewModel");
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public q(r rVar, b bVar) {
        this(rVar, bVar, null, 4, null);
        ax.p335uc.l.f(rVar, "store");
        ax.p335uc.l.f(bVar, "factory");
    }

    public q(r rVar, b bVar, ax.I0.a aVar) {
        ax.p335uc.l.f(rVar, "store");
        ax.p335uc.l.f(bVar, "factory");
        ax.p335uc.l.f(aVar, "defaultCreationExtras");
        this.a = rVar;
        this.b = bVar;
        this.c = aVar;
    }

    public /* synthetic */ q(r rVar, b bVar, ax.I0.a aVar, int i, ax.p335uc.g gVar) {
        this(rVar, bVar, (i & 4) != 0 ? ax.I0.a.C0109a.b : aVar);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public q(v vVar, b bVar) {
        this(vVar.getViewModelStore(), bVar, u.a(vVar));
        ax.p335uc.l.f(vVar, "owner");
        ax.p335uc.l.f(bVar, "factory");
    }

    public <T extends p> T a(Class<T> cls) {
        ax.p335uc.l.f(cls, "modelClass");
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        return (T) b("androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public <T extends p> T b(String str, Class<T> cls) {
        T t;
        ax.p335uc.l.f(str, "key");
        ax.p335uc.l.f(cls, "modelClass");
        T t2 = (T) this.a.b(str);
        if (!cls.isInstance(t2)) {
            ax.I0.d dVar = new ax.I0.d(this.c);
            dVar.c(c.c, str);
            try {
                t = (T) this.b.b(cls, dVar);
            } catch (AbstractMethodError unused) {
                t = (T) this.b.a(cls);
            }
            this.a.d(str, t);
            return t;
        }
        Object obj = this.b;
        d dVar2 = obj instanceof d ? (d) obj : null;
        if (dVar2 != null) {
            ax.p335uc.l.c(t2);
            dVar2.c(t2);
        }
        ax.p335uc.l.d(t2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
        return t2;
    }
}
