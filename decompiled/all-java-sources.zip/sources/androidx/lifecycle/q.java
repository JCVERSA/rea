package androidx.lifecycle;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class q {
    private final Map<String, o> a = new LinkedHashMap();

    public final void a() {
        Iterator<o> it = this.a.values().iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.a.clear();
    }

    public final o b(String str) {
        ax.p138jb.l.f(str, "key");
        return this.a.get(str);
    }

    public final Set<String> c() {
        return new HashSet(this.a.keySet());
    }

    public final void d(String str, o oVar) {
        ax.p138jb.l.f(str, "key");
        ax.p138jb.l.f(oVar, "viewModel");
        o oVarPut = this.a.put(str, oVar);
        if (oVarPut != null) {
            oVarPut.d();
        }
    }
}
