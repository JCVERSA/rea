package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class j implements ax.F0.g {
    public static final b l0 = new b(null);
    private static final j m0 = new j();
    private int X;
    private Handler h0;
    private int q;
    private boolean Y = true;
    private boolean Z = true;
    private final g i0 = new g(this);
    private final Runnable j0 = new Runnable() { // from class: ax.F0.m
        @Override // java.lang.Runnable
        public final void run() {
            androidx.lifecycle.j.j(this.q);
        }
    };
    private final k.a k0 = new d();

    public static final class a {
        public static final a a = new a();

        private a() {
        }

        public static final void a(Activity activity, Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
            ax.p138jb.l.f(activity, "activity");
            ax.p138jb.l.f(activityLifecycleCallbacks, "callback");
            activity.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
        }
    }

    public static final class b {
        private b() {
        }

        public final ax.F0.g a() {
            return j.m0;
        }

        public final void b(Context context) {
            ax.p138jb.l.f(context, "context");
            j.m0.i(context);
        }

        public /* synthetic */ b(ax.p138jb.g gVar) {
            this();
        }
    }

    public static final class c extends ax.F0.c {

        public static final class a extends ax.F0.c {
            final /* synthetic */ j this$0;

            a(j jVar) {
                this.this$0 = jVar;
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostResumed(Activity activity) {
                ax.p138jb.l.f(activity, "activity");
                this.this$0.e();
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostStarted(Activity activity) {
                ax.p138jb.l.f(activity, "activity");
                this.this$0.g();
            }
        }

        c() {
        }

        @Override // ax.F0.c, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            ax.p138jb.l.f(activity, "activity");
            if (Build.VERSION.SDK_INT < 29) {
                k.X.b(activity).f(j.this.k0);
            }
        }

        @Override // ax.F0.c, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            ax.p138jb.l.f(activity, "activity");
            j.this.d();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreCreated(Activity activity, Bundle bundle) {
            ax.p138jb.l.f(activity, "activity");
            a.a(activity, new a(j.this));
        }

        @Override // ax.F0.c, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            ax.p138jb.l.f(activity, "activity");
            j.this.h();
        }
    }

    public static final class d implements k.a {
        d() {
        }

        @Override // androidx.lifecycle.k.a
        public void b() {
            j.this.g();
        }

        @Override // androidx.lifecycle.k.a
        public void onCreate() {
        }

        @Override // androidx.lifecycle.k.a
        public void onResume() {
            j.this.e();
        }
    }

    private j() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void j(j jVar) {
        ax.p138jb.l.f(jVar, "this$0");
        jVar.k();
        jVar.l();
    }

    public static final ax.F0.g m() {
        return l0.a();
    }

    public final void d() {
        int i = this.X - 1;
        this.X = i;
        if (i == 0) {
            Handler handler = this.h0;
            ax.p138jb.l.c(handler);
            handler.postDelayed(this.j0, 700L);
        }
    }

    public final void e() {
        int i = this.X + 1;
        this.X = i;
        if (i == 1) {
            if (this.Y) {
                this.i0.h(androidx.lifecycle.d.a.ON_RESUME);
                this.Y = false;
            } else {
                Handler handler = this.h0;
                ax.p138jb.l.c(handler);
                handler.removeCallbacks(this.j0);
            }
        }
    }

    @Override // ax.F0.g
    public androidx.lifecycle.d f() {
        return this.i0;
    }

    public final void g() {
        int i = this.q + 1;
        this.q = i;
        if (i == 1 && this.Z) {
            this.i0.h(androidx.lifecycle.d.a.ON_START);
            this.Z = false;
        }
    }

    public final void h() {
        this.q--;
        l();
    }

    public final void i(Context context) {
        ax.p138jb.l.f(context, "context");
        this.h0 = new Handler();
        this.i0.h(androidx.lifecycle.d.a.ON_CREATE);
        Context applicationContext = context.getApplicationContext();
        ax.p138jb.l.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext).registerActivityLifecycleCallbacks(new c());
    }

    public final void k() {
        if (this.X == 0) {
            this.Y = true;
            this.i0.h(androidx.lifecycle.d.a.ON_PAUSE);
        }
    }

    public final void l() {
        if (this.q == 0 && this.Y) {
            this.i0.h(androidx.lifecycle.d.a.ON_STOP);
            this.Z = true;
        }
    }
}
