package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class j implements ax.G0.h {
    public static final b o0 = new b(null);
    private static final j p0 = new j();
    private int X;
    private Handler k0;
    private int q;
    private boolean Y = true;
    private boolean Z = true;
    private final g l0 = new g(this);
    private final Runnable m0 = new Runnable() { // from class: ax.G0.n
        @Override // java.lang.Runnable
        public final void run() {
            androidx.lifecycle.j.i(this.q);
        }
    };
    private final k.a n0 = new d();

    public static final class a {
        public static final a a = new a();

        private a() {
        }

        public static final void a(Activity activity, Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
            ax.p335uc.l.f(activity, "activity");
            ax.p335uc.l.f(activityLifecycleCallbacks, "callback");
            activity.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(ax.p335uc.g gVar) {
            this();
        }

        public final ax.G0.h a() {
            return j.p0;
        }

        public final void b(Context context) {
            ax.p335uc.l.f(context, "context");
            j.p0.h(context);
        }
    }

    public static final class c extends ax.G0.d {

        public static final class a extends ax.G0.d {
            final /* synthetic */ j this$0;

            a(j jVar) {
                this.this$0 = jVar;
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostResumed(Activity activity) {
                ax.p335uc.l.f(activity, "activity");
                this.this$0.e();
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostStarted(Activity activity) {
                ax.p335uc.l.f(activity, "activity");
                this.this$0.f();
            }
        }

        c() {
        }

        @Override // ax.G0.d, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            ax.p335uc.l.f(activity, "activity");
            if (Build.VERSION.SDK_INT < 29) {
                k.X.b(activity).e(j.this.n0);
            }
        }

        @Override // ax.G0.d, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            ax.p335uc.l.f(activity, "activity");
            j.this.d();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreCreated(Activity activity, Bundle bundle) {
            ax.p335uc.l.f(activity, "activity");
            a.a(activity, new a(j.this));
        }

        @Override // ax.G0.d, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            ax.p335uc.l.f(activity, "activity");
            j.this.g();
        }
    }

    public static final class d implements k.a {
        d() {
        }

        @Override // androidx.lifecycle.k.a
        public void b() {
            j.this.f();
        }

        @Override // androidx.lifecycle.k.a
        public void onCreate() {
        }

        @Override // androidx.lifecycle.k.a
        public void onResume() {
            j.this.e();
        }
    }

    private j() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void i(j jVar) {
        ax.p335uc.l.f(jVar, "this$0");
        jVar.j();
        jVar.k();
    }

    public static final ax.G0.h l() {
        return o0.a();
    }

    public final void d() {
        int i = this.X - 1;
        this.X = i;
        if (i == 0) {
            Handler handler = this.k0;
            ax.p335uc.l.c(handler);
            handler.postDelayed(this.m0, 700L);
        }
    }

    public final void e() {
        int i = this.X + 1;
        this.X = i;
        if (i == 1) {
            if (this.Y) {
                this.l0.h(androidx.lifecycle.d.a.ON_RESUME);
                this.Y = false;
            } else {
                Handler handler = this.k0;
                ax.p335uc.l.c(handler);
                handler.removeCallbacks(this.m0);
            }
        }
    }

    public final void f() {
        int i = this.q + 1;
        this.q = i;
        if (i == 1 && this.Z) {
            this.l0.h(androidx.lifecycle.d.a.ON_START);
            this.Z = false;
        }
    }

    public final void g() {
        this.q--;
        k();
    }

    @Override // ax.G0.h
    public androidx.lifecycle.d getLifecycle() {
        return this.l0;
    }

    public final void h(Context context) {
        ax.p335uc.l.f(context, "context");
        this.k0 = new Handler();
        this.l0.h(androidx.lifecycle.d.a.ON_CREATE);
        Context applicationContext = context.getApplicationContext();
        ax.p335uc.l.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext).registerActivityLifecycleCallbacks(new c());
    }

    public final void j() {
        if (this.X == 0) {
            this.Y = true;
            this.l0.h(androidx.lifecycle.d.a.ON_PAUSE);
        }
    }

    public final void k() {
        if (this.q == 0 && this.Y) {
            this.l0.h(androidx.lifecycle.d.a.ON_STOP);
            this.Z = true;
        }
    }
}
