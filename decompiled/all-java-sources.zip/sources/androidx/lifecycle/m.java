package androidx.lifecycle;

import android.os.Bundle;
import ax.F0.t;
import ax.p138jb.w;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    public static final ax.H0.a.b<ax.p016b1.d> a = new b();
    public static final ax.H0.a.b<t> b = new c();
    public static final ax.H0.a.b<Bundle> c = new a();

    public static final class a implements ax.H0.a.b<Bundle> {
        a() {
        }
    }

    public static final class b implements ax.H0.a.b<ax.p016b1.d> {
        b() {
        }
    }

    public static final class c implements ax.H0.a.b<t> {
        c() {
        }
    }

    static final class d extends ax.p138jb.m implements ax.p124ib.l<ax.H0.a, ax.F0.q> {
        public static final d q = new d();

        d() {
            super(1);
        }

        @Override // ax.p124ib.l
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public final ax.F0.q invoke(ax.H0.a aVar) {
            ax.p138jb.l.f(aVar, "$this$initializer");
            return new ax.F0.q();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final <T extends ax.p016b1.d & t> void a(T t) {
        ax.p138jb.l.f(t, "<this>");
        androidx.lifecycle.d.b bVarB = t.f().b();
        if (bVarB != androidx.lifecycle.d.b.INITIALIZED && bVarB != androidx.lifecycle.d.b.CREATED) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        if (t.R().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
            ax.F0.p pVar = new ax.F0.p(t.R(), t);
            t.R().h("androidx.lifecycle.internal.SavedStateHandlesProvider", pVar);
            t.f().a(new SavedStateHandleAttacher(pVar));
        }
    }

    public static final ax.F0.q b(t tVar) {
        ax.p138jb.l.f(tVar, "<this>");
        ax.H0.c cVar = new ax.H0.c();
        cVar.a(w.b(ax.F0.q.class), d.q);
        return (ax.F0.q) new p(tVar, cVar.b()).b("androidx.lifecycle.internal.SavedStateHandlesVM", ax.F0.q.class);
    }
}
