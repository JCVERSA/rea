package androidx.lifecycle;

import android.os.Bundle;
import ax.G0.v;
import ax.p335uc.w;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    public static final ax.I0.a.b<ax.p245p2.d> a = new b();
    public static final ax.I0.a.b<v> b = new c();
    public static final ax.I0.a.b<Bundle> c = new a();

    public static final class a implements ax.I0.a.b<Bundle> {
        a() {
        }
    }

    public static final class b implements ax.I0.a.b<ax.p245p2.d> {
        b() {
        }
    }

    public static final class c implements ax.I0.a.b<v> {
        c() {
        }
    }

    static final class d extends ax.p335uc.m implements ax.p319tc.l<ax.I0.a, ax.G0.r> {
        public static final d q = new d();

        d() {
            super(1);
        }

        @Override // ax.p319tc.l
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final ax.G0.r invoke(ax.I0.a aVar) {
            ax.p335uc.l.f(aVar, "$this$initializer");
            return new ax.G0.r();
        }
    }

    public static final l a(ax.I0.a aVar) {
        ax.p335uc.l.f(aVar, "<this>");
        ax.p245p2.d dVar = (ax.p245p2.d) aVar.a(a);
        if (dVar == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `SAVED_STATE_REGISTRY_OWNER_KEY`");
        }
        v vVar = (v) aVar.a(b);
        if (vVar == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_STORE_OWNER_KEY`");
        }
        Bundle bundle = (Bundle) aVar.a(c);
        String str = (String) aVar.a(q.c.c);
        if (str != null) {
            return b(dVar, vVar, str, bundle);
        }
        throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_KEY`");
    }

    private static final l b(ax.p245p2.d dVar, v vVar, String str, Bundle bundle) {
        ax.G0.q qVarD = d(dVar);
        ax.G0.r rVarE = e(vVar);
        l lVar = rVarE.f().get(str);
        if (lVar != null) {
            return lVar;
        }
        l lVarA = l.f.a(qVarD.b(str), bundle);
        rVarE.f().put(str, lVarA);
        return lVarA;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final <T extends ax.p245p2.d & v> void c(T t) {
        ax.p335uc.l.f(t, "<this>");
        androidx.lifecycle.d.b bVarB = t.getLifecycle().b();
        if (bVarB != androidx.lifecycle.d.b.INITIALIZED && bVarB != androidx.lifecycle.d.b.CREATED) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        if (t.getSavedStateRegistry().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
            ax.G0.q qVar = new ax.G0.q(t.getSavedStateRegistry(), t);
            t.getSavedStateRegistry().h("androidx.lifecycle.internal.SavedStateHandlesProvider", qVar);
            t.getLifecycle().a(new SavedStateHandleAttacher(qVar));
        }
    }

    public static final ax.G0.q d(ax.p245p2.d dVar) {
        ax.p335uc.l.f(dVar, "<this>");
        androidx.savedstate.a.c cVarC = dVar.getSavedStateRegistry().c("androidx.lifecycle.internal.SavedStateHandlesProvider");
        ax.G0.q qVar = cVarC instanceof ax.G0.q ? (ax.G0.q) cVarC : null;
        if (qVar != null) {
            return qVar;
        }
        throw new IllegalStateException("enableSavedStateHandles() wasn't called prior to createSavedStateHandle() call");
    }

    public static final ax.G0.r e(v vVar) {
        ax.p335uc.l.f(vVar, "<this>");
        ax.I0.c cVar = new ax.I0.c();
        cVar.a(w.b(ax.G0.r.class), d.q);
        return (ax.G0.r) new q(vVar, cVar.b()).b("androidx.lifecycle.internal.SavedStateHandlesVM", ax.G0.r.class);
    }
}
