package androidx.lifecycle;

import ax.Ec.C0795i;
import ax.Ec.InterfaceC0801l;
import ax.Ec.InterfaceC0815s0;
import ax.Ec.J;
import ax.Ec.K;
import ax.p111gc.t;
import ax.p335uc.v;

/* JADX INFO: loaded from: classes.dex */
final class RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 implements f {
    final /* synthetic */ v<InterfaceC0815s0> X;
    final /* synthetic */ J Y;
    final /* synthetic */ d.a Z;
    final /* synthetic */ InterfaceC0801l<t> k0;
    final /* synthetic */ ax.Nc.a l0;
    final /* synthetic */ ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> m0;
    final /* synthetic */ d.a q;

    @ax.p207mc.f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {171, 110}, m = "invokeSuspend")
    static final class a extends ax.p207mc.l implements ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> {
        Object k0;
        Object l0;
        int m0;
        final /* synthetic */ ax.Nc.a n0;
        final /* synthetic */ ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> o0;

        /* JADX INFO: renamed from: androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a, reason: collision with other inner class name */
        @ax.p207mc.f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
        static final class C0021a extends ax.p207mc.l implements ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> {
            int k0;
            private /* synthetic */ Object l0;
            final /* synthetic */ ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> m0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            C0021a(ax.p319tc.p<? super J, ? super ax.p175kc.e<? super t>, ? extends Object> pVar, ax.p175kc.e<? super C0021a> eVar) {
                super(2, eVar);
                this.m0 = pVar;
            }

            @Override // ax.p207mc.a
            public final ax.p175kc.e<t> g(Object obj, ax.p175kc.e<?> eVar) {
                C0021a c0021a = new C0021a(this.m0, eVar);
                c0021a.l0 = obj;
                return c0021a;
            }

            @Override // ax.p207mc.a
            public final Object p(Object obj) {
                Object objC = ax.p191lc.b.c();
                int i = this.k0;
                if (i == 0) {
                    ax.p111gc.o.b(obj);
                    J j = (J) this.l0;
                    ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> pVar = this.m0;
                    this.k0 = 1;
                    if (pVar.l(j, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ax.p111gc.o.b(obj);
                }
                return t.a;
            }

            @Override // ax.p319tc.p
            /* JADX INFO: renamed from: t, reason: merged with bridge method [inline-methods] */
            public final Object l(J j, ax.p175kc.e<? super t> eVar) {
                return ((C0021a) g(j, eVar)).p(t.a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        a(ax.Nc.a aVar, ax.p319tc.p<? super J, ? super ax.p175kc.e<? super t>, ? extends Object> pVar, ax.p175kc.e<? super a> eVar) {
            super(2, eVar);
            this.n0 = aVar;
            this.o0 = pVar;
        }

        @Override // ax.p207mc.a
        public final ax.p175kc.e<t> g(Object obj, ax.p175kc.e<?> eVar) {
            return new a(this.n0, this.o0, eVar);
        }

        @Override // ax.p207mc.a
        public final Object p(Object obj) throws Throwable {
            ax.Nc.a aVar;
            ax.p319tc.p<J, ax.p175kc.e<? super t>, Object> pVar;
            ax.Nc.a aVar2;
            Throwable th;
            Object objC = ax.p191lc.b.c();
            int i = this.m0;
            try {
                if (i == 0) {
                    ax.p111gc.o.b(obj);
                    aVar = this.n0;
                    pVar = this.o0;
                    this.k0 = aVar;
                    this.l0 = pVar;
                    this.m0 = 1;
                    if (aVar.a(null, this) != objC) {
                    }
                    return objC;
                }
                if (i != 1) {
                    if (i != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    aVar2 = (ax.Nc.a) this.k0;
                    try {
                        ax.p111gc.o.b(obj);
                        t tVar = t.a;
                        aVar2.c(null);
                        return t.a;
                    } catch (Throwable th2) {
                        th = th2;
                        aVar2.c(null);
                        throw th;
                    }
                }
                pVar = (ax.p319tc.p) this.l0;
                ax.Nc.a aVar3 = (ax.Nc.a) this.k0;
                ax.p111gc.o.b(obj);
                aVar = aVar3;
                C0021a c0021a = new C0021a(pVar, null);
                this.k0 = aVar;
                this.l0 = null;
                this.m0 = 2;
                if (K.b(c0021a, this) != objC) {
                    aVar2 = aVar;
                    t tVar2 = t.a;
                    aVar2.c(null);
                    return t.a;
                }
                return objC;
            } catch (Throwable th3) {
                aVar2 = aVar;
                th = th3;
                aVar2.c(null);
                throw th;
            }
        }

        @Override // ax.p319tc.p
        /* JADX INFO: renamed from: t, reason: merged with bridge method [inline-methods] */
        public final Object l(J j, ax.p175kc.e<? super t> eVar) {
            return ((a) g(j, eVar)).p(t.a);
        }
    }

    /* JADX WARN: Type inference failed for: r9v5, types: [T, ax.Ec.s0] */
    @Override // androidx.lifecycle.f
    public final void b(ax.G0.h hVar, d.a aVar) {
        ax.p335uc.l.f(hVar, "<anonymous parameter 0>");
        ax.p335uc.l.f(aVar, "event");
        if (aVar == this.q) {
            this.X.q = C0795i.d(this.Y, null, null, new a(this.l0, this.m0, null), 3, null);
            return;
        }
        if (aVar == this.Z) {
            InterfaceC0815s0 interfaceC0815s0 = this.X.q;
            if (interfaceC0815s0 != null) {
                InterfaceC0815s0.a.a(interfaceC0815s0, null, 1, null);
            }
            this.X.q = null;
        }
        if (aVar == d.a.ON_DESTROY) {
            InterfaceC0801l<t> interfaceC0801l = this.k0;
            ax.gc.n.a aVar2 = ax.p111gc.n.q;
            interfaceC0801l.c(ax.p111gc.n.a(t.a));
        }
    }
}
