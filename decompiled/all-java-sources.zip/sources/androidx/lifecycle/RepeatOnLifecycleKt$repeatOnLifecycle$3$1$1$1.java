package androidx.lifecycle;

import ax.Wa.t;
import ax.p138jb.v;
import ax.p278tb.C5688i;
import ax.p278tb.InterfaceC5694l;
import ax.p278tb.InterfaceC5708s0;
import ax.p278tb.J;
import ax.p278tb.K;

/* JADX INFO: loaded from: classes.dex */
final class RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 implements f {
    final /* synthetic */ v<InterfaceC5708s0> X;
    final /* synthetic */ J Y;
    final /* synthetic */ d.a Z;
    final /* synthetic */ InterfaceC5694l<t> h0;
    final /* synthetic */ ax.Cb.a i0;
    final /* synthetic */ ax.p124ib.p<J, ax.Za.d<? super t>, Object> j0;
    final /* synthetic */ d.a q;

    @ax.p026bb.f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {171, 110}, m = "invokeSuspend")
    static final class a extends ax.p026bb.l implements ax.p124ib.p<J, ax.Za.d<? super t>, Object> {
        Object h0;
        Object i0;
        int j0;
        final /* synthetic */ ax.Cb.a k0;
        final /* synthetic */ ax.p124ib.p<J, ax.Za.d<? super t>, Object> l0;

        /* JADX INFO: renamed from: androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a, reason: collision with other inner class name */
        @ax.p026bb.f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
        static final class C0020a extends ax.p026bb.l implements ax.p124ib.p<J, ax.Za.d<? super t>, Object> {
            int h0;
            private /* synthetic */ Object i0;
            final /* synthetic */ ax.p124ib.p<J, ax.Za.d<? super t>, Object> j0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            C0020a(ax.p124ib.p<? super J, ? super ax.Za.d<? super t>, ? extends Object> pVar, ax.Za.d<? super C0020a> dVar) {
                super(2, dVar);
                this.j0 = pVar;
            }

            @Override // ax.p026bb.a
            public final ax.Za.d<t> j(Object obj, ax.Za.d<?> dVar) {
                C0020a c0020a = new C0020a(this.j0, dVar);
                c0020a.i0 = obj;
                return c0020a;
            }

            @Override // ax.p026bb.a
            public final Object p(Object obj) {
                Object objC = ax.p012ab.b.c();
                int i = this.h0;
                if (i == 0) {
                    ax.Wa.o.b(obj);
                    J j = (J) this.i0;
                    ax.p124ib.p<J, ax.Za.d<? super t>, Object> pVar = this.j0;
                    this.h0 = 1;
                    if (pVar.g(j, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    ax.Wa.o.b(obj);
                }
                return t.a;
            }

            @Override // ax.p124ib.p
            /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
            public final Object g(J j, ax.Za.d<? super t> dVar) {
                return ((C0020a) j(j, dVar)).p(t.a);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        a(ax.Cb.a aVar, ax.p124ib.p<? super J, ? super ax.Za.d<? super t>, ? extends Object> pVar, ax.Za.d<? super a> dVar) {
            super(2, dVar);
            this.k0 = aVar;
            this.l0 = pVar;
        }

        @Override // ax.p026bb.a
        public final ax.Za.d<t> j(Object obj, ax.Za.d<?> dVar) {
            return new a(this.k0, this.l0, dVar);
        }

        @Override // ax.p026bb.a
        public final Object p(Object obj) throws Throwable {
            ax.Cb.a aVar;
            ax.p124ib.p<J, ax.Za.d<? super t>, Object> pVar;
            ax.Cb.a aVar2;
            Throwable th;
            Object objC = ax.p012ab.b.c();
            int i = this.j0;
            try {
                if (i == 0) {
                    ax.Wa.o.b(obj);
                    aVar = this.k0;
                    pVar = this.l0;
                    this.h0 = aVar;
                    this.i0 = pVar;
                    this.j0 = 1;
                    if (aVar.b(null, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i != 1) {
                        if (i != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        aVar2 = (ax.Cb.a) this.h0;
                        try {
                            ax.Wa.o.b(obj);
                            t tVar = t.a;
                            aVar2.c(null);
                            return t.a;
                        } catch (Throwable th2) {
                            th = th2;
                            aVar2.c(null);
                            throw th;
                        }
                    }
                    pVar = (ax.p124ib.p) this.i0;
                    ax.Cb.a aVar3 = (ax.Cb.a) this.h0;
                    ax.Wa.o.b(obj);
                    aVar = aVar3;
                }
                C0020a c0020a = new C0020a(pVar, null);
                this.h0 = aVar;
                this.i0 = null;
                this.j0 = 2;
                if (K.b(c0020a, this) == objC) {
                    return objC;
                }
                aVar2 = aVar;
                t tVar2 = t.a;
                aVar2.c(null);
                return t.a;
            } catch (Throwable th3) {
                aVar2 = aVar;
                th = th3;
                aVar2.c(null);
                throw th;
            }
        }

        @Override // ax.p124ib.p
        /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
        public final Object g(J j, ax.Za.d<? super t> dVar) {
            return ((a) j(j, dVar)).p(t.a);
        }
    }

    /* JADX WARN: Type inference failed for: r9v5, types: [T, ax.tb.s0] */
    @Override // androidx.lifecycle.f
    public final void d(ax.F0.g gVar, d.a aVar) {
        ax.p138jb.l.f(gVar, "<anonymous parameter 0>");
        ax.p138jb.l.f(aVar, "event");
        if (aVar == this.q) {
            this.X.q = C5688i.d(this.Y, null, null, new a(this.i0, this.j0, null), 3, null);
            return;
        }
        if (aVar == this.Z) {
            InterfaceC5708s0 interfaceC5708s0 = this.X.q;
            if (interfaceC5708s0 != null) {
                InterfaceC5708s0.a.a(interfaceC5708s0, null, 1, null);
            }
            this.X.q = null;
        }
        if (aVar == d.a.ON_DESTROY) {
            InterfaceC5694l<t> interfaceC5694l = this.h0;
            ax.Wa.n.a aVar2 = ax.Wa.n.q;
            interfaceC5694l.e(ax.Wa.n.a(t.a));
        }
    }
}
