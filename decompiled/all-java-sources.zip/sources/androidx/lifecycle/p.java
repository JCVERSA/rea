package androidx.lifecycle;

import android.app.Application;
import ax.F0.s;
import ax.F0.t;

/* JADX INFO: loaded from: classes.dex */
public class p {
    private final q a;
    private final b b;
    private final ax.H0.a c;

    public static class a extends c {
        public static final C0024a c = new C0024a(null);
        public static final ax.H0.a.b<Application> d = C0024a.C0025a.a;

        /* JADX INFO: renamed from: androidx.lifecycle.p$a$a, reason: collision with other inner class name */
        public static final class C0024a {

            /* JADX INFO: renamed from: androidx.lifecycle.p$a$a$a, reason: collision with other inner class name */
            private static final class C0025a implements ax.H0.a.b<Application> {
                public static final C0025a a = new C0025a();

                private C0025a() {
                }
            }

            private C0024a() {
            }

            public /* synthetic */ C0024a(ax.p138jb.g gVar) {
                this();
            }
        }
    }

    public interface b {
        <T extends o> T a(Class<T> cls);

        <T extends o> T b(Class<T> cls, ax.H0.a aVar);
    }

    public static class c implements b {
        public static final a a = new a(null);
        public static final ax.H0.a.b<String> b = a.C0026a.a;

        public static final class a {

            /* JADX INFO: renamed from: androidx.lifecycle.p$c$a$a, reason: collision with other inner class name */
            private static final class C0026a implements ax.H0.a.b<String> {
                public static final C0026a a = new C0026a();

                private C0026a() {
                }
            }

            private a() {
            }

            public /* synthetic */ a(ax.p138jb.g gVar) {
                this();
            }
        }
    }

    public static class d {
        public void a(o oVar) {
            ax.p138jb.l.f(oVar, "viewModel");
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public p(q qVar, b bVar) {
        this(qVar, bVar, null, 4, null);
        ax.p138jb.l.f(qVar, "store");
        ax.p138jb.l.f(bVar, "factory");
    }

    public <T extends o> T a(Class<T> cls) {
        ax.p138jb.l.f(cls, "modelClass");
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        return (T) b("androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public <T extends o> T b(String str, Class<T> cls) {
        T t;
        ax.p138jb.l.f(str, "key");
        ax.p138jb.l.f(cls, "modelClass");
        T t2 = (T) this.a.b(str);
        if (!cls.isInstance(t2)) {
            ax.H0.d dVar = new ax.H0.d(this.c);
            dVar.b(c.b, str);
            try {
                t = (T) this.b.b(cls, dVar);
            } catch (AbstractMethodError unused) {
                t = (T) this.b.a(cls);
            }
            this.a.d(str, t);
            return t;
        }
        Object obj = this.b;
        d dVar2 = obj instanceof d ? (d) obj : null;
        if (dVar2 != null) {
            ax.p138jb.l.c(t2);
            dVar2.a(t2);
        }
        ax.p138jb.l.d(t2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
        return t2;
    }

    public p(q qVar, b bVar, ax.H0.a aVar) {
        ax.p138jb.l.f(qVar, "store");
        ax.p138jb.l.f(bVar, "factory");
        ax.p138jb.l.f(aVar, "defaultCreationExtras");
        this.a = qVar;
        this.b = bVar;
        this.c = aVar;
    }

    public /* synthetic */ p(q qVar, b bVar, ax.H0.a aVar, int i, ax.p138jb.g gVar) {
        this(qVar, bVar, (i & 4) != 0 ? ax.H0.a.C0140a.b : aVar);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public p(t tVar, b bVar) {
        this(tVar.J(), bVar, s.a(tVar));
        ax.p138jb.l.f(tVar, "owner");
        ax.p138jb.l.f(bVar, "factory");
    }
}
