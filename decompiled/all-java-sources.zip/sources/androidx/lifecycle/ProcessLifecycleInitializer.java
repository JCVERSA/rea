package androidx.lifecycle;

import android.content.Context;
import ax.Xa.C5081l;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements ax.p058e1.a<ax.F0.g> {
    @Override // ax.p058e1.a
    public List<Class<? extends ax.p058e1.a<?>>> a() {
        return C5081l.f();
    }

    @Override // ax.p058e1.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public ax.F0.g b(Context context) {
        ax.p138jb.l.f(context, "context");
        androidx.startup.a aVarE = androidx.startup.a.e(context);
        ax.p138jb.l.e(aVarE, "getInstance(context)");
        if (!aVarE.g(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml".toString());
        }
        e.a(context);
        j.b bVar = j.l0;
        bVar.b(context);
        return bVar.a();
    }
}
