package androidx.lifecycle;

import android.content.Context;
import ax.p127hc.C2093o;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements ax.p309t2.a<ax.G0.h> {
    @Override // ax.p309t2.a
    public List<Class<? extends ax.p309t2.a<?>>> a() {
        return C2093o.j();
    }

    @Override // ax.p309t2.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public ax.G0.h b(Context context) {
        ax.p335uc.l.f(context, "context");
        androidx.startup.a aVarE = androidx.startup.a.e(context);
        ax.p335uc.l.e(aVarE, "getInstance(context)");
        if (!aVarE.g(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        e.a(context);
        j.b bVar = j.o0;
        bVar.b(context);
        return bVar.a();
    }
}
