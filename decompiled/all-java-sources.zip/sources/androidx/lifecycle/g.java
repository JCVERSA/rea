package androidx.lifecycle;

import android.annotation.SuppressLint;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class g extends d {
    public static final a j = new a(null);
    private final boolean b;
    private ax.p354w.a<ax.G0.g, b> c;
    private d.b d;
    private final WeakReference<ax.G0.h> e;
    private int f;
    private boolean g;
    private boolean h;
    private ArrayList<d.b> i;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(ax.p335uc.g gVar) {
            this();
        }

        public final d.b a(d.b bVar, d.b bVar2) {
            ax.p335uc.l.f(bVar, "state1");
            return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
        }
    }

    public static final class b {
        private d.b a;
        private f b;

        public b(ax.G0.g gVar, d.b bVar) {
            ax.p335uc.l.f(bVar, "initialState");
            ax.p335uc.l.c(gVar);
            this.b = h.f(gVar);
            this.a = bVar;
        }

        public final void a(ax.G0.h hVar, d.a aVar) {
            ax.p335uc.l.f(aVar, "event");
            d.b bVarK = aVar.k();
            this.a = g.j.a(this.a, bVarK);
            f fVar = this.b;
            ax.p335uc.l.c(hVar);
            fVar.b(hVar, aVar);
            this.a = bVarK;
        }

        public final d.b b() {
            return this.a;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public g(ax.G0.h hVar) {
        this(hVar, true);
        ax.p335uc.l.f(hVar, "provider");
    }

    private g(ax.G0.h hVar, boolean z) {
        this.b = z;
        this.c = new ax.p354w.a<>();
        this.d = d.b.INITIALIZED;
        this.i = new ArrayList<>();
        this.e = new WeakReference<>(hVar);
    }

    private final void d(ax.G0.h hVar) {
        Iterator<Map.Entry<ax.G0.g, b>> itDescendingIterator = this.c.descendingIterator();
        ax.p335uc.l.e(itDescendingIterator, "observerMap.descendingIterator()");
        while (itDescendingIterator.hasNext() && !this.h) {
            Map.Entry<ax.G0.g, b> next = itDescendingIterator.next();
            ax.p335uc.l.e(next, "next()");
            ax.G0.g key = next.getKey();
            b value = next.getValue();
            while (value.b().compareTo(this.d) > 0 && !this.h && this.c.contains(key)) {
                d.a aVarA = d.a.Companion.a(value.b());
                if (aVarA == null) {
                    throw new IllegalStateException("no event down from " + value.b());
                }
                l(aVarA.k());
                value.a(hVar, aVarA);
                k();
            }
        }
    }

    private final d.b e(ax.G0.g gVar) {
        b value;
        Map.Entry<ax.G0.g, b> entryO = this.c.o(gVar);
        d.b bVar = null;
        d.b bVarB = (entryO == null || (value = entryO.getValue()) == null) ? null : value.b();
        if (!this.i.isEmpty()) {
            ArrayList<d.b> arrayList = this.i;
            bVar = arrayList.get(arrayList.size() - 1);
        }
        a aVar = j;
        return aVar.a(aVar.a(this.d, bVarB), bVar);
    }

    @SuppressLint({"RestrictedApi"})
    private final void f(String str) {
        if (!this.b || ax.p338v.c.g().b()) {
            return;
        }
        throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
    }

    private final void g(ax.G0.h hVar) {
        ax.p354w.b<ax.G0.g, b>.d dVarG = this.c.g();
        ax.p335uc.l.e(dVarG, "observerMap.iteratorWithAdditions()");
        while (dVarG.hasNext() && !this.h) {
            Map.Entry next = dVarG.next();
            ax.G0.g gVar = (ax.G0.g) next.getKey();
            b bVar = (b) next.getValue();
            while (bVar.b().compareTo(this.d) < 0 && !this.h && this.c.contains(gVar)) {
                l(bVar.b());
                d.a aVarB = d.a.Companion.b(bVar.b());
                if (aVarB == null) {
                    throw new IllegalStateException("no event up from " + bVar.b());
                }
                bVar.a(hVar, aVarB);
                k();
            }
        }
    }

    private final boolean i() {
        if (this.c.size() == 0) {
            return true;
        }
        Map.Entry<ax.G0.g, b> entryE = this.c.e();
        ax.p335uc.l.c(entryE);
        d.b bVarB = entryE.getValue().b();
        Map.Entry<ax.G0.g, b> entryI = this.c.i();
        ax.p335uc.l.c(entryI);
        d.b bVarB2 = entryI.getValue().b();
        return bVarB == bVarB2 && this.d == bVarB2;
    }

    private final void j(d.b bVar) {
        d.b bVar2 = this.d;
        if (bVar2 == bVar) {
            return;
        }
        if (bVar2 == d.b.INITIALIZED && bVar == d.b.DESTROYED) {
            throw new IllegalStateException(("no event down from " + this.d + " in component " + this.e.get()).toString());
        }
        this.d = bVar;
        if (this.g || this.f != 0) {
            this.h = true;
            return;
        }
        this.g = true;
        n();
        this.g = false;
        if (this.d == d.b.DESTROYED) {
            this.c = new ax.p354w.a<>();
        }
    }

    private final void k() {
        ArrayList<d.b> arrayList = this.i;
        arrayList.remove(arrayList.size() - 1);
    }

    private final void l(d.b bVar) {
        this.i.add(bVar);
    }

    private final void n() {
        ax.G0.h hVar = this.e.get();
        if (hVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (!i()) {
            this.h = false;
            d.b bVar = this.d;
            Map.Entry<ax.G0.g, b> entryE = this.c.e();
            ax.p335uc.l.c(entryE);
            if (bVar.compareTo(entryE.getValue().b()) < 0) {
                d(hVar);
            }
            Map.Entry<ax.G0.g, b> entryI = this.c.i();
            if (!this.h && entryI != null && this.d.compareTo(entryI.getValue().b()) > 0) {
                g(hVar);
            }
        }
        this.h = false;
    }

    @Override // androidx.lifecycle.d
    public void a(ax.G0.g gVar) {
        ax.G0.h hVar;
        ax.p335uc.l.f(gVar, "observer");
        f("addObserver");
        d.b bVar = this.d;
        d.b bVar2 = d.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = d.b.INITIALIZED;
        }
        b bVar3 = new b(gVar, bVar2);
        if (this.c.m(gVar, bVar3) == null && (hVar = this.e.get()) != null) {
            boolean z = this.f != 0 || this.g;
            d.b bVarE = e(gVar);
            this.f++;
            while (bVar3.b().compareTo(bVarE) < 0 && this.c.contains(gVar)) {
                l(bVar3.b());
                d.a aVarB = d.a.Companion.b(bVar3.b());
                if (aVarB == null) {
                    throw new IllegalStateException("no event up from " + bVar3.b());
                }
                bVar3.a(hVar, aVarB);
                k();
                bVarE = e(gVar);
            }
            if (!z) {
                n();
            }
            this.f--;
        }
    }

    @Override // androidx.lifecycle.d
    public d.b b() {
        return this.d;
    }

    @Override // androidx.lifecycle.d
    public void c(ax.G0.g gVar) {
        ax.p335uc.l.f(gVar, "observer");
        f("removeObserver");
        this.c.n(gVar);
    }

    public void h(d.a aVar) {
        ax.p335uc.l.f(aVar, "event");
        f("handleLifecycleEvent");
        j(aVar.k());
    }

    public void m(d.b bVar) {
        ax.p335uc.l.f(bVar, "state");
        f("setCurrentState");
        j(bVar);
    }
}
