package androidx.lifecycle;

import android.annotation.SuppressLint;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class g extends d {
    public static final a j = new a(null);
    private final boolean b;
    private ax.p308w.a<ax.F0.f, b> c;
    private d.b d;
    private final WeakReference<ax.F0.g> e;
    private int f;
    private boolean g;
    private boolean h;
    private ArrayList<d.b> i;

    public static final class a {
        private a() {
        }

        public final d.b a(d.b bVar, d.b bVar2) {
            ax.p138jb.l.f(bVar, "state1");
            return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
        }

        public /* synthetic */ a(ax.p138jb.g gVar) {
            this();
        }
    }

    public static final class b {
        private d.b a;
        private f b;

        public b(ax.F0.f fVar, d.b bVar) {
            ax.p138jb.l.f(bVar, "initialState");
            ax.p138jb.l.c(fVar);
            this.b = h.f(fVar);
            this.a = bVar;
        }

        public final void a(ax.F0.g gVar, d.a aVar) {
            ax.p138jb.l.f(aVar, "event");
            d.b bVarH = aVar.h();
            this.a = g.j.a(this.a, bVarH);
            f fVar = this.b;
            ax.p138jb.l.c(gVar);
            fVar.d(gVar, aVar);
            this.a = bVarH;
        }

        public final d.b b() {
            return this.a;
        }
    }

    private g(ax.F0.g gVar, boolean z) {
        this.b = z;
        this.c = new ax.p308w.a<>();
        this.d = d.b.INITIALIZED;
        this.i = new ArrayList<>();
        this.e = new WeakReference<>(gVar);
    }

    private final void d(ax.F0.g gVar) {
        Iterator<Map.Entry<ax.F0.f, b>> itDescendingIterator = this.c.descendingIterator();
        ax.p138jb.l.e(itDescendingIterator, "observerMap.descendingIterator()");
        while (itDescendingIterator.hasNext() && !this.h) {
            Map.Entry<ax.F0.f, b> next = itDescendingIterator.next();
            ax.p138jb.l.e(next, "next()");
            ax.F0.f key = next.getKey();
            b value = next.getValue();
            while (value.b().compareTo(this.d) > 0 && !this.h && this.c.contains(key)) {
                d.a aVarA = d.a.Companion.a(value.b());
                if (aVarA == null) {
                    throw new IllegalStateException("no event down from " + value.b());
                }
                l(aVarA.h());
                value.a(gVar, aVarA);
                k();
            }
        }
    }

    private final d.b e(ax.F0.f fVar) {
        b value;
        Map.Entry<ax.F0.f, b> entryQ = this.c.q(fVar);
        d.b bVar = null;
        d.b bVarB = (entryQ == null || (value = entryQ.getValue()) == null) ? null : value.b();
        if (!this.i.isEmpty()) {
            ArrayList<d.b> arrayList = this.i;
            bVar = arrayList.get(arrayList.size() - 1);
        }
        a aVar = j;
        return aVar.a(aVar.a(this.d, bVarB), bVar);
    }

    @SuppressLint({"RestrictedApi"})
    private final void f(String str) {
        if (!this.b || ax.p294v.c.g().b()) {
            return;
        }
        throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
    }

    private final void g(ax.F0.g gVar) {
        ax.p308w.b<ax.F0.f, b>.d dVarJ = this.c.j();
        ax.p138jb.l.e(dVarJ, "observerMap.iteratorWithAdditions()");
        while (dVarJ.hasNext() && !this.h) {
            Map.Entry next = dVarJ.next();
            ax.F0.f fVar = (ax.F0.f) next.getKey();
            b bVar = (b) next.getValue();
            while (bVar.b().compareTo(this.d) < 0 && !this.h && this.c.contains(fVar)) {
                l(bVar.b());
                d.a aVarB = d.a.Companion.b(bVar.b());
                if (aVarB == null) {
                    throw new IllegalStateException("no event up from " + bVar.b());
                }
                bVar.a(gVar, aVarB);
                k();
            }
        }
    }

    private final boolean i() {
        if (this.c.size() == 0) {
            return true;
        }
        Map.Entry<ax.F0.f, b> entryE = this.c.e();
        ax.p138jb.l.c(entryE);
        d.b bVarB = entryE.getValue().b();
        Map.Entry<ax.F0.f, b> entryM = this.c.m();
        ax.p138jb.l.c(entryM);
        d.b bVarB2 = entryM.getValue().b();
        return bVarB == bVarB2 && this.d == bVarB2;
    }

    private final void j(d.b bVar) {
        d.b bVar2 = this.d;
        if (bVar2 == bVar) {
            return;
        }
        if (bVar2 == d.b.INITIALIZED && bVar == d.b.DESTROYED) {
            throw new IllegalStateException(("no event down from " + this.d + " in component " + this.e.get()).toString());
        }
        this.d = bVar;
        if (this.g || this.f != 0) {
            this.h = true;
            return;
        }
        this.g = true;
        n();
        this.g = false;
        if (this.d == d.b.DESTROYED) {
            this.c = new ax.p308w.a<>();
        }
    }

    private final void k() {
        ArrayList<d.b> arrayList = this.i;
        arrayList.remove(arrayList.size() - 1);
    }

    private final void l(d.b bVar) {
        this.i.add(bVar);
    }

    private final void n() {
        ax.F0.g gVar = this.e.get();
        if (gVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (!i()) {
            this.h = false;
            d.b bVar = this.d;
            Map.Entry<ax.F0.f, b> entryE = this.c.e();
            ax.p138jb.l.c(entryE);
            if (bVar.compareTo(entryE.getValue().b()) < 0) {
                d(gVar);
            }
            Map.Entry<ax.F0.f, b> entryM = this.c.m();
            if (!this.h && entryM != null && this.d.compareTo(entryM.getValue().b()) > 0) {
                g(gVar);
            }
        }
        this.h = false;
    }

    @Override // androidx.lifecycle.d
    public void a(ax.F0.f fVar) {
        ax.F0.g gVar;
        ax.p138jb.l.f(fVar, "observer");
        f("addObserver");
        d.b bVar = this.d;
        d.b bVar2 = d.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = d.b.INITIALIZED;
        }
        b bVar3 = new b(fVar, bVar2);
        if (this.c.o(fVar, bVar3) == null && (gVar = this.e.get()) != null) {
            boolean z = this.f != 0 || this.g;
            d.b bVarE = e(fVar);
            this.f++;
            while (bVar3.b().compareTo(bVarE) < 0 && this.c.contains(fVar)) {
                l(bVar3.b());
                d.a aVarB = d.a.Companion.b(bVar3.b());
                if (aVarB == null) {
                    throw new IllegalStateException("no event up from " + bVar3.b());
                }
                bVar3.a(gVar, aVarB);
                k();
                bVarE = e(fVar);
            }
            if (!z) {
                n();
            }
            this.f--;
        }
    }

    @Override // androidx.lifecycle.d
    public d.b b() {
        return this.d;
    }

    @Override // androidx.lifecycle.d
    public void c(ax.F0.f fVar) {
        ax.p138jb.l.f(fVar, "observer");
        f("removeObserver");
        this.c.p(fVar);
    }

    public void h(d.a aVar) {
        ax.p138jb.l.f(aVar, "event");
        f("handleLifecycleEvent");
        j(aVar.h());
    }

    public void m(d.b bVar) {
        ax.p138jb.l.f(bVar, "state");
        f("setCurrentState");
        j(bVar);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public g(ax.F0.g gVar) {
        this(gVar, true);
        ax.p138jb.l.f(gVar, "provider");
    }
}
