package androidx.profileinstaller;

/* JADX INFO: loaded from: classes.dex */
class k {
    final e a;
    final int b;
    final byte[] c;
    final boolean d;

    k(e eVar, int i, byte[] bArr, boolean z) {
        this.a = eVar;
        this.b = i;
        this.c = bArr;
        this.d = z;
    }
}
