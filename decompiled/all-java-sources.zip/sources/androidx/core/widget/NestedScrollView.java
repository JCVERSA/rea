package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import ax.p035c0.C;
import ax.p035c0.C1832a;
import ax.p035c0.C1839d0;
import ax.p035c0.C1860o;
import ax.p035c0.D;
import ax.p035c0.E;
import ax.p035c0.G;
import ax.p035c0.H;
import ax.p035c0.InterfaceC1862p;
import ax.p051d0.L;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements G, D {
    private static final float M0 = (float) (Math.log(0.78d) / Math.log(0.9d));
    private static final a N0 = new a();
    private static final int[] O0 = {R.attr.fillViewport};
    private int A0;
    private final int[] B0;
    private final int[] C0;
    private int D0;
    private int E0;
    private e F0;
    private final H G0;
    private final E H0;
    private float I0;
    private d J0;
    final c K0;
    C1860o L0;
    private long k0;
    private final Rect l0;
    private OverScroller m0;
    public EdgeEffect n0;
    public EdgeEffect o0;
    private int p0;
    private final float q;
    private boolean q0;
    private boolean r0;
    private View s0;
    private boolean t0;
    private VelocityTracker u0;
    private boolean v0;
    private boolean w0;
    private int x0;
    private int y0;
    private int z0;

    static class a extends C1832a {
        a() {
        }

        @Override // ax.p035c0.C1832a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            L.a(accessibilityEvent, nestedScrollView.getScrollX());
            L.b(accessibilityEvent, nestedScrollView.getScrollRange());
        }

        @Override // ax.p035c0.C1832a
        public void g(View view, ax.p051d0.H h) {
            int scrollRange;
            super.g(view, h);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            h.m0(ScrollView.class.getName());
            if (!nestedScrollView.isEnabled() || (scrollRange = nestedScrollView.getScrollRange()) <= 0) {
                return;
            }
            h.G0(true);
            if (nestedScrollView.getScrollY() > 0) {
                h.b(ax.d0.H.a.r);
                h.b(ax.d0.H.a.C);
            }
            if (nestedScrollView.getScrollY() < scrollRange) {
                h.b(ax.d0.H.a.q);
                h.b(ax.d0.H.a.E);
            }
        }

        @Override // ax.p035c0.C1832a
        public boolean j(View view, int i, Bundle bundle) {
            if (super.j(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            int height = nestedScrollView.getHeight();
            Rect rect = new Rect();
            if (nestedScrollView.getMatrix().isIdentity() && nestedScrollView.getGlobalVisibleRect(rect)) {
                height = rect.height();
            }
            if (i != 4096) {
                if (i == 8192 || i == 16908344) {
                    int iMax = Math.max(nestedScrollView.getScrollY() - ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (iMax == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.W(0, iMax, true);
                    return true;
                }
                if (i != 16908346) {
                    return false;
                }
            }
            int iMin = Math.min(nestedScrollView.getScrollY() + ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (iMin == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.W(0, iMin, true);
            return true;
        }
    }

    static class b {
        static boolean a(ViewGroup viewGroup) {
            return viewGroup.getClipToPadding();
        }
    }

    class c implements InterfaceC1862p {
        c() {
        }

        @Override // ax.p035c0.InterfaceC1862p
        public boolean a(float f) {
            if (f == 0.0f) {
                return false;
            }
            c();
            NestedScrollView.this.v((int) f);
            return true;
        }

        @Override // ax.p035c0.InterfaceC1862p
        public float b() {
            return -NestedScrollView.this.getVerticalScrollFactorCompat();
        }

        @Override // ax.p035c0.InterfaceC1862p
        public void c() {
            NestedScrollView.this.m0.abortAnimation();
        }
    }

    public interface d {
        void a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    static class e extends View.BaseSavedState {
        public static final Parcelable.Creator<e> CREATOR = new a();
        public int q;

        class a implements Parcelable.Creator<e> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public e[] newArray(int i) {
                return new e[i];
            }
        }

        e(Parcel parcel) {
            super(parcel);
            this.q = parcel.readInt();
        }

        e(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.q + "}";
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.q);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, ax.O.a.c);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.l0 = new Rect();
        this.q0 = true;
        this.r0 = false;
        this.s0 = null;
        this.t0 = false;
        this.w0 = true;
        this.A0 = -1;
        this.B0 = new int[2];
        this.C0 = new int[2];
        c cVar = new c();
        this.K0 = cVar;
        this.L0 = new C1860o(getContext(), cVar);
        this.n0 = ax.p115h0.d.a(context, attributeSet);
        this.o0 = ax.p115h0.d.a(context, attributeSet);
        this.q = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        B();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, O0, i, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.G0 = new H(this);
        this.H0 = new E(this);
        setNestedScrollingEnabled(true);
        C1839d0.l0(this, N0);
    }

    private void A() {
        VelocityTracker velocityTracker = this.u0;
        if (velocityTracker == null) {
            this.u0 = VelocityTracker.obtain();
        } else {
            velocityTracker.clear();
        }
    }

    private void B() {
        this.m0 = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.x0 = viewConfiguration.getScaledTouchSlop();
        this.y0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.z0 = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    private void C() {
        if (this.u0 == null) {
            this.u0 = VelocityTracker.obtain();
        }
    }

    private void D(int i, int i2) {
        this.p0 = i;
        this.A0 = i2;
        X(2, 0);
    }

    private boolean E(View view) {
        return !G(view, 0, getHeight());
    }

    private static boolean F(View view, View view2) {
        if (view == view2) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && F((View) parent, view2);
    }

    private boolean G(View view, int i, int i2) {
        view.getDrawingRect(this.l0);
        offsetDescendantRectToMyCoords(view, this.l0);
        return this.l0.bottom + i >= getScrollY() && this.l0.top - i <= getScrollY() + i2;
    }

    private void H(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.H0.e(0, scrollY2, 0, i - scrollY2, null, i2, iArr);
    }

    private void I(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.A0) {
            int i = actionIndex == 0 ? 1 : 0;
            this.p0 = (int) motionEvent.getY(i);
            this.A0 = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.u0;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private void L() {
        VelocityTracker velocityTracker = this.u0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.u0 = null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0061  */
    private int M(int i, float f) {
        float fD;
        int iRound;
        float width = f / getWidth();
        float height = i / getHeight();
        float f2 = 0.0f;
        if (ax.p115h0.d.b(this.n0) == 0.0f) {
            if (ax.p115h0.d.b(this.o0) != 0.0f) {
                fD = ax.p115h0.d.d(this.o0, height, 1.0f - width);
                if (ax.p115h0.d.b(this.o0) == 0.0f) {
                    this.o0.onRelease();
                }
            }
            iRound = Math.round(f2 * getHeight());
            if (iRound != 0) {
                invalidate();
            }
            return iRound;
        }
        fD = -ax.p115h0.d.d(this.n0, -height, width);
        if (ax.p115h0.d.b(this.n0) == 0.0f) {
            this.n0.onRelease();
        }
        f2 = fD;
        iRound = Math.round(f2 * getHeight());
        if (iRound != 0) {
            invalidate();
        }
        return iRound;
    }

    private void N(boolean z) {
        if (z) {
            X(2, 1);
        } else {
            Z(1);
        }
        this.E0 = getScrollY();
        postInvalidateOnAnimation();
    }

    private boolean O(int i, int i2, int i3) {
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = height + scrollY;
        boolean z = false;
        boolean z2 = i == 33;
        View viewU = u(z2, i2, i3);
        if (viewU == null) {
            viewU = this;
        }
        if (i2 < scrollY || i3 > i4) {
            P(z2 ? i2 - scrollY : i3 - i4, 0, 1, true);
            z = true;
        }
        if (viewU != findFocus()) {
            viewU.requestFocus(i);
        }
        return z;
    }

    private int P(int i, int i2, int i3, boolean z) {
        int i4;
        int i5;
        VelocityTracker velocityTracker;
        if (i3 == 1) {
            X(2, i3);
        }
        boolean z2 = false;
        if (k(0, i, this.C0, this.B0, i3)) {
            int i6 = i - this.C0[1];
            i5 = this.B0[1];
            i4 = i6;
        } else {
            i4 = i;
            i5 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        boolean z3 = e() && !z;
        int i7 = i4;
        boolean z4 = J(0, i4, 0, scrollY, 0, scrollRange, 0, 0, true) && !y(i3);
        int scrollY2 = getScrollY() - scrollY;
        int[] iArr = this.C0;
        iArr[1] = 0;
        l(0, scrollY2, 0, i7 - scrollY2, this.B0, i3, iArr);
        int i8 = i5 + this.B0[1];
        int i9 = i7 - this.C0[1];
        int i10 = scrollY + i9;
        if (i10 < 0) {
            if (z3) {
                ax.p115h0.d.d(this.n0, (-i9) / getHeight(), i2 / getWidth());
                if (!this.o0.isFinished()) {
                    this.o0.onRelease();
                }
            }
        } else if (i10 > scrollRange && z3) {
            ax.p115h0.d.d(this.o0, i9 / getHeight(), 1.0f - (i2 / getWidth()));
            if (!this.n0.isFinished()) {
                this.n0.onRelease();
            }
        }
        if (this.n0.isFinished() && this.o0.isFinished()) {
            z2 = z4;
        } else {
            postInvalidateOnAnimation();
        }
        if (z2 && i3 == 0 && (velocityTracker = this.u0) != null) {
            velocityTracker.clear();
        }
        if (i3 == 1) {
            Z(i3);
            this.n0.onRelease();
            this.o0.onRelease();
        }
        return i8;
    }

    private void Q(View view) {
        view.getDrawingRect(this.l0);
        offsetDescendantRectToMyCoords(view, this.l0);
        int i = i(this.l0);
        if (i != 0) {
            scrollBy(0, i);
        }
    }

    private boolean R(Rect rect, boolean z) {
        int i = i(rect);
        boolean z2 = i != 0;
        if (z2) {
            if (z) {
                scrollBy(0, i);
                return z2;
            }
            T(0, i);
        }
        return z2;
    }

    private boolean S(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        return x(-i) < ax.p115h0.d.b(edgeEffect) * ((float) getHeight());
    }

    private void U(int i, int i2, int i3, boolean z) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.k0 > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.m0.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, height - height2))) - scrollY, i3);
            N(z);
        } else {
            if (!this.m0.isFinished()) {
                a();
            }
            scrollBy(i, i2);
        }
        this.k0 = AnimationUtils.currentAnimationTimeMillis();
    }

    private boolean Y(MotionEvent motionEvent) {
        boolean z;
        if (ax.p115h0.d.b(this.n0) != 0.0f) {
            ax.p115h0.d.d(this.n0, 0.0f, motionEvent.getX() / getWidth());
            z = true;
        } else {
            z = false;
        }
        if (ax.p115h0.d.b(this.o0) == 0.0f) {
            return z;
        }
        ax.p115h0.d.d(this.o0, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    private void a() {
        this.m0.abortAnimation();
        Z(1);
    }

    private boolean e() {
        int overScrollMode = getOverScrollMode();
        return overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0);
    }

    private boolean g() {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                return true;
            }
        }
        return false;
    }

    private static int h(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    private void q(int i) {
        if (i != 0) {
            if (this.w0) {
                T(0, i);
            } else {
                scrollBy(0, i);
            }
        }
    }

    private boolean r(int i) {
        if (ax.p115h0.d.b(this.n0) != 0.0f) {
            if (S(this.n0, i)) {
                this.n0.onAbsorb(i);
                return true;
            }
            v(-i);
            return true;
        }
        if (ax.p115h0.d.b(this.o0) == 0.0f) {
            return false;
        }
        int i2 = -i;
        if (S(this.o0, i2)) {
            this.o0.onAbsorb(i2);
            return true;
        }
        v(i2);
        return true;
    }

    private void s() {
        this.A0 = -1;
        this.t0 = false;
        L();
        Z(0);
        this.n0.onRelease();
        this.o0.onRelease();
    }

    /* JADX WARN: Code duplicated, block: B:29:0x004f  */
    private View u(boolean z, int i, int i2) {
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z2 = false;
        for (int i3 = 0; i3 < size; i3++) {
            View view2 = focusables.get(i3);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i < bottom && top < i2) {
                boolean z3 = i < top && bottom < i2;
                if (view == null) {
                    view = view2;
                    z2 = z3;
                } else {
                    boolean z4 = (z && top < view.getTop()) || (!z && bottom > view.getBottom());
                    if (z2) {
                        if (z3 && z4) {
                            view = view2;
                        }
                    } else if (z3) {
                        view = view2;
                        z2 = true;
                    } else if (z4) {
                        view = view2;
                    }
                }
            }
        }
        return view;
    }

    private float x(int i) {
        double dLog = Math.log((Math.abs(i) * 0.35f) / (this.q * 0.015f));
        float f = M0;
        return (float) (((double) (this.q * 0.015f)) * Math.exp((((double) f) / (((double) f) - 1.0d)) * dLog));
    }

    private boolean z(int i, int i2) {
        if (getChildCount() > 0) {
            int scrollY = getScrollY();
            View childAt = getChildAt(0);
            if (i2 >= childAt.getTop() - scrollY && i2 < childAt.getBottom() - scrollY && i >= childAt.getLeft() && i < childAt.getRight()) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:38:0x0056  */
    /* JADX WARN: Code duplicated, block: B:40:0x0059 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x005b  */
    /* JADX WARN: Code duplicated, block: B:42:0x005d  */
    /* JADX WARN: Code duplicated, block: B:44:0x0060  */
    /* JADX WARN: Code duplicated, block: B:47:0x007e  */
    /* JADX WARN: Code duplicated, block: B:50:0x0084 A[ADDED_TO_REGION] */
    boolean J(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, boolean z) {
        boolean z2;
        boolean z3;
        int i9;
        int overScrollMode = getOverScrollMode();
        boolean z4 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z5 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z6 = overScrollMode == 0 || (overScrollMode == 1 && z4);
        boolean z7 = overScrollMode == 0 || (overScrollMode == 1 && z5);
        int i10 = i3 + i;
        int i11 = !z6 ? 0 : i7;
        int i12 = i4 + i2;
        int i13 = !z7 ? 0 : i8;
        int i14 = -i11;
        int i15 = i11 + i5;
        int i16 = -i13;
        int i17 = i13 + i6;
        if (i10 <= i15) {
            if (i10 < i14) {
                i10 = i14;
            } else {
                z2 = false;
            }
            if (i12 > i17) {
                if (i12 < i16) {
                    i12 = i16;
                } else {
                    z3 = false;
                }
                if (z3 || y(1)) {
                    i9 = i10;
                } else {
                    int i18 = i10;
                    this.m0.springBack(i18, i12, 0, 0, 0, getScrollRange());
                    i9 = i18;
                }
                onOverScrolled(i9, i12, z2, z3);
                return !z2 || z3;
            }
            i12 = i17;
            z3 = true;
            if (z3) {
                i9 = i10;
            } else {
                i9 = i10;
            }
            onOverScrolled(i9, i12, z2, z3);
            if (z2) {
            }
        }
        i10 = i15;
        z2 = true;
        if (i12 > i17) {
            if (i12 < i16) {
                i12 = i16;
            } else {
                z3 = false;
            }
            if (z3) {
                i9 = i10;
            } else {
                i9 = i10;
            }
            onOverScrolled(i9, i12, z2, z3);
            if (z2) {
            }
        }
        i12 = i17;
        z3 = true;
        if (z3) {
            i9 = i10;
        } else {
            i9 = i10;
        }
        onOverScrolled(i9, i12, z2, z3);
        if (z2) {
        }
    }

    public boolean K(int i) {
        boolean z = i == 130;
        int height = getHeight();
        if (z) {
            this.l0.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
                Rect rect = this.l0;
                if (rect.top + height > bottom) {
                    rect.top = bottom - height;
                }
            }
        } else {
            this.l0.top = getScrollY() - height;
            Rect rect2 = this.l0;
            if (rect2.top < 0) {
                rect2.top = 0;
            }
        }
        Rect rect3 = this.l0;
        int i2 = rect3.top;
        int i3 = height + i2;
        rect3.bottom = i3;
        return O(i, i2, i3);
    }

    public final void T(int i, int i2) {
        U(i, i2, 250, false);
    }

    void V(int i, int i2, int i3, boolean z) {
        U(i - getScrollX(), i2 - getScrollY(), i3, z);
    }

    void W(int i, int i2, boolean z) {
        V(i, i2, 250, z);
    }

    public boolean X(int i, int i2) {
        return this.H0.p(i, i2);
    }

    public void Z(int i) {
        this.H0.r(i);
    }

    @Override // android.view.ViewGroup
    public void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i);
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i, layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, layoutParams);
    }

    public boolean c(int i) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !G(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            P(maxScrollAmount, 0, 1, true);
        } else {
            viewFindNextFocus.getDrawingRect(this.l0);
            offsetDescendantRectToMyCoords(viewFindNextFocus, this.l0);
            P(i(this.l0), 0, 1, true);
            viewFindNextFocus.requestFocus(i);
        }
        if (viewFindFocus != null && viewFindFocus.isFocused() && E(viewFindFocus)) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    @Override // android.view.View
    public void computeScroll() {
        if (this.m0.isFinished()) {
            return;
        }
        this.m0.computeScrollOffset();
        int currY = this.m0.getCurrY();
        int iJ = j(currY - this.E0);
        this.E0 = currY;
        int[] iArr = this.C0;
        iArr[1] = 0;
        k(0, iJ, iArr, null, 1);
        int i = iJ - this.C0[1];
        int scrollRange = getScrollRange();
        if (i != 0) {
            int scrollY = getScrollY();
            J(0, i, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
            int scrollY2 = getScrollY() - scrollY;
            int i2 = i - scrollY2;
            int[] iArr2 = this.C0;
            iArr2[1] = 0;
            l(0, scrollY2, 0, i2, this.B0, 1, iArr2);
            i = i2 - this.C0[1];
        }
        if (i != 0) {
            int overScrollMode = getOverScrollMode();
            if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                if (i < 0) {
                    if (this.n0.isFinished()) {
                        this.n0.onAbsorb((int) this.m0.getCurrVelocity());
                    }
                } else if (this.o0.isFinished()) {
                    this.o0.onAbsorb((int) this.m0.getCurrVelocity());
                }
            }
            a();
        }
        if (this.m0.isFinished()) {
            Z(1);
        } else {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? bottom + (scrollY - iMax) : bottom;
    }

    @Override // ax.p035c0.G
    public void d(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        H(i4, i5, iArr);
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || t(keyEvent);
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.H0.a(f, f2, z);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.H0.b(f, f2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return k(i, i2, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.H0.f(i, i2, i3, i4, iArr);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        int paddingLeft2 = 0;
        if (!this.n0.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (b.a(this)) {
                width -= getPaddingLeft() + getPaddingRight();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (b.a(this)) {
                height -= getPaddingTop() + getPaddingBottom();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            this.n0.setSize(width, height);
            if (this.n0.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        if (this.o0.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (b.a(this)) {
            width2 -= getPaddingLeft() + getPaddingRight();
            paddingLeft2 = getPaddingLeft();
        }
        if (b.a(this)) {
            height2 -= getPaddingTop() + getPaddingBottom();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        this.o0.setSize(width2, height2);
        if (this.o0.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // ax.p035c0.F
    public void f(View view, int i, int i2, int i3, int i4, int i5) {
        H(i4, i5, null);
    }

    @Override // android.view.View
    protected float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.G0.a();
    }

    int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    protected float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    float getVerticalScrollFactorCompat() {
        if (this.I0 == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.I0 = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.I0;
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return y(0);
    }

    protected int i(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i3 = rect.bottom;
        if (i3 > i2 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i2, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        }
        if (rect.top >= scrollY || i3 >= i2) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return this.H0.l();
    }

    int j(int i) {
        int height = getHeight();
        if (i > 0 && ax.p115h0.d.b(this.n0) != 0.0f) {
            int iRound = Math.round(((-height) / 4.0f) * ax.p115h0.d.d(this.n0, ((-i) * 4.0f) / height, 0.5f));
            if (iRound != i) {
                this.n0.finish();
            }
            return i - iRound;
        }
        if (i >= 0 || ax.p115h0.d.b(this.o0) == 0.0f) {
            return i;
        }
        float f = height;
        int iRound2 = Math.round((f / 4.0f) * ax.p115h0.d.d(this.o0, (i * 4.0f) / f, 0.5f));
        if (iRound2 != i) {
            this.o0.finish();
        }
        return i - iRound2;
    }

    public boolean k(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.H0.d(i, i2, iArr, iArr2, i3);
    }

    public void l(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        this.H0.e(i, i2, i3, i4, iArr, i5, iArr2);
    }

    @Override // ax.p035c0.F
    public boolean m(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    @Override // android.view.ViewGroup
    protected void measureChild(View view, int i, int i2) {
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    protected void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    @Override // ax.p035c0.F
    public void n(View view, View view2, int i, int i2) {
        this.G0.c(view, view2, i, i2);
        X(2, i2);
    }

    @Override // ax.p035c0.F
    public void o(View view, int i) {
        this.G0.e(view, i);
        Z(i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.r0 = false;
    }

    @Override // android.view.View
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i;
        float axisValue;
        int width;
        if (motionEvent.getAction() == 8 && !this.t0) {
            if (C.e(motionEvent, 2)) {
                i = 9;
                axisValue = motionEvent.getAxisValue(9);
                width = (int) motionEvent.getX();
            } else if (C.e(motionEvent, 4194304)) {
                axisValue = motionEvent.getAxisValue(26);
                width = getWidth() / 2;
                i = 26;
            } else {
                i = 0;
                axisValue = 0.0f;
                width = 0;
            }
            if (axisValue != 0.0f) {
                P(-((int) (axisValue * getVerticalScrollFactorCompat())), width, 1, C.e(motionEvent, 8194));
                if (i != 0) {
                    this.L0.g(motionEvent, i);
                }
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:31:0x007e  */
    /* JADX WARN: Code duplicated, block: B:33:0x009c  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z = true;
        if (action == 2 && this.t0) {
            return true;
        }
        int i = action & 255;
        if (i == 0) {
            int y = (int) motionEvent.getY();
            if (z((int) motionEvent.getX(), y)) {
                this.p0 = y;
                this.A0 = motionEvent.getPointerId(0);
                A();
                this.u0.addMovement(motionEvent);
                this.m0.computeScrollOffset();
                if (!Y(motionEvent) && this.m0.isFinished()) {
                    z = false;
                }
                this.t0 = z;
                X(2, 0);
            } else {
                if (!Y(motionEvent) && this.m0.isFinished()) {
                    z = false;
                }
                this.t0 = z;
                L();
            }
        } else if (i == 1) {
            this.t0 = false;
            this.A0 = -1;
            L();
            if (this.m0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            Z(0);
        } else if (i == 2) {
            int i2 = this.A0;
            if (i2 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i2);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i2 + " in onInterceptTouchEvent");
                } else {
                    int y2 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y2 - this.p0) > this.x0 && (2 & getNestedScrollAxes()) == 0) {
                        this.t0 = true;
                        this.p0 = y2;
                        C();
                        this.u0.addMovement(motionEvent);
                        this.D0 = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i == 3) {
            this.t0 = false;
            this.A0 = -1;
            L();
            if (this.m0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            Z(0);
        } else if (i == 6) {
            I(motionEvent);
        }
        return this.t0;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int measuredHeight = 0;
        this.q0 = false;
        View view = this.s0;
        if (view != null && F(view, this)) {
            Q(this.s0);
        }
        this.s0 = null;
        if (!this.r0) {
            if (this.F0 != null) {
                scrollTo(getScrollX(), this.F0.q);
                this.F0 = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iH = h(scrollY, paddingTop, measuredHeight);
            if (iH != scrollY) {
                scrollTo(getScrollX(), iH);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.r0 = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.v0 && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        v((int) f2);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        p(view, i, i2, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        H(i4, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i) {
        n(view, view2, i, 0);
    }

    @Override // android.view.View
    protected void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (viewFindNextFocus == null || E(viewFindNextFocus)) {
            return false;
        }
        return viewFindNextFocus.requestFocus(i, rect);
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e eVar = (e) parcelable;
        super.onRestoreInstanceState(eVar.getSuperState());
        this.F0 = eVar;
        requestLayout();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        e eVar = new e(super.onSaveInstanceState());
        eVar.q = getScrollY();
        return eVar;
    }

    @Override // android.view.View
    protected void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        d dVar = this.J0;
        if (dVar != null) {
            dVar.a(this, i, i2, i3, i4);
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !G(viewFindFocus, 0, i4)) {
            return;
        }
        viewFindFocus.getDrawingRect(this.l0);
        offsetDescendantRectToMyCoords(viewFindFocus, this.l0);
        q(i(this.l0));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i) {
        return m(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        o(view, 0);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        C();
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.D0 = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(0.0f, this.D0);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.u0;
                velocityTracker.computeCurrentVelocity(1000, this.z0);
                int yVelocity = (int) velocityTracker.getYVelocity(this.A0);
                if (Math.abs(yVelocity) >= this.y0) {
                    if (!r(yVelocity)) {
                        int i = -yVelocity;
                        float f = i;
                        if (!dispatchNestedPreFling(0.0f, f)) {
                            dispatchNestedFling(0.0f, f, true);
                            v(i);
                        }
                    }
                } else if (this.m0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                s();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.A0);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.A0 + " in onTouchEvent");
                } else {
                    int y = (int) motionEvent.getY(iFindPointerIndex);
                    int i2 = this.p0 - y;
                    int iM = i2 - M(i2, motionEvent.getX(iFindPointerIndex));
                    if (!this.t0 && Math.abs(iM) > this.x0) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.t0 = true;
                        iM = iM > 0 ? iM - this.x0 : iM + this.x0;
                    }
                    if (this.t0) {
                        int iP = P(iM, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.p0 = y - iP;
                        this.D0 += iP;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.t0 && getChildCount() > 0 && this.m0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                s();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.p0 = (int) motionEvent.getY(actionIndex);
                this.A0 = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                I(motionEvent);
                this.p0 = (int) motionEvent.getY(motionEvent.findPointerIndex(this.A0));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.t0 && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.m0.isFinished()) {
                a();
            }
            D((int) motionEvent.getY(), motionEvent.getPointerId(0));
        }
        VelocityTracker velocityTracker2 = this.u0;
        if (velocityTracker2 != null) {
            velocityTracker2.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    @Override // ax.p035c0.F
    public void p(View view, int i, int i2, int[] iArr, int i3) {
        k(i, i2, iArr, null, i3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (this.q0) {
            this.s0 = view2;
        } else {
            Q(view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        return R(rect, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            L();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        this.q0 = true;
        super.requestLayout();
    }

    @Override // android.view.View
    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int iH = h(i, width, width2);
            int iH2 = h(i2, height, height2);
            if (iH == getScrollX() && iH2 == getScrollY()) {
                return;
            }
            super.scrollTo(iH, iH2);
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.v0) {
            this.v0 = z;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z) {
        this.H0.m(z);
    }

    public void setOnScrollChangeListener(d dVar) {
        this.J0 = dVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.w0 = z;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i) {
        return X(i, 0);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        Z(0);
    }

    public boolean t(KeyEvent keyEvent) {
        this.l0.setEmpty();
        if (!g()) {
            if (isFocused() && keyEvent.getKeyCode() != 4) {
                View viewFindFocus = findFocus();
                if (viewFindFocus == this) {
                    viewFindFocus = null;
                }
                View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                if (viewFindNextFocus != null && viewFindNextFocus != this && viewFindNextFocus.requestFocus(130)) {
                    return true;
                }
            }
            return false;
        }
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 19) {
                return keyEvent.isAltPressed() ? w(33) : c(33);
            }
            if (keyCode == 20) {
                return keyEvent.isAltPressed() ? w(130) : c(130);
            }
            if (keyCode == 62) {
                K(keyEvent.isShiftPressed() ? 33 : 130);
                return false;
            }
            if (keyCode == 92) {
                return w(33);
            }
            if (keyCode == 93) {
                return w(130);
            }
            if (keyCode == 122) {
                K(33);
                return false;
            }
            if (keyCode == 123) {
                K(130);
                return false;
            }
        }
        return false;
    }

    public void v(int i) {
        if (getChildCount() > 0) {
            this.m0.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, SubsamplingScaleImageView.TILE_SIZE_AUTO, 0, 0);
            N(true);
        }
    }

    public boolean w(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.l0;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.l0.bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
            Rect rect2 = this.l0;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.l0;
        return O(i, rect3.top, rect3.bottom);
    }

    public boolean y(int i) {
        return this.H0.k(i);
    }
}
