package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import ax.p128j1.b;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements b {
    public IconCompat a;
    public CharSequence b;
    public CharSequence c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
