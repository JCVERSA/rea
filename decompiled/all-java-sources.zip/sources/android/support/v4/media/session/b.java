package android.support.v4.media.session;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import ax.p409z6.C3772df;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface b extends IInterface {

    public static abstract class a extends Binder implements b {

        /* JADX INFO: renamed from: android.support.v4.media.session.b$a$a, reason: collision with other inner class name */
        private static class C0006a implements b {
            private IBinder q;

            C0006a(IBinder iBinder) {
                this.q = iBinder;
            }

            @Override // android.support.v4.media.session.b
            public void C0(long j) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeLong(j);
                    this.q.transact(24, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void D3(Uri uri, Bundle bundle) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    C0007b.f(parcelObtain, uri, 0);
                    C0007b.f(parcelObtain, bundle, 0);
                    this.q.transact(16, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void G1(Uri uri, Bundle bundle) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    C0007b.f(parcelObtain, uri, 0);
                    C0007b.f(parcelObtain, bundle, 0);
                    this.q.transact(36, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void J() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(18, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void K(float f) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeFloat(f);
                    this.q.transact(49, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public int O0() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(47, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readInt();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public PlaybackStateCompat V() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(28, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (PlaybackStateCompat) C0007b.d(parcelObtain2, PlaybackStateCompat.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void X(int i) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeInt(i);
                    this.q.transact(39, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.q;
            }

            @Override // android.support.v4.media.session.b
            public void g3(android.support.v4.media.session.a aVar) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeStrongInterface(aVar);
                    this.q.transact(4, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public Bundle getExtras() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(31, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (Bundle) C0007b.d(parcelObtain2, Bundle.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void j0() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(13, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void next() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(20, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public int o0() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(37, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readInt();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void p0(int i) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeInt(i);
                    this.q.transact(48, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void previous() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(21, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void s1(android.support.v4.media.session.a aVar) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeStrongInterface(aVar);
                    this.q.transact(3, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public void stop() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(19, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public boolean t4(KeyEvent keyEvent) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    C0007b.f(parcelObtain, keyEvent, 0);
                    this.q.transact(2, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readInt() != 0;
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.support.v4.media.session.b
            public MediaMetadataCompat w0() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    this.q.transact(27, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (MediaMetadataCompat) C0007b.d(parcelObtain2, MediaMetadataCompat.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }
        }

        public a() {
            attachInterface(this, "android.support.v4.media.session.IMediaSession");
        }

        public static b M0(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof b)) ? new C0006a(iBinder) : (b) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface("android.support.v4.media.session.IMediaSession");
            }
            if (i == 1598968902) {
                parcel2.writeString("android.support.v4.media.session.IMediaSession");
                return true;
            }
            switch (i) {
                case 1:
                    a6(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR), (MediaSessionCompat.ResultReceiverWrapper) C0007b.d(parcel, MediaSessionCompat.ResultReceiverWrapper.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 2:
                    boolean zT4 = t4((KeyEvent) C0007b.d(parcel, KeyEvent.CREATOR));
                    parcel2.writeNoException();
                    parcel2.writeInt(zT4 ? 1 : 0);
                    return true;
                case 3:
                    s1(android.support.v4.media.session.a.AbstractBinderC0004a.M0(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 4:
                    g3(android.support.v4.media.session.a.AbstractBinderC0004a.M0(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 5:
                    boolean zT1 = T1();
                    parcel2.writeNoException();
                    parcel2.writeInt(zT1 ? 1 : 0);
                    return true;
                case 6:
                    String strD7 = D7();
                    parcel2.writeNoException();
                    parcel2.writeString(strD7);
                    return true;
                case 7:
                    String strH0 = h0();
                    parcel2.writeNoException();
                    parcel2.writeString(strH0);
                    return true;
                case 8:
                    PendingIntent pendingIntentZ1 = Z1();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, pendingIntentZ1, 1);
                    return true;
                case 9:
                    long jX0 = X0();
                    parcel2.writeNoException();
                    parcel2.writeLong(jX0);
                    return true;
                case 10:
                    ParcelableVolumeInfo parcelableVolumeInfoV6 = V6();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, parcelableVolumeInfoV6, 1);
                    return true;
                case 11:
                    F4(parcel.readInt(), parcel.readInt(), parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 12:
                    D1(parcel.readInt(), parcel.readInt(), parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 13:
                    j0();
                    parcel2.writeNoException();
                    return true;
                case 14:
                    n3(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 15:
                    u3(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 16:
                    D3((Uri) C0007b.d(parcel, Uri.CREATOR), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 17:
                    P6(parcel.readLong());
                    parcel2.writeNoException();
                    return true;
                case 18:
                    J();
                    parcel2.writeNoException();
                    return true;
                case 19:
                    stop();
                    parcel2.writeNoException();
                    return true;
                case 20:
                    next();
                    parcel2.writeNoException();
                    return true;
                case C3772df.zzm /* 21 */:
                    previous();
                    parcel2.writeNoException();
                    return true;
                case 22:
                    y3();
                    parcel2.writeNoException();
                    return true;
                case 23:
                    r6();
                    parcel2.writeNoException();
                    return true;
                case 24:
                    C0(parcel.readLong());
                    parcel2.writeNoException();
                    return true;
                case 25:
                    y1((RatingCompat) C0007b.d(parcel, RatingCompat.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 26:
                    l1(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 27:
                    MediaMetadataCompat mediaMetadataCompatW0 = w0();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, mediaMetadataCompatW0, 1);
                    return true;
                case 28:
                    PlaybackStateCompat playbackStateCompatV = V();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, playbackStateCompatV, 1);
                    return true;
                case 29:
                    List<MediaSessionCompat.QueueItem> listF6 = f6();
                    parcel2.writeNoException();
                    C0007b.e(parcel2, listF6, 1);
                    return true;
                case 30:
                    CharSequence charSequenceR2 = R2();
                    parcel2.writeNoException();
                    if (charSequenceR2 != null) {
                        parcel2.writeInt(1);
                        TextUtils.writeToParcel(charSequenceR2, parcel2, 1);
                    } else {
                        parcel2.writeInt(0);
                    }
                    return true;
                case 31:
                    Bundle extras = getExtras();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, extras, 1);
                    return true;
                case 32:
                    int iF2 = f2();
                    parcel2.writeNoException();
                    parcel2.writeInt(iF2);
                    return true;
                case 33:
                    d0();
                    parcel2.writeNoException();
                    return true;
                case 34:
                    c3(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 35:
                    i2(parcel.readString(), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 36:
                    G1((Uri) C0007b.d(parcel, Uri.CREATOR), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 37:
                    int iO0 = o0();
                    parcel2.writeNoException();
                    parcel2.writeInt(iO0);
                    return true;
                case 38:
                    boolean zX1 = x1();
                    parcel2.writeNoException();
                    parcel2.writeInt(zX1 ? 1 : 0);
                    return true;
                case 39:
                    X(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 40:
                    R6(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 41:
                    V1((MediaDescriptionCompat) C0007b.d(parcel, MediaDescriptionCompat.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 42:
                    L4((MediaDescriptionCompat) C0007b.d(parcel, MediaDescriptionCompat.CREATOR), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 43:
                    Q1((MediaDescriptionCompat) C0007b.d(parcel, MediaDescriptionCompat.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 44:
                    y5(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 45:
                    boolean zB5 = B5();
                    parcel2.writeNoException();
                    parcel2.writeInt(zB5 ? 1 : 0);
                    return true;
                case 46:
                    R4(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 47:
                    int iO1 = O0();
                    parcel2.writeNoException();
                    parcel2.writeInt(iO1);
                    return true;
                case 48:
                    p0(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 49:
                    K(parcel.readFloat());
                    parcel2.writeNoException();
                    return true;
                case 50:
                    Bundle bundleF3 = f3();
                    parcel2.writeNoException();
                    C0007b.f(parcel2, bundleF3, 1);
                    return true;
                case 51:
                    I4((RatingCompat) C0007b.d(parcel, RatingCompat.CREATOR), (Bundle) C0007b.d(parcel, Bundle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    /* JADX INFO: renamed from: android.support.v4.media.session.b$b, reason: collision with other inner class name */
    public static class C0007b {
        /* JADX INFO: Access modifiers changed from: private */
        public static <T> T d(Parcel parcel, Parcelable.Creator<T> creator) {
            if (parcel.readInt() != 0) {
                return creator.createFromParcel(parcel);
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static <T extends Parcelable> void e(Parcel parcel, List<T> list, int i) {
            if (list == null) {
                parcel.writeInt(-1);
                return;
            }
            int size = list.size();
            parcel.writeInt(size);
            for (int i2 = 0; i2 < size; i2++) {
                f(parcel, list.get(i2), i);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static <T extends Parcelable> void f(Parcel parcel, T t, int i) {
            if (t == null) {
                parcel.writeInt(0);
            } else {
                parcel.writeInt(1);
                t.writeToParcel(parcel, i);
            }
        }
    }

    boolean B5() throws RemoteException;

    void C0(long j) throws RemoteException;

    void D1(int i, int i2, String str) throws RemoteException;

    void D3(Uri uri, Bundle bundle) throws RemoteException;

    String D7() throws RemoteException;

    void F4(int i, int i2, String str) throws RemoteException;

    void G1(Uri uri, Bundle bundle) throws RemoteException;

    void I4(RatingCompat ratingCompat, Bundle bundle) throws RemoteException;

    void J() throws RemoteException;

    void K(float f) throws RemoteException;

    void L4(MediaDescriptionCompat mediaDescriptionCompat, int i) throws RemoteException;

    int O0() throws RemoteException;

    void P6(long j) throws RemoteException;

    void Q1(MediaDescriptionCompat mediaDescriptionCompat) throws RemoteException;

    CharSequence R2() throws RemoteException;

    void R4(boolean z) throws RemoteException;

    void R6(boolean z) throws RemoteException;

    boolean T1() throws RemoteException;

    PlaybackStateCompat V() throws RemoteException;

    void V1(MediaDescriptionCompat mediaDescriptionCompat) throws RemoteException;

    ParcelableVolumeInfo V6() throws RemoteException;

    void X(int i) throws RemoteException;

    long X0() throws RemoteException;

    PendingIntent Z1() throws RemoteException;

    void a6(String str, Bundle bundle, MediaSessionCompat.ResultReceiverWrapper resultReceiverWrapper) throws RemoteException;

    void c3(String str, Bundle bundle) throws RemoteException;

    void d0() throws RemoteException;

    int f2() throws RemoteException;

    Bundle f3() throws RemoteException;

    List<MediaSessionCompat.QueueItem> f6() throws RemoteException;

    void g3(android.support.v4.media.session.a aVar) throws RemoteException;

    Bundle getExtras() throws RemoteException;

    String h0() throws RemoteException;

    void i2(String str, Bundle bundle) throws RemoteException;

    void j0() throws RemoteException;

    void l1(String str, Bundle bundle) throws RemoteException;

    void n3(String str, Bundle bundle) throws RemoteException;

    void next() throws RemoteException;

    int o0() throws RemoteException;

    void p0(int i) throws RemoteException;

    void previous() throws RemoteException;

    void r6() throws RemoteException;

    void s1(android.support.v4.media.session.a aVar) throws RemoteException;

    void stop() throws RemoteException;

    boolean t4(KeyEvent keyEvent) throws RemoteException;

    void u3(String str, Bundle bundle) throws RemoteException;

    MediaMetadataCompat w0() throws RemoteException;

    boolean x1() throws RemoteException;

    void y1(RatingCompat ratingCompat) throws RemoteException;

    void y3() throws RemoteException;

    void y5(int i) throws RemoteException;
}
