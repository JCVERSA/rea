package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
    final long X;
    final long Y;
    final float Z;
    final long h0;
    final int i0;
    final CharSequence j0;
    final long k0;
    List<CustomAction> l0;
    final long m0;
    final Bundle n0;
    private PlaybackState o0;
    final int q;

    class a implements Parcelable.Creator<PlaybackStateCompat> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    }

    private static class b {
        static void a(PlaybackState.Builder builder, PlaybackState.CustomAction customAction) {
            builder.addCustomAction(customAction);
        }

        static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder builder) {
            return builder.build();
        }

        static PlaybackState c(PlaybackState.Builder builder) {
            return builder.build();
        }

        static PlaybackState.Builder d() {
            return new PlaybackState.Builder();
        }

        static PlaybackState.CustomAction.Builder e(String str, CharSequence charSequence, int i) {
            return new PlaybackState.CustomAction.Builder(str, charSequence, i);
        }

        static String f(PlaybackState.CustomAction customAction) {
            return customAction.getAction();
        }

        static long g(PlaybackState playbackState) {
            return playbackState.getActions();
        }

        static long h(PlaybackState playbackState) {
            return playbackState.getActiveQueueItemId();
        }

        static long i(PlaybackState playbackState) {
            return playbackState.getBufferedPosition();
        }

        static List<PlaybackState.CustomAction> j(PlaybackState playbackState) {
            return playbackState.getCustomActions();
        }

        static CharSequence k(PlaybackState playbackState) {
            return playbackState.getErrorMessage();
        }

        static Bundle l(PlaybackState.CustomAction customAction) {
            return customAction.getExtras();
        }

        static int m(PlaybackState.CustomAction customAction) {
            return customAction.getIcon();
        }

        static long n(PlaybackState playbackState) {
            return playbackState.getLastPositionUpdateTime();
        }

        static CharSequence o(PlaybackState.CustomAction customAction) {
            return customAction.getName();
        }

        static float p(PlaybackState playbackState) {
            return playbackState.getPlaybackSpeed();
        }

        static long q(PlaybackState playbackState) {
            return playbackState.getPosition();
        }

        static int r(PlaybackState playbackState) {
            return playbackState.getState();
        }

        static void s(PlaybackState.Builder builder, long j) {
            builder.setActions(j);
        }

        static void t(PlaybackState.Builder builder, long j) {
            builder.setActiveQueueItemId(j);
        }

        static void u(PlaybackState.Builder builder, long j) {
            builder.setBufferedPosition(j);
        }

        static void v(PlaybackState.Builder builder, CharSequence charSequence) {
            builder.setErrorMessage(charSequence);
        }

        static void w(PlaybackState.CustomAction.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }

        static void x(PlaybackState.Builder builder, int i, long j, float f, long j2) {
            builder.setState(i, j, f, j2);
        }
    }

    private static class c {
        static Bundle a(PlaybackState playbackState) {
            return playbackState.getExtras();
        }

        static void b(PlaybackState.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }
    }

    PlaybackStateCompat(int i, long j, long j2, float f, long j3, int i2, CharSequence charSequence, long j4, List<CustomAction> list, long j5, Bundle bundle) {
        this.q = i;
        this.X = j;
        this.Y = j2;
        this.Z = f;
        this.h0 = j3;
        this.i0 = i2;
        this.j0 = charSequence;
        this.k0 = j4;
        this.l0 = new ArrayList(list);
        this.m0 = j5;
        this.n0 = bundle;
    }

    public static PlaybackStateCompat a(Object obj) {
        ArrayList arrayList;
        Bundle bundleA = null;
        if (obj == null) {
            return null;
        }
        PlaybackState playbackState = (PlaybackState) obj;
        List<PlaybackState.CustomAction> listJ = b.j(playbackState);
        if (listJ != null) {
            ArrayList arrayList2 = new ArrayList(listJ.size());
            Iterator<PlaybackState.CustomAction> it = listJ.iterator();
            while (it.hasNext()) {
                arrayList2.add(CustomAction.a(it.next()));
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        if (Build.VERSION.SDK_INT >= 22) {
            bundleA = c.a(playbackState);
            MediaSessionCompat.a(bundleA);
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(b.r(playbackState), b.q(playbackState), b.i(playbackState), b.p(playbackState), b.g(playbackState), 0, b.k(playbackState), b.n(playbackState), arrayList, b.h(playbackState), bundleA);
        playbackStateCompat.o0 = playbackState;
        return playbackStateCompat;
    }

    public long b() {
        return this.h0;
    }

    public CharSequence c() {
        return this.j0;
    }

    public long d() {
        return this.k0;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public float e() {
        return this.Z;
    }

    public Object f() {
        if (this.o0 == null) {
            PlaybackState.Builder builderD = b.d();
            b.x(builderD, this.q, this.X, this.Z, this.k0);
            b.u(builderD, this.Y);
            b.s(builderD, this.h0);
            b.v(builderD, this.j0);
            Iterator<CustomAction> it = this.l0.iterator();
            while (it.hasNext()) {
                b.a(builderD, (PlaybackState.CustomAction) it.next().b());
            }
            b.t(builderD, this.m0);
            if (Build.VERSION.SDK_INT >= 22) {
                c.b(builderD, this.n0);
            }
            this.o0 = b.c(builderD);
        }
        return this.o0;
    }

    public long g() {
        return this.X;
    }

    public int h() {
        return this.q;
    }

    public String toString() {
        return "PlaybackState {state=" + this.q + ", position=" + this.X + ", buffered position=" + this.Y + ", speed=" + this.Z + ", updated=" + this.k0 + ", actions=" + this.h0 + ", error code=" + this.i0 + ", error message=" + this.j0 + ", custom actions=" + this.l0 + ", active item id=" + this.m0 + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.q);
        parcel.writeLong(this.X);
        parcel.writeFloat(this.Z);
        parcel.writeLong(this.k0);
        parcel.writeLong(this.Y);
        parcel.writeLong(this.h0);
        TextUtils.writeToParcel(this.j0, parcel, i);
        parcel.writeTypedList(this.l0);
        parcel.writeLong(this.m0);
        parcel.writeBundle(this.n0);
        parcel.writeInt(this.i0);
    }

    public static final class d {
        private final List<CustomAction> a;
        private int b;
        private long c;
        private long d;
        private float e;
        private long f;
        private int g;
        private CharSequence h;
        private long i;
        private long j;
        private Bundle k;

        public d() {
            this.a = new ArrayList();
            this.j = -1L;
        }

        public d a(CustomAction customAction) {
            if (customAction == null) {
                throw new IllegalArgumentException("You may not add a null CustomAction to PlaybackStateCompat");
            }
            this.a.add(customAction);
            return this;
        }

        public PlaybackStateCompat b() {
            return new PlaybackStateCompat(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.a, this.j, this.k);
        }

        public d c(long j) {
            this.f = j;
            return this;
        }

        public d d(long j) {
            this.j = j;
            return this;
        }

        @Deprecated
        public d e(CharSequence charSequence) {
            this.h = charSequence;
            return this;
        }

        public d f(int i, long j, float f, long j2) {
            this.b = i;
            this.c = j;
            this.i = j2;
            this.e = f;
            return this;
        }

        public d(PlaybackStateCompat playbackStateCompat) {
            ArrayList arrayList = new ArrayList();
            this.a = arrayList;
            this.j = -1L;
            this.b = playbackStateCompat.q;
            this.c = playbackStateCompat.X;
            this.e = playbackStateCompat.Z;
            this.i = playbackStateCompat.k0;
            this.d = playbackStateCompat.Y;
            this.f = playbackStateCompat.h0;
            this.g = playbackStateCompat.i0;
            this.h = playbackStateCompat.j0;
            List<CustomAction> list = playbackStateCompat.l0;
            if (list != null) {
                arrayList.addAll(list);
            }
            this.j = playbackStateCompat.m0;
            this.k = playbackStateCompat.n0;
        }
    }

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();
        private final CharSequence X;
        private final int Y;
        private final Bundle Z;
        private PlaybackState.CustomAction h0;
        private final String q;

        class a implements Parcelable.Creator<CustomAction> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public CustomAction[] newArray(int i) {
                return new CustomAction[i];
            }
        }

        public static final class b {
            private final String a;
            private final CharSequence b;
            private final int c;
            private Bundle d;

            public b(String str, CharSequence charSequence, int i) {
                if (TextUtils.isEmpty(str)) {
                    throw new IllegalArgumentException("You must specify an action to build a CustomAction");
                }
                if (TextUtils.isEmpty(charSequence)) {
                    throw new IllegalArgumentException("You must specify a name to build a CustomAction");
                }
                if (i == 0) {
                    throw new IllegalArgumentException("You must specify an icon resource id to build a CustomAction");
                }
                this.a = str;
                this.b = charSequence;
                this.c = i;
            }

            public CustomAction a() {
                return new CustomAction(this.a, this.b, this.c, this.d);
            }

            public b b(Bundle bundle) {
                this.d = bundle;
                return this;
            }
        }

        CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.q = str;
            this.X = charSequence;
            this.Y = i;
            this.Z = bundle;
        }

        public static CustomAction a(Object obj) {
            if (obj == null) {
                return null;
            }
            PlaybackState.CustomAction customAction = (PlaybackState.CustomAction) obj;
            Bundle bundleL = b.l(customAction);
            MediaSessionCompat.a(bundleL);
            CustomAction customAction2 = new CustomAction(b.f(customAction), b.o(customAction), b.m(customAction), bundleL);
            customAction2.h0 = customAction;
            return customAction2;
        }

        public Object b() {
            PlaybackState.CustomAction customAction = this.h0;
            if (customAction != null) {
                return customAction;
            }
            PlaybackState.CustomAction.Builder builderE = b.e(this.q, this.X, this.Y);
            b.w(builderE, this.Z);
            return b.b(builderE);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "Action:mName='" + ((Object) this.X) + ", mIcon=" + this.Y + ", mExtras=" + this.Z;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.q);
            TextUtils.writeToParcel(this.X, parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeBundle(this.Z);
        }

        CustomAction(Parcel parcel) {
            this.q = parcel.readString();
            this.X = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.Y = parcel.readInt();
            this.Z = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }
    }

    PlaybackStateCompat(Parcel parcel) {
        this.q = parcel.readInt();
        this.X = parcel.readLong();
        this.Z = parcel.readFloat();
        this.k0 = parcel.readLong();
        this.Y = parcel.readLong();
        this.h0 = parcel.readLong();
        this.j0 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.l0 = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.m0 = parcel.readLong();
        this.n0 = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.i0 = parcel.readInt();
    }
}
