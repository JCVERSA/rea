package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
    final long X;
    final long Y;
    final float Z;
    final long k0;
    final int l0;
    final CharSequence m0;
    final long n0;
    List<CustomAction> o0;
    final long p0;
    final int q;
    final Bundle q0;
    private PlaybackState r0;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();
        private final CharSequence X;
        private final int Y;
        private final Bundle Z;
        private PlaybackState.CustomAction k0;
        private final String q;

        class a implements Parcelable.Creator<CustomAction> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public CustomAction[] newArray(int i) {
                return new CustomAction[i];
            }
        }

        CustomAction(Parcel parcel) {
            this.q = parcel.readString();
            this.X = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.Y = parcel.readInt();
            this.Z = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.q = str;
            this.X = charSequence;
            this.Y = i;
            this.Z = bundle;
        }

        public static CustomAction a(Object obj) {
            if (obj == null) {
                return null;
            }
            PlaybackState.CustomAction customAction = (PlaybackState.CustomAction) obj;
            Bundle bundleL = b.l(customAction);
            MediaSessionCompat.a(bundleL);
            CustomAction customAction2 = new CustomAction(b.f(customAction), b.o(customAction), b.m(customAction), bundleL);
            customAction2.k0 = customAction;
            return customAction2;
        }

        public Object b() {
            PlaybackState.CustomAction customAction = this.k0;
            if (customAction != null) {
                return customAction;
            }
            PlaybackState.CustomAction.Builder builderE = b.e(this.q, this.X, this.Y);
            b.w(builderE, this.Z);
            return b.b(builderE);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "Action:mName='" + ((Object) this.X) + ", mIcon=" + this.Y + ", mExtras=" + this.Z;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.q);
            TextUtils.writeToParcel(this.X, parcel, i);
            parcel.writeInt(this.Y);
            parcel.writeBundle(this.Z);
        }
    }

    class a implements Parcelable.Creator<PlaybackStateCompat> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    }

    private static class b {
        static void a(PlaybackState.Builder builder, PlaybackState.CustomAction customAction) {
            builder.addCustomAction(customAction);
        }

        static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder builder) {
            return builder.build();
        }

        static PlaybackState c(PlaybackState.Builder builder) {
            return builder.build();
        }

        static PlaybackState.Builder d() {
            return new PlaybackState.Builder();
        }

        static PlaybackState.CustomAction.Builder e(String str, CharSequence charSequence, int i) {
            return new PlaybackState.CustomAction.Builder(str, charSequence, i);
        }

        static String f(PlaybackState.CustomAction customAction) {
            return customAction.getAction();
        }

        static long g(PlaybackState playbackState) {
            return playbackState.getActions();
        }

        static long h(PlaybackState playbackState) {
            return playbackState.getActiveQueueItemId();
        }

        static long i(PlaybackState playbackState) {
            return playbackState.getBufferedPosition();
        }

        static List<PlaybackState.CustomAction> j(PlaybackState playbackState) {
            return playbackState.getCustomActions();
        }

        static CharSequence k(PlaybackState playbackState) {
            return playbackState.getErrorMessage();
        }

        static Bundle l(PlaybackState.CustomAction customAction) {
            return customAction.getExtras();
        }

        static int m(PlaybackState.CustomAction customAction) {
            return customAction.getIcon();
        }

        static long n(PlaybackState playbackState) {
            return playbackState.getLastPositionUpdateTime();
        }

        static CharSequence o(PlaybackState.CustomAction customAction) {
            return customAction.getName();
        }

        static float p(PlaybackState playbackState) {
            return playbackState.getPlaybackSpeed();
        }

        static long q(PlaybackState playbackState) {
            return playbackState.getPosition();
        }

        static int r(PlaybackState playbackState) {
            return playbackState.getState();
        }

        static void s(PlaybackState.Builder builder, long j) {
            builder.setActions(j);
        }

        static void t(PlaybackState.Builder builder, long j) {
            builder.setActiveQueueItemId(j);
        }

        static void u(PlaybackState.Builder builder, long j) {
            builder.setBufferedPosition(j);
        }

        static void v(PlaybackState.Builder builder, CharSequence charSequence) {
            builder.setErrorMessage(charSequence);
        }

        static void w(PlaybackState.CustomAction.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }

        static void x(PlaybackState.Builder builder, int i, long j, float f, long j2) {
            builder.setState(i, j, f, j2);
        }
    }

    private static class c {
        static Bundle a(PlaybackState playbackState) {
            return playbackState.getExtras();
        }

        static void b(PlaybackState.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }
    }

    public static final class d {
        private final List<CustomAction> a;
        private int b;
        private long c;
        private long d;
        private float e;
        private long f;
        private int g;
        private CharSequence h;
        private long i;
        private long j;
        private Bundle k;

        public d() {
            this.a = new ArrayList();
            this.j = -1L;
        }

        public d(PlaybackStateCompat playbackStateCompat) {
            ArrayList arrayList = new ArrayList();
            this.a = arrayList;
            this.j = -1L;
            this.b = playbackStateCompat.q;
            this.c = playbackStateCompat.X;
            this.e = playbackStateCompat.Z;
            this.i = playbackStateCompat.n0;
            this.d = playbackStateCompat.Y;
            this.f = playbackStateCompat.k0;
            this.g = playbackStateCompat.l0;
            this.h = playbackStateCompat.m0;
            List<CustomAction> list = playbackStateCompat.o0;
            if (list != null) {
                arrayList.addAll(list);
            }
            this.j = playbackStateCompat.p0;
            this.k = playbackStateCompat.q0;
        }

        public PlaybackStateCompat a() {
            return new PlaybackStateCompat(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.a, this.j, this.k);
        }

        public d b(long j) {
            this.f = j;
            return this;
        }

        public d c(long j) {
            this.j = j;
            return this;
        }

        @Deprecated
        public d d(CharSequence charSequence) {
            this.h = charSequence;
            return this;
        }

        public d e(Bundle bundle) {
            this.k = bundle;
            return this;
        }

        public d f(int i, long j, float f, long j2) {
            this.b = i;
            this.c = j;
            this.i = j2;
            this.e = f;
            return this;
        }
    }

    PlaybackStateCompat(int i, long j, long j2, float f, long j3, int i2, CharSequence charSequence, long j4, List<CustomAction> list, long j5, Bundle bundle) {
        this.q = i;
        this.X = j;
        this.Y = j2;
        this.Z = f;
        this.k0 = j3;
        this.l0 = i2;
        this.m0 = charSequence;
        this.n0 = j4;
        this.o0 = new ArrayList(list);
        this.p0 = j5;
        this.q0 = bundle;
    }

    PlaybackStateCompat(Parcel parcel) {
        this.q = parcel.readInt();
        this.X = parcel.readLong();
        this.Z = parcel.readFloat();
        this.n0 = parcel.readLong();
        this.Y = parcel.readLong();
        this.k0 = parcel.readLong();
        this.m0 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.o0 = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.p0 = parcel.readLong();
        this.q0 = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.l0 = parcel.readInt();
    }

    public static PlaybackStateCompat a(Object obj) {
        ArrayList arrayList;
        Bundle bundleA = null;
        if (obj == null) {
            return null;
        }
        PlaybackState playbackState = (PlaybackState) obj;
        List<PlaybackState.CustomAction> listJ = b.j(playbackState);
        if (listJ != null) {
            ArrayList arrayList2 = new ArrayList(listJ.size());
            Iterator<PlaybackState.CustomAction> it = listJ.iterator();
            while (it.hasNext()) {
                arrayList2.add(CustomAction.a(it.next()));
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        if (Build.VERSION.SDK_INT >= 22) {
            bundleA = c.a(playbackState);
            MediaSessionCompat.a(bundleA);
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(b.r(playbackState), b.q(playbackState), b.i(playbackState), b.p(playbackState), b.g(playbackState), 0, b.k(playbackState), b.n(playbackState), arrayList, b.h(playbackState), bundleA);
        playbackStateCompat.r0 = playbackState;
        return playbackStateCompat;
    }

    public long b() {
        return this.k0;
    }

    public CharSequence c() {
        return this.m0;
    }

    public Bundle d() {
        return this.q0;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public long e() {
        return this.n0;
    }

    public float f() {
        return this.Z;
    }

    public Object h() {
        if (this.r0 == null) {
            PlaybackState.Builder builderD = b.d();
            b.x(builderD, this.q, this.X, this.Z, this.n0);
            b.u(builderD, this.Y);
            b.s(builderD, this.k0);
            b.v(builderD, this.m0);
            Iterator<CustomAction> it = this.o0.iterator();
            while (it.hasNext()) {
                b.a(builderD, (PlaybackState.CustomAction) it.next().b());
            }
            b.t(builderD, this.p0);
            if (Build.VERSION.SDK_INT >= 22) {
                c.b(builderD, this.q0);
            }
            this.r0 = b.c(builderD);
        }
        return this.r0;
    }

    public long i() {
        return this.X;
    }

    public int j() {
        return this.q;
    }

    public String toString() {
        return "PlaybackState {state=" + this.q + ", position=" + this.X + ", buffered position=" + this.Y + ", speed=" + this.Z + ", updated=" + this.n0 + ", actions=" + this.k0 + ", error code=" + this.l0 + ", error message=" + this.m0 + ", custom actions=" + this.o0 + ", active item id=" + this.p0 + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.q);
        parcel.writeLong(this.X);
        parcel.writeFloat(this.Z);
        parcel.writeLong(this.n0);
        parcel.writeLong(this.Y);
        parcel.writeLong(this.k0);
        TextUtils.writeToParcel(this.m0, parcel, i);
        parcel.writeTypedList(this.o0);
        parcel.writeLong(this.p0);
        parcel.writeBundle(this.q0);
        parcel.writeInt(this.l0);
    }
}
