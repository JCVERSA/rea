package ax.Ab;

/* JADX INFO: loaded from: classes2.dex */
public final class e extends g {
    public static final e a = new e();

    private e() {
    }

    @Override // ax.Ab.g
    public long a() {
        return System.nanoTime();
    }
}
