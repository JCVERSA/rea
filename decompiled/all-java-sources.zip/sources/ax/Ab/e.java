package ax.Ab;

import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class e extends h {
    public e(String str, String str2, boolean z) {
        this(HttpUrl.parse(str), HttpUrl.parse(str2), z);
    }

    public e(HttpUrl httpUrl, HttpUrl httpUrl2, boolean z) {
        e("Destination", httpUrl2.uri().toASCIIString());
        e("Overwrite", z ? "T" : "F");
        h(httpUrl);
    }

    @Override // ax.Ab.h
    public String c() {
        return "MOVE";
    }
}
