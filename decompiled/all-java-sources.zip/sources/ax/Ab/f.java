package ax.Ab;

import ax.p278tb.AbstractC5689i0;

/* JADX INFO: loaded from: classes2.dex */
public class f extends AbstractC5689i0 {
    private final int Z;
    private final int h0;
    private final long i0;
    private final String j0;
    private a k0 = a1();

    public f(int i, int i2, long j, String str) {
        this.Z = i;
        this.h0 = i2;
        this.i0 = j;
        this.j0 = str;
    }

    private final a a1() {
        return new a(this.Z, this.h0, this.i0, this.j0);
    }

    @Override // ax.p278tb.G
    public void N0(ax.Za.g gVar, Runnable runnable) {
        a.l(this.k0, runnable, null, false, 6, null);
    }

    public final void d1(Runnable runnable, i iVar, boolean z) {
        this.k0.k(runnable, iVar, z);
    }
}
