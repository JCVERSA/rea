package ax.Ab;

import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class f extends h {
    public f(String str) {
        this(HttpUrl.parse(str));
    }

    public f(HttpUrl httpUrl) {
        i("1");
        h(httpUrl);
    }

    @Override // ax.Ab.h
    public String c() {
        return "PROPFIND";
    }

    public f i(String str) {
        e("Depth", str);
        return this;
    }
}
