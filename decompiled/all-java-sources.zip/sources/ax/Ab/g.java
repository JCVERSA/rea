package ax.Ab;

import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class g extends h {
    public g(String str) {
        h(HttpUrl.parse(str));
    }

    @Override // ax.Ab.h
    public String c() {
        return "PUT";
    }
}
