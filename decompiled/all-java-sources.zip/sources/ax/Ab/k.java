package ax.Ab;

import ax.p278tb.N;

/* JADX INFO: loaded from: classes2.dex */
public final class k extends h {
    public final Runnable Y;

    public k(Runnable runnable, long j, i iVar) {
        super(j, iVar);
        this.Y = runnable;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            this.Y.run();
        } finally {
            this.X.a();
        }
    }

    public String toString() {
        return "Task[" + N.a(this.Y) + '@' + N.b(this.Y) + ", " + this.q + ", " + this.X + ']';
    }
}
