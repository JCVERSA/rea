package ax.Ab;

import ax.p278tb.G;
import ax.p348yb.C5812n;

/* JADX INFO: loaded from: classes2.dex */
final class m extends G {
    public static final m Y = new m();

    private m() {
    }

    @Override // ax.p278tb.G
    public void N0(ax.Za.g gVar, Runnable runnable) {
        c.l0.d1(runnable, l.h, false);
    }

    @Override // ax.p278tb.G
    public G Y0(int i) {
        C5812n.a(i);
        return i >= l.d ? this : super.Y0(i);
    }
}
