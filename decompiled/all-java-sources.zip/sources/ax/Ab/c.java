package ax.Ab;

import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class c extends h {
    public c(String str) {
        h(HttpUrl.parse(str));
    }

    @Override // ax.Ab.h
    public String c() {
        return "GET";
    }
}
