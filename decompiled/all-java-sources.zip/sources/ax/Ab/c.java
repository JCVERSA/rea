package ax.Ab;

/* JADX INFO: loaded from: classes2.dex */
public final class c extends f {
    public static final c l0 = new c();

    private c() {
        super(l.c, l.d, l.e, l.a);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    @Override // ax.p278tb.G
    public String toString() {
        return "Dispatchers.Default";
    }
}
