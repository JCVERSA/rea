package ax.Ab;

/* JADX INFO: loaded from: classes2.dex */
final class j implements i {
    private final int a;

    public j(int i) {
        this.a = i;
    }

    @Override // ax.Ab.i
    public int b() {
        return this.a;
    }

    @Override // ax.Ab.i
    public void a() {
    }
}
