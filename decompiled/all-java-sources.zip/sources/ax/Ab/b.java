package ax.Ab;

import ax.p278tb.AbstractC5689i0;
import ax.p278tb.G;
import ax.p348yb.I;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes2.dex */
public final class b extends AbstractC5689i0 implements Executor {
    public static final b Z = new b();
    private static final G h0 = m.Y.Y0(I.e("kotlinx.coroutines.io.parallelism", ax.p208ob.g.b(64, ax.p348yb.G.a()), 0, 0, 12, null));

    private b() {
    }

    @Override // ax.p278tb.G
    public void N0(ax.Za.g gVar, Runnable runnable) {
        h0.N0(gVar, runnable);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO".toString());
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable runnable) {
        N0(ax.Za.h.q, runnable);
    }

    @Override // ax.p278tb.G
    public String toString() {
        return "Dispatchers.IO";
    }
}
