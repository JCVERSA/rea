package ax.Ab;

import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class d extends h {
    public d(String str) {
        this(HttpUrl.parse(str));
    }

    public d(HttpUrl httpUrl) {
        h(httpUrl);
    }

    @Override // ax.Ab.h
    public String c() {
        return "MKCOL";
    }
}
