package ax.Ab;

import ax.p348yb.r;

/* JADX INFO: loaded from: classes2.dex */
public final class d extends r<h> {
    public d() {
        super(false);
    }
}
