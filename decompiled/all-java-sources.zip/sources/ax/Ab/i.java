package ax.Ab;

/* JADX INFO: loaded from: classes2.dex */
public interface i {
    void a();

    int b();
}
