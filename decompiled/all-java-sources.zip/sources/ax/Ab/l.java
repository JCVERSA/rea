package ax.Ab;

import ax.p348yb.G;
import ax.p348yb.I;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes2.dex */
public final class l {
    public static final String a = G.e("kotlinx.coroutines.scheduler.default.name", "DefaultDispatcher");
    public static final long b = I.f("kotlinx.coroutines.scheduler.resolution.ns", 100000, 0, 0, 12, null);
    public static final int c = I.e("kotlinx.coroutines.scheduler.core.pool.size", ax.p208ob.g.b(G.a(), 2), 1, 0, 8, null);
    public static final int d = I.e("kotlinx.coroutines.scheduler.max.pool.size", 2097150, 0, 2097150, 4, null);
    public static final long e = TimeUnit.SECONDS.toNanos(I.f("kotlinx.coroutines.scheduler.keep.alive.sec", 60, 0, 0, 12, null));
    public static g f = e.a;
    public static final i g = new j(0);
    public static final i h = new j(1);
}
