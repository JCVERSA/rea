package ax.Ab;

/* JADX INFO: loaded from: classes2.dex */
public abstract class h implements Runnable {
    public i X;
    public long q;

    public h(long j, i iVar) {
        this.q = j;
        this.X = iVar;
    }

    public h() {
        this(0L, l.g);
    }
}
