package ax.Ab;

import ax.Wa.t;
import ax.p138jb.v;
import ax.p278tb.C5676c;
import ax.p278tb.N;
import ax.p348yb.A;
import ax.p348yb.F;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;

/* JADX INFO: loaded from: classes2.dex */
public final class a implements Executor, Closeable {
    public static final C0057a k0 = new C0057a(null);
    private static final AtomicLongFieldUpdater l0 = AtomicLongFieldUpdater.newUpdater(a.class, "parkedWorkersStack");
    private static final AtomicLongFieldUpdater m0 = AtomicLongFieldUpdater.newUpdater(a.class, "controlState");
    private static final AtomicIntegerFieldUpdater n0 = AtomicIntegerFieldUpdater.newUpdater(a.class, "_isTerminated");
    public static final F o0 = new F("NOT_IN_STACK");
    public final int X;
    public final long Y;
    public final String Z;
    private volatile int _isTerminated;
    private volatile long controlState;
    public final ax.Ab.d h0;
    public final ax.Ab.d i0;
    public final A<c> j0;
    private volatile long parkedWorkersStack;
    public final int q;

    /* JADX INFO: renamed from: ax.Ab.a$a, reason: collision with other inner class name */
    public static final class C0057a {
        private C0057a() {
        }

        public /* synthetic */ C0057a(ax.p138jb.g gVar) {
            this();
        }
    }

    public /* synthetic */ class b {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[d.values().length];
            try {
                iArr[d.PARKING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[d.BLOCKING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[d.CPU_ACQUIRED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[d.DORMANT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[d.TERMINATED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            a = iArr;
        }
    }

    public enum d {
        CPU_ACQUIRED,
        BLOCKING,
        PARKING,
        DORMANT,
        TERMINATED
    }

    public a(int i, int i2, long j, String str) {
        this.q = i;
        this.X = i2;
        this.Y = j;
        this.Z = str;
        if (i < 1) {
            throw new IllegalArgumentException(("Core pool size " + i + " should be at least 1").toString());
        }
        if (i2 < i) {
            throw new IllegalArgumentException(("Max pool size " + i2 + " should be greater than or equals to core pool size " + i).toString());
        }
        if (i2 > 2097150) {
            throw new IllegalArgumentException(("Max pool size " + i2 + " should not exceed maximal supported number of threads 2097150").toString());
        }
        if (j <= 0) {
            throw new IllegalArgumentException(("Idle worker keep alive time " + j + " must be positive").toString());
        }
        this.h0 = new ax.Ab.d();
        this.i0 = new ax.Ab.d();
        this.j0 = new A<>((i + 1) * 2);
        this.controlState = ((long) i) << 42;
        this._isTerminated = 0;
    }

    private final void E(long j, boolean z) {
        if (z || R() || K(j)) {
            return;
        }
        R();
    }

    private final h G(c cVar, h hVar, boolean z) {
        if (cVar == null || cVar.Y == d.TERMINATED) {
            return hVar;
        }
        if (hVar.X.b() == 0 && cVar.Y == d.BLOCKING) {
            return hVar;
        }
        cVar.j0 = true;
        return cVar.q.a(hVar, z);
    }

    private final boolean K(long j) {
        if (ax.p208ob.g.b(((int) (2097151 & j)) - ((int) ((j & 4398044413952L) >> 21)), 0) < this.q) {
            int iF = f();
            if (iF == 1 && this.q > 1) {
                f();
            }
            if (iF > 0) {
                return true;
            }
        }
        return false;
    }

    static /* synthetic */ boolean M(a aVar, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            j = m0.get(aVar);
        }
        return aVar.K(j);
    }

    private final boolean R() {
        c cVarT;
        do {
            cVarT = t();
            if (cVarT == null) {
                return false;
            }
        } while (!c.j().compareAndSet(cVarT, -1, 0));
        LockSupport.unpark(cVarT);
        return true;
    }

    private final boolean d(h hVar) {
        return hVar.X.b() == 1 ? this.i0.a(hVar) : this.h0.a(hVar);
    }

    private final int f() {
        synchronized (this.j0) {
            try {
                if (isTerminated()) {
                    return -1;
                }
                AtomicLongFieldUpdater atomicLongFieldUpdater = m0;
                long j = atomicLongFieldUpdater.get(this);
                int i = (int) (j & 2097151);
                int iB = ax.p208ob.g.b(i - ((int) ((j & 4398044413952L) >> 21)), 0);
                if (iB >= this.q) {
                    return 0;
                }
                if (i >= this.X) {
                    return 0;
                }
                int i2 = ((int) (m0.get(this) & 2097151)) + 1;
                if (i2 <= 0 || this.j0.b(i2) != null) {
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }
                c cVar = new c(this, i2);
                this.j0.c(i2, cVar);
                if (i2 != ((int) (2097151 & atomicLongFieldUpdater.incrementAndGet(this)))) {
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }
                int i3 = iB + 1;
                cVar.start();
                return i3;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private final c j() {
        Thread threadCurrentThread = Thread.currentThread();
        c cVar = threadCurrentThread instanceof c ? (c) threadCurrentThread : null;
        if (cVar == null || !ax.p138jb.l.a(a.this, this)) {
            return null;
        }
        return cVar;
    }

    public static /* synthetic */ void l(a aVar, Runnable runnable, i iVar, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            iVar = l.g;
        }
        if ((i & 4) != 0) {
            z = false;
        }
        aVar.k(runnable, iVar, z);
    }

    private final int r(c cVar) {
        Object objI = cVar.i();
        while (objI != o0) {
            if (objI == null) {
                return 0;
            }
            c cVar2 = (c) objI;
            int iH = cVar2.h();
            if (iH != 0) {
                return iH;
            }
            objI = cVar2.i();
        }
        return -1;
    }

    private final c t() {
        AtomicLongFieldUpdater atomicLongFieldUpdater = l0;
        while (true) {
            long j = atomicLongFieldUpdater.get(this);
            c cVarB = this.j0.b((int) (2097151 & j));
            if (cVarB == null) {
                return null;
            }
            long j2 = (2097152 + j) & (-2097152);
            int iR = r(cVarB);
            if (iR >= 0 && l0.compareAndSet(this, j, ((long) iR) | j2)) {
                cVarB.r(o0);
                return cVarB;
            }
        }
    }

    public final void A(h hVar) {
        try {
            hVar.run();
        } catch (Throwable th) {
            try {
                Thread threadCurrentThread = Thread.currentThread();
                threadCurrentThread.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread, th);
            } finally {
                C5676c.a();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x005b  */
    public final void B(long j) throws InterruptedException {
        int i;
        h hVarD;
        if (n0.compareAndSet(this, 0, 1)) {
            c cVarJ = j();
            synchronized (this.j0) {
                i = (int) (m0.get(this) & 2097151);
            }
            if (1 <= i) {
                int i2 = 1;
                while (true) {
                    c cVarB = this.j0.b(i2);
                    ax.p138jb.l.c(cVarB);
                    c cVar = cVarB;
                    if (cVar != cVarJ) {
                        while (cVar.isAlive()) {
                            LockSupport.unpark(cVar);
                            cVar.join(j);
                        }
                        cVar.q.f(this.i0);
                    }
                    if (i2 == i) {
                        break;
                    } else {
                        i2++;
                    }
                }
            }
            this.i0.b();
            this.h0.b();
            while (true) {
                if (cVarJ == null) {
                    hVarD = this.h0.d();
                    if (hVarD == null && (hVarD = this.i0.d()) == null) {
                        break;
                    }
                } else {
                    hVarD = cVarJ.g(true);
                    if (hVarD == null) {
                        hVarD = this.h0.d();
                        if (hVarD == null) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }
                A(hVarD);
            }
            if (cVarJ != null) {
                cVarJ.u(d.TERMINATED);
            }
            l0.set(this, 0L);
            m0.set(this, 0L);
        }
    }

    public final void F() {
        if (R() || M(this, 0L, 1, null)) {
            return;
        }
        R();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws InterruptedException {
        B(10000L);
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable runnable) {
        l(this, runnable, null, false, 6, null);
    }

    public final h i(Runnable runnable, i iVar) {
        long jA = l.f.a();
        if (!(runnable instanceof h)) {
            return new k(runnable, jA, iVar);
        }
        h hVar = (h) runnable;
        hVar.q = jA;
        hVar.X = iVar;
        return hVar;
    }

    public final boolean isTerminated() {
        return n0.get(this) != 0;
    }

    public final void k(Runnable runnable, i iVar, boolean z) {
        C5676c.a();
        h hVarI = i(runnable, iVar);
        boolean z2 = false;
        boolean z3 = hVarI.X.b() == 1;
        long jAddAndGet = z3 ? m0.addAndGet(this, 2097152L) : 0L;
        c cVarJ = j();
        h hVarG = G(cVarJ, hVarI, z);
        if (hVarG != null && !d(hVarG)) {
            throw new RejectedExecutionException(this.Z + " was terminated");
        }
        if (z && cVarJ != null) {
            z2 = true;
        }
        if (z3) {
            E(jAddAndGet, z2);
        } else {
            if (z2) {
                return;
            }
            F();
        }
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        int iA = this.j0.a();
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 1; i6 < iA; i6++) {
            c cVarB = this.j0.b(i6);
            if (cVarB != null) {
                int iE = cVarB.q.e();
                int i7 = b.a[cVarB.Y.ordinal()];
                if (i7 == 1) {
                    i3++;
                } else if (i7 == 2) {
                    i2++;
                    StringBuilder sb = new StringBuilder();
                    sb.append(iE);
                    sb.append('b');
                    arrayList.add(sb.toString());
                } else if (i7 == 3) {
                    i++;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(iE);
                    sb2.append('c');
                    arrayList.add(sb2.toString());
                } else if (i7 == 4) {
                    i4++;
                    if (iE > 0) {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(iE);
                        sb3.append('d');
                        arrayList.add(sb3.toString());
                    }
                } else if (i7 == 5) {
                    i5++;
                }
            }
        }
        long j = m0.get(this);
        return this.Z + '@' + N.b(this) + "[Pool Size {core = " + this.q + ", max = " + this.X + "}, Worker States {CPU = " + i + ", blocking = " + i2 + ", parked = " + i3 + ", dormant = " + i4 + ", terminated = " + i5 + "}, running workers queues = " + arrayList + ", global CPU queue size = " + this.h0.c() + ", global blocking queue size = " + this.i0.c() + ", Control State {created workers= " + ((int) (2097151 & j)) + ", blocking tasks = " + ((int) ((4398044413952L & j) >> 21)) + ", CPUs acquired = " + (this.q - ((int) ((9223367638808264704L & j) >> 42))) + "}]";
    }

    public final boolean v(c cVar) {
        long j;
        int iH;
        if (cVar.i() != o0) {
            return false;
        }
        AtomicLongFieldUpdater atomicLongFieldUpdater = l0;
        do {
            j = atomicLongFieldUpdater.get(this);
            iH = cVar.h();
            cVar.r(this.j0.b((int) (2097151 & j)));
        } while (!l0.compareAndSet(this, j, ((2097152 + j) & (-2097152)) | ((long) iH)));
        return true;
    }

    public final void x(c cVar, int i, int i2) {
        AtomicLongFieldUpdater atomicLongFieldUpdater = l0;
        while (true) {
            long j = atomicLongFieldUpdater.get(this);
            int iR = (int) (2097151 & j);
            long j2 = (2097152 + j) & (-2097152);
            if (iR == i) {
                iR = i2 == 0 ? r(cVar) : i2;
            }
            if (iR >= 0 && l0.compareAndSet(this, j, j2 | ((long) iR))) {
                return;
            }
        }
    }

    public final class c extends Thread {
        private static final AtomicIntegerFieldUpdater l0 = AtomicIntegerFieldUpdater.newUpdater(c.class, "workerCtl");
        private final v<h> X;
        public d Y;
        private long Z;
        private long h0;
        private int i0;
        private volatile int indexInArray;
        public boolean j0;
        private volatile Object nextParkedWorker;
        public final n q;
        private volatile int workerCtl;

        private c() {
            setDaemon(true);
            this.q = new n();
            this.X = new v<>();
            this.Y = d.DORMANT;
            this.nextParkedWorker = a.o0;
            this.i0 = ax.p180mb.c.q.b();
        }

        private final void b(int i) {
            if (i == 0) {
                return;
            }
            a.m0.addAndGet(a.this, -2097152L);
            if (this.Y != d.TERMINATED) {
                this.Y = d.DORMANT;
            }
        }

        private final void c(int i) {
            if (i != 0 && u(d.BLOCKING)) {
                a.this.F();
            }
        }

        private final void d(h hVar) {
            int iB = hVar.X.b();
            k(iB);
            c(iB);
            a.this.A(hVar);
            b(iB);
        }

        private final h e(boolean z) {
            h hVarO;
            h hVarO2;
            if (z) {
                boolean z2 = m(a.this.q * 2) == 0;
                if (z2 && (hVarO2 = o()) != null) {
                    return hVarO2;
                }
                h hVarG = this.q.g();
                if (hVarG != null) {
                    return hVarG;
                }
                if (!z2 && (hVarO = o()) != null) {
                    return hVarO;
                }
            } else {
                h hVarO3 = o();
                if (hVarO3 != null) {
                    return hVarO3;
                }
            }
            return v(3);
        }

        private final h f() {
            h hVarH = this.q.h();
            if (hVarH != null) {
                return hVarH;
            }
            h hVarD = a.this.i0.d();
            return hVarD == null ? v(1) : hVarD;
        }

        public static final AtomicIntegerFieldUpdater j() {
            return l0;
        }

        private final void k(int i) {
            this.Z = 0L;
            if (this.Y == d.PARKING) {
                this.Y = d.BLOCKING;
            }
        }

        private final boolean l() {
            return this.nextParkedWorker != a.o0;
        }

        private final void n() {
            if (this.Z == 0) {
                this.Z = System.nanoTime() + a.this.Y;
            }
            LockSupport.parkNanos(a.this.Y);
            if (System.nanoTime() - this.Z >= 0) {
                this.Z = 0L;
                w();
            }
        }

        private final h o() {
            if (m(2) == 0) {
                h hVarD = a.this.h0.d();
                return hVarD != null ? hVarD : a.this.i0.d();
            }
            h hVarD2 = a.this.i0.d();
            return hVarD2 != null ? hVarD2 : a.this.h0.d();
        }

        private final void p() {
            loop0: while (true) {
                boolean z = false;
                while (true) {
                    if (a.this.isTerminated() || this.Y == d.TERMINATED) {
                        break loop0;
                    }
                    h hVarG = g(this.j0);
                    if (hVarG != null) {
                        this.h0 = 0L;
                        d(hVarG);
                        break;
                    }
                    this.j0 = false;
                    if (this.h0 == 0) {
                        t();
                    } else {
                        if (z) {
                            u(d.PARKING);
                            Thread.interrupted();
                            LockSupport.parkNanos(this.h0);
                            this.h0 = 0L;
                            break;
                        }
                        z = true;
                    }
                }
            }
            u(d.TERMINATED);
        }

        private final boolean s() {
            long j;
            if (this.Y == d.CPU_ACQUIRED) {
                return true;
            }
            a aVar = a.this;
            AtomicLongFieldUpdater atomicLongFieldUpdater = a.m0;
            do {
                j = atomicLongFieldUpdater.get(aVar);
                if (((int) ((9223367638808264704L & j) >> 42)) == 0) {
                    return false;
                }
            } while (!a.m0.compareAndSet(aVar, j, j - 4398046511104L));
            this.Y = d.CPU_ACQUIRED;
            return true;
        }

        private final void t() {
            if (!l()) {
                a.this.v(this);
                return;
            }
            l0.set(this, -1);
            while (l() && l0.get(this) == -1 && !a.this.isTerminated() && this.Y != d.TERMINATED) {
                u(d.PARKING);
                Thread.interrupted();
                n();
            }
        }

        private final h v(int i) {
            int i2 = (int) (a.m0.get(a.this) & 2097151);
            if (i2 < 2) {
                return null;
            }
            int iM = m(i2);
            a aVar = a.this;
            long jMin = Long.MAX_VALUE;
            for (int i3 = 0; i3 < i2; i3++) {
                iM++;
                if (iM > i2) {
                    iM = 1;
                }
                c cVarB = aVar.j0.b(iM);
                if (cVarB != null && cVarB != this) {
                    long jN = cVarB.q.n(i, this.X);
                    if (jN == -1) {
                        v<h> vVar = this.X;
                        h hVar = vVar.q;
                        vVar.q = null;
                        return hVar;
                    }
                    if (jN > 0) {
                        jMin = Math.min(jMin, jN);
                    }
                }
            }
            if (jMin == Long.MAX_VALUE) {
                jMin = 0;
            }
            this.h0 = jMin;
            return null;
        }

        private final void w() {
            a aVar = a.this;
            synchronized (aVar.j0) {
                try {
                    if (aVar.isTerminated()) {
                        return;
                    }
                    if (((int) (a.m0.get(aVar) & 2097151)) <= aVar.q) {
                        return;
                    }
                    if (l0.compareAndSet(this, -1, 1)) {
                        int i = this.indexInArray;
                        q(0);
                        aVar.x(this, i, 0);
                        int andDecrement = (int) (a.m0.getAndDecrement(aVar) & 2097151);
                        if (andDecrement != i) {
                            c cVarB = aVar.j0.b(andDecrement);
                            ax.p138jb.l.c(cVarB);
                            c cVar = cVarB;
                            aVar.j0.c(i, cVar);
                            cVar.q(i);
                            aVar.x(cVar, andDecrement, i);
                        }
                        aVar.j0.c(andDecrement, null);
                        t tVar = t.a;
                        this.Y = d.TERMINATED;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public final h g(boolean z) {
            return s() ? e(z) : f();
        }

        public final int h() {
            return this.indexInArray;
        }

        public final Object i() {
            return this.nextParkedWorker;
        }

        public final int m(int i) {
            int i2 = this.i0;
            int i3 = i2 ^ (i2 << 13);
            int i4 = i3 ^ (i3 >> 17);
            int i5 = i4 ^ (i4 << 5);
            this.i0 = i5;
            int i6 = i - 1;
            return (i6 & i) == 0 ? i5 & i6 : (i5 & SubsamplingScaleImageView.TILE_SIZE_AUTO) % i;
        }

        public final void q(int i) {
            StringBuilder sb = new StringBuilder();
            sb.append(a.this.Z);
            sb.append("-worker-");
            sb.append(i == 0 ? "TERMINATED" : String.valueOf(i));
            setName(sb.toString());
            this.indexInArray = i;
        }

        public final void r(Object obj) {
            this.nextParkedWorker = obj;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            p();
        }

        public final boolean u(d dVar) {
            d dVar2 = this.Y;
            boolean z = dVar2 == d.CPU_ACQUIRED;
            if (z) {
                a.m0.addAndGet(a.this, 4398046511104L);
            }
            if (dVar2 != dVar) {
                this.Y = dVar;
            }
            return z;
        }

        public c(a aVar, int i) {
            this();
            q(i);
        }
    }
}
