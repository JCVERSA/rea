package ax.A1;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import ax.I1.C0718i;
import ax.J1.C0744z;
import ax.J1.F;
import ax.J1.r;
import com.alphainventor.filemanager.file.AbstractC5838l;
import com.alphainventor.filemanager.file.C5839m;
import com.alphainventor.filemanager.file.w;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class l {
    private HashMap<String, a> a = new HashMap<>();
    private Context b;
    private F c;

    public static class a {
        String a;
        long b;
        long c;
        public String d;
        public String e;
        public String f;
        public boolean g;

        a(String str, long j, long j2, String str2, String str3, String str4) {
            this.a = str;
            this.b = j;
            this.c = j2;
            this.d = str2;
            this.e = str3;
            this.f = str4;
        }
    }

    l(Context context, F f) {
        this.c = f;
        this.b = context;
    }

    private static File c(Context context, F f) throws IOException {
        File fileQ = ax.p338y1.e.q(context);
        String str = "duplicate_hash_" + f.d().H() + "#" + f.b();
        if (fileQ != null) {
            return new File(fileQ.getAbsolutePath(), str);
        }
        throw new IOException("cannot get index file");
    }

    private static File d(Context context, F f) throws IOException {
        File fileQ = ax.p338y1.e.q(context);
        String str = "duplicate_hash_" + f.d().H() + ":" + f.b();
        if (fileQ != null) {
            return new File(fileQ.getAbsolutePath(), str);
        }
        throw new IOException("cannot get index file");
    }

    private void f(String str) {
        try {
            String[] strArrSplit = str.split("\u0000");
            String strDecode = Uri.decode(strArrSplit[0]);
            this.a.put(strDecode, new a(strDecode, Long.parseLong(strArrSplit[1]), Long.parseLong(strArrSplit[2]), strArrSplit[3], strArrSplit[4], strArrSplit[5]));
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }

    private void i(BufferedWriter bufferedWriter, a aVar) throws IOException {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(Uri.encode(aVar.a));
        stringBuffer.append("\u0000");
        stringBuffer.append(String.valueOf(aVar.b));
        stringBuffer.append("\u0000");
        stringBuffer.append(String.valueOf(aVar.c));
        stringBuffer.append("\u0000");
        String str = aVar.d;
        if (str != null) {
            stringBuffer.append(str);
        }
        stringBuffer.append("\u0000");
        String str2 = aVar.e;
        if (str2 != null) {
            stringBuffer.append(str2);
        }
        stringBuffer.append("\u0000");
        String str3 = aVar.f;
        if (str3 != null) {
            stringBuffer.append(str3);
        }
        stringBuffer.append("\u0000");
        stringBuffer.append("#");
        stringBuffer.append("\n");
        bufferedWriter.write(stringBuffer.toString());
    }

    public boolean a(w wVar, w wVar2) {
        String str;
        String str2;
        a aVarB = b(wVar);
        a aVarB2 = b(wVar2);
        if (aVarB == null || aVarB2 == null || ".folderimage".equals(wVar.b()) || ".folderimage".equals(wVar2.b()) || !aVarB.d.equals(aVarB2.d)) {
            return false;
        }
        if (TextUtils.isEmpty(aVarB.e)) {
            h(aVarB, 2);
        }
        if (TextUtils.isEmpty(aVarB2.e)) {
            h(aVarB2, 2);
        }
        String str3 = aVarB.e;
        if (str3 == null || (str = aVarB2.e) == null || !str3.equals(str)) {
            return false;
        }
        if (aVarB.c == aVarB2.c) {
            return true;
        }
        if (TextUtils.isEmpty(aVarB.f)) {
            h(aVarB, 3);
        }
        if (TextUtils.isEmpty(aVarB2.f)) {
            h(aVarB2, 3);
        }
        String str4 = aVarB.f;
        if (str4 != null && (str2 = aVarB2.f) != null) {
            return str4.equals(str2);
        }
        return false;
    }

    public a b(w wVar) {
        a aVar;
        if (this.a.containsKey(wVar.a) && (aVar = this.a.get(wVar.a)) != null) {
            if (wVar.c == aVar.c) {
                aVar.g = true;
                return aVar;
            }
            this.a.remove(wVar.a);
        }
        try {
            C5839m c5839mG = r.g(wVar.a);
            a aVar2 = new a(wVar.a, wVar.d, wVar.c, ax.p045d2.d.b(c5839mG.d1(c5839mG.V0(wVar.a), 0L), 8192L, null), null, null);
            aVar2.g = true;
            this.a.put(aVar2.a, aVar2);
            return aVar2;
        } catch (C0718i | IOException unused) {
            return null;
        }
    }

    public void e() throws Throwable {
        BufferedReader bufferedReader = null;
        try {
            try {
                File fileD = d(this.b, this.c);
                File fileC = c(this.b, this.c);
                if (fileD.exists()) {
                    if (fileC.exists()) {
                        fileD.delete();
                    } else {
                        fileD.renameTo(fileC);
                        fileC = c(this.b, this.c);
                    }
                }
                if (!fileC.exists()) {
                    return;
                }
                BufferedReader bufferedReader2 = new BufferedReader(new FileReader(fileC));
                try {
                    if (!"1".equals(bufferedReader2.readLine())) {
                        bufferedReader2.close();
                        fileC.delete();
                        C0744z.a(bufferedReader2);
                        return;
                    } else {
                        while (true) {
                            String line = bufferedReader2.readLine();
                            if (line == null) {
                                C0744z.a(bufferedReader2);
                                return;
                            }
                            f(line);
                        }
                    }
                } catch (IOException e) {
                    e = e;
                    bufferedReader = bufferedReader2;
                } catch (Throwable th) {
                    th = th;
                    bufferedReader = bufferedReader2;
                    if (bufferedReader != null) {
                        C0744z.a(bufferedReader);
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (IOException e2) {
            e = e2;
        }
        e.printStackTrace();
        if (bufferedReader != null) {
            C0744z.a(bufferedReader);
        }
    }

    public void g() {
        BufferedWriter bufferedWriter = null;
        try {
            BufferedWriter bufferedWriter2 = new BufferedWriter(new FileWriter(c(this.b, this.c)));
            try {
                bufferedWriter2.write("1\n");
                for (a aVar : this.a.values()) {
                    if (aVar.g) {
                        i(bufferedWriter2, aVar);
                    }
                }
                bufferedWriter2.close();
            } catch (IOException unused) {
                bufferedWriter = bufferedWriter2;
                if (bufferedWriter != null) {
                    C0744z.a(bufferedWriter);
                }
            }
        } catch (IOException unused2) {
        }
    }

    void h(a aVar, int i) {
        try {
            C5839m c5839mG = r.g(aVar.a);
            AbstractC5838l abstractC5838lV0 = c5839mG.V0(aVar.a);
            InputStream inputStreamD1 = c5839mG.d1(abstractC5838lV0, 0L);
            if (i == 2) {
                aVar.e = ax.p045d2.d.b(inputStreamD1, 1048576L, null);
            } else if (i == 3) {
                aVar.f = ax.p045d2.d.b(inputStreamD1, abstractC5838lV0.o(), null);
            }
            this.a.put(aVar.a, aVar);
        } catch (C0718i | IOException unused) {
        }
    }
}
