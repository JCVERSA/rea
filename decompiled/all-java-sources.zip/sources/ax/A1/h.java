package ax.A1;

import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Process;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.text.TextUtils;
import ax.E1.P;
import ax.I1.C0713d;
import ax.I1.C0718i;
import ax.J1.C0733n;
import ax.J1.C0739u;
import ax.J1.EnumC0738t;
import ax.J1.F;
import ax.J1.V;
import ax.J1.b0;
import ax.J1.r;
import com.alphainventor.filemanager.file.AbstractC5838l;
import com.alphainventor.filemanager.file.C5839m;
import com.alphainventor.filemanager.file.E;
import com.alphainventor.filemanager.file.u;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.Stack;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
public class h {
    private static final Logger o = ax.p338y1.g.a(h.class);
    private static HashMap<F, h> p = new HashMap<>();
    final F a;
    e b;
    C0051h c;
    boolean e;
    private CountDownLatch i;
    private Set<String> j;
    private boolean k;
    private ArrayList<f> f = new ArrayList<>();
    final Object g = new Object();
    final Object h = new Object();
    final AtomicInteger l = new AtomicInteger(0);
    private boolean m = false;
    Comparator<g> n = new a();
    boolean d = false;

    class a implements Comparator<g> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(g gVar, g gVar2) {
            return Long.valueOf(gVar2.b).compareTo(Long.valueOf(gVar.b));
        }
    }

    class b implements Comparator<AbstractC5838l> {
        b() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(AbstractC5838l abstractC5838l, AbstractC5838l abstractC5838l2) {
            return abstractC5838l.C().compareTo(abstractC5838l2.C());
        }
    }

    class c implements Comparator<AbstractC5838l> {
        c() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(AbstractC5838l abstractC5838l, AbstractC5838l abstractC5838l2) {
            return abstractC5838l2.C().compareTo(abstractC5838l.C());
        }
    }

    public static class d {
        public String a;
        public AbstractC5838l b;
        public boolean c = false;
        public long d = 0;
        public long e = 0;
        public long f = 0;
        public long g = 0;
        public long h = 0;
        public long i = 0;
        public long j = 0;
        public boolean k = false;
        public long l = 0;
        public long m = 0;
    }

    public static class e {
        u a;
        b0 c;
        j m;
        j n;
        long b = 0;
        HashMap<String, Long> d = new HashMap<>();
        HashMap<EnumC0738t, Long> e = new HashMap<>();
        ArrayList<g> f = new ArrayList<>();
        ArrayList<g> g = new ArrayList<>();
        ArrayList<g> h = new ArrayList<>();
        ArrayList<g> i = new ArrayList<>();
        List<ax.B1.f> j = new ArrayList();
        List<ax.B1.f> k = new ArrayList();
        List<ax.B1.f> l = new ArrayList();
        long o = 0;
        long p = 0;
        long q = 0;
        long r = 0;
        long s = 0;
        long t = 0;
        long u = 0;
        long v = 0;
        boolean w = false;
        long x = 0;
    }

    public interface f {
        void a();

        void b(String str, boolean z);
    }

    public static class g {
        String a;
        long b;
        boolean c;

        g(String str, long j, boolean z) {
            this.a = str;
            this.b = j;
            this.c = z;
        }

        public String a() {
            return this.a;
        }

        public long b() {
            return this.b;
        }

        public boolean c() {
            return this.c;
        }
    }

    /* JADX INFO: renamed from: ax.A1.h$h, reason: collision with other inner class name */
    static class C0051h {
        ArrayList<g> a = new ArrayList<>();
        long b = 0;

        C0051h() {
        }
    }

    h(F f2) {
        this.a = f2;
        this.k = ax.p338y1.f.t0(f2.d());
    }

    private void D0(C5839m c5839m, e eVar, String str, String[] strArr) throws C0718i {
        String[] strArrSplit = strArr[2].split("/");
        d dVar = new d();
        dVar.d = Long.valueOf(strArrSplit[0]).longValue();
        dVar.e = Long.valueOf(strArrSplit[1]).longValue();
        dVar.f = Long.valueOf(strArrSplit[2]).longValue();
        dVar.g = Long.valueOf(strArrSplit[3]).longValue();
        dVar.h = Long.valueOf(strArrSplit[4]).longValue();
        dVar.i = Long.valueOf(strArrSplit[5]).longValue();
        dVar.j = Long.valueOf(strArrSplit[6]).longValue();
        dVar.k = Boolean.valueOf(strArrSplit[7]).booleanValue();
        dVar.l = Long.valueOf(strArrSplit[8]).longValue();
        dVar.m = Long.valueOf(strArrSplit[9]).longValue();
        dVar.c = false;
        dVar.b = null;
        dVar.a = str;
        x0(c5839m, eVar, dVar);
    }

    private void F0(List<g> list) {
        Collections.sort(list, this.n);
    }

    private void J0(C5839m c5839m, e eVar, AbstractC5838l abstractC5838l, List<AbstractC5838l> list, Writer writer, boolean z) throws IOException {
        String strZ = Z(abstractC5838l);
        d dVar = new d();
        dVar.b = abstractC5838l;
        dVar.a = abstractC5838l.C();
        if (z) {
            dVar.m = 1L;
        } else {
            dVar.m = abstractC5838l.q();
        }
        for (AbstractC5838l abstractC5838l2 : list) {
            try {
                long jO = abstractC5838l2.o();
                EnumC0738t enumC0738tE = C0739u.e(V.f(abstractC5838l2.w()));
                EnumC0738t enumC0738tG = C0739u.g(enumC0738tE);
                dVar.d += jO;
                if (EnumC0738t.GROUP_DOCUMENT == enumC0738tG) {
                    dVar.h += jO;
                } else if (EnumC0738t.IMAGE == enumC0738tE) {
                    dVar.e += jO;
                } else if (EnumC0738t.AUDIO == enumC0738tE) {
                    dVar.f += jO;
                } else if (EnumC0738t.VIDEO == enumC0738tE) {
                    dVar.g += jO;
                } else if (EnumC0738t.ARCHIVE == enumC0738tE) {
                    dVar.i += jO;
                } else {
                    dVar.j += jO;
                }
                d(eVar.e, enumC0738tE, jO);
                if (jO > 10485760) {
                    dVar.k = true;
                    dVar.l += jO;
                    eVar.g.add(new g(a0(abstractC5838l2.C(), false), jO, false));
                    eVar.o += jO;
                }
            } catch (IllegalArgumentException unused) {
            }
        }
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(Uri.encode(abstractC5838l.C()));
        stringBuffer.append("\u0000");
        stringBuffer.append(String.valueOf(dVar.m));
        stringBuffer.append("\u0000");
        stringBuffer.append(dVar.d);
        stringBuffer.append("/");
        stringBuffer.append(dVar.e);
        stringBuffer.append("/");
        stringBuffer.append(dVar.f);
        stringBuffer.append("/");
        stringBuffer.append(dVar.g);
        stringBuffer.append("/");
        stringBuffer.append(dVar.h);
        stringBuffer.append("/");
        stringBuffer.append(dVar.i);
        stringBuffer.append("/");
        stringBuffer.append(dVar.j);
        stringBuffer.append("/");
        stringBuffer.append(dVar.k);
        stringBuffer.append("/");
        stringBuffer.append(dVar.l);
        stringBuffer.append("/");
        stringBuffer.append(dVar.m);
        dVar.c = true;
        if (ax.B1.d.P(strZ)) {
            eVar.h.add(new g(strZ, 0L, true));
        }
        long j = dVar.d;
        if (j > 52428800) {
            eVar.f.add(new g(strZ, j, true));
            eVar.p += dVar.d;
        }
        y0(eVar, strZ, dVar.d);
        stringBuffer.append("\n");
        if (writer != null) {
            writer.write(stringBuffer.toString());
        }
        s(strZ, false);
    }

    public static h O(F f2) {
        h hVar = p.get(f2);
        if (hVar != null) {
            return hVar;
        }
        ax.p045d2.b.c(ax.p338y1.f.T(f2.d()));
        h hVar2 = new h(f2);
        p.put(f2, hVar2);
        return hVar2;
    }

    public static h P(AbstractC5838l abstractC5838l) {
        F fR = abstractC5838l.R();
        if (ax.p338y1.f.T(fR.d())) {
            return O(fR);
        }
        if (ax.p338y1.f.R(fR.d())) {
            return O(o(abstractC5838l.L()));
        }
        ax.p045d2.b.g("NOT REACHABLE : invalid fileinfo");
        return null;
    }

    public static h W() {
        F fA = F.a(ax.p338y1.f.o1, 0);
        h hVar = p.get(fA);
        if (hVar != null) {
            return hVar;
        }
        h hVar2 = new h(fA);
        p.put(fA, hVar2);
        return hVar2;
    }

    public static F X(F f2) {
        return F.a(ax.p338y1.f.o1, p(f2));
    }

    private String Z(AbstractC5838l abstractC5838l) {
        return V.u(this.a, abstractC5838l.C(), Boolean.valueOf(abstractC5838l.isDirectory()));
    }

    private String a0(String str, boolean z) {
        return V.u(this.a, str, Boolean.valueOf(z));
    }

    private void c(HashMap<EnumC0738t, Long> map, String str, long j) {
        EnumC0738t enumC0738tE = C0739u.e(str);
        if (enumC0738tE == null) {
            enumC0738tE = EnumC0738t.OTHERS;
        }
        Long l = map.get(enumC0738tE);
        if (l != null) {
            map.put(enumC0738tE, Long.valueOf(l.longValue() + j));
        } else {
            map.put(enumC0738tE, Long.valueOf(j));
        }
    }

    private long c0() {
        return Long.MAX_VALUE;
    }

    private void d(HashMap<EnumC0738t, Long> map, EnumC0738t enumC0738t, long j) {
        if (enumC0738t == null) {
            enumC0738t = EnumC0738t.OTHERS;
        }
        Long l = map.get(enumC0738t);
        if (l != null) {
            map.put(enumC0738t, Long.valueOf(l.longValue() + j));
        } else {
            map.put(enumC0738t, Long.valueOf(j));
        }
    }

    private void f(Context context, e eVar, F f2) {
        long jR;
        long jS;
        long jE;
        if (f2.e() == null) {
            return;
        }
        List<ax.B1.f> listB = ax.B1.d.F(context).B();
        try {
            UUID uuidForPath = ((StorageManager) context.getSystemService("storage")).getUuidForPath(new File(f2.e()));
            Iterator<ax.B1.f> it = listB.iterator();
            while (it.hasNext()) {
                if (it.next().B()) {
                    it.remove();
                }
            }
            long jQ = 0;
            if (StorageManager.UUID_DEFAULT.equals(uuidForPath)) {
                ax.B1.d.F(context).j(listB, true);
                jR = 0;
                jS = 0;
                jE = 0;
                for (ax.B1.f fVar : listB) {
                    if (fVar.v()) {
                        jQ += fVar.q();
                        jR += fVar.r();
                        jS += fVar.s();
                        jE += fVar.e();
                    } else {
                        jQ += fVar.b();
                    }
                }
            } else {
                StorageStatsManager storageStatsManagerA = ax.A1.c.a(context.getSystemService("storagestats"));
                UserHandle userHandleMyUserHandle = Process.myUserHandle();
                Iterator<ax.B1.f> it2 = listB.iterator();
                long cacheBytes = 0;
                long appBytes = 0;
                long dataBytes = 0;
                while (it2.hasNext()) {
                    try {
                        StorageStats storageStatsQueryStatsForPackage = storageStatsManagerA.queryStatsForPackage(uuidForPath, it2.next().n(), userHandleMyUserHandle);
                        appBytes += storageStatsQueryStatsForPackage.getAppBytes();
                        cacheBytes += storageStatsQueryStatsForPackage.getCacheBytes();
                        dataBytes += storageStatsQueryStatsForPackage.getDataBytes();
                    } catch (PackageManager.NameNotFoundException | IOException | SecurityException e2) {
                        e2.printStackTrace();
                    }
                }
                jR = cacheBytes;
                jS = dataBytes;
                jE = 0;
                jQ = appBytes;
            }
            Comparator<ax.B1.f> comparatorD = ax.B1.f.d("SizeDown");
            if (comparatorD != null) {
                try {
                    Collections.sort(listB, comparatorD);
                    eVar.j = listB;
                } catch (IllegalArgumentException unused) {
                }
            }
            eVar.s = jQ;
            eVar.t = jR;
            eVar.u = jS;
            eVar.v = jE;
            if (P.L0()) {
                ArrayList arrayList = new ArrayList(listB);
                Comparator<ax.B1.f> comparatorD2 = ax.B1.f.d("ExternalCacheSizeDown");
                if (comparatorD2 != null) {
                    Collections.sort(arrayList, comparatorD2);
                    eVar.l = arrayList;
                }
            }
        } catch (IOException | IllegalArgumentException unused2) {
        }
    }

    private void g(C0051h c0051h, F f2) throws C0718i {
        F fX = X(f2);
        C5839m c5839mD = r.d(fX);
        long j = 0;
        int i = 0;
        for (AbstractC5838l abstractC5838l : C0733n.e(c5839mD.g1(c5839mD.V0(fX.e())), C0733n.b("DateDownNoSeparate"))) {
            long jO = abstractC5838l.o();
            j += jO;
            int i2 = i + 1;
            if (i < 5) {
                c0051h.a.add(new g(V.M(V.s(abstractC5838l), abstractC5838l.w()), jO, abstractC5838l.isDirectory()));
            }
            i = i2;
        }
        c0051h.b = j;
    }

    private void i(C5839m c5839m, e eVar) {
        File fileW = w(c5839m.s(), this.a);
        try {
            k0(c5839m, eVar, fileW);
        } catch (C0718i e2) {
            e = e2;
            e.printStackTrace();
            o.severe("Retry Incremental Scan.");
            try {
                fileW.delete();
                k0(c5839m, eVar, fileW);
            } catch (C0718i e3) {
                e = e3;
                o.severe("Incremental Analysis Failed.");
                e.printStackTrace();
            } catch (IOException e4) {
                e = e4;
                o.severe("Incremental Analysis Failed.");
                e.printStackTrace();
            } catch (IndexOutOfBoundsException e5) {
                o.severe("Incremental Scan Failed.");
                e5.printStackTrace();
                ax.p221pa.c.h().d("ANALYSIS OOB").m(e5).h(this.a.toString()).i();
            }
        } catch (IOException e6) {
            e = e6;
            e.printStackTrace();
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        } catch (IllegalArgumentException e7) {
            e7.printStackTrace();
            ax.p221pa.c.h().d("ANALYSIS4").m(e7).h("location:" + this.a.toString()).i();
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        } catch (IllegalStateException e8) {
            e8.printStackTrace();
            if (TextUtils.isEmpty(e8.getMessage())) {
                ax.p221pa.c.h().d("ANALYSIS2:").m(e8).h("location:" + this.a.toString()).i();
            } else {
                ax.p221pa.c.h().d("ANALYSIS2-2").h(e8.getMessage()).i();
            }
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        } catch (IndexOutOfBoundsException e9) {
            e9.printStackTrace();
            ax.p221pa.c.h().d("ANALYSIS1:").m(e9).h("location:" + this.a.toString()).i();
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        } catch (NumberFormatException e10) {
            e10.printStackTrace();
            ax.p221pa.c.h().d("ANALYSIS3").m(e10).h("location:" + this.a.toString()).i();
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        } catch (StackOverflowError e11) {
            e11.printStackTrace();
            ax.p221pa.c.h().d("ANALYSIS STACK!!!").m(e11).h("location:" + this.a.toString()).i();
            o.severe("Retry Incremental Scan.");
            fileW.delete();
            k0(c5839m, eVar, fileW);
        }
    }

    public static boolean i0(F f2) {
        if (ax.p338y1.f.T(f2.d())) {
            return O(f2).g0();
        }
        return false;
    }

    private void j(e eVar, C5839m c5839m) throws Throwable {
        eVar.a = (u) c5839m.V0(c5839m.B());
        eVar.b = c0();
        eVar.c = c5839m.C();
        long jCurrentTimeMillis = System.currentTimeMillis();
        i(c5839m, eVar);
        if (!this.k) {
            l lVar = new l(c5839m.s(), T());
            lVar.e();
            i.a(c5839m, eVar, lVar);
            lVar.g();
        }
        o.fine("AnalyzeStorage time :" + (System.currentTimeMillis() - jCurrentTimeMillis));
    }

    /* JADX WARN: Code duplicated, block: B:36:0x0097 A[Catch: all -> 0x002f, TryCatch #3 {, blocks: (B:4:0x0005, B:5:0x0012, B:7:0x0018, B:11:0x002a, B:18:0x0038, B:20:0x003e, B:22:0x0044, B:25:0x0051, B:27:0x0057, B:28:0x005b, B:30:0x006d, B:34:0x008b, B:36:0x0097, B:37:0x00a6, B:39:0x00ac, B:44:0x00e8, B:32:0x0081, B:40:0x00b9, B:42:0x00d4, B:45:0x00ed, B:47:0x0104, B:49:0x010a, B:50:0x0110, B:52:0x0116, B:54:0x012a, B:55:0x013a), top: B:65:0x0005 }] */
    /* JADX WARN: Code duplicated, block: B:39:0x00ac A[Catch: all -> 0x002f, TryCatch #3 {, blocks: (B:4:0x0005, B:5:0x0012, B:7:0x0018, B:11:0x002a, B:18:0x0038, B:20:0x003e, B:22:0x0044, B:25:0x0051, B:27:0x0057, B:28:0x005b, B:30:0x006d, B:34:0x008b, B:36:0x0097, B:37:0x00a6, B:39:0x00ac, B:44:0x00e8, B:32:0x0081, B:40:0x00b9, B:42:0x00d4, B:45:0x00ed, B:47:0x0104, B:49:0x010a, B:50:0x0110, B:52:0x0116, B:54:0x012a, B:55:0x013a), top: B:65:0x0005 }] */
    /* JADX WARN: Code duplicated, block: B:69:0x00e8 A[SYNTHETIC] */
    private synchronized void k(e eVar, C5839m c5839m, AbstractC5838l abstractC5838l) {
        long jO;
        String strZ;
        List<AbstractC5838l> listU0;
        Stack stack = new Stack();
        stack.push(abstractC5838l);
        c0();
        while (stack.size() > 0) {
            AbstractC5838l abstractC5838l2 = (AbstractC5838l) stack.pop();
            if (abstractC5838l2.isDirectory()) {
                try {
                    try {
                        listU0 = u0(c5839m, abstractC5838l2);
                    } catch (C0718i unused) {
                        jO = 0;
                        o.severe("getDirectorySize Error!");
                        strZ = Z(abstractC5838l2);
                        if (jO > 52428800) {
                            eVar.f.add(new g(strZ, jO, true));
                            eVar.p += jO;
                        }
                        if (ax.B1.d.P(strZ)) {
                            eVar.h.add(new g(strZ, 0L, true));
                        }
                        y0(eVar, strZ, jO);
                    }
                } catch (C0713d unused2) {
                    listU0 = null;
                }
                if (listU0 != null) {
                    jO = 0;
                    for (AbstractC5838l abstractC5838l3 : listU0) {
                        try {
                            if (!E.b2(abstractC5838l3)) {
                                if (abstractC5838l3.isDirectory()) {
                                    stack.push(abstractC5838l3);
                                } else {
                                    long jO2 = abstractC5838l3.o();
                                    jO += jO2;
                                    c(eVar.e, abstractC5838l3.v(), jO2);
                                    if (jO2 > 10485760) {
                                        eVar.g.add(new g(Z(abstractC5838l3), jO2, false));
                                        eVar.o += jO2;
                                    }
                                }
                            }
                        } catch (C0718i unused3) {
                            o.severe("getDirectorySize Error!");
                        }
                    }
                } else {
                    jO = 0;
                }
                strZ = Z(abstractC5838l2);
                if (jO > 52428800) {
                    eVar.f.add(new g(strZ, jO, true));
                    eVar.p += jO;
                }
                if (ax.B1.d.P(strZ)) {
                    eVar.h.add(new g(strZ, 0L, true));
                }
            } else {
                String strR = V.r(Z(abstractC5838l2));
                jO = abstractC5838l2.o();
                c(eVar.e, abstractC5838l2.v(), jO);
                if (jO > 10485760) {
                    eVar.g.add(new g(Z(abstractC5838l2), jO, false));
                    eVar.o += jO;
                }
                strZ = strR;
            }
            y0(eVar, strZ, jO);
        }
        F0(eVar.i);
        F0(eVar.g);
        F0(eVar.f);
        eVar.q = 0L;
        ArrayList<g> arrayList = eVar.h;
        if (arrayList != null && arrayList.size() > 0) {
            for (g gVar : eVar.h) {
                Long l = eVar.d.get(gVar.a());
                if (l != null) {
                    gVar.b = l.longValue();
                    eVar.q += l.longValue();
                }
            }
            F0(eVar.h);
        }
    }

    /* JADX WARN: Code duplicated, block: B:50:0x00f6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:51:0x00f8 A[Catch: all -> 0x00ed, IOException -> 0x00fb, TRY_LEAVE, TryCatch #4 {all -> 0x00ed, blocks: (B:49:0x00f3, B:51:0x00f8, B:52:0x00fb, B:42:0x00e9), top: B:65:0x0002 }] */
    /* JADX WARN: Code duplicated, block: B:66:0x00f3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    private synchronized void k0(C5839m c5839m, e eVar, File file) throws C0718i, IOException {
        BufferedWriter bufferedWriter;
        String line;
        BufferedReader bufferedReader = null;
        try {
            try {
                String absolutePath = file.getAbsolutePath();
                BufferedReader bufferedReader2 = file.exists() ? new BufferedReader(new FileReader(absolutePath)) : null;
                try {
                    bufferedWriter = new BufferedWriter(new FileWriter(absolutePath + ".tmp"));
                    if (bufferedReader2 != null) {
                        try {
                            line = bufferedReader2.readLine();
                        } catch (Throwable th) {
                            th = th;
                            bufferedReader = bufferedReader2;
                            if (bufferedReader != null) {
                                try {
                                    bufferedReader.close();
                                    if (bufferedWriter != null) {
                                        bufferedWriter.close();
                                    }
                                } catch (IOException unused) {
                                    throw th;
                                }
                            } else if (bufferedWriter != null) {
                                bufferedWriter.close();
                            }
                            throw th;
                        }
                    } else {
                        line = null;
                    }
                    if (!"6".equals(line) && bufferedReader2 != null) {
                        bufferedReader2.close();
                        try {
                            file.delete();
                            bufferedReader2 = null;
                        } catch (Throwable th2) {
                            th = th2;
                            if (bufferedReader != null) {
                                bufferedReader.close();
                                if (bufferedWriter != null) {
                                    bufferedWriter.close();
                                }
                            } else if (bufferedWriter != null) {
                                bufferedWriter.close();
                            }
                            throw th;
                        }
                    }
                    bufferedWriter.write("6\n");
                    if (bufferedReader2 != null) {
                        bufferedReader2.readLine();
                    }
                    l0(c5839m, eVar, eVar.a, bufferedWriter, new ax.G1.h(bufferedReader2));
                    if (bufferedReader2 != null) {
                        bufferedReader2.close();
                        bufferedReader2 = null;
                    }
                    bufferedWriter.close();
                    file.delete();
                    new File(absolutePath + ".tmp").renameTo(file.getAbsoluteFile());
                    F0(eVar.i);
                    F0(eVar.g);
                    F0(eVar.f);
                    for (g gVar : eVar.h) {
                        Long l = eVar.d.get(gVar.a());
                        if (l != null) {
                            gVar.b = l.longValue();
                            eVar.q += l.longValue();
                        }
                    }
                    F0(eVar.h);
                    s(HttpUrl.FRAGMENT_ENCODE_SET, true);
                    if (bufferedReader2 != null) {
                        try {
                            bufferedReader2.close();
                        } catch (IOException unused2) {
                        }
                    }
                } catch (Throwable th3) {
                    th = th3;
                    bufferedWriter = null;
                }
            } catch (Throwable th4) {
                th = th4;
                bufferedWriter = null;
            }
        } catch (Throwable th5) {
            throw th5;
        }
    }

    private void l0(C5839m c5839m, e eVar, AbstractC5838l abstractC5838l, BufferedWriter bufferedWriter, ax.G1.h hVar) throws C0718i, IOException {
        List<AbstractC5838l> listU0;
        String[] strArrSplit;
        String strDecode;
        int iCompareTo;
        if (((u) abstractC5838l).q0()) {
            try {
                listU0 = u0(c5839m, abstractC5838l);
            } catch (C0713d unused) {
                listU0 = null;
            }
            if (listU0 == null) {
                return;
            }
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (AbstractC5838l abstractC5838l2 : listU0) {
                if (abstractC5838l2.isDirectory()) {
                    arrayList.add(abstractC5838l2);
                } else {
                    arrayList2.add(abstractC5838l2);
                }
            }
            Collections.sort(arrayList, new b());
            J0(c5839m, eVar, abstractC5838l, arrayList2, bufferedWriter, false);
            if (arrayList.size() == 0) {
                n(c5839m, abstractC5838l, hVar);
                return;
            }
            String strC = hVar.c();
            int i = 0;
            while (i < arrayList.size()) {
                AbstractC5838l abstractC5838l3 = (AbstractC5838l) arrayList.get(i);
                String strC2 = abstractC5838l3.C();
                if (strC == null) {
                    iCompareTo = -1;
                    strArrSplit = null;
                    strDecode = null;
                } else {
                    strArrSplit = strC.split("\u0000");
                    strDecode = Uri.decode(strArrSplit[0]);
                    iCompareTo = strC2.compareTo(strDecode);
                }
                if (iCompareTo == 0) {
                    if (Long.valueOf(strArrSplit[1]).longValue() == abstractC5838l3.q()) {
                        bufferedWriter.write(strC + "\n");
                        D0(c5839m, eVar, strDecode, strArrSplit);
                        hVar.a();
                        o0(c5839m, eVar, strDecode, bufferedWriter, hVar);
                        strC = hVar.c();
                    } else {
                        hVar.a();
                        l0(c5839m, eVar, abstractC5838l3, bufferedWriter, hVar);
                        strC = hVar.c();
                    }
                } else if (iCompareTo < 0) {
                    n0(c5839m, eVar, abstractC5838l3, bufferedWriter);
                } else {
                    hVar.a();
                    strC = hVar.c();
                }
                i++;
            }
            n(c5839m, abstractC5838l, hVar);
        }
    }

    private void m0(C5839m c5839m, e eVar, Stack<AbstractC5838l> stack, Writer writer) throws C0718i, IOException {
        List<AbstractC5838l> listU0;
        AbstractC5838l abstractC5838lPop = stack.pop();
        if (E.b2(abstractC5838lPop) || s0(abstractC5838lPop)) {
            return;
        }
        if (abstractC5838lPop.n()) {
            try {
                listU0 = u0(c5839m, abstractC5838lPop);
            } catch (C0713d unused) {
                listU0 = null;
            } catch (OutOfMemoryError unused2) {
                ax.p221pa.c.h().g().d("Analysis: listFiles OUT OF MEMORY").i();
                listU0 = null;
            }
        } else {
            listU0 = null;
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (listU0 == null) {
            J0(c5839m, eVar, abstractC5838lPop, arrayList2, writer, true);
            return;
        }
        for (AbstractC5838l abstractC5838l : listU0) {
            if (abstractC5838l.isDirectory()) {
                arrayList.add(abstractC5838l);
            } else {
                arrayList2.add(abstractC5838l);
            }
        }
        J0(c5839m, eVar, abstractC5838lPop, arrayList2, writer, false);
        Collections.sort(arrayList, new c());
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            stack.push((AbstractC5838l) it.next());
        }
    }

    private void n(C5839m c5839m, AbstractC5838l abstractC5838l, ax.G1.h hVar) throws IOException {
        while (true) {
            String strC = hVar.c();
            if (strC == null || !Uri.decode(strC.split("\u0000")[0]).startsWith(abstractC5838l.C())) {
                return;
            } else {
                hVar.a();
            }
        }
    }

    private void n0(C5839m c5839m, e eVar, AbstractC5838l abstractC5838l, Writer writer) throws C0718i, IOException {
        Stack<AbstractC5838l> stack = new Stack<>();
        stack.push(abstractC5838l);
        while (!stack.isEmpty()) {
            m0(c5839m, eVar, stack, writer);
        }
    }

    public static F o(int i) {
        if (i == 1) {
            return F.e;
        }
        if (i == 2) {
            return F.f;
        }
        if (i < 100) {
            ax.p221pa.c.h().d("INVALID LOCATION KEY").k().h(Integer.valueOf(i)).i();
            return F.e;
        }
        F fA = F.a(ax.p338y1.f.x0, i - 100);
        if (!ax.G1.i.D().s0(fA)) {
            ax.p221pa.c.h().g().d("INVALID USB LOCATION KEY").k().h(Integer.valueOf(i)).i();
        }
        return fA;
    }

    private void o0(C5839m c5839m, e eVar, String str, BufferedWriter bufferedWriter, ax.G1.h hVar) throws C0718i, IOException {
        Stack<String> stack = new Stack<>();
        stack.push(str);
        while (!stack.isEmpty()) {
            p0(c5839m, eVar, stack, bufferedWriter, hVar);
        }
    }

    public static int p(F f2) {
        if (F.e.equals(f2)) {
            return 1;
        }
        if (F.f.equals(f2)) {
            return 2;
        }
        if (f2 == null || ax.p338y1.f.x0 != f2.d()) {
            return 0;
        }
        return f2.b() + 100;
    }

    private void p0(C5839m c5839m, e eVar, Stack<String> stack, BufferedWriter bufferedWriter, ax.G1.h hVar) throws C0718i, IOException {
        AbstractC5838l abstractC5838l;
        String str;
        String strPop = stack.pop();
        String str2 = null;
        AbstractC5838l abstractC5838l2 = null;
        while (true) {
            String strC = hVar.c();
            if (strC == null) {
                return;
            }
            String[] strArrSplit = strC.split("\u0000");
            String strDecode = Uri.decode(strArrSplit[0]);
            if (!V.y(strDecode)) {
                ax.p221pa.c.h().d("ANALYSIS ISCD:").h(strDecode + ":" + strC.length() + ":" + strC).i();
                hVar.a();
            } else {
                if (!V.r(strDecode).equals(strPop) && strPop != null) {
                    return;
                }
                if (str2 == null || abstractC5838l2 == null || !str2.equals(strDecode)) {
                    AbstractC5838l abstractC5838lV0 = c5839m.V0(strDecode);
                    if (abstractC5838lV0.q() == 0 && P.L() && (abstractC5838lV0 instanceof u)) {
                        ((u) abstractC5838lV0).f1();
                    }
                    abstractC5838l = abstractC5838lV0;
                    str = strDecode;
                } else {
                    str = str2;
                    abstractC5838l = abstractC5838l2;
                }
                if (s0(abstractC5838l)) {
                    hVar.a();
                } else {
                    if (abstractC5838l.q() == Long.parseLong(strArrSplit[1])) {
                        bufferedWriter.write(strC + "\n");
                        D0(c5839m, eVar, strDecode, strArrSplit);
                        hVar.a();
                        stack.push(strPop);
                        stack.push(strDecode);
                        return;
                    }
                    hVar.a();
                    l0(c5839m, eVar, abstractC5838l, bufferedWriter, hVar);
                }
                str2 = str;
                abstractC5838l2 = abstractC5838l;
            }
        }
    }

    private void r() {
        synchronized (this.g) {
            try {
                Iterator<f> it = this.f.iterator();
                while (it.hasNext()) {
                    it.next().a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void s(String str, boolean z) {
        synchronized (this.g) {
            try {
                Iterator<f> it = this.f.iterator();
                while (it.hasNext()) {
                    it.next().b(str, z);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private boolean s0(AbstractC5838l abstractC5838l) {
        Set<String> set = this.j;
        if (set == null) {
            return false;
        }
        return set.contains(abstractC5838l.C());
    }

    private List<AbstractC5838l> u0(C5839m c5839m, AbstractC5838l abstractC5838l) throws C0718i {
        return c5839m.g1(abstractC5838l);
    }

    static File w(Context context, F f2) {
        String str;
        File fileQ = ax.p338y1.e.q(context);
        if (f2.b() == 0) {
            str = "analysis_" + f2.d().H();
        } else {
            str = "analysis_" + f2.d().H() + ":" + f2.b();
        }
        return new File(fileQ.getAbsolutePath(), str);
    }

    public static F x(F f2) {
        return F.a(ax.p338y1.f.i1, p(f2));
    }

    private void x0(C5839m c5839m, e eVar, d dVar) throws C0718i {
        List<AbstractC5838l> listU0;
        String strA0 = a0(dVar.a, true);
        y0(eVar, strA0, dVar.d);
        long j = dVar.d;
        if (j > 52428800) {
            eVar.f.add(new g(strA0, j, true));
            eVar.p += dVar.d;
        }
        if (ax.B1.d.P(strA0)) {
            eVar.h.add(new g(strA0, 0L, true));
        }
        long j2 = dVar.e;
        if (j2 > 0) {
            d(eVar.e, EnumC0738t.IMAGE, j2);
        }
        long j3 = dVar.f;
        if (j3 > 0) {
            d(eVar.e, EnumC0738t.AUDIO, j3);
        }
        long j4 = dVar.g;
        if (j4 > 0) {
            d(eVar.e, EnumC0738t.VIDEO, j4);
        }
        long j5 = dVar.h;
        if (j5 > 0) {
            d(eVar.e, EnumC0738t.GROUP_DOCUMENT, j5);
        }
        long j6 = dVar.i;
        if (j6 > 0) {
            d(eVar.e, EnumC0738t.ARCHIVE, j6);
        }
        long j7 = dVar.j;
        if (j7 > 0) {
            d(eVar.e, EnumC0738t.OTHERS, j7);
        }
        if (dVar.k) {
            if (dVar.b == null) {
                dVar.b = c5839m.V0(dVar.a);
            }
            if (!dVar.b.isDirectory()) {
                ".android_secure".equals(dVar.b.w());
                return;
            }
            try {
                listU0 = u0(c5839m, dVar.b);
            } catch (C0713d unused) {
                listU0 = null;
            }
            if (listU0 != null) {
                ArrayList<AbstractC5838l> arrayList = new ArrayList();
                for (AbstractC5838l abstractC5838l : listU0) {
                    if (!abstractC5838l.isDirectory()) {
                        arrayList.add(abstractC5838l);
                    }
                }
                for (AbstractC5838l abstractC5838l2 : arrayList) {
                    long jO = abstractC5838l2.o();
                    if (jO > 10485760) {
                        eVar.g.add(new g(a0(abstractC5838l2.C(), false), jO, false));
                        eVar.o += jO;
                    }
                }
            }
        }
    }

    private void y0(e eVar, String str, long j) {
        while (true) {
            Long l = eVar.d.get(str);
            if (l != null) {
                eVar.d.put(str, Long.valueOf(l.longValue() + j));
            } else {
                eVar.d.put(str, Long.valueOf(j));
            }
            if ("/".equals(str)) {
                return;
            } else {
                str = V.r(str);
            }
        }
    }

    public long A(AbstractC5838l abstractC5838l) {
        Long l;
        e eVar = this.b;
        if (eVar == null || (l = eVar.d.get(Z(abstractC5838l))) == null) {
            return 0L;
        }
        return l.longValue();
    }

    public void A0(Context context) {
        w(context, this.a).delete();
    }

    public long B(AbstractC5838l abstractC5838l) {
        ax.p045d2.b.c(abstractC5838l != null);
        ax.p045d2.b.c(abstractC5838l.n());
        return ((u) abstractC5838l).y0().getTotalSpace();
    }

    public void B0(f fVar) {
        synchronized (this.g) {
            this.f.remove(fVar);
        }
    }

    public List<g> C() {
        j jVar;
        e eVar = this.b;
        if (eVar == null || (jVar = eVar.m) == null) {
            return null;
        }
        return jVar.b(this.a, 5);
    }

    public void C0() {
        synchronized (this.l) {
            this.l.getAndIncrement();
        }
    }

    public List<g> D() {
        j jVar;
        e eVar = this.b;
        if (eVar == null || (jVar = eVar.m) == null) {
            return null;
        }
        return jVar.c(this.a);
    }

    public j E() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.m;
    }

    public void E0() {
        if (this.b == null) {
            return;
        }
        this.m = true;
    }

    public long F() {
        j jVar;
        e eVar = this.b;
        if (eVar == null || (jVar = eVar.m) == null) {
            return 0L;
        }
        return jVar.b;
    }

    public List<g> G() {
        j jVar;
        e eVar = this.b;
        if (eVar == null || (jVar = eVar.n) == null) {
            return null;
        }
        return jVar.b(this.a, 5);
    }

    public void G0(long j) {
        e eVar = this.b;
        if (eVar == null) {
            return;
        }
        eVar.q -= j;
    }

    public j H() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.n;
    }

    public void H0(long j) {
        e eVar = this.b;
        if (eVar == null) {
            return;
        }
        eVar.o -= j;
    }

    public long I() {
        j jVar;
        e eVar = this.b;
        if (eVar == null || (jVar = eVar.n) == null) {
            return 0L;
        }
        return jVar.b;
    }

    public void I0(List<ax.B1.f> list) {
        List<ax.B1.f> listD0;
        e eVar = this.b;
        if (eVar == null || eVar.k == null || (listD0 = d0()) == null) {
            return;
        }
        HashSet hashSet = new HashSet();
        Iterator<ax.B1.f> it = list.iterator();
        while (it.hasNext()) {
            hashSet.add(it.next().n());
        }
        long jO = this.b.s;
        ListIterator<ax.B1.f> listIterator = listD0.listIterator();
        boolean z = false;
        while (listIterator.hasNext()) {
            ax.B1.f next = listIterator.next();
            if (!hashSet.contains(next.n())) {
                listIterator.remove();
                jO -= next.o();
                z = true;
            }
        }
        if (z) {
            e eVar2 = this.b;
            eVar2.k = listD0;
            eVar2.x = jO;
            eVar2.w = true;
        }
        this.m = false;
    }

    public List<g> J() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.h;
    }

    public long K() {
        e eVar = this.b;
        if (eVar == null) {
            return 0L;
        }
        return eVar.q;
    }

    public List<ax.B1.f> L() {
        e eVar = this.b;
        if (eVar == null || eVar.l == null) {
            return null;
        }
        return new ArrayList(this.b.l);
    }

    public long M(EnumC0738t enumC0738t) {
        return N(this.b, enumC0738t);
    }

    public long N(e eVar, EnumC0738t enumC0738t) {
        long jLongValue = 0;
        if (eVar == null) {
            return 0L;
        }
        if (!C0739u.D(enumC0738t)) {
            Long l = eVar.e.get(enumC0738t);
            if (l == null) {
                return 0L;
            }
            return l.longValue();
        }
        List<EnumC0738t> listH = C0739u.h(enumC0738t);
        if (listH == null) {
            return 0L;
        }
        Iterator<EnumC0738t> it = listH.iterator();
        while (it.hasNext()) {
            Long l2 = eVar.e.get(it.next());
            if (l2 != null) {
                jLongValue += l2.longValue();
            }
        }
        Long l3 = eVar.e.get(enumC0738t);
        return l3 != null ? jLongValue + l3.longValue() : jLongValue;
    }

    public List<g> Q() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.f;
    }

    public List<g> R() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.g;
    }

    public long S() {
        e eVar = this.b;
        if (eVar == null) {
            return 0L;
        }
        return eVar.o;
    }

    public F T() {
        return this.a;
    }

    public long U(AbstractC5838l abstractC5838l) {
        return abstractC5838l.isDirectory() ? A(abstractC5838l) : abstractC5838l.o();
    }

    public List<g> V() {
        C0051h c0051h = this.c;
        if (c0051h == null) {
            return null;
        }
        return c0051h.a;
    }

    public long Y() {
        C0051h c0051h = this.c;
        if (c0051h == null) {
            return 0L;
        }
        return c0051h.b;
    }

    public void a(AbstractC5838l abstractC5838l) {
        k(this.b, r.d(this.a), abstractC5838l);
    }

    public void b(f fVar) {
        synchronized (this.g) {
            this.f.add(fVar);
        }
    }

    public b0 b0() {
        e eVar = this.b;
        if (eVar == null) {
            return null;
        }
        return eVar.c;
    }

    public List<ax.B1.f> d0() {
        e eVar = this.b;
        if (eVar == null || eVar.k == null) {
            return null;
        }
        return new ArrayList(this.b.k);
    }

    public void e(f fVar) throws C0718i {
        if (this.a.e() == null) {
            throw new C0718i("ROOT PATH IS NULL");
        }
        try {
            C0();
            synchronized (this.h) {
                this.i = new CountDownLatch(1);
            }
            if (fVar != null) {
                b(fVar);
            }
            C5839m c5839mD = r.d(this.a);
            if (P.L() && this.a == F.f) {
                HashSet hashSet = new HashSet();
                this.j = hashSet;
                hashSet.add(V.L(this.a.e(), "/Android/data"));
            }
            this.b = new e();
            this.c = new C0051h();
            j(this.b, c5839mD);
            if (!this.k) {
                g(this.c, this.a);
                if (P.t1() && this.a == F.e && !ax.G1.i.D().g0() && ax.p045d2.l.d(c5839mD.s())) {
                    f(c5839mD.s(), this.b, this.a);
                }
            }
            this.d = true;
            this.e = false;
            z0();
            r();
            if (fVar != null) {
                B0(fVar);
            }
            this.i.countDown();
        } catch (Throwable th) {
            z0();
            r();
            if (fVar != null) {
                B0(fVar);
            }
            this.i.countDown();
            throw th;
        }
    }

    public long e0() {
        return this.b.x;
    }

    public long f0() {
        e eVar = this.b;
        if (eVar == null) {
            return 0L;
        }
        return eVar.v;
    }

    public boolean g0() {
        return this.d;
    }

    public boolean h() {
        try {
            C0();
            C0051h c0051h = new C0051h();
            this.c = c0051h;
            g(c0051h, null);
            this.d = true;
            this.e = false;
            return true;
        } catch (C0718i unused) {
            return false;
        } finally {
            z0();
        }
    }

    public boolean h0() {
        ArrayList<g> arrayList;
        e eVar = this.b;
        if (eVar == null || (arrayList = eVar.h) == null || arrayList.size() < 1) {
            return false;
        }
        return !(eVar.h.size() == 1 && "/Android/data/com.alphainventor.filemanager/cache".equals(eVar.h.get(0).a())) && eVar.q > 0;
    }

    public boolean j0() {
        List<ax.B1.f> list;
        e eVar = this.b;
        return (eVar == null || (list = eVar.k) == null || list.size() <= 0) ? false : true;
    }

    public void l() {
        this.d = false;
    }

    public void m() {
        e eVar = this.b;
        if (eVar == null) {
            return;
        }
        eVar.h.clear();
        eVar.q = 0L;
        eVar.l.clear();
        eVar.v = 0L;
    }

    public void q(AbstractC5838l abstractC5838l, long j) {
        e eVar = this.b;
        String strZ = Z(abstractC5838l);
        while (true) {
            Long l = eVar.d.get(strZ);
            if (l != null) {
                eVar.d.put(strZ, Long.valueOf(l.longValue() - j));
            }
            if ("/".equals(strZ)) {
                return;
            } else {
                strZ = V.r(strZ);
            }
        }
    }

    public void q0() {
        this.e = true;
    }

    public boolean r0() {
        boolean z;
        synchronized (this.h) {
            try {
                CountDownLatch countDownLatch = this.i;
                z = countDownLatch != null && countDownLatch.getCount() > 0;
            } catch (Throwable th) {
                throw th;
            }
        }
        return z;
    }

    public void t() {
        e eVar = this.b;
        if (eVar == null) {
            return;
        }
        eVar.m = null;
    }

    public boolean t0() {
        return this.e;
    }

    public boolean u() {
        e eVar = this.b;
        if (eVar == null) {
            return false;
        }
        return eVar.w;
    }

    public String v(String str) {
        return V.L(this.a.e(), str);
    }

    public void v0(f fVar) throws C0718i {
        if (this.i == null) {
            ax.p045d2.b.f();
            return;
        }
        if (fVar != null) {
            try {
                b(fVar);
            } catch (InterruptedException unused) {
                ax.p045d2.b.f();
                if (fVar == null) {
                    return;
                }
            } finally {
                if (fVar != null) {
                    B0(fVar);
                }
            }
        }
        this.i.await();
    }

    public boolean w0() {
        return this.m;
    }

    public List<ax.B1.f> y() {
        if (this.b == null) {
            return null;
        }
        return new ArrayList(this.b.j);
    }

    public long z() {
        e eVar = this.b;
        return eVar.s + eVar.u + eVar.t;
    }

    public void z0() {
        synchronized (this.l) {
            try {
                if (this.l.decrementAndGet() == 0) {
                    o.fine("analysis instance all released : clear");
                    l();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
