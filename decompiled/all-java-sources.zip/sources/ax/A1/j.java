package ax.A1;

import ax.J1.F;
import ax.J1.V;
import com.alphainventor.filemanager.file.w;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class j {
    List<k> a;
    long b;

    public j(List<k> list, long j) {
        this.a = list;
        this.b = j;
    }

    private String d(F f, String str) {
        return V.u(f, str, Boolean.FALSE);
    }

    public List<k> a() {
        return this.a;
    }

    public List<h.g> b(F f, int i) {
        ArrayList arrayList = new ArrayList();
        Iterator<k> it = this.a.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            w wVarD = it.next().d();
            if (wVarD != null) {
                arrayList.add(new h.g(d(f, wVarD.a), wVarD.d, wVarD.b));
            }
            i2++;
            if (i2 >= i) {
                break;
            }
        }
        return arrayList;
    }

    public List<h.g> c(F f) {
        ArrayList arrayList = new ArrayList();
        for (k kVar : this.a) {
            for (int i = 1; i < kVar.a.size(); i++) {
                w wVar = kVar.a.get(i);
                if (wVar != null) {
                    arrayList.add(new h.g(d(f, wVar.a), wVar.d, wVar.b));
                }
            }
        }
        return arrayList;
    }

    public void e(String str) {
        Iterator<k> it = this.a.iterator();
        while (it.hasNext()) {
            k next = it.next();
            Iterator<w> it2 = next.a.iterator();
            while (it2.hasNext()) {
                w next2 = it2.next();
                if (next2.a.equals(str)) {
                    it2.remove();
                    this.b -= next2.d;
                }
            }
            if (next.a.size() <= 1) {
                it.remove();
            }
        }
    }
}
