package ax.A1;

import android.content.Context;
import ax.I1.C0718i;
import ax.J1.V;
import com.alphainventor.filemanager.R;
import com.alphainventor.filemanager.file.AbstractC5838l;
import com.alphainventor.filemanager.file.C5839m;
import com.alphainventor.filemanager.file.C5845t;
import com.alphainventor.filemanager.file.w;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public class i {
    private static final Logger a = ax.p338y1.g.a(i.class);

    public static void a(C5839m c5839m, h.e eVar, l lVar) {
        List<w> listR0;
        j jVarB;
        C5845t c5845t = (C5845t) c5839m.t();
        try {
            AbstractC5838l abstractC5838lV0 = c5839m.V0(V.M(eVar.a.C(), "Download"));
            if (!abstractC5838lV0.n() || (listR0 = c5845t.R0(abstractC5838lV0, false, 0L, 0L)) == null || (jVarB = b(c5839m.s(), listR0, abstractC5838lV0, false, true, lVar)) == null) {
                return;
            }
            eVar.m = jVarB;
        } catch (C0718i e) {
            e.printStackTrace();
            eVar.m = null;
        }
    }

    private static j b(Context context, List<w> list, AbstractC5838l abstractC5838l, boolean z, boolean z2, l lVar) {
        String str;
        long jCurrentTimeMillis = System.currentTimeMillis();
        Iterator<w> it = list.iterator();
        while (it.hasNext()) {
            w next = it.next();
            if (next.b) {
                it.remove();
            } else if (z && (str = next.a) != null && !V.r(str).equalsIgnoreCase(abstractC5838l.C())) {
                it.remove();
            } else if (next.d == 0) {
                it.remove();
            }
        }
        try {
            Collections.sort(list, new w.d());
            long j = -1000;
            long j2 = 0;
            int i = 0;
            while (i < list.size()) {
                long j3 = list.get(i).d;
                if (j == j3) {
                    j2++;
                    i++;
                } else {
                    if (j2 != 0) {
                        i++;
                        j2 = 0;
                    } else if (i > 0) {
                        list.remove(i - 1);
                    }
                    j = j3;
                }
            }
            Collections.sort(list, new w.b(lVar));
            ArrayList<k> arrayList = new ArrayList();
            String string = context.getString(R.string.copy_postfix);
            w wVar = null;
            k kVar = null;
            for (int i2 = 0; i2 < list.size(); i2++) {
                w wVar2 = list.get(i2);
                if (!wVar2.b) {
                    if (wVar == null) {
                        wVar = wVar2;
                    } else if (wVar2.d == wVar.d && ((!z2 || (ax.p045d2.e.c(wVar2.b(), wVar.b(), string) && wVar2.c().equals(wVar.c()))) && lVar.a(wVar2, wVar))) {
                        if (kVar == null) {
                            kVar = new k();
                            arrayList.add(kVar);
                            kVar.a(wVar);
                        }
                        kVar.a(wVar2);
                    } else {
                        kVar = null;
                        wVar = wVar2;
                    }
                }
            }
            a.fine("duplicate analysis time :" + (System.currentTimeMillis() - jCurrentTimeMillis));
            if (arrayList.size() > 0) {
                long jC = 0;
                for (k kVar2 : arrayList) {
                    kVar2.e(string);
                    jC += kVar2.c();
                }
                return new j(arrayList, jC);
            }
        } catch (IllegalArgumentException unused) {
        }
        return null;
    }
}
