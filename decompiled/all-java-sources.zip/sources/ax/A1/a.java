package ax.A1;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a {
}
