package ax.A1;

import ax.P0.C;
import ax.S0.F;
import ax.p404z1.c;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class b extends c {
    private static C c(F f) {
        f.r(12);
        int iD = (f.d() + f.h(12)) - 4;
        f.r(44);
        f.s(f.h(12));
        f.r(16);
        ArrayList arrayList = new ArrayList();
        while (true) {
            String strL = null;
            if (f.d() >= iD) {
                break;
            }
            f.r(48);
            int iH = f.h(8);
            f.r(4);
            int iD2 = f.d() + f.h(12);
            String strL2 = null;
            while (f.d() < iD2) {
                int iH2 = f.h(8);
                int iH3 = f.h(8);
                int iD3 = f.d() + iH3;
                if (iH2 == 2) {
                    int iH4 = f.h(16);
                    f.r(8);
                    if (iH4 == 3) {
                        while (f.d() < iD3) {
                            strL = f.l(f.h(8), StandardCharsets.US_ASCII);
                            int iH5 = f.h(8);
                            for (int i = 0; i < iH5; i++) {
                                f.s(f.h(8));
                            }
                        }
                    }
                } else if (iH2 == 21) {
                    strL2 = f.l(iH3, StandardCharsets.US_ASCII);
                }
                f.p(iD3 * 8);
            }
            f.p(iD2 * 8);
            if (strL != null && strL2 != null) {
                arrayList.add(new a(iH, strL + strL2));
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new C(arrayList);
    }

    @Override // ax.p404z1.c
    protected C b(ax.p404z1.b bVar, ByteBuffer byteBuffer) {
        if (byteBuffer.get() == 116) {
            return c(new F(byteBuffer.array(), byteBuffer.limit()));
        }
        return null;
    }
}
