package ax.A1;

import android.app.usage.StorageStatsManager;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c {
    public static /* bridge */ /* synthetic */ StorageStatsManager a(Object obj) {
        return (StorageStatsManager) obj;
    }
}
