package ax.A1;

import com.alphainventor.filemanager.file.w;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class k {
    List<w> a = new ArrayList();

    void a(w wVar) {
        this.a.add(wVar);
    }

    public List<w> b() {
        return this.a;
    }

    long c() {
        if (this.a.size() > 1) {
            return this.a.get(0).d * ((long) (this.a.size() - 1));
        }
        ax.p045d2.b.f();
        return 0L;
    }

    w d() {
        if (this.a.size() == 0) {
            return null;
        }
        return this.a.get(0);
    }

    void e(String str) {
        try {
            Collections.sort(this.a, new w.a(str));
        } catch (IllegalArgumentException unused) {
        }
    }
}
