package ax.B1;

import android.annotation.SuppressLint;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Process;
import android.os.storage.StorageManager;
import ax.D1.h;
import ax.E1.P;
import ax.G1.i;
import ax.I1.C0710a;
import ax.I1.C0718i;
import ax.J1.AbstractC0726g;
import ax.J1.C0740v;
import ax.J1.C0744z;
import ax.J1.V;
import ax.p045d2.l;
import ax.p045d2.n;
import ax.p045d2.v;
import ax.p149k8.r;
import com.alphainventor.filemanager.data.ApkPlusInfo;
import com.alphainventor.filemanager.file.AbstractC5838l;
import com.alphainventor.filemanager.file.C5839m;
import com.alphainventor.filemanager.file.C5845t;
import com.alphainventor.filemanager.file.u;
import com.alphainventor.filemanager.receiver.PackageCommitReceiver;
import com.google.gson.Gson;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"DefaultLocale"})
public class d {
    private static final Logger k = ax.p338y1.g.a(d.class);
    private static d l;
    Context b;
    HashMap<String, f> e;
    final String a = "\u0000";
    List<Intent> c = new ArrayList();
    final Object f = new Object();
    HashMap<String, Boolean> g = new HashMap<>();
    HashMap<String, e> h = new HashMap<>();
    private final Object j = new Object();
    ax.G1.b d = ax.G1.b.k();
    final File i = new File(i.D().I() + "/backups/apps");

    class a implements FilenameFilter {
        a() {
        }

        @Override // java.io.FilenameFilter
        public boolean accept(File file, String str) {
            return d.R(V.j(str));
        }
    }

    class b implements FilenameFilter {
        b() {
        }

        @Override // java.io.FilenameFilter
        public boolean accept(File file, String str) {
            return "apk".equals(V.j(str));
        }
    }

    class c implements Comparator<File> {
        c() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(File file, File file2) {
            return Integer.compare(d.p(file.getName()), d.p(file.getName()));
        }
    }

    /* JADX INFO: renamed from: ax.B1.d$d, reason: collision with other inner class name */
    public static class C0059d extends n<Void, Void, Void> {
        Context h;

        public C0059d(Context context) {
            super(n.f.LOW);
            this.h = context;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // ax.p045d2.n
        /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
        public Void g(Void... voidArr) {
            d.k.fine("start caching app name");
            d.F(this.h).D("APPS_ALL");
            return null;
        }
    }

    public static class e {
        public String a;
        public long b;

        public e(String str, long j) {
            this.a = str;
            this.b = j;
        }
    }

    public static class f {
        String a;
        long b;

        f(String str, long j) {
            this.a = str;
            this.b = j;
        }

        public long a() {
            return this.b;
        }

        public String b() {
            return this.a;
        }
    }

    public static class g {
        public String a;
        public String b;
    }

    private d(Context context) {
        this.b = context.getApplicationContext();
    }

    private synchronized List<ax.B1.f> A() {
        ArrayList arrayList;
        arrayList = new ArrayList();
        try {
            PackageManager packageManager = this.b.getPackageManager();
            for (PackageInfo packageInfo : packageManager.getInstalledPackages(0)) {
                try {
                    if (packageInfo.applicationInfo != null) {
                        arrayList.add(new ax.B1.f(packageManager, packageInfo));
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return arrayList;
    }

    public static Bitmap E(ax.B1.f fVar) {
        Drawable drawableI = fVar.i();
        if (drawableI instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawableI).getBitmap();
        }
        if (drawableI != null) {
            return v.d(drawableI);
        }
        return null;
    }

    public static d F(Context context) {
        if (l == null) {
            l = new d(context);
        }
        return l;
    }

    private File H() {
        return new File(ax.p338y1.e.q(this.b), "appcache_" + Locale.getDefault().toString());
    }

    public static String K(ax.B1.f fVar) {
        return C0740v.u(fVar);
    }

    public static long L(PackageInfo packageInfo) {
        return P.j0() ? packageInfo.getLongVersionCode() : packageInfo.versionCode;
    }

    private static boolean M(String str) {
        return "apkm".equals(str) || "apk+".equals(str);
    }

    public static boolean N(Context context, AbstractC0726g abstractC0726g) throws Throwable {
        File file = new File(ax.G1.a.l(context, "apks-tmp"), String.valueOf(abstractC0726g.C().hashCode()));
        ax.G1.a.e(file, true);
        try {
            C0744z.m(abstractC0726g, file, null);
            File file2 = new File(file, "splits");
            if (file2.exists() && file2.isDirectory()) {
                file = file2;
            }
            File[] fileArrListFiles = file.listFiles();
            if (fileArrListFiles != null && fileArrListFiles.length == 1 && fileArrListFiles[0].isDirectory()) {
                file = fileArrListFiles[0];
            }
            File[] fileArrListFiles2 = file.listFiles(new b());
            if (fileArrListFiles2 == null) {
                return false;
            }
            List listAsList = Arrays.asList(fileArrListFiles2);
            Collections.sort(listAsList, new c());
            PackageInstaller packageInstaller = context.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams sessionParams = new PackageInstaller.SessionParams(1);
            sessionParams.setSize(0L);
            int iCreateSession = -1;
            try {
                iCreateSession = packageInstaller.createSession(sessionParams);
                Iterator it = listAsList.iterator();
                while (it.hasNext()) {
                    a0(packageInstaller, iCreateSession, (File) it.next());
                }
                Z(context, packageInstaller, iCreateSession);
                return true;
            } catch (IOException e2) {
                e2.printStackTrace();
                if (iCreateSession > 0) {
                    packageInstaller.abandonSession(iCreateSession);
                }
                return false;
            } catch (IllegalStateException e3) {
                e3.printStackTrace();
                ax.p221pa.c.h().g().b("APP INSTALL SESSION ERROR").m(e3).i();
                if (iCreateSession > 0) {
                    packageInstaller.abandonSession(iCreateSession);
                }
                return false;
            } catch (NullPointerException unused) {
                if (iCreateSession > 0) {
                    packageInstaller.abandonSession(iCreateSession);
                }
                return false;
            }
        } catch (C0718i unused2) {
        }
    }

    public static boolean O(String str) {
        return "apk+".equals(str);
    }

    public static boolean P(String str) {
        return str.endsWith("/cache") && str.startsWith("/Android/data/") && str.split("/").length == 5;
    }

    public static boolean R(String str) {
        return "apk".equals(str) || "apk+".equals(str);
    }

    public static boolean S(String str) {
        return "apks".equals(str) || "apkm".equals(str) || "apk+".equals(str);
    }

    private void U(List<ax.B1.f> list, Intent intent) {
        String action = intent.getAction();
        String strReplace = intent.getDataString().replace("package:", HttpUrl.FRAGMENT_ENCODE_SET);
        if ("android.intent.action.PACKAGE_ADDED".equals(action) || "android.intent.action.PACKAGE_REPLACED".equals(action)) {
            X(list, strReplace);
            c(list, strReplace);
        } else if ("android.intent.action.PACKAGE_REMOVED".equals(action)) {
            X(list, strReplace);
        }
    }

    private HashMap<String, f> V() {
        File fileH = H();
        if (fileH.exists()) {
            fileH.delete();
        }
        File fileW = w();
        if (!fileW.exists()) {
            return null;
        }
        fileW.delete();
        return null;
    }

    private void X(List<ax.B1.f> list, String str) {
        ax.B1.f fVarK = k(list, str);
        if (fVarK != null) {
            list.remove(fVarK);
        }
    }

    private static void Z(Context context, PackageInstaller packageInstaller, int i) throws Throwable {
        PackageInstaller.Session sessionOpenSession;
        try {
            sessionOpenSession = packageInstaller.openSession(i);
            try {
                sessionOpenSession.commit(ax.p045d2.i.c(context, 0, new Intent(context, (Class<?>) PackageCommitReceiver.class), 0).getIntentSender());
                sessionOpenSession.close();
                sessionOpenSession.close();
            } catch (Throwable th) {
                th = th;
                if (sessionOpenSession != null) {
                    sessionOpenSession.close();
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            sessionOpenSession = null;
        }
    }

    private static void a0(PackageInstaller packageInstaller, int i, File file) throws Throwable {
        PackageInstaller.Session sessionOpenSession;
        FileInputStream fileInputStream;
        OutputStream outputStream = null;
        try {
            sessionOpenSession = packageInstaller.openSession(i);
            try {
                OutputStream outputStreamOpenWrite = sessionOpenSession.openWrite(file.getName(), 0L, file.length());
                try {
                    fileInputStream = new FileInputStream(file);
                    try {
                        C0744z.d(fileInputStream, outputStreamOpenWrite);
                        sessionOpenSession.fsync(outputStreamOpenWrite);
                        if (outputStreamOpenWrite != null) {
                            outputStreamOpenWrite.close();
                        }
                        fileInputStream.close();
                        sessionOpenSession.close();
                    } catch (Throwable th) {
                        th = th;
                        outputStream = outputStreamOpenWrite;
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        if (sessionOpenSession != null) {
                            sessionOpenSession.close();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    fileInputStream = null;
                }
            } catch (Throwable th3) {
                th = th3;
                fileInputStream = null;
            }
        } catch (Throwable th4) {
            th = th4;
            sessionOpenSession = null;
            fileInputStream = null;
        }
    }

    private void c(List<ax.B1.f> list, String str) {
        PackageManager packageManager = this.b.getPackageManager();
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
            if (packageInfo.applicationInfo != null) {
                list.add(new ax.B1.f(packageManager, packageInfo));
            }
        } catch (Exception unused) {
            k.severe("Adding changed packaged to cache was failed");
        }
    }

    public static g c0(AbstractC0726g abstractC0726g, File file) throws C0718i {
        ax.B.b bVar = new ax.B.b();
        bVar.add("splits/base-master.apk");
        bVar.add("base.apk");
        bVar.add(ApkPlusInfo.ICON_FILENAME);
        ax.B.b<String> bVarM = C0744z.m(abstractC0726g, file, bVar);
        g gVar = new g();
        if (bVarM != null) {
            for (String str : bVarM) {
                if (ApkPlusInfo.ICON_FILENAME.equals(str)) {
                    gVar.b = str;
                } else {
                    gVar.a = str;
                }
            }
        }
        return gVar;
    }

    private void d(List<ax.B1.f> list) {
        this.e = new HashMap<>();
        for (ax.B1.f fVar : list) {
            this.e.put(fVar.n(), new f(fVar.m(), fVar.j()));
        }
    }

    private static byte[] e(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public static String h(String str) {
        return str.substring(14, str.lastIndexOf(47));
    }

    public static List<ax.B1.f> i(List<ax.B1.f> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (ax.B1.f fVar : list) {
            if (!fVar.B()) {
                arrayList.add(fVar);
            }
        }
        return arrayList;
    }

    private ax.B1.f k(List<ax.B1.f> list, String str) {
        for (ax.B1.f fVar : list) {
            if (fVar.n().equals(str)) {
                return fVar;
            }
        }
        return null;
    }

    private static ax.B1.a l(Context context, u uVar) {
        PackageManager packageManager = context.getPackageManager();
        String strB0 = uVar.B0();
        PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(strB0, 0);
        if (packageArchiveInfo == null) {
            return null;
        }
        ax.B1.a aVar = new ax.B1.a();
        ApplicationInfo applicationInfo = packageArchiveInfo.applicationInfo;
        applicationInfo.sourceDir = strB0;
        applicationInfo.publicSourceDir = strB0;
        String str = packageArchiveInfo.versionName;
        if (str == null) {
            str = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        aVar.b = str;
        aVar.a = applicationInfo.loadLabel(packageManager).toString();
        aVar.c = packageArchiveInfo.packageName;
        aVar.d = L(packageArchiveInfo);
        return aVar;
    }

    private static ax.B1.a m(ApkPlusInfo apkPlusInfo) {
        ax.B1.a aVar = new ax.B1.a();
        String str = apkPlusInfo.version_name;
        if (str == null) {
            str = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        aVar.b = str;
        aVar.a = apkPlusInfo.app_name;
        aVar.c = apkPlusInfo.package_name;
        aVar.d = apkPlusInfo.version_code;
        return aVar;
    }

    public static e n(AbstractC0726g abstractC0726g) {
        ApkPlusInfo apkPlusInfoO = o(abstractC0726g);
        if (apkPlusInfoO == null) {
            return null;
        }
        return new e(apkPlusInfoO.package_name, apkPlusInfoO.version_code);
    }

    public static ApkPlusInfo o(AbstractC0726g abstractC0726g) {
        try {
            byte[] bArrI = C0744z.i(abstractC0726g, ApkPlusInfo.INFO_FILENAME);
            if (bArrI == null) {
                return null;
            }
            return (ApkPlusInfo) new Gson().i(new String(bArrI), ApkPlusInfo.class);
        } catch (C0718i | r | NullPointerException unused) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int p(String str) {
        if (str == null) {
            return 100;
        }
        if (str.contains("base.apk")) {
            return 0;
        }
        if (str.contains("split") || str.contains("config")) {
            return 10;
        }
        return str.contains("base") ? 1 : 2;
    }

    private static InputStream q(Context context, String str) {
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(str, 0);
        if (packageArchiveInfo == null) {
            return null;
        }
        ApplicationInfo applicationInfo = packageArchiveInfo.applicationInfo;
        applicationInfo.sourceDir = str;
        applicationInfo.publicSourceDir = str;
        Drawable drawableLoadIcon = applicationInfo.loadIcon(packageManager);
        if (drawableLoadIcon == null) {
            return null;
        }
        return new ByteArrayInputStream(e(drawableLoadIcon instanceof BitmapDrawable ? ((BitmapDrawable) drawableLoadIcon).getBitmap() : v.d(drawableLoadIcon)));
    }

    public static ax.B1.a r(Context context, u uVar) {
        return S(uVar.v()) ? t(context, uVar) : l(context, uVar);
    }

    public static InputStream s(Context context, String str) {
        return S(V.k(str)) ? u(context, str) : q(context, str);
    }

    private static ax.B1.a t(Context context, u uVar) {
        ApkPlusInfo apkPlusInfoO;
        File file = new File(ax.G1.a.l(context, "apks-tmp"), String.valueOf(uVar.C().hashCode()));
        ax.G1.a.e(file, true);
        try {
            if (O(uVar.v()) && (apkPlusInfoO = o(uVar)) != null) {
                return m(apkPlusInfoO);
            }
            g gVarC0 = c0(uVar, file);
            if (gVarC0.a == null) {
                return null;
            }
            try {
                return l(context, u.A0(V.M(file.getAbsolutePath(), gVarC0.a)));
            } catch (C0718i unused) {
                return null;
            }
        } catch (C0718i e2) {
            e2.printStackTrace();
            return null;
        } finally {
            ax.G1.a.e(file, true);
        }
    }

    private static InputStream u(Context context, String str) {
        byte[] bArrI;
        File file = new File(ax.G1.a.l(context, "apks-tmp"), String.valueOf(str.hashCode()));
        try {
            u uVarA0 = u.A0(str);
            if (M(V.k(str)) && (bArrI = C0744z.i(uVarA0, ApkPlusInfo.ICON_FILENAME)) != null) {
                return new ByteArrayInputStream(bArrI);
            }
            ax.G1.a.e(file, true);
            g gVarC0 = c0(uVarA0, file);
            if (gVarC0.b != null) {
                File file2 = new File(V.M(file.getAbsolutePath(), gVarC0.b));
                if (file2.exists()) {
                    try {
                        FileInputStream fileInputStream = new FileInputStream(file2);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        C0744z.d(fileInputStream, byteArrayOutputStream);
                        return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            if (gVarC0.a != null) {
                String strM = V.M(file.getAbsolutePath(), gVarC0.a);
                if (new File(strM).exists()) {
                    return q(context, strM);
                }
            }
            return null;
        } catch (C0718i e3) {
            e3.printStackTrace();
            return null;
        } finally {
            ax.G1.a.e(file, true);
        }
    }

    private File w() {
        return new File(ax.p338y1.e.w(this.b), "appcache_" + Locale.getDefault().toString());
    }

    public synchronized List<ax.B1.f> B() {
        try {
            List<ax.B1.f> listI = this.d.i("APPS_BASE");
            if (listI == null || listI.size() == 0) {
                this.c.clear();
                List<ax.B1.f> listA = A();
                this.d.n("APPS_BASE", listA);
                return new ArrayList(listA);
            }
            if (this.c.size() > 0) {
                Iterator<Intent> it = this.c.iterator();
                while (it.hasNext()) {
                    U(listI, it.next());
                }
                this.c.clear();
            }
            return new ArrayList(listI);
        } catch (Throwable th) {
            throw th;
        }
    }

    public long C(StorageStats storageStats) {
        return storageStats.getExternalCacheBytes();
    }

    public List<ax.B1.f> D(String str) {
        List<ax.B1.f> listI = this.d.i(str);
        if (listI != null && listI.size() != 0) {
            return new ArrayList(listI);
        }
        List<ax.B1.f> listB = B();
        if ("APPS_DOWNLOADED".equals(str)) {
            listB = i(listB);
        }
        this.d.n(str, new ArrayList(listB));
        if (this.e == null) {
            synchronized (this.f) {
                this.e = V();
            }
        }
        boolean z = false;
        for (ax.B1.f fVar : listB) {
            synchronized (this.f) {
                if (fVar.a(this.e)) {
                    z = true;
                }
            }
        }
        if ("APPS_ALL".equals(str) && z) {
            synchronized (this.f) {
                d(listB);
                d0(this.e);
            }
        }
        this.g.put(str, Boolean.TRUE);
        return listB;
    }

    public int G(boolean z) {
        List<ax.B1.f> listB = B();
        return z ? listB.size() : i(listB).size();
    }

    public long I(boolean z) {
        List<ax.B1.f> listB = B();
        if (!z) {
            listB = i(listB);
        }
        if (l.d(this.b)) {
            F(this.b).j(listB, false);
        }
        Iterator<ax.B1.f> it = listB.iterator();
        long jO = 0;
        while (it.hasNext()) {
            try {
                jO += it.next().o();
            } catch (NullPointerException e2) {
                ax.p221pa.c.h().d("AHFLNULL!!:").m(e2).i();
            }
        }
        return jO;
    }

    public InputStream J(Uri uri) {
        Bitmap bitmapE;
        String path = uri.getPath();
        if ("apk".equals(uri.getAuthority())) {
            return s(this.b, path);
        }
        ax.B1.f fVarX = x(path.substring(1));
        if (fVarX == null || (bitmapE = E(fVarX)) == null) {
            return null;
        }
        return new ByteArrayInputStream(e(bitmapE));
    }

    public boolean Q(String str) {
        Boolean bool = this.g.get(str);
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }

    public boolean T() {
        return false;
    }

    public void W() {
        File fileW = w();
        if (fileW.exists()) {
            fileW.delete();
        }
    }

    public synchronized void Y(Intent intent) {
        this.c.add((Intent) intent.clone());
        List<ax.B1.f> listI = this.d.i("APPS_BASE");
        this.d.b();
        if (listI != null) {
            this.d.n("APPS_BASE", listI);
        }
    }

    public List<ax.B1.f> b0(List<ax.B1.f> list, String str) {
        Comparator<ax.B1.f> comparatorD = ax.B1.f.d(str);
        if (comparatorD != null) {
            try {
                if (ax.B1.f.z(str)) {
                    synchronized (this.j) {
                        Collections.sort(list, comparatorD);
                    }
                } else {
                    Collections.sort(list, comparatorD);
                }
            } catch (IllegalArgumentException e2) {
                ax.p221pa.c.h().g().b("APPINFO SORT ERROR").m(e2).i();
            }
        }
        return list;
    }

    public void f() {
        if (this.i.exists()) {
            return;
        }
        this.i.mkdirs();
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00a3 A[Catch: all -> 0x0083, TRY_LEAVE, TryCatch #4 {all -> 0x0083, blocks: (B:9:0x0038, B:13:0x0063, B:17:0x007f, B:27:0x0092, B:28:0x0095, B:31:0x0099, B:32:0x009d, B:34:0x00a3, B:35:0x00b7, B:37:0x00cd, B:40:0x00db, B:42:0x00e2, B:47:0x00f3, B:51:0x00fa, B:61:0x010d, B:62:0x0110, B:64:0x0113), top: B:71:0x0038, inners: #3 }] */
    /* JADX WARN: Code duplicated, block: B:37:0x00cd A[Catch: all -> 0x0083, a -> 0x00ed, TryCatch #4 {all -> 0x0083, blocks: (B:9:0x0038, B:13:0x0063, B:17:0x007f, B:27:0x0092, B:28:0x0095, B:31:0x0099, B:32:0x009d, B:34:0x00a3, B:35:0x00b7, B:37:0x00cd, B:40:0x00db, B:42:0x00e2, B:47:0x00f3, B:51:0x00fa, B:61:0x010d, B:62:0x0110, B:64:0x0113), top: B:71:0x0038, inners: #3 }] */
    /* JADX WARN: Code duplicated, block: B:40:0x00db A[Catch: all -> 0x0083, a -> 0x00ed, TryCatch #4 {all -> 0x0083, blocks: (B:9:0x0038, B:13:0x0063, B:17:0x007f, B:27:0x0092, B:28:0x0095, B:31:0x0099, B:32:0x009d, B:34:0x00a3, B:35:0x00b7, B:37:0x00cd, B:40:0x00db, B:42:0x00e2, B:47:0x00f3, B:51:0x00fa, B:61:0x010d, B:62:0x0110, B:64:0x0113), top: B:71:0x0038, inners: #3 }] */
    /* JADX WARN: Code duplicated, block: B:41:0x00e1  */
    public boolean g(Context context, ax.B1.f fVar, File file, ax.p045d2.c cVar, h hVar) throws C0718i {
        FileOutputStream fileOutputStream;
        File file2;
        AbstractC5838l abstractC5838lV0;
        ax.P1.i iVarR;
        boolean z = false;
        C5839m c5839mE = ax.J1.r.e(ax.p338y1.f.q0, 0);
        ArrayList<String> arrayList = new ArrayList();
        String strC = fVar.c();
        if (strC == null) {
            return false;
        }
        arrayList.add(strC);
        String[] strArrP = fVar.p();
        if (strArrP != null) {
            arrayList.addAll(Arrays.asList(strArrP));
        }
        File file3 = new File(ax.G1.a.l(context, "backup-tmp"), fVar.n());
        ax.G1.a.e(file3, false);
        try {
            file3.mkdirs();
            ApkPlusInfo apkPlusInfo = new ApkPlusInfo();
            apkPlusInfo.fillInfo(fVar);
            String strR = new Gson().r(apkPlusInfo);
            AutoCloseable autoCloseable = null;
            try {
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(new File(file3, ApkPlusInfo.INFO_FILENAME)));
                try {
                    outputStreamWriter.write(strR);
                    C0744z.a(outputStreamWriter);
                    Bitmap bitmapE = E(fVar);
                    if (bitmapE != null) {
                        try {
                            fileOutputStream = new FileOutputStream(new File(file3, ApkPlusInfo.ICON_FILENAME));
                            try {
                                bitmapE.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                            } catch (IOException unused) {
                                if (fileOutputStream == null) {
                                    for (String str : arrayList) {
                                        File file4 = new File(str);
                                        file2 = new File(file3, V.h(str));
                                        try {
                                            abstractC5838lV0 = c5839mE.V0(file2.getAbsolutePath());
                                            AbstractC5838l abstractC5838lV1 = c5839mE.V0(file4.getAbsolutePath());
                                            if (abstractC5838lV0.n()) {
                                                c5839mE.l1(abstractC5838lV0);
                                                abstractC5838lV0 = c5839mE.V0(file2.getAbsolutePath());
                                            }
                                            AbstractC5838l abstractC5838l = abstractC5838lV0;
                                            if (hVar != null) {
                                                iVarR = hVar.R();
                                            } else {
                                                iVarR = null;
                                            }
                                            c5839mE.i(abstractC5838lV1, c5839mE, abstractC5838l, false, false, false, cVar, iVarR);
                                        } catch (C0710a unused2) {
                                            ax.G1.a.e(file3, true);
                                            return false;
                                        }
                                    }
                                    C0744z.c(file3, file, 0);
                                    z = true;
                                    ax.G1.a.e(file3, true);
                                    return z;
                                }
                                ax.G1.a.e(file3, true);
                                throw th;
                            } catch (Throwable th) {
                                th = th;
                                autoCloseable = fileOutputStream;
                                if (autoCloseable != null) {
                                    C0744z.a(autoCloseable);
                                }
                                throw th;
                            }
                        } catch (IOException unused3) {
                            fileOutputStream = null;
                        } catch (Throwable th2) {
                            th = th2;
                        }
                        C0744z.a(fileOutputStream);
                    }
                    while (r14.hasNext()) {
                        File file5 = new File(str);
                        file2 = new File(file3, V.h(str));
                        abstractC5838lV0 = c5839mE.V0(file2.getAbsolutePath());
                        AbstractC5838l abstractC5838lV2 = c5839mE.V0(file5.getAbsolutePath());
                        if (abstractC5838lV0.n()) {
                            c5839mE.l1(abstractC5838lV0);
                            abstractC5838lV0 = c5839mE.V0(file2.getAbsolutePath());
                        }
                        AbstractC5838l abstractC5838l2 = abstractC5838lV0;
                        if (hVar != null) {
                            iVarR = hVar.R();
                        } else {
                            iVarR = null;
                        }
                        c5839mE.i(abstractC5838lV2, c5839mE, abstractC5838l2, false, false, false, cVar, iVarR);
                    }
                    try {
                        C0744z.c(file3, file, 0);
                        z = true;
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    ax.G1.a.e(file3, true);
                    return z;
                } catch (IOException unused4) {
                    autoCloseable = outputStreamWriter;
                    if (autoCloseable != null) {
                        C0744z.a(autoCloseable);
                    }
                    ax.G1.a.e(file3, true);
                    return false;
                } catch (Throwable th3) {
                    th = th3;
                    autoCloseable = outputStreamWriter;
                    if (autoCloseable != null) {
                        C0744z.a(autoCloseable);
                    }
                    throw th;
                }
            } catch (IOException unused5) {
            } catch (Throwable th4) {
                th = th4;
            }
        } catch (Throwable th5) {
            ax.G1.a.e(file3, true);
            throw th5;
        }
    }

    public void j(List<ax.B1.f> list, boolean z) {
        StorageStatsManager storageStatsManagerA;
        if (!P.t1() || list == null || (storageStatsManagerA = ax.A1.c.a(this.b.getSystemService("storagestats"))) == null) {
            return;
        }
        synchronized (this.j) {
            try {
                for (ax.B1.f fVar : list) {
                    if (fVar.y()) {
                        if (!z) {
                            try {
                                if (fVar.C()) {
                                }
                            } catch (PackageManager.NameNotFoundException | IOException | SecurityException unused) {
                            }
                        }
                        StorageStats storageStatsQueryStatsForPackage = storageStatsManagerA.queryStatsForPackage(StorageManager.UUID_DEFAULT, fVar.n(), Process.myUserHandle());
                        fVar.D(storageStatsQueryStatsForPackage.getAppBytes(), storageStatsQueryStatsForPackage.getCacheBytes(), storageStatsQueryStatsForPackage.getDataBytes(), P.L0() ? C(storageStatsQueryStatsForPackage) : 0L);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public File v() {
        return this.i;
    }

    public ax.B1.f x(String str) {
        List<ax.B1.f> listI = this.d.i("APPS_BASE");
        if (listI != null && listI.size() != 0) {
            for (ax.B1.f fVar : listI) {
                if (str.equals(fVar.n())) {
                    return fVar;
                }
            }
            return null;
        }
        PackageManager packageManager = this.b.getPackageManager();
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
            if (packageInfo == null || packageInfo.applicationInfo == null) {
                return null;
            }
            return new ax.B1.f(packageManager, packageInfo);
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public Map<String, e> y() {
        File[] fileArrListFiles;
        e eVar;
        HashMap map = new HashMap();
        if (!this.i.exists() || !this.i.isDirectory() || (fileArrListFiles = this.i.listFiles(new a())) == null) {
            return map;
        }
        PackageManager packageManager = this.b.getPackageManager();
        for (File file : fileArrListFiles) {
            String strJ = V.j(file.getName());
            String absolutePath = file.getAbsolutePath();
            String str = file.getAbsolutePath() + "-" + file.lastModified();
            e eVar2 = this.h.get(str);
            if (eVar2 == null) {
                if (O(strJ)) {
                    eVar2 = n(C5845t.o0(file));
                    if (eVar2 != null) {
                        this.h.put(str, eVar2);
                    }
                } else {
                    PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(absolutePath, 0);
                    if (packageArchiveInfo != null) {
                        eVar2 = new e(packageArchiveInfo.packageName, L(packageArchiveInfo));
                        this.h.put(str, eVar2);
                    }
                }
            }
            if (eVar2 != null && ((eVar = (e) map.get(eVar2.a)) == null || eVar.b < eVar2.b)) {
                map.put(eVar2.a, eVar2);
            }
        }
        return map;
    }

    public File z(ax.B1.f fVar) {
        String strB = V.b(fVar.m() + " " + fVar.t());
        String strF = fVar.A() ? "apk+" : V.f(fVar.f().getName());
        return new File(this.i, strB + "." + strF);
    }

    private void d0(HashMap<String, f> map) {
    }
}
