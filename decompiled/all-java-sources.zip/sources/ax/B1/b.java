package ax.B1;

import ax.P0.C;
import ax.S0.C1498a;
import ax.S0.G;
import java.nio.ByteBuffer;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class b extends ax.p404z1.c {
    @Override // ax.p404z1.c
    protected C b(ax.p404z1.b bVar, ByteBuffer byteBuffer) {
        return new C(c(new G(byteBuffer.array(), byteBuffer.limit())));
    }

    public a c(G g) {
        return new a((String) C1498a.e(g.G()), (String) C1498a.e(g.G()), g.F(), g.F(), Arrays.copyOfRange(g.f(), g.g(), g.j()));
    }
}
