package ax.B1;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import ax.E1.P;
import ax.J1.C0740v;
import ax.p045d2.x;
import java.io.File;
import java.text.Collator;
import java.util.Comparator;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class f {
    private PackageManager a;
    private PackageInfo b;
    private File c;
    private boolean d = false;
    private Long e;
    private long f;
    private Long g;
    private Long h;
    private Long i;
    private Long j;
    private Long k;
    private String l;

    public static class a implements Comparator<f> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return x.c(fVar2.j(), fVar.j());
        }
    }

    public static class b implements Comparator<f> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return x.c(fVar.j(), fVar2.j());
        }
    }

    public static class c implements Comparator<f> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return x.c(fVar2.e(), fVar.e());
        }
    }

    public static class d implements Comparator<f> {
        Collator q;

        public d() {
            Collator collator = Collator.getInstance();
            this.q = collator;
            collator.setDecomposition(1);
            this.q.setStrength(3);
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return this.q.compare(fVar2.m(), fVar.m());
        }
    }

    public static class e implements Comparator<f> {
        Collator q;

        public e() {
            Collator collator = Collator.getInstance();
            this.q = collator;
            collator.setDecomposition(1);
            this.q.setStrength(3);
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return this.q.compare(fVar.m(), fVar2.m());
        }
    }

    /* JADX INFO: renamed from: ax.B1.f$f, reason: collision with other inner class name */
    public static class C0060f implements Comparator<f> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return x.c(fVar2.o(), fVar.o());
        }
    }

    public static class g implements Comparator<f> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(f fVar, f fVar2) {
            return x.c(fVar.o(), fVar2.o());
        }
    }

    public f(PackageManager packageManager, PackageInfo packageInfo) {
        this.a = packageManager;
        this.b = packageInfo;
        ax.p045d2.b.d(packageInfo.applicationInfo != null);
    }

    public static Comparator<f> d(String str) {
        if (str.equals("NameUp")) {
            return new e();
        }
        if (str.equals("NameDown")) {
            return new d();
        }
        if (str.equals("SizeUp")) {
            return new g();
        }
        if (str.equals("SizeDown")) {
            return new C0060f();
        }
        if (str.equals("DateUp")) {
            return new b();
        }
        if (str.equals("DateDown")) {
            return new a();
        }
        if (str.equals("ExternalCacheSizeDown")) {
            return new c();
        }
        return null;
    }

    public static boolean z(String str) {
        return "SizeDown".equals(str) || "SizeUp".equals(str);
    }

    public boolean A() {
        String[] strArr;
        return P.r1() && (strArr = this.b.applicationInfo.splitSourceDirs) != null && strArr.length > 0;
    }

    public boolean B() {
        PackageInfo packageInfo = this.b;
        ApplicationInfo applicationInfo = packageInfo.applicationInfo;
        if (applicationInfo != null) {
            return (applicationInfo.flags & 1) == 1;
        }
        if (packageInfo.packageName == null) {
            ax.p221pa.c.h().g().b("ApplicaitonInfo null packageName null").i();
        }
        return true;
    }

    public boolean C() {
        return System.currentTimeMillis() - this.f > 600000;
    }

    public void D(long j, long j2, long j3, long j4) {
        this.f = System.currentTimeMillis();
        this.i = Long.valueOf(j);
        this.h = Long.valueOf(j2);
        this.g = Long.valueOf(j3);
        this.j = Long.valueOf(j4);
    }

    public boolean a(HashMap<String, ax.B1.d.f> map) {
        ax.B1.d.f fVar;
        if (this.l != null) {
            return false;
        }
        if (map != null && (fVar = map.get(n())) != null && fVar.a() == j()) {
            this.l = fVar.b();
        }
        if (this.l != null) {
            return false;
        }
        this.l = this.b.applicationInfo.loadLabel(this.a).toString();
        return true;
    }

    public long b() {
        try {
            if (!A()) {
                return f().length();
            }
            long length = f().length();
            String[] strArr = this.b.applicationInfo.splitSourceDirs;
            if (strArr != null) {
                for (String str : strArr) {
                    length += new File(str).length();
                }
            }
            return length;
        } catch (IllegalArgumentException unused) {
            return 0L;
        }
    }

    public String c() {
        return this.b.applicationInfo.sourceDir;
    }

    public long e() {
        Long l = this.j;
        if (l == null) {
            return 0L;
        }
        return l.longValue();
    }

    public File f() {
        if (this.c == null) {
            String strC = c();
            if (strC == null) {
                this.c = new File("/nosource");
            } else {
                this.c = new File(strC);
            }
        }
        return this.c;
    }

    public String g(Context context) {
        return x.l(context, j());
    }

    public String h(Context context) {
        return C0740v.f(context, o());
    }

    public Drawable i() {
        return this.b.applicationInfo.loadIcon(this.a);
    }

    public long j() {
        if (this.k == null) {
            this.k = Long.valueOf(this.b.lastUpdateTime);
        }
        return this.k.longValue();
    }

    public String k() {
        ApplicationInfo applicationInfo = this.b.applicationInfo;
        if (applicationInfo == null) {
            return null;
        }
        return applicationInfo.manageSpaceActivityName;
    }

    public int l() {
        if (this.b.applicationInfo != null && P.Y0()) {
            return this.b.applicationInfo.minSdkVersion;
        }
        return 0;
    }

    public String m() {
        if (this.l == null) {
            a(null);
        }
        return this.l;
    }

    public String n() {
        return this.b.packageName;
    }

    public long o() {
        Long l = this.g;
        if (l != null && this.i != null) {
            return l.longValue() + this.i.longValue();
        }
        if (this.e == null) {
            this.e = Long.valueOf(b());
        }
        return this.e.longValue();
    }

    public String[] p() {
        return this.b.applicationInfo.splitSourceDirs;
    }

    public long q() {
        return this.i.longValue();
    }

    public long r() {
        return this.h.longValue();
    }

    public long s() {
        return this.g.longValue();
    }

    public String t() {
        return this.b.versionName;
    }

    public long u() {
        return ax.B1.d.L(this.b);
    }

    public boolean v() {
        return (this.f == 0 || this.i == null) ? false : true;
    }

    public boolean w() {
        return this.d;
    }

    public boolean x() {
        return y();
    }

    public boolean y() {
        int i = this.b.applicationInfo.flags;
        return (i & 128) != 0 || (i & 1) == 0;
    }
}
