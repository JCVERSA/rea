package ax.B1;

/* JADX INFO: loaded from: classes.dex */
public class a {
    public String a;
    public String b;
    public String c;
    public long d;
}
