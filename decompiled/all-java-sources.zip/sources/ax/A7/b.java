package ax.A7;

import android.os.Bundle;

/* JADX INFO: loaded from: classes2.dex */
public interface b {
    void Y0(String str, Bundle bundle);
}
