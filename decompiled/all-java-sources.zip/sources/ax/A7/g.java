package ax.A7;

/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class g {
}
