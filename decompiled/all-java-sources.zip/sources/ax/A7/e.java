package ax.A7;

import android.os.Bundle;

/* JADX INFO: loaded from: classes2.dex */
public class e implements a {
    private final ax.p274t7.a a;

    public e(ax.p274t7.a aVar) {
        this.a = aVar;
    }

    @Override // ax.A7.a
    public void a(String str, Bundle bundle) {
        this.a.c("clx", str, bundle);
    }
}
