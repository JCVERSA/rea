package ax.A7;

import android.os.Bundle;

/* JADX INFO: loaded from: classes2.dex */
public interface a {
    void a(String str, Bundle bundle);
}
