package ax.A7;

import android.os.Bundle;
import ax.p358z7.g;

/* JADX INFO: loaded from: classes2.dex */
public class f implements a {
    @Override // ax.A7.a
    public void a(String str, Bundle bundle) {
        g.f().b("Skipping logging Crashlytics event to Firebase, no Firebase Analytics");
    }
}
