package ax.B0;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import ax.p127hc.C2093o;
import ax.p127hc.F;
import ax.p127hc.L;
import ax.p335uc.l;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class c {
    public static final c a = new c();
    private static C0057c b = C0057c.d;

    public enum a {
        PENALTY_LOG,
        PENALTY_DEATH,
        DETECT_FRAGMENT_REUSE,
        DETECT_FRAGMENT_TAG_USAGE,
        DETECT_RETAIN_INSTANCE_USAGE,
        DETECT_SET_USER_VISIBLE_HINT,
        DETECT_TARGET_FRAGMENT_USAGE,
        DETECT_WRONG_FRAGMENT_CONTAINER
    }

    public interface b {
    }

    /* JADX INFO: renamed from: ax.B0.c$c, reason: collision with other inner class name */
    public static final class C0057c {
        public static final a c = new a(null);
        public static final C0057c d = new C0057c(L.d(), null, F.g());
        private final Set<a> a;
        private final Map<String, Set<Class<? extends h>>> b;

        /* JADX INFO: renamed from: ax.B0.c$c$a */
        public static final class a {
            private a() {
            }

            public /* synthetic */ a(ax.p335uc.g gVar) {
                this();
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public C0057c(Set<? extends a> set, b bVar, Map<String, ? extends Set<Class<? extends h>>> map) {
            l.f(set, "flags");
            l.f(map, "allowedViolations");
            this.a = set;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry<String, ? extends Set<Class<? extends h>>> entry : map.entrySet()) {
                linkedHashMap.put(entry.getKey(), entry.getValue());
            }
            this.b = linkedHashMap;
        }

        public final Set<a> a() {
            return this.a;
        }

        public final b b() {
            return null;
        }

        public final Map<String, Set<Class<? extends h>>> c() {
            return this.b;
        }
    }

    private c() {
    }

    private final C0057c b(Fragment fragment) {
        while (fragment != null) {
            if (fragment.h1()) {
                FragmentManager fragmentManagerJ0 = fragment.J0();
                l.e(fragmentManagerJ0, "declaringFragment.parentFragmentManager");
                if (fragmentManagerJ0.C0() != null) {
                    C0057c c0057cC0 = fragmentManagerJ0.C0();
                    l.c(c0057cC0);
                    return c0057cC0;
                }
            }
            fragment = fragment.I0();
        }
        return b;
    }

    private final void c(C0057c c0057c, final h hVar) {
        Fragment fragmentA = hVar.a();
        final String name = fragmentA.getClass().getName();
        if (c0057c.a().contains(a.PENALTY_LOG)) {
            Log.d("FragmentStrictMode", "Policy violation in " + name, hVar);
        }
        c0057c.b();
        if (c0057c.a().contains(a.PENALTY_DEATH)) {
            k(fragmentA, new Runnable() { // from class: ax.B0.b
                @Override // java.lang.Runnable
                public final void run() {
                    c.d(name, hVar);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(String str, h hVar) {
        l.f(hVar, "$violation");
        Log.e("FragmentStrictMode", "Policy violation with PENALTY_DEATH in " + str, hVar);
        throw hVar;
    }

    private final void e(h hVar) {
        if (FragmentManager.J0(3)) {
            Log.d("FragmentManager", "StrictMode violation in " + hVar.a().getClass().getName(), hVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void f(Fragment fragment, String str) {
        l.f(fragment, "fragment");
        l.f(str, "previousFragmentId");
        ax.B0.a aVar = new ax.B0.a(fragment, str);
        c cVar = a;
        cVar.e(aVar);
        C0057c c0057cB = cVar.b(fragment);
        if (c0057cB.a().contains(a.DETECT_FRAGMENT_REUSE) && cVar.l(c0057cB, fragment.getClass(), aVar.getClass())) {
            cVar.c(c0057cB, aVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void g(Fragment fragment, ViewGroup viewGroup) {
        l.f(fragment, "fragment");
        d dVar = new d(fragment, viewGroup);
        c cVar = a;
        cVar.e(dVar);
        C0057c c0057cB = cVar.b(fragment);
        if (c0057cB.a().contains(a.DETECT_FRAGMENT_TAG_USAGE) && cVar.l(c0057cB, fragment.getClass(), dVar.getClass())) {
            cVar.c(c0057cB, dVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void h(Fragment fragment) {
        l.f(fragment, "fragment");
        e eVar = new e(fragment);
        c cVar = a;
        cVar.e(eVar);
        C0057c c0057cB = cVar.b(fragment);
        if (c0057cB.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.l(c0057cB, fragment.getClass(), eVar.getClass())) {
            cVar.c(c0057cB, eVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void i(Fragment fragment, Fragment fragment2, int i) {
        l.f(fragment, "violatingFragment");
        l.f(fragment2, "targetFragment");
        f fVar = new f(fragment, fragment2, i);
        c cVar = a;
        cVar.e(fVar);
        C0057c c0057cB = cVar.b(fragment);
        if (c0057cB.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.l(c0057cB, fragment.getClass(), fVar.getClass())) {
            cVar.c(c0057cB, fVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void j(Fragment fragment, ViewGroup viewGroup) {
        l.f(fragment, "fragment");
        l.f(viewGroup, "container");
        i iVar = new i(fragment, viewGroup);
        c cVar = a;
        cVar.e(iVar);
        C0057c c0057cB = cVar.b(fragment);
        if (c0057cB.a().contains(a.DETECT_WRONG_FRAGMENT_CONTAINER) && cVar.l(c0057cB, fragment.getClass(), iVar.getClass())) {
            cVar.c(c0057cB, iVar);
        }
    }

    private final void k(Fragment fragment, Runnable runnable) {
        if (!fragment.h1()) {
            runnable.run();
            return;
        }
        Handler handlerG = fragment.J0().w0().g();
        l.e(handlerG, "fragment.parentFragmentManager.host.handler");
        if (l.a(handlerG.getLooper(), Looper.myLooper())) {
            runnable.run();
        } else {
            handlerG.post(runnable);
        }
    }

    private final boolean l(C0057c c0057c, Class<? extends Fragment> cls, Class<? extends h> cls2) {
        Set<Class<? extends h>> set = c0057c.c().get(cls.getName());
        if (set == null) {
            return true;
        }
        if (l.a(cls2.getSuperclass(), h.class) || !C2093o.z(set, cls2.getSuperclass())) {
            return !set.contains(cls2);
        }
        return false;
    }
}
