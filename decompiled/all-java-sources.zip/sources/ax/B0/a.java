package ax.B0;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public static final int a = 2131165293;
}
