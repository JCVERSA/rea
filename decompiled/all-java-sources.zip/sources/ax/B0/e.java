package ax.B0;

import androidx.fragment.app.Fragment;
import ax.p335uc.l;

/* JADX INFO: loaded from: classes.dex */
public final class e extends g {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Fragment fragment) {
        super(fragment, "Attempting to get target fragment from fragment " + fragment);
        l.f(fragment, "fragment");
    }
}
