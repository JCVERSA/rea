package ax.B0;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public static final int A = 12;
    public static final int B = 13;
    public static final int i = 0;
    public static final int j = 1;
    public static final int k = 2;
    public static final int l = 3;
    public static final int m = 4;
    public static final int n = 5;
    public static final int o = 6;
    public static final int q = 2;
    public static final int r = 3;
    public static final int s = 4;
    public static final int t = 5;
    public static final int u = 6;
    public static final int v = 7;
    public static final int w = 8;
    public static final int x = 9;
    public static final int y = 10;
    public static final int z = 11;
    public static final int[] a = {R.attr.color, R.attr.alpha, R.attr.lStar, com.alphainventor.filemanager.R.attr.alpha, com.alphainventor.filemanager.R.attr.lStar};
    public static final int[] b = {com.alphainventor.filemanager.R.attr.keylines, com.alphainventor.filemanager.R.attr.statusBarBackground};
    public static final int[] c = {R.attr.layout_gravity, com.alphainventor.filemanager.R.attr.layout_anchor, com.alphainventor.filemanager.R.attr.layout_anchorGravity, com.alphainventor.filemanager.R.attr.layout_behavior, com.alphainventor.filemanager.R.attr.layout_dodgeInsetEdges, com.alphainventor.filemanager.R.attr.layout_insetEdge, com.alphainventor.filemanager.R.attr.layout_keyline};
    public static final int[] d = {com.alphainventor.filemanager.R.attr.fontProviderAuthority, com.alphainventor.filemanager.R.attr.fontProviderCerts, com.alphainventor.filemanager.R.attr.fontProviderFetchStrategy, com.alphainventor.filemanager.R.attr.fontProviderFetchTimeout, com.alphainventor.filemanager.R.attr.fontProviderPackage, com.alphainventor.filemanager.R.attr.fontProviderQuery, com.alphainventor.filemanager.R.attr.fontProviderSystemFontFamily};
    public static final int[] e = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.alphainventor.filemanager.R.attr.font, com.alphainventor.filemanager.R.attr.fontStyle, com.alphainventor.filemanager.R.attr.fontVariationSettings, com.alphainventor.filemanager.R.attr.fontWeight, com.alphainventor.filemanager.R.attr.ttcIndex};
    public static final int[] f = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] g = {R.attr.color, R.attr.offset};
    public static final int[] h = {com.alphainventor.filemanager.R.attr.alignmentMode, com.alphainventor.filemanager.R.attr.columnCount, com.alphainventor.filemanager.R.attr.columnOrderPreserved, com.alphainventor.filemanager.R.attr.orientation, com.alphainventor.filemanager.R.attr.rowCount, com.alphainventor.filemanager.R.attr.rowOrderPreserved, com.alphainventor.filemanager.R.attr.useDefaultMargins};
    public static final int[] p = {R.attr.layout_width, R.attr.layout_height, R.attr.layout_margin, R.attr.layout_marginLeft, R.attr.layout_marginTop, R.attr.layout_marginRight, R.attr.layout_marginBottom, com.alphainventor.filemanager.R.attr.layout_column, com.alphainventor.filemanager.R.attr.layout_columnSpan, com.alphainventor.filemanager.R.attr.layout_columnWeight, com.alphainventor.filemanager.R.attr.layout_gravity, com.alphainventor.filemanager.R.attr.layout_row, com.alphainventor.filemanager.R.attr.layout_rowSpan, com.alphainventor.filemanager.R.attr.layout_rowWeight};
}
