package ax.A4;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import ax.V4.C4769a;
import ax.p145k4.AbstractC5526n;
import ax.p145k4.O;
import ax.p145k4.P;
import ax.p145k4.f0;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class g extends AbstractC5526n implements Handler.Callback {
    private final d o0;
    private final f p0;
    private final Handler q0;
    private final e r0;
    private final a[] s0;
    private final long[] t0;
    private int u0;
    private int v0;
    private c w0;
    private boolean x0;
    private long y0;

    public g(f fVar, Looper looper) {
        this(fVar, looper, d.a);
    }

    private void P(a aVar, List<a.b> list) {
        for (int i = 0; i < aVar.d(); i++) {
            O o = aVar.c(i).o();
            if (o == null || !this.o0.c(o)) {
                list.add(aVar.c(i));
            } else {
                c cVarD = this.o0.d(o);
                byte[] bArr = (byte[]) C4769a.e(aVar.c(i).C());
                this.r0.clear();
                this.r0.o(bArr.length);
                ((ByteBuffer) ax.V4.O.h(this.r0.X)).put(bArr);
                this.r0.q();
                a aVarA = cVarD.a(this.r0);
                if (aVarA != null) {
                    P(aVarA, list);
                }
            }
        }
    }

    private void Q() {
        Arrays.fill(this.s0, (Object) null);
        this.u0 = 0;
        this.v0 = 0;
    }

    private void R(a aVar) {
        Handler handler = this.q0;
        if (handler != null) {
            handler.obtainMessage(0, aVar).sendToTarget();
        } else {
            S(aVar);
        }
    }

    private void S(a aVar) {
        this.p0.h(aVar);
    }

    @Override // ax.p145k4.AbstractC5526n
    protected void F() {
        Q();
        this.w0 = null;
    }

    @Override // ax.p145k4.AbstractC5526n
    protected void H(long j, boolean z) {
        Q();
        this.x0 = false;
    }

    @Override // ax.p145k4.AbstractC5526n
    protected void L(O[] oArr, long j) {
        this.w0 = this.o0.d(oArr[0]);
    }

    @Override // ax.p145k4.e0
    public boolean b() {
        return this.x0;
    }

    @Override // ax.p145k4.g0
    public int c(O o) {
        if (this.o0.c(o)) {
            return f0.a(AbstractC5526n.O(null, o.o0) ? 4 : 2);
        }
        return f0.a(0);
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message message) {
        if (message.what != 0) {
            throw new IllegalStateException();
        }
        S((a) message.obj);
        return true;
    }

    @Override // ax.p145k4.e0
    public boolean isReady() {
        return true;
    }

    @Override // ax.p145k4.e0
    public void p(long j, long j2) {
        if (!this.x0 && this.v0 < 5) {
            this.r0.clear();
            P pA = A();
            int iM = M(pA, this.r0, false);
            if (iM == -4) {
                if (this.r0.isEndOfStream()) {
                    this.x0 = true;
                } else if (!this.r0.isDecodeOnly()) {
                    e eVar = this.r0;
                    eVar.j0 = this.y0;
                    eVar.q();
                    a aVarA = ((c) ax.V4.O.h(this.w0)).a(this.r0);
                    if (aVarA != null) {
                        ArrayList arrayList = new ArrayList(aVarA.d());
                        P(aVarA, arrayList);
                        if (!arrayList.isEmpty()) {
                            a aVar = new a(arrayList);
                            int i = this.u0;
                            int i2 = this.v0;
                            int i3 = (i + i2) % 5;
                            this.s0[i3] = aVar;
                            this.t0[i3] = this.r0.Z;
                            this.v0 = i2 + 1;
                        }
                    }
                }
            } else if (iM == -5) {
                this.y0 = ((O) C4769a.e(pA.c)).p0;
            }
        }
        if (this.v0 > 0) {
            long[] jArr = this.t0;
            int i4 = this.u0;
            if (jArr[i4] <= j) {
                R((a) ax.V4.O.h(this.s0[i4]));
                a[] aVarArr = this.s0;
                int i5 = this.u0;
                aVarArr[i5] = null;
                this.u0 = (i5 + 1) % 5;
                this.v0--;
            }
        }
    }

    public g(f fVar, Looper looper, d dVar) {
        super(4);
        this.p0 = (f) C4769a.e(fVar);
        this.q0 = looper == null ? null : ax.V4.O.s(looper, this);
        this.o0 = (d) C4769a.e(dVar);
        this.r0 = new e();
        this.s0 = new a[5];
        this.t0 = new long[5];
    }
}
