package ax.A4;

import ax.Z4.h;
import ax.Z4.j;
import ax.Z4.m;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class b {
    public static final Set<String> c = new HashSet(Arrays.asList("invalid_request", "invalid_grant", "unsupported_grant_type"));
    public static final ax.p407z4.b<b> d = new a();
    private final String a;
    private final String b;

    class a extends ax.p407z4.b<b> {
        a() {
        }

        @Override // ax.p407z4.b
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public final b d(j jVar) throws ax.p407z4.a, IOException {
            h hVarB = ax.p407z4.b.b(jVar);
            String strF = null;
            String strF2 = null;
            while (jVar.p() == m.FIELD_NAME) {
                String strL = jVar.l();
                jVar.I();
                try {
                    if (strL.equals("error")) {
                        strF = ax.p407z4.b.h.f(jVar, strL, strF);
                    } else if (strL.equals("error_description")) {
                        strF2 = ax.p407z4.b.h.f(jVar, strL, strF2);
                    } else {
                        ax.p407z4.b.k(jVar);
                    }
                } catch (ax.p407z4.a e) {
                    throw e.a(strL);
                }
            }
            ax.p407z4.b.a(jVar);
            if (strF != null) {
                return new b(strF, strF2);
            }
            throw new ax.p407z4.a("missing field \"error\"", hVarB);
        }
    }

    public b(String str, String str2) {
        if (c.contains(str)) {
            this.a = str;
        } else {
            this.a = "unknown";
        }
        this.b = str2;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}
