package ax.A4;

import ax.p145k4.O;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b {
    public static byte[] a(a.b bVar) {
        return null;
    }

    public static O b(a.b bVar) {
        return null;
    }
}
