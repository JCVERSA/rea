package ax.A4;

import ax.p343v4.j;

/* JADX INFO: loaded from: classes.dex */
public class c extends j {
    private final b X;

    public c(String str, b bVar) {
        super(str, bVar.b());
        this.X = bVar;
    }

    public b a() {
        return this.X;
    }
}
