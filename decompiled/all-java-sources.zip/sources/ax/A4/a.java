package ax.A4;

import android.os.Parcel;
import android.os.Parcelable;
import ax.p145k4.O;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0054a();
    private final b[] q;

    /* JADX INFO: renamed from: ax.A4.a$a, reason: collision with other inner class name */
    static class C0054a implements Parcelable.Creator<a> {
        C0054a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public a[] newArray(int i) {
            return new a[i];
        }
    }

    public interface b extends Parcelable {
        byte[] C();

        O o();
    }

    public a(b... bVarArr) {
        this.q = bVarArr;
    }

    public a a(b... bVarArr) {
        return bVarArr.length == 0 ? this : new a((b[]) ax.V4.O.j0(this.q, bVarArr));
    }

    public a b(a aVar) {
        return aVar == null ? this : a(aVar.q);
    }

    public b c(int i) {
        return this.q[i];
    }

    public int d() {
        return this.q.length;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || a.class != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.q, ((a) obj).q);
    }

    public int hashCode() {
        return Arrays.hashCode(this.q);
    }

    public String toString() {
        return "entries=" + Arrays.toString(this.q);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.q.length);
        for (b bVar : this.q) {
            parcel.writeParcelable(bVar, 0);
        }
    }

    public a(List<? extends b> list) {
        b[] bVarArr = new b[list.size()];
        this.q = bVarArr;
        list.toArray(bVarArr);
    }

    a(Parcel parcel) {
        this.q = new b[parcel.readInt()];
        int i = 0;
        while (true) {
            b[] bVarArr = this.q;
            if (i >= bVarArr.length) {
                return;
            }
            bVarArr[i] = (b) parcel.readParcelable(b.class.getClassLoader());
            i++;
        }
    }
}
