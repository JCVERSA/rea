package ax.A4;

import ax.C4.f;
import ax.Z4.g;
import ax.Z4.h;
import ax.Z4.m;
import ax.p343v4.j;
import ax.p343v4.k;
import ax.p343v4.n;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class a {
    public static final ax.p407z4.b<a> f = new b();
    public static final ax.p407z4.c<a> g = new c();
    private String a;
    private Long b;
    private final String c;
    private final String d;
    private final String e;

    /* JADX INFO: renamed from: ax.A4.a$a, reason: collision with other inner class name */
    class C0053a extends n.c<d> {
        C0053a() {
        }

        @Override // ax.v4.n.c
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public d a(ax.y4.a.b bVar) throws j {
            if (bVar.d() == 200) {
                return (d) n.u(d.e, bVar);
            }
            throw new ax.A4.c(n.q(bVar), (ax.A4.b) n.u(ax.A4.b.d, bVar));
        }
    }

    class b extends ax.p407z4.b<a> {
        b() {
        }

        @Override // ax.p407z4.b
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public final a d(ax.Z4.j jVar) throws ax.p407z4.a, IOException {
            h hVarB = ax.p407z4.b.b(jVar);
            String strF = null;
            Long lF = null;
            String strF2 = null;
            String strF3 = null;
            String strF4 = null;
            while (jVar.p() == m.FIELD_NAME) {
                String strL = jVar.l();
                jVar.I();
                try {
                    if (strL.equals("access_token")) {
                        strF = ax.p407z4.b.h.f(jVar, strL, strF);
                    } else if (strL.equals("expires_at")) {
                        lF = ax.p407z4.b.b.f(jVar, strL, lF);
                    } else if (strL.equals("refresh_token")) {
                        strF2 = ax.p407z4.b.h.f(jVar, strL, strF2);
                    } else if (strL.equals("app_key")) {
                        strF3 = ax.p407z4.b.h.f(jVar, strL, strF3);
                    } else if (strL.equals("app_secret")) {
                        strF4 = ax.p407z4.b.h.f(jVar, strL, strF4);
                    } else {
                        ax.p407z4.b.k(jVar);
                    }
                } catch (ax.p407z4.a e) {
                    throw e.a(strL);
                }
            }
            ax.p407z4.b.a(jVar);
            if (strF != null) {
                return new a(strF, lF, strF2, strF3, strF4);
            }
            throw new ax.p407z4.a("missing field \"access_token\"", hVarB);
        }
    }

    class c extends ax.p407z4.c<a> {
        c() {
        }

        @Override // ax.p407z4.c
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void a(a aVar, g gVar) throws IOException {
            gVar.R();
            gVar.m0("access_token", aVar.a);
            if (aVar.b != null) {
                gVar.C("expires_at", aVar.b.longValue());
            }
            if (aVar.c != null) {
                gVar.m0("refresh_token", aVar.c);
            }
            if (aVar.d != null) {
                gVar.m0("app_key", aVar.d);
            }
            if (aVar.e != null) {
                gVar.m0("app_secret", aVar.e);
            }
            gVar.r();
        }
    }

    public a(String str) {
        this(str, null, null, null, null);
    }

    public a(String str, Long l, String str2, String str3) {
        this(str, l, str2, str3, null);
    }

    public a(String str, Long l, String str2, String str3, String str4) {
        if (str == null) {
            throw new IllegalArgumentException("Missing access token.");
        }
        if (str2 != null && str3 == null) {
            throw new IllegalArgumentException("Can't refresh without app Key.");
        }
        if (str2 != null && l == null) {
            throw new IllegalArgumentException("Missing expireAt.");
        }
        this.a = str;
        this.b = l;
        this.c = str2;
        this.d = str3;
        this.e = str4;
    }

    public boolean a() {
        return h() != null && System.currentTimeMillis() + 300000 > h().longValue();
    }

    public String g() {
        return this.a;
    }

    public Long h() {
        return this.b;
    }

    public String i() {
        return this.c;
    }

    public d j(ax.p343v4.m mVar) throws j {
        return k(mVar, k.e, null);
    }

    public d k(ax.p343v4.m mVar, k kVar, Collection<String> collection) throws j {
        if (this.c == null) {
            throw new ax.A4.c(null, new ax.A4.b("invalid_request", "Cannot refresh becasue there is no refresh token"));
        }
        if (this.d == null) {
            throw new IllegalStateException("DbxCredential's constructor should always guarantee appKey is not null if refreshToken is not null.");
        }
        HashMap map = new HashMap();
        map.put("grant_type", "refresh_token");
        map.put("refresh_token", this.c);
        map.put("locale", mVar.d());
        ArrayList arrayList = new ArrayList();
        String str = this.e;
        if (str == null) {
            map.put("client_id", this.d);
        } else {
            n.b(arrayList, this.d, str);
        }
        if (collection != null) {
            map.put("scope", f.e(collection, " "));
        }
        d dVar = (d) n.j(mVar, "OfficialDropboxJavaSDKv2", kVar.h(), "oauth2/token", n.z(map), arrayList, new C0053a());
        synchronized (this) {
            this.a = dVar.a();
            this.b = dVar.b();
        }
        return dVar;
    }

    public String toString() {
        return g.b(this);
    }
}
