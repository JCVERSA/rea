package ax.A4;

import ax.p187n4.h;

/* JADX INFO: loaded from: classes.dex */
public final class e extends h {
    public long j0;

    public e() {
        super(1);
    }
}
