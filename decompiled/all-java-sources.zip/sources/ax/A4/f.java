package ax.A4;

/* JADX INFO: loaded from: classes.dex */
public interface f {
    void h(a aVar);
}
