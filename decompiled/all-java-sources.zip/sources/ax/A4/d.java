package ax.A4;

import ax.E4.h;
import ax.p145k4.O;

/* JADX INFO: loaded from: classes.dex */
public interface d {
    public static final d a = new a();

    static class a implements d {
        a() {
        }

        @Override // ax.A4.d
        public boolean c(O o) {
            String str = o.l0;
            return "application/id3".equals(str) || "application/x-emsg".equals(str) || "application/x-scte35".equals(str) || "application/x-icy".equals(str);
        }

        @Override // ax.A4.d
        public c d(O o) {
            String str = o.l0;
            if (str != null) {
                switch (str) {
                    case "application/x-icy":
                        return new ax.D4.a();
                    case "application/id3":
                        return new h();
                    case "application/x-emsg":
                        return new ax.B4.b();
                    case "application/x-scte35":
                        return new ax.F4.c();
                }
            }
            throw new IllegalArgumentException("Attempted to create decoder for unsupported MIME type: " + str);
        }
    }

    boolean c(O o);

    c d(O o);
}
