package ax.A4;

import ax.Z4.h;
import ax.Z4.j;
import ax.Z4.m;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public class d {
    public static final ax.p407z4.b<d> e = new a();
    private final String a;
    private final long b;
    private long c;
    private String d;

    class a extends ax.p407z4.b<d> {
        a() {
        }

        @Override // ax.p407z4.b
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public d d(j jVar) throws ax.p407z4.a, IOException {
            h hVarB = ax.p407z4.b.b(jVar);
            String strF = null;
            String strF2 = null;
            Long lF = null;
            String strF3 = null;
            while (jVar.p() == m.FIELD_NAME) {
                String strL = jVar.l();
                ax.p407z4.b.c(jVar);
                try {
                    if (strL.equals("token_type")) {
                        strF = ax.p343v4.h.k.f(jVar, strL, strF);
                    } else if (strL.equals("access_token")) {
                        strF2 = ax.p343v4.h.l.f(jVar, strL, strF2);
                    } else if (strL.equals("expires_in")) {
                        lF = ax.p407z4.b.d.f(jVar, strL, lF);
                    } else if (strL.equals("scope")) {
                        strF3 = ax.p407z4.b.h.f(jVar, strL, strF3);
                    } else {
                        ax.p407z4.b.k(jVar);
                    }
                } catch (ax.p407z4.a e) {
                    throw e.a(strL);
                }
            }
            ax.p407z4.b.a(jVar);
            if (strF == null) {
                throw new ax.p407z4.a("missing field \"token_type\"", hVarB);
            }
            if (strF2 == null) {
                throw new ax.p407z4.a("missing field \"access_token\"", hVarB);
            }
            if (lF != null) {
                return new d(strF2, lF.longValue(), strF3);
            }
            throw new ax.p407z4.a("missing field \"expires_in\"", hVarB);
        }
    }

    public d(String str, long j) {
        this(str, j, null);
    }

    public d(String str, long j, String str2) {
        if (str == null) {
            throw new IllegalArgumentException("access token can't be null.");
        }
        this.a = str;
        this.b = j;
        this.c = System.currentTimeMillis();
        this.d = str2;
    }

    public String a() {
        return this.a;
    }

    public Long b() {
        return Long.valueOf(this.c + (this.b * 1000));
    }
}
