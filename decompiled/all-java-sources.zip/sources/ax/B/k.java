package ax.B;

import ax.p127hc.C2087i;
import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class k<K, V> {
    private Object[] X;
    private int Y;
    private int[] q;

    public k() {
        this(0, 1, null);
    }

    public k(int i) {
        this.q = i == 0 ? ax.C.a.a : new int[i];
        this.X = i == 0 ? ax.C.a.c : new Object[i << 1];
    }

    public /* synthetic */ k(int i, int i2, ax.p335uc.g gVar) {
        this((i2 & 1) != 0 ? 0 : i);
    }

    public k(k<? extends K, ? extends V> kVar) {
        this(0, 1, null);
        if (kVar != null) {
            h(kVar);
        }
    }

    private final int c(K k, int i) {
        int i2 = this.Y;
        if (i2 == 0) {
            return -1;
        }
        int iA = ax.C.a.a(this.q, i2, i);
        if (iA < 0 || ax.p335uc.l.a(k, this.X[iA << 1])) {
            return iA;
        }
        int i3 = iA + 1;
        while (i3 < i2 && this.q[i3] == i) {
            if (ax.p335uc.l.a(k, this.X[i3 << 1])) {
                return i3;
            }
            i3++;
        }
        for (int i4 = iA - 1; i4 >= 0 && this.q[i4] == i; i4--) {
            if (ax.p335uc.l.a(k, this.X[i4 << 1])) {
                return i4;
            }
        }
        return ~i3;
    }

    private final int e() {
        int i = this.Y;
        if (i == 0) {
            return -1;
        }
        int iA = ax.C.a.a(this.q, i, 0);
        if (iA < 0 || this.X[iA << 1] == null) {
            return iA;
        }
        int i2 = iA + 1;
        while (i2 < i && this.q[i2] == 0) {
            if (this.X[i2 << 1] == null) {
                return i2;
            }
            i2++;
        }
        for (int i3 = iA - 1; i3 >= 0 && this.q[i3] == 0; i3--) {
            if (this.X[i3 << 1] == null) {
                return i3;
            }
        }
        return ~i2;
    }

    public final int a(V v) {
        int i = this.Y * 2;
        Object[] objArr = this.X;
        if (v == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (ax.p335uc.l.a(v, objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    public void b(int i) {
        int i2 = this.Y;
        int[] iArr = this.q;
        if (iArr.length < i) {
            int[] iArrCopyOf = Arrays.copyOf(iArr, i);
            ax.p335uc.l.e(iArrCopyOf, "copyOf(this, newSize)");
            this.q = iArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.X, i * 2);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.X = objArrCopyOf;
        }
        if (this.Y != i2) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        if (this.Y > 0) {
            this.q = ax.C.a.a;
            this.X = ax.C.a.c;
            this.Y = 0;
        }
        if (this.Y > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(K k) {
        return d(k) >= 0;
    }

    public boolean containsValue(V v) {
        return a(v) >= 0;
    }

    public int d(K k) {
        return k == null ? e() : c(k, k.hashCode());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        try {
            if (obj instanceof k) {
                if (size() != ((k) obj).size()) {
                    return false;
                }
                k kVar = (k) obj;
                int i = this.Y;
                for (int i2 = 0; i2 < i; i2++) {
                    K kF = f(i2);
                    V vK = k(i2);
                    Object obj2 = kVar.get(kF);
                    if (vK == null) {
                        if (obj2 != null || !kVar.containsKey(kF)) {
                            return false;
                        }
                    } else if (!ax.p335uc.l.a(vK, obj2)) {
                        return false;
                    }
                }
                return true;
            }
            if (!(obj instanceof Map) || size() != ((Map) obj).size()) {
                return false;
            }
            int i3 = this.Y;
            for (int i4 = 0; i4 < i3; i4++) {
                K kF2 = f(i4);
                V vK2 = k(i4);
                Object obj3 = ((Map) obj).get(kF2);
                if (vK2 == null) {
                    if (obj3 != null || !((Map) obj).containsKey(kF2)) {
                        return false;
                    }
                } else if (!ax.p335uc.l.a(vK2, obj3)) {
                    return false;
                }
            }
            return true;
        } catch (ClassCastException | NullPointerException unused) {
        }
        return false;
    }

    public K f(int i) {
        if (i >= 0 && i < this.Y) {
            return (K) this.X[i << 1];
        }
        throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
    }

    public V get(K k) {
        int iD = d(k);
        if (iD >= 0) {
            return (V) this.X[(iD << 1) + 1];
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public V getOrDefault(Object obj, V v) {
        int iD = d(obj);
        return iD >= 0 ? (V) this.X[(iD << 1) + 1] : v;
    }

    public void h(k<? extends K, ? extends V> kVar) {
        ax.p335uc.l.f(kVar, "map");
        int i = kVar.Y;
        b(this.Y + i);
        if (this.Y != 0) {
            for (int i2 = 0; i2 < i; i2++) {
                put(kVar.f(i2), kVar.k(i2));
            }
        } else if (i > 0) {
            C2087i.e(kVar.q, this.q, 0, 0, i);
            C2087i.g(kVar.X, this.X, 0, 0, i << 1);
            this.Y = i;
        }
    }

    public int hashCode() {
        int[] iArr = this.q;
        Object[] objArr = this.X;
        int i = this.Y;
        int i2 = 1;
        int i3 = 0;
        int iHashCode = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            iHashCode += (obj != null ? obj.hashCode() : 0) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return iHashCode;
    }

    public V i(int i) {
        int i2;
        if (i < 0 || i >= (i2 = this.Y)) {
            throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
        }
        Object[] objArr = this.X;
        int i3 = i << 1;
        V v = (V) objArr[i3 + 1];
        if (i2 <= 1) {
            clear();
            return v;
        }
        int i4 = i2 - 1;
        int[] iArr = this.q;
        if (iArr.length <= 8 || i2 >= iArr.length / 3) {
            if (i < i4) {
                int i5 = i + 1;
                C2087i.e(iArr, iArr, i, i5, i2);
                Object[] objArr2 = this.X;
                C2087i.g(objArr2, objArr2, i3, i5 << 1, i2 << 1);
            }
            Object[] objArr3 = this.X;
            int i6 = i4 << 1;
            objArr3[i6] = null;
            objArr3[i6 + 1] = null;
        } else {
            int i7 = i2 > 8 ? i2 + (i2 >> 1) : 8;
            int[] iArrCopyOf = Arrays.copyOf(iArr, i7);
            ax.p335uc.l.e(iArrCopyOf, "copyOf(this, newSize)");
            this.q = iArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.X, i7 << 1);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.X = objArrCopyOf;
            if (i2 != this.Y) {
                throw new ConcurrentModificationException();
            }
            if (i > 0) {
                C2087i.e(iArr, this.q, 0, 0, i);
                C2087i.g(objArr, this.X, 0, 0, i3);
            }
            if (i < i4) {
                int i8 = i + 1;
                C2087i.e(iArr, this.q, i, i8, i2);
                C2087i.g(objArr, this.X, i3, i8 << 1, i2 << 1);
            }
        }
        if (i2 != this.Y) {
            throw new ConcurrentModificationException();
        }
        this.Y = i4;
        return v;
    }

    public boolean isEmpty() {
        return this.Y <= 0;
    }

    public V j(int i, V v) {
        if (i < 0 || i >= this.Y) {
            throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
        }
        int i2 = (i << 1) + 1;
        Object[] objArr = this.X;
        V v2 = (V) objArr[i2];
        objArr[i2] = v;
        return v2;
    }

    public V k(int i) {
        if (i >= 0 && i < this.Y) {
            return (V) this.X[(i << 1) + 1];
        }
        throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
    }

    public V put(K k, V v) {
        int i = this.Y;
        int iHashCode = k != null ? k.hashCode() : 0;
        int iC = k != null ? c(k, iHashCode) : e();
        if (iC >= 0) {
            int i2 = (iC << 1) + 1;
            Object[] objArr = this.X;
            V v2 = (V) objArr[i2];
            objArr[i2] = v;
            return v2;
        }
        int i3 = ~iC;
        int[] iArr = this.q;
        if (i >= iArr.length) {
            int i4 = 8;
            if (i >= 8) {
                i4 = (i >> 1) + i;
            } else if (i < 4) {
                i4 = 4;
            }
            int[] iArrCopyOf = Arrays.copyOf(iArr, i4);
            ax.p335uc.l.e(iArrCopyOf, "copyOf(this, newSize)");
            this.q = iArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.X, i4 << 1);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.X = objArrCopyOf;
            if (i != this.Y) {
                throw new ConcurrentModificationException();
            }
        }
        if (i3 < i) {
            int[] iArr2 = this.q;
            int i5 = i3 + 1;
            C2087i.e(iArr2, iArr2, i5, i3, i);
            Object[] objArr2 = this.X;
            C2087i.g(objArr2, objArr2, i5 << 1, i3 << 1, this.Y << 1);
        }
        int i6 = this.Y;
        if (i == i6) {
            int[] iArr3 = this.q;
            if (i3 < iArr3.length) {
                iArr3[i3] = iHashCode;
                Object[] objArr3 = this.X;
                int i7 = i3 << 1;
                objArr3[i7] = k;
                objArr3[i7 + 1] = v;
                this.Y = i6 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V v2 = get(k);
        return v2 == null ? put(k, v) : v2;
    }

    public V remove(K k) {
        int iD = d(k);
        if (iD >= 0) {
            return i(iD);
        }
        return null;
    }

    public boolean remove(K k, V v) {
        int iD = d(k);
        if (iD < 0 || !ax.p335uc.l.a(v, k(iD))) {
            return false;
        }
        i(iD);
        return true;
    }

    public V replace(K k, V v) {
        int iD = d(k);
        if (iD >= 0) {
            return j(iD, v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int iD = d(k);
        if (iD < 0 || !ax.p335uc.l.a(v, k(iD))) {
            return false;
        }
        j(iD, v2);
        return true;
    }

    public int size() {
        return this.Y;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Y * 28);
        sb.append('{');
        int i = this.Y;
        for (int i2 = 0; i2 < i; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            K kF = f(i2);
            if (kF != sb) {
                sb.append(kF);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            V vK = k(i2);
            if (vK != sb) {
                sb.append(vK);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        String string = sb.toString();
        ax.p335uc.l.e(string, "StringBuilder(capacity).…builderAction).toString()");
        return string;
    }
}
