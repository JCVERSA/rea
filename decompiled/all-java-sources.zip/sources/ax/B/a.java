package ax.B;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

/* JADX INFO: loaded from: classes.dex */
public class a<K, V> extends h<K, V> implements Map<K, V>, j$.util.Map {
    g<K, V> k0;

    /* JADX INFO: renamed from: ax.B.a$a, reason: collision with other inner class name */
    class C0058a extends g<K, V> {
        C0058a() {
        }

        @Override // ax.B.g
        protected void a() {
            a.this.clear();
        }

        @Override // ax.B.g
        protected Object b(int i, int i2) {
            return a.this.X[(i << 1) + i2];
        }

        @Override // ax.B.g
        protected Map<K, V> c() {
            return a.this;
        }

        @Override // ax.B.g
        protected int d() {
            return a.this.Y;
        }

        @Override // ax.B.g
        protected int e(Object obj) {
            return a.this.f(obj);
        }

        @Override // ax.B.g
        protected int f(Object obj) {
            return a.this.h(obj);
        }

        @Override // ax.B.g
        protected void g(K k, V v) {
            a.this.put(k, v);
        }

        @Override // ax.B.g
        protected void h(int i) {
            a.this.k(i);
        }

        @Override // ax.B.g
        protected V i(int i, V v) {
            return a.this.l(i, v);
        }
    }

    public a() {
    }

    private g<K, V> n() {
        if (this.k0 == null) {
            this.k0 = new C0058a();
        }
        return this.k0;
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ Object compute(Object obj, BiFunction biFunction) {
        return j$.util.Map.CC.$default$compute(this, obj, biFunction);
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ Object computeIfAbsent(Object obj, Function function) {
        return j$.util.Map.CC.$default$computeIfAbsent(this, obj, function);
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ Object computeIfPresent(Object obj, BiFunction biFunction) {
        return j$.util.Map.CC.$default$computeIfPresent(this, obj, biFunction);
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        return n().l();
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ void forEach(BiConsumer biConsumer) {
        j$.util.Map.CC.$default$forEach(this, biConsumer);
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        return n().m();
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ Object merge(Object obj, Object obj2, BiFunction biFunction) {
        return j$.util.Map.CC.$default$merge(this, obj, obj2, biFunction);
    }

    public boolean o(Collection<?> collection) {
        return g.p(this, collection);
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        c(this.Y + map.size());
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map, j$.util.Map
    public /* synthetic */ void replaceAll(BiFunction biFunction) {
        j$.util.Map.CC.$default$replaceAll(this, biFunction);
    }

    @Override // java.util.Map
    public Collection<V> values() {
        return n().n();
    }

    public a(int i) {
        super(i);
    }

    public a(h hVar) {
        super(hVar);
    }
}
