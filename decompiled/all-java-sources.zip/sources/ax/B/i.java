package ax.B;

/* JADX INFO: loaded from: classes.dex */
public final class i {
    private static final Object a = new Object();
}
