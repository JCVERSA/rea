package ax.B;

/* JADX INFO: loaded from: classes.dex */
public class i<E> implements Cloneable {
    private static final Object h0 = new Object();
    private int[] X;
    private Object[] Y;
    private int Z;
    private boolean q;

    public i() {
        this(10);
    }

    private void g() {
        int i = this.Z;
        int[] iArr = this.X;
        Object[] objArr = this.Y;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != h0) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.q = false;
        this.Z = i2;
    }

    public void b(int i, E e) {
        int i2 = this.Z;
        if (i2 != 0 && i <= this.X[i2 - 1]) {
            m(i, e);
            return;
        }
        if (this.q && i2 >= this.X.length) {
            g();
        }
        int i3 = this.Z;
        if (i3 >= this.X.length) {
            int iE = d.e(i3 + 1);
            int[] iArr = new int[iE];
            Object[] objArr = new Object[iE];
            int[] iArr2 = this.X;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr2 = this.Y;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.X = iArr;
            this.Y = objArr;
        }
        this.X[i3] = i;
        this.Y[i3] = e;
        this.Z = i3 + 1;
    }

    public void c() {
        int i = this.Z;
        Object[] objArr = this.Y;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.Z = 0;
        this.q = false;
    }

    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public i<E> clone() {
        try {
            i<E> iVar = (i) super.clone();
            iVar.X = (int[]) this.X.clone();
            iVar.Y = (Object[]) this.Y.clone();
            return iVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public E h(int i) {
        return i(i, null);
    }

    public E i(int i, E e) {
        E e2;
        int iA = d.a(this.X, this.Z, i);
        return (iA < 0 || (e2 = (E) this.Y[iA]) == h0) ? e : e2;
    }

    public int k(E e) {
        if (this.q) {
            g();
        }
        for (int i = 0; i < this.Z; i++) {
            if (this.Y[i] == e) {
                return i;
            }
        }
        return -1;
    }

    public int l(int i) {
        if (this.q) {
            g();
        }
        return this.X[i];
    }

    public void m(int i, E e) {
        int iA = d.a(this.X, this.Z, i);
        if (iA >= 0) {
            this.Y[iA] = e;
            return;
        }
        int i2 = ~iA;
        int i3 = this.Z;
        if (i2 < i3) {
            Object[] objArr = this.Y;
            if (objArr[i2] == h0) {
                this.X[i2] = i;
                objArr[i2] = e;
                return;
            }
        }
        if (this.q && i3 >= this.X.length) {
            g();
            i2 = ~d.a(this.X, this.Z, i);
        }
        int i4 = this.Z;
        if (i4 >= this.X.length) {
            int iE = d.e(i4 + 1);
            int[] iArr = new int[iE];
            Object[] objArr2 = new Object[iE];
            int[] iArr2 = this.X;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr3 = this.Y;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.X = iArr;
            this.Y = objArr2;
        }
        int i5 = this.Z;
        if (i5 - i2 != 0) {
            int[] iArr3 = this.X;
            int i6 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i6, i5 - i2);
            Object[] objArr4 = this.Y;
            System.arraycopy(objArr4, i2, objArr4, i6, this.Z - i2);
        }
        this.X[i2] = i;
        this.Y[i2] = e;
        this.Z++;
    }

    public void n(int i) {
        int iA = d.a(this.X, this.Z, i);
        if (iA >= 0) {
            Object[] objArr = this.Y;
            Object obj = objArr[iA];
            Object obj2 = h0;
            if (obj != obj2) {
                objArr[iA] = obj2;
                this.q = true;
            }
        }
    }

    public int o() {
        if (this.q) {
            g();
        }
        return this.Z;
    }

    public E p(int i) {
        if (this.q) {
            g();
        }
        return (E) this.Y[i];
    }

    public String toString() {
        if (o() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Z * 28);
        sb.append('{');
        for (int i = 0; i < this.Z; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(l(i));
            sb.append('=');
            E eP = p(i);
            if (eP != this) {
                sb.append(eP);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public i(int i) {
        this.q = false;
        if (i == 0) {
            this.X = d.a;
            this.Y = d.c;
        } else {
            int iE = d.e(i);
            this.X = new int[iE];
            this.Y = new Object[iE];
        }
    }
}
