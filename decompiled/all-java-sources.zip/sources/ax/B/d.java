package ax.B;

import java.util.ConcurrentModificationException;

/* JADX INFO: loaded from: classes.dex */
public final class d {
    public static final <E> void a(b<E> bVar, int i) {
        ax.p335uc.l.f(bVar, "<this>");
        bVar.p(new int[i]);
        bVar.o(new Object[i]);
    }

    public static final <E> int b(b<E> bVar, int i) {
        ax.p335uc.l.f(bVar, "<this>");
        try {
            return ax.C.a.a(bVar.i(), bVar.m(), i);
        } catch (IndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public static final <E> int c(b<E> bVar, Object obj, int i) {
        ax.p335uc.l.f(bVar, "<this>");
        int iM = bVar.m();
        if (iM == 0) {
            return -1;
        }
        int iB = b(bVar, i);
        if (iB < 0 || ax.p335uc.l.a(obj, bVar.f()[iB])) {
            return iB;
        }
        int i2 = iB + 1;
        while (i2 < iM && bVar.i()[i2] == i) {
            if (ax.p335uc.l.a(obj, bVar.f()[i2])) {
                return i2;
            }
            i2++;
        }
        for (int i3 = iB - 1; i3 >= 0 && bVar.i()[i3] == i; i3--) {
            if (ax.p335uc.l.a(obj, bVar.f()[i3])) {
                return i3;
            }
        }
        return ~i2;
    }

    public static final <E> int d(b<E> bVar) {
        ax.p335uc.l.f(bVar, "<this>");
        return c(bVar, null, 0);
    }
}
