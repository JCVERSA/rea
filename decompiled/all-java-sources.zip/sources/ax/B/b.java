package ax.B;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class b<E> implements Collection<E>, Set<E> {
    private static final int[] h0 = new int[0];
    private static final Object[] i0 = new Object[0];
    private static Object[] j0;
    private static int k0;
    private static Object[] l0;
    private static int m0;
    Object[] X;
    int Y;
    private g<E, E> Z;
    private int[] q;

    class a extends g<E, E> {
        a() {
        }

        @Override // ax.B.g
        protected void a() {
            b.this.clear();
        }

        @Override // ax.B.g
        protected Object b(int i, int i2) {
            return b.this.X[i];
        }

        @Override // ax.B.g
        protected Map<E, E> c() {
            throw new UnsupportedOperationException("not a map");
        }

        @Override // ax.B.g
        protected int d() {
            return b.this.Y;
        }

        @Override // ax.B.g
        protected int e(Object obj) {
            return b.this.indexOf(obj);
        }

        @Override // ax.B.g
        protected int f(Object obj) {
            return b.this.indexOf(obj);
        }

        @Override // ax.B.g
        protected void g(E e, E e2) {
            b.this.add(e);
        }

        @Override // ax.B.g
        protected void h(int i) {
            b.this.p(i);
        }

        @Override // ax.B.g
        protected E i(int i, E e) {
            throw new UnsupportedOperationException("not a map");
        }
    }

    public b() {
        this(0);
    }

    private void e(int i) {
        if (i == 8) {
            synchronized (b.class) {
                try {
                    Object[] objArr = l0;
                    if (objArr != null) {
                        this.X = objArr;
                        l0 = (Object[]) objArr[0];
                        this.q = (int[]) objArr[1];
                        objArr[1] = null;
                        objArr[0] = null;
                        m0--;
                        return;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (i == 4) {
            synchronized (b.class) {
                try {
                    Object[] objArr2 = j0;
                    if (objArr2 != null) {
                        this.X = objArr2;
                        j0 = (Object[]) objArr2[0];
                        this.q = (int[]) objArr2[1];
                        objArr2[1] = null;
                        objArr2[0] = null;
                        k0--;
                        return;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.q = new int[i];
        this.X = new Object[i];
    }

    private static void j(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (b.class) {
                try {
                    if (m0 < 10) {
                        objArr[0] = l0;
                        objArr[1] = iArr;
                        for (int i2 = i - 1; i2 >= 2; i2--) {
                            objArr[i2] = null;
                        }
                        l0 = objArr;
                        m0++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (b.class) {
                try {
                    if (k0 < 10) {
                        objArr[0] = j0;
                        objArr[1] = iArr;
                        for (int i3 = i - 1; i3 >= 2; i3--) {
                            objArr[i3] = null;
                        }
                        j0 = objArr;
                        k0++;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    private g<E, E> m() {
        if (this.Z == null) {
            this.Z = new a();
        }
        return this.Z;
    }

    private int n(Object obj, int i) {
        int i2 = this.Y;
        if (i2 == 0) {
            return -1;
        }
        int iA = d.a(this.q, i2, i);
        if (iA < 0 || obj.equals(this.X[iA])) {
            return iA;
        }
        int i3 = iA + 1;
        while (i3 < i2 && this.q[i3] == i) {
            if (obj.equals(this.X[i3])) {
                return i3;
            }
            i3++;
        }
        for (int i4 = iA - 1; i4 >= 0 && this.q[i4] == i; i4--) {
            if (obj.equals(this.X[i4])) {
                return i4;
            }
        }
        return ~i3;
    }

    private int o() {
        int i = this.Y;
        if (i == 0) {
            return -1;
        }
        int iA = d.a(this.q, i, 0);
        if (iA < 0 || this.X[iA] == null) {
            return iA;
        }
        int i2 = iA + 1;
        while (i2 < i && this.q[i2] == 0) {
            if (this.X[i2] == null) {
                return i2;
            }
            i2++;
        }
        for (int i3 = iA - 1; i3 >= 0 && this.q[i3] == 0; i3--) {
            if (this.X[i3] == null) {
                return i3;
            }
        }
        return ~i2;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean add(E e) {
        int i;
        int iN;
        if (e == null) {
            iN = o();
            i = 0;
        } else {
            int iHashCode = e.hashCode();
            i = iHashCode;
            iN = n(e, iHashCode);
        }
        if (iN >= 0) {
            return false;
        }
        int i2 = ~iN;
        int i3 = this.Y;
        int[] iArr = this.q;
        if (i3 >= iArr.length) {
            int i4 = 8;
            if (i3 >= 8) {
                i4 = (i3 >> 1) + i3;
            } else if (i3 < 4) {
                i4 = 4;
            }
            Object[] objArr = this.X;
            e(i4);
            int[] iArr2 = this.q;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.X, 0, objArr.length);
            }
            j(iArr, objArr, this.Y);
        }
        int i5 = this.Y;
        if (i2 < i5) {
            int[] iArr3 = this.q;
            int i6 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i6, i5 - i2);
            Object[] objArr2 = this.X;
            System.arraycopy(objArr2, i2, objArr2, i6, this.Y - i2);
        }
        this.q[i2] = i;
        this.X[i2] = e;
        this.Y++;
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean addAll(Collection<? extends E> collection) {
        f(this.Y + collection.size());
        Iterator<? extends E> it = collection.iterator();
        boolean zAdd = false;
        while (it.hasNext()) {
            zAdd |= add(it.next());
        }
        return zAdd;
    }

    @Override // java.util.Collection, java.util.Set
    public void clear() {
        int i = this.Y;
        if (i != 0) {
            j(this.q, this.X, i);
            this.q = h0;
            this.X = i0;
            this.Y = 0;
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean containsAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (size() != set.size()) {
                return false;
            }
            for (int i = 0; i < this.Y; i++) {
                try {
                    if (!set.contains(q(i))) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    public void f(int i) {
        int[] iArr = this.q;
        if (iArr.length < i) {
            Object[] objArr = this.X;
            e(i);
            int i2 = this.Y;
            if (i2 > 0) {
                System.arraycopy(iArr, 0, this.q, 0, i2);
                System.arraycopy(objArr, 0, this.X, 0, this.Y);
            }
            j(iArr, objArr, this.Y);
        }
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        int[] iArr = this.q;
        int i = this.Y;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            i2 += iArr[i3];
        }
        return i2;
    }

    public int indexOf(Object obj) {
        return obj == null ? o() : n(obj, obj.hashCode());
    }

    @Override // java.util.Collection, java.util.Set
    public boolean isEmpty() {
        return this.Y <= 0;
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator<E> iterator() {
        return m().m().iterator();
    }

    public E p(int i) {
        Object[] objArr = this.X;
        E e = (E) objArr[i];
        int i2 = this.Y;
        if (i2 <= 1) {
            j(this.q, objArr, i2);
            this.q = h0;
            this.X = i0;
            this.Y = 0;
        } else {
            int[] iArr = this.q;
            if (iArr.length <= 8 || i2 >= iArr.length / 3) {
                int i3 = i2 - 1;
                this.Y = i3;
                if (i < i3) {
                    int i4 = i + 1;
                    System.arraycopy(iArr, i4, iArr, i, i3 - i);
                    Object[] objArr2 = this.X;
                    System.arraycopy(objArr2, i4, objArr2, i, this.Y - i);
                }
                this.X[this.Y] = null;
            } else {
                e(i2 > 8 ? i2 + (i2 >> 1) : 8);
                this.Y--;
                if (i > 0) {
                    System.arraycopy(iArr, 0, this.q, 0, i);
                    System.arraycopy(objArr, 0, this.X, 0, i);
                }
                int i5 = this.Y;
                if (i < i5) {
                    int i6 = i + 1;
                    System.arraycopy(iArr, i6, this.q, i, i5 - i);
                    System.arraycopy(objArr, i6, this.X, i, this.Y - i);
                }
            }
        }
        return e;
    }

    public E q(int i) {
        return (E) this.X[i];
    }

    @Override // java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        int iIndexOf = indexOf(obj);
        if (iIndexOf < 0) {
            return false;
        }
        p(iIndexOf);
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean removeAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        boolean zRemove = false;
        while (it.hasNext()) {
            zRemove |= remove(it.next());
        }
        return zRemove;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean retainAll(Collection<?> collection) {
        boolean z = false;
        for (int i = this.Y - 1; i >= 0; i--) {
            if (!collection.contains(this.X[i])) {
                p(i);
                z = true;
            }
        }
        return z;
    }

    @Override // java.util.Collection, java.util.Set
    public int size() {
        return this.Y;
    }

    @Override // java.util.Collection, java.util.Set
    public Object[] toArray() {
        int i = this.Y;
        Object[] objArr = new Object[i];
        System.arraycopy(this.X, 0, objArr, 0, i);
        return objArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Y * 14);
        sb.append('{');
        for (int i = 0; i < this.Y; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            E eQ = q(i);
            if (eQ != this) {
                sb.append(eQ);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public b(int i) {
        if (i == 0) {
            this.q = h0;
            this.X = i0;
        } else {
            e(i);
        }
        this.Y = 0;
    }

    @Override // java.util.Collection, java.util.Set
    public <T> T[] toArray(T[] tArr) {
        if (tArr.length < this.Y) {
            tArr = (T[]) ((Object[]) Array.newInstance(tArr.getClass().getComponentType(), this.Y));
        }
        System.arraycopy(this.X, 0, tArr, 0, this.Y);
        int length = tArr.length;
        int i = this.Y;
        if (length > i) {
            tArr[i] = null;
        }
        return tArr;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public b(Collection<E> collection) {
        this();
        if (collection != 0) {
            addAll(collection);
        }
    }
}
