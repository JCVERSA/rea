package ax.B;

import ax.p127hc.C2087i;
import ax.p127hc.C2093o;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class b<E> implements Collection<E>, Set<E>, ax.p351vc.a {
    private Object[] X;
    private int Y;
    private int[] q;

    private final class a extends g<E> {
        public a() {
            super(b.this.m());
        }

        @Override // ax.B.g
        protected E b(int i) {
            return b.this.s(i);
        }

        @Override // ax.B.g
        protected void c(int i) {
            b.this.n(i);
        }
    }

    public b() {
        this(0, 1, null);
    }

    public b(int i) {
        this.q = ax.C.a.a;
        this.X = ax.C.a.c;
        if (i > 0) {
            d.a(this, i);
        }
    }

    public /* synthetic */ b(int i, int i2, ax.p335uc.g gVar) {
        this((i2 & 1) != 0 ? 0 : i);
    }

    public b(Collection<? extends E> collection) {
        this(0);
        if (collection != null) {
            addAll(collection);
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean add(E e) {
        int i;
        int iC;
        int iM = m();
        if (e == null) {
            iC = d.d(this);
            i = 0;
        } else {
            int iHashCode = e.hashCode();
            i = iHashCode;
            iC = d.c(this, e, iHashCode);
        }
        if (iC >= 0) {
            return false;
        }
        int i2 = ~iC;
        if (iM >= i().length) {
            int i3 = 8;
            if (iM >= 8) {
                i3 = (iM >> 1) + iM;
            } else if (iM < 4) {
                i3 = 4;
            }
            int[] iArrI = i();
            Object[] objArrF = f();
            d.a(this, i3);
            if (iM != m()) {
                throw new ConcurrentModificationException();
            }
            if (!(i().length == 0)) {
                C2087i.i(iArrI, i(), 0, 0, iArrI.length, 6, null);
                C2087i.j(objArrF, f(), 0, 0, objArrF.length, 6, null);
            }
        }
        if (i2 < iM) {
            int i4 = i2 + 1;
            C2087i.e(i(), i(), i4, i2, iM);
            C2087i.g(f(), f(), i4, i2, iM);
        }
        if (iM != m() || i2 >= i().length) {
            throw new ConcurrentModificationException();
        }
        i()[i2] = i;
        f()[i2] = e;
        q(m() + 1);
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean addAll(Collection<? extends E> collection) {
        ax.p335uc.l.f(collection, "elements");
        e(m() + collection.size());
        Iterator<? extends E> it = collection.iterator();
        boolean zAdd = false;
        while (it.hasNext()) {
            zAdd |= add(it.next());
        }
        return zAdd;
    }

    @Override // java.util.Collection, java.util.Set
    public void clear() {
        if (m() != 0) {
            p(ax.C.a.a);
            o(ax.C.a.c);
            q(0);
        }
        if (m() != 0) {
            throw new ConcurrentModificationException();
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean containsAll(Collection<? extends Object> collection) {
        ax.p335uc.l.f(collection, "elements");
        Iterator<? extends Object> it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    public final void e(int i) {
        int iM = m();
        if (i().length < i) {
            int[] iArrI = i();
            Object[] objArrF = f();
            d.a(this, i);
            if (m() > 0) {
                C2087i.i(iArrI, i(), 0, 0, m(), 6, null);
                C2087i.j(objArrF, f(), 0, 0, m(), 6, null);
            }
        }
        if (m() != iM) {
            throw new ConcurrentModificationException();
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Set) || size() != ((Set) obj).size()) {
            return false;
        }
        try {
            int iM = m();
            for (int i = 0; i < iM; i++) {
                if (!((Set) obj).contains(s(i))) {
                    return false;
                }
            }
            return true;
        } catch (ClassCastException | NullPointerException unused) {
            return false;
        }
    }

    public final Object[] f() {
        return this.X;
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        int[] iArrI = i();
        int iM = m();
        int i = 0;
        for (int i2 = 0; i2 < iM; i2++) {
            i += iArrI[i2];
        }
        return i;
    }

    public final int[] i() {
        return this.q;
    }

    public final int indexOf(Object obj) {
        return obj == null ? d.d(this) : d.c(this, obj, obj.hashCode());
    }

    @Override // java.util.Collection, java.util.Set
    public boolean isEmpty() {
        return m() <= 0;
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator<E> iterator() {
        return new a();
    }

    public int j() {
        return this.Y;
    }

    public final int m() {
        return this.Y;
    }

    public final E n(int i) {
        int i2;
        Object[] objArr;
        int iM = m();
        E e = (E) f()[i];
        if (iM <= 1) {
            clear();
            return e;
        }
        int i3 = iM - 1;
        if (i().length <= 8 || m() >= i().length / 3) {
            if (i < i3) {
                int i4 = i + 1;
                C2087i.e(i(), i(), i, i4, iM);
                C2087i.g(f(), f(), i, i4, iM);
            }
            f()[i3] = null;
        } else {
            int iM2 = m() > 8 ? m() + (m() >> 1) : 8;
            int[] iArrI = i();
            Object[] objArrF = f();
            d.a(this, iM2);
            if (i > 0) {
                C2087i.i(iArrI, i(), 0, 0, i, 6, null);
                objArr = objArrF;
                C2087i.j(objArr, f(), 0, 0, i, 6, null);
                i2 = i;
            } else {
                i2 = i;
                objArr = objArrF;
            }
            if (i2 < i3) {
                int i5 = i2 + 1;
                C2087i.e(iArrI, i(), i2, i5, iM);
                C2087i.g(objArr, f(), i2, i5, iM);
            }
        }
        if (iM != m()) {
            throw new ConcurrentModificationException();
        }
        q(i3);
        return e;
    }

    public final void o(Object[] objArr) {
        ax.p335uc.l.f(objArr, "<set-?>");
        this.X = objArr;
    }

    public final void p(int[] iArr) {
        ax.p335uc.l.f(iArr, "<set-?>");
        this.q = iArr;
    }

    public final void q(int i) {
        this.Y = i;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        int iIndexOf = indexOf(obj);
        if (iIndexOf < 0) {
            return false;
        }
        n(iIndexOf);
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean removeAll(Collection<? extends Object> collection) {
        ax.p335uc.l.f(collection, "elements");
        Iterator<? extends Object> it = collection.iterator();
        boolean zRemove = false;
        while (it.hasNext()) {
            zRemove |= remove(it.next());
        }
        return zRemove;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean retainAll(Collection<? extends Object> collection) {
        ax.p335uc.l.f(collection, "elements");
        boolean z = false;
        for (int iM = m() - 1; -1 < iM; iM--) {
            if (!C2093o.z(collection, f()[iM])) {
                n(iM);
                z = true;
            }
        }
        return z;
    }

    public final E s(int i) {
        return (E) f()[i];
    }

    @Override // java.util.Collection, java.util.Set
    public final /* bridge */ int size() {
        return j();
    }

    @Override // java.util.Collection, java.util.Set
    public final Object[] toArray() {
        return C2087i.l(this.X, 0, this.Y);
    }

    @Override // java.util.Collection, java.util.Set
    public final <T> T[] toArray(T[] tArr) {
        ax.p335uc.l.f(tArr, "array");
        T[] tArr2 = (T[]) c.a(tArr, this.Y);
        C2087i.g(this.X, tArr2, 0, 0, this.Y);
        ax.p335uc.l.e(tArr2, "result");
        return tArr2;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(m() * 14);
        sb.append('{');
        int iM = m();
        for (int i = 0; i < iM; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            E eS = s(i);
            if (eS != this) {
                sb.append(eS);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        String string = sb.toString();
        ax.p335uc.l.e(string, "StringBuilder(capacity).…builderAction).toString()");
        return string;
    }
}
