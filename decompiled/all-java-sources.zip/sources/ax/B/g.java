package ax.B;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public abstract class g<T> implements Iterator<T>, ax.p351vc.a {
    private int X;
    private boolean Y;
    private int q;

    public g(int i) {
        this.q = i;
    }

    protected abstract T b(int i);

    protected abstract void c(int i);

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.X < this.q;
    }

    @Override // java.util.Iterator
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        T tB = b(this.X);
        this.X++;
        this.Y = true;
        return tB;
    }

    @Override // java.util.Iterator
    public void remove() {
        if (!this.Y) {
            throw new IllegalStateException("Call next() before removing an element.");
        }
        int i = this.X - 1;
        this.X = i;
        c(i);
        this.q--;
        this.Y = false;
    }
}
