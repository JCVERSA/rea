package ax.B;

/* JADX INFO: loaded from: classes.dex */
public final class f {
    public static final f a = new f();

    private f() {
    }
}
