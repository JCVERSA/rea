package ax.B;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class f<K, V> {
    private final LinkedHashMap<K, V> a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;

    public f(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.c = i;
        this.a = new LinkedHashMap<>(0, 0.75f, true);
    }

    private int f(K k, V v) {
        int iG = g(k, v);
        if (iG >= 0) {
            return iG;
        }
        throw new IllegalStateException("Negative size: " + k + "=" + v);
    }

    protected V a(K k) {
        return null;
    }

    public final V c(K k) {
        V vPut;
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        synchronized (this) {
            try {
                V v = this.a.get(k);
                if (v != null) {
                    this.g++;
                    return v;
                }
                this.h++;
                V vA = a(k);
                if (vA == null) {
                    return null;
                }
                synchronized (this) {
                    try {
                        this.e++;
                        vPut = this.a.put(k, vA);
                        if (vPut != null) {
                            this.a.put(k, vPut);
                        } else {
                            this.b += f(k, vA);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                if (vPut != null) {
                    b(false, k, vA, vPut);
                    return vPut;
                }
                i(this.c);
                return vA;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final V d(K k, V v) {
        V vPut;
        if (k == null || v == null) {
            throw new NullPointerException("key == null || value == null");
        }
        synchronized (this) {
            try {
                this.d++;
                this.b += f(k, v);
                vPut = this.a.put(k, v);
                if (vPut != null) {
                    this.b -= f(k, vPut);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (vPut != null) {
            b(false, k, vPut, v);
        }
        i(this.c);
        return vPut;
    }

    public final V e(K k) {
        V vRemove;
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        synchronized (this) {
            try {
                vRemove = this.a.remove(k);
                if (vRemove != null) {
                    this.b -= f(k, vRemove);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (vRemove != null) {
            b(false, k, vRemove, null);
        }
        return vRemove;
    }

    protected int g(K k, V v) {
        return 1;
    }

    public final synchronized Map<K, V> h() {
        return new LinkedHashMap(this.a);
    }

    public void i(int i) {
        K key;
        V value;
        while (true) {
            synchronized (this) {
                try {
                    if (this.b < 0 || (this.a.isEmpty() && this.b != 0)) {
                        break;
                    }
                    if (this.b > i && !this.a.isEmpty()) {
                        Map.Entry<K, V> next = this.a.entrySet().iterator().next();
                        key = next.getKey();
                        value = next.getValue();
                        this.a.remove(key);
                        this.b -= f(key, value);
                        this.f++;
                    }
                    return;
                } catch (Throwable th) {
                    throw th;
                }
            }
            b(true, key, value, null);
        }
        throw new IllegalStateException(getClass().getName() + ".sizeOf() is reporting inconsistent results!");
    }

    public final synchronized String toString() {
        int i;
        int i2;
        try {
            i = this.g;
            i2 = this.h + i;
        } catch (Throwable th) {
            throw th;
        }
        return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", Integer.valueOf(this.c), Integer.valueOf(this.g), Integer.valueOf(this.h), Integer.valueOf(i2 != 0 ? (i * 100) / i2 : 0));
    }

    protected void b(boolean z, K k, V v, V v2) {
    }
}
