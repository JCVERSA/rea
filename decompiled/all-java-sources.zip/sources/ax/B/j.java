package ax.B;

import ax.p111gc.t;
import ax.p127hc.C2093o;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class j<K, V> {
    private int a;
    private final ax.C.c<K, V> b;
    private final ax.C.b c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;

    public j(int i) {
        this.a = i;
        if (i <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.b = new ax.C.c<>(0, 0.75f);
        this.c = new ax.C.b();
    }

    private final int f(K k, V v) {
        int iG = g(k, v);
        if (iG >= 0) {
            return iG;
        }
        throw new IllegalStateException(("Negative size: " + k + '=' + v).toString());
    }

    protected V a(K k) {
        ax.p335uc.l.f(k, "key");
        return null;
    }

    protected void b(boolean z, K k, V v, V v2) {
        ax.p335uc.l.f(k, "key");
        ax.p335uc.l.f(v, "oldValue");
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final V c(K k) {
        V v;
        ax.p335uc.l.f(k, "key");
        synchronized (this.c) {
            V vA = this.b.a(k);
            if (vA != null) {
                this.h++;
                return vA;
            }
            this.i++;
            V vA2 = a(k);
            if (vA2 == null) {
                return null;
            }
            synchronized (this.c) {
                try {
                    this.f++;
                    v = (V) this.b.d(k, vA2);
                    if (v != null) {
                        this.b.d(k, v);
                    } else {
                        this.d += f(k, vA2);
                        t tVar = t.a;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (v != null) {
                b(false, k, vA2, v);
                return v;
            }
            i(this.a);
            return vA2;
        }
    }

    public final V d(K k, V v) {
        V vD;
        ax.p335uc.l.f(k, "key");
        ax.p335uc.l.f(v, "value");
        synchronized (this.c) {
            try {
                this.e++;
                this.d += f(k, v);
                vD = this.b.d(k, v);
                if (vD != null) {
                    this.d -= f(k, vD);
                }
                t tVar = t.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (vD != null) {
            b(false, k, vD, v);
        }
        i(this.a);
        return vD;
    }

    public final V e(K k) {
        V vE;
        ax.p335uc.l.f(k, "key");
        synchronized (this.c) {
            try {
                vE = this.b.e(k);
                if (vE != null) {
                    this.d -= f(k, vE);
                }
                t tVar = t.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (vE != null) {
            b(false, k, vE, null);
        }
        return vE;
    }

    protected int g(K k, V v) {
        ax.p335uc.l.f(k, "key");
        ax.p335uc.l.f(v, "value");
        return 1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Map<K, V> h() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        synchronized (this.c) {
            try {
                Iterator<T> it = this.b.b().iterator();
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    linkedHashMap.put(entry.getKey(), entry.getValue());
                }
                t tVar = t.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        return linkedHashMap;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void i(int i) {
        Object key;
        Object value;
        while (true) {
            synchronized (this.c) {
                try {
                    if (this.d < 0 || (this.b.c() && this.d != 0)) {
                        break;
                    }
                    if (this.d > i && !this.b.c()) {
                        Map.Entry entry = (Map.Entry) C2093o.F(this.b.b());
                        if (entry == null) {
                            return;
                        }
                        key = entry.getKey();
                        value = entry.getValue();
                        this.b.e((K) key);
                        this.d -= f(key, value);
                        this.g++;
                    }
                    return;
                } catch (Throwable th) {
                    throw th;
                }
            }
            b(true, key, value, null);
        }
        throw new IllegalStateException("LruCache.sizeOf() is reporting inconsistent results!");
    }

    public String toString() {
        String str;
        synchronized (this.c) {
            try {
                int i = this.h;
                int i2 = this.i + i;
                str = "LruCache[maxSize=" + this.a + ",hits=" + this.h + ",misses=" + this.i + ",hitRate=" + (i2 != 0 ? (i * 100) / i2 : 0) + "%]";
            } catch (Throwable th) {
                throw th;
            }
        }
        return str;
    }
}
