package ax.B;

import ax.p127hc.C2087i;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class l<E> implements Cloneable {
    public /* synthetic */ int[] X;
    public /* synthetic */ Object[] Y;
    public /* synthetic */ int Z;
    public /* synthetic */ boolean q;

    public l() {
        this(0, 1, null);
    }

    public l(int i) {
        if (i == 0) {
            this.X = ax.C.a.a;
            this.Y = ax.C.a.c;
        } else {
            int iE = ax.C.a.e(i);
            this.X = new int[iE];
            this.Y = new Object[iE];
        }
    }

    public /* synthetic */ l(int i, int i2, ax.p335uc.g gVar) {
        this((i2 & 1) != 0 ? 10 : i);
    }

    public void b(int i, E e) {
        int i2 = this.Z;
        if (i2 != 0 && i <= this.X[i2 - 1]) {
            l(i, e);
            return;
        }
        if (this.q && i2 >= this.X.length) {
            m.f(this);
        }
        int i3 = this.Z;
        if (i3 >= this.X.length) {
            int iE = ax.C.a.e(i3 + 1);
            int[] iArrCopyOf = Arrays.copyOf(this.X, iE);
            ax.p335uc.l.e(iArrCopyOf, "copyOf(this, newSize)");
            this.X = iArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.Y, iE);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.Y = objArrCopyOf;
        }
        this.X[i3] = i;
        this.Y[i3] = e;
        this.Z = i3 + 1;
    }

    public void c() {
        int i = this.Z;
        Object[] objArr = this.Y;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.Z = 0;
        this.q = false;
    }

    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public l<E> clone() throws CloneNotSupportedException {
        Object objClone = super.clone();
        ax.p335uc.l.d(objClone, "null cannot be cast to non-null type androidx.collection.SparseArrayCompat<E of androidx.collection.SparseArrayCompat>");
        l<E> lVar = (l) objClone;
        lVar.X = (int[]) this.X.clone();
        lVar.Y = (Object[]) this.Y.clone();
        return lVar;
    }

    public E e(int i) {
        return (E) m.c(this, i);
    }

    public E g(int i, E e) {
        return (E) m.d(this, i, e);
    }

    public int j(E e) {
        if (this.q) {
            m.f(this);
        }
        int i = this.Z;
        for (int i2 = 0; i2 < i; i2++) {
            if (this.Y[i2] == e) {
                return i2;
            }
        }
        return -1;
    }

    public int k(int i) {
        if (this.q) {
            m.f(this);
        }
        return this.X[i];
    }

    public void l(int i, E e) {
        int iA = ax.C.a.a(this.X, this.Z, i);
        if (iA >= 0) {
            this.Y[iA] = e;
            return;
        }
        int i2 = ~iA;
        if (i2 < this.Z && this.Y[i2] == m.a) {
            this.X[i2] = i;
            this.Y[i2] = e;
            return;
        }
        if (this.q && this.Z >= this.X.length) {
            m.f(this);
            i2 = ~ax.C.a.a(this.X, this.Z, i);
        }
        int i3 = this.Z;
        if (i3 >= this.X.length) {
            int iE = ax.C.a.e(i3 + 1);
            int[] iArrCopyOf = Arrays.copyOf(this.X, iE);
            ax.p335uc.l.e(iArrCopyOf, "copyOf(this, newSize)");
            this.X = iArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.Y, iE);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.Y = objArrCopyOf;
        }
        int i4 = this.Z;
        if (i4 - i2 != 0) {
            int[] iArr = this.X;
            int i5 = i2 + 1;
            C2087i.e(iArr, iArr, i5, i2, i4);
            Object[] objArr = this.Y;
            C2087i.g(objArr, objArr, i5, i2, this.Z);
        }
        this.X[i2] = i;
        this.Y[i2] = e;
        this.Z++;
    }

    public void m(int i) {
        m.e(this, i);
    }

    public int n() {
        if (this.q) {
            m.f(this);
        }
        return this.Z;
    }

    public E o(int i) {
        if (this.q) {
            m.f(this);
        }
        return (E) this.Y[i];
    }

    public String toString() {
        if (n() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Z * 28);
        sb.append('{');
        int i = this.Z;
        for (int i2 = 0; i2 < i; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            sb.append(k(i2));
            sb.append('=');
            E eO = o(i2);
            if (eO != this) {
                sb.append(eO);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        String string = sb.toString();
        ax.p335uc.l.e(string, "buffer.toString()");
        return string;
    }
}
