package ax.B;

/* JADX INFO: loaded from: classes.dex */
public class e<E> implements Cloneable {
    private static final Object h0 = new Object();
    private long[] X;
    private Object[] Y;
    private int Z;
    private boolean q;

    public e() {
        this(10);
    }

    private void g() {
        int i = this.Z;
        long[] jArr = this.X;
        Object[] objArr = this.Y;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != h0) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.q = false;
        this.Z = i2;
    }

    public void b(long j, E e) {
        int i = this.Z;
        if (i != 0 && j <= this.X[i - 1]) {
            m(j, e);
            return;
        }
        if (this.q && i >= this.X.length) {
            g();
        }
        int i2 = this.Z;
        if (i2 >= this.X.length) {
            int iF = d.f(i2 + 1);
            long[] jArr = new long[iF];
            Object[] objArr = new Object[iF];
            long[] jArr2 = this.X;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.Y;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.X = jArr;
            this.Y = objArr;
        }
        this.X[i2] = j;
        this.Y[i2] = e;
        this.Z = i2 + 1;
    }

    public void c() {
        int i = this.Z;
        Object[] objArr = this.Y;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.Z = 0;
        this.q = false;
    }

    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public e<E> clone() {
        try {
            e<E> eVar = (e) super.clone();
            eVar.X = (long[]) this.X.clone();
            eVar.Y = (Object[]) this.Y.clone();
            return eVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public E h(long j) {
        return i(j, null);
    }

    public E i(long j, E e) {
        E e2;
        int iB = d.b(this.X, this.Z, j);
        return (iB < 0 || (e2 = (E) this.Y[iB]) == h0) ? e : e2;
    }

    public int k(long j) {
        if (this.q) {
            g();
        }
        return d.b(this.X, this.Z, j);
    }

    public long l(int i) {
        if (this.q) {
            g();
        }
        return this.X[i];
    }

    public void m(long j, E e) {
        int iB = d.b(this.X, this.Z, j);
        if (iB >= 0) {
            this.Y[iB] = e;
            return;
        }
        int i = ~iB;
        int i2 = this.Z;
        if (i < i2) {
            Object[] objArr = this.Y;
            if (objArr[i] == h0) {
                this.X[i] = j;
                objArr[i] = e;
                return;
            }
        }
        if (this.q && i2 >= this.X.length) {
            g();
            i = ~d.b(this.X, this.Z, j);
        }
        int i3 = this.Z;
        if (i3 >= this.X.length) {
            int iF = d.f(i3 + 1);
            long[] jArr = new long[iF];
            Object[] objArr2 = new Object[iF];
            long[] jArr2 = this.X;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.Y;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.X = jArr;
            this.Y = objArr2;
        }
        int i4 = this.Z;
        if (i4 - i != 0) {
            long[] jArr3 = this.X;
            int i5 = i + 1;
            System.arraycopy(jArr3, i, jArr3, i5, i4 - i);
            Object[] objArr4 = this.Y;
            System.arraycopy(objArr4, i, objArr4, i5, this.Z - i);
        }
        this.X[i] = j;
        this.Y[i] = e;
        this.Z++;
    }

    public void n(long j) {
        int iB = d.b(this.X, this.Z, j);
        if (iB >= 0) {
            Object[] objArr = this.Y;
            Object obj = objArr[iB];
            Object obj2 = h0;
            if (obj != obj2) {
                objArr[iB] = obj2;
                this.q = true;
            }
        }
    }

    public void o(int i) {
        Object[] objArr = this.Y;
        Object obj = objArr[i];
        Object obj2 = h0;
        if (obj != obj2) {
            objArr[i] = obj2;
            this.q = true;
        }
    }

    public int p() {
        if (this.q) {
            g();
        }
        return this.Z;
    }

    public E q(int i) {
        if (this.q) {
            g();
        }
        return (E) this.Y[i];
    }

    public String toString() {
        if (p() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Z * 28);
        sb.append('{');
        for (int i = 0; i < this.Z; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(l(i));
            sb.append('=');
            E eQ = q(i);
            if (eQ != this) {
                sb.append(eQ);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public e(int i) {
        this.q = false;
        if (i == 0) {
            this.X = d.b;
            this.Y = d.c;
        } else {
            int iF = d.f(i);
            this.X = new long[iF];
            this.Y = new Object[iF];
        }
    }
}
