package ax.B;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class h<K, V> {
    static Object[] Z;
    static int h0;
    static Object[] i0;
    static int j0;
    Object[] X;
    int Y;
    int[] q;

    public h() {
        this.q = d.a;
        this.X = d.c;
        this.Y = 0;
    }

    private void a(int i) {
        if (i == 8) {
            synchronized (h.class) {
                try {
                    Object[] objArr = i0;
                    if (objArr != null) {
                        this.X = objArr;
                        i0 = (Object[]) objArr[0];
                        this.q = (int[]) objArr[1];
                        objArr[1] = null;
                        objArr[0] = null;
                        j0--;
                        return;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (i == 4) {
            synchronized (h.class) {
                try {
                    Object[] objArr2 = Z;
                    if (objArr2 != null) {
                        this.X = objArr2;
                        Z = (Object[]) objArr2[0];
                        this.q = (int[]) objArr2[1];
                        objArr2[1] = null;
                        objArr2[0] = null;
                        h0--;
                        return;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.q = new int[i];
        this.X = new Object[i << 1];
    }

    private static int b(int[] iArr, int i, int i2) {
        try {
            return d.a(iArr, i, i2);
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    private static void d(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (h.class) {
                try {
                    if (j0 < 10) {
                        objArr[0] = i0;
                        objArr[1] = iArr;
                        for (int i2 = (i << 1) - 1; i2 >= 2; i2--) {
                            objArr[i2] = null;
                        }
                        i0 = objArr;
                        j0++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (h.class) {
                try {
                    if (h0 < 10) {
                        objArr[0] = Z;
                        objArr[1] = iArr;
                        for (int i3 = (i << 1) - 1; i3 >= 2; i3--) {
                            objArr[i3] = null;
                        }
                        Z = objArr;
                        h0++;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    public void c(int i) {
        int i2 = this.Y;
        int[] iArr = this.q;
        if (iArr.length < i) {
            Object[] objArr = this.X;
            a(i);
            if (this.Y > 0) {
                System.arraycopy(iArr, 0, this.q, 0, i2);
                System.arraycopy(objArr, 0, this.X, 0, i2 << 1);
            }
            d(iArr, objArr, i2);
        }
        if (this.Y != i2) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        int i = this.Y;
        if (i > 0) {
            int[] iArr = this.q;
            Object[] objArr = this.X;
            this.q = d.a;
            this.X = d.c;
            this.Y = 0;
            d(iArr, objArr, i);
        }
        if (this.Y > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return f(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return h(obj) >= 0;
    }

    int e(Object obj, int i) {
        int i2 = this.Y;
        if (i2 == 0) {
            return -1;
        }
        int iB = b(this.q, i2, i);
        if (iB < 0 || obj.equals(this.X[iB << 1])) {
            return iB;
        }
        int i3 = iB + 1;
        while (i3 < i2 && this.q[i3] == i) {
            if (obj.equals(this.X[i3 << 1])) {
                return i3;
            }
            i3++;
        }
        for (int i4 = iB - 1; i4 >= 0 && this.q[i4] == i; i4--) {
            if (obj.equals(this.X[i4 << 1])) {
                return i4;
            }
        }
        return ~i3;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof h) {
            h hVar = (h) obj;
            if (size() != hVar.size()) {
                return false;
            }
            for (int i = 0; i < this.Y; i++) {
                try {
                    K kI = i(i);
                    V vM = m(i);
                    Object obj2 = hVar.get(kI);
                    if (vM == null) {
                        if (obj2 != null || !hVar.containsKey(kI)) {
                            return false;
                        }
                    } else if (!vM.equals(obj2)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (size() != map.size()) {
                return false;
            }
            for (int i2 = 0; i2 < this.Y; i2++) {
                try {
                    K kI2 = i(i2);
                    V vM2 = m(i2);
                    Object obj3 = map.get(kI2);
                    if (vM2 == null) {
                        if (obj3 != null || !map.containsKey(kI2)) {
                            return false;
                        }
                    } else if (!vM2.equals(obj3)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    public int f(Object obj) {
        return obj == null ? g() : e(obj, obj.hashCode());
    }

    int g() {
        int i = this.Y;
        if (i == 0) {
            return -1;
        }
        int iB = b(this.q, i, 0);
        if (iB < 0 || this.X[iB << 1] == null) {
            return iB;
        }
        int i2 = iB + 1;
        while (i2 < i && this.q[i2] == 0) {
            if (this.X[i2 << 1] == null) {
                return i2;
            }
            i2++;
        }
        for (int i3 = iB - 1; i3 >= 0 && this.q[i3] == 0; i3--) {
            if (this.X[i3 << 1] == null) {
                return i3;
            }
        }
        return ~i2;
    }

    public V get(Object obj) {
        return getOrDefault(obj, null);
    }

    public V getOrDefault(Object obj, V v) {
        int iF = f(obj);
        return iF >= 0 ? (V) this.X[(iF << 1) + 1] : v;
    }

    int h(Object obj) {
        int i = this.Y * 2;
        Object[] objArr = this.X;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (obj.equals(objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    public int hashCode() {
        int[] iArr = this.q;
        Object[] objArr = this.X;
        int i = this.Y;
        int i2 = 1;
        int i3 = 0;
        int iHashCode = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            iHashCode += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return iHashCode;
    }

    public K i(int i) {
        return (K) this.X[i << 1];
    }

    public boolean isEmpty() {
        return this.Y <= 0;
    }

    public void j(h<? extends K, ? extends V> hVar) {
        int i = hVar.Y;
        c(this.Y + i);
        if (this.Y != 0) {
            for (int i2 = 0; i2 < i; i2++) {
                put(hVar.i(i2), hVar.m(i2));
            }
        } else if (i > 0) {
            System.arraycopy(hVar.q, 0, this.q, 0, i);
            System.arraycopy(hVar.X, 0, this.X, 0, i << 1);
            this.Y = i;
        }
    }

    public V k(int i) {
        Object[] objArr = this.X;
        int i2 = i << 1;
        V v = (V) objArr[i2 + 1];
        int i3 = this.Y;
        int i4 = 0;
        if (i3 <= 1) {
            d(this.q, objArr, i3);
            this.q = d.a;
            this.X = d.c;
        } else {
            int i5 = i3 - 1;
            int[] iArr = this.q;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                if (i < i5) {
                    int i6 = i + 1;
                    int i7 = i5 - i;
                    System.arraycopy(iArr, i6, iArr, i, i7);
                    Object[] objArr2 = this.X;
                    System.arraycopy(objArr2, i6 << 1, objArr2, i2, i7 << 1);
                }
                Object[] objArr3 = this.X;
                int i8 = i5 << 1;
                objArr3[i8] = null;
                objArr3[i8 + 1] = null;
            } else {
                a(i3 > 8 ? i3 + (i3 >> 1) : 8);
                if (i3 != this.Y) {
                    throw new ConcurrentModificationException();
                }
                if (i > 0) {
                    System.arraycopy(iArr, 0, this.q, 0, i);
                    System.arraycopy(objArr, 0, this.X, 0, i2);
                }
                if (i < i5) {
                    int i9 = i + 1;
                    int i10 = i5 - i;
                    System.arraycopy(iArr, i9, this.q, i, i10);
                    System.arraycopy(objArr, i9 << 1, this.X, i2, i10 << 1);
                }
            }
            i4 = i5;
        }
        if (i3 != this.Y) {
            throw new ConcurrentModificationException();
        }
        this.Y = i4;
        return v;
    }

    public V l(int i, V v) {
        int i2 = (i << 1) + 1;
        Object[] objArr = this.X;
        V v2 = (V) objArr[i2];
        objArr[i2] = v;
        return v2;
    }

    public V m(int i) {
        return (V) this.X[(i << 1) + 1];
    }

    public V put(K k, V v) {
        int i;
        int iE;
        int i2 = this.Y;
        if (k == null) {
            iE = g();
            i = 0;
        } else {
            int iHashCode = k.hashCode();
            i = iHashCode;
            iE = e(k, iHashCode);
        }
        if (iE >= 0) {
            int i3 = (iE << 1) + 1;
            Object[] objArr = this.X;
            V v2 = (V) objArr[i3];
            objArr[i3] = v;
            return v2;
        }
        int i4 = ~iE;
        int[] iArr = this.q;
        if (i2 >= iArr.length) {
            int i5 = 8;
            if (i2 >= 8) {
                i5 = (i2 >> 1) + i2;
            } else if (i2 < 4) {
                i5 = 4;
            }
            Object[] objArr2 = this.X;
            a(i5);
            if (i2 != this.Y) {
                throw new ConcurrentModificationException();
            }
            int[] iArr2 = this.q;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr2, 0, this.X, 0, objArr2.length);
            }
            d(iArr, objArr2, i2);
        }
        if (i4 < i2) {
            int[] iArr3 = this.q;
            int i6 = i4 + 1;
            System.arraycopy(iArr3, i4, iArr3, i6, i2 - i4);
            Object[] objArr3 = this.X;
            System.arraycopy(objArr3, i4 << 1, objArr3, i6 << 1, (this.Y - i4) << 1);
        }
        int i7 = this.Y;
        if (i2 == i7) {
            int[] iArr4 = this.q;
            if (i4 < iArr4.length) {
                iArr4[i4] = i;
                Object[] objArr4 = this.X;
                int i8 = i4 << 1;
                objArr4[i8] = k;
                objArr4[i8 + 1] = v;
                this.Y = i7 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V v2 = get(k);
        return v2 == null ? put(k, v) : v2;
    }

    public V remove(Object obj) {
        int iF = f(obj);
        if (iF >= 0) {
            return k(iF);
        }
        return null;
    }

    public V replace(K k, V v) {
        int iF = f(k);
        if (iF >= 0) {
            return l(iF, v);
        }
        return null;
    }

    public int size() {
        return this.Y;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Y * 28);
        sb.append('{');
        for (int i = 0; i < this.Y; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            K kI = i(i);
            if (kI != this) {
                sb.append(kI);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            V vM = m(i);
            if (vM != this) {
                sb.append(vM);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public boolean remove(Object obj, Object obj2) {
        int iF = f(obj);
        if (iF < 0) {
            return false;
        }
        V vM = m(iF);
        if (obj2 != vM && (obj2 == null || !obj2.equals(vM))) {
            return false;
        }
        k(iF);
        return true;
    }

    public boolean replace(K k, V v, V v2) {
        int iF = f(k);
        if (iF < 0) {
            return false;
        }
        V vM = m(iF);
        if (vM != v && (v == null || !v.equals(vM))) {
            return false;
        }
        l(iF, v2);
        return true;
    }

    public h(int i) {
        if (i == 0) {
            this.q = d.a;
            this.X = d.c;
        } else {
            a(i);
        }
        this.Y = 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public h(h<K, V> hVar) {
        this();
        if (hVar != 0) {
            j(hVar);
        }
    }
}
