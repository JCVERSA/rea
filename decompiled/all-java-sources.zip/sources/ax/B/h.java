package ax.B;

import ax.p127hc.C2087i;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class h<E> implements Cloneable {
    public /* synthetic */ long[] X;
    public /* synthetic */ Object[] Y;
    public /* synthetic */ int Z;
    public /* synthetic */ boolean q;

    public h() {
        this(0, 1, null);
    }

    public h(int i) {
        if (i == 0) {
            this.X = ax.C.a.b;
            this.Y = ax.C.a.c;
        } else {
            int iF = ax.C.a.f(i);
            this.X = new long[iF];
            this.Y = new Object[iF];
        }
    }

    public /* synthetic */ h(int i, int i2, ax.p335uc.g gVar) {
        this((i2 & 1) != 0 ? 10 : i);
    }

    public void b(long j, E e) {
        int i = this.Z;
        if (i != 0 && j <= this.X[i - 1]) {
            l(j, e);
            return;
        }
        if (this.q) {
            long[] jArr = this.X;
            if (i >= jArr.length) {
                Object[] objArr = this.Y;
                int i2 = 0;
                for (int i3 = 0; i3 < i; i3++) {
                    Object obj = objArr[i3];
                    if (obj != i.a) {
                        if (i3 != i2) {
                            jArr[i2] = jArr[i3];
                            objArr[i2] = obj;
                            objArr[i3] = null;
                        }
                        i2++;
                    }
                }
                this.q = false;
                this.Z = i2;
            }
        }
        int i4 = this.Z;
        if (i4 >= this.X.length) {
            int iF = ax.C.a.f(i4 + 1);
            long[] jArrCopyOf = Arrays.copyOf(this.X, iF);
            ax.p335uc.l.e(jArrCopyOf, "copyOf(this, newSize)");
            this.X = jArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.Y, iF);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.Y = objArrCopyOf;
        }
        this.X[i4] = j;
        this.Y[i4] = e;
        this.Z = i4 + 1;
    }

    public void c() {
        int i = this.Z;
        Object[] objArr = this.Y;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.Z = 0;
        this.q = false;
    }

    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public h<E> clone() throws CloneNotSupportedException {
        Object objClone = super.clone();
        ax.p335uc.l.d(objClone, "null cannot be cast to non-null type androidx.collection.LongSparseArray<E of androidx.collection.LongSparseArray>");
        h<E> hVar = (h) objClone;
        hVar.X = (long[]) this.X.clone();
        hVar.Y = (Object[]) this.Y.clone();
        return hVar;
    }

    public E e(long j) {
        int iB = ax.C.a.b(this.X, this.Z, j);
        if (iB < 0 || this.Y[iB] == i.a) {
            return null;
        }
        return (E) this.Y[iB];
    }

    public E g(long j, E e) {
        int iB = ax.C.a.b(this.X, this.Z, j);
        return (iB < 0 || this.Y[iB] == i.a) ? e : (E) this.Y[iB];
    }

    public int j(long j) {
        if (this.q) {
            int i = this.Z;
            long[] jArr = this.X;
            Object[] objArr = this.Y;
            int i2 = 0;
            for (int i3 = 0; i3 < i; i3++) {
                Object obj = objArr[i3];
                if (obj != i.a) {
                    if (i3 != i2) {
                        jArr[i2] = jArr[i3];
                        objArr[i2] = obj;
                        objArr[i3] = null;
                    }
                    i2++;
                }
            }
            this.q = false;
            this.Z = i2;
        }
        return ax.C.a.b(this.X, this.Z, j);
    }

    public long k(int i) {
        int i2;
        if (i < 0 || i >= (i2 = this.Z)) {
            throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
        }
        if (this.q) {
            long[] jArr = this.X;
            Object[] objArr = this.Y;
            int i3 = 0;
            for (int i4 = 0; i4 < i2; i4++) {
                Object obj = objArr[i4];
                if (obj != i.a) {
                    if (i4 != i3) {
                        jArr[i3] = jArr[i4];
                        objArr[i3] = obj;
                        objArr[i4] = null;
                    }
                    i3++;
                }
            }
            this.q = false;
            this.Z = i3;
        }
        return this.X[i];
    }

    public void l(long j, E e) {
        int iB = ax.C.a.b(this.X, this.Z, j);
        if (iB >= 0) {
            this.Y[iB] = e;
            return;
        }
        int i = ~iB;
        if (i < this.Z && this.Y[i] == i.a) {
            this.X[i] = j;
            this.Y[i] = e;
            return;
        }
        if (this.q) {
            int i2 = this.Z;
            long[] jArr = this.X;
            if (i2 >= jArr.length) {
                Object[] objArr = this.Y;
                int i3 = 0;
                for (int i4 = 0; i4 < i2; i4++) {
                    Object obj = objArr[i4];
                    if (obj != i.a) {
                        if (i4 != i3) {
                            jArr[i3] = jArr[i4];
                            objArr[i3] = obj;
                            objArr[i4] = null;
                        }
                        i3++;
                    }
                }
                this.q = false;
                this.Z = i3;
                i = ~ax.C.a.b(this.X, i3, j);
            }
        }
        int i5 = this.Z;
        if (i5 >= this.X.length) {
            int iF = ax.C.a.f(i5 + 1);
            long[] jArrCopyOf = Arrays.copyOf(this.X, iF);
            ax.p335uc.l.e(jArrCopyOf, "copyOf(this, newSize)");
            this.X = jArrCopyOf;
            Object[] objArrCopyOf = Arrays.copyOf(this.Y, iF);
            ax.p335uc.l.e(objArrCopyOf, "copyOf(this, newSize)");
            this.Y = objArrCopyOf;
        }
        int i6 = this.Z;
        if (i6 - i != 0) {
            long[] jArr2 = this.X;
            int i7 = i + 1;
            C2087i.f(jArr2, jArr2, i7, i, i6);
            Object[] objArr2 = this.Y;
            C2087i.g(objArr2, objArr2, i7, i, this.Z);
        }
        this.X[i] = j;
        this.Y[i] = e;
        this.Z++;
    }

    public void m(long j) {
        int iB = ax.C.a.b(this.X, this.Z, j);
        if (iB < 0 || this.Y[iB] == i.a) {
            return;
        }
        this.Y[iB] = i.a;
        this.q = true;
    }

    public void n(int i) {
        if (this.Y[i] != i.a) {
            this.Y[i] = i.a;
            this.q = true;
        }
    }

    public int o() {
        if (this.q) {
            int i = this.Z;
            long[] jArr = this.X;
            Object[] objArr = this.Y;
            int i2 = 0;
            for (int i3 = 0; i3 < i; i3++) {
                Object obj = objArr[i3];
                if (obj != i.a) {
                    if (i3 != i2) {
                        jArr[i2] = jArr[i3];
                        objArr[i2] = obj;
                        objArr[i3] = null;
                    }
                    i2++;
                }
            }
            this.q = false;
            this.Z = i2;
        }
        return this.Z;
    }

    public E q(int i) {
        int i2;
        if (i < 0 || i >= (i2 = this.Z)) {
            throw new IllegalArgumentException(("Expected index to be within 0..size()-1, but was " + i).toString());
        }
        if (this.q) {
            long[] jArr = this.X;
            Object[] objArr = this.Y;
            int i3 = 0;
            for (int i4 = 0; i4 < i2; i4++) {
                Object obj = objArr[i4];
                if (obj != i.a) {
                    if (i4 != i3) {
                        jArr[i3] = jArr[i4];
                        objArr[i3] = obj;
                        objArr[i4] = null;
                    }
                    i3++;
                }
            }
            this.q = false;
            this.Z = i3;
        }
        return (E) this.Y[i];
    }

    public String toString() {
        if (o() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.Z * 28);
        sb.append('{');
        int i = this.Z;
        for (int i2 = 0; i2 < i; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            sb.append(k(i2));
            sb.append('=');
            E eQ = q(i2);
            if (eQ != sb) {
                sb.append(eQ);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        String string = sb.toString();
        ax.p335uc.l.e(string, "StringBuilder(capacity).…builderAction).toString()");
        return string;
    }
}
