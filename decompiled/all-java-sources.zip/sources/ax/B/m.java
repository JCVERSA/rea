package ax.B;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    private static final Object a = new Object();

    public static final <E> E c(l<E> lVar, int i) {
        E e;
        ax.p335uc.l.f(lVar, "<this>");
        int iA = ax.C.a.a(lVar.X, lVar.Z, i);
        if (iA < 0 || (e = (E) lVar.Y[iA]) == a) {
            return null;
        }
        return e;
    }

    public static final <E> E d(l<E> lVar, int i, E e) {
        E e2;
        ax.p335uc.l.f(lVar, "<this>");
        int iA = ax.C.a.a(lVar.X, lVar.Z, i);
        return (iA < 0 || (e2 = (E) lVar.Y[iA]) == a) ? e : e2;
    }

    public static final <E> void e(l<E> lVar, int i) {
        ax.p335uc.l.f(lVar, "<this>");
        int iA = ax.C.a.a(lVar.X, lVar.Z, i);
        if (iA >= 0) {
            Object[] objArr = lVar.Y;
            Object obj = objArr[iA];
            Object obj2 = a;
            if (obj != obj2) {
                objArr[iA] = obj2;
                lVar.q = true;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final <E> void f(l<E> lVar) {
        int i = lVar.Z;
        int[] iArr = lVar.X;
        Object[] objArr = lVar.Y;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != a) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        lVar.q = false;
        lVar.Z = i2;
    }
}
