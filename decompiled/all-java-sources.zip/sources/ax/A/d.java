package ax.A;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public final class d {
    public static final int[] a = {R.attr.minWidth, R.attr.minHeight, com.alphainventor.filemanager.R.attr.cardBackgroundColor, com.alphainventor.filemanager.R.attr.cardCornerRadius, com.alphainventor.filemanager.R.attr.cardElevation, com.alphainventor.filemanager.R.attr.cardMaxElevation, com.alphainventor.filemanager.R.attr.cardPreventCornerOverlap, com.alphainventor.filemanager.R.attr.cardUseCompatPadding, com.alphainventor.filemanager.R.attr.contentPadding, com.alphainventor.filemanager.R.attr.contentPaddingBottom, com.alphainventor.filemanager.R.attr.contentPaddingLeft, com.alphainventor.filemanager.R.attr.contentPaddingRight, com.alphainventor.filemanager.R.attr.contentPaddingTop};
    public static final int b = 0;
    public static final int c = 1;
    public static final int d = 2;
    public static final int e = 3;
    public static final int f = 4;
    public static final int g = 5;
    public static final int h = 6;
    public static final int i = 7;
    public static final int j = 8;
    public static final int k = 9;
    public static final int l = 10;
    public static final int m = 11;
    public static final int n = 12;
}
