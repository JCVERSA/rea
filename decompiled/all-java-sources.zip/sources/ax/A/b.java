package ax.A;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public static final int a = 2131099735;
    public static final int b = 2131099736;
}
