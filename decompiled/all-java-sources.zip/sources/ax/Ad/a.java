package ax.Ad;

/* JADX INFO: loaded from: classes4.dex */
public interface a {
}
