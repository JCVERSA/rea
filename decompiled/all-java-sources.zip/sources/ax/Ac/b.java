package ax.Ac;

/* JADX INFO: loaded from: classes.dex */
public class b extends e {
    public static void n(int i, int[] iArr, int[] iArr2) {
        int i2 = 16;
        if (iArr.length != 16) {
            throw new IllegalArgumentException();
        }
        if (iArr2.length != 16) {
            throw new IllegalArgumentException();
        }
        if (i % 2 != 0) {
            throw new IllegalArgumentException("Number of rounds must be even");
        }
        char c = 0;
        int i3 = iArr[0];
        int i4 = iArr[1];
        int i5 = iArr[2];
        int i6 = iArr[3];
        int i7 = iArr[4];
        int i8 = iArr[5];
        int i9 = iArr[6];
        int i10 = 7;
        int i11 = iArr[7];
        int i12 = 8;
        int i13 = iArr[8];
        int i14 = iArr[9];
        int i15 = iArr[10];
        int i16 = iArr[11];
        int i17 = 12;
        int i18 = iArr[12];
        int i19 = iArr[13];
        int i20 = iArr[14];
        int iC = iArr[15];
        int iC2 = i20;
        int iC3 = i19;
        int iC4 = i18;
        int i21 = i16;
        int i22 = i15;
        int i23 = i14;
        int i24 = i13;
        int iC5 = i11;
        int iC6 = i9;
        int iC7 = i8;
        int iC8 = i7;
        int i25 = i6;
        int i26 = i5;
        int i27 = i4;
        int i28 = i3;
        int i29 = i;
        while (i29 > 0) {
            int i30 = i28 + iC8;
            int iC9 = ax.Lc.b.c(iC4 ^ i30, i2);
            int i31 = i24 + iC9;
            int iC10 = ax.Lc.b.c(iC8 ^ i31, i17);
            int i32 = i30 + iC10;
            int iC11 = ax.Lc.b.c(iC9 ^ i32, i12);
            int i33 = i31 + iC11;
            int iC12 = ax.Lc.b.c(iC10 ^ i33, i10);
            int i34 = i27 + iC7;
            int iC13 = ax.Lc.b.c(iC3 ^ i34, i2);
            int i35 = i23 + iC13;
            int iC14 = ax.Lc.b.c(iC7 ^ i35, i17);
            int i36 = i34 + iC14;
            int iC15 = ax.Lc.b.c(iC13 ^ i36, i12);
            int i37 = i35 + iC15;
            int iC16 = ax.Lc.b.c(iC14 ^ i37, i10);
            int i38 = i26 + iC6;
            int iC17 = ax.Lc.b.c(iC2 ^ i38, i2);
            int i39 = i22 + iC17;
            int iC18 = ax.Lc.b.c(iC6 ^ i39, i17);
            int i40 = i38 + iC18;
            int iC19 = ax.Lc.b.c(iC17 ^ i40, i12);
            int i41 = i39 + iC19;
            int iC20 = ax.Lc.b.c(iC18 ^ i41, i10);
            int i42 = i25 + iC5;
            int iC21 = ax.Lc.b.c(iC ^ i42, 16);
            int i43 = i21 + iC21;
            int iC22 = ax.Lc.b.c(iC5 ^ i43, i17);
            int i44 = i42 + iC22;
            int iC23 = ax.Lc.b.c(iC21 ^ i44, 8);
            int i45 = i43 + iC23;
            int iC24 = ax.Lc.b.c(iC22 ^ i45, 7);
            int i46 = i32 + iC16;
            int iC25 = ax.Lc.b.c(iC23 ^ i46, 16);
            int i47 = i41 + iC25;
            int iC26 = ax.Lc.b.c(iC16 ^ i47, 12);
            i28 = i46 + iC26;
            iC = ax.Lc.b.c(iC25 ^ i28, 8);
            i22 = i47 + iC;
            iC7 = ax.Lc.b.c(iC26 ^ i22, 7);
            int i48 = i36 + iC20;
            int iC27 = ax.Lc.b.c(iC11 ^ i48, 16);
            int i49 = i45 + iC27;
            int iC28 = ax.Lc.b.c(iC20 ^ i49, 12);
            i27 = i48 + iC28;
            iC4 = ax.Lc.b.c(iC27 ^ i27, 8);
            i21 = i49 + iC4;
            iC6 = ax.Lc.b.c(iC28 ^ i21, 7);
            int i50 = i40 + iC24;
            int iC29 = ax.Lc.b.c(iC15 ^ i50, 16);
            int i51 = i33 + iC29;
            int iC30 = ax.Lc.b.c(iC24 ^ i51, 12);
            i26 = i50 + iC30;
            iC3 = ax.Lc.b.c(iC29 ^ i26, 8);
            i24 = i51 + iC3;
            iC5 = ax.Lc.b.c(iC30 ^ i24, 7);
            int i52 = i44 + iC12;
            i2 = 16;
            int iC31 = ax.Lc.b.c(iC19 ^ i52, 16);
            int i53 = i37 + iC31;
            int iC32 = ax.Lc.b.c(iC12 ^ i53, 12);
            i25 = i52 + iC32;
            iC2 = ax.Lc.b.c(iC31 ^ i25, 8);
            i23 = i53 + iC2;
            iC8 = ax.Lc.b.c(iC32 ^ i23, 7);
            i29 -= 2;
            c = 0;
            i17 = 12;
            i12 = 8;
            i10 = 7;
        }
        iArr2[c] = i28 + iArr[c];
        iArr2[1] = i27 + iArr[1];
        iArr2[2] = i26 + iArr[2];
        iArr2[3] = i25 + iArr[3];
        iArr2[4] = iC8 + iArr[4];
        iArr2[5] = iC7 + iArr[5];
        iArr2[6] = iC6 + iArr[6];
        iArr2[7] = iC5 + iArr[7];
        iArr2[8] = i24 + iArr[8];
        iArr2[9] = i23 + iArr[9];
        iArr2[10] = i22 + iArr[10];
        iArr2[11] = i21 + iArr[11];
        iArr2[12] = iC4 + iArr[12];
        iArr2[13] = iC3 + iArr[13];
        iArr2[14] = iC2 + iArr[14];
        iArr2[15] = iC + iArr[15];
    }

    @Override // ax.Ac.e
    protected void b() {
        int[] iArr = this.c;
        int i = iArr[12] + 1;
        iArr[12] = i;
        if (i == 0) {
            iArr[13] = iArr[13] + 1;
        }
    }

    @Override // ax.Ac.e
    protected void c(byte[] bArr) {
        n(this.a, this.c, this.d);
        ax.Lc.e.g(this.d, bArr, 0);
    }

    @Override // ax.Ac.e
    public String d() {
        return "ChaCha" + this.a;
    }

    @Override // ax.Ac.e
    protected void j() {
        int[] iArr = this.c;
        iArr[13] = 0;
        iArr[12] = 0;
    }

    @Override // ax.Ac.e
    protected void m(byte[] bArr, byte[] bArr2) {
        if (bArr != null) {
            if (bArr.length != 16 && bArr.length != 32) {
                throw new IllegalArgumentException(d() + " requires 128 bit or 256 bit key");
            }
            i(bArr.length, this.c, 0);
            ax.Lc.e.j(bArr, 0, this.c, 4, 4);
            ax.Lc.e.j(bArr, bArr.length - 16, this.c, 8, 4);
        }
        ax.Lc.e.j(bArr2, 0, this.c, 14, 2);
    }
}
