package ax.Ac;

/* JADX INFO: loaded from: classes4.dex */
public interface b<T> extends c {
    String a();
}
