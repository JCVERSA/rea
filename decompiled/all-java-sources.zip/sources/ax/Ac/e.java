package ax.Ac;

import ax.Gc.k;
import ax.Gc.l;
import ax.Lc.f;
import ax.p349yc.m;
import ax.p349yc.n;
import ax.p349yc.t;

/* JADX INFO: loaded from: classes.dex */
public class e implements t {
    private static final int[] j = ax.Lc.e.k(f.a("expand 16-byte kexpand 32-byte k"), 0, 8);
    protected static final byte[] k = f.a("expand 32-byte k");
    protected static final byte[] l = f.a("expand 16-byte k");
    protected int a;
    private int b;
    protected int[] c;
    protected int[] d;
    private byte[] e;
    private boolean f;
    private int g;
    private int h;
    private int i;

    public e() {
        this(20);
    }

    private boolean h(int i) {
        int i2 = this.g + i;
        this.g = i2;
        if (i2 >= i || i2 < 0) {
            return false;
        }
        int i3 = this.h + 1;
        this.h = i3;
        if (i3 != 0) {
            return false;
        }
        int i4 = this.i + 1;
        this.i = i4;
        return (i4 & 32) != 0;
    }

    private void k() {
        this.g = 0;
        this.h = 0;
        this.i = 0;
    }

    public static void l(int i, int[] iArr, int[] iArr2) {
        if (iArr.length != 16) {
            throw new IllegalArgumentException();
        }
        if (iArr2.length != 16) {
            throw new IllegalArgumentException();
        }
        if (i % 2 != 0) {
            throw new IllegalArgumentException("Number of rounds must be even");
        }
        int i2 = iArr[0];
        int i3 = iArr[1];
        int i4 = iArr[2];
        int i5 = iArr[3];
        int i6 = iArr[4];
        int i7 = iArr[5];
        int i8 = iArr[6];
        int i9 = 7;
        int i10 = iArr[7];
        int i11 = iArr[8];
        int i12 = 9;
        int i13 = iArr[9];
        int i14 = iArr[10];
        int i15 = iArr[11];
        int i16 = iArr[12];
        int i17 = 13;
        int i18 = iArr[13];
        int i19 = iArr[14];
        int iC = iArr[15];
        int iC2 = i19;
        int iC3 = i18;
        int iC4 = i16;
        int iC5 = i15;
        int iC6 = i14;
        int iC7 = i13;
        int i20 = i11;
        int iC8 = i10;
        int iC9 = i8;
        int iC10 = i7;
        int i21 = i6;
        int i22 = i5;
        int iC11 = i4;
        int iC12 = i3;
        int i23 = i2;
        int i24 = i;
        while (i24 > 0) {
            int iC13 = ax.Lc.b.c(i23 + iC4, i9) ^ i21;
            int iC14 = i20 ^ ax.Lc.b.c(iC13 + i23, i12);
            int iC15 = iC4 ^ ax.Lc.b.c(iC14 + iC13, i17);
            int iC16 = ax.Lc.b.c(iC15 + iC14, 18) ^ i23;
            int iC17 = iC7 ^ ax.Lc.b.c(iC10 + iC12, i9);
            int iC18 = iC3 ^ ax.Lc.b.c(iC17 + iC10, i12);
            int iC19 = iC12 ^ ax.Lc.b.c(iC18 + iC17, i17);
            int iC20 = ax.Lc.b.c(iC19 + iC18, 18) ^ iC10;
            int iC21 = iC2 ^ ax.Lc.b.c(iC6 + iC9, 7);
            int iC22 = iC11 ^ ax.Lc.b.c(iC21 + iC6, 9);
            int iC23 = iC9 ^ ax.Lc.b.c(iC22 + iC21, 13);
            int iC24 = iC6 ^ ax.Lc.b.c(iC23 + iC22, 18);
            int iC25 = i22 ^ ax.Lc.b.c(iC + iC5, 7);
            int iC26 = iC8 ^ ax.Lc.b.c(iC25 + iC, 9);
            int i25 = i24;
            int iC27 = iC5 ^ ax.Lc.b.c(iC26 + iC25, 13);
            int iC28 = iC ^ ax.Lc.b.c(iC27 + iC26, 18);
            iC12 = iC19 ^ ax.Lc.b.c(iC16 + iC25, 7);
            iC11 = iC22 ^ ax.Lc.b.c(iC12 + iC16, 9);
            int iC29 = iC25 ^ ax.Lc.b.c(iC11 + iC12, 13);
            int iC30 = iC16 ^ ax.Lc.b.c(iC29 + iC11, 18);
            iC9 = iC23 ^ ax.Lc.b.c(iC20 + iC13, 7);
            iC8 = iC26 ^ ax.Lc.b.c(iC9 + iC20, 9);
            int iC31 = ax.Lc.b.c(iC8 + iC9, 13) ^ iC13;
            iC10 = iC20 ^ ax.Lc.b.c(iC31 + iC8, 18);
            iC5 = iC27 ^ ax.Lc.b.c(iC24 + iC17, 7);
            int iC32 = ax.Lc.b.c(iC5 + iC24, 9) ^ iC14;
            iC7 = iC17 ^ ax.Lc.b.c(iC32 + iC5, 13);
            iC6 = iC24 ^ ax.Lc.b.c(iC7 + iC32, 18);
            iC4 = iC15 ^ ax.Lc.b.c(iC28 + iC21, 7);
            iC3 = iC18 ^ ax.Lc.b.c(iC4 + iC28, 9);
            iC2 = iC21 ^ ax.Lc.b.c(iC3 + iC4, 13);
            iC = iC28 ^ ax.Lc.b.c(iC2 + iC3, 18);
            i22 = iC29;
            i20 = iC32;
            i23 = iC30;
            i21 = iC31;
            i17 = 13;
            i12 = 9;
            i9 = 7;
            i24 = i25 - 2;
        }
        iArr2[0] = i23 + iArr[0];
        iArr2[1] = iC12 + iArr[1];
        iArr2[2] = iC11 + iArr[2];
        iArr2[3] = i22 + iArr[3];
        iArr2[4] = i21 + iArr[4];
        iArr2[5] = iC10 + iArr[5];
        iArr2[6] = iC9 + iArr[6];
        iArr2[7] = iC8 + iArr[7];
        iArr2[8] = i20 + iArr[8];
        iArr2[9] = iC7 + iArr[9];
        iArr2[10] = iC6 + iArr[10];
        iArr2[11] = iC5 + iArr[11];
        iArr2[12] = iC4 + iArr[12];
        iArr2[13] = iC3 + iArr[13];
        iArr2[14] = iC2 + iArr[14];
        iArr2[15] = iC + iArr[15];
    }

    @Override // ax.p349yc.t
    public void a() {
        this.b = 0;
        k();
        j();
        c(this.e);
    }

    protected void b() {
        throw null;
    }

    protected void c(byte[] bArr) {
        throw null;
    }

    public String d() {
        throw null;
    }

    @Override // ax.p349yc.t
    public void e(boolean z, ax.p349yc.d dVar) {
        if (!(dVar instanceof l)) {
            throw new IllegalArgumentException(d() + " Init parameters must include an IV");
        }
        l lVar = (l) dVar;
        byte[] bArrA = lVar.a();
        if (bArrA == null || bArrA.length != f()) {
            throw new IllegalArgumentException(d() + " requires exactly " + f() + " bytes of IV");
        }
        ax.p349yc.d dVarB = lVar.b();
        if (dVarB == null) {
            if (!this.f) {
                throw new IllegalStateException(d() + " KeyParameter can not be null for first initialisation");
            }
            m(null, bArrA);
        } else {
            if (!(dVarB instanceof k)) {
                throw new IllegalArgumentException(d() + " Init parameters must contain a KeyParameter (or null for re-init)");
            }
            m(((k) dVarB).a(), bArrA);
        }
        a();
        this.f = true;
    }

    protected int f() {
        return 8;
    }

    @Override // ax.p349yc.t
    public int g(byte[] bArr, int i, int i2, byte[] bArr2, int i3) {
        if (!this.f) {
            throw new IllegalStateException(d() + " not initialised");
        }
        if (i + i2 > bArr.length) {
            throw new ax.p349yc.f("input buffer too short");
        }
        if (i3 + i2 > bArr2.length) {
            throw new n("output buffer too short");
        }
        if (h(i2)) {
            throw new m("2^70 byte limit per IV would be exceeded; Change IV");
        }
        for (int i4 = 0; i4 < i2; i4++) {
            byte[] bArr3 = this.e;
            int i5 = this.b;
            bArr2[i4 + i3] = (byte) (bArr3[i5] ^ bArr[i4 + i]);
            int i6 = (i5 + 1) & 63;
            this.b = i6;
            if (i6 == 0) {
                b();
                c(this.e);
            }
        }
        return i2;
    }

    protected void i(int i, int[] iArr, int i2) {
        int i3 = (i - 16) / 4;
        int[] iArr2 = j;
        iArr[i2] = iArr2[i3];
        iArr[i2 + 1] = iArr2[i3 + 1];
        iArr[i2 + 2] = iArr2[i3 + 2];
        iArr[i2 + 3] = iArr2[i3 + 3];
    }

    protected void j() {
        throw null;
    }

    protected void m(byte[] bArr, byte[] bArr2) {
        throw null;
    }

    public e(int i) {
        this.b = 0;
        this.c = new int[16];
        this.d = new int[16];
        this.e = new byte[64];
        this.f = false;
        if (i <= 0 || (i & 1) != 0) {
            throw new IllegalArgumentException("'rounds' must be a positive, even number");
        }
        this.a = i;
    }
}
