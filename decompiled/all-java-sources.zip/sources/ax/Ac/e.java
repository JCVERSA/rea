package ax.Ac;

/* JADX INFO: loaded from: classes4.dex */
public interface e<V> extends g<V>, ax.p319tc.a<V> {
    V get();
}
