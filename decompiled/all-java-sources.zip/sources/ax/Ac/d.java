package ax.Ac;

/* JADX INFO: loaded from: classes4.dex */
public interface d<R> extends a<R>, ax.p111gc.c<R> {
}
