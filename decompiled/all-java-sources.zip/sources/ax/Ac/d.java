package ax.Ac;

import ax.Gc.k;
import ax.p349yc.f;
import ax.p349yc.n;
import ax.p349yc.t;

/* JADX INFO: loaded from: classes.dex */
public class d implements t {
    private byte[] a = null;
    private int b = 0;
    private int c = 0;
    private byte[] d = null;

    private void b(byte[] bArr) {
        this.d = bArr;
        this.b = 0;
        this.c = 0;
        if (this.a == null) {
            this.a = new byte[256];
        }
        for (int i = 0; i < 256; i++) {
            this.a[i] = (byte) i;
        }
        int length = 0;
        int i2 = 0;
        for (int i3 = 0; i3 < 256; i3++) {
            int i4 = bArr[length] & 255;
            byte[] bArr2 = this.a;
            byte b = bArr2[i3];
            i2 = (i4 + b + i2) & 255;
            bArr2[i3] = bArr2[i2];
            bArr2[i2] = b;
            length = (length + 1) % bArr.length;
        }
    }

    @Override // ax.p349yc.t
    public void a() {
        b(this.d);
    }

    @Override // ax.p349yc.t
    public void e(boolean z, ax.p349yc.d dVar) {
        if (dVar instanceof k) {
            byte[] bArrA = ((k) dVar).a();
            this.d = bArrA;
            b(bArrA);
        } else {
            throw new IllegalArgumentException("invalid parameter passed to RC4 init - " + dVar.getClass().getName());
        }
    }

    @Override // ax.p349yc.t
    public int g(byte[] bArr, int i, int i2, byte[] bArr2, int i3) {
        if (i + i2 > bArr.length) {
            throw new f("input buffer too short");
        }
        if (i3 + i2 > bArr2.length) {
            throw new n("output buffer too short");
        }
        for (int i4 = 0; i4 < i2; i4++) {
            int i5 = (this.b + 1) & 255;
            this.b = i5;
            byte[] bArr3 = this.a;
            byte b = bArr3[i5];
            int i6 = (this.c + b) & 255;
            this.c = i6;
            bArr3[i5] = bArr3[i6];
            bArr3[i6] = b;
            bArr2[i4 + i3] = (byte) (bArr3[(bArr3[i5] + b) & 255] ^ bArr[i4 + i]);
        }
        return i2;
    }
}
