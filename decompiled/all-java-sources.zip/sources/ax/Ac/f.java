package ax.Ac;

import ax.p319tc.p;

/* JADX INFO: loaded from: classes4.dex */
public interface f<D, E, V> extends g<V>, p<D, E, V> {

    public interface a<D, E, V> extends d, p<D, E, V> {
    }

    a<D, E, V> f();

    V n(D d, E e);
}
