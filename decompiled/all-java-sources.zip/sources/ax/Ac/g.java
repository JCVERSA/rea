package ax.Ac;

/* JADX INFO: loaded from: classes4.dex */
public interface g<V> extends a<V> {
}
