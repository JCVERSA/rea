package ax.Ae;

import ax.Be.d;
import ax.Kd.C1283q;
import ax.Kd.C1292v;
import ax.Kd.D;
import ax.p417ze.c;
import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.spec.PSSParameterSpec;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
class b {
    private static final Map b;
    private static final Map c;
    private static final Map d;
    private static final Map e;
    private static final Map f;
    private static c g;
    private ax.p353ve.b a;

    static {
        HashMap map = new HashMap();
        b = map;
        HashMap map2 = new HashMap();
        c = map2;
        HashMap map3 = new HashMap();
        d = map3;
        HashMap map4 = new HashMap();
        e = map4;
        HashMap map5 = new HashMap();
        f = map5;
        g = new c();
        map.put(ax.Zd.a.i, "SHA1");
        map.put(ax.Xd.a.f, "SHA224");
        map.put(ax.Xd.a.c, "SHA256");
        map.put(ax.Xd.a.d, "SHA384");
        map.put(ax.Xd.a.e, "SHA512");
        map.put(ax.p049ce.a.c, "RIPEMD128");
        map.put(ax.p049ce.a.b, "RIPEMD160");
        map.put(ax.p049ce.a.d, "RIPEMD256");
        map2.put(ax.p017ae.a.b, "RSA/ECB/PKCS1Padding");
        map2.put(ax.Od.a.m, "ECGOST3410");
        C1292v c1292v = ax.p017ae.a.S1;
        map3.put(c1292v, "DESEDEWrap");
        map3.put(ax.p017ae.a.T1, "RC2Wrap");
        C1292v c1292v2 = ax.Xd.a.B;
        map3.put(c1292v2, "AESWrap");
        C1292v c1292v3 = ax.Xd.a.J;
        map3.put(c1292v3, "AESWrap");
        C1292v c1292v4 = ax.Xd.a.R;
        map3.put(c1292v4, "AESWrap");
        C1292v c1292v5 = ax.Yd.a.d;
        map3.put(c1292v5, "CamelliaWrap");
        C1292v c1292v6 = ax.Yd.a.e;
        map3.put(c1292v6, "CamelliaWrap");
        C1292v c1292v7 = ax.Yd.a.f;
        map3.put(c1292v7, "CamelliaWrap");
        C1292v c1292v8 = ax.Vd.a.d;
        map3.put(c1292v8, "SEEDWrap");
        C1292v c1292v9 = ax.p017ae.a.D;
        map3.put(c1292v9, "DESede");
        map5.put(c1292v, d.d(192));
        map5.put(c1292v2, d.d(128));
        map5.put(c1292v3, d.d(192));
        map5.put(c1292v4, d.d(256));
        map5.put(c1292v5, d.d(128));
        map5.put(c1292v6, d.d(192));
        map5.put(c1292v7, d.d(256));
        map5.put(c1292v8, d.d(128));
        map5.put(c1292v9, d.d(192));
        map4.put(ax.Xd.a.w, "AES");
        map4.put(ax.Xd.a.y, "AES");
        map4.put(ax.Xd.a.G, "AES");
        map4.put(ax.Xd.a.O, "AES");
        map4.put(c1292v9, "DESede");
        map4.put(ax.p017ae.a.E, "RC2");
    }

    b(ax.p353ve.b bVar) {
        this.a = bVar;
    }

    private static String c(ax.p097fe.a aVar) {
        return g.a(aVar);
    }

    private boolean d(D d2) throws GeneralSecurityException {
        if (d2 != null && d2.size() != 0) {
            ax.p017ae.c cVarS = ax.p017ae.c.s(d2);
            if (!cVarS.t().q().x(ax.p017ae.a.i) || !cVarS.q().equals(ax.p097fe.a.t(cVarS.t().u()))) {
                return true;
            }
            if (cVarS.u().intValue() != a(cVarS.q()).getDigestLength()) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.security.MessageDigest] */
    MessageDigest a(ax.p097fe.a aVar) throws GeneralSecurityException {
        ax.p353ve.b bVar;
        String strA;
        try {
            if (aVar.q().x(ax.Xd.a.t)) {
                bVar = this.a;
                strA = "SHAKE256-" + C1283q.H(aVar.u()).J();
            } else if (aVar.q().x(ax.Xd.a.s)) {
                bVar = this.a;
                strA = "SHAKE128-" + C1283q.H(aVar.u()).J();
            } else {
                bVar = this.a;
                strA = ax.p353ve.c.a(aVar.q());
            }
            aVar = bVar.a(strA);
            return aVar;
        } catch (NoSuchAlgorithmException e2) {
            Map map = b;
            if (map.get(aVar.q()) == null) {
                throw e2;
            }
            return this.a.a((String) map.get(aVar.q()));
        }
    }

    Signature b(ax.p097fe.a aVar) throws GeneralSecurityException {
        Signature signatureC;
        String strC = c(aVar);
        try {
            signatureC = this.a.c(strC);
        } catch (NoSuchAlgorithmException e2) {
            if (!strC.endsWith("WITHRSAANDMGF1")) {
                throw e2;
            }
            signatureC = this.a.c(strC.substring(0, strC.indexOf(87)) + "WITHRSASSA-PSS");
        }
        if (aVar.q().x(ax.p017ae.a.k)) {
            D dJ = D.J(aVar.u());
            if (d(dJ)) {
                try {
                    AlgorithmParameters algorithmParametersB = this.a.b("PSS");
                    algorithmParametersB.init(dJ.o());
                    signatureC.setParameter(algorithmParametersB.getParameterSpec(PSSParameterSpec.class));
                } catch (IOException e3) {
                    throw new GeneralSecurityException("unable to process PSS parameters: " + e3.getMessage());
                }
            }
        }
        return signatureC;
    }
}
