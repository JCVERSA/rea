package ax.Ae;

import ax.Kd.C1265h;
import ax.Kd.C1272k0;
import ax.Kd.C1297x0;
import ax.Kd.D;
import ax.p417ze.d;
import ax.p417ze.f;
import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public class a {
    private SecureRandom b;
    private String c;
    private ax.p097fe.a d;
    private ax.Ae.b a = new ax.Ae.b(new ax.p353ve.a());
    private AlgorithmParameterSpec e = null;

    /* JADX INFO: renamed from: ax.Ae.a$a, reason: collision with other inner class name */
    class C0055a implements ax.p417ze.a {
        private OutputStream a;
        final /* synthetic */ Signature b;
        final /* synthetic */ ax.p097fe.a c;

        C0055a(Signature signature, ax.p097fe.a aVar) {
            this.b = signature;
            this.c = aVar;
            this.a = ax.p337ue.a.a(signature);
        }

        @Override // ax.p417ze.a
        public byte[] a() {
            try {
                return this.b.sign();
            } catch (SignatureException e) {
                throw new f("exception obtaining signature: " + e.getMessage(), e);
            }
        }

        @Override // ax.p417ze.a
        public OutputStream b() {
            return this.a;
        }

        @Override // ax.p417ze.a
        public ax.p097fe.a c() {
            return this.c;
        }
    }

    class b implements ax.p417ze.a {
        OutputStream a;
        final /* synthetic */ OutputStream b;
        final /* synthetic */ Signature[] c;

        b(OutputStream outputStream, Signature[] signatureArr) {
            this.b = outputStream;
            this.c = signatureArr;
            this.a = outputStream;
        }

        @Override // ax.p417ze.a
        public byte[] a() {
            try {
                C1265h c1265h = new C1265h();
                for (int i = 0; i != this.c.length; i++) {
                    c1265h.a(new C1272k0(this.c[i].sign()));
                }
                return new C1297x0(c1265h).p("DER");
            } catch (IOException e) {
                throw new f("exception encoding signature: " + e.getMessage(), e);
            } catch (SignatureException e2) {
                throw new f("exception obtaining signature: " + e2.getMessage(), e2);
            }
        }

        @Override // ax.p417ze.a
        public OutputStream b() {
            return this.a;
        }

        @Override // ax.p417ze.a
        public ax.p097fe.a c() {
            return a.this.d;
        }
    }

    public a(String str) {
        this.c = str;
        this.d = new ax.p417ze.b().b(str);
    }

    private ax.p417ze.a c(ax.p321te.a aVar) throws d {
        try {
            List<PrivateKey> listA = aVar.a();
            D dJ = D.J(this.d.u());
            int size = dJ.size();
            Signature[] signatureArr = new Signature[size];
            for (int i = 0; i != dJ.size(); i++) {
                Signature signatureB = this.a.b(ax.p097fe.a.t(dJ.K(i)));
                signatureArr[i] = signatureB;
                if (this.b != null) {
                    signatureB.initSign(listA.get(i), this.b);
                } else {
                    signatureB.initSign(listA.get(i));
                }
            }
            OutputStream outputStreamA = ax.p337ue.a.a(signatureArr[0]);
            int i2 = 1;
            while (i2 != size) {
                ax.De.b bVar = new ax.De.b(outputStreamA, ax.p337ue.a.a(signatureArr[i2]));
                i2++;
                outputStreamA = bVar;
            }
            return new b(outputStreamA, signatureArr);
        } catch (GeneralSecurityException e) {
            throw new d("cannot create signer: " + e.getMessage(), e);
        }
    }

    public ax.p417ze.a b(PrivateKey privateKey) throws d {
        if (privateKey instanceof ax.p321te.a) {
            return c((ax.p321te.a) privateKey);
        }
        try {
            Signature signatureB = this.a.b(this.d);
            ax.p097fe.a aVar = this.d;
            SecureRandom secureRandom = this.b;
            if (secureRandom != null) {
                signatureB.initSign(privateKey, secureRandom);
            } else {
                signatureB.initSign(privateKey);
            }
            return new C0055a(signatureB, aVar);
        } catch (GeneralSecurityException e) {
            throw new d("cannot create signer: " + e.getMessage(), e);
        }
    }
}
