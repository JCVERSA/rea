package ax.B3;

/* JADX INFO: loaded from: classes.dex */
public class a extends Exception {
    public a(Throwable th) {
        super(th);
    }
}
