package ax.B3;

import android.app.Activity;
import android.content.Context;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import androidx.fragment.app.f;

/* JADX INFO: loaded from: classes.dex */
public class c {

    public enum a {
        NONE,
        PLAYING,
        PAUSED
    }

    public static String a(String str, String... strArr) {
        StringBuilder sb = new StringBuilder();
        if (strArr != null) {
            for (int i = 0; i < strArr.length; i++) {
                if (!g(strArr[i])) {
                    throw new IllegalArgumentException("Invalid category: " + strArr[0]);
                }
                sb.append(strArr[i]);
                if (i < strArr.length - 1) {
                    sb.append('/');
                }
            }
        }
        if (str != null) {
            sb.append('|');
            sb.append(str);
        }
        return sb.toString();
    }

    public static String b(String str) {
        int iIndexOf = str.indexOf(124);
        if (iIndexOf >= 0) {
            return str.substring(iIndexOf + 1);
        }
        return null;
    }

    public static String[] c(String str) {
        int iIndexOf = str.indexOf(124);
        if (iIndexOf >= 0) {
            str = str.substring(0, iIndexOf);
        }
        return str.split(String.valueOf('/'));
    }

    public static a d(Context context, String str) {
        return f(context, str) ? e(context) : a.NONE;
    }

    public static a e(Context context) {
        PlaybackStateCompat playbackStateCompatE = MediaControllerCompat.c((Activity) context).e();
        if (playbackStateCompatE == null) {
            return a.NONE;
        }
        if (playbackStateCompatE.h() == 3) {
            return a.PLAYING;
        }
        return playbackStateCompatE.h() == 2 ? a.PAUSED : a.NONE;
    }

    public static boolean f(Context context, String str) {
        MediaMetadataCompat mediaMetadataCompatD;
        MediaControllerCompat mediaControllerCompatC = MediaControllerCompat.c((f) context);
        if (mediaControllerCompatC != null && (mediaMetadataCompatD = mediaControllerCompatC.d()) != null) {
            try {
                String strF = mediaMetadataCompatD.e().f();
                if (strF != null && TextUtils.equals(strF, str)) {
                    return true;
                }
            } catch (RuntimeException e) {
                ax.p221pa.c.e(context).a().g().b("MusicPlayer MetaData getError").m(e).i();
            }
        }
        return false;
    }

    private static boolean g(String str) {
        return str == null || (str.indexOf(47) < 0 && str.indexOf(124) < 0);
    }
}
