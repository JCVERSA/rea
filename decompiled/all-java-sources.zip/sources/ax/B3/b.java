package ax.B3;

import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class b {
    private static final int a = 5;

    public static void b(String str, Throwable th, Object... objArr) {
        e(str, 6, th, objArr);
    }

    public static void c(String str, Object... objArr) {
        e(str, 6, null, objArr);
    }

    public static void d(String str, Object... objArr) {
        e(str, 4, null, objArr);
    }

    public static void e(String str, int i, Throwable th, Object... objArr) {
        String string;
        if (Log.isLoggable(str, i)) {
            if (th == null && objArr != null && objArr.length == 1) {
                string = objArr[0].toString();
            } else {
                StringBuilder sb = new StringBuilder();
                if (objArr != null) {
                    for (Object obj : objArr) {
                        sb.append(obj);
                    }
                }
                if (th != null) {
                    sb.append("\n");
                    sb.append(Log.getStackTraceString(th));
                }
                string = sb.toString();
            }
            Log.println(i, str, string);
        }
    }

    public static String f(Class cls) {
        return g(cls.getSimpleName());
    }

    public static String g(String str) {
        int length = str.length();
        int i = a;
        if (length > 23 - i) {
            return "uamp_" + str.substring(0, 22 - i);
        }
        return "uamp_" + str;
    }

    public static void i(String str, Throwable th, Object... objArr) {
        e(str, 5, th, objArr);
    }

    public static void j(String str, Object... objArr) {
        e(str, 5, null, objArr);
    }

    public static void a(String str, Object... objArr) {
    }

    public static void h(String str, Object... objArr) {
    }
}
