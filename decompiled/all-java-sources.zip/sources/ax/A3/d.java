package ax.A3;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import ax.p340y3.k;
import com.example.android.uamp.MusicService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class d {
    private static final String m = ax.B3.b.f(d.class);
    private ax.p354z3.b a;
    private b b;
    private Resources c;
    private List<MediaSessionCompat.QueueItem> f;
    private int h;
    private Context i;
    private int k;
    private String l;
    private int j = -1;
    private List<MediaSessionCompat.QueueItem> d = Collections.synchronizedList(new ArrayList());
    private List<MediaSessionCompat.QueueItem> e = Collections.synchronizedList(new ArrayList());
    private int g = 0;

    class a extends ax.p340y3.a.AbstractC0481a {
        final /* synthetic */ String a;

        a(String str) {
            this.a = str;
        }

        @Override // ax.p340y3.a.AbstractC0481a
        public void b(String str, Bitmap bitmap, Bitmap bitmap2, Bitmap bitmap3) {
            if (!d.this.j(bitmap2)) {
                bitmap2 = null;
            }
            if (!d.this.j(bitmap3)) {
                bitmap3 = null;
            }
            if (bitmap2 == null && bitmap3 == null) {
                return;
            }
            d.this.a.s(this.a, bitmap2, bitmap3);
            MediaSessionCompat.QueueItem queueItemH = d.this.h();
            if (queueItemH == null) {
                return;
            }
            if (this.a.equals(ax.B3.c.b(queueItemH.c().f()))) {
                try {
                    d.this.b.G0(d.this.a.e(this.a));
                } catch (IllegalArgumentException unused) {
                    d.this.a.b(this.a);
                }
            }
        }
    }

    public interface b {
        void G0(MediaMetadataCompat mediaMetadataCompat);

        void a();

        void b(int i);

        void c(String str, List<MediaSessionCompat.QueueItem> list);
    }

    private class c extends AsyncTask<Void, Integer, MediaMetadataCompat> {
        String a;

        c(String str) {
            this.a = str;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public MediaMetadataCompat doInBackground(Void... voidArr) {
            return d.this.a.t(d.this.i, this.a);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(MediaMetadataCompat mediaMetadataCompat) {
            MediaSessionCompat.QueueItem queueItemH;
            String strF;
            String strB;
            if (mediaMetadataCompat == null || (queueItemH = d.this.h()) == null || (strF = queueItemH.c().f()) == null || (strB = ax.B3.c.b(strF)) == null || !strB.equals(this.a)) {
                return;
            }
            d.this.b.G0(mediaMetadataCompat);
        }
    }

    public d(Context context, ax.p354z3.b bVar, Resources resources, b bVar2) {
        this.i = context;
        this.a = bVar;
        this.b = bVar2;
        this.c = resources;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean j(Bitmap bitmap) {
        return bitmap != null && bitmap.getHeight() > 0 && bitmap.getWidth() > 0;
    }

    private void o(int i) {
        if (i < 0 || i >= this.d.size()) {
            return;
        }
        this.g = i;
        this.b.b(i);
    }

    private void w(String str) {
        int iC;
        if (this.k == 1) {
            this.d = this.e;
        } else {
            this.d = this.f;
        }
        List<MediaSessionCompat.QueueItem> list = this.d;
        if (list != null) {
            this.j = list.size();
        } else {
            this.j = -100;
        }
        if (str != null) {
            iC = ax.B3.d.c(this.d, str);
            this.h = iC;
        } else {
            iC = 0;
        }
        this.g = Math.max(iC, 0);
        this.b.c(this.l, this.d);
    }

    public int e() {
        if (i() == 0) {
            return 0;
        }
        int size = this.g;
        int i = this.h;
        if (size < i) {
            size = this.d.size() + this.g;
            i = this.h;
        }
        return (size - i) + 1;
    }

    public int f() {
        return this.g;
    }

    public String g() {
        MediaSessionCompat.QueueItem queueItemH = h();
        if (queueItemH == null) {
            return null;
        }
        return queueItemH.c().f();
    }

    public MediaSessionCompat.QueueItem h() {
        if (ax.B3.d.e(this.g, this.d)) {
            return this.d.get(this.g);
        }
        return null;
    }

    public int i() {
        List<MediaSessionCompat.QueueItem> list = this.d;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public boolean k() {
        List<MediaSessionCompat.QueueItem> list = this.d;
        return list == null || list.size() == 0;
    }

    public boolean l(String str) {
        String[] strArrC = ax.B3.c.c(str);
        MediaSessionCompat.QueueItem queueItemH = h();
        if (queueItemH == null) {
            return false;
        }
        return Arrays.equals(strArrC, ax.B3.c.c(queueItemH.c().f()));
    }

    public void m() {
        MusicService.H(this.i);
    }

    protected void n(String str, List<MediaSessionCompat.QueueItem> list, String str2) {
        this.f = list;
        ArrayList arrayList = new ArrayList(list);
        this.e = arrayList;
        Collections.shuffle(arrayList);
        this.l = str;
        w(str2);
    }

    public boolean p(long j) {
        int iB = ax.B3.d.b(this.d, j);
        o(iB);
        return iB >= 0;
    }

    public boolean q(String str) {
        int iC = ax.B3.d.c(this.d, str);
        o(iC);
        return iC >= 0;
    }

    public void r(String str) {
        n("musics", ax.B3.d.a(this.a.f(), new String[0]), str);
        v();
    }

    public void s(String str) {
        ax.B3.b.a(m, "setQueueFromMusic", str);
        if (!(l(str) ? q(str) : false)) {
            n("musics", ax.B3.d.d(str, this.a), str);
        }
        v();
    }

    public void t(int i) {
        this.k = i;
        w(g());
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0049 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:11:0x004b  */
    /* JADX WARN: Code duplicated, block: B:12:0x0054  */
    public boolean u(int i) {
        int size;
        int i2 = this.g + i;
        if (i() == 0) {
            ax.p221pa.c.i(this.i).o("MUSICPLAYER-QUEUESIZE0").k().h("mCurrentIndex=" + this.g + ",queueset=" + this.j).i();
            return false;
        }
        if (i < 0) {
            int i3 = this.h;
            size = this.g;
            if (i3 != size) {
                if (i2 < 0) {
                    size = this.d.size() - 1;
                } else {
                    size = i2 % this.d.size();
                }
            }
        } else if (i2 < 0) {
            size = this.d.size() - 1;
        } else {
            size = i2 % this.d.size();
        }
        if (!ax.B3.d.e(size, this.d)) {
            ax.B3.b.c(m, "Cannot increment queue index by ", Integer.valueOf(i), ". Current=", Integer.valueOf(this.g), " queue length=", Integer.valueOf(this.d.size()));
            return false;
        }
        this.g = size;
        MusicService.J(this.i, this.a.d(), this.d.get(this.g).c().f(), 0);
        return true;
    }

    public void v() {
        MediaSessionCompat.QueueItem queueItemH = h();
        if (queueItemH == null) {
            this.b.a();
            return;
        }
        String strB = ax.B3.c.b(queueItemH.c().f());
        MediaMetadataCompat mediaMetadataCompatE = this.a.e(strB);
        if (mediaMetadataCompatE == null) {
            throw new IllegalArgumentException("Invalid musicId " + strB);
        }
        if (!this.a.n(strB)) {
            new c(strB).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
        this.b.G0(mediaMetadataCompatE);
        MediaDescriptionCompat mediaDescriptionCompatB = k.b(mediaMetadataCompatE);
        if (mediaDescriptionCompatB.c() != null || mediaDescriptionCompatB.d() == null) {
            return;
        }
        ax.p340y3.a.i().f(this.i.getApplicationContext(), mediaDescriptionCompatB.d().toString(), new a(strB));
    }
}
