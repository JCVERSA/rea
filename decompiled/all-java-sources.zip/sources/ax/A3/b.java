package ax.A3;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import ax.P8.l;
import ax.Q6.AbstractC1477j;
import ax.Q6.InterfaceC1472e;
import ax.U2.g;
import ax.p075e8.f;
import ax.p302sb.c;
import ax.p406z3.B;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public class b {
    private static final Logger d = g.a(b.class);
    private com.google.firebase.remoteconfig.a a;
    HashMap<String, Object> b;
    private boolean c;

    class a implements InterfaceC1472e<Boolean> {

        /* JADX INFO: renamed from: ax.A3.b$a$a, reason: collision with other inner class name */
        class RunnableC0052a implements Runnable {
            RunnableC0052a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (B.D("GoogleApiHandler")) {
                    b.d.fine("ThreadGuard : GoogleApiHandler Delay");
                }
            }
        }

        a() {
        }

        @Override // ax.Q6.InterfaceC1472e
        public void a(AbstractC1477j<Boolean> abstractC1477j) {
            if (abstractC1477j.n()) {
                b.d.fine("Dynamic config fetch succeeded");
            } else {
                b.d.fine("Dynamic config fetch failed");
            }
            new Handler(Looper.getMainLooper()).postDelayed(new RunnableC0052a(), 2000L);
        }
    }

    public boolean b(String str) {
        com.google.firebase.remoteconfig.a aVar;
        if (!this.c || (aVar = this.a) == null) {
            return ((Boolean) this.b.get(str)).booleanValue();
        }
        l lVarK = aVar.k(str);
        if (lVarK.a() == 0 || lVarK.a() == 1) {
            return ((Boolean) this.b.get(str)).booleanValue();
        }
        try {
            return lVarK.d();
        } catch (IllegalArgumentException unused) {
            return ((Boolean) this.b.get(str)).booleanValue();
        }
    }

    public int c(String str) {
        com.google.firebase.remoteconfig.a aVar;
        if (!this.c || (aVar = this.a) == null) {
            return ((Long) this.b.get(str)).intValue();
        }
        l lVarK = aVar.k(str);
        if (lVarK.a() == 0 || lVarK.a() == 1) {
            return ((Long) this.b.get(str)).intValue();
        }
        try {
            return (int) lVarK.b();
        } catch (IllegalArgumentException unused) {
            return ((Long) this.b.get(str)).intValue();
        }
    }

    public long d(String str) {
        com.google.firebase.remoteconfig.a aVar;
        if (!this.c || (aVar = this.a) == null) {
            return ((Long) this.b.get(str)).longValue();
        }
        l lVarK = aVar.k(str);
        if (lVarK.a() == 0 || lVarK.a() == 1) {
            return ((Long) this.b.get(str)).longValue();
        }
        try {
            return lVarK.b();
        } catch (IllegalArgumentException unused) {
            return ((Long) this.b.get(str)).longValue();
        }
    }

    public String e(String str) {
        com.google.firebase.remoteconfig.a aVar;
        if (!this.c || (aVar = this.a) == null) {
            return (String) this.b.get(str);
        }
        l lVarK = aVar.k(str);
        if (lVarK.a() == 0 || lVarK.a() == 1) {
            return (String) this.b.get(str);
        }
        try {
            return lVarK.c();
        } catch (IllegalArgumentException unused) {
            return (String) this.b.get(str);
        }
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0063 A[Catch: Exception -> 0x007e, TRY_LEAVE, TryCatch #1 {Exception -> 0x007e, blocks: (B:20:0x0043, B:21:0x005d, B:23:0x0063), top: B:28:0x0043 }] */
    /* JADX WARN: Instruction removed from duplicated block: B:23:0x0063, please report this as an issue */
    public void f(Context context, HashMap<String, Object> map, boolean z) {
        String str;
        Iterator<String> it;
        this.b = map;
        try {
            if (this.a == null) {
                if (!z || !g()) {
                    this.c = false;
                    return;
                }
                f.q(context);
                com.google.firebase.remoteconfig.a aVarH = com.google.firebase.remoteconfig.a.h();
                this.a = aVarH;
                aVarH.g().b(new a());
                if (B.D("GoogleApiHandler")) {
                    d.fine("ThreadGuard : GoogleApiHandler");
                }
                this.c = true;
            }
        } catch (RuntimeException e) {
            e = e;
            e.printStackTrace();
            str = null;
            try {
                str = "sign:";
                it = B.p(context.getPackageManager().getPackageInfo(context.getPackageName(), 64).signatures).iterator();
                while (it.hasNext()) {
                    str = str + it.next() + ":::";
                }
            } catch (Exception unused) {
            }
            c.h().g().d("FIREBASE INIT ERROR").m(e).h(str).i();
        } catch (VerifyError e2) {
            e = e2;
            e.printStackTrace();
            str = null;
            str = "sign:";
            it = B.p(context.getPackageManager().getPackageInfo(context.getPackageName(), 64).signatures).iterator();
            while (it.hasNext()) {
                str = str + it.next() + ":::";
            }
            c.h().g().d("FIREBASE INIT ERROR").m(e).h(str).i();
        }
    }

    public boolean g() {
        return !"LG-E615f".equals(Build.MODEL);
    }
}
