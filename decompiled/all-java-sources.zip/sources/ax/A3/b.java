package ax.A3;

import android.support.v4.media.session.MediaSessionCompat;

/* JADX INFO: loaded from: classes.dex */
public interface b {

    public interface a {
        void a(String str, boolean z);

        void b();

        void c(int i);
    }

    void N();

    boolean a();

    boolean b();

    void c(MediaSessionCompat.QueueItem queueItem);

    void d(boolean z);

    void e(a aVar);

    void f(String str, int i);

    void g(int i);

    int getState();

    String h();

    int i();

    void j(int i);
}
