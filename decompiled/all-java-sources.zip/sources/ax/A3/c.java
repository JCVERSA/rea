package ax.A3;

import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import ax.p340y3.h;
import ax.p340y3.i;

/* JADX INFO: loaded from: classes.dex */
public class c implements ax.A3.b.a {
    private static final String n = ax.B3.b.f(c.class);
    private ax.p354z3.b a;
    private d b;
    private Resources c;
    private ax.A3.b d;
    private InterfaceC0053c e;
    private String g;
    private int h;
    private int i;
    private boolean j;
    private boolean l;
    Handler k = new Handler(Looper.getMainLooper());
    private Runnable m = new a();
    private b f = new b(this, null);

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            c.this.H();
            c.this.l = false;
        }
    }

    private class b extends MediaSessionCompat.b {
        private b() {
        }

        private void E(Uri uri, Bundle bundle) {
            ax.p354z3.c cVar = new ax.p354z3.c();
            String strA = cVar.a(uri, bundle);
            c.this.a.o(cVar);
            c.this.j = cVar.d();
            c.this.g = ax.B3.c.a(strA, new String[0]);
            int i = bundle.getInt("PLAY_RESUME_POSITION", -1);
            if (i != -1) {
                c.this.d.f(c.this.g, i);
            }
            c.this.b.r(c.this.g);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void A() {
            c.this.I();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void B(long j) {
            if (c.this.b.k()) {
                return;
            }
            ax.B3.b.a(c.n, "OnSkipToQueueItem:" + j);
            c.this.b.p(j);
            c.this.x();
            c.this.b.v();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void C() {
            ax.B3.b.a(c.n, "stop. current state=" + c.this.d.getState());
            c.this.y(null);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void e(String str, Bundle bundle) {
            String strF;
            if (!"com.example.android.uamp.THUMBS_UP".equals(str)) {
                ax.B3.b.c(c.n, "Unsupported action: ", str);
                return;
            }
            ax.B3.b.d(c.n, "onCustomAction: favorite for current track");
            MediaSessionCompat.QueueItem queueItemH = c.this.b.h();
            if (queueItemH != null && (strF = queueItemH.c().f()) != null) {
                String strB = ax.B3.c.b(strF);
                c.this.a.r(strB, true ^ c.this.a.k(strB));
            }
            c.this.K(null);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void h() {
            ax.B3.b.a(c.n, "pause. current state=" + c.this.d.getState());
            c.this.w();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void i() {
            ax.B3.b.a(c.n, "play");
            if (c.this.b.h() != null) {
                c.this.x();
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void j(String str, Bundle bundle) {
            if (c.this.b.k()) {
                return;
            }
            ax.B3.b.a(c.n, "playFromMediaId mediaId:", str, "  extras=", bundle);
            c.this.b.s(str);
            c.this.x();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void l(Uri uri, Bundle bundle) {
            E(uri, bundle);
            c.this.x();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void p(Uri uri, Bundle bundle) {
            E(uri, bundle);
            c.this.K(null);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void s(long j) {
            ax.B3.b.a(c.n, "onSeekTo:", Long.valueOf(j));
            c.this.d.g((int) j);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void x(int i) {
            c.this.E(i);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void y(int i) {
            c.this.F(i);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.b
        public void z() {
            c.this.G();
        }

        /* synthetic */ b(c cVar, a aVar) {
            this();
        }
    }

    /* JADX INFO: renamed from: ax.A3.c$c, reason: collision with other inner class name */
    public interface InterfaceC0053c {
        void Q(int i);

        void a() throws ax.B3.a;

        void b(PlaybackStateCompat playbackStateCompat);

        void c(ax.A3.b bVar, String str, boolean z, boolean z2);

        void d(ax.A3.b bVar, boolean z);

        void e();

        void p0(int i);
    }

    public c(InterfaceC0053c interfaceC0053c, Resources resources, ax.p354z3.b bVar, d dVar, ax.A3.b bVar2) {
        this.a = bVar;
        this.e = interfaceC0053c;
        this.c = resources;
        this.b = dVar;
        this.d = bVar2;
        bVar2.e(this);
    }

    private boolean B() {
        String str = this.g;
        return str != null && str.equals(this.b.g());
    }

    private void C() {
        this.k.postDelayed(this.m, 1000L);
        this.l = true;
    }

    private void D(PlaybackStateCompat.d dVar) {
        String strF;
        MediaSessionCompat.QueueItem queueItemH = this.b.h();
        if (queueItemH == null || (strF = queueItemH.c().f()) == null) {
            return;
        }
        String strB = ax.B3.c.b(strF);
        int i = this.a.k(strB) ? h.e : h.d;
        ax.B3.b.a(n, "updatePlaybackState, setting Favorite custom action of music ", strB, " current favorite=", Boolean.valueOf(this.a.k(strB)));
        dVar.a(new PlaybackStateCompat.CustomAction.b("com.example.android.uamp.THUMBS_UP", this.c.getString(i.b), i).b(new Bundle()).a());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E(int i) {
        this.i = i;
        this.e.Q(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void F(int i) {
        this.h = i;
        this.b.t(i);
        this.e.p0(i);
        this.g = this.b.g();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G() {
        if (this.b.k()) {
            return;
        }
        ax.B3.b.a(n, "skipToNext");
        if (this.b.u(1)) {
            x();
        } else {
            y("Cannot skip");
        }
        this.b.v();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H() {
        G();
        if (this.i == 0 && B()) {
            J(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I() {
        if (this.b.k()) {
            return;
        }
        int iF = this.b.f();
        if (this.b.u(-1)) {
            if (iF == this.b.f()) {
                this.d.j(0);
            }
            x();
        } else {
            y("Cannot skip");
        }
        this.b.v();
    }

    private void J(boolean z) {
        y(null);
        if (z) {
            this.b.m();
        }
    }

    private void q() {
        if (this.l) {
            this.k.removeCallbacks(this.m);
            this.l = false;
        }
    }

    private long r() {
        return this.d.b() ? 2362422L : 2362421L;
    }

    public void A(int i, int i2) {
        E(i2);
        F(i);
    }

    public void K(String str) {
        ax.B3.b.a(n, "updatePlaybackState, playback state=" + this.d.getState());
        ax.A3.b bVar = this.d;
        long jI = (bVar == null || !bVar.a()) ? -1L : this.d.i();
        PlaybackStateCompat.d dVarC = new PlaybackStateCompat.d().c(r());
        D(dVarC);
        int state = this.d.getState();
        if (str != null) {
            dVarC.e(str);
            state = 7;
        }
        dVarC.f(state, jI, 1.0f, SystemClock.elapsedRealtime());
        MediaSessionCompat.QueueItem queueItemH = this.b.h();
        if (queueItemH != null) {
            dVarC.d(queueItemH.d());
        }
        this.e.b(dVarC.b());
        if (state == 3 || state == 2) {
            try {
                this.e.a();
            } catch (ax.B3.a unused) {
                if (state == 3) {
                    w();
                }
            }
        }
    }

    @Override // ax.A3.b.a
    public void a(String str, boolean z) {
        boolean z2;
        K(str);
        if (!z) {
            z2 = false;
        } else if (B()) {
            z2 = true;
        } else {
            C();
            z2 = false;
        }
        this.e.c(this.d, str, z, z2);
    }

    @Override // ax.A3.b.a
    public void b() {
        int i = this.i;
        if (i == 1) {
            this.d.j(0);
            x();
            this.b.v();
        } else {
            if (i == 3) {
                J(true);
                return;
            }
            if (!this.b.u(1)) {
                y(null);
                return;
            }
            if (this.i == 0 && B()) {
                J(true);
            } else {
                if (B()) {
                    this.d.j(0);
                }
                x();
            }
            this.b.v();
        }
    }

    @Override // ax.A3.b.a
    public void c(int i) {
        K(null);
    }

    public int s() {
        return this.b.e();
    }

    public int t() {
        return this.b.i();
    }

    public MediaSessionCompat.b u() {
        return this.f;
    }

    public ax.A3.b v() {
        return this.d;
    }

    public void w() {
        q();
        ax.B3.b.a(n, "handlePauseRequest: mState=" + this.d.getState());
        if (this.d.b()) {
            this.d.N();
            this.e.d(this.d, true);
        }
    }

    public void x() {
        q();
        ax.B3.b.a(n, "handlePlayRequest: mState=" + this.d.getState());
        MediaSessionCompat.QueueItem queueItemH = this.b.h();
        if (queueItemH != null) {
            this.e.e();
            this.d.c(queueItemH);
        }
    }

    public void y(String str) {
        q();
        ax.B3.b.a(n, "handleStopRequest: mState=" + this.d.getState() + " error=", str);
        this.d.d(true);
        this.e.d(this.d, false);
        if (str != null) {
            K(str);
        }
    }

    public boolean z() {
        return this.j;
    }
}
