package ax.A3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import ax.p340y3.k;
import com.example.android.uamp.MusicService;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public class a implements b, AudioManager.OnAudioFocusChangeListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnSeekCompleteListener {
    private static final String t0 = ax.B3.b.f(a.class);
    public static int u0;
    private final WifiManager.WifiLock X;
    private int Y;
    private boolean Z;
    private b.a h0;
    private final ax.p354z3.b i0;
    private volatile boolean j0;
    private volatile int k0;
    private volatile int l0;
    private volatile String m0;
    private volatile String n0;
    private final AudioManager p0;
    private final Context q;
    private MediaPlayer q0;
    private int o0 = 0;
    private final IntentFilter r0 = new IntentFilter("android.media.AUDIO_BECOMING_NOISY");
    private final BroadcastReceiver s0 = new C0052a();

    /* JADX INFO: renamed from: ax.A3.a$a, reason: collision with other inner class name */
    class C0052a extends BroadcastReceiver {
        C0052a() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("android.media.AUDIO_BECOMING_NOISY".equals(intent.getAction())) {
                ax.B3.b.a(a.t0, "Headphones disconnected.");
                if (a.this.b()) {
                    Intent intent2 = new Intent(context, (Class<?>) MusicService.class);
                    intent2.setAction("com.example.android.uamp.ACTION_CMD");
                    intent2.putExtra("CMD_NAME", "CMD_PAUSE");
                    try {
                        k.d(a.this.q, intent2);
                    } catch (IllegalStateException e) {
                        ax.p221pa.c.i(a.this.q).g().b("AUDIO NOISY").m(e).i();
                    }
                }
            }
        }
    }

    public a(Context context, ax.p354z3.b bVar) {
        this.q = context;
        this.i0 = bVar;
        this.p0 = (AudioManager) context.getSystemService("audio");
        WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService("wifi");
        if (wifiManager != null) {
            this.X = wifiManager.createWifiLock(3, "uAmp_lock");
        } else {
            this.X = null;
        }
        this.Y = 0;
    }

    private void m() {
        String str = t0;
        ax.B3.b.a(str, "configMediaPlayerState. mAudioFocus=", Integer.valueOf(this.o0));
        int i = this.o0;
        if (i != 0) {
            if (i == 1) {
                MediaPlayer mediaPlayer = this.q0;
                if (mediaPlayer != null) {
                    mediaPlayer.setVolume(0.2f, 0.2f);
                }
            } else {
                MediaPlayer mediaPlayer2 = this.q0;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.setVolume(1.0f, 1.0f);
                }
            }
            if (this.Z) {
                MediaPlayer mediaPlayer3 = this.q0;
                if (mediaPlayer3 != null && !mediaPlayer3.isPlaying()) {
                    ax.B3.b.a(str, "configMediaPlayerState startMediaPlayer. seeking to ", Integer.valueOf(this.k0));
                    if (this.k0 == this.q0.getCurrentPosition()) {
                        this.q0.start();
                        this.Y = 3;
                    } else {
                        this.q0.seekTo(this.k0);
                        this.Y = 6;
                    }
                }
                this.Z = false;
            }
        } else if (this.Y == 3) {
            N();
        }
        b.a aVar = this.h0;
        if (aVar != null) {
            aVar.c(this.Y);
        }
    }

    private void n() {
        ax.B3.b.a(t0, "createMediaPlayerIfNeeded. needed? ", Boolean.valueOf(this.q0 == null));
        MediaPlayer mediaPlayer = this.q0;
        if (mediaPlayer != null) {
            mediaPlayer.reset();
            return;
        }
        try {
            MediaPlayer mediaPlayer2 = new MediaPlayer();
            this.q0 = mediaPlayer2;
            mediaPlayer2.setWakeMode(this.q.getApplicationContext(), 1);
            this.q0.setOnPreparedListener(this);
            this.q0.setOnCompletionListener(this);
            this.q0.setOnErrorListener(this);
            this.q0.setOnSeekCompleteListener(this);
            try {
                Intent intent = new Intent("android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION");
                intent.putExtra("android.media.extra.PACKAGE_NAME", this.q.getPackageName());
                intent.putExtra("android.media.extra.AUDIO_SESSION", this.q0.getAudioSessionId());
                this.q.sendBroadcast(intent);
            } catch (Exception unused) {
            }
            u0 = this.q0.getAudioSessionId();
        } catch (NullPointerException e) {
            ax.p221pa.c.i(this.q).d("MEDIA PLAYER CREATE INSTANCE ERROR").m(e).i();
            throw new IllegalStateException(e);
        }
    }

    public static int p() {
        return u0;
    }

    private void q() {
        ax.B3.b.a(t0, "giveUpAudioFocus");
        if (this.o0 == 2 && this.p0.abandonAudioFocus(this) == 1) {
            this.o0 = 0;
        }
    }

    private boolean r(Uri uri) {
        String scheme = uri.getScheme();
        return "file".equals(scheme) || "content".equals(scheme);
    }

    private void s() {
        if (this.j0) {
            return;
        }
        this.q.registerReceiver(this.s0, this.r0);
        this.j0 = true;
    }

    private void t(boolean z) {
        MediaPlayer mediaPlayer;
        ax.B3.b.a(t0, "relaxResources. releaseMediaPlayer=", Boolean.valueOf(z));
        if (z && (mediaPlayer = this.q0) != null) {
            mediaPlayer.reset();
            try {
                this.q0.release();
            } catch (IllegalArgumentException unused) {
            }
            this.q0 = null;
            u0 = 0;
        }
        WifiManager.WifiLock wifiLock = this.X;
        if (wifiLock == null || !wifiLock.isHeld()) {
            return;
        }
        this.X.release();
    }

    private void u() {
        ax.B3.b.a(t0, "tryToGetAudioFocus");
        if (this.o0 == 2 || this.p0.requestAudioFocus(this, 3, 1) != 1) {
            return;
        }
        this.o0 = 2;
    }

    private void v() {
        if (this.j0) {
            try {
                this.q.unregisterReceiver(this.s0);
            } catch (IllegalArgumentException unused) {
            }
            this.j0 = false;
        }
    }

    @Override // ax.A3.b
    public void N() {
        if (this.Y == 3) {
            MediaPlayer mediaPlayer = this.q0;
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                this.q0.pause();
                this.k0 = this.q0.getCurrentPosition();
            }
            t(false);
            q();
        }
        this.Y = 2;
        b.a aVar = this.h0;
        if (aVar != null) {
            aVar.c(2);
        }
        v();
    }

    @Override // ax.A3.b
    public boolean a() {
        return true;
    }

    @Override // ax.A3.b
    public boolean b() {
        MediaPlayer mediaPlayer;
        return this.Z || ((mediaPlayer = this.q0) != null && mediaPlayer.isPlaying());
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:56:? A[RETURN, SYNTHETIC] */
    @Override // ax.A3.b
    public void c(MediaSessionCompat.QueueItem queueItem) {
        b.a aVar;
        WifiManager.WifiLock wifiLock;
        this.Z = true;
        u();
        s();
        String strF = queueItem.c().f();
        boolean z = !TextUtils.equals(strF, this.n0);
        if (z) {
            if (this.l0 == 0 || strF == null || !strF.equals(this.m0)) {
                this.k0 = 0;
            } else {
                this.k0 = this.l0;
            }
            this.l0 = 0;
            this.m0 = null;
            this.n0 = strF;
        }
        if (this.Y == 2 && !z && this.q0 != null) {
            m();
            return;
        }
        this.Y = 1;
        t(false);
        String strH = this.i0.e(ax.B3.c.b(queueItem.c().f())).h("__SOURCE__");
        try {
            n();
            this.Y = 6;
            this.q0.setAudioStreamType(3);
            Uri uri = Uri.parse(strH);
            this.q0.setDataSource(this.q, uri);
            this.q0.prepareAsync();
            if (!r(uri) && (wifiLock = this.X) != null) {
                wifiLock.acquire();
            }
            b.a aVar2 = this.h0;
            if (aVar2 != null) {
                aVar2.c(this.Y);
            }
        } catch (IOException e) {
            e = e;
            ax.B3.b.b(t0, e, "Exception playing song");
            aVar = this.h0;
            if (aVar != null) {
                aVar.a(e.getMessage(), true);
            }
        } catch (IllegalArgumentException e2) {
            ax.p221pa.c.i(this.q).g().d("MEDIA PLAYER ILLEGAL ARGUMENT ERROR").m(e2).i();
            b.a aVar3 = this.h0;
            if (aVar3 != null) {
                aVar3.a(e2.getMessage(), true);
            }
        } catch (IllegalStateException e3) {
            e = e3;
            ax.B3.b.b(t0, e, "Exception playing song");
            aVar = this.h0;
            if (aVar != null) {
                aVar.a(e.getMessage(), true);
            }
        } catch (NullPointerException e4) {
            ax.p221pa.c.i(this.q).g().b("MEDIA PLAYER ERROR").m(e4).i();
            b.a aVar4 = this.h0;
            if (aVar4 != null) {
                aVar4.a(e4.getMessage(), true);
            }
        } catch (SecurityException e5) {
            e = e5;
            ax.B3.b.b(t0, e, "Exception playing song");
            aVar = this.h0;
            if (aVar != null) {
                aVar.a(e.getMessage(), true);
            }
        }
    }

    @Override // ax.A3.b
    public void d(boolean z) {
        b.a aVar;
        this.Y = 1;
        if (z && (aVar = this.h0) != null) {
            aVar.c(1);
        }
        this.k0 = i();
        q();
        v();
        t(true);
    }

    @Override // ax.A3.b
    public void e(b.a aVar) {
        this.h0 = aVar;
    }

    @Override // ax.A3.b
    public void f(String str, int i) {
        this.k0 = i;
        this.l0 = i;
        this.m0 = str;
    }

    @Override // ax.A3.b
    public void g(int i) {
        b.a aVar;
        ax.B3.b.a(t0, "seekTo called with ", Integer.valueOf(i));
        MediaPlayer mediaPlayer = this.q0;
        if (mediaPlayer == null) {
            this.k0 = i;
            return;
        }
        int i2 = this.Y;
        if (mediaPlayer.isPlaying()) {
            this.Y = 6;
        }
        this.q0.seekTo(i);
        int i3 = this.Y;
        if (i2 == i3 || (aVar = this.h0) == null) {
            return;
        }
        aVar.c(i3);
    }

    @Override // ax.A3.b
    public int getState() {
        return this.Y;
    }

    @Override // ax.A3.b
    public String h() {
        return this.n0;
    }

    @Override // ax.A3.b
    public int i() {
        MediaPlayer mediaPlayer = this.q0;
        return mediaPlayer != null ? mediaPlayer.getCurrentPosition() : this.k0;
    }

    @Override // ax.A3.b
    public void j(int i) {
        this.k0 = i;
    }

    public void o() {
        t(true);
    }

    @Override // android.media.AudioManager.OnAudioFocusChangeListener
    public void onAudioFocusChange(int i) {
        String str = t0;
        ax.B3.b.a(str, "onAudioFocusChange. focusChange=", Integer.valueOf(i));
        if (i == 1) {
            this.o0 = 2;
        } else if (i == -1 || i == -2 || i == -3) {
            int i2 = i == -3 ? 1 : 0;
            this.o0 = i2;
            if (this.Y == 3 && i2 == 0) {
                this.Z = true;
            }
        } else {
            ax.B3.b.c(str, "onAudioFocusChange: Ignoring unsupported focusChange: ", Integer.valueOf(i));
        }
        m();
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mediaPlayer) {
        ax.B3.b.a(t0, "onCompletion from MediaPlayer");
        g(0);
        b.a aVar = this.h0;
        if (aVar != null) {
            aVar.b();
        }
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        ax.B3.b.c(t0, "Media player error: what=" + i + ", extra=" + i2);
        b.a aVar = this.h0;
        if (aVar != null) {
            aVar.a("MediaPlayer error " + i + " (" + i2 + ")", false);
        }
        return true;
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mediaPlayer) {
        ax.B3.b.a(t0, "onPrepared from MediaPlayer");
        m();
    }

    @Override // android.media.MediaPlayer.OnSeekCompleteListener
    public void onSeekComplete(MediaPlayer mediaPlayer) {
        ax.B3.b.a(t0, "onSeekComplete from MediaPlayer:", Integer.valueOf(mediaPlayer.getCurrentPosition()));
        this.k0 = mediaPlayer.getCurrentPosition();
        if (this.Y == 6) {
            this.q0.start();
            this.Y = 3;
        }
        b.a aVar = this.h0;
        if (aVar != null) {
            aVar.c(this.Y);
        }
    }
}
