package ax.A3;

import android.content.Context;
import android.os.Bundle;
import ax.U2.c;
import ax.p390y3.k;
import ax.p390y3.m;
import com.google.firebase.analytics.FirebaseAnalytics;

/* JADX INFO: loaded from: classes.dex */
public class a {
    private FirebaseAnalytics a;

    public void a(boolean z) {
        FirebaseAnalytics firebaseAnalytics = this.a;
        if (firebaseAnalytics != null) {
            firebaseAnalytics.b(z);
        }
    }

    public void b(Context context) {
        if (!c.a() && this.a == null) {
            try {
                boolean zO = k.o(context);
                FirebaseAnalytics firebaseAnalytics = FirebaseAnalytics.getInstance(context);
                this.a = firebaseAnalytics;
                firebaseAnalytics.c("navigation_type", m.k());
                a(zO);
                if (zO) {
                    this.a.a("INIT_EVENT", new Bundle());
                }
            } catch (IllegalArgumentException | IllegalStateException | NoClassDefFoundError | NullPointerException | SecurityException unused) {
            }
        }
    }

    public void c(String str, Bundle bundle) {
        FirebaseAnalytics firebaseAnalytics = this.a;
        if (firebaseAnalytics != null) {
            firebaseAnalytics.a(str, bundle);
        }
    }
}
