package ax.A9;

/* JADX INFO: loaded from: classes3.dex */
public class b extends RuntimeException {
    public b(String str) {
        super(str);
    }

    public b(Throwable th) {
        super(th);
    }
}
