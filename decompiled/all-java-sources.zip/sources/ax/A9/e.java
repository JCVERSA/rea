package ax.A9;

/* JADX INFO: loaded from: classes2.dex */
public interface e {
    <T> String a(T t);

    <T> T b(String str, Class<T> cls);
}
