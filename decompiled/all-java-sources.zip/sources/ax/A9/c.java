package ax.A9;

import ax.p149k8.o;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import java.util.EnumSet;
import java.util.Iterator;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes2.dex */
public class c {
    public static EnumSet a(Type type, String str) {
        Gson gson = new Gson();
        String str2 = "[" + str + "]";
        if (str == null) {
            return null;
        }
        return (EnumSet) gson.j(str2, type);
    }

    public static o b(EnumSet<?> enumSet) {
        Iterator<?> it = enumSet.iterator();
        String str = HttpUrl.FRAGMENT_ENCODE_SET;
        while (it.hasNext()) {
            str = str + it.next().toString() + ",";
        }
        return new o(str.substring(0, str.length() - 1));
    }
}
