package ax.A9;

import ax.p149k8.l;

/* JADX INFO: loaded from: classes2.dex */
public interface d {
    void c(e eVar, l lVar);

    com.microsoft.graph.serializer.a d();
}
