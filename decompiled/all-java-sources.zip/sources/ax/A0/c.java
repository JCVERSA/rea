package ax.A0;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.m;
import ax.Xa.C;
import ax.Xa.C5081l;
import ax.Xa.I;
import ax.p138jb.l;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class c {
    public static final c a = new c();
    private static C0050c b = C0050c.d;

    public enum a {
        PENALTY_LOG,
        PENALTY_DEATH,
        DETECT_FRAGMENT_REUSE,
        DETECT_FRAGMENT_TAG_USAGE,
        DETECT_RETAIN_INSTANCE_USAGE,
        DETECT_SET_USER_VISIBLE_HINT,
        DETECT_TARGET_FRAGMENT_USAGE,
        DETECT_WRONG_FRAGMENT_CONTAINER
    }

    public interface b {
    }

    /* JADX INFO: renamed from: ax.A0.c$c, reason: collision with other inner class name */
    public static final class C0050c {
        public static final a c = new a(null);
        public static final C0050c d = new C0050c(I.b(), null, C.d());
        private final Set<a> a;
        private final Map<String, Set<Class<? extends i>>> b;

        /* JADX INFO: renamed from: ax.A0.c$c$a */
        public static final class a {
            private a() {
            }

            public /* synthetic */ a(ax.p138jb.g gVar) {
                this();
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        public C0050c(Set<? extends a> set, b bVar, Map<String, ? extends Set<Class<? extends i>>> map) {
            l.f(set, "flags");
            l.f(map, "allowedViolations");
            this.a = set;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry<String, ? extends Set<Class<? extends i>>> entry : map.entrySet()) {
                linkedHashMap.put(entry.getKey(), entry.getValue());
            }
            this.b = linkedHashMap;
        }

        public final Set<a> a() {
            return this.a;
        }

        public final b b() {
            return null;
        }

        public final Map<String, Set<Class<? extends i>>> c() {
            return this.b;
        }
    }

    private c() {
    }

    private final C0050c b(Fragment fragment) {
        while (fragment != null) {
            if (fragment.l1()) {
                m mVarN0 = fragment.N0();
                l.e(mVarN0, "declaringFragment.parentFragmentManager");
                if (mVarN0.A0() != null) {
                    C0050c c0050cA0 = mVarN0.A0();
                    l.c(c0050cA0);
                    return c0050cA0;
                }
            }
            fragment = fragment.M0();
        }
        return b;
    }

    private final void c(C0050c c0050c, final i iVar) {
        Fragment fragmentA = iVar.a();
        final String name = fragmentA.getClass().getName();
        if (c0050c.a().contains(a.PENALTY_LOG)) {
            Log.d("FragmentStrictMode", "Policy violation in " + name, iVar);
        }
        c0050c.b();
        if (c0050c.a().contains(a.PENALTY_DEATH)) {
            l(fragmentA, new Runnable() { // from class: ax.A0.b
                @Override // java.lang.Runnable
                public final void run() {
                    c.d(name, iVar);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(String str, i iVar) {
        l.f(iVar, "$violation");
        Log.e("FragmentStrictMode", "Policy violation with PENALTY_DEATH in " + str, iVar);
        throw iVar;
    }

    private final void e(i iVar) {
        if (m.H0(3)) {
            Log.d("FragmentManager", "StrictMode violation in " + iVar.a().getClass().getName(), iVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void f(Fragment fragment, String str) {
        l.f(fragment, "fragment");
        l.f(str, "previousFragmentId");
        ax.A0.a aVar = new ax.A0.a(fragment, str);
        c cVar = a;
        cVar.e(aVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_FRAGMENT_REUSE) && cVar.m(c0050cB, fragment.getClass(), aVar.getClass())) {
            cVar.c(c0050cB, aVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void g(Fragment fragment, ViewGroup viewGroup) {
        l.f(fragment, "fragment");
        d dVar = new d(fragment, viewGroup);
        c cVar = a;
        cVar.e(dVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_FRAGMENT_TAG_USAGE) && cVar.m(c0050cB, fragment.getClass(), dVar.getClass())) {
            cVar.c(c0050cB, dVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void h(Fragment fragment) {
        l.f(fragment, "fragment");
        e eVar = new e(fragment);
        c cVar = a;
        cVar.e(eVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.m(c0050cB, fragment.getClass(), eVar.getClass())) {
            cVar.c(c0050cB, eVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void i(Fragment fragment) {
        l.f(fragment, "fragment");
        f fVar = new f(fragment);
        c cVar = a;
        cVar.e(fVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.m(c0050cB, fragment.getClass(), fVar.getClass())) {
            cVar.c(c0050cB, fVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void j(Fragment fragment, Fragment fragment2, int i) {
        l.f(fragment, "violatingFragment");
        l.f(fragment2, "targetFragment");
        g gVar = new g(fragment, fragment2, i);
        c cVar = a;
        cVar.e(gVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.m(c0050cB, fragment.getClass(), gVar.getClass())) {
            cVar.c(c0050cB, gVar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final void k(Fragment fragment, ViewGroup viewGroup) {
        l.f(fragment, "fragment");
        l.f(viewGroup, "container");
        j jVar = new j(fragment, viewGroup);
        c cVar = a;
        cVar.e(jVar);
        C0050c c0050cB = cVar.b(fragment);
        if (c0050cB.a().contains(a.DETECT_WRONG_FRAGMENT_CONTAINER) && cVar.m(c0050cB, fragment.getClass(), jVar.getClass())) {
            cVar.c(c0050cB, jVar);
        }
    }

    private final void l(Fragment fragment, Runnable runnable) {
        if (!fragment.l1()) {
            runnable.run();
            return;
        }
        Handler handlerH = fragment.N0().u0().h();
        l.e(handlerH, "fragment.parentFragmentManager.host.handler");
        if (l.a(handlerH.getLooper(), Looper.myLooper())) {
            runnable.run();
        } else {
            handlerH.post(runnable);
        }
    }

    private final boolean m(C0050c c0050c, Class<? extends Fragment> cls, Class<? extends i> cls2) {
        Set<Class<? extends i>> set = c0050c.c().get(cls.getName());
        if (set == null) {
            return true;
        }
        if (l.a(cls2.getSuperclass(), i.class) || !C5081l.v(set, cls2.getSuperclass())) {
            return !set.contains(cls2);
        }
        return false;
    }
}
