package ax.A0;

import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import ax.p138jb.l;

/* JADX INFO: loaded from: classes.dex */
public final class d extends i {
    private final ViewGroup X;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(Fragment fragment, ViewGroup viewGroup) {
        super(fragment, "Attempting to use <fragment> tag to add fragment " + fragment + " to container " + viewGroup);
        l.f(fragment, "fragment");
        this.X = viewGroup;
    }
}
