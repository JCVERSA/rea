package ax.A0;

import androidx.fragment.app.Fragment;
import ax.p138jb.l;

/* JADX INFO: loaded from: classes.dex */
public final class f extends h {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(Fragment fragment) {
        super(fragment, "Attempting to get target fragment from fragment " + fragment);
        l.f(fragment, "fragment");
    }
}
