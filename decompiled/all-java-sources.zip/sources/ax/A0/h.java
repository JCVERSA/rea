package ax.A0;

import androidx.fragment.app.Fragment;
import ax.p138jb.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class h extends i {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(Fragment fragment, String str) {
        super(fragment, str);
        l.f(fragment, "fragment");
    }
}
