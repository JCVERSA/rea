package ax.A0;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

/* JADX INFO: loaded from: classes.dex */
public interface k {
    void a(FragmentManager fragmentManager, Fragment fragment);
}
