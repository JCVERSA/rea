package ax.A0;

import androidx.fragment.app.Fragment;
import ax.p138jb.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class i extends RuntimeException {
    private final Fragment q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(Fragment fragment, String str) {
        super(str);
        l.f(fragment, "fragment");
        this.q = fragment;
    }

    public final Fragment a() {
        return this.q;
    }
}
