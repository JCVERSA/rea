package ax.A0;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public interface l {
    void a(String str, Bundle bundle);
}
