package ax.A5;

import ax.E5.l;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public class b implements l {
    private final GoogleSignInAccount X;
    private final Status q;

    public GoogleSignInAccount a() {
        return this.X;
    }

    @Override // ax.E5.l
    public Status e() {
        return this.q;
    }
}
