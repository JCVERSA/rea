package ax.A6;

import android.os.IInterface;
import android.os.RemoteException;

/* JADX INFO: loaded from: classes3.dex */
public interface f extends IInterface {
    String c() throws RemoteException;

    boolean f() throws RemoteException;

    boolean j2(boolean z) throws RemoteException;
}
