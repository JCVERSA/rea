package ax.A6;

import android.annotation.TargetApi;

/* JADX INFO: loaded from: classes3.dex */
public final class i {
    private static volatile h a = new g();

    @TargetApi(28)
    public static void a() {
    }

    public static void b(int i) {
    }
}
