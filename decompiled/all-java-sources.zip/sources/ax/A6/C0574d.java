package ax.A6;

import android.R;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.view.Window;
import ax.P5.C1452Re;
import ax.p015b0.C5232m0;

/* JADX INFO: renamed from: ax.A6.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public class C0574d {
    public static void a(Window window, boolean z, Integer num, Integer num2) {
        boolean z2 = num == null || num.intValue() == 0;
        boolean z3 = num2 == null || num2.intValue() == 0;
        if (z2 || z3) {
            int iB = ax.p287u6.a.b(window.getContext(), R.attr.colorBackground, -16777216);
            if (z2) {
                num = Integer.valueOf(iB);
            }
            if (z3) {
                num2 = Integer.valueOf(iB);
            }
        }
        C5232m0.b(window, !z);
        int iC = c(window.getContext(), z);
        int iB2 = b(window.getContext(), z);
        window.setStatusBarColor(iC);
        window.setNavigationBarColor(iB2);
        f(window, d(iC, ax.p287u6.a.i(num.intValue())));
        e(window, d(iB2, ax.p287u6.a.i(num2.intValue())));
    }

    @TargetApi(C1452Re.zzm)
    private static int b(Context context, boolean z) {
        if (z && Build.VERSION.SDK_INT < 27) {
            return ax.S.a.k(ax.p287u6.a.b(context, R.attr.navigationBarColor, -16777216), 128);
        }
        if (z) {
            return 0;
        }
        return ax.p287u6.a.b(context, R.attr.navigationBarColor, -16777216);
    }

    @TargetApi(C1452Re.zzm)
    private static int c(Context context, boolean z) {
        if (z && Build.VERSION.SDK_INT < 23) {
            return ax.S.a.k(ax.p287u6.a.b(context, R.attr.statusBarColor, -16777216), 128);
        }
        if (z) {
            return 0;
        }
        return ax.p287u6.a.b(context, R.attr.statusBarColor, -16777216);
    }

    private static boolean d(int i, boolean z) {
        return ax.p287u6.a.i(i) || (i == 0 && z);
    }

    public static void e(Window window, boolean z) {
        C5232m0.a(window, window.getDecorView()).b(z);
    }

    public static void f(Window window, boolean z) {
        C5232m0.a(window, window.getDecorView()).c(z);
    }
}
