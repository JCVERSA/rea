package ax.A6;

import android.annotation.SuppressLint;
import android.widget.ImageButton;

/* JADX INFO: loaded from: classes2.dex */
@SuppressLint({"AppCompatCustomView"})
public class B extends ImageButton {
    private int q;

    public final void b(int i, boolean z) {
        super.setVisibility(i);
        if (z) {
            this.q = i;
        }
    }

    public final int getUserSetVisibility() {
        return this.q;
    }

    @Override // android.widget.ImageView, android.view.View
    public void setVisibility(int i) {
        b(i, true);
    }
}
