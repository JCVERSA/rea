package ax.A6;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import ax.p015b0.A0;
import ax.p015b0.H;
import ax.p015b0.Y;
import ax.p015b0.Z0;

/* JADX INFO: loaded from: classes2.dex */
public class A {

    class a implements H {
        final /* synthetic */ c a;
        final /* synthetic */ d b;

        a(c cVar, d dVar) {
            this.a = cVar;
            this.b = dVar;
        }

        @Override // ax.p015b0.H
        public A0 a(View view, A0 a0) {
            return this.a.a(view, a0, new d(this.b));
        }
    }

    public interface c {
        A0 a(View view, A0 a0, d dVar);
    }

    public static void b(View view, c cVar) {
        Y.E0(view, new a(cVar, new d(Y.H(view), view.getPaddingTop(), Y.G(view), view.getPaddingBottom())));
        j(view);
    }

    public static float c(Context context, int i) {
        return TypedValue.applyDimension(1, i, context.getResources().getDisplayMetrics());
    }

    public static Integer d(View view) {
        ColorStateList colorStateListF = ax.p329x6.f.f(view.getBackground());
        if (colorStateListF != null) {
            return Integer.valueOf(colorStateListF.getDefaultColor());
        }
        return null;
    }

    private static InputMethodManager e(View view) {
        return (InputMethodManager) ax.P.b.f(view.getContext(), InputMethodManager.class);
    }

    public static float f(View view) {
        float fW = 0.0f;
        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
            fW += Y.w((View) parent);
        }
        return fW;
    }

    public static boolean g(View view) {
        return Y.C(view) == 1;
    }

    public static PorterDuff.Mode i(int i, PorterDuff.Mode mode) {
        if (i == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        switch (i) {
            case 14:
                return PorterDuff.Mode.MULTIPLY;
            case 15:
                return PorterDuff.Mode.SCREEN;
            case 16:
                return PorterDuff.Mode.ADD;
            default:
                return mode;
        }
    }

    public static void j(View view) {
        if (Y.T(view)) {
            Y.n0(view);
        } else {
            view.addOnAttachStateChangeListener(new b());
        }
    }

    public static void k(final View view, final boolean z) {
        view.requestFocus();
        view.post(new Runnable() { // from class: ax.A6.z
            @Override // java.lang.Runnable
            public final void run() {
                A.l(view, z);
            }
        });
    }

    public static void l(View view, boolean z) {
        Z0 z0M;
        if (!z || (z0M = Y.M(view)) == null) {
            e(view).showSoftInput(view, 1);
        } else {
            z0M.d(A0.m.a());
        }
    }

    public static class d {
        public int a;
        public int b;
        public int c;
        public int d;

        public d(int i, int i2, int i3, int i4) {
            this.a = i;
            this.b = i2;
            this.c = i3;
            this.d = i4;
        }

        public d(d dVar) {
            this.a = dVar.a;
            this.b = dVar.b;
            this.c = dVar.c;
            this.d = dVar.d;
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            view.removeOnAttachStateChangeListener(this);
            Y.n0(view);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }
}
