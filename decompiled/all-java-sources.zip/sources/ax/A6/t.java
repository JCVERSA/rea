package ax.A6;

import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.lang.reflect.Constructor;
import okhttp3.HttpUrl;

/* JADX INFO: loaded from: classes2.dex */
final class t {
    static final int n;
    private static boolean o;
    private static Constructor<StaticLayout> p;
    private static Object q;
    private CharSequence a;
    private final TextPaint b;
    private final int c;
    private int e;
    private boolean l;
    private int d = 0;
    private Layout.Alignment f = Layout.Alignment.ALIGN_NORMAL;
    private int g = SubsamplingScaleImageView.TILE_SIZE_AUTO;
    private float h = 0.0f;
    private float i = 1.0f;
    private int j = n;
    private boolean k = true;
    private TextUtils.TruncateAt m = null;

    static class a extends Exception {
        a(Throwable th) {
            super("Error thrown initializing StaticLayout " + th.getMessage(), th);
        }
    }

    static {
        n = Build.VERSION.SDK_INT >= 23 ? 1 : 0;
    }

    private t(CharSequence charSequence, TextPaint textPaint, int i) {
        this.a = charSequence;
        this.b = textPaint;
        this.c = i;
        this.e = charSequence.length();
    }

    private void b() throws a {
        if (o) {
            return;
        }
        try {
            q = this.l && Build.VERSION.SDK_INT >= 23 ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR;
            Class cls = Integer.TYPE;
            Class cls2 = Float.TYPE;
            Constructor<StaticLayout> declaredConstructor = StaticLayout.class.getDeclaredConstructor(CharSequence.class, cls, cls, TextPaint.class, cls, Layout.Alignment.class, TextDirectionHeuristic.class, cls2, cls2, Boolean.TYPE, TextUtils.TruncateAt.class, cls, cls);
            p = declaredConstructor;
            declaredConstructor.setAccessible(true);
            o = true;
        } catch (Exception e) {
            throw new a(e);
        }
    }

    public static t c(CharSequence charSequence, TextPaint textPaint, int i) {
        return new t(charSequence, textPaint, i);
    }

    public StaticLayout a() throws a {
        if (this.a == null) {
            this.a = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        int iMax = Math.max(0, this.c);
        CharSequence charSequenceEllipsize = this.a;
        if (this.g == 1) {
            charSequenceEllipsize = TextUtils.ellipsize(charSequenceEllipsize, this.b, iMax, this.m);
        }
        int iMin = Math.min(charSequenceEllipsize.length(), this.e);
        this.e = iMin;
        if (Build.VERSION.SDK_INT < 23) {
            b();
            try {
                return (StaticLayout) ((Constructor) ax.p001a0.g.g(p)).newInstance(charSequenceEllipsize, Integer.valueOf(this.d), Integer.valueOf(this.e), this.b, Integer.valueOf(iMax), this.f, ax.p001a0.g.g(q), Float.valueOf(1.0f), Float.valueOf(0.0f), Boolean.valueOf(this.k), null, Integer.valueOf(iMax), Integer.valueOf(this.g));
            } catch (Exception e) {
                throw new a(e);
            }
        }
        if (this.l && this.g == 1) {
            this.f = Layout.Alignment.ALIGN_OPPOSITE;
        }
        StaticLayout.Builder builderObtain = StaticLayout.Builder.obtain(charSequenceEllipsize, this.d, iMin, this.b, iMax);
        builderObtain.setAlignment(this.f);
        builderObtain.setIncludePad(this.k);
        builderObtain.setTextDirection(this.l ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR);
        TextUtils.TruncateAt truncateAt = this.m;
        if (truncateAt != null) {
            builderObtain.setEllipsize(truncateAt);
        }
        builderObtain.setMaxLines(this.g);
        float f = this.h;
        if (f != 0.0f || this.i != 1.0f) {
            builderObtain.setLineSpacing(f, this.i);
        }
        if (this.g > 1) {
            builderObtain.setHyphenationFrequency(this.j);
        }
        return builderObtain.build();
    }

    public t d(Layout.Alignment alignment) {
        this.f = alignment;
        return this;
    }

    public t e(TextUtils.TruncateAt truncateAt) {
        this.m = truncateAt;
        return this;
    }

    public t f(int i) {
        this.j = i;
        return this;
    }

    public t g(boolean z) {
        this.k = z;
        return this;
    }

    public t h(boolean z) {
        this.l = z;
        return this;
    }

    public t i(float f, float f2) {
        this.h = f;
        this.i = f2;
        return this;
    }

    public t j(int i) {
        this.g = i;
        return this;
    }

    public t k(u uVar) {
        return this;
    }
}
