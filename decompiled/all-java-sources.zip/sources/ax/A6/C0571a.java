package ax.A6;

import android.animation.TimeInterpolator;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import ax.p015b0.C5244t;
import ax.p015b0.Y;

/* JADX INFO: renamed from: ax.A6.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes2.dex */
public final class C0571a {
    private static final boolean t0 = false;
    private static final Paint u0 = null;
    private Typeface A;
    private Typeface B;
    private Typeface C;
    private ax.E6.a D;
    private ax.E6.a E;
    private CharSequence G;
    private CharSequence H;
    private boolean I;
    private boolean K;
    private Bitmap L;
    private Paint M;
    private float N;
    private float O;
    private float P;
    private float Q;
    private float R;
    private int S;
    private int[] T;
    private boolean U;
    private final TextPaint V;
    private final TextPaint W;
    private TimeInterpolator X;
    private TimeInterpolator Y;
    private float Z;
    private final View a;
    private float a0;
    private float b;
    private float b0;
    private boolean c;
    private ColorStateList c0;
    private float d;
    private float d0;
    private float e;
    private float e0;
    private int f;
    private float f0;
    private final Rect g;
    private ColorStateList g0;
    private final Rect h;
    private float h0;
    private final RectF i;
    private float i0;
    private float j0;
    private StaticLayout k0;
    private float l0;
    private float m0;
    private ColorStateList n;
    private float n0;
    private ColorStateList o;
    private CharSequence o0;
    private int p;
    private float q;
    private float r;
    private float s;
    private float t;
    private float u;
    private float v;
    private Typeface w;
    private Typeface x;
    private Typeface y;
    private Typeface z;
    private int j = 16;
    private int k = 16;
    private float l = 15.0f;
    private float m = 15.0f;
    private TextUtils.TruncateAt F = TextUtils.TruncateAt.END;
    private boolean J = true;
    private int p0 = 1;
    private float q0 = 0.0f;
    private float r0 = 1.0f;
    private int s0 = t.n;

    /* JADX INFO: renamed from: ax.A6.a$a, reason: collision with other inner class name */
    class C0055a implements ax.E6.a.InterfaceC0104a {
        C0055a() {
        }

        @Override // ax.E6.a.InterfaceC0104a
        public void a(Typeface typeface) {
            C0571a.this.T(typeface);
        }
    }

    public C0571a(View view) {
        this.a = view;
        TextPaint textPaint = new TextPaint(129);
        this.V = textPaint;
        this.W = new TextPaint(textPaint);
        this.h = new Rect();
        this.g = new Rect();
        this.i = new RectF();
        this.e = e();
        H(view.getContext().getResources().getConfiguration());
    }

    private void A(TextPaint textPaint) {
        textPaint.setTextSize(this.l);
        textPaint.setTypeface(this.z);
        textPaint.setLetterSpacing(this.i0);
    }

    private void B(float f) {
        if (this.c) {
            this.i.set(f < this.e ? this.g : this.h);
            return;
        }
        this.i.left = G(this.g.left, this.h.left, f, this.X);
        this.i.top = G(this.q, this.r, f, this.X);
        this.i.right = G(this.g.right, this.h.right, f, this.X);
        this.i.bottom = G(this.g.bottom, this.h.bottom, f, this.X);
    }

    private static boolean C(float f, float f2) {
        return Math.abs(f - f2) < 1.0E-5f;
    }

    private boolean D() {
        return Y.C(this.a) == 1;
    }

    private boolean F(CharSequence charSequence, boolean z) {
        return (z ? ax.Z.u.d : ax.Z.u.c).a(charSequence, 0, charSequence.length());
    }

    private static float G(float f, float f2, float f3, TimeInterpolator timeInterpolator) {
        if (timeInterpolator != null) {
            f3 = timeInterpolator.getInterpolation(f3);
        }
        return ax.p119i6.a.a(f, f2, f3);
    }

    private float I(TextPaint textPaint, CharSequence charSequence) {
        return textPaint.measureText(charSequence, 0, charSequence.length());
    }

    private static boolean L(Rect rect, int i, int i2, int i3, int i4) {
        return rect.left == i && rect.top == i2 && rect.right == i3 && rect.bottom == i4;
    }

    private void Q(float f) {
        this.m0 = f;
        Y.h0(this.a);
    }

    private boolean U(Typeface typeface) {
        ax.E6.a aVar = this.E;
        if (aVar != null) {
            aVar.c();
        }
        if (this.y == typeface) {
            return false;
        }
        this.y = typeface;
        Typeface typefaceB = ax.E6.j.b(this.a.getContext().getResources().getConfiguration(), typeface);
        this.x = typefaceB;
        if (typefaceB == null) {
            typefaceB = this.y;
        }
        this.w = typefaceB;
        return true;
    }

    private void Y(float f) {
        this.n0 = f;
        Y.h0(this.a);
    }

    private static int a(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.argb(Math.round((Color.alpha(i) * f2) + (Color.alpha(i2) * f)), Math.round((Color.red(i) * f2) + (Color.red(i2) * f)), Math.round((Color.green(i) * f2) + (Color.green(i2) * f)), Math.round((Color.blue(i) * f2) + (Color.blue(i2) * f)));
    }

    private void b(boolean z) {
        StaticLayout staticLayout;
        i(1.0f, z);
        CharSequence charSequence = this.H;
        if (charSequence != null && (staticLayout = this.k0) != null) {
            this.o0 = TextUtils.ellipsize(charSequence, this.V, staticLayout.getWidth(), this.F);
        }
        CharSequence charSequence2 = this.o0;
        float fI = 0.0f;
        if (charSequence2 != null) {
            this.l0 = I(this.V, charSequence2);
        } else {
            this.l0 = 0.0f;
        }
        int iB = C5244t.b(this.k, this.I ? 1 : 0);
        int i = iB & 112;
        if (i == 48) {
            this.r = this.h.top;
        } else if (i != 80) {
            this.r = this.h.centerY() - ((this.V.descent() - this.V.ascent()) / 2.0f);
        } else {
            this.r = this.h.bottom + this.V.ascent();
        }
        int i2 = iB & 8388615;
        if (i2 == 1) {
            this.t = this.h.centerX() - (this.l0 / 2.0f);
        } else if (i2 != 5) {
            this.t = this.h.left;
        } else {
            this.t = this.h.right - this.l0;
        }
        i(0.0f, z);
        StaticLayout staticLayout2 = this.k0;
        float height = staticLayout2 != null ? staticLayout2.getHeight() : 0.0f;
        StaticLayout staticLayout3 = this.k0;
        if (staticLayout3 == null || this.p0 <= 1) {
            CharSequence charSequence3 = this.H;
            if (charSequence3 != null) {
                fI = I(this.V, charSequence3);
            }
        } else {
            fI = staticLayout3.getWidth();
        }
        StaticLayout staticLayout4 = this.k0;
        this.p = staticLayout4 != null ? staticLayout4.getLineCount() : 0;
        int iB2 = C5244t.b(this.j, this.I ? 1 : 0);
        int i3 = iB2 & 112;
        if (i3 == 48) {
            this.q = this.g.top;
        } else if (i3 != 80) {
            this.q = this.g.centerY() - (height / 2.0f);
        } else {
            this.q = (this.g.bottom - height) + this.V.descent();
        }
        int i4 = iB2 & 8388615;
        if (i4 == 1) {
            this.s = this.g.centerX() - (fI / 2.0f);
        } else if (i4 != 5) {
            this.s = this.g.left;
        } else {
            this.s = this.g.right - fI;
        }
        j();
        d0(this.b);
    }

    private boolean b0(Typeface typeface) {
        ax.E6.a aVar = this.D;
        if (aVar != null) {
            aVar.c();
        }
        if (this.B == typeface) {
            return false;
        }
        this.B = typeface;
        Typeface typefaceB = ax.E6.j.b(this.a.getContext().getResources().getConfiguration(), typeface);
        this.A = typefaceB;
        if (typefaceB == null) {
            typefaceB = this.B;
        }
        this.z = typefaceB;
        return true;
    }

    private void c() {
        g(this.b);
    }

    private float d(float f) {
        float f2 = this.e;
        return f <= f2 ? ax.p119i6.a.b(1.0f, 0.0f, this.d, f2, f) : ax.p119i6.a.b(0.0f, 1.0f, f2, 1.0f, f);
    }

    private void d0(float f) {
        h(f);
        boolean z = t0 && this.N != 1.0f;
        this.K = z;
        if (z) {
            n();
        }
        Y.h0(this.a);
    }

    private float e() {
        float f = this.d;
        return f + ((1.0f - f) * 0.5f);
    }

    private boolean f(CharSequence charSequence) {
        boolean zD = D();
        return this.J ? F(charSequence, zD) : zD;
    }

    private void g(float f) {
        float f2;
        B(f);
        if (!this.c) {
            this.u = G(this.s, this.t, f, this.X);
            this.v = G(this.q, this.r, f, this.X);
            d0(f);
            f2 = f;
        } else if (f < this.e) {
            this.u = this.s;
            this.v = this.q;
            d0(0.0f);
            f2 = 0.0f;
        } else {
            this.u = this.t;
            this.v = this.r - Math.max(0, this.f);
            d0(1.0f);
            f2 = 1.0f;
        }
        TimeInterpolator timeInterpolator = ax.p119i6.a.b;
        Q(1.0f - G(0.0f, 1.0f, 1.0f - f, timeInterpolator));
        Y(G(1.0f, 0.0f, f, timeInterpolator));
        if (this.o != this.n) {
            this.V.setColor(a(v(), t(), f2));
        } else {
            this.V.setColor(t());
        }
        int i = Build.VERSION.SDK_INT;
        float f3 = this.h0;
        float f4 = this.i0;
        if (f3 != f4) {
            this.V.setLetterSpacing(G(f4, f3, f, timeInterpolator));
        } else {
            this.V.setLetterSpacing(f3);
        }
        this.P = G(this.d0, this.Z, f, null);
        this.Q = G(this.e0, this.a0, f, null);
        this.R = G(this.f0, this.b0, f, null);
        int iA = a(u(this.g0), u(this.c0), f);
        this.S = iA;
        this.V.setShadowLayer(this.P, this.Q, this.R, iA);
        if (this.c) {
            this.V.setAlpha((int) (d(f) * this.V.getAlpha()));
            if (i >= 31) {
                TextPaint textPaint = this.V;
                textPaint.setShadowLayer(this.P, this.Q, this.R, ax.p287u6.a.a(this.S, textPaint.getAlpha()));
            }
        }
        Y.h0(this.a);
    }

    private void h(float f) {
        i(f, false);
    }

    private void i(float f, boolean z) {
        float f2;
        float f3;
        Typeface typeface;
        if (this.G == null) {
            return;
        }
        float fWidth = this.h.width();
        float fWidth2 = this.g.width();
        if (C(f, 1.0f)) {
            f2 = this.m;
            f3 = this.h0;
            this.N = 1.0f;
            typeface = this.w;
        } else {
            float f4 = this.l;
            float f5 = this.i0;
            Typeface typeface2 = this.z;
            if (C(f, 0.0f)) {
                this.N = 1.0f;
            } else {
                this.N = G(this.l, this.m, f, this.Y) / this.l;
            }
            float f6 = this.m / this.l;
            fWidth = (z || this.c || fWidth2 * f6 <= fWidth) ? fWidth2 : Math.min(fWidth / f6, fWidth2);
            f2 = f4;
            f3 = f5;
            typeface = typeface2;
        }
        boolean z2 = false;
        if (fWidth > 0.0f) {
            boolean z3 = this.O != f2;
            boolean z4 = this.j0 != f3;
            boolean z5 = this.C != typeface;
            StaticLayout staticLayout = this.k0;
            boolean z6 = z3 || z4 || (staticLayout != null && (fWidth > ((float) staticLayout.getWidth()) ? 1 : (fWidth == ((float) staticLayout.getWidth()) ? 0 : -1)) != 0) || z5 || this.U;
            this.O = f2;
            this.j0 = f3;
            this.C = typeface;
            this.U = false;
            this.V.setLinearText(this.N != 1.0f);
            z2 = z6;
        }
        if (this.H == null || z2) {
            this.V.setTextSize(this.O);
            this.V.setTypeface(this.C);
            this.V.setLetterSpacing(this.j0);
            this.I = f(this.G);
            StaticLayout staticLayoutK = k(j0() ? this.p0 : 1, fWidth, this.I);
            this.k0 = staticLayoutK;
            this.H = staticLayoutK.getText();
        }
    }

    private void j() {
        Bitmap bitmap = this.L;
        if (bitmap != null) {
            bitmap.recycle();
            this.L = null;
        }
    }

    private boolean j0() {
        return this.p0 > 1 && (!this.I || this.c) && !this.K;
    }

    private StaticLayout k(int i, float f, boolean z) {
        StaticLayout staticLayoutA = null;
        try {
            staticLayoutA = t.c(this.G, this.V, (int) f).e(this.F).h(z).d(i == 1 ? Layout.Alignment.ALIGN_NORMAL : y()).g(false).j(i).i(this.q0, this.r0).f(this.s0).k(null).a();
        } catch (t.a e) {
            Log.e("CollapsingTextHelper", e.getCause().getMessage(), e);
        }
        return (StaticLayout) ax.p001a0.g.g(staticLayoutA);
    }

    private void m(Canvas canvas, float f, float f2) {
        int alpha = this.V.getAlpha();
        canvas.translate(f, f2);
        if (!this.c) {
            this.V.setAlpha((int) (this.n0 * alpha));
            if (Build.VERSION.SDK_INT >= 31) {
                TextPaint textPaint = this.V;
                textPaint.setShadowLayer(this.P, this.Q, this.R, ax.p287u6.a.a(this.S, textPaint.getAlpha()));
            }
            this.k0.draw(canvas);
        }
        if (!this.c) {
            this.V.setAlpha((int) (this.m0 * alpha));
        }
        int i = Build.VERSION.SDK_INT;
        if (i >= 31) {
            TextPaint textPaint2 = this.V;
            textPaint2.setShadowLayer(this.P, this.Q, this.R, ax.p287u6.a.a(this.S, textPaint2.getAlpha()));
        }
        int lineBaseline = this.k0.getLineBaseline(0);
        CharSequence charSequence = this.o0;
        float f3 = lineBaseline;
        canvas.drawText(charSequence, 0, charSequence.length(), 0.0f, f3, this.V);
        if (i >= 31) {
            this.V.setShadowLayer(this.P, this.Q, this.R, this.S);
        }
        if (this.c) {
            return;
        }
        String strTrim = this.o0.toString().trim();
        if (strTrim.endsWith("…")) {
            strTrim = strTrim.substring(0, strTrim.length() - 1);
        }
        String str = strTrim;
        this.V.setAlpha(alpha);
        canvas.drawText(str, 0, Math.min(this.k0.getLineEnd(0), str.length()), 0.0f, f3, (Paint) this.V);
    }

    private void n() {
        if (this.L != null || this.g.isEmpty() || TextUtils.isEmpty(this.H)) {
            return;
        }
        g(0.0f);
        int width = this.k0.getWidth();
        int height = this.k0.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }
        this.L = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        this.k0.draw(new Canvas(this.L));
        if (this.M == null) {
            this.M = new Paint(3);
        }
    }

    private float r(int i, int i2) {
        if (i2 == 17 || (i2 & 7) == 1) {
            return (i / 2.0f) - (this.l0 / 2.0f);
        }
        if ((i2 & 8388613) == 8388613 || (i2 & 5) == 5) {
            return this.I ? this.h.left : this.h.right - this.l0;
        }
        return this.I ? this.h.right - this.l0 : this.h.left;
    }

    private float s(RectF rectF, int i, int i2) {
        if (i2 == 17 || (i2 & 7) == 1) {
            return (i / 2.0f) + (this.l0 / 2.0f);
        }
        if ((i2 & 8388613) == 8388613 || (i2 & 5) == 5) {
            return this.I ? rectF.left + this.l0 : this.h.right;
        }
        return this.I ? this.h.right : rectF.left + this.l0;
    }

    private int u(ColorStateList colorStateList) {
        if (colorStateList == null) {
            return 0;
        }
        int[] iArr = this.T;
        return iArr != null ? colorStateList.getColorForState(iArr, 0) : colorStateList.getDefaultColor();
    }

    private int v() {
        return u(this.n);
    }

    private Layout.Alignment y() {
        int iB = C5244t.b(this.j, this.I ? 1 : 0) & 7;
        if (iB == 1) {
            return Layout.Alignment.ALIGN_CENTER;
        }
        if (iB != 5) {
            return this.I ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
        }
        return this.I ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_OPPOSITE;
    }

    private void z(TextPaint textPaint) {
        textPaint.setTextSize(this.m);
        textPaint.setTypeface(this.w);
        textPaint.setLetterSpacing(this.h0);
    }

    public final boolean E() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2 = this.o;
        return (colorStateList2 != null && colorStateList2.isStateful()) || ((colorStateList = this.n) != null && colorStateList.isStateful());
    }

    public void H(Configuration configuration) {
        if (Build.VERSION.SDK_INT >= 31) {
            Typeface typeface = this.y;
            if (typeface != null) {
                this.x = ax.E6.j.b(configuration, typeface);
            }
            Typeface typeface2 = this.B;
            if (typeface2 != null) {
                this.A = ax.E6.j.b(configuration, typeface2);
            }
            Typeface typeface3 = this.x;
            if (typeface3 == null) {
                typeface3 = this.y;
            }
            this.w = typeface3;
            Typeface typeface4 = this.A;
            if (typeface4 == null) {
                typeface4 = this.B;
            }
            this.z = typeface4;
            K(true);
        }
    }

    public void J() {
        K(false);
    }

    public void K(boolean z) {
        if ((this.a.getHeight() <= 0 || this.a.getWidth() <= 0) && !z) {
            return;
        }
        b(z);
        c();
    }

    public void M(ColorStateList colorStateList) {
        if (this.o == colorStateList && this.n == colorStateList) {
            return;
        }
        this.o = colorStateList;
        this.n = colorStateList;
        J();
    }

    public void N(int i, int i2, int i3, int i4) {
        if (L(this.h, i, i2, i3, i4)) {
            return;
        }
        this.h.set(i, i2, i3, i4);
        this.U = true;
    }

    public void O(Rect rect) {
        N(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void P(int i) {
        ax.E6.d dVar = new ax.E6.d(this.a.getContext(), i);
        if (dVar.i() != null) {
            this.o = dVar.i();
        }
        if (dVar.j() != 0.0f) {
            this.m = dVar.j();
        }
        ColorStateList colorStateList = dVar.c;
        if (colorStateList != null) {
            this.c0 = colorStateList;
        }
        this.a0 = dVar.h;
        this.b0 = dVar.i;
        this.Z = dVar.j;
        this.h0 = dVar.l;
        ax.E6.a aVar = this.E;
        if (aVar != null) {
            aVar.c();
        }
        this.E = new ax.E6.a(new C0055a(), dVar.e());
        dVar.h(this.a.getContext(), this.E);
        J();
    }

    public void R(ColorStateList colorStateList) {
        if (this.o != colorStateList) {
            this.o = colorStateList;
            J();
        }
    }

    public void S(int i) {
        if (this.k != i) {
            this.k = i;
            J();
        }
    }

    public void T(Typeface typeface) {
        if (U(typeface)) {
            J();
        }
    }

    public void V(int i, int i2, int i3, int i4) {
        if (L(this.g, i, i2, i3, i4)) {
            return;
        }
        this.g.set(i, i2, i3, i4);
        this.U = true;
    }

    public void W(Rect rect) {
        V(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void X(float f) {
        if (this.i0 != f) {
            this.i0 = f;
            J();
        }
    }

    public void Z(int i) {
        if (this.j != i) {
            this.j = i;
            J();
        }
    }

    public void a0(float f) {
        if (this.l != f) {
            this.l = f;
            J();
        }
    }

    public void c0(float f) {
        float fA = ax.V.a.a(f, 0.0f, 1.0f);
        if (fA != this.b) {
            this.b = fA;
            c();
        }
    }

    public void e0(TimeInterpolator timeInterpolator) {
        this.X = timeInterpolator;
        J();
    }

    public final boolean f0(int[] iArr) {
        this.T = iArr;
        if (!E()) {
            return false;
        }
        J();
        return true;
    }

    public void g0(CharSequence charSequence) {
        if (charSequence == null || !TextUtils.equals(this.G, charSequence)) {
            this.G = charSequence;
            this.H = null;
            j();
            J();
        }
    }

    public void h0(TimeInterpolator timeInterpolator) {
        this.Y = timeInterpolator;
        J();
    }

    public void i0(Typeface typeface) {
        boolean zU = U(typeface);
        boolean zB0 = b0(typeface);
        if (zU || zB0) {
            J();
        }
    }

    public void l(Canvas canvas) {
        int iSave = canvas.save();
        if (this.H == null || this.i.width() <= 0.0f || this.i.height() <= 0.0f) {
            return;
        }
        this.V.setTextSize(this.O);
        float f = this.u;
        float f2 = this.v;
        boolean z = this.K && this.L != null;
        float f3 = this.N;
        if (f3 != 1.0f && !this.c) {
            canvas.scale(f3, f3, f, f2);
        }
        if (z) {
            canvas.drawBitmap(this.L, f, f2, this.M);
            canvas.restoreToCount(iSave);
            return;
        }
        if (!j0() || (this.c && this.b <= this.e)) {
            canvas.translate(f, f2);
            this.k0.draw(canvas);
        } else {
            m(canvas, this.u - this.k0.getLineStart(0), f2);
        }
        canvas.restoreToCount(iSave);
    }

    public void o(RectF rectF, int i, int i2) {
        this.I = f(this.G);
        rectF.left = Math.max(r(i, i2), this.h.left);
        rectF.top = this.h.top;
        rectF.right = Math.min(s(rectF, i, i2), this.h.right);
        rectF.bottom = this.h.top + q();
    }

    public ColorStateList p() {
        return this.o;
    }

    public float q() {
        z(this.W);
        return -this.W.ascent();
    }

    public int t() {
        return u(this.o);
    }

    public float w() {
        A(this.W);
        return -this.W.ascent();
    }

    public float x() {
        return this.b;
    }
}
