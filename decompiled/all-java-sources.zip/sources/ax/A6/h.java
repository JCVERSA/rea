package ax.A6;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import ax.P5.C1452Re;

/* JADX INFO: loaded from: classes2.dex */
public class h extends androidx.appcompat.widget.B {
    boolean A0;
    private Drawable v0;
    private final Rect w0;
    private final Rect x0;
    private int y0;
    protected boolean z0;

    public h(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        Drawable drawable = this.v0;
        if (drawable != null) {
            if (this.A0) {
                this.A0 = false;
                Rect rect = this.w0;
                Rect rect2 = this.x0;
                int right = getRight() - getLeft();
                int bottom = getBottom() - getTop();
                if (this.z0) {
                    rect.set(0, 0, right, bottom);
                } else {
                    rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
                }
                Gravity.apply(this.y0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2);
                drawable.setBounds(rect2);
            }
            drawable.draw(canvas);
        }
    }

    @Override // android.view.View
    @TargetApi(C1452Re.zzm)
    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.v0;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.v0;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        this.v0.setState(getDrawableState());
    }

    @Override // android.view.View
    public Drawable getForeground() {
        return this.v0;
    }

    @Override // android.view.View
    public int getForegroundGravity() {
        return this.y0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.v0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // androidx.appcompat.widget.B, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.A0 = z | this.A0;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.A0 = true;
    }

    @Override // android.view.View
    public void setForeground(Drawable drawable) {
        Drawable drawable2 = this.v0;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
                unscheduleDrawable(this.v0);
            }
            this.v0 = drawable;
            this.A0 = true;
            if (drawable != null) {
                setWillNotDraw(false);
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    drawable.setState(getDrawableState());
                }
                if (this.y0 == 119) {
                    drawable.getPadding(new Rect());
                }
            } else {
                setWillNotDraw(true);
            }
            requestLayout();
            invalidate();
        }
    }

    @Override // android.view.View
    public void setForegroundGravity(int i) {
        if (this.y0 != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.y0 = i;
            if (i == 119 && this.v0 != null) {
                this.v0.getPadding(new Rect());
            }
            requestLayout();
        }
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.v0;
    }

    public h(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.w0 = new Rect();
        this.x0 = new Rect();
        this.y0 = 119;
        this.z0 = true;
        this.A0 = false;
        TypedArray typedArrayI = x.i(context, attributeSet, ax.p105h6.l.b2, i, 0, new int[0]);
        this.y0 = typedArrayI.getInt(ax.p105h6.l.d2, this.y0);
        Drawable drawable = typedArrayI.getDrawable(ax.p105h6.l.c2);
        if (drawable != null) {
            setForeground(drawable);
        }
        this.z0 = typedArrayI.getBoolean(ax.p105h6.l.e2, true);
        typedArrayI.recycle();
    }
}
