package ax.A6;

/* JADX INFO: loaded from: classes3.dex */
public interface h {
}
