package ax.A6;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: classes3.dex */
public final class d extends a implements f {
    d(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
    }

    @Override // ax.A6.f
    public final String c() throws RemoteException {
        Parcel parcelP0 = P0(1, M0());
        String string = parcelP0.readString();
        parcelP0.recycle();
        return string;
    }

    @Override // ax.A6.f
    public final boolean f() throws RemoteException {
        Parcel parcelP0 = P0(6, M0());
        boolean zB = c.b(parcelP0);
        parcelP0.recycle();
        return zB;
    }

    @Override // ax.A6.f
    public final boolean j2(boolean z) throws RemoteException {
        Parcel parcelM0 = M0();
        c.a(parcelM0, true);
        Parcel parcelP0 = P0(2, parcelM0);
        boolean zB = c.b(parcelP0);
        parcelP0.recycle();
        return zB;
    }
}
