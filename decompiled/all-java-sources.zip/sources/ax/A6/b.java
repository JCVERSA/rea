package ax.A6;

import android.os.Binder;
import android.os.IInterface;

/* JADX INFO: loaded from: classes3.dex */
public class b extends Binder implements IInterface {
}
