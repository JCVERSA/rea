package ax.A2;

import android.graphics.Bitmap;

/* JADX INFO: loaded from: classes.dex */
interface l {
    Bitmap a();

    String b(int i, int i2, Bitmap.Config config);

    void c(Bitmap bitmap);

    Bitmap d(int i, int i2, Bitmap.Config config);

    int e(Bitmap bitmap);

    String f(Bitmap bitmap);
}
