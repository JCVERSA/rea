package ax.A2;

import ax.B2.w;

/* JADX INFO: loaded from: classes.dex */
public class f {
    public static boolean a(String str) {
        return w.b(str);
    }
}
