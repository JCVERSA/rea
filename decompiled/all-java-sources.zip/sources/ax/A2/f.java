package ax.A2;

/* JADX INFO: loaded from: classes.dex */
public final class f implements a<byte[]> {
    @Override // ax.A2.a
    public int a() {
        return 1;
    }

    @Override // ax.A2.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public int b(byte[] bArr) {
        return bArr.length;
    }

    @Override // ax.A2.a
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public byte[] newArray(int i) {
        return new byte[i];
    }

    @Override // ax.A2.a
    public String g0() {
        return "ByteArrayPool";
    }
}
