package ax.A2;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class k implements d {
    private static final Bitmap.Config k = Bitmap.Config.ARGB_8888;
    private final l a;
    private final Set<Bitmap.Config> b;
    private final int c;
    private final a d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;

    private interface a {
        void a(Bitmap bitmap);

        void b(Bitmap bitmap);
    }

    k(int i, l lVar, Set<Bitmap.Config> set) {
        this.c = i;
        this.e = i;
        this.a = lVar;
        this.b = set;
        this.d = new b();
    }

    @TargetApi(26)
    private static void f(Bitmap.Config config) {
        if (Build.VERSION.SDK_INT >= 26 && config == Bitmap.Config.HARDWARE) {
            throw new IllegalArgumentException("Cannot create a mutable Bitmap with config: " + config + ". Consider setting Downsampler#ALLOW_HARDWARE_CONFIG to false in your RequestOptions and/or in GlideBuilder.setDefaultRequestOptions");
        }
    }

    private void g() {
        if (Log.isLoggable("LruBitmapPool", 2)) {
            h();
        }
    }

    private void h() {
        Log.v("LruBitmapPool", "Hits=" + this.g + ", misses=" + this.h + ", puts=" + this.i + ", evictions=" + this.j + ", currentSize=" + this.f + ", maxSize=" + this.e + "\nStrategy=" + this.a);
    }

    private void i() {
        o(this.e);
    }

    @TargetApi(26)
    private static Set<Bitmap.Config> j() {
        HashSet hashSet = new HashSet();
        hashSet.addAll(Arrays.asList(Bitmap.Config.values()));
        int i = Build.VERSION.SDK_INT;
        hashSet.add(null);
        if (i >= 26) {
            hashSet.remove(Bitmap.Config.HARDWARE);
        }
        return Collections.unmodifiableSet(hashSet);
    }

    private static l k() {
        return new n();
    }

    private synchronized Bitmap l(int i, int i2, Bitmap.Config config) {
        Bitmap bitmapD;
        try {
            f(config);
            bitmapD = this.a.d(i, i2, config != null ? config : k);
            if (bitmapD == null) {
                if (Log.isLoggable("LruBitmapPool", 3)) {
                    Log.d("LruBitmapPool", "Missing bitmap=" + this.a.b(i, i2, config));
                }
                this.h++;
            } else {
                this.g++;
                this.f -= this.a.e(bitmapD);
                this.d.a(bitmapD);
                n(bitmapD);
            }
            if (Log.isLoggable("LruBitmapPool", 2)) {
                Log.v("LruBitmapPool", "Get bitmap=" + this.a.b(i, i2, config));
            }
            g();
        } catch (Throwable th) {
            throw th;
        }
        return bitmapD;
    }

    @TargetApi(19)
    private static void m(Bitmap bitmap) {
        bitmap.setPremultiplied(true);
    }

    private static void n(Bitmap bitmap) {
        bitmap.setHasAlpha(true);
        m(bitmap);
    }

    private synchronized void o(int i) {
        while (this.f > i) {
            try {
                Bitmap bitmapA = this.a.a();
                if (bitmapA == null) {
                    if (Log.isLoggable("LruBitmapPool", 5)) {
                        Log.w("LruBitmapPool", "Size mismatch, resetting");
                        h();
                    }
                    this.f = 0;
                    return;
                }
                this.d.a(bitmapA);
                this.f -= this.a.e(bitmapA);
                this.j++;
                if (Log.isLoggable("LruBitmapPool", 3)) {
                    Log.d("LruBitmapPool", "Evicting bitmap=" + this.a.f(bitmapA));
                }
                g();
                bitmapA.recycle();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // ax.A2.d
    @SuppressLint({"InlinedApi"})
    public void a(int i) {
        if (Log.isLoggable("LruBitmapPool", 3)) {
            Log.d("LruBitmapPool", "trimMemory, level=" + i);
        }
        if (i >= 40) {
            b();
        } else if (i >= 20) {
            o(this.e / 2);
        }
    }

    @Override // ax.A2.d
    public void b() {
        if (Log.isLoggable("LruBitmapPool", 3)) {
            Log.d("LruBitmapPool", "clearMemory");
        }
        o(0);
    }

    @Override // ax.A2.d
    public synchronized void c(Bitmap bitmap) {
        try {
            if (bitmap == null) {
                throw new NullPointerException("Bitmap must not be null");
            }
            if (bitmap.isRecycled()) {
                throw new IllegalStateException("Cannot pool recycled bitmap");
            }
            if (bitmap.isMutable() && this.a.e(bitmap) <= this.e && this.b.contains(bitmap.getConfig())) {
                int iE = this.a.e(bitmap);
                this.a.c(bitmap);
                this.d.b(bitmap);
                this.i++;
                this.f += iE;
                if (Log.isLoggable("LruBitmapPool", 2)) {
                    Log.v("LruBitmapPool", "Put bitmap in pool=" + this.a.f(bitmap));
                }
                g();
                i();
                return;
            }
            if (Log.isLoggable("LruBitmapPool", 2)) {
                Log.v("LruBitmapPool", "Reject bitmap from pool, bitmap: " + this.a.f(bitmap) + ", is mutable: " + bitmap.isMutable() + ", is allowed config: " + this.b.contains(bitmap.getConfig()));
            }
            bitmap.recycle();
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // ax.A2.d
    public Bitmap d(int i, int i2, Bitmap.Config config) {
        Bitmap bitmapL = l(i, i2, config);
        if (bitmapL == null) {
            return Bitmap.createBitmap(i, i2, config);
        }
        bitmapL.eraseColor(0);
        return bitmapL;
    }

    @Override // ax.A2.d
    public Bitmap e(int i, int i2, Bitmap.Config config) {
        Bitmap bitmapL = l(i, i2, config);
        return bitmapL == null ? Bitmap.createBitmap(i, i2, config) : bitmapL;
    }

    public k(int i) {
        this(i, k(), j());
    }

    private static class b implements a {
        b() {
        }

        @Override // ax.A2.k.a
        public void a(Bitmap bitmap) {
        }

        @Override // ax.A2.k.a
        public void b(Bitmap bitmap) {
        }
    }
}
