package ax.A2;

/* JADX INFO: loaded from: classes.dex */
public interface a<T> {
    int a();

    int b(T t);

    String g0();

    T newArray(int i);
}
