package ax.A2;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
}
