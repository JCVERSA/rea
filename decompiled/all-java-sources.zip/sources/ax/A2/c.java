package ax.A2;

import j$.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class c {
    private final d[] a;
    private final String b;
    private final byte[] c;
    private final int d;

    public c(String str, d[] dVarArr) {
        this.b = str;
        this.c = null;
        this.a = dVarArr;
        this.d = 0;
    }

    public c(byte[] bArr, d[] dVarArr) {
        Objects.requireNonNull(bArr);
        this.c = bArr;
        this.b = null;
        this.a = dVarArr;
        this.d = 1;
    }

    private void a(int i) {
        if (i == this.d) {
            return;
        }
        throw new IllegalStateException("Wrong data accessor type detected. " + c(this.d) + " expected, but got " + c(i));
    }

    private String c(int i) {
        if (i != 0) {
            return i != 1 ? "Unknown" : "ArrayBuffer";
        }
        return "String";
    }

    public String b() {
        a(0);
        return this.b;
    }
}
