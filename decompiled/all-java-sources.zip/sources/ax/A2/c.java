package ax.A2;

import ax.A2.m;
import java.util.Queue;

/* JADX INFO: loaded from: classes.dex */
abstract class c<T extends m> {
    private final Queue<T> a = ax.U2.i.e(20);

    c() {
    }

    protected abstract T a();

    protected T b() {
        T tPoll = this.a.poll();
        return tPoll == null ? (T) a() : tPoll;
    }

    public void c(T t) {
        if (this.a.size() < 20) {
            this.a.offer(t);
        }
    }
}
