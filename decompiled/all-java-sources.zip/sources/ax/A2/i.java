package ax.A2;

import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class i implements ax.A2.b {
    private final g<a, Object> a = new g<>();
    private final b b = new b();
    private final Map<Class<?>, NavigableMap<Integer, Integer>> c = new HashMap();
    private final Map<Class<?>, ax.A2.a<?>> d = new HashMap();
    private final int e;
    private int f;

    private static final class a implements m {
        private final b a;
        int b;
        private Class<?> c;

        a(b bVar) {
            this.a = bVar;
        }

        @Override // ax.A2.m
        public void a() {
            this.a.c(this);
        }

        void b(int i, Class<?> cls) {
            this.b = i;
            this.c = cls;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.b == aVar.b && this.c == aVar.c;
        }

        public int hashCode() {
            int i = this.b * 31;
            Class<?> cls = this.c;
            return i + (cls != null ? cls.hashCode() : 0);
        }

        public String toString() {
            return "Key{size=" + this.b + "array=" + this.c + '}';
        }
    }

    private static final class b extends c<a> {
        b() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // ax.A2.c
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public a a() {
            return new a(this);
        }

        a e(int i, Class<?> cls) {
            a aVarB = b();
            aVarB.b(i, cls);
            return aVarB;
        }
    }

    public i(int i) {
        this.e = i;
    }

    private void e(int i, Class<?> cls) {
        NavigableMap<Integer, Integer> navigableMapK = k(cls);
        Integer num = navigableMapK.get(Integer.valueOf(i));
        if (num != null) {
            if (num.intValue() == 1) {
                navigableMapK.remove(Integer.valueOf(i));
                return;
            } else {
                navigableMapK.put(Integer.valueOf(i), Integer.valueOf(num.intValue() - 1));
                return;
            }
        }
        throw new NullPointerException("Tried to decrement empty size, size: " + i + ", this: " + this);
    }

    private void f() {
        g(this.e);
    }

    private void g(int i) {
        while (this.f > i) {
            Object objF = this.a.f();
            ax.U2.h.d(objF);
            ax.A2.a aVarH = h(objF);
            this.f -= aVarH.b(objF) * aVarH.a();
            e(aVarH.b(objF), objF.getClass());
            if (Log.isLoggable(aVarH.g0(), 2)) {
                Log.v(aVarH.g0(), "evicted: " + aVarH.b(objF));
            }
        }
    }

    private <T> ax.A2.a<T> h(T t) {
        return i(t.getClass());
    }

    private <T> ax.A2.a<T> i(Class<T> cls) {
        ax.A2.a<T> fVar = (ax.A2.a) this.d.get(cls);
        if (fVar == null) {
            if (cls.equals(int[].class)) {
                fVar = new h();
            } else {
                if (!cls.equals(byte[].class)) {
                    throw new IllegalArgumentException("No array pool found for: " + cls.getSimpleName());
                }
                fVar = new f();
            }
            this.d.put(cls, fVar);
        }
        return fVar;
    }

    private <T> T j(a aVar) {
        return (T) this.a.a(aVar);
    }

    private NavigableMap<Integer, Integer> k(Class<?> cls) {
        NavigableMap<Integer, Integer> navigableMap = this.c.get(cls);
        if (navigableMap != null) {
            return navigableMap;
        }
        TreeMap treeMap = new TreeMap();
        this.c.put(cls, treeMap);
        return treeMap;
    }

    private boolean l() {
        int i = this.f;
        return i == 0 || this.e / i >= 2;
    }

    private boolean m(int i) {
        return i <= this.e / 2;
    }

    private boolean n(int i, Integer num) {
        return num != null && (l() || num.intValue() <= i * 8);
    }

    @Override // ax.A2.b
    public synchronized void a(int i) {
        try {
            if (i >= 40) {
                b();
            } else if (i >= 20) {
                g(this.e / 2);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // ax.A2.b
    public synchronized void b() {
        g(0);
    }

    @Override // ax.A2.b
    public synchronized <T> void c(T t, Class<T> cls) {
        ax.A2.a<T> aVarI = i(cls);
        int iB = aVarI.b(t);
        int iA = aVarI.a() * iB;
        if (m(iA)) {
            a aVarE = this.b.e(iB, cls);
            this.a.d(aVarE, t);
            NavigableMap<Integer, Integer> navigableMapK = k(cls);
            Integer num = navigableMapK.get(Integer.valueOf(aVarE.b));
            Integer numValueOf = Integer.valueOf(aVarE.b);
            int iIntValue = 1;
            if (num != null) {
                iIntValue = 1 + num.intValue();
            }
            navigableMapK.put(numValueOf, Integer.valueOf(iIntValue));
            this.f += iA;
            f();
        }
    }

    @Override // ax.A2.b
    public <T> T d(int i, Class<T> cls) {
        T t;
        ax.A2.a<T> aVarI = i(cls);
        synchronized (this) {
            try {
                Integer numCeilingKey = k(cls).ceilingKey(Integer.valueOf(i));
                t = (T) j(n(i, numCeilingKey) ? this.b.e(numCeilingKey.intValue(), cls) : this.b.e(i, cls));
                if (t != null) {
                    this.f -= aVarI.b(t) * aVarI.a();
                    e(aVarI.b(t), cls);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (t != null) {
            return t;
        }
        if (Log.isLoggable(aVarI.g0(), 2)) {
            Log.v(aVarI.g0(), "Allocated " + i + " bytes");
        }
        return aVarI.newArray(i);
    }
}
