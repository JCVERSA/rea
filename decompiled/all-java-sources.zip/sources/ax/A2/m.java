package ax.A2;

/* JADX INFO: loaded from: classes.dex */
interface m {
    void a();
}
