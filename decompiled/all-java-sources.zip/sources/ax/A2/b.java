package ax.A2;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    void a(int i);

    void b();

    <T> void c(T t, Class<T> cls);

    <T> T d(int i, Class<T> cls);
}
