package ax.A2;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import ax.B2.AbstractC0673a;
import ax.B2.g;
import ax.B2.w;
import ax.B2.x;
import ax.B2.y;
import ax.B2.z;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;
import okhttp3.HttpUrl;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;

/* JADX INFO: loaded from: classes.dex */
public class e {
    private static final Uri a = Uri.parse("*");
    private static final Uri b = Uri.parse(HttpUrl.FRAGMENT_ENCODE_SET);

    public interface a {
        void a(WebView webView, c cVar, Uri uri, boolean z, ax.A2.a aVar);
    }

    public static void a(WebView webView, String str, Set<String> set, a aVar) {
        if (!w.U.c()) {
            throw w.a();
        }
        f(webView).a(str, (String[]) set.toArray(new String[0]), aVar);
    }

    private static WebViewProviderBoundaryInterface b(WebView webView) {
        return d().createWebView(webView);
    }

    public static PackageInfo c() {
        if (Build.VERSION.SDK_INT >= 26) {
            return g.a();
        }
        try {
            return e();
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            return null;
        }
    }

    private static z d() {
        return x.c();
    }

    @SuppressLint({"PrivateApi"})
    private static PackageInfo e() throws IllegalAccessException, NoSuchMethodException, ClassNotFoundException, InvocationTargetException {
        return (PackageInfo) Class.forName("android.webkit.WebViewFactory").getMethod("getLoadedPackageInfo", null).invoke(null, null);
    }

    private static y f(WebView webView) {
        return new y(b(webView));
    }

    public static WebViewClient g(WebView webView) {
        AbstractC0673a.e eVar = w.H;
        if (eVar.b()) {
            return g.d(webView);
        }
        if (eVar.c()) {
            return f(webView).b();
        }
        throw w.a();
    }

    public static boolean h() {
        if (w.R.c()) {
            return d().getStatics().isMultiProcessEnabled();
        }
        throw w.a();
    }

    public static void i(WebView webView, String str) {
        if (!w.U.c()) {
            throw w.a();
        }
        f(webView).c(str);
    }

    public static void j(WebView webView, boolean z) {
        if (!w.f0.c()) {
            throw w.a();
        }
        f(webView).d(z);
    }
}
