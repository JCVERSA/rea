package ax.A2;

import android.graphics.Bitmap;

/* JADX INFO: loaded from: classes.dex */
public class e implements d {
    @Override // ax.A2.d
    public void c(Bitmap bitmap) {
        bitmap.recycle();
    }

    @Override // ax.A2.d
    public Bitmap d(int i, int i2, Bitmap.Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    @Override // ax.A2.d
    public Bitmap e(int i, int i2, Bitmap.Config config) {
        return d(i, i2, config);
    }

    @Override // ax.A2.d
    public void b() {
    }

    @Override // ax.A2.d
    public void a(int i) {
    }
}
