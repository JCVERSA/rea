package ax.A2;

/* JADX INFO: loaded from: classes.dex */
public final class h implements a<int[]> {
    @Override // ax.A2.a
    public int a() {
        return 4;
    }

    @Override // ax.A2.a
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public int b(int[] iArr) {
        return iArr.length;
    }

    @Override // ax.A2.a
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public int[] newArray(int i) {
        return new int[i];
    }

    @Override // ax.A2.a
    public String g0() {
        return "IntegerArrayPool";
    }
}
