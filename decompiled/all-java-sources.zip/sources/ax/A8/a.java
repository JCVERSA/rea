package ax.A8;

/* JADX INFO: loaded from: classes2.dex */
public class a extends ax.p094g9.b {
    public a(long j, String str) {
        super(j, str);
    }

    public a(Throwable th) {
        super(th);
    }
}
