package ax.A8;

/* JADX INFO: loaded from: classes3.dex */
public interface a {
}
