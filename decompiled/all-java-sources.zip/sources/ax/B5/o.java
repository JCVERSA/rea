package ax.B5;

import android.content.Context;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.C5852c;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class o {
    private static final ax.J5.a a = new ax.J5.a("GoogleSignInCommon", new String[0]);

    public static ax.E5.h a(ax.E5.g gVar, Context context, boolean z) {
        a.a("Revoking access", new Object[0]);
        String strE = c.b(context).e();
        c(context);
        return z ? f.a(strE) : gVar.a(new m(gVar));
    }

    public static ax.E5.h b(ax.E5.g gVar, Context context, boolean z) {
        a.a("Signing out", new Object[0]);
        c(context);
        return z ? ax.E5.i.b(Status.i0, gVar) : gVar.a(new k(gVar));
    }

    private static void c(Context context) {
        p.a(context).b();
        Iterator<ax.E5.g> it = ax.E5.g.b().iterator();
        while (it.hasNext()) {
            it.next().e();
        }
        C5852c.a();
    }
}
