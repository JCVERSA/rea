package ax.B5;

import com.google.android.gms.common.api.internal.AbstractC5851b;

/* JADX INFO: loaded from: classes.dex */
abstract class n extends AbstractC5851b {
    public n(ax.E5.g gVar) {
        super(ax.p342y5.a.b, gVar);
    }
}
