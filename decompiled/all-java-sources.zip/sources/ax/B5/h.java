package ax.B5;

/* JADX INFO: loaded from: classes.dex */
public final class h implements ax.A5.a {
}
