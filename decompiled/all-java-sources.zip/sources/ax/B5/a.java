package ax.B5;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class a extends ax.H5.a {
    public static final Parcelable.Creator<a> CREATOR = new d();
    private int X;
    private Bundle Y;
    final int q;

    a(int i, int i2, Bundle bundle) {
        this.q = i;
        this.X = i2;
        this.Y = bundle;
    }

    public int p() {
        return this.X;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int iA = ax.H5.c.a(parcel);
        ax.H5.c.k(parcel, 1, this.q);
        ax.H5.c.k(parcel, 2, p());
        ax.H5.c.e(parcel, 3, this.Y, false);
        ax.H5.c.b(parcel, iA);
    }
}
