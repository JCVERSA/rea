package ax.B5;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import ax.G5.AbstractC0669g;
import ax.G5.C0666d;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class i extends AbstractC0669g {
    private final GoogleSignInOptions L0;

    public i(Context context, Looper looper, C0666d c0666d, GoogleSignInOptions googleSignInOptions, ax.E5.g.a aVar, ax.E5.g.b bVar) {
        super(context, looper, 91, c0666d, aVar, bVar);
        GoogleSignInOptions.a aVar2 = googleSignInOptions != null ? new GoogleSignInOptions.a(googleSignInOptions) : new GoogleSignInOptions.a();
        aVar2.e(ax.T5.b.a());
        if (!c0666d.d().isEmpty()) {
            Iterator<Scope> it = c0666d.d().iterator();
            while (it.hasNext()) {
                aVar2.d(it.next(), new Scope[0]);
            }
        }
        this.L0 = aVar2.a();
    }

    @Override // ax.G5.AbstractC0665c
    protected final String E() {
        return "com.google.android.gms.auth.api.signin.internal.ISignInService";
    }

    @Override // ax.G5.AbstractC0665c
    protected final String F() {
        return "com.google.android.gms.auth.api.signin.service.START";
    }

    @Override // ax.G5.AbstractC0665c, ax.E5.a.f
    public final int j() {
        return 12451000;
    }

    public final GoogleSignInOptions m0() {
        return this.L0;
    }

    @Override // ax.G5.AbstractC0665c
    protected final /* synthetic */ IInterface s(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.api.signin.internal.ISignInService");
        return iInterfaceQueryLocalInterface instanceof u ? (u) iInterfaceQueryLocalInterface : new u(iBinder);
    }
}
