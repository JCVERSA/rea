package ax.B5;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import ax.G5.C0678p;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class c {
    private static final Lock c = new ReentrantLock();
    private static c d;
    private final Lock a = new ReentrantLock();
    private final SharedPreferences b;

    c(Context context) {
        this.b = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    public static c b(Context context) {
        C0678p.l(context);
        c.lock();
        try {
            if (d == null) {
                d = new c(context.getApplicationContext());
            }
            return d;
        } finally {
            c.unlock();
        }
    }

    private static final String i(String str, String str2) {
        return str + ":" + str2;
    }

    public void a() {
        this.a.lock();
        try {
            this.b.edit().clear().apply();
        } finally {
            this.a.unlock();
        }
    }

    public GoogleSignInAccount c() {
        String strG;
        String strG2 = g("defaultGoogleSignInAccount");
        if (TextUtils.isEmpty(strG2) || (strG = g(i("googleSignInAccount", strG2))) == null) {
            return null;
        }
        try {
            return GoogleSignInAccount.S(strG);
        } catch (JSONException unused) {
            return null;
        }
    }

    public GoogleSignInOptions d() {
        String strG;
        String strG2 = g("defaultGoogleSignInAccount");
        if (TextUtils.isEmpty(strG2) || (strG = g(i("googleSignInOptions", strG2))) == null) {
            return null;
        }
        try {
            return GoogleSignInOptions.P(strG);
        } catch (JSONException unused) {
            return null;
        }
    }

    public String e() {
        return g("refreshToken");
    }

    public void f(GoogleSignInAccount googleSignInAccount, GoogleSignInOptions googleSignInOptions) {
        C0678p.l(googleSignInAccount);
        C0678p.l(googleSignInOptions);
        h("defaultGoogleSignInAccount", googleSignInAccount.T());
        C0678p.l(googleSignInAccount);
        C0678p.l(googleSignInOptions);
        String strT = googleSignInAccount.T();
        h(i("googleSignInAccount", strT), googleSignInAccount.U());
        h(i("googleSignInOptions", strT), googleSignInOptions.U());
    }

    protected final String g(String str) {
        this.a.lock();
        try {
            return this.b.getString(str, null);
        } finally {
            this.a.unlock();
        }
    }

    protected final void h(String str, String str2) {
        this.a.lock();
        try {
            this.b.edit().putString(str, str2).apply();
        } finally {
            this.a.unlock();
        }
    }
}
