package ax.B5;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
public class e extends s {
    @Override // ax.B5.t
    public void M4(Status status) throws RemoteException {
        throw new UnsupportedOperationException();
    }

    @Override // ax.B5.t
    public void h4(Status status) throws RemoteException {
        throw new UnsupportedOperationException();
    }

    @Override // ax.B5.t
    public void j4(GoogleSignInAccount googleSignInAccount, Status status) throws RemoteException {
        throw new UnsupportedOperationException();
    }
}
