package ax.B5;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
final class l extends e {
    final /* synthetic */ m q;

    l(m mVar) {
        this.q = mVar;
    }

    @Override // ax.B5.e, ax.B5.t
    public final void h4(Status status) throws RemoteException {
        this.q.f(status);
    }
}
