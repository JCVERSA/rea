package ax.B5;

import ax.G5.C0678p;
import com.google.android.gms.common.api.Status;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/* JADX INFO: loaded from: classes.dex */
public final class f implements Runnable {
    private static final ax.J5.a Y = new ax.J5.a("RevokeAccessOperation", new String[0]);
    private final ax.F5.m X = new ax.F5.m(null);
    private final String q;

    public f(String str) {
        this.q = C0678p.f(str);
    }

    public static ax.E5.h a(String str) {
        if (str == null) {
            return ax.E5.i.a(new Status(4), null);
        }
        f fVar = new f(str);
        new Thread(fVar).start();
        return fVar.X;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Status status = Status.k0;
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://accounts.google.com/o/oauth2/revoke?token=" + this.q).openConnection();
            httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == 200) {
                status = Status.i0;
            } else {
                Y.b("Unable to revoke access!", new Object[0]);
            }
            Y.a("Response Code: " + responseCode, new Object[0]);
        } catch (IOException e) {
            Y.b("IOException when revoking access: ".concat(String.valueOf(e.toString())), new Object[0]);
        } catch (Exception e2) {
            Y.b("Exception when revoking access: ".concat(String.valueOf(e2.toString())), new Object[0]);
        }
        this.X.f(status);
    }
}
