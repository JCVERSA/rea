package ax.B5;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
final class k extends n {
    k(ax.E5.g gVar) {
        super(gVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.google.android.gms.common.api.internal.AbstractC5851b
    protected final /* bridge */ /* synthetic */ void l(ax.E5.a.b bVar) throws RemoteException {
        i iVar = (i) bVar;
        ((u) iVar.D()).Y2(new j(this), iVar.m0());
    }

    @Override // com.google.android.gms.common.api.internal.BasePendingResult
    protected final /* bridge */ /* synthetic */ ax.E5.l c(Status status) {
        return status;
    }
}
