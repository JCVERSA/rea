package ax.B5;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* JADX INFO: loaded from: classes.dex */
final class j extends e {
    final /* synthetic */ k q;

    j(k kVar) {
        this.q = kVar;
    }

    @Override // ax.B5.e, ax.B5.t
    public final void M4(Status status) throws RemoteException {
        this.q.f(status);
    }
}
