package ax.B5;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class d implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iY = ax.H5.b.y(parcel);
        Bundle bundleA = null;
        int iT = 0;
        int iT2 = 0;
        while (parcel.dataPosition() < iY) {
            int iR = ax.H5.b.r(parcel);
            int iL = ax.H5.b.l(iR);
            if (iL == 1) {
                iT = ax.H5.b.t(parcel, iR);
            } else if (iL == 2) {
                iT2 = ax.H5.b.t(parcel, iR);
            } else if (iL != 3) {
                ax.H5.b.x(parcel, iR);
            } else {
                bundleA = ax.H5.b.a(parcel, iR);
            }
        }
        ax.H5.b.k(parcel, iY);
        return new a(iT, iT2, bundleA);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i) {
        return new a[i];
    }
}
