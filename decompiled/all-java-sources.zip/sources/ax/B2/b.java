package ax.B2;

import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public class b implements a {
    @Override // ax.B2.a
    public File b(ax.p311w2.h hVar) {
        return null;
    }

    @Override // ax.B2.a
    public void a(ax.p311w2.h hVar, a.b bVar) {
    }
}
