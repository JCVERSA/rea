package ax.B2;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: loaded from: classes.dex */
final class c {
    private final Map<ax.p311w2.h, a> a = new HashMap();
    private final b b = new b();

    private static class a {
        final Lock a = new ReentrantLock();
        int b;

        a() {
        }
    }

    private static class b {
        private final Queue<a> a = new ArrayDeque();

        b() {
        }

        a a() {
            a aVarPoll;
            synchronized (this.a) {
                aVarPoll = this.a.poll();
            }
            return aVarPoll == null ? new a() : aVarPoll;
        }

        void b(a aVar) {
            synchronized (this.a) {
                try {
                    if (this.a.size() < 10) {
                        this.a.offer(aVar);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    c() {
    }

    void a(ax.p311w2.h hVar) {
        a aVarA;
        synchronized (this) {
            try {
                aVarA = this.a.get(hVar);
                if (aVarA == null) {
                    aVarA = this.b.a();
                    this.a.put(hVar, aVarA);
                }
                aVarA.b++;
            } catch (Throwable th) {
                throw th;
            }
        }
        aVarA.a.lock();
    }

    void b(ax.p311w2.h hVar) {
        a aVar;
        synchronized (this) {
            try {
                aVar = (a) ax.U2.h.d(this.a.get(hVar));
                int i = aVar.b;
                if (i < 1) {
                    throw new IllegalStateException("Cannot release a lock that is not held, key: " + hVar + ", interestedThreads: " + aVar.b);
                }
                int i2 = i - 1;
                aVar.b = i2;
                if (i2 == 0) {
                    a aVarRemove = this.a.remove(hVar);
                    if (!aVarRemove.equals(aVar)) {
                        throw new IllegalStateException("Removed the wrong lock, expected to remove: " + aVar + ", but actually removed: " + aVarRemove + ", key: " + hVar);
                    }
                    this.b.b(aVarRemove);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        aVar.a.unlock();
    }
}
