package ax.B2;

import android.util.Log;
import java.io.File;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public class e implements a {
    private static e f;
    private final File b;
    private final int c;
    private ax.p283u2.a e;
    private final c d = new c();
    private final j a = new j();

    protected e(File file, int i) {
        this.b = file;
        this.c = i;
    }

    public static synchronized a c(File file, int i) {
        try {
            if (f == null) {
                f = new e(file, i);
            }
        } catch (Throwable th) {
            throw th;
        }
        return f;
    }

    private synchronized ax.p283u2.a d() throws IOException {
        try {
            if (this.e == null) {
                this.e = ax.p283u2.a.E(this.b, 1, 1, this.c);
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.e;
    }

    @Override // ax.B2.a
    public void a(ax.p311w2.h hVar, a.b bVar) {
        this.d.a(hVar);
        try {
            String strB = this.a.b(hVar);
            if (Log.isLoggable("DiskLruCacheWrapper", 2)) {
                Log.v("DiskLruCacheWrapper", "Put: Obtained: " + strB + " for for Key: " + hVar);
            }
            try {
                ax.p283u2.a aVarD = d();
                if (aVarD.A(strB) != null) {
                    this.d.b(hVar);
                    return;
                }
                ax.u2.a.c cVarV = aVarD.v(strB);
                if (cVarV == null) {
                    throw new IllegalStateException("Had two simultaneous puts for: " + strB);
                }
                try {
                    if (bVar.a(cVarV.f(0))) {
                        cVarV.e();
                    }
                    cVarV.b();
                    this.d.b(hVar);
                } catch (Throwable th) {
                    cVarV.b();
                    throw th;
                }
            } catch (IOException e) {
                if (Log.isLoggable("DiskLruCacheWrapper", 5)) {
                    Log.w("DiskLruCacheWrapper", "Unable to put to disk cache", e);
                }
            }
        } catch (Throwable th2) {
            this.d.b(hVar);
            throw th2;
        }
    }

    @Override // ax.B2.a
    public File b(ax.p311w2.h hVar) {
        String strB = this.a.b(hVar);
        if (Log.isLoggable("DiskLruCacheWrapper", 2)) {
            Log.v("DiskLruCacheWrapper", "Get: Obtained: " + strB + " for for Key: " + hVar);
        }
        try {
            ax.u2.a.e eVarA = d().A(strB);
            if (eVarA != null) {
                return eVarA.a(0);
            }
            return null;
        } catch (IOException e) {
            if (!Log.isLoggable("DiskLruCacheWrapper", 5)) {
                return null;
            }
            Log.w("DiskLruCacheWrapper", "Unable to get from disk cache", e);
            return null;
        }
    }
}
