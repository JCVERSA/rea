package ax.B2;

import android.os.Build;
import j$.util.DesugarCollections;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: renamed from: ax.B2.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0673a implements p {
    private static final Set<AbstractC0673a> c = new HashSet();
    private final String a;
    private final String b;

    /* JADX INFO: renamed from: ax.B2.a$a, reason: collision with other inner class name */
    private static class C0058a {
        static final Set<String> a = new HashSet(Arrays.asList(x.c().a()));
    }

    /* JADX INFO: renamed from: ax.B2.a$b */
    public static class b extends AbstractC0673a {
        b(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 23;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$c */
    public static class c extends AbstractC0673a {
        c(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 24;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$d */
    public static class d extends AbstractC0673a {
        d(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return false;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$e */
    public static class e extends AbstractC0673a {
        e(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 26;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$f */
    public static class f extends AbstractC0673a {
        f(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 27;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$g */
    public static class g extends AbstractC0673a {
        g(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 28;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$h */
    public static class h extends AbstractC0673a {
        h(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 29;
        }
    }

    /* JADX INFO: renamed from: ax.B2.a$i */
    public static class i extends AbstractC0673a {
        i(String str, String str2) {
            super(str, str2);
        }

        @Override // ax.B2.AbstractC0673a
        public final boolean b() {
            return Build.VERSION.SDK_INT >= 33;
        }
    }

    AbstractC0673a(String str, String str2) {
        this.a = str;
        this.b = str2;
        c.add(this);
    }

    public static Set<AbstractC0673a> d() {
        return DesugarCollections.unmodifiableSet(c);
    }

    @Override // ax.B2.p
    public String a() {
        return this.a;
    }

    public abstract boolean b();

    public boolean c() {
        return ax.Ee.a.b(C0058a.a, this.b);
    }

    @Override // ax.B2.p
    public boolean isSupported() {
        return b() || c();
    }
}
