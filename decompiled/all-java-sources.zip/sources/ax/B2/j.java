package ax.B2;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/* JADX INFO: loaded from: classes.dex */
public class j {
    private final ax.U2.e<ax.p311w2.h, String> a = new ax.U2.e<>(1000);
    private final ax.p001a0.d<b> b = ax.V2.a.e(10, new a());

    class a implements ax.V2.a.d<b> {
        a() {
        }

        @Override // ax.V2.a.d
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public b a() {
            try {
                return new b(MessageDigest.getInstance("SHA-256"));
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static final class b implements ax.V2.a.f {
        private final ax.V2.b X = ax.V2.b.a();
        final MessageDigest q;

        b(MessageDigest messageDigest) {
            this.q = messageDigest;
        }

        @Override // ax.V2.a.f
        public ax.V2.b k() {
            return this.X;
        }
    }

    private String a(ax.p311w2.h hVar) {
        b bVarB = this.b.b();
        try {
            hVar.b(bVarB.q);
            return ax.U2.i.s(bVarB.q.digest());
        } finally {
            this.b.c(bVarB);
        }
    }

    public String b(ax.p311w2.h hVar) {
        String strG;
        synchronized (this.a) {
            strG = this.a.g(hVar);
        }
        if (strG == null) {
            strG = a(hVar);
        }
        synchronized (this.a) {
            this.a.k(hVar, strG);
        }
        return strG;
    }
}
