package ax.B2;

import android.annotation.SuppressLint;
import ax.p353z2.s;

/* JADX INFO: loaded from: classes.dex */
public class g extends ax.U2.e<ax.p311w2.h, s<?>> implements h {
    private h.a e;

    public g(int i) {
        super(i);
    }

    @Override // ax.B2.h
    @SuppressLint({"InlinedApi"})
    public void a(int i) {
        if (i >= 40) {
            b();
        } else if (i >= 20) {
            m(h() / 2);
        }
    }

    @Override // ax.B2.h
    public /* bridge */ /* synthetic */ s c(ax.p311w2.h hVar) {
        return (s) super.l(hVar);
    }

    @Override // ax.B2.h
    public void d(h.a aVar) {
        this.e = aVar;
    }

    @Override // ax.B2.h
    public /* bridge */ /* synthetic */ s e(ax.p311w2.h hVar, s sVar) {
        return (s) super.k(hVar, sVar);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ax.U2.e
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public int i(s<?> sVar) {
        return sVar.getSize();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // ax.U2.e
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public void j(ax.p311w2.h hVar, s<?> sVar) {
        h.a aVar = this.e;
        if (aVar != null) {
            aVar.d(sVar);
        }
    }
}
