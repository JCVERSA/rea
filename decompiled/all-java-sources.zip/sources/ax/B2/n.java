package ax.B2;

import android.webkit.TracingConfig;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class n {
    public static /* synthetic */ TracingConfig.Builder a() {
        return new TracingConfig.Builder();
    }
}
