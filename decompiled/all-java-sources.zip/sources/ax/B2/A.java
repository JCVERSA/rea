package ax.B2;

import android.webkit.WebView;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;

/* JADX INFO: loaded from: classes.dex */
public class A implements z {
    final WebViewProviderFactoryBoundaryInterface a;

    public A(WebViewProviderFactoryBoundaryInterface webViewProviderFactoryBoundaryInterface) {
        this.a = webViewProviderFactoryBoundaryInterface;
    }

    @Override // ax.B2.z
    public String[] a() {
        return this.a.getSupportedFeatures();
    }

    @Override // ax.B2.z
    public WebViewProviderBoundaryInterface createWebView(WebView webView) {
        return (WebViewProviderBoundaryInterface) ax.Ee.a.a(WebViewProviderBoundaryInterface.class, this.a.createWebView(webView));
    }

    @Override // ax.B2.z
    public StaticsBoundaryInterface getStatics() {
        return (StaticsBoundaryInterface) ax.Ee.a.a(StaticsBoundaryInterface.class, this.a.getStatics());
    }
}
