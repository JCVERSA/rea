package ax.B2;

import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public interface a {

    /* JADX INFO: renamed from: ax.B2.a$a, reason: collision with other inner class name */
    public interface InterfaceC0061a {
        a j();
    }

    public interface b {
        boolean a(File file);
    }

    void a(ax.p311w2.h hVar, b bVar);

    File b(ax.p311w2.h hVar);
}
