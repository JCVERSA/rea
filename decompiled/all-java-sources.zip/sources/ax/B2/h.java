package ax.B2;

import ax.p353z2.s;

/* JADX INFO: loaded from: classes.dex */
public interface h {

    public interface a {
        void d(s<?> sVar);
    }

    void a(int i);

    void b();

    s<?> c(ax.p311w2.h hVar);

    void d(a aVar);

    s<?> e(ax.p311w2.h hVar, s<?> sVar);
}
