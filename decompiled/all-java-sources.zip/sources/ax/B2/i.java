package ax.B2;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i {
}
