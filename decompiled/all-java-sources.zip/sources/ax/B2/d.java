package ax.B2;

import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public class d implements ax.B2.a.InterfaceC0061a {
    private final int a;
    private final a b;

    public interface a {
        File a();
    }

    public d(a aVar, int i) {
        this.a = i;
        this.b = aVar;
    }

    @Override // ax.B2.a.InterfaceC0061a
    public ax.B2.a j() {
        File fileA = this.b.a();
        if (fileA == null) {
            return null;
        }
        if (fileA.mkdirs() || (fileA.exists() && fileA.isDirectory())) {
            return e.c(fileA, this.a);
        }
        return null;
    }
}
