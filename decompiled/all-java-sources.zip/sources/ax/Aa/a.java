package ax.Aa;

import ax.p149k8.j;
import ax.p149k8.r;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    private final Gson a;
    private final d b;
    private final e.g c;

    a(Gson gson, d dVar, e.g gVar) {
        if (dVar == null) {
            throw new NullPointerException("XmlParserCreator is null");
        }
        this.a = gson;
        this.b = dVar;
        this.c = gVar;
    }

    private static void a(Object obj, JsonReader jsonReader) {
        if (obj != null) {
            try {
                if (jsonReader.peek() == JsonToken.END_DOCUMENT) {
                } else {
                    throw new j("JSON document was not fully consumed.");
                }
            } catch (MalformedJsonException e) {
                throw new r(e);
            } catch (IOException e2) {
                throw new j(e2);
            }
        }
    }

    public <T> T b(e eVar, Type type) throws r, j {
        return (T) this.a.g(eVar, type);
    }

    public <T> T c(Reader reader, Class<T> cls) throws r, j {
        e eVar = new e(reader, this.b, this.c);
        Object objB = b(eVar, cls);
        a(objB, eVar);
        return (T) ax.p177m8.j.b(cls).cast(objB);
    }

    public String toString() {
        return this.a.toString();
    }
}
