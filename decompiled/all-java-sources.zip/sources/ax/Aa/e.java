package ax.Aa;

/* JADX INFO: loaded from: classes3.dex */
public interface e {
    <T> String a(T t);

    <T> T b(String str, Class<T> cls);
}
