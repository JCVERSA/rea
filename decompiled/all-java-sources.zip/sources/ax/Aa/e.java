package ax.Aa;

import ax.p149k8.r;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import java.util.Set;
import okhttp3.HttpUrl;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: classes2.dex */
public class e extends JsonReader {
    final g X;
    private final h<j> Y;
    private final h<k> Z;
    private j h0;
    private j i0;
    private k j0;
    private k k0;
    private JsonToken l0;
    private boolean m0;
    private boolean n0;
    private boolean o0;
    private String p0;
    private final XmlPullParser q;
    private final ax.Aa.c<i> q0;
    private final ax.Aa.c<C0056e> r0;
    private JsonToken s0;
    private int t0;
    private boolean u0;
    private final l v0;
    private final d w0;

    class a implements f<j> {
        a() {
        }

        @Override // ax.Aa.e.f
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public j a() {
            return new j(null);
        }
    }

    class b implements f<k> {
        b() {
        }

        @Override // ax.Aa.e.f
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public k a() {
            return new k(null);
        }
    }

    static /* synthetic */ class c {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] b;

        static {
            int[] iArr = new int[i.values().length];
            b = iArr;
            try {
                iArr[i.INSIDE_PRIMITIVE_ARRAY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[i.INSIDE_PRIMITIVE_EMBEDDED_ARRAY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[i.INSIDE_EMBEDDED_ARRAY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                b[i.INSIDE_ARRAY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                b[i.NAME.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                b[i.PRIMITIVE_VALUE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                b[i.INSIDE_OBJECT.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            int[] iArr2 = new int[JsonToken.values().length];
            a = iArr2;
            try {
                iArr2[JsonToken.BEGIN_OBJECT.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                a[JsonToken.STRING.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                a[JsonToken.BEGIN_ARRAY.ordinal()] = 3;
            } catch (NoSuchFieldError unused10) {
            }
        }
    }

    private final class d {
        String[] a;
        String[] b;
        String[] c;
        int d = 0;

        public d(int i) {
            a(i);
        }

        private void a(int i) {
            this.a = new String[i];
            this.b = new String[i];
            this.c = new String[i];
        }

        public void b(XmlPullParser xmlPullParser) {
            int attributeCount = xmlPullParser.getAttributeCount();
            if (attributeCount > this.a.length) {
                a(attributeCount);
            }
            this.d = attributeCount;
            for (int i = 0; i < attributeCount; i++) {
                this.a[i] = xmlPullParser.getAttributeName(i);
                if (e.this.X.d) {
                    this.c[i] = xmlPullParser.getAttributePrefix(i);
                }
                this.b[i] = xmlPullParser.getAttributeValue(i);
            }
        }

        public String c(int i) throws XmlPullParserException, IOException {
            return e.this.r(this.a[i], this.c[i], null);
        }
    }

    /* JADX INFO: renamed from: ax.Aa.e$e, reason: collision with other inner class name */
    private static class C0056e {
        int a;
        String b;

        public C0056e(int i, String str) {
            this.a = i;
            this.b = str;
        }

        public String toString() {
            return "'" + this.b + "'/" + this.a;
        }
    }

    private interface f<T> {
        T a();
    }

    public static class g {
        boolean a;
        boolean b;
        boolean c;
        boolean d;
        boolean e;
        boolean f;
        Map<String, String> g;
        Set<String> h;
        Set<String> i;
        boolean j;
    }

    private static final class h<T> {
        private final f<T> a;
        private final Object[] b = new Object[32];
        private int c = 0;

        public h(f<T> fVar) {
            this.a = fVar;
        }

        public T a() {
            int i = this.c;
            if (i == 0) {
                return this.a.a();
            }
            Object[] objArr = this.b;
            int i2 = i - 1;
            this.c = i2;
            return (T) objArr[i2];
        }

        public void b(T t) {
            int i = this.c;
            if (i < 32) {
                Object[] objArr = this.b;
                this.c = i + 1;
                objArr[i] = t;
            }
        }
    }

    private enum i {
        INSIDE_OBJECT(false),
        INSIDE_ARRAY(true),
        INSIDE_EMBEDDED_ARRAY(true),
        INSIDE_PRIMITIVE_EMBEDDED_ARRAY(true),
        INSIDE_PRIMITIVE_ARRAY(true),
        PRIMITIVE_VALUE(false),
        NAME(false);

        final boolean q;

        i(boolean z) {
            this.q = z;
        }
    }

    private static final class j {
        JsonToken a;
        j b;

        private j() {
        }

        public String toString() {
            return this.a + ", " + this.b;
        }

        /* synthetic */ j(a aVar) {
            this();
        }
    }

    private static final class k {
        String a;
        k b;

        private k() {
        }

        public String toString() {
            return this.a + ", " + this.b;
        }

        /* synthetic */ k(a aVar) {
            this();
        }
    }

    private final class l {
        int a;
        String b;
        String c;
        String d;
        d e;

        private l() {
        }

        public void a() {
            this.a = -1;
            this.b = null;
            this.c = null;
            this.d = null;
            this.e = null;
        }

        public String b(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
            return e.this.r(this.b, this.d, xmlPullParser);
        }

        public String toString() {
            String str;
            String str2;
            StringBuilder sb = new StringBuilder();
            sb.append("xml ");
            int i = this.a;
            if (i == 1) {
                str = "start";
            } else {
                str = i == 2 ? "end" : "value";
            }
            sb.append(str);
            sb.append(" <");
            sb.append(this.d);
            sb.append(":");
            sb.append(this.b);
            sb.append(">=");
            sb.append(this.c);
            if (this.e != null) {
                str2 = ", " + this.e;
            } else {
                str2 = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            sb.append(str2);
            return sb.toString();
        }

        /* synthetic */ l(e eVar, a aVar) {
            this();
        }
    }

    public e(Reader reader, ax.Aa.d dVar, g gVar) {
        super(reader);
        this.Y = new h<>(new a());
        this.Z = new h<>(new b());
        this.n0 = true;
        this.o0 = false;
        this.q0 = new ax.Aa.c<>();
        this.r0 = new ax.Aa.c<>();
        this.t0 = 0;
        l lVar = new l(this, null);
        this.v0 = lVar;
        this.w0 = new d(10);
        XmlPullParser xmlPullParserA = dVar.a();
        this.q = xmlPullParserA;
        this.X = gVar;
        lVar.a = -1;
        try {
            xmlPullParserA.setInput(reader);
            xmlPullParserA.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", gVar.d);
        } catch (XmlPullParserException e) {
            throw new ax.p149k8.j(e);
        }
    }

    private JsonToken A() {
        j jVar = this.i0;
        if (jVar != null) {
            return jVar.a;
        }
        return null;
    }

    private void B(l lVar) throws XmlPullParserException, IOException {
        switch (c.b[this.q0.g().ordinal()]) {
            case 1:
            case 4:
                g(JsonToken.END_ARRAY);
                l();
                break;
            case 2:
            case 3:
                g(JsonToken.END_ARRAY);
                g(JsonToken.END_OBJECT);
                l();
                l();
                break;
            case 5:
                if (this.o0) {
                    d(HttpUrl.FRAGMENT_ENCODE_SET, true);
                }
                l();
                break;
            case 6:
                this.q0.c();
                break;
            case 7:
                g(JsonToken.END_OBJECT);
                this.t0 = 0;
                l();
                break;
        }
        if (this.X.c) {
            int depth = this.q.getDepth();
            String strB = this.X.d ? lVar.b(this.q) : lVar.b;
            ax.Aa.c<C0056e> cVar = this.r0;
            while (cVar.j() > 0 && cVar.g().a > depth) {
                cVar.c();
            }
            if (cVar.j() == 0 || cVar.g().a < depth) {
                cVar.h(new C0056e(depth, strB));
            } else {
                cVar.g().b = strB;
            }
        }
    }

    private void E(l lVar) throws XmlPullParserException, IOException {
        if (!this.X.b) {
            g(this.l0);
            this.q0.h(i.INSIDE_OBJECT);
            F(lVar);
            return;
        }
        if (lVar.e != null) {
            g(JsonToken.BEGIN_OBJECT);
            this.q0.h(i.INSIDE_OBJECT);
            f(lVar.e);
            return;
        }
        int i2 = c.a[this.l0.ordinal()];
        if (i2 == 1) {
            g(JsonToken.BEGIN_OBJECT);
            this.q0.h(i.INSIDE_OBJECT);
        } else if (i2 == 3) {
            g(JsonToken.BEGIN_ARRAY);
            this.q0.h(this.X.e ? i.INSIDE_PRIMITIVE_ARRAY : i.INSIDE_ARRAY);
        } else {
            throw new IllegalStateException("First expectedToken=" + this.l0 + " (not begin_object/begin_array)");
        }
    }

    private void F(l lVar) throws XmlPullParserException, IOException {
        i iVarG = this.q0.g();
        if (this.X.c && iVarG.q && this.r0.j() > 0) {
            C0056e c0056eG = this.r0.g();
            if (c0056eG.a == this.q.getDepth()) {
                if (!(this.X.d ? lVar.b(this.q) : lVar.b).equals(c0056eG.b)) {
                    g(JsonToken.END_ARRAY);
                    l();
                    iVarG = this.q0.g();
                }
            }
        }
        int i2 = c.b[iVarG.ordinal()];
        boolean z = false;
        if (i2 == 1 || i2 == 2) {
            this.q0.h(i.PRIMITIVE_VALUE);
        } else if (i2 == 3 || i2 == 4) {
            g(JsonToken.BEGIN_OBJECT);
            this.q0.h(i.INSIDE_OBJECT);
        } else if (i2 != 5) {
            z = true;
        } else {
            z = true;
            g(JsonToken.BEGIN_OBJECT);
            this.q0.h(i.INSIDE_OBJECT);
        }
        this.p0 = lVar.b(this.q);
        if (z) {
            this.q0.h(i.NAME);
            g(JsonToken.NAME);
            h(lVar.b(this.q));
            this.o0 = true;
        }
        if (lVar.e != null) {
            g gVar = this.X;
            if (gVar.j && gVar.i.contains(this.p0)) {
                return;
            }
            i iVarG2 = this.q0.g();
            if (iVarG2 == i.PRIMITIVE_VALUE) {
                throw new IllegalStateException("Attributes data in primitive scope");
            }
            if (iVarG2 == i.NAME) {
                g(JsonToken.BEGIN_OBJECT);
                this.q0.h(i.INSIDE_OBJECT);
            }
            f(lVar.e);
        }
    }

    private boolean G(l lVar) {
        int i2 = c.b[this.q0.g().ordinal()];
        if (i2 == 5) {
            d(lVar.c, true);
            return true;
        }
        if (i2 == 6) {
            d(lVar.c, false);
            return false;
        }
        if (i2 != 7) {
            throw new r("Cannot process text '" + lVar.c + "' inside scope " + this.q0.g());
        }
        String str = "$";
        if (this.t0 > 0) {
            str = "$" + this.t0;
        }
        this.t0++;
        g(JsonToken.NAME);
        h(str);
        d(lVar.c, false);
        return false;
    }

    private void H(JsonToken jsonToken) {
        j jVarA = this.Y.a();
        jVarA.a = jsonToken;
        jVarA.b = null;
        j jVar = this.i0;
        if (jVar == null) {
            this.i0 = jVarA;
            this.h0 = jVarA;
        } else {
            jVarA.b = jVar;
            this.i0 = jVarA;
        }
    }

    private void K(String str) {
        k kVarA = this.Z.a();
        kVarA.a = str;
        kVarA.b = null;
        k kVar = this.k0;
        if (kVar == null) {
            this.j0 = kVarA;
            this.k0 = kVarA;
        } else {
            kVarA.b = kVar;
            this.k0 = kVarA;
        }
    }

    private void a() throws XmlPullParserException, IOException {
        Set<String> set;
        JsonToken jsonToken;
        JsonToken jsonToken2 = this.s0;
        JsonToken jsonToken3 = this.l0;
        if (jsonToken2 == jsonToken3) {
            return;
        }
        JsonToken jsonToken4 = JsonToken.BEGIN_OBJECT;
        if (jsonToken3 == jsonToken4 && jsonToken2 == (jsonToken = JsonToken.STRING) && HttpUrl.FRAGMENT_ENCODE_SET.equals(this.j0.a)) {
            this.s0 = jsonToken4;
            String str = v().a;
            H(JsonToken.END_OBJECT);
            H(jsonToken);
            H(JsonToken.NAME);
            K(str);
            K("$");
            return;
        }
        JsonToken jsonToken5 = this.l0;
        JsonToken jsonToken6 = JsonToken.BEGIN_ARRAY;
        if (jsonToken5 != jsonToken6) {
            return;
        }
        int i2 = c.a[this.s0.ordinal()];
        if (i2 != 1) {
            if (i2 != 2) {
                return;
            }
            this.s0 = jsonToken6;
            g gVar = this.X;
            if (!gVar.c) {
                H(JsonToken.END_ARRAY);
                if (this.k0 != null) {
                    v();
                    return;
                }
                return;
            }
            if (gVar.a && ((set = gVar.h) == null || (set != null && set.contains(this.p0)))) {
                H(JsonToken.STRING);
                this.q0.h(i.INSIDE_PRIMITIVE_EMBEDDED_ARRAY);
                return;
            }
            String str2 = v().a;
            H(JsonToken.END_OBJECT);
            H(JsonToken.STRING);
            H(JsonToken.NAME);
            H(jsonToken4);
            K(str2);
            K("$");
            this.q0.h(i.INSIDE_EMBEDDED_ARRAY);
            return;
        }
        this.s0 = jsonToken6;
        i iVarG = this.q0.g();
        if (A() == JsonToken.NAME) {
            if (this.X.c) {
                this.q0.a(2);
                H(jsonToken4);
                this.q0.h(i.INSIDE_EMBEDDED_ARRAY);
                this.q0.h(i.INSIDE_OBJECT);
                i iVar = i.NAME;
                if (iVarG == iVar) {
                    this.q0.h(iVar);
                    return;
                }
                return;
            }
            t();
            v();
            int iJ = this.q0.j();
            if (this.X.a && A() == null) {
                k(true);
            }
            int iB = this.q0.b(3, iJ);
            if (this.X.a && A() == JsonToken.STRING) {
                this.q0.i(iB, i.INSIDE_PRIMITIVE_ARRAY);
                return;
            }
            this.q0.i(iB, i.INSIDE_ARRAY);
            int i3 = iB + 1;
            if (this.q0.j() <= i3 || this.q0.f(i3) != i.INSIDE_OBJECT) {
                this.q0.i(i3, i.INSIDE_OBJECT);
            }
            if (A() != jsonToken4) {
                H(jsonToken4);
            }
        }
    }

    private void d(String str, boolean z) {
        j jVar;
        if (!z || (jVar = this.h0) == null || jVar.a != JsonToken.STRING) {
            g(JsonToken.STRING);
            h(str);
        } else if (str.length() > 0) {
            StringBuilder sb = new StringBuilder();
            k kVar = this.j0;
            sb.append(kVar.a);
            sb.append(" ");
            sb.append(str);
            kVar.a = sb.toString();
        }
    }

    private void f(d dVar) throws XmlPullParserException, IOException {
        int i2 = dVar.d;
        for (int i3 = 0; i3 < i2; i3++) {
            g(JsonToken.NAME);
            h("@" + dVar.c(i3));
            g(JsonToken.STRING);
            h(dVar.b[i3]);
        }
    }

    private void g(JsonToken jsonToken) {
        j jVarA = this.Y.a();
        jVarA.a = jsonToken;
        jVarA.b = null;
        j jVar = this.h0;
        if (jVar == null) {
            this.h0 = jVarA;
            this.i0 = jVarA;
        } else {
            jVar.b = jVarA;
            this.h0 = jVarA;
        }
    }

    private void h(String str) {
        k kVarA = this.Z.a();
        kVarA.a = str.trim();
        kVarA.b = null;
        k kVar = this.j0;
        if (kVar == null) {
            this.j0 = kVarA;
            this.k0 = kVarA;
        } else {
            kVar.b = kVarA;
            this.j0 = kVarA;
        }
    }

    private CharSequence i() {
        StringBuilder sb = new StringBuilder();
        sb.append("Scopes: ");
        sb.append(this.q0);
        sb.append('\n');
        sb.append("Closed tags: ");
        sb.append(this.r0);
        sb.append('\n');
        sb.append("Token: ");
        sb.append(this.s0);
        sb.append('\n');
        sb.append("Tokens queue: ");
        sb.append(this.i0);
        sb.append('\n');
        sb.append("Values queue: ");
        sb.append(this.k0);
        sb.append('\n');
        return sb;
    }

    private void j(JsonToken jsonToken) throws IOException {
        JsonToken jsonTokenPeek = peek();
        this.s0 = null;
        if (jsonTokenPeek == jsonToken) {
            return;
        }
        throw new IllegalStateException(jsonToken + " expected, but met " + jsonTokenPeek + "\n" + ((Object) i()));
    }

    private void k(boolean z) throws XmlPullParserException, IOException {
        while (true) {
            if ((this.h0 != null || this.m0) && !z) {
                return;
            }
            l lVarX = x();
            if (this.m0) {
                if (this.X.b) {
                    return;
                }
                g(JsonToken.END_OBJECT);
                return;
            }
            int i2 = lVarX.a;
            if (i2 != -1) {
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 == 3) {
                            z = G(lVarX);
                        }
                        if (!z && this.u0) {
                            return;
                        }
                    } else {
                        B(lVarX);
                    }
                } else if (this.n0) {
                    this.n0 = false;
                    E(lVarX);
                } else {
                    F(lVarX);
                }
                z = false;
                if (!z) {
                    continue;
                }
            }
        }
    }

    private void l() {
        this.q0.e(i.NAME);
    }

    private JsonToken t() {
        j jVar = this.i0;
        if (jVar == null) {
            return JsonToken.END_DOCUMENT;
        }
        this.i0 = jVar.b;
        if (jVar == this.h0) {
            this.h0 = null;
        }
        this.Y.b(jVar);
        return jVar.a;
    }

    private k v() {
        k kVar = this.k0;
        if (kVar == null) {
            throw new IllegalStateException("No value can be given");
        }
        if (kVar == this.j0) {
            this.j0 = null;
        }
        this.Z.b(kVar);
        this.k0 = kVar.b;
        return kVar;
    }

    private l x() throws XmlPullParserException, IOException {
        int next = this.q.next();
        l lVar = this.v0;
        lVar.a();
        if (next != 1) {
            if (next == 2) {
                lVar.a = 1;
                lVar.b = this.q.getName();
                lVar.d = this.q.getNamespace();
                if (this.q.getAttributeCount() > 0) {
                    this.w0.b(this.q);
                    lVar.e = this.w0;
                }
            } else if (next == 3) {
                lVar.a = 2;
                lVar.b = this.q.getName();
                lVar.d = this.q.getNamespace();
            } else if (next == 4) {
                String strTrim = this.q.getText().trim();
                if (strTrim.length() == 0) {
                    this.o0 = true;
                    lVar.a = -1;
                    return lVar;
                }
                this.o0 = false;
                lVar.a = 3;
                lVar.c = strTrim;
            }
            return lVar;
        }
        this.m0 = true;
        lVar.a = -1;
        return lVar;
    }

    @Override // com.google.gson.stream.JsonReader
    public void beginArray() throws IOException {
        JsonToken jsonToken = JsonToken.BEGIN_ARRAY;
        this.l0 = jsonToken;
        j(jsonToken);
    }

    @Override // com.google.gson.stream.JsonReader
    public void beginObject() throws IOException {
        JsonToken jsonToken = JsonToken.BEGIN_OBJECT;
        this.l0 = jsonToken;
        j(jsonToken);
    }

    @Override // com.google.gson.stream.JsonReader
    public void endArray() throws IOException {
        JsonToken jsonToken = JsonToken.END_ARRAY;
        this.l0 = jsonToken;
        j(jsonToken);
    }

    @Override // com.google.gson.stream.JsonReader
    public void endObject() throws IOException {
        JsonToken jsonToken = JsonToken.END_OBJECT;
        this.l0 = jsonToken;
        j(jsonToken);
    }

    @Override // com.google.gson.stream.JsonReader
    public boolean hasNext() throws IOException {
        peek();
        JsonToken jsonToken = this.s0;
        return (jsonToken == JsonToken.END_OBJECT || jsonToken == JsonToken.END_ARRAY) ? false : true;
    }

    @Override // com.google.gson.stream.JsonReader
    public boolean nextBoolean() throws IOException {
        j(JsonToken.BOOLEAN);
        String str = v().a;
        if ("true".equalsIgnoreCase(str) || "false".equalsIgnoreCase(str)) {
            return true;
        }
        throw new IOException("Cannot parse <" + str + "> to boolean");
    }

    @Override // com.google.gson.stream.JsonReader
    public double nextDouble() throws IOException {
        j(JsonToken.STRING);
        return Double.parseDouble(v().a);
    }

    @Override // com.google.gson.stream.JsonReader
    public int nextInt() throws IOException {
        j(JsonToken.STRING);
        return Integer.parseInt(v().a);
    }

    @Override // com.google.gson.stream.JsonReader
    public long nextLong() throws IOException {
        j(JsonToken.STRING);
        return Long.parseLong(v().a);
    }

    @Override // com.google.gson.stream.JsonReader
    public String nextName() throws IOException {
        JsonToken jsonToken = JsonToken.NAME;
        this.l0 = jsonToken;
        j(jsonToken);
        return v().a;
    }

    @Override // com.google.gson.stream.JsonReader
    public String nextString() throws IOException {
        j(JsonToken.STRING);
        return v().a;
    }

    @Override // com.google.gson.stream.JsonReader
    public JsonToken peek() throws IOException {
        if (this.l0 == null && this.n0) {
            return JsonToken.BEGIN_OBJECT;
        }
        if (this.s0 != null) {
            try {
                a();
                this.l0 = null;
                return this.s0;
            } catch (XmlPullParserException e) {
                throw new r("XML parsing exception", e);
            }
        }
        try {
            k(false);
            this.l0 = null;
            JsonToken jsonTokenT = t();
            this.s0 = jsonTokenT;
            return jsonTokenT;
        } catch (XmlPullParserException e2) {
            throw new r("XML parsing exception", e2);
        }
    }

    String r(String str, String str2, XmlPullParser xmlPullParser) throws XmlPullParserException {
        if (this.X.f || str2 == null || str2.length() <= 0) {
            return str;
        }
        Map<String, String> map = this.X.g;
        if (map != null && map.containsKey(str2)) {
            str2 = this.X.g.get(str2);
        } else if (xmlPullParser != null) {
            int namespaceCount = xmlPullParser.getNamespaceCount(xmlPullParser.getDepth());
            for (int i2 = 0; i2 < namespaceCount; i2++) {
                if (str2.equals(xmlPullParser.getNamespaceUri(i2))) {
                    str2 = xmlPullParser.getNamespacePrefix(i2);
                    break;
                }
            }
        }
        return "<" + str2 + ">" + str;
    }

    @Override // com.google.gson.stream.JsonReader
    public void skipValue() throws IOException {
        this.u0 = true;
        int i2 = 0;
        do {
            try {
                JsonToken jsonTokenPeek = peek();
                if (jsonTokenPeek == JsonToken.BEGIN_ARRAY || jsonTokenPeek == JsonToken.BEGIN_OBJECT) {
                    i2++;
                } else if (jsonTokenPeek == JsonToken.END_ARRAY || jsonTokenPeek == JsonToken.END_OBJECT) {
                    i2--;
                } else if (this.j0 != null) {
                    v();
                }
                this.s0 = null;
            } catch (Throwable th) {
                this.u0 = false;
                throw th;
            }
        } while (i2 != 0);
        this.u0 = false;
    }

    @Override // com.google.gson.stream.JsonReader
    public String toString() {
        return "--- XmlReader ---\n" + ((Object) i());
    }
}
