package ax.Aa;

import org.xmlpull.v1.XmlPullParser;

/* JADX INFO: loaded from: classes2.dex */
public interface d {
    XmlPullParser a();
}
