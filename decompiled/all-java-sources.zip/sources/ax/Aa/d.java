package ax.Aa;

import ax.Y8.l;

/* JADX INFO: loaded from: classes3.dex */
public interface d {
    void c(e eVar, l lVar);

    com.microsoft.graph.serializer.a d();
}
