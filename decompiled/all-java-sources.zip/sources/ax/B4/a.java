package ax.B4;

import android.os.Parcel;
import android.os.Parcelable;
import ax.p145k4.O;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class a implements ax.A4.a.b {
    public final String X;
    public final long Y;
    public final long Z;
    public final byte[] h0;
    private int i0;
    public final String q;
    private static final O j0 = O.x(null, "application/id3", Long.MAX_VALUE);
    private static final O k0 = O.x(null, "application/x-scte35", Long.MAX_VALUE);
    public static final Parcelable.Creator<a> CREATOR = new C0062a();

    /* JADX INFO: renamed from: ax.B4.a$a, reason: collision with other inner class name */
    static class C0062a implements Parcelable.Creator<a> {
        C0062a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public a[] newArray(int i) {
            return new a[i];
        }
    }

    public a(String str, String str2, long j, long j2, byte[] bArr) {
        this.q = str;
        this.X = str2;
        this.Y = j;
        this.Z = j2;
        this.h0 = bArr;
    }

    @Override // ax.A4.a.b
    public byte[] C() {
        if (o() != null) {
            return this.h0;
        }
        return null;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || a.class != obj.getClass()) {
            return false;
        }
        a aVar = (a) obj;
        return this.Y == aVar.Y && this.Z == aVar.Z && ax.V4.O.c(this.q, aVar.q) && ax.V4.O.c(this.X, aVar.X) && Arrays.equals(this.h0, aVar.h0);
    }

    public int hashCode() {
        if (this.i0 == 0) {
            String str = this.q;
            int iHashCode = (527 + (str != null ? str.hashCode() : 0)) * 31;
            String str2 = this.X;
            int iHashCode2 = str2 != null ? str2.hashCode() : 0;
            long j = this.Y;
            int i = (((iHashCode + iHashCode2) * 31) + ((int) (j ^ (j >>> 32)))) * 31;
            long j2 = this.Z;
            this.i0 = ((i + ((int) (j2 ^ (j2 >>> 32)))) * 31) + Arrays.hashCode(this.h0);
        }
        return this.i0;
    }

    @Override // ax.A4.a.b
    public O o() {
        String str = this.q;
        str.hashCode();
        switch (str) {
            case "urn:scte:scte35:2014:bin":
                return k0;
            case "https://aomedia.org/emsg/ID3":
            case "https://developer.apple.com/streaming/emsg-id3":
                return j0;
            default:
                return null;
        }
    }

    public String toString() {
        return "EMSG: scheme=" + this.q + ", id=" + this.Z + ", durationMs=" + this.Y + ", value=" + this.X;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.q);
        parcel.writeString(this.X);
        parcel.writeLong(this.Y);
        parcel.writeLong(this.Z);
        parcel.writeByteArray(this.h0);
    }

    a(Parcel parcel) {
        this.q = (String) ax.V4.O.h(parcel.readString());
        this.X = (String) ax.V4.O.h(parcel.readString());
        this.Y = parcel.readLong();
        this.Z = parcel.readLong();
        this.h0 = (byte[]) ax.V4.O.h(parcel.createByteArray());
    }
}
