package ax.B4;

import ax.A4.e;
import ax.V4.C4769a;
import ax.V4.t;
import java.nio.ByteBuffer;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class b implements ax.A4.c {
    @Override // ax.A4.c
    public ax.A4.a a(e eVar) {
        ByteBuffer byteBuffer = (ByteBuffer) C4769a.e(eVar.X);
        return new ax.A4.a(b(new t(byteBuffer.array(), byteBuffer.limit())));
    }

    public a b(t tVar) {
        return new a((String) C4769a.e(tVar.t()), (String) C4769a.e(tVar.t()), tVar.B(), tVar.B(), Arrays.copyOfRange(tVar.a, tVar.c(), tVar.d()));
    }
}
