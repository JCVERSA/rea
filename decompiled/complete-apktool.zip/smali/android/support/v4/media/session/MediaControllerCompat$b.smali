.class interface abstract Landroid/support/v4/media/session/MediaControllerCompat$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/media/session/MediaControllerCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "b"
.end annotation


# virtual methods
.method public abstract K0()I
.end method

.method public abstract P()Landroid/support/v4/media/session/PlaybackStateCompat;
.end method

.method public abstract a(Landroid/support/v4/media/session/MediaControllerCompat$a;)V
.end method

.method public abstract b(Landroid/view/KeyEvent;)Z
.end method

.method public abstract c()Landroid/support/v4/media/session/MediaControllerCompat$e;
.end method

.method public abstract d(Landroid/support/v4/media/session/MediaControllerCompat$a;Landroid/os/Handler;)V
.end method

.method public abstract m0()I
.end method

.method public abstract n0()Landroid/os/Bundle;
.end method

.method public abstract x0()Landroid/support/v4/media/MediaMetadataCompat;
.end method
