.class Landroidx/appcompat/widget/x$c;
.super Landroidx/appcompat/widget/x$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field final synthetic b:Landroidx/appcompat/widget/x;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/x;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/appcompat/widget/x$c;->b:Landroidx/appcompat/widget/x;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Landroidx/appcompat/widget/x$b;-><init>(Landroidx/appcompat/widget/x;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public f(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/appcompat/widget/x$c;->b:Landroidx/appcompat/widget/x;

    .line 2
    .line 3
    invoke-static {v0, p1}, Landroidx/appcompat/widget/x;->r(Landroidx/appcompat/widget/x;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public j(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/appcompat/widget/x$c;->b:Landroidx/appcompat/widget/x;

    .line 2
    .line 3
    invoke-static {v0, p1}, Landroidx/appcompat/widget/x;->g(Landroidx/appcompat/widget/x;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
