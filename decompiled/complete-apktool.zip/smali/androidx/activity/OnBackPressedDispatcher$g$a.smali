.class public final Landroidx/activity/OnBackPressedDispatcher$g$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/window/OnBackAnimationCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/OnBackPressedDispatcher$g;->a(Lax/ib/l;Lax/ib/l;Lax/ib/a;Lax/ib/a;)Landroid/window/OnBackInvokedCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lax/ib/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lax/ib/l<",
            "Lax/i/b;",
            "Lax/Wa/t;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Lax/ib/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lax/ib/l<",
            "Lax/i/b;",
            "Lax/Wa/t;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Lax/ib/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lax/ib/a<",
            "Lax/Wa/t;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:Lax/ib/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lax/ib/a<",
            "Lax/Wa/t;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lax/ib/l;Lax/ib/l;Lax/ib/a;Lax/ib/a;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lax/ib/l<",
            "-",
            "Lax/i/b;",
            "Lax/Wa/t;",
            ">;",
            "Lax/ib/l<",
            "-",
            "Lax/i/b;",
            "Lax/Wa/t;",
            ">;",
            "Lax/ib/a<",
            "Lax/Wa/t;",
            ">;",
            "Lax/ib/a<",
            "Lax/Wa/t;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->a:Lax/ib/l;

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->b:Lax/ib/l;

    .line 4
    .line 5
    iput-object p3, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->c:Lax/ib/a;

    .line 6
    .line 7
    iput-object p4, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->d:Lax/ib/a;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public onBackCancelled()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->d:Lax/ib/a;

    .line 2
    .line 3
    invoke-interface {v0}, Lax/ib/a;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public onBackInvoked()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->c:Lax/ib/a;

    .line 2
    .line 3
    invoke-interface {v0}, Lax/ib/a;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public onBackProgressed(Landroid/window/BackEvent;)V
    .locals 2

    .line 1
    const-string v0, "backEvent"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lax/jb/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->b:Lax/ib/l;

    .line 7
    .line 8
    new-instance v1, Lax/i/b;

    .line 9
    .line 10
    invoke-direct {v1, p1}, Lax/i/b;-><init>(Landroid/window/BackEvent;)V

    .line 11
    .line 12
    .line 13
    invoke-interface {v0, v1}, Lax/ib/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public onBackStarted(Landroid/window/BackEvent;)V
    .locals 2

    .line 1
    const-string v0, "backEvent"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lax/jb/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$g$a;->a:Lax/ib/l;

    .line 7
    .line 8
    new-instance v1, Lax/i/b;

    .line 9
    .line 10
    invoke-direct {v1, p1}, Lax/i/b;-><init>(Landroid/window/BackEvent;)V

    .line 11
    .line 12
    .line 13
    invoke-interface {v0, v1}, Lax/ib/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-void
.end method
