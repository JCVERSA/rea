.class public Landroidx/emoji2/text/e$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/emoji2/text/e$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroidx/emoji2/text/m;)Lax/u0/b;
    .locals 1

    .line 1
    new-instance v0, Lax/u0/d;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lax/u0/d;-><init>(Landroidx/emoji2/text/m;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
