.class Landroidx/emoji2/text/EmojiCompatInitializer$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lax/F0/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/emoji2/text/EmojiCompatInitializer;->d(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic X:Landroidx/emoji2/text/EmojiCompatInitializer;

.field final synthetic q:Landroidx/lifecycle/d;


# direct methods
.method constructor <init>(Landroidx/emoji2/text/EmojiCompatInitializer;Landroidx/lifecycle/d;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/emoji2/text/EmojiCompatInitializer$1;->X:Landroidx/emoji2/text/EmojiCompatInitializer;

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/emoji2/text/EmojiCompatInitializer$1;->q:Landroidx/lifecycle/d;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(Lax/F0/g;)V
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/emoji2/text/EmojiCompatInitializer$1;->X:Landroidx/emoji2/text/EmojiCompatInitializer;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroidx/emoji2/text/EmojiCompatInitializer;->e()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Landroidx/emoji2/text/EmojiCompatInitializer$1;->q:Landroidx/lifecycle/d;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Landroidx/lifecycle/d;->c(Lax/F0/f;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public synthetic b(Lax/F0/g;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lax/F0/a;->a(Lax/F0/b;Lax/F0/g;)V

    return-void
.end method

.method public synthetic c(Lax/F0/g;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lax/F0/a;->d(Lax/F0/b;Lax/F0/g;)V

    return-void
.end method

.method public synthetic e(Lax/F0/g;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lax/F0/a;->b(Lax/F0/b;Lax/F0/g;)V

    return-void
.end method

.method public synthetic f(Lax/F0/g;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lax/F0/a;->e(Lax/F0/b;Lax/F0/g;)V

    return-void
.end method

.method public synthetic h(Lax/F0/g;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lax/F0/a;->c(Lax/F0/b;Lax/F0/g;)V

    return-void
.end method
