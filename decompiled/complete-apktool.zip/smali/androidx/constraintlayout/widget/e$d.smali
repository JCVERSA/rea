.class public Landroidx/constraintlayout/widget/e$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation


# instance fields
.field public a:Z

.field public b:I

.field public c:I

.field public d:F

.field public e:F


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/e$d;->a:Z

    .line 6
    .line 7
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 8
    .line 9
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->c:I

    .line 10
    .line 11
    const/high16 v0, 0x3f800000    # 1.0f

    .line 12
    .line 13
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->d:F

    .line 14
    .line 15
    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 16
    .line 17
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->e:F

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public a(Landroidx/constraintlayout/widget/e$d;)V
    .locals 1

    .line 1
    iget-boolean v0, p1, Landroidx/constraintlayout/widget/e$d;->a:Z

    .line 2
    .line 3
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/e$d;->a:Z

    .line 4
    .line 5
    iget v0, p1, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 6
    .line 7
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 8
    .line 9
    iget v0, p1, Landroidx/constraintlayout/widget/e$d;->d:F

    .line 10
    .line 11
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->d:F

    .line 12
    .line 13
    iget v0, p1, Landroidx/constraintlayout/widget/e$d;->e:F

    .line 14
    .line 15
    iput v0, p0, Landroidx/constraintlayout/widget/e$d;->e:F

    .line 16
    .line 17
    iget p1, p1, Landroidx/constraintlayout/widget/e$d;->c:I

    .line 18
    .line 19
    iput p1, p0, Landroidx/constraintlayout/widget/e$d;->c:I

    .line 20
    .line 21
    return-void
.end method

.method b(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    .line 1
    sget-object v0, Lax/K/c;->l7:[I

    .line 2
    .line 3
    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const/4 p2, 0x1

    .line 8
    iput-boolean p2, p0, Landroidx/constraintlayout/widget/e$d;->a:Z

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 11
    .line 12
    .line 13
    move-result p2

    .line 14
    const/4 v0, 0x0

    .line 15
    :goto_0
    if-ge v0, p2, :cond_4

    .line 16
    .line 17
    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    sget v2, Lax/K/c;->n7:I

    .line 22
    .line 23
    if-ne v1, v2, :cond_0

    .line 24
    .line 25
    iget v2, p0, Landroidx/constraintlayout/widget/e$d;->d:F

    .line 26
    .line 27
    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    iput v1, p0, Landroidx/constraintlayout/widget/e$d;->d:F

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_0
    sget v2, Lax/K/c;->m7:I

    .line 35
    .line 36
    if-ne v1, v2, :cond_1

    .line 37
    .line 38
    iget v2, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 39
    .line 40
    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    iput v1, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 45
    .line 46
    invoke-static {}, Landroidx/constraintlayout/widget/e;->b()[I

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    iget v2, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 51
    .line 52
    aget v1, v1, v2

    .line 53
    .line 54
    iput v1, p0, Landroidx/constraintlayout/widget/e$d;->b:I

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_1
    sget v2, Lax/K/c;->p7:I

    .line 58
    .line 59
    if-ne v1, v2, :cond_2

    .line 60
    .line 61
    iget v2, p0, Landroidx/constraintlayout/widget/e$d;->c:I

    .line 62
    .line 63
    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    iput v1, p0, Landroidx/constraintlayout/widget/e$d;->c:I

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_2
    sget v2, Lax/K/c;->o7:I

    .line 71
    .line 72
    if-ne v1, v2, :cond_3

    .line 73
    .line 74
    iget v2, p0, Landroidx/constraintlayout/widget/e$d;->e:F

    .line 75
    .line 76
    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    iput v1, p0, Landroidx/constraintlayout/widget/e$d;->e:F

    .line 81
    .line 82
    :cond_3
    :goto_1
    add-int/lit8 v0, v0, 0x1

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_4
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 86
    .line 87
    .line 88
    return-void
.end method
